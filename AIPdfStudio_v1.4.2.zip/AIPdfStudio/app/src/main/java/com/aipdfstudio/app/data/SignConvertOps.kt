package com.aipdfstudio.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix as AMatrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.util.Matrix
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.math.max
import kotlin.math.min

/** Where a signature goes on a page, as fractions (0..1) of the page as displayed (top-left origin). */
data class Placement(val fx: Float, val fy: Float, val fw: Float, val fh: Float)

/** Saved signatures (transparent PNGs) in the app's private storage. */
object Signatures {
    fun dir(ctx: Context): File = File(ctx.filesDir, "signatures").apply { mkdirs() }

    fun list(ctx: Context): List<File> =
        (dir(ctx).listFiles()?.filter { it.name.endsWith(".png") } ?: emptyList()).sortedByDescending { it.lastModified() }

    fun save(ctx: Context, bmp: Bitmap): File {
        val f = File(dir(ctx), "sig_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return f
    }
}

object SignOps {
    /** Stamps the signature image at every placement (page index -> spot). */
    fun sign(ctx: Context, uri: Uri, signature: File, placements: Map<Int, Placement>, out: File) {
        if (placements.isEmpty()) throw UserError("Place your signature on at least one page.")
        val bmp = BitmapFactory.decodeFile(signature.path) ?: throw UserError("Couldn't read the signature. Make a new one.")
        val doc = PdfOps.load(ctx, uri)
        try {
            val img = LosslessFactory.createFromImage(doc, bmp)
            for ((index, p) in placements) {
                if (index !in 0 until doc.numberOfPages) continue
                val page = doc.getPage(index)
                val box = page.cropBox
                val pm = PageMath(box.lowerLeftX, box.lowerLeftY, box.width, box.height, page.rotation)
                val m = pm.rectMatrix(p.fx * pm.dispW, p.fy * pm.dispH, p.fw * pm.dispW, p.fh * pm.dispH)
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.drawImage(img, Matrix(m[0], m[1], m[2], m[3], m[4], m[5]))
                }
            }
            try {
                doc.save(out)
            } catch (e: Throwable) {
                out.delete()
                throw e
            }
        } finally {
            doc.close()
            bmp.recycle()
        }
    }
}

object ConvertOps {
    private const val A4_W = 595f
    private const val A4_H = 842f

    /** Decodes a photo at most [maxPx] on its long side, turned upright using its EXIF data. */
    fun decodeImage(ctx: Context, uri: Uri, maxPx: Int): Bitmap? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: return null
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxPx) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val orientation = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val scale = min(1f, maxPx.toFloat() / max(bmp.width, bmp.height))
        if (degrees != 0f || scale < 1f) {
            val m = AMatrix()
            if (scale < 1f) m.postScale(scale, scale)
            if (degrees != 0f) m.postRotate(degrees)
            val turned = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (turned !== bmp) bmp.recycle()
            bmp = turned
        }
        // JPEG has no transparency: put see-through images on white.
        if (bmp.hasAlpha()) {
            val white = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            white.eraseColor(Color.WHITE)
            Canvas(white).drawBitmap(bmp, 0f, 0f, null)
            bmp.recycle()
            bmp = white
        }
        return bmp
    }

    fun imagesToPdf(ctx: Context, uris: List<Uri>, a4: Boolean, out: File, progress: (String) -> Unit) {
        if (uris.isEmpty()) throw UserError("Add at least one image.")
        val doc = PDDocument()
        try {
            uris.forEachIndexed { i, u ->
                progress("Adding image ${i + 1} of ${uris.size}")
                val bmp = decodeImage(ctx, u, 2400) ?: throw UserError("Couldn't read image ${i + 1}. Is it a photo?")
                try {
                    val img = JPEGFactory.createFromImage(doc, bmp, 0.85f)
                    val iw = bmp.width.toFloat()
                    val ih = bmp.height.toFloat()
                    val pw: Float
                    val ph: Float
                    val margin: Float
                    if (a4) {
                        val landscape = iw > ih
                        pw = if (landscape) A4_H else A4_W
                        ph = if (landscape) A4_W else A4_H
                        margin = 24f
                    } else {
                        pw = A4_W
                        ph = A4_W * ih / iw
                        margin = 0f
                    }
                    val s = min((pw - 2 * margin) / iw, (ph - 2 * margin) / ih)
                    val w = iw * s
                    val h = ih * s
                    val page = PDPage(PDRectangle(pw, ph))
                    doc.addPage(page)
                    PDPageContentStream(doc, page).use { it.drawImage(img, (pw - w) / 2, (ph - h) / 2, w, h) }
                } finally {
                    bmp.recycle()
                }
            }
            progress("Saving")
            try {
                doc.save(out)
            } catch (e: Throwable) {
                out.delete()
                throw e
            }
        } finally {
            doc.close()
        }
    }

    /** One JPG per page at good quality (about 150 dpi, at most 3000 px). */
    fun pdfToImages(ctx: Context, uri: Uri, sourceName: String, progress: (String) -> Unit): List<File> {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("Can't open file")
        val made = ArrayList<File>()
        try {
            val r = try {
                PdfRenderer(pfd)
            } catch (e: SecurityException) {
                throw UserError("This PDF is password protected. Unlock it first with the Unlock tool.")
            }
            try {
                for (i in 0 until r.pageCount) {
                    progress("Page ${i + 1} of ${r.pageCount}")
                    val page = r.openPage(i)
                    try {
                        val scale = min(150f / 72f, 3000f / max(page.width, page.height))
                        val w = max(1, (page.width * scale).toInt())
                        val h = max(1, (page.height * scale).toInt())
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val f = Outputs.newFile(ctx, sourceName, "page_${i + 1}", "jpg")
                        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                        bmp.recycle()
                        made.add(f)
                    } finally {
                        page.close()
                    }
                }
            } finally {
                r.close()
            }
            return made
        } catch (e: Throwable) {
            made.forEach { it.delete() }
            throw e
        } finally {
            try { pfd.close() } catch (ignored: Exception) {}
        }
    }

    /** Text of each page (empty string for pages without selectable text). */
    fun pageTexts(doc: PDDocument): List<String> {
        val stripper = PDFTextStripper()
        return (1..doc.numberOfPages).map { n ->
            stripper.startPage = n
            stripper.endPage = n
            stripper.getText(doc).trim()
        }
    }

    private const val NO_TEXT =
        "No text found in this PDF. It looks like a scan or photo. Use the OCR tool to read the text from it."

    fun pdfToText(ctx: Context, uri: Uri, out: File): String {
        val doc = PdfOps.load(ctx, uri)
        try {
            val pages = pageTexts(doc)
            if (pages.all { it.isBlank() }) throw UserError(NO_TEXT)
            val text = pages.joinToString("\n\n")
            out.writeText(text)
            return text
        } finally {
            doc.close()
        }
    }

    fun pdfToWord(ctx: Context, uri: Uri, out: File) {
        val doc = PdfOps.load(ctx, uri)
        try {
            val pages = pageTexts(doc)
            if (pages.all { it.isBlank() }) throw UserError(NO_TEXT)
            try {
                FileOutputStream(out).use { Docx.write(pages, it) }
            } catch (e: Throwable) {
                out.delete()
                throw e
            }
        } finally {
            doc.close()
        }
    }
}
