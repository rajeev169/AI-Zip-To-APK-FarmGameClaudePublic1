package com.aipdfstudio.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aipdfstudio.app.data.CloudLinks
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.ui.AiViewModel
import kotlin.concurrent.thread
import com.aipdfstudio.app.ui.AppRoot
import com.aipdfstudio.app.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    private val ai: AiViewModel by viewModels()
    private var incoming by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handle(intent)
        setContent {
            AppTheme {
                AppRoot(ai = ai, incoming = incoming, onIncomingHandled = { incoming = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    /** VIEW: open the file directly. SEND (Share to AI PDF Studio): copy it first, the other app's permission is temporary. */
    private fun handle(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND) {
            @Suppress("DEPRECATION")
            val shared: Uri = (if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else i.getParcelableExtra(Intent.EXTRA_STREAM)) ?: return
            thread {
                val local = try {
                    Outputs.uri(this, CloudLinks.importShared(this, shared))
                } catch (e: Exception) {
                    null
                }
                runOnUiThread {
                    if (local != null) incoming = local
                    else Toast.makeText(this, "Couldn't open the shared file", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            incoming = i.data
        }
    }
}
