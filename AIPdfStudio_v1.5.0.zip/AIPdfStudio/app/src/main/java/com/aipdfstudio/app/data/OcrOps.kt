package com.aipdfstudio.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.MlKitException
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.state.RenderingMode
import com.tom_roush.pdfbox.util.Matrix
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.min

enum class OcrScript(val label: String, val sub: String) {
    LATIN("English", "Also other Latin-script languages"),
    DEVANAGARI("Hindi", "Also Marathi, Nepali and other Devanagari text")
}

/** One line of text found on a page, with its box in rendered-bitmap pixels. */
private class OcrLine(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)

private class OcrPage(val text: String, val lines: List<OcrLine>, val bmpW: Int, val bmpH: Int, val hadText: Boolean)

private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}

object OcrOps {
    /**
     * Reads text from every page. Pages that already have real text are not scanned again.
     * If [searchablePdf] is given, an invisible text layer is added to a copy of the PDF so it can
     * be searched and copied (Latin script only, because the built-in PDF font has no Hindi letters).
     * Returns all text, pages separated by blank lines.
     */
    suspend fun run(
        ctx: Context,
        uri: Uri,
        script: OcrScript,
        searchablePdf: File?,
        progress: (String) -> Unit,
        maxPages: Int = Int.MAX_VALUE
    ): String {
        // Existing text per page, so we only scan pages that need it.
        val existing: List<String> = PdfOps.load(ctx, uri).use { ConvertOps.pageTexts(it) }
        val recognizer: TextRecognizer = when (script) {
            OcrScript.LATIN -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            OcrScript.DEVANAGARI -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        }
        val pages = ArrayList<OcrPage>()
        try {
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("Can't open file")
            try {
                val r = try {
                    PdfRenderer(pfd)
                } catch (e: SecurityException) {
                    throw UserError("This PDF is password protected. Unlock it first with the Unlock tool.")
                }
                try {
                    for (i in 0 until min(r.pageCount, maxPages)) {
                        val known = existing.getOrNull(i).orEmpty()
                        if (known.length >= 40) {
                            pages.add(OcrPage(known, emptyList(), 1, 1, true))
                            continue
                        }
                        progress("Reading page ${i + 1} of ${r.pageCount}")
                        val bmp = renderForOcr(r, i)
                        try {
                            val result: Text = try {
                                recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
                            } catch (e: MlKitException) {
                                if (e.errorCode == MlKitException.UNAVAILABLE) {
                                    throw UserError(
                                        "The text reader is still being downloaded by Google Play services. " +
                                            "Stay online and try again in a minute."
                                    )
                                }
                                throw e
                            }
                            val lines = ArrayList<OcrLine>()
                            for (block in result.textBlocks) {
                                for (line in block.lines) {
                                    val b = line.boundingBox ?: continue
                                    lines.add(OcrLine(line.text, b.left, b.top, b.right, b.bottom))
                                }
                            }
                            pages.add(OcrPage(result.text.trim(), lines, bmp.width, bmp.height, false))
                        } finally {
                            bmp.recycle()
                        }
                    }
                } finally {
                    r.close()
                }
            } finally {
                try { pfd.close() } catch (ignored: Exception) {}
            }
        } finally {
            recognizer.close()
        }

        val all = pages.joinToString("\n\n") { it.text }.trim()
        if (all.isBlank()) throw UserError("No text could be read. Try a clearer scan, or pick the other language.")

        if (searchablePdf != null) {
            progress("Making the PDF searchable")
            addTextLayer(ctx, uri, pages, searchablePdf)
        }
        return all
    }

    /** Renders a page about 2000 px on its long side, on white. */
    private fun renderForOcr(r: PdfRenderer, index: Int): Bitmap {
        val page = r.openPage(index)
        try {
            val scale = min(4f, 2000f / max(page.width, page.height))
            val w = max(1, (page.width * scale).toInt())
            val h = max(1, (page.height * scale).toInt())
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            page.close()
        }
    }

    private fun addTextLayer(ctx: Context, uri: Uri, pages: List<OcrPage>, out: File) {
        val doc = PdfOps.load(ctx, uri)
        try {
            val font = PDType1Font.HELVETICA
            pages.forEachIndexed { i, p ->
                if (p.hadText || p.lines.isEmpty() || i >= doc.numberOfPages) return@forEachIndexed
                val page = doc.getPage(i)
                val box = page.cropBox
                val pm = PageMath(box.lowerLeftX, box.lowerLeftY, box.width, box.height, page.rotation)
                val sx = pm.dispW / p.bmpW
                val sy = pm.dispH / p.bmpH
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.beginText()
                    cs.setRenderingMode(RenderingMode.NEITHER)
                    for (line in p.lines) {
                        val text = winAnsiOnly(line.text).trim()
                        if (text.isEmpty()) continue
                        val left = line.left * sx
                        val top = line.top * sy
                        val boxW = (line.right - line.left) * sx
                        val boxH = (line.bottom - line.top) * sy
                        if (boxW <= 1f || boxH <= 1f) continue
                        val size = boxH * 0.8f
                        val natural = try {
                            font.getStringWidth(text) / 1000f * size
                        } catch (e: Exception) {
                            continue
                        }
                        if (natural <= 0f) continue
                        val t = pm.textMatrix(left, top + boxH * 0.8f, boxW / natural)
                        cs.setFont(font, size)
                        cs.setTextMatrix(Matrix(t[0], t[1], t[2], t[3], t[4], t[5]))
                        try {
                            cs.showText(text)
                        } catch (e: IllegalArgumentException) {
                            // A character the font can't draw; skip this line.
                        }
                    }
                    cs.endText()
                }
            }
            try {
                doc.save(out)
            } catch (e: Throwable) {
                out.delete()
                throw e
            }
        } finally {
            doc.close()
        }
    }
}
