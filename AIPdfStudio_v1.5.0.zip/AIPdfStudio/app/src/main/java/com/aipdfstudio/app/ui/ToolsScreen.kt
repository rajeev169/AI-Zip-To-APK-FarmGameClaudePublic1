@file:OptIn(ExperimentalMaterial3Api::class)

package com.aipdfstudio.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Compress
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material.icons.outlined.Draw
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Difference
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.MergeType
import androidx.compose.material.icons.outlined.RotateRight
import androidx.compose.material.icons.outlined.Summarize
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material.icons.outlined.TextFields
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.abs

private data class Tool(
    val id: String,
    val title: String,
    val sub: String,
    val icon: ImageVector,
    val ready: Boolean
)

private val sections: List<Pair<String, List<Tool>>> = listOf(
    "Read and AI" to listOf(
        Tool("open", "Open PDF", "Read, pinch zoom, bookmarks", Icons.Outlined.FolderOpen, true),
        Tool("link", "Open from link", "Drive, Dropbox, web", Icons.Outlined.Link, true),
        Tool("ai", "Summarize", "Get the key points", Icons.Outlined.Summarize, true),
        Tool("ai", "Chat with PDF", "Ask questions", Icons.Outlined.ChatBubbleOutline, true),
        Tool("ai", "Translate", "Any language", Icons.Outlined.Translate, true)
    ),
    "Organize" to listOf(
        Tool("merge", "Merge", "Join PDFs into one", Icons.Outlined.MergeType, true),
        Tool("split", "Split", "Pick pages or split up", Icons.Outlined.ContentCut, true),
        Tool("pages", "Page tools", "Rotate, delete, reorder", Icons.Outlined.RotateRight, true),
        Tool("compress", "Compress", "Shrink file size", Icons.Outlined.Compress, true)
    ),
    "Edit and sign" to listOf(
        Tool("edit", "Edit PDF", "Edit text, annotate, sign", Icons.Outlined.Edit, true),
        Tool("sign", "Sign", "Draw or type, then place", Icons.Outlined.Draw, true),
        Tool("forms", "Fill form", "Type into PDF forms", Icons.Outlined.EditNote, true),
        Tool("redact", "Redact", "Hide private info", Icons.Outlined.VisibilityOff, true)
    ),
    "Protect" to listOf(
        Tool("lock", "Lock", "Add a password", Icons.Outlined.Lock, true),
        Tool("unlock", "Unlock", "Remove a password", Icons.Outlined.LockOpen, true)
    ),
    "Scan and convert" to listOf(
        Tool("scan", "Scan to PDF", "Auto edge detection", Icons.Outlined.DocumentScanner, true),
        Tool("convert", "Convert", "Images, JPG, Word, text", Icons.Outlined.Sync, true),
        Tool("ocr", "OCR", "Read scanned text", Icons.Outlined.TextFields, true),
        Tool("compare", "Compare", "Find what changed", Icons.Outlined.Difference, true)
    )
)

@Composable
fun ToolsScreen(onOpenFile: () -> Unit, onAi: () -> Unit, onTool: (String) -> Unit, onSoon: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val tints: List<Pair<Color, Color>> = listOf(
        cs.primaryContainer to cs.onPrimaryContainer,
        cs.tertiaryContainer to cs.onTertiaryContainer,
        cs.secondaryContainer to cs.onSecondaryContainer,
        cs.errorContainer to cs.onErrorContainer
    )

    Scaffold(
        containerColor = cs.background,
        contentWindowInsets = WindowInsets.statusBars
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Tools", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Medium)
            }
            sections.forEach { (title, tools) ->
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        title,
                        style = MaterialTheme.typography.titleSmall,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                items(tools) { t ->
                    val tint = tints[abs(t.title.hashCode()) % tints.size]
                    ToolCard(t, tint.first, tint.second) {
                        when {
                            !t.ready -> onSoon(t.title)
                            t.id == "open" -> onOpenFile()
                            t.id == "ai" -> onAi()
                            else -> onTool(t.id)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolCard(t: Tool, bg: Color, fg: Color, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Box(
                Modifier.size(40.dp).background(bg, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(t.icon, contentDescription = null, tint = fg) }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                if (!t.ready) {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Soon",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surfaceContainerHighest, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Text(t.sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
