@file:Suppress("DEPRECATION") // android.hardware.Camera: simple, and works on every phone this app supports

package com.aipdfstudio.app.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.SurfaceTexture
import android.hardware.Camera
import android.view.TextureView
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material.icons.outlined.Draw
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.LineWeight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.aipdfstudio.app.data.ConvertOps
import com.aipdfstudio.app.data.InkCutout
import com.aipdfstudio.app.data.Signatures
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val PadRed = Color(0xFFE53935)

/** Pen colours offered while drawing (the same set the ✏️ panel uses). */
private val PadColors = listOf(0x000000, 0x1E3AF2, 0x0D2B6B, 0xE53935, 0x1B8A3A, 0x7E22CE, 0x795548, 0x8C8C8C)

private enum class AddStage { SHEET, DRAW, SCAN, TYPE, PREVIEW, NONE }

/** Keeps the screen in [orientation] while shown, then puts it back. */
@Composable
private fun LockOrientation(orientation: Int) {
    val act = LocalContext.current.findActivity()
    DisposableEffect(act, orientation) {
        val old = act?.requestedOrientation
        act?.requestedOrientation = orientation
        onDispose { if (act != null && old != null) act.requestedOrientation = old }
    }
}

private fun cutToBitmap(c: InkCutout.Cut): Bitmap = Bitmap.createBitmap(c.px, c.w, c.h, Bitmap.Config.ARGB_8888)

/** Cleans a photo of a signature (scaled for speed). Null when no ink was found. */
private fun cleanPhoto(src: Bitmap): Bitmap? {
    val s = min(1f, 1400f / max(src.width, src.height))
    val b = if (s < 1f) Bitmap.createScaledBitmap(src, max(1, (src.width * s).roundToInt()), max(1, (src.height * s).roundToInt()), true) else src
    val px = IntArray(b.width * b.height)
    b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
    val cut = InkCutout.extract(px, b.width, b.height) ?: return null
    if (cut.inkShare > 0.45f) return null // mostly dark: not a signature on paper
    return cutToBitmap(cut)
}

/**
 * "Add signature": a sheet with Draw / Scan / Import from Gallery / Type, and each of those screens.
 * [onCreated] gets the saved signature file (kept in the tray when "Save as template" is ticked).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignatureAdder(onDismiss: () -> Unit, onCreated: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var stage by remember { mutableStateOf(AddStage.SHEET) }
    var cleaned by remember { mutableStateOf<Bitmap?>(null) }
    var fromCamera by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }

    fun finish(f: File) {
        stage = AddStage.NONE
        onCreated(f)
    }
    fun showCleaned(b: Bitmap?) {
        working = false
        if (b == null) {
            Toast.makeText(ctx, "No signature found. Use dark ink on white paper, in good light.", Toast.LENGTH_LONG).show()
            stage = if (fromCamera) AddStage.SCAN else AddStage.SHEET
        } else {
            cleaned = b
            stage = AddStage.PREVIEW
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) {
            stage = AddStage.SHEET
            return@rememberLauncherForActivityResult
        }
        fromCamera = false
        working = true
        scope.launch {
            val b = withContext(Dispatchers.Default) {
                try {
                    ConvertOps.decodeImage(ctx, uri, 1600)?.let { cleanPhoto(it) }
                } catch (e: Throwable) {
                    null
                }
            }
            showCleaned(b)
        }
    }
    val camPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            stage = AddStage.SCAN
        } else {
            Toast.makeText(ctx, "Camera permission is needed to scan your signature", Toast.LENGTH_LONG).show()
            stage = AddStage.SHEET
        }
    }

    when (stage) {
        AddStage.SHEET -> ModalBottomSheet(onDismissRequest = onDismiss) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 18.dp)) {
                Text(
                    "Add signature",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp)
                )
                @Composable
                fun Choice(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
                    Row(
                        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 15.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(icon, contentDescription = null)
                        Spacer(Modifier.width(18.dp))
                        Text(label, style = MaterialTheme.typography.bodyLarge)
                    }
                }
                Choice(Icons.Outlined.Draw, "Draw signature") { stage = AddStage.DRAW }
                Choice(Icons.Outlined.DocumentScanner, "Scan signature") {
                    fromCamera = true
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) stage = AddStage.SCAN
                    else camPermission.launch(Manifest.permission.CAMERA)
                }
                Choice(Icons.Outlined.AddPhotoAlternate, "Import from Gallery") {
                    stage = AddStage.NONE
                    gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                Choice(Icons.Outlined.Keyboard, "Type signature") { stage = AddStage.TYPE }
            }
        }
        AddStage.DRAW -> DrawSignaturePad(
            onClose = { stage = AddStage.SHEET },
            onDone = { bmp, ink, keep ->
                val f = Signatures.save(ctx, bmp, ink, keep)
                bmp.recycle()
                finish(f)
            }
        )
        AddStage.SCAN -> ScanSignatureScreen(
            onClose = { stage = AddStage.SHEET },
            onShot = { photo ->
                working = true
                stage = AddStage.NONE
                scope.launch {
                    val b = withContext(Dispatchers.Default) { try { cleanPhoto(photo) } catch (e: Throwable) { null } }
                    showCleaned(b)
                }
            }
        )
        AddStage.TYPE -> TypeSignatureDialog(
            onClose = { stage = AddStage.SHEET },
            onDone = { bmp, keep ->
                val f = Signatures.save(ctx, bmp, null, keep)
                bmp.recycle()
                finish(f)
            }
        )
        AddStage.PREVIEW -> cleaned?.let { b ->
            CleanedPreview(
                bmp = b,
                retryLabel = if (fromCamera) "Retake" else "Choose another",
                onRetry = {
                    if (fromCamera) stage = AddStage.SCAN
                    else { stage = AddStage.NONE; gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                },
                onClose = { stage = AddStage.SHEET },
                onUse = { keep -> finish(Signatures.save(ctx, b, null, keep)) }
            )
        }
        AddStage.NONE -> Unit
    }

    if (working) {
        AlertDialog(onDismissRequest = {}, confirmButton = {}, text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                Spacer(Modifier.width(16.dp))
                Text("Cleaning up the background…")
            }
        })
    }
}

// ------------------------------------------------------------------ draw

/** Full-screen, sideways pad: ✕, clear, undo, redo, ✓ at the top; Save as template, thickness and colour at the bottom. */
@Composable
private fun DrawSignaturePad(onClose: () -> Unit, onDone: (Bitmap, com.aipdfstudio.app.data.SigInk?, Boolean) -> Unit) {
    LockOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE)
    val density = LocalDensity.current
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    val current = remember { mutableStateListOf<Offset>() }
    val undo = remember { ArrayDeque<List<List<Offset>>>() }
    val redo = remember { ArrayDeque<List<List<Offset>>>() }
    var histTick by remember { mutableIntStateOf(0) } // re-reads undo/redo availability
    var thick by remember { mutableFloatStateOf(3f) }
    var color by remember { mutableIntStateOf(0x000000) }
    var keep by remember { mutableStateOf(true) }
    var showThick by remember { mutableStateOf(false) }
    var showColor by remember { mutableStateOf(false) }
    val strokePx = with(density) { (thick * 1.3f).dp.toPx() }

    fun record() { undo.addLast(strokes.toList()); redo.clear(); histTick++ }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.White) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 12.dp)) {
                Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Outlined.Close, contentDescription = "Close") }
                    Spacer(Modifier.weight(1f))
                    val t = histTick
                    IconButton(onClick = { record(); strokes.clear() }, enabled = strokes.isNotEmpty() && t >= 0) {
                        Icon(Icons.Outlined.CleaningServices, contentDescription = "Clear")
                    }
                    IconButton(onClick = {
                        undo.removeLastOrNull()?.let { prev -> redo.addLast(strokes.toList()); strokes.clear(); strokes.addAll(prev); histTick++ }
                    }, enabled = undo.isNotEmpty() && t >= 0) { Icon(Icons.AutoMirrored.Outlined.Undo, contentDescription = "Undo") }
                    IconButton(onClick = {
                        redo.removeLastOrNull()?.let { next -> undo.addLast(strokes.toList()); strokes.clear(); strokes.addAll(next); histTick++ }
                    }, enabled = redo.isNotEmpty() && t >= 0) { Icon(Icons.AutoMirrored.Outlined.Redo, contentDescription = "Redo") }
                    val ready = strokes.isNotEmpty()
                    Box(
                        Modifier.padding(start = 6.dp).size(width = 52.dp, height = 36.dp)
                            .background(if (ready) PadRed else PadRed.copy(alpha = 0.15f), RoundedCornerShape(18.dp))
                            .clickable(enabled = ready) {
                                strokesToBitmap(strokes.toList(), (0xFF000000.toInt() or color), strokePx)?.let { (bmp, ink) -> onDone(bmp, ink, keep) }
                            },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Outlined.Check, contentDescription = "Done", tint = if (ready) Color.White else PadRed.copy(alpha = 0.5f)) }
                }
                val dash = remember { PathEffect.dashPathEffect(floatArrayOf(12f, 10f)) }
                Box(
                    Modifier.weight(1f).fillMaxWidth().padding(horizontal = 28.dp)
                        .background(Color(0xFFF6F6F6), RoundedCornerShape(14.dp))
                        .drawBehind {
                            drawRoundRect(Color(0xFFD0D0D0), cornerRadius = CornerRadius(14.dp.toPx()), style = Stroke(2f, pathEffect = dash))
                        }
                ) {
                    if (strokes.isEmpty() && current.isEmpty()) {
                        Text(
                            "Sign here",
                            style = TextStyle(fontStyle = FontStyle.Italic, fontSize = 22.sp, color = Color(0xFF6B6B6B)),
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                    Canvas(
                        Modifier.fillMaxSize()
                            .pointerInput(Unit) {
                                detectTapGestures { p -> record(); strokes.add(listOf(p, p + Offset(0.6f, 0.6f))) }
                            }
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { p -> current.clear(); current.add(p) },
                                    onDragEnd = {
                                        if (current.size > 1) { record(); strokes.add(current.toList()) }
                                        current.clear()
                                    },
                                    onDragCancel = { current.clear() }
                                ) { change, _ ->
                                    change.consume()
                                    current.add(change.position)
                                }
                            }
                    ) {
                        val c = col(color)
                        (strokes + listOf(current.toList())).forEach { pts ->
                            if (pts.size > 1) {
                                val path = Path().apply { moveTo(pts[0].x, pts[0].y); for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y) }
                                drawPath(path, c, style = Stroke(strokePx, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.clickable { keep = !keep }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = keep, onCheckedChange = { keep = it })
                        Text("Save as template", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF555555))
                    }
                    Spacer(Modifier.weight(1f))
                    Box {
                        IconButton(onClick = { showThick = true }) { Icon(Icons.Outlined.LineWeight, contentDescription = "Thickness") }
                        DropdownMenu(expanded = showThick, onDismissRequest = { showThick = false }) {
                            Column(Modifier.width(240.dp).padding(horizontal = 14.dp, vertical = 6.dp)) {
                                Text("Thickness  ${thick.roundToInt()}", style = MaterialTheme.typography.labelLarge)
                                Slider(
                                    value = thick, onValueChange = { thick = it }, valueRange = 1f..16f, steps = 14,
                                    colors = SliderDefaults.colors(thumbColor = PadRed, activeTrackColor = PadRed, activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent)
                                )
                            }
                        }
                    }
                    Box {
                        IconButton(onClick = { showColor = true }) {
                            Box(Modifier.size(22.dp).border(2.dp, Color.Black, RoundedCornerShape(4.dp)).padding(3.dp).background(col(color), RoundedCornerShape(2.dp)))
                        }
                        DropdownMenu(expanded = showColor, onDismissRequest = { showColor = false }) {
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                PadColors.forEach { c ->
                                    Box(
                                        Modifier.size(30.dp).background(col(c), RoundedCornerShape(5.dp)).clickable { color = c; showColor = false },
                                        contentAlignment = Alignment.Center
                                    ) { if (c == color) Icon(Icons.Outlined.Check, contentDescription = "Selected", tint = Color.White, modifier = Modifier.size(18.dp)) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun col(c: Int) = Color(0xFF000000.toInt() or c)

// ------------------------------------------------------------------ scan

/** The back camera, the old simple API. Opened when the preview surface exists, closed when it goes. */
private class SigCamera {
    var cam: Camera? = null
        private set
    var orientation = 90
        private set
    /** Preview aspect (width / height) as shown upright on a phone held normally. */
    var aspect = 0.75f
        private set

    private fun pick(sizes: List<Camera.Size>, maxW: Int): Camera.Size? {
        val four3 = sizes.filter { abs(it.width.toFloat() / it.height - 4f / 3f) < 0.03f && it.width <= maxW }
        return (four3.ifEmpty { sizes.filter { it.width <= maxW } }.ifEmpty { sizes }).maxByOrNull { it.width * it.height }
    }

    fun open(tex: SurfaceTexture): Boolean = try {
        close()
        val n = Camera.getNumberOfCameras()
        val info = Camera.CameraInfo()
        var id = 0
        for (i in 0 until n) {
            Camera.getCameraInfo(i, info)
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) { id = i; break }
        }
        Camera.getCameraInfo(id, info)
        orientation = info.orientation
        val c = Camera.open(id)
        val p = c.parameters
        val prev = pick(p.supportedPreviewSizes, 1920)
        val pic = pick(p.supportedPictureSizes, 3300)
        if (prev != null) p.setPreviewSize(prev.width, prev.height)
        if (pic != null) p.setPictureSize(pic.width, pic.height)
        if (p.supportedFocusModes?.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE) == true) {
            p.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
        }
        try { c.parameters = p } catch (e: Exception) {}
        val ps = c.parameters.previewSize
        aspect = if (orientation % 180 != 0) ps.height.toFloat() / ps.width else ps.width.toFloat() / ps.height
        c.setDisplayOrientation(orientation)
        c.setPreviewTexture(tex)
        c.startPreview()
        cam = c
        true
    } catch (e: Exception) {
        close()
        false
    }

    fun shoot(cb: (ByteArray?) -> Unit) {
        val c = cam ?: return cb(null)
        try {
            c.takePicture(null, null) { data, _ -> cb(data) }
        } catch (e: Exception) {
            cb(null)
        }
    }

    fun close() {
        val c = cam ?: return
        cam = null
        try { c.stopPreview() } catch (ignored: Exception) {}
        try { c.release() } catch (ignored: Exception) {}
    }
}

/** Guide box as fractions of the preview: wide and centred, like a signature line. */
private const val GUIDE_L = 0.06f
private const val GUIDE_R = 0.94f
private const val GUIDE_RATIO = 2.6f // width / height

/** Camera screen: "Fit it inside the borders", a white frame and a shutter. Returns the frame area, upright. */
@Composable
private fun ScanSignatureScreen(onClose: () -> Unit, onShot: (Bitmap) -> Unit) {
    LockOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val camera = remember { SigCamera() }
    var texture by remember { mutableStateOf<SurfaceTexture?>(null) }
    var aspect by remember { mutableFloatStateOf(0.75f) }
    var ready by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }

    fun start() {
        val t = texture ?: return
        ready = camera.open(t)
        failed = !ready
        if (ready) aspect = camera.aspect
    }

    // Let go of the camera when the app goes to the background, take it back when it returns.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_PAUSE -> { camera.close(); ready = false }
                Lifecycle.Event.ON_RESUME -> if (texture != null && camera.cam == null) start()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); camera.close() }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Outlined.Close, contentDescription = "Close", tint = Color.White) }
                }
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(aspect)) {
                        AndroidView(
                            factory = { c ->
                                TextureView(c).apply {
                                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                        override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { texture = st; start() }
                                        override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                                        override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { camera.close(); texture = null; ready = false; return true }
                                        override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                        // Dim everything outside the guide box, and draw the box.
                        Canvas(Modifier.fillMaxSize()) {
                            val gw = size.width * (GUIDE_R - GUIDE_L)
                            val gh = gw / GUIDE_RATIO
                            val l = size.width * GUIDE_L
                            val t = (size.height - gh) / 2
                            clipRect(l, t, l + gw, t + gh, clipOp = ClipOp.Difference) { drawRect(Color(0x88000000)) }
                            drawRoundRect(Color.White, Offset(l, t), Size(gw, gh), CornerRadius(10.dp.toPx()), style = Stroke(2.dp.toPx()))
                        }
                        Text(
                            "Fit it inside the borders",
                            color = Color.White,
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.align(Alignment.Center).padding(bottom = (maxWidth * (GUIDE_R - GUIDE_L) / GUIDE_RATIO) + 28.dp)
                        )
                        if (failed) {
                            Text(
                                "Couldn't open the camera. Close other camera apps and try again.",
                                color = Color.White,
                                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp)
                            )
                        }
                    }
                }
                Box(Modifier.fillMaxWidth().height(130.dp), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.size(72.dp).border(4.dp, Color.White, CircleShape).padding(7.dp)
                            .background(if (ready && !busy) Color.White else Color(0x66FFFFFF), CircleShape)
                            .clickable(enabled = ready && !busy) {
                                busy = true
                                camera.shoot { data ->
                                    scope.launch {
                                        val shot = withContext(Dispatchers.Default) { data?.let { cropGuide(it, camera.orientation) } }
                                        busy = false
                                        if (shot != null) onShot(shot)
                                        else {
                                            Toast.makeText(ctx, "Couldn't take the photo. Try again.", Toast.LENGTH_SHORT).show()
                                            start()
                                        }
                                    }
                                }
                            }
                    )
                    if (busy) CircularProgressIndicator(color = PadRed, modifier = Modifier.size(80.dp))
                }
            }
        }
    }
}

/** Decodes the photo, turns it upright and keeps only what was inside the guide box. */
private fun cropGuide(jpeg: ByteArray, rotation: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, bounds)
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 2000) sample *= 2
    val raw = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
    val up = if (rotation % 360 != 0) {
        val m = android.graphics.Matrix().apply { postRotate(rotation.toFloat()) }
        Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true).also { if (it !== raw) raw.recycle() }
    } else raw
    val w = up.width
    val h = up.height
    val gw = w * (GUIDE_R - GUIDE_L)
    val gh = gw / GUIDE_RATIO
    val l = (w * GUIDE_L).roundToInt()
    val t = ((h - gh) / 2).roundToInt().coerceAtLeast(0)
    val cw = gw.roundToInt().coerceAtMost(w - l)
    val ch = gh.roundToInt().coerceAtMost(h - t)
    if (cw <= 8 || ch <= 8) return up
    return Bitmap.createBitmap(up, l, t, cw, ch).also { if (it !== up) up.recycle() }
}

// ------------------------------------------------------------------ preview and type

/** Shows the cleaned-up signature (ink only) before it's used. */
@Composable
private fun CleanedPreview(bmp: Bitmap, retryLabel: String, onRetry: () -> Unit, onClose: () -> Unit, onUse: (Boolean) -> Unit) {
    var keep by remember { mutableStateOf(true) }
    val image = remember(bmp) { bmp.asImageBitmap() }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Your signature") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("The paper was removed; only the ink is kept.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Box(
                    Modifier.fillMaxWidth().height(140.dp).background(Color.White, RoundedCornerShape(12.dp))
                        .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) { Image(image, contentDescription = "Cleaned signature", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()) }
                Row(Modifier.clickable { keep = !keep }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = keep, onCheckedChange = { keep = it })
                    Text("Save as template")
                }
            }
        },
        confirmButton = { Button(onClick = { onUse(keep) }) { Text("Use") } },
        dismissButton = { OutlinedButton(onClick = onRetry) { Text(retryLabel) } }
    )
}

@Composable
private fun TypeSignatureDialog(onClose: () -> Unit, onDone: (Bitmap, Boolean) -> Unit) {
    var typed by remember { mutableStateOf("") }
    var color by remember { mutableIntStateOf(0x000000) }
    var keep by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Type signature") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = typed, onValueChange = { typed = it.take(40) }, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Box(Modifier.fillMaxWidth().height(90.dp).background(Color(0xFFF6F6F6), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Text(
                        typed.ifBlank { "Your name" },
                        style = TextStyle(fontFamily = FontFamily.Cursive, fontSize = 36.sp, color = if (typed.isBlank()) Color(0xFFBBBBBB) else col(color))
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PadColors.take(6).forEach { c ->
                        Box(Modifier.size(28.dp).background(col(c), RoundedCornerShape(5.dp)).clickable { color = c }, contentAlignment = Alignment.Center) {
                            if (c == color) Icon(Icons.Outlined.Check, contentDescription = "Selected", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }
                Row(Modifier.clickable { keep = !keep }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = keep, onCheckedChange = { keep = it })
                    Text("Save as template")
                }
            }
        },
        confirmButton = {
            TextButton(enabled = typed.isNotBlank(), onClick = { onDone(textToBitmap(typed.trim(), 0xFF000000.toInt() or color), keep) }) { Text("Use") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
