package com.aipdfstudio.app.data

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

enum class ListenVoice(val label: String) { ENGLISH("English (India)"), HINDI("हिन्दी"), AUTO("Auto") }
enum class SleepMode(val label: String, val minutes: Int) { OFF("Off", 0), M15("15 min", 15), M30("30 min", 30), M60("60 min", 60), CHAPTER("End of chapter", -1) }

/** Everything the Listen screen shows. */
data class ListenState(
    val uri: Uri? = null,
    val name: String = "",
    val pages: List<List<String>> = emptyList(),
    val chapters: List<OutlineEntry> = emptyList(),
    val page: Int = 0,
    val sentence: Int = 0,
    val playing: Boolean = false,
    val loading: String? = null,
    val error: String? = null,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val voice: ListenVoice = ListenVoice.AUTO,
    val sleep: SleepMode = SleepMode.OFF,
    val sleepAt: Long = 0L,
    val fromPage: Int = 0,
    val toPage: Int = Int.MAX_VALUE,
    val missingVoice: String? = null,
    val ready: Boolean = false
) {
    val pageCount get() = pages.size
    val lastPage get() = minOf(toPage, pageCount - 1)
    val current: String? get() = pages.getOrNull(page)?.getOrNull(sentence)
    /** 0..1 through the chosen pages, by characters. */
    val progress: Float get() {
        if (pages.isEmpty()) return 0f
        val range = (fromPage..lastPage)
        val total = range.sumOf { p -> pages[p].sumOf { it.length } }.coerceAtLeast(1)
        val done = range.filter { it < page }.sumOf { p -> pages[p].sumOf { it.length } } + pages.getOrNull(page)?.take(sentence)?.sumOf { it.length }.let { it ?: 0 }
        return (done.toFloat() / total).coerceIn(0f, 1f)
    }
    val charsLeft: Int get() {
        if (pages.isEmpty()) return 0
        return (page..lastPage).sumOf { p -> if (p == page) pages[p].drop(sentence).sumOf { it.length } else pages[p].sumOf { it.length } }
    }
    /** Title of the chapter the current page is in (from the PDF's table of contents). */
    val chapterTitle: String? get() = chapters.lastOrNull { it.page in 0..page }?.title
}

/**
 * Reads a PDF aloud with the phone's text-to-speech voice, sentence by sentence.
 * Lives as long as the app; [ListenService] keeps it running with the screen off.
 */
object ListenPlayer {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(ListenState())
    val state: StateFlow<ListenState> = _state

    private var app: Context? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingPlay = false
    private var loadJob: Job? = null
    private var utterance = 0L
    private var lastLang: Locale? = null
    private var focus: AudioFocusRequest? = null

    private fun set(f: (ListenState) -> ListenState) { _state.value = f(_state.value) }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("listen", Context.MODE_PRIVATE)

    private fun ensureTts(ctx: Context) {
        if (tts != null) return
        app = ctx.applicationContext
        val p = prefs(ctx)
        set { it.copy(speed = p.getFloat("speed", 1f), pitch = p.getFloat("pitch", 1f), voice = ListenVoice.entries.getOrElse(p.getInt("voice", 2)) { ListenVoice.AUTO }) }
        tts = TextToSpeech(ctx.applicationContext) { status ->
            main.post {
                ttsReady = status == TextToSpeech.SUCCESS
                if (!ttsReady) set { it.copy(error = "No text-to-speech voice on this phone. Install \"Speech Services by Google\" from Play Store.", playing = false) }
                else {
                    tts?.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    tts?.setOnUtteranceProgressListener(listener)
                    if (pendingPlay) { pendingPlay = false; play() }
                }
            }
        }
    }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(id: String?) {}
        override fun onDone(id: String?) { main.post { if (id == utterance.toString() && _state.value.playing) advance() } }
        @Deprecated("old API")
        override fun onError(id: String?) { main.post { if (id == utterance.toString() && _state.value.playing) advance() } }
        override fun onError(id: String?, code: Int) { main.post { if (id == utterance.toString() && _state.value.playing) advance() } }
    }

    /** Loads [uri] (skipped if it's already loaded) and goes to where the user stopped last time. */
    fun open(ctx: Context, uri: Uri, name: String) {
        ensureTts(ctx)
        if (_state.value.uri == uri && (_state.value.ready || _state.value.loading != null)) return
        stop()
        set { it.copy(uri = uri, name = name, pages = emptyList(), page = 0, sentence = 0, loading = "Getting your notes ready…", error = null, ready = false, fromPage = 0, toPage = Int.MAX_VALUE) }
        loadJob?.cancel()
        loadJob = scope.launch {
            try {
                val (pages, chapters) = withContext(Dispatchers.IO) {
                    val texts = OcrOps.pageTextsForListening(ctx, uri) { msg -> main.post { set { s -> s.copy(loading = msg) } } }
                    texts.map { ListenText.sentences(it) } to Outline.read(ctx, uri)
                }
                if (pages.all { it.isEmpty() }) throw UserError("No text found in this PDF to read aloud.")
                val saved = prefs(ctx).getString("pos:$uri", null)?.split(':')
                var pg = saved?.getOrNull(0)?.toIntOrNull()?.coerceIn(0, pages.size - 1) ?: 0
                var se = saved?.getOrNull(1)?.toIntOrNull() ?: 0
                if (se >= pages[pg].size) se = 0
                while (pg < pages.size - 1 && pages[pg].isEmpty()) { pg++; se = 0 }
                set { it.copy(pages = pages, chapters = chapters.filter { c -> c.page >= 0 }, page = pg, sentence = se, loading = null, ready = true) }
            } catch (e: Throwable) {
                set { it.copy(loading = null, error = PdfOps.friendly(e)) }
            }
        }
    }

    private fun savePos() {
        val s = _state.value
        val c = app ?: return
        if (s.uri != null) prefs(c).edit().putString("pos:${s.uri}", "${s.page}:${s.sentence}").apply()
    }

    private fun localeFor(text: String): Locale = when (_state.value.voice) {
        ListenVoice.ENGLISH -> Locale("en", "IN")
        ListenVoice.HINDI -> Locale("hi", "IN")
        ListenVoice.AUTO -> if (ListenText.isHindi(text)) Locale("hi", "IN") else Locale("en", "IN")
    }

    private fun speakCurrent() {
        val t = tts ?: return
        val s = _state.value
        val text = s.current ?: run { advance(); return }
        val loc = localeFor(text)
        if (loc != lastLang) {
            val r = t.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                val fallback = if (loc.language == "hi") Locale("en", "IN") else Locale.US
                if (t.setLanguage(fallback) < 0) t.setLanguage(Locale.US)
                set { it.copy(missingVoice = if (loc.language == "hi") "Hindi" else "English (India)") }
            }
            lastLang = loc
        }
        t.setSpeechRate(s.speed)
        t.setPitch(s.pitch)
        utterance++
        t.speak(text.replace("•", ""), TextToSpeech.QUEUE_FLUSH, Bundle(), utterance.toString())
    }

    private fun advance() {
        val s = _state.value
        var pg = s.page
        var se = s.sentence + 1
        while (pg <= s.lastPage && se >= (s.pages.getOrNull(pg)?.size ?: 0)) {
            pg++; se = 0
            // "End of chapter": stop where the next chapter (or, without contents, the next page) starts.
            if (s.sleep == SleepMode.CHAPTER && pg <= s.lastPage && (s.chapters.isEmpty() || s.chapters.any { it.page == pg })) {
                set { it.copy(page = pg, sentence = 0) }
                pause(); set { it.copy(sleep = SleepMode.OFF) }
                return
            }
        }
        if (pg > s.lastPage) {
            set { it.copy(playing = false, page = s.fromPage, sentence = 0) }
            savePos(); abandonFocus(); ListenService.refresh(app)
            return
        }
        set { it.copy(page = pg, sentence = se) }
        savePos()
        speakCurrent()
        ListenService.refresh(app)
    }

    fun play() {
        val c = app ?: return
        val s = _state.value
        if (!s.ready) return
        if (!ttsReady) { pendingPlay = true; return }
        if (!requestFocus(c)) return
        var pg = s.page.coerceIn(s.fromPage, s.lastPage)
        var se = if (pg != s.page) 0 else s.sentence
        while (pg < s.lastPage && s.pages[pg].isEmpty()) { pg++; se = 0 }
        set { it.copy(playing = true, page = pg, sentence = se, error = null) }
        ListenService.start(c)
        speakCurrent()
    }

    fun pause() {
        utterance++
        tts?.stop()
        set { it.copy(playing = false) }
        savePos()
        abandonFocus()
        ListenService.refresh(app)
    }

    fun toggle() = if (_state.value.playing) pause() else play()

    /** Jump to a sentence (and keep playing if it was). */
    fun seek(page: Int, sentence: Int) {
        val s = _state.value
        if (s.pages.isEmpty()) return
        val pg = page.coerceIn(0, s.pages.size - 1)
        val se = sentence.coerceIn(0, maxOf(0, s.pages[pg].size - 1))
        set { it.copy(page = pg, sentence = se) }
        savePos()
        if (s.playing) speakCurrent()
        ListenService.refresh(app)
    }

    fun nextSentence() {
        val s = _state.value
        if (s.sentence + 1 < (s.pages.getOrNull(s.page)?.size ?: 0)) seek(s.page, s.sentence + 1) else nextPage()
    }

    fun prevSentence() {
        val s = _state.value
        if (s.sentence > 0) seek(s.page, s.sentence - 1)
        else if (s.page > 0) seek(s.page - 1, (s.pages[s.page - 1].size - 1).coerceAtLeast(0))
    }

    fun nextPage() { val s = _state.value; if (s.page + 1 < s.pageCount) seek(s.page + 1, 0) }
    fun prevPage() { val s = _state.value; if (s.sentence > 0) seek(s.page, 0) else if (s.page > 0) seek(s.page - 1, 0) }

    fun setSpeed(v: Float) { set { it.copy(speed = v) }; app?.let { prefs(it).edit().putFloat("speed", v).apply() }; if (_state.value.playing) speakCurrent() }
    fun setPitch(v: Float) { set { it.copy(pitch = v) }; app?.let { prefs(it).edit().putFloat("pitch", v).apply() } }
    fun setVoice(v: ListenVoice) {
        set { it.copy(voice = v, missingVoice = null) }; lastLang = null
        app?.let { prefs(it).edit().putInt("voice", v.ordinal).apply() }
        if (_state.value.playing) speakCurrent()
    }

    private val sleepRunnable = Runnable { pause(); set { it.copy(sleep = SleepMode.OFF, sleepAt = 0L) } }
    fun setSleep(m: SleepMode) {
        main.removeCallbacks(sleepRunnable)
        val at = if (m.minutes > 0) System.currentTimeMillis() + m.minutes * 60_000L else 0L
        if (m.minutes > 0) main.postDelayed(sleepRunnable, m.minutes * 60_000L)
        set { it.copy(sleep = m, sleepAt = at) }
    }

    /** Read only pages [from]..[to] (1-based, as the user types them). */
    fun setRange(from: Int, to: Int) {
        val s = _state.value
        val f = (from - 1).coerceIn(0, maxOf(0, s.pageCount - 1))
        val t = (to - 1).coerceIn(f, maxOf(0, s.pageCount - 1))
        set { it.copy(fromPage = f, toPage = t) }
        if (s.page !in f..t) seek(f, 0)
    }

    /** Stops reading and closes the notification. */
    fun stop() {
        utterance++
        tts?.stop()
        if (_state.value.playing) savePos()
        set { it.copy(playing = false) }
        abandonFocus()
        main.removeCallbacks(sleepRunnable)
        ListenService.stop(app)
    }

    fun clearMissingVoice() = set { it.copy(missingVoice = null) }

    fun installVoicesIntent(): Intent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    // ------------------------------------------------------------ audio focus (pause for calls and other audio)

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) main.post { if (_state.value.playing) pause() }
    }

    private fun requestFocus(c: Context): Boolean {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setOnAudioFocusChangeListener(focusListener)
            .build()
        focus = req
        return am.requestAudioFocus(req) != AudioManager.AUDIOFOCUS_REQUEST_FAILED
    }

    private fun abandonFocus() {
        val c = app ?: return
        val f = focus ?: return
        (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(f)
        focus = null
    }

    @Suppress("unused")
    private val sdk = Build.VERSION.SDK_INT
}

/** Hooks so the data layer can drive the notification without knowing the service class. */
object ListenService {
    var onStart: ((Context) -> Unit)? = null
    var onRefresh: ((Context) -> Unit)? = null
    var onStop: ((Context) -> Unit)? = null
    fun start(c: Context?) { c?.let { onStart?.invoke(it) } }
    fun refresh(c: Context?) { c?.let { onRefresh?.invoke(it) } }
    fun stop(c: Context?) { c?.let { onStop?.invoke(it) } }
}
