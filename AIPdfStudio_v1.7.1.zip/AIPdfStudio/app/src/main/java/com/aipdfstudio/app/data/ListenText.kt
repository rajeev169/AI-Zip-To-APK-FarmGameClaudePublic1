package com.aipdfstudio.app.data

/** Turns page text into sentences that read well aloud (pure Kotlin, tested off-device). */
object ListenText {
    private val DEVANAGARI = Regex("[\\u0900-\\u097F]")
    private val LETTER = Regex("\\p{L}")

    /** True when most letters in [s] are Hindi (Devanagari). */
    fun isHindi(s: String): Boolean {
        val all = LETTER.findAll(s).count()
        if (all == 0) return false
        return DEVANAGARI.findAll(s).count() * 2 >= all
    }

    /**
     * Sentences of one page. Lines broken in the middle of a sentence are joined, words split
     * with a hyphen at a line end are put back together, bullets become separate sentences,
     * and very long sentences are cut at commas so the highlight stays readable.
     */
    fun sentences(page: String): List<String> {
        val text = page.replace("\r", "")
            .replace(Regex("(\\p{L})-\\n(\\p{Ll})"), "$1$2")
        // Decide for each line whether it continues the previous one (a sentence broken across lines)
        // or starts something new (a heading, a bullet, a new paragraph).
        val blocks = ArrayList<String>()
        val cur = StringBuilder()
        var prev = ""
        fun flush() { if (cur.isNotBlank()) blocks.add(cur.toString().trim()); cur.setLength(0); prev = "" }
        val bulletRe = Regex("^([•●▪◦‣*]|[-–]|\\d{1,3}[.)])\\s+.*")
        for (raw in text.split('\n')) {
            val line = raw.trim()
            if (line.isEmpty()) { flush(); continue }
            val bullet = line.matches(bulletRe)
            val continues = prev.isNotEmpty() && !bullet && !prev.contains(Regex("[.!?।॥:]$")) &&
                (line.first().isLowerCase() || prev.length >= 45)
            if (!continues) flush()
            cur.append(if (cur.isEmpty()) "" else " ").append(line.replace(Regex("^[•●▪◦‣*]\\s*"), ""))
            prev = line
        }
        flush()
        val out = ArrayList<String>()
        val end = Regex("(?<=[.!?।॥])\\s+(?=[\"'“(\\[]?[\\p{Lu}\\p{N}\\u0900-\\u097F])")
        for (b in blocks) {
            for (s in b.split(end)) {
                val t = s.replace(Regex("\\s+"), " ").trim()
                if (t.isEmpty() || !LETTER.containsMatchIn(t) && !t.any { it.isDigit() }) continue
                out.addAll(cutLong(t))
            }
        }
        return out
    }

    private fun cutLong(s: String, max: Int = 240): List<String> {
        if (s.length <= max) return listOf(s)
        val out = ArrayList<String>()
        var rest = s
        while (rest.length > max) {
            var cut = listOf(", ", "; ", ": ", " – ", " - ").map { rest.lastIndexOf(it, max) }.maxOrNull() ?: -1
            if (cut < max / 3) cut = rest.lastIndexOf(' ', max)
            if (cut <= 0) cut = max
            out.add(rest.substring(0, cut + 1).trim())
            rest = rest.substring(cut + 1).trim()
        }
        if (rest.isNotEmpty()) out.add(rest)
        return out
    }

    /** Rough listening time in minutes for [chars] characters at [speed]. */
    fun minutesFor(chars: Int, speed: Float): Int = kotlin.math.max(1, (chars / (14.5f * 60f * speed)).toInt())
}
