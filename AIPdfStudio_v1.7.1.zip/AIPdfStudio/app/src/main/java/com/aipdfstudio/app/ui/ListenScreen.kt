package com.aipdfstudio.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.FastForward
import androidx.compose.material.icons.outlined.FastRewind
import androidx.compose.material.icons.outlined.FormatListBulleted
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.SkipNext
import androidx.compose.material.icons.outlined.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.core.content.ContextCompat
import com.aipdfstudio.app.data.AudioExport
import com.aipdfstudio.app.data.ListenPlayer
import com.aipdfstudio.app.data.ListenText
import com.aipdfstudio.app.data.ListenVoice
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PdfOps
import com.aipdfstudio.app.data.SleepMode
import com.aipdfstudio.app.data.queryName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

private val SPEEDS = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
private fun speedLabel(v: Float) = (if (v % 1f == 0f) v.toInt().toString() else v.toString().trimEnd('0')) + "×"

/** Listen: a PDF read aloud, sentence by sentence, with the sentence being read highlighted. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListenScreen(uri: Uri?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val s by ListenPlayer.state.collectAsState()
    val dark = cs.background.luminance() < 0.4f
    val highlight = if (dark) Color(0xFF5B4A10) else Color(0xFFFFE08A)

    LaunchedEffect(uri) { if (uri != null) ListenPlayer.open(ctx, uri, queryName(ctx, uri)) }

    var showOptions by remember { mutableStateOf(false) }
    var showRange by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf<File?>(null) }
    var saveError by remember { mutableStateOf<String?>(null) }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ListenPlayer.play() }
    fun playPause() {
        if (!s.playing && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        else ListenPlayer.toggle()
    }
    fun saveAudio() {
        if (!s.ready || saving != null) return
        val st = s
        saving = "Getting the voice ready…"
        scope.launch {
            try {
                val f = withContext(Dispatchers.IO) {
                    AudioExport.save(ctx, st.name, st.pages, st.fromPage, st.lastPage, st.voice, st.speed, st.pitch) { msg -> saving = msg }
                }
                saved = f
            } catch (e: Throwable) {
                saveError = PdfOps.friendly(e)
            }
            saving = null
        }
    }

    Scaffold(containerColor = cs.background, contentWindowInsets = WindowInsets.statusBars) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).navigationBarsPadding()) {
            // ---------------------------------------------------- top bar
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
                Column(Modifier.weight(1f)) {
                    Text(s.name.ifBlank { "Listen" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val sub = s.chapterTitle ?: if (s.ready) "${s.pageCount} page${if (s.pageCount == 1) "" else "s"}" else ""
                    if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { showOptions = true }, enabled = s.ready) { Icon(Icons.Outlined.MoreVert, contentDescription = "Listening options") }
            }

            s.missingVoice?.let { v ->
                Surface(color = cs.tertiaryContainer, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
                    Row(Modifier.padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("$v voice isn't installed on this phone.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { try { ctx.startActivity(ListenPlayer.installVoicesIntent()) } catch (e: Exception) {}; ListenPlayer.clearMissingVoice() }) { Text("Install") }
                    }
                }
            }

            // ---------------------------------------------------- reading card
            Surface(
                color = if (dark) cs.surfaceContainer else Color.White,
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                when {
                    s.loading != null -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(14.dp))
                        Text(s.loading ?: "", color = cs.onSurfaceVariant)
                    }
                    s.error != null && !s.ready -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) { Text(s.error ?: "", color = cs.error) }
                    !s.ready -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) { Text("Choose a PDF to listen to", color = cs.onSurfaceVariant) }
                    else -> PageText(s.pages.getOrNull(s.page) ?: emptyList(), s.sentence, s.page, s.pageCount, highlight, dark) { i -> ListenPlayer.seek(s.page, i) }
                }
            }

            // ---------------------------------------------------- progress
            WavyProgress(s.progress, s.playing, Modifier.fillMaxWidth().padding(horizontal = 24.dp).height(24.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                Text(if (s.ready) "Page ${s.page + 1}" else "", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                if (s.ready) Text("~${ListenText.minutesFor(s.charsLeft, s.speed)} min left", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }

            // ---------------------------------------------------- controls
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { ListenPlayer.prevPage() }, enabled = s.ready, modifier = Modifier.size(52.dp)) { Icon(Icons.Outlined.SkipPrevious, "Previous page", Modifier.size(30.dp)) }
                IconButton(onClick = { ListenPlayer.prevSentence() }, enabled = s.ready, modifier = Modifier.size(52.dp)) { Icon(Icons.Outlined.FastRewind, "Back one sentence", Modifier.size(30.dp)) }
                Spacer(Modifier.width(8.dp))
                Surface(
                    onClick = { playPause() }, enabled = s.ready, color = cs.primary, shape = RoundedCornerShape(if (s.playing) 30.dp else 46.dp),
                    shadowElevation = 6.dp, modifier = Modifier.size(92.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(if (s.playing) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, if (s.playing) "Pause" else "Play", tint = cs.onPrimary, modifier = Modifier.size(44.dp))
                    }
                }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = { ListenPlayer.nextSentence() }, enabled = s.ready, modifier = Modifier.size(52.dp)) { Icon(Icons.Outlined.FastForward, "Forward one sentence", Modifier.size(30.dp)) }
                IconButton(onClick = { ListenPlayer.nextPage() }, enabled = s.ready, modifier = Modifier.size(52.dp)) { Icon(Icons.Outlined.SkipNext, "Next page", Modifier.size(30.dp)) }
            }

            // ---------------------------------------------------- quick chips
            Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 14.dp, start = 10.dp, end = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
                QuickChip(null, speedLabel(s.speed), selected = true) {
                    val i = SPEEDS.indexOf(s.speed)
                    ListenPlayer.setSpeed(SPEEDS[(if (i < 0) 1 else i + 1) % SPEEDS.size])
                }
                QuickChip(Icons.Outlined.Bedtime, if (s.sleep == SleepMode.OFF) "Sleep" else if (s.sleep == SleepMode.CHAPTER) "Chapter" else s.sleep.label) { showOptions = true }
                QuickChip(Icons.Outlined.RecordVoiceOver, s.voice.label) { showOptions = true }
                QuickChip(Icons.Outlined.Download, null) { saveAudio() }
            }
        }
    }

    if (showOptions) {
        ModalBottomSheet(onDismissRequest = { showOptions = false }) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp).padding(bottom = 22.dp)) {
                Text("Listening options", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                OptLabel("Voice")
                Segments(ListenVoice.entries.map { it.label }, s.voice.ordinal) { ListenPlayer.setVoice(ListenVoice.entries[it]) }
                OptLabel("Speed", speedLabel(s.speed))
                Segments(SPEEDS.map { speedLabel(it) }, SPEEDS.indexOf(s.speed)) { ListenPlayer.setSpeed(SPEEDS[it]) }
                OptLabel("Pitch")
                Slider(
                    value = s.pitch, onValueChange = { ListenPlayer.setPitch(it) }, valueRange = 0.6f..1.6f,
                    colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary)
                )
                OptLabel("Sleep timer")
                Segments(SleepMode.entries.map { it.label }, s.sleep.ordinal) { ListenPlayer.setSleep(SleepMode.entries[it]) }
                OptionCard(Icons.Outlined.Download, "Save as audio", "Make an audio file to play in any music app") { showOptions = false; saveAudio() }
                OptionCard(
                    Icons.Outlined.FormatListBulleted, "Read only selected pages",
                    if (s.fromPage == 0 && s.lastPage >= s.pageCount - 1) "e.g. 3–7" else "Pages ${s.fromPage + 1}–${s.lastPage + 1}"
                ) { showRange = true }
            }
        }
    }
    if (showRange) {
        var a by remember { mutableStateOf((s.fromPage + 1).toString()) }
        var b by remember { mutableStateOf((s.lastPage + 1).toString()) }
        AlertDialog(
            onDismissRequest = { showRange = false },
            title = { Text("Read only these pages") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(a, { a = it.filter(Char::isDigit).take(4) }, label = { Text("From") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    Text("  –  ")
                    OutlinedTextField(b, { b = it.filter(Char::isDigit).take(4) }, label = { Text("To") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }
            },
            confirmButton = { TextButton(onClick = { ListenPlayer.setRange(a.toIntOrNull() ?: 1, b.toIntOrNull() ?: s.pageCount); showRange = false }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { ListenPlayer.setRange(1, s.pageCount); showRange = false }) { Text("All pages") } }
        )
    }
    saving?.let { msg ->
        AlertDialog(onDismissRequest = {}, confirmButton = {}, text = {
            Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp); Spacer(Modifier.width(16.dp)); Text(msg) }
        })
    }
    saved?.let { f ->
        AlertDialog(
            onDismissRequest = { saved = null },
            title = { Text("Audio ready") },
            text = { Text("${f.name}\nOpen it in a music app or share it with friends.") },
            confirmButton = { Button(onClick = { saved = null; try { Outputs.share(ctx, listOf(f)) } catch (e: Exception) {} }) { Text("Share") } },
            dismissButton = { TextButton(onClick = { saved = null; try { Outputs.view(ctx, f) } catch (e: Exception) {} }) { Text("Play") } }
        )
    }
    saveError?.let { e ->
        AlertDialog(onDismissRequest = { saveError = null }, title = { Text("Couldn't save audio") }, text = { Text(e) }, confirmButton = { TextButton(onClick = { saveError = null }) { Text("OK") } })
    }
}

/** The current page as flowing text: the sentence being read is highlighted, later ones are softer. Tap a sentence to read from there. */
@Composable
private fun PageText(sentences: List<String>, current: Int, page: Int, pages: Int, highlight: Color, dark: Boolean, onTap: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scroll = rememberScrollState()
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val starts = remember(sentences) {
        var pos = 0
        sentences.map { s -> val st = pos; pos += s.length + 1; st }
    }
    val text = remember(sentences, current, highlight) {
        buildAnnotatedString {
            sentences.forEachIndexed { i, s ->
                when {
                    i == current -> withStyle(SpanStyle(background = highlight)) { append(s) }
                    i > current + 1 -> withStyle(SpanStyle(color = cs.onSurfaceVariant)) { append(s) }
                    else -> append(s)
                }
                append(if (i < sentences.size - 1) " " else "")
            }
        }
    }
    // Keep the sentence being read in view.
    LaunchedEffect(current, layout) {
        val l = layout ?: return@LaunchedEffect
        val off = starts.getOrNull(current) ?: return@LaunchedEffect
        val top = l.getLineTop(l.getLineForOffset(off.coerceAtMost(max(0, l.layoutInput.text.length - 1)))).toInt()
        scroll.animateScrollTo(max(0, top - 140))
    }
    Column(Modifier.fillMaxSize().padding(start = 18.dp, end = 18.dp, top = 16.dp)) {
        Text(
            "Page ${page + 1} of $pages", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold,
            color = cs.onPrimaryContainer,
            modifier = Modifier.background(cs.primaryContainer, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 4.dp)
        )
        Spacer(Modifier.height(10.dp))
        Box(Modifier.weight(1f).verticalScroll(scroll)) {
            if (sentences.isEmpty()) Text("This page has no text.", color = cs.onSurfaceVariant)
            else Text(
                text,
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp, lineHeight = 25.sp),
                color = if (dark) cs.onSurface else Color(0xFF1B1F1E),
                onTextLayout = { layout = it },
                modifier = Modifier.padding(bottom = 16.dp).pointerInput(sentences) {
                    detectTapGestures { p ->
                        val l = layout ?: return@detectTapGestures
                        val off = l.getOffsetForPosition(p)
                        val i = starts.indexOfLast { it <= off }
                        if (i >= 0) onTap(i)
                    }
                }
            )
        }
    }
}

/** Material 3 Expressive wavy progress: a wave for the part done, a flat line for the rest. */
@Composable
private fun WavyProgress(progress: Float, moving: Boolean, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val phase by rememberInfiniteTransition(label = "wave").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "phase"
    )
    Canvas(modifier) {
        val w = size.width; val cy = size.height / 2
        val done = (w * progress.coerceIn(0f, 1f))
        val amp = 3.2.dp.toPx(); val period = 14.dp.toPx()
        val ph = if (moving) phase * period else 0f
        val path = Path()
        var x = 0f
        path.moveTo(0f, cy)
        while (x <= done) {
            path.lineTo(x, cy + amp * sin(((x + ph) / period) * 2 * PI).toFloat())
            x += 2f
        }
        val sw = 4.dp.toPx()
        if (done > 2f) drawPath(path, cs.primary, style = Stroke(sw, cap = StrokeCap.Round))
        if (done + 8.dp.toPx() < w) drawLine(cs.primaryContainer, Offset(done + 8.dp.toPx(), cy), Offset(w, cy), sw, StrokeCap.Round)
        drawCircle(cs.primary, 2.dp.toPx(), Offset(w - 1.dp.toPx(), cy))
    }
}

@Composable
private fun QuickChip(icon: ImageVector?, label: String?, selected: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) cs.primaryContainer else Color.Transparent,
        border = if (selected) null else BorderStroke(1.5.dp, cs.outlineVariant)
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) Icon(icon, contentDescription = label ?: "Save as audio", modifier = Modifier.size(17.dp))
            if (icon != null && label != null) Spacer(Modifier.width(5.dp))
            if (label != null) Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = if (selected) cs.onPrimaryContainer else cs.onSurface, maxLines = 1)
        }
    }
}

@Composable
private fun OptLabel(t: String, value: String? = null) {
    Row(Modifier.padding(top = 14.dp, bottom = 6.dp)) {
        Text(t, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (value != null) Text(" $value", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    }
}

/** Connected segmented buttons, as in the design (a tick on the chosen one when it fits). */
@Composable
private fun Segments(labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().height(42.dp).border(1.5.dp, cs.outline.copy(alpha = 0.6f), RoundedCornerShape(21.dp)).padding(1.5.dp)) {
        labels.forEachIndexed { i, l ->
            val on = i == selected
            val shape = when (i) { 0 -> RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp); labels.size - 1 -> RoundedCornerShape(topEnd = 20.dp, bottomEnd = 20.dp); else -> RoundedCornerShape(0.dp) }
            Box(
                Modifier.weight(1f).fillMaxSize().background(if (on) cs.primaryContainer else Color.Transparent, shape).clickable { onPick(i) },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (on && labels.size <= 3) { Icon(Icons.Outlined.Check, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)) }
                    Text(
                        l, fontSize = if (l.length > 9) 11.sp else 12.5.sp, lineHeight = 13.sp, maxLines = 2,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        color = if (on) cs.onPrimaryContainer else cs.onSurface, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
            if (i < labels.size - 1) Box(Modifier.width(1.5.dp).fillMaxSize().background(cs.outline.copy(alpha = 0.6f)))
        }
    }
}

@Composable
private fun OptionCard(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onClick, color = cs.surfaceContainer, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = cs.onPrimaryContainer)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
    }
}
