package com.aipdfstudio.app.data

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** Which language the voice reads in. Auto picks Hindi or English for each sentence. */
enum class ListenVoice(val label: String) { ENGLISH("English"), HINDI("हिन्दी"), AUTO("Auto") }
enum class SleepMode(val label: String, val minutes: Int) { OFF("Off", 0), M15("15 min", 15), M30("30 min", 30), M60("60 min", 60), CHAPTER("End of chapter", -1) }

/** Everything the Listen screen shows. */
data class ListenState(
    val uri: Uri? = null,
    val name: String = "",
    val layouts: List<LPage> = emptyList(),
    val chapters: List<OutlineEntry> = emptyList(),
    val page: Int = 0,
    val sentence: Int = 0,
    val playing: Boolean = false,
    val loading: String? = null,
    val error: String? = null,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val voice: ListenVoice = ListenVoice.AUTO,
    val sleep: SleepMode = SleepMode.OFF,
    val sleepAt: Long = 0L,
    val fromPage: Int = 0,
    val toPage: Int = Int.MAX_VALUE,
    val missingVoice: String? = null,
    val ready: Boolean = false,
    val read: ListenReadPrefs = ListenReadPrefs(),
    // Voices
    val voices: List<VoiceItem> = emptyList(),
    val voiceEn: String? = null,
    val voiceHi: String? = null,
    val engine: String? = null,          // engine in use (package name)
    val googleInstalled: Boolean = false,
    val phoneEngine: String? = null,     // the phone's default engine
    val phoneEngineLabel: String = "Phone voice",
    val usePhoneEngine: Boolean = false,
    val sampling: String? = null,        // voice name playing a sample
    val note: String? = null
) {
    /** What the voice reads, page by page. */
    val pages: List<List<String>> get() = layouts.map { it.says }
    val pageCount get() = layouts.size
    val lastPage get() = minOf(toPage, pageCount - 1)
    val current: String? get() = layouts.getOrNull(page)?.sentences?.getOrNull(sentence)?.say
    private fun len(p: Int) = layouts[p].sentences.sumOf { it.say.length }
    /** 0..1 through the chosen pages, by characters. */
    val progress: Float get() {
        if (layouts.isEmpty()) return 0f
        val range = (fromPage..lastPage)
        val total = range.sumOf { len(it) }.coerceAtLeast(1)
        val done = range.filter { it < page }.sumOf { len(it) } + (layouts.getOrNull(page)?.sentences?.take(sentence)?.sumOf { it.say.length } ?: 0)
        return (done.toFloat() / total).coerceIn(0f, 1f)
    }
    val charsLeft: Int get() {
        if (layouts.isEmpty()) return 0
        return (page..lastPage).sumOf { p -> if (p == page) layouts[p].sentences.drop(sentence).sumOf { it.say.length } else len(p) }
    }
    /** Title of the chapter the current page is in (from the PDF's table of contents). */
    val chapterTitle: String? get() = chapters.lastOrNull { it.page in 0..page }?.title

    fun chosenVoice(lang: String): VoiceItem? {
        val want = if (lang == "hi") voiceHi else voiceEn
        return voices.firstOrNull { it.name == want && it.lang == lang } ?: ListenVoices.best(voices, lang)
    }
}

/**
 * Reads a PDF aloud with the phone's text-to-speech voice. The next sentences are queued while
 * one is being read, so the voice flows without a stop between sentences.
 * Lives as long as the app; [ListenService] keeps it running with the screen off.
 */
object ListenPlayer {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(ListenState())
    val state: StateFlow<ListenState> = _state

    private var app: Context? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingPlay = false
    private var pendingSample: String? = null
    private var loadJob: Job? = null
    private var focus: AudioFocusRequest? = null

    // Queue: sentences handed to the voice ahead of time. Ids are "gen:page:sentence".
    private var gen = 0
    private var lastQueued: Pair<Int, Int>? = null
    private var pending = 0
    private var chapterStop: Pair<Int, Int>? = null
    /** Languages whose online voice failed (no internet): use an offline one until the app restarts. */
    private val offlineOnly = HashSet<String>()

    private fun set(f: (ListenState) -> ListenState) { _state.value = f(_state.value) }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("listen", Context.MODE_PRIVATE)

    private fun ensureTts(ctx: Context) {
        if (tts != null) return
        app = ctx.applicationContext
        val p = prefs(ctx)
        set {
            it.copy(
                speed = p.getFloat("speed", 1f), pitch = p.getFloat("pitch", 1f),
                voice = ListenVoice.entries.getOrElse(p.getInt("voice", 2)) { ListenVoice.AUTO },
                read = ListenReadPrefs(p.getBoolean("skipNumbers", true), p.getBoolean("skipFigures", true), p.getBoolean("tableRows", true)),
                voiceEn = p.getString("voiceEn", null), voiceHi = p.getString("voiceHi", null),
                usePhoneEngine = p.getBoolean("phoneEngine", false)
            )
        }
        createTts(ctx.applicationContext)
    }

    private fun createTts(c: Context) {
        val google = ListenVoices.googleInstalled(c)
        val phone = ListenVoices.defaultEngine(c)
        // Google's voices sound the most natural, so they are used even if the phone's default engine is another one.
        val engine = if (google && !_state.value.usePhoneEngine) ListenVoices.GOOGLE else phone
        ttsReady = false
        set { it.copy(googleInstalled = google, phoneEngine = phone, phoneEngineLabel = ListenVoices.engineLabel(c, phone), engine = engine) }
        val init = TextToSpeech.OnInitListener { status ->
            main.post {
                ttsReady = status == TextToSpeech.SUCCESS
                if (!ttsReady) set { it.copy(error = "No text-to-speech voice on this phone. Install \"Speech Services by Google\" from Play Store.", playing = false) }
                else {
                    val t = tts ?: return@post
                    t.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    t.setOnUtteranceProgressListener(listener)
                    val used = try { t.defaultEngine } catch (e: Exception) { null }
                    val eng = engine ?: used ?: ""
                    set { it.copy(voices = ListenVoices.list(t, eng), engine = eng) }
                    pendingSample?.let { n -> pendingSample = null; sample(n) }
                    if (pendingPlay) { pendingPlay = false; play() }
                }
            }
        }
        tts = if (engine != null) TextToSpeech(c, init, engine) else TextToSpeech(c, init)
    }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(id: String?) { main.post { started(id) } }
        override fun onDone(id: String?) { main.post { finished(id, 0) } }
        @Deprecated("old API")
        override fun onError(id: String?) { main.post { finished(id, -1) } }
        override fun onError(id: String?, code: Int) { main.post { finished(id, code) } }
    }

    private fun parse(id: String?): Triple<Int, Int, Int>? {
        val p = id?.split(':') ?: return null
        if (p.size != 3) return null
        return Triple(p[0].toIntOrNull() ?: return null, p[1].toIntOrNull() ?: return null, p[2].toIntOrNull() ?: return null)
    }

    private fun started(id: String?) {
        if (id == "sample") return
        val (g, pg, se) = parse(id) ?: return
        if (g != gen || !_state.value.playing) return
        pending = (pending - 1).coerceAtLeast(0)
        set { it.copy(page = pg, sentence = se) }
        savePos()
        ListenService.refresh(app)
        fill()
    }

    private fun finished(id: String?, code: Int) {
        if (id == "sample") { set { it.copy(sampling = null) }; return }
        val (g, pg, se) = parse(id) ?: return
        if (g != gen || !_state.value.playing) return
        // An online voice without internet: switch to an offline voice and carry on from here.
        if (code == TextToSpeech.ERROR_NETWORK || code == TextToSpeech.ERROR_NETWORK_TIMEOUT || code == TextToSpeech.ERROR_NOT_INSTALLED_YET) {
            val text = _state.value.layouts.getOrNull(pg)?.sentences?.getOrNull(se)?.say.orEmpty()
            val lang = langOf(text)
            if (lang !in offlineOnly) {
                offlineOnly.add(lang)
                set { it.copy(note = "The online voice needs internet. Reading with an offline voice for now.") }
                startFrom(pg, se)
                return
            }
        }
        if (Pair(pg, se) == lastQueued && pending == 0) {
            // Nothing more was queued: the end of the chosen pages, or the end of the chapter.
            val stop = chapterStop
            if (stop != null) {
                set { it.copy(page = stop.first, sentence = stop.second) }
                pause(); set { it.copy(sleep = SleepMode.OFF) }
            } else {
                val s = _state.value
                set { it.copy(playing = false, page = s.fromPage, sentence = 0) }
                savePos(); abandonFocus(); ListenService.refresh(app)
            }
        }
    }

    /** Loads [uri] (skipped if it's already loaded) and goes to where the user stopped last time. */
    fun open(ctx: Context, uri: Uri, name: String) {
        ensureTts(ctx)
        if (_state.value.uri == uri && (_state.value.ready || _state.value.loading != null)) return
        stop()
        set { it.copy(uri = uri, name = name, layouts = emptyList(), page = 0, sentence = 0, loading = "Getting your notes ready…", error = null, ready = false, fromPage = 0, toPage = Int.MAX_VALUE) }
        load(ctx, uri, keepPage = null)
    }

    private fun load(ctx: Context, uri: Uri, keepPage: Int?) {
        loadJob?.cancel()
        val readPrefs = _state.value.read
        loadJob = scope.launch {
            try {
                val (pages, chapters) = withContext(Dispatchers.IO) {
                    OcrOps.listenPages(ctx, uri, readPrefs) { msg -> main.post { set { s -> s.copy(loading = msg) } } } to Outline.read(ctx, uri)
                }
                if (pages.all { it.sentences.isEmpty() }) throw UserError("No text found in this PDF to read aloud.")
                var pg: Int
                var se: Int
                if (keepPage != null) { pg = keepPage.coerceIn(0, pages.size - 1); se = 0 }
                else {
                    val saved = prefs(ctx).getString("pos:$uri", null)?.split(':')
                    pg = saved?.getOrNull(0)?.toIntOrNull()?.coerceIn(0, pages.size - 1) ?: 0
                    se = saved?.getOrNull(1)?.toIntOrNull() ?: 0
                }
                if (se >= pages[pg].sentences.size) se = 0
                while (pg < pages.size - 1 && pages[pg].sentences.isEmpty()) { pg++; se = 0 }
                set { it.copy(layouts = pages, chapters = chapters.filter { c -> c.page >= 0 }, page = pg, sentence = se, loading = null, ready = true) }
            } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                set { it.copy(loading = null, error = PdfOps.friendly(e)) }
            }
        }
    }

    private fun savePos() {
        val s = _state.value
        val c = app ?: return
        if (s.uri != null) prefs(c).edit().putString("pos:${s.uri}", "${s.page}:${s.sentence}").apply()
    }

    private fun langOf(text: String): String = when (_state.value.voice) {
        ListenVoice.ENGLISH -> "en"
        ListenVoice.HINDI -> "hi"
        ListenVoice.AUTO -> if (ListenText.isHindi(text)) "hi" else "en"
    }

    /** Sets the voice for a sentence in [lang]; falls back to the language if no voice is available. */
    private fun applyVoice(t: TextToSpeech, lang: String) {
        val s = _state.value
        var v = s.chosenVoice(lang)
        if (v != null && v.online && lang in offlineOnly) v = s.voices.firstOrNull { it.lang == lang && !it.online }
        val voice = ListenVoices.find(t, v?.name)
        if (voice != null && t.setVoice(voice) == TextToSpeech.SUCCESS) return
        val loc = if (lang == "hi") Locale("hi", "IN") else Locale("en", "IN")
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            val fallback = if (lang == "hi") Locale("en", "IN") else Locale.US
            if (t.setLanguage(fallback) < 0) t.setLanguage(Locale.US)
            if (s.missingVoice == null) set { it.copy(missingVoice = if (lang == "hi") "Hindi" else "English (India)") }
        }
    }

    /** Next sentence after (p, s) within the chosen pages, or null at the end (or at a chapter stop). */
    private fun nextPos(p: Int, s: Int): Pair<Int, Int>? {
        val st = _state.value
        var pg = p
        var se = s + 1
        while (pg <= st.lastPage && se >= (st.layouts.getOrNull(pg)?.sentences?.size ?: 0)) {
            pg++; se = 0
            // "End of chapter": stop where the next chapter (or, without contents, the next page) starts.
            if (st.sleep == SleepMode.CHAPTER && pg <= st.lastPage && (st.chapters.isEmpty() || st.chapters.any { it.page == pg })) {
                chapterStop = pg to 0
                return null
            }
        }
        return if (pg > st.lastPage) null else pg to se
    }

    private fun blockEnds(p: Int, s: Int): Boolean {
        val lp = _state.value.layouts.getOrNull(p) ?: return false
        return lp.blocks.any { it.count > 0 && it.first + it.count - 1 == s }
    }

    private fun enqueue(p: Int, s: Int, flush: Boolean) {
        val t = tts ?: return
        val st = _state.value
        val text = st.layouts.getOrNull(p)?.sentences?.getOrNull(s)?.say ?: return
        applyVoice(t, langOf(text))
        t.setSpeechRate(st.speed)
        t.setPitch(st.pitch)
        t.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, Bundle(), "$gen:$p:$s")
        // A short breath after headings, points and paragraphs.
        if (blockEnds(p, s)) t.playSilentUtterance(260, TextToSpeech.QUEUE_ADD, "$gen:pause")
        lastQueued = p to s
        pending++
    }

    /** Keeps two sentences waiting after the one being read. */
    private fun fill() {
        while (pending < 2) {
            val last = lastQueued ?: return
            val n = nextPos(last.first, last.second) ?: return
            enqueue(n.first, n.second, flush = false)
        }
    }

    private fun startFrom(p: Int, s: Int) {
        gen++
        pending = 0
        chapterStop = null
        lastQueued = null
        if (_state.value.layouts.getOrNull(p)?.sentences?.getOrNull(s) == null) {
            val n = nextPos(p, s - 1)
            if (n == null) { pause(); return }
            enqueue(n.first, n.second, flush = true)
        } else enqueue(p, s, flush = true)
        fill()
    }

    fun play() {
        val c = app ?: return
        val s = _state.value
        if (!s.ready) return
        if (!ttsReady) { pendingPlay = true; return }
        if (!requestFocus(c)) return
        var pg = s.page.coerceIn(s.fromPage, s.lastPage)
        var se = if (pg != s.page) 0 else s.sentence
        while (pg < s.lastPage && s.layouts[pg].sentences.isEmpty()) { pg++; se = 0 }
        set { it.copy(playing = true, page = pg, sentence = se, error = null, sampling = null) }
        ListenService.start(c)
        startFrom(pg, se)
    }

    fun pause() {
        gen++
        tts?.stop()
        set { it.copy(playing = false) }
        savePos()
        abandonFocus()
        ListenService.refresh(app)
    }

    fun toggle() = if (_state.value.playing) pause() else play()

    /** Jump to a sentence (and keep playing if it was). */
    fun seek(page: Int, sentence: Int) {
        val s = _state.value
        if (s.layouts.isEmpty()) return
        val pg = page.coerceIn(0, s.layouts.size - 1)
        val se = sentence.coerceIn(0, maxOf(0, s.layouts[pg].sentences.size - 1))
        set { it.copy(page = pg, sentence = se) }
        savePos()
        if (s.playing) startFrom(pg, se)
        ListenService.refresh(app)
    }

    fun nextSentence() {
        val s = _state.value
        if (s.sentence + 1 < (s.layouts.getOrNull(s.page)?.sentences?.size ?: 0)) seek(s.page, s.sentence + 1) else nextPage()
    }

    fun prevSentence() {
        val s = _state.value
        if (s.sentence > 0) seek(s.page, s.sentence - 1)
        else if (s.page > 0) seek(s.page - 1, (s.layouts[s.page - 1].sentences.size - 1).coerceAtLeast(0))
    }

    fun nextPage() { val s = _state.value; if (s.page + 1 < s.pageCount) seek(s.page + 1, 0) }
    fun prevPage() { val s = _state.value; if (s.sentence > 0) seek(s.page, 0) else if (s.page > 0) seek(s.page - 1, 0) }

    private fun restartIfPlaying() { val s = _state.value; if (s.playing) startFrom(s.page, s.sentence) }

    fun setSpeed(v: Float) { set { it.copy(speed = v) }; app?.let { prefs(it).edit().putFloat("speed", v).apply() }; restartIfPlaying() }
    fun setPitch(v: Float) { set { it.copy(pitch = v) }; app?.let { prefs(it).edit().putFloat("pitch", v).apply() } }
    fun setVoice(v: ListenVoice) {
        set { it.copy(voice = v, missingVoice = null) }
        app?.let { prefs(it).edit().putInt("voice", v.ordinal).apply() }
        restartIfPlaying()
    }

    /** Picks a voice from "Choose a voice". */
    fun chooseVoice(item: VoiceItem) {
        val c = app ?: return
        if (item.lang == "hi") set { it.copy(voiceHi = item.name) } else set { it.copy(voiceEn = item.name) }
        prefs(c).edit().putString(if (item.lang == "hi") "voiceHi" else "voiceEn", item.name).apply()
        offlineOnly.remove(item.lang)
        set { it.copy(missingVoice = null, note = null) }
        restartIfPlaying()
    }

    /** Plays a short sample in [name] (stops reading first). */
    fun sample(name: String) {
        val t = tts
        if (t == null || !ttsReady) { pendingSample = name; return }
        if (_state.value.playing) pause()
        if (_state.value.sampling == name) { t.stop(); set { it.copy(sampling = null) }; return }
        val item = _state.value.voices.firstOrNull { it.name == name } ?: return
        ListenVoices.find(t, name)?.let { t.setVoice(it) }
        t.setSpeechRate(_state.value.speed)
        t.setPitch(_state.value.pitch)
        set { it.copy(sampling = name) }
        t.speak(if (item.lang == "hi") ListenVoices.SAMPLE_HI else ListenVoices.SAMPLE_EN, TextToSpeech.QUEUE_FLUSH, Bundle(), "sample")
    }

    fun stopSample() { if (_state.value.sampling != null) { tts?.stop(); set { it.copy(sampling = null) } } }

    /** Switch between Google's natural voices and the phone's own engine. */
    fun usePhoneEngine(on: Boolean) {
        val c = app ?: return
        if (_state.value.usePhoneEngine == on) return
        val wasPlaying = _state.value.playing
        if (wasPlaying) pause()
        prefs(c).edit().putBoolean("phoneEngine", on).apply()
        set { it.copy(usePhoneEngine = on, voices = emptyList()) }
        try { tts?.shutdown() } catch (ignored: Exception) {}
        tts = null
        createTts(c)
        if (wasPlaying) pendingPlay = true
    }

    /** After the user installed voices or Google's speech app: look again. */
    fun refreshVoices() {
        val c = app ?: return
        val google = ListenVoices.googleInstalled(c)
        if (google != _state.value.googleInstalled || tts == null) {
            try { tts?.shutdown() } catch (ignored: Exception) {}
            tts = null
            createTts(c)
        } else {
            val t = tts ?: return
            set { it.copy(voices = ListenVoices.list(t, it.engine ?: "")) }
        }
    }

    /** Changes a "What to read" switch and gets the pages again (staying on this page). */
    fun setReadPrefs(ctx: Context, p: ListenReadPrefs) {
        val s = _state.value
        if (p == s.read) return
        prefs(ctx).edit().putBoolean("skipNumbers", p.skipNumbers).putBoolean("skipFigures", p.skipFigures).putBoolean("tableRows", p.tableRows).apply()
        set { it.copy(read = p) }
        val uri = s.uri ?: return
        if (s.playing) pause()
        set { it.copy(loading = "Updating…", ready = false) }
        load(ctx, uri, keepPage = s.page)
    }

    private val sleepRunnable = Runnable { pause(); set { it.copy(sleep = SleepMode.OFF, sleepAt = 0L) } }
    fun setSleep(m: SleepMode) {
        main.removeCallbacks(sleepRunnable)
        val at = if (m.minutes > 0) System.currentTimeMillis() + m.minutes * 60_000L else 0L
        if (m.minutes > 0) main.postDelayed(sleepRunnable, m.minutes * 60_000L)
        set { it.copy(sleep = m, sleepAt = at) }
        restartIfPlaying()
    }

    /** Read only pages [from]..[to] (1-based, as the user types them). */
    fun setRange(from: Int, to: Int) {
        val s = _state.value
        val f = (from - 1).coerceIn(0, maxOf(0, s.pageCount - 1))
        val t = (to - 1).coerceIn(f, maxOf(0, s.pageCount - 1))
        set { it.copy(fromPage = f, toPage = t) }
        if (s.page !in f..t) seek(f, 0) else restartIfPlaying()
    }

    /** Stops reading and closes the notification. */
    fun stop() {
        gen++
        tts?.stop()
        if (_state.value.playing) savePos()
        set { it.copy(playing = false, sampling = null) }
        abandonFocus()
        main.removeCallbacks(sleepRunnable)
        ListenService.stop(app)
    }

    fun clearMissingVoice() = set { it.copy(missingVoice = null) }
    fun clearNote() = set { it.copy(note = null) }

    fun installVoicesIntent(): Intent = ListenVoices.installVoicesIntent(_state.value.engine?.takeIf { it.isNotEmpty() })

    // ------------------------------------------------------------ audio focus (pause for calls and other audio)

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) main.post { if (_state.value.playing) pause() }
    }

    private fun requestFocus(c: Context): Boolean {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setOnAudioFocusChangeListener(focusListener)
            .build()
        focus = req
        return am.requestAudioFocus(req) != AudioManager.AUDIOFOCUS_REQUEST_FAILED
    }

    private fun abandonFocus() {
        val c = app ?: return
        val f = focus ?: return
        (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(f)
        focus = null
    }
}

/** Hooks so the data layer can drive the notification without knowing the service class. */
object ListenService {
    var onStart: ((Context) -> Unit)? = null
    var onRefresh: ((Context) -> Unit)? = null
    var onStop: ((Context) -> Unit)? = null
    fun start(c: Context?) { c?.let { onStart?.invoke(it) } }
    fun refresh(c: Context?) { c?.let { onRefresh?.invoke(it) } }
    fun stop(c: Context?) { c?.let { onStop?.invoke(it) } }
}
