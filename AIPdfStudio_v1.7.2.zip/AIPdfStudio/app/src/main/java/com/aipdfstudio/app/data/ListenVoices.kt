package com.aipdfstudio.app.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/** One voice in "Choose a voice". [name] is the engine's own id (like "en-in-x-ena-local"). */
data class VoiceItem(
    val name: String,
    val label: String,
    val lang: String,          // "en" or "hi"
    val country: String,       // "India", "US", …
    val online: Boolean,       // needs internet (usually the most natural)
    val natural: Boolean,
    val engine: String
)

/** Finds the phone's voices and picks the most natural one. */
object ListenVoices {
    const val GOOGLE = "com.google.android.tts"

    fun googleInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(GOOGLE, 0); true
    } catch (e: Exception) { false }

    /** The phone's default speech engine (package name), or null if none. */
    fun defaultEngine(ctx: Context): String? = try {
        android.provider.Settings.Secure.getString(ctx.contentResolver, "tts_default_synth")
    } catch (e: Exception) { null }

    fun engineLabel(ctx: Context, pkg: String?): String {
        if (pkg == null) return "Phone voice"
        if (pkg == GOOGLE) return "Google"
        return try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { "Phone voice" }
    }

    private fun countryName(l: Locale): String = when (l.country.uppercase()) {
        "IN" -> "India"; "US" -> "US"; "GB" -> "UK"; "AU" -> "Australia"; "NG" -> "Nigeria"; "" -> ""
        else -> l.getDisplayCountry(Locale.ENGLISH)
    }

    /** English and Hindi voices that are ready to use, best first, named "Voice 1", "Voice 2"… per language. */
    fun list(tts: TextToSpeech?, engine: String): List<VoiceItem> {
        val all: Set<Voice> = try { tts?.voices ?: emptySet() } catch (e: Exception) { emptySet() }
        val out = ArrayList<VoiceItem>()
        for (lang in listOf("en", "hi")) {
            val vs = all.filter { v ->
                val l = v.locale
                l.language == lang &&
                    !(v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) ?: false) &&
                    !v.name.contains("legacy", ignoreCase = true)
            }.sortedWith(compareBy<Voice>(
                { if (it.locale.country.equals("IN", true)) 0 else if (it.locale.country.equals("US", true)) 1 else if (it.locale.country.equals("GB", true)) 2 else 3 },
                { if (it.isNetworkConnectionRequired) 1 else 0 },
                { -it.quality },
                { it.name }
            ))
            vs.forEachIndexed { i, v ->
                out.add(VoiceItem(
                    name = v.name, label = "Voice ${i + 1}", lang = lang, country = countryName(v.locale),
                    online = v.isNetworkConnectionRequired,
                    natural = engine == GOOGLE || v.quality >= Voice.QUALITY_HIGH,
                    engine = engine
                ))
            }
        }
        return out
    }

    /** The voice to use for [lang] when the user hasn't picked one: an offline Indian voice if possible. */
    fun best(list: List<VoiceItem>, lang: String): VoiceItem? =
        list.filter { it.lang == lang }.let { l -> l.firstOrNull { !it.online && it.natural } ?: l.firstOrNull { !it.online } ?: l.firstOrNull() }

    fun find(tts: TextToSpeech?, name: String?): Voice? {
        if (name == null || tts == null) return null
        return try { tts.voices?.firstOrNull { it.name == name } } catch (e: Exception) { null }
    }

    /** Opens Google's speech app in the Play Store (to install the natural voices). */
    fun getGoogleIntent(): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$GOOGLE")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun getGoogleWebIntent(): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$GOOGLE")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Opens the engine's "download voices" screen. */
    fun installVoicesIntent(engine: String?): Intent =
        Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).apply { if (engine != null) setPackage(engine) }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    const val SAMPLE_EN = "Plants make their own food using sunlight, water and carbon dioxide."
    const val SAMPLE_HI = "पौधे सूर्य के प्रकाश, पानी और कार्बन डाइऑक्साइड से अपना भोजन बनाते हैं।"
}
