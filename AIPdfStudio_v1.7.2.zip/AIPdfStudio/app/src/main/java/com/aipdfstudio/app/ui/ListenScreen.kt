package com.aipdfstudio.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.FastForward
import androidx.compose.material.icons.outlined.FastRewind
import androidx.compose.material.icons.outlined.FormatListBulleted
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.SkipNext
import androidx.compose.material.icons.outlined.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.core.content.ContextCompat
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.material3.Switch
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.TableChart
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.FormatListNumbered
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import com.aipdfstudio.app.data.LKind
import com.aipdfstudio.app.data.LPage
import com.aipdfstudio.app.data.ListenState
import com.aipdfstudio.app.data.ListenVoices
import com.aipdfstudio.app.data.VoiceItem
import com.aipdfstudio.app.data.AudioExport
import com.aipdfstudio.app.data.ListenPlayer
import com.aipdfstudio.app.data.ListenText
import com.aipdfstudio.app.data.ListenVoice
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PdfOps
import com.aipdfstudio.app.data.SleepMode
import com.aipdfstudio.app.data.queryName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

private val SPEEDS = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
private fun speedLabel(v: Float) = (if (v % 1f == 0f) v.toInt().toString() else v.toString().trimEnd('0')) + "×"

/** Listen: a PDF read aloud, sentence by sentence, with the sentence being read highlighted. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListenScreen(uri: Uri?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val s by ListenPlayer.state.collectAsState()
    val dark = cs.background.luminance() < 0.4f
    val highlight = if (dark) Color(0xFF5B4A10) else Color(0xFFFFE08A)

    LaunchedEffect(uri) { if (uri != null) ListenPlayer.open(ctx, uri, queryName(ctx, uri)) }

    var showOptions by remember { mutableStateOf(false) }
    var showVoices by remember { mutableStateOf(false) }
    var showRange by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf<File?>(null) }
    var saveError by remember { mutableStateOf<String?>(null) }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ListenPlayer.play() }
    fun playPause() {
        if (!s.playing && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        else ListenPlayer.toggle()
    }
    fun saveAudio() {
        if (!s.ready || saving != null) return
        val st = s
        saving = "Getting the voice ready…"
        scope.launch {
            try {
                val f = withContext(Dispatchers.IO) {
                    AudioExport.save(ctx, st.name, st.pages, st.fromPage, st.lastPage, st.voice, st.speed, st.pitch, st.engine, st.chosenVoice("en")?.name, st.chosenVoice("hi")?.name) { msg -> saving = msg }
                }
                saved = f
            } catch (e: Throwable) {
                saveError = PdfOps.friendly(e)
            }
            saving = null
        }
    }

    Scaffold(containerColor = cs.background, contentWindowInsets = WindowInsets.statusBars) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).navigationBarsPadding()) {
            // ---------------------------------------------------- top bar
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
                Column(Modifier.weight(1f)) {
                    Text(s.name.ifBlank { "Listen" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val sub = s.chapterTitle ?: if (s.ready) "${s.pageCount} page${if (s.pageCount == 1) "" else "s"}" else ""
                    if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { showOptions = true }, enabled = s.ready) { Icon(Icons.Outlined.MoreVert, contentDescription = "Listening options") }
            }

            s.missingVoice?.let { v ->
                Surface(color = cs.tertiaryContainer, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
                    Row(Modifier.padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("$v voice isn't installed on this phone.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { try { ctx.startActivity(ListenPlayer.installVoicesIntent()) } catch (e: Exception) {}; ListenPlayer.clearMissingVoice() }) { Text("Install") }
                    }
                }
            }

            s.note?.let { n ->
                Surface(color = cs.secondaryContainer, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
                    Row(Modifier.padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(n, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { ListenPlayer.clearNote() }) { Text("OK") }
                    }
                }
            }

            // ---------------------------------------------------- reading card
            Surface(
                color = if (dark) cs.surfaceContainer else Color.White,
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                when {
                    s.loading != null -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(14.dp))
                        Text(s.loading ?: "", color = cs.onSurfaceVariant)
                    }
                    s.error != null && !s.ready -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) { Text(s.error ?: "", color = cs.error) }
                    !s.ready -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) { Text("Choose a PDF to listen to", color = cs.onSurfaceVariant) }
                    else -> PageView(s.layouts.getOrNull(s.page), s.sentence, s.page, s.pageCount, highlight, dark) { i -> ListenPlayer.seek(s.page, i) }
                }
            }

            // ---------------------------------------------------- progress
            WavyProgress(s.progress, s.playing, Modifier.fillMaxWidth().padding(horizontal = 24.dp).height(24.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                Text(if (s.ready) "Page ${s.page + 1}" else "", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                if (s.ready) Text("~${ListenText.minutesFor(s.charsLeft, s.speed)} min left", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }

            // ---------------------------------------------------- controls
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { ListenPlayer.prevPage() }, enabled = s.ready, modifier = Modifier.size(52.dp)) { Icon(Icons.Outlined.SkipPrevious, "Previous page", Modifier.size(30.dp)) }
                IconButton(onClick = { ListenPlayer.prevSentence() }, enabled = s.ready, modifier = Modifier.size(52.dp)) { Icon(Icons.Outlined.FastRewind, "Back one sentence", Modifier.size(30.dp)) }
                Spacer(Modifier.width(8.dp))
                Surface(
                    onClick = { playPause() }, enabled = s.ready, color = cs.primary, shape = RoundedCornerShape(if (s.playing) 30.dp else 46.dp),
                    shadowElevation = 6.dp, modifier = Modifier.size(92.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(if (s.playing) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, if (s.playing) "Pause" else "Play", tint = cs.onPrimary, modifier = Modifier.size(44.dp))
                    }
                }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = { ListenPlayer.nextSentence() }, enabled = s.ready, modifier = Modifier.size(52.dp)) { Icon(Icons.Outlined.FastForward, "Forward one sentence", Modifier.size(30.dp)) }
                IconButton(onClick = { ListenPlayer.nextPage() }, enabled = s.ready, modifier = Modifier.size(52.dp)) { Icon(Icons.Outlined.SkipNext, "Next page", Modifier.size(30.dp)) }
            }

            // ---------------------------------------------------- quick chips
            Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 14.dp, start = 10.dp, end = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
                QuickChip(null, speedLabel(s.speed), selected = true) {
                    val i = SPEEDS.indexOf(s.speed)
                    ListenPlayer.setSpeed(SPEEDS[(if (i < 0) 1 else i + 1) % SPEEDS.size])
                }
                QuickChip(Icons.Outlined.Bedtime, if (s.sleep == SleepMode.OFF) "Sleep" else if (s.sleep == SleepMode.CHAPTER) "Chapter" else s.sleep.label) { showOptions = true }
                QuickChip(Icons.Outlined.Person, voiceChipLabel(s)) { showVoices = true }
                QuickChip(Icons.Outlined.Download, null) { saveAudio() }
            }
        }
    }

    if (showOptions) {
        ModalBottomSheet(onDismissRequest = { showOptions = false }) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 18.dp).padding(bottom = 22.dp)) {
                Text("Listening options", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                OptLabel("Voice")
                CurrentVoiceCard(s) { showVoices = true }
                OptLabel("Language")
                Segments(ListenVoice.entries.map { it.label }, s.voice.ordinal) { ListenPlayer.setVoice(ListenVoice.entries[it]) }
                OptLabel("Speed", speedLabel(s.speed))
                Segments(SPEEDS.map { speedLabel(it) }, SPEEDS.indexOf(s.speed)) { ListenPlayer.setSpeed(SPEEDS[it]) }
                OptLabel("What to read")
                SwitchCard(Icons.Outlined.FormatListNumbered, "Skip page numbers", "“3 / 8” at the bottom is not read", s.read.skipNumbers) {
                    ListenPlayer.setReadPrefs(ctx, s.read.copy(skipNumbers = it))
                }
                SwitchCard(Icons.Outlined.Image, "Skip words inside diagrams", "Labels like “Xylem, Phloem” are skipped", s.read.skipFigures) {
                    ListenPlayer.setReadPrefs(ctx, s.read.copy(skipFigures = it))
                }
                SwitchCard(Icons.Outlined.TableChart, "Read tables row by row", "“Parenchyma. Cell walls: thin…”", s.read.tableRows) {
                    ListenPlayer.setReadPrefs(ctx, s.read.copy(tableRows = it))
                }
                OptLabel("Sleep timer")
                Segments(SleepMode.entries.map { it.label }, s.sleep.ordinal) { ListenPlayer.setSleep(SleepMode.entries[it]) }
                OptLabel("Pitch")
                Slider(
                    value = s.pitch, onValueChange = { ListenPlayer.setPitch(it) }, valueRange = 0.6f..1.6f,
                    colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary)
                )
                OptionCard(Icons.Outlined.Download, "Save as audio", "Make an audio file to play in any music app") { showOptions = false; saveAudio() }
                OptionCard(
                    Icons.Outlined.FormatListBulleted, "Read only selected pages",
                    if (s.fromPage == 0 && s.lastPage >= s.pageCount - 1) "e.g. 3–7" else "Pages ${s.fromPage + 1}–${s.lastPage + 1}"
                ) { showRange = true }
            }
        }
    }
    if (showVoices) VoicePicker(s, onClose = { ListenPlayer.stopSample(); showVoices = false })
    if (showRange) {
        var a by remember { mutableStateOf((s.fromPage + 1).toString()) }
        var b by remember { mutableStateOf((s.lastPage + 1).toString()) }
        AlertDialog(
            onDismissRequest = { showRange = false },
            title = { Text("Read only these pages") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(a, { a = it.filter(Char::isDigit).take(4) }, label = { Text("From") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    Text("  –  ")
                    OutlinedTextField(b, { b = it.filter(Char::isDigit).take(4) }, label = { Text("To") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }
            },
            confirmButton = { TextButton(onClick = { ListenPlayer.setRange(a.toIntOrNull() ?: 1, b.toIntOrNull() ?: s.pageCount); showRange = false }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { ListenPlayer.setRange(1, s.pageCount); showRange = false }) { Text("All pages") } }
        )
    }
    saving?.let { msg ->
        AlertDialog(onDismissRequest = {}, confirmButton = {}, text = {
            Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp); Spacer(Modifier.width(16.dp)); Text(msg) }
        })
    }
    saved?.let { f ->
        AlertDialog(
            onDismissRequest = { saved = null },
            title = { Text("Audio ready") },
            text = { Text("${f.name}\nOpen it in a music app or share it with friends.") },
            confirmButton = { Button(onClick = { saved = null; try { Outputs.share(ctx, listOf(f)) } catch (e: Exception) {} }) { Text("Share") } },
            dismissButton = { TextButton(onClick = { saved = null; try { Outputs.view(ctx, f) } catch (e: Exception) {} }) { Text("Play") } }
        )
    }
    saveError?.let { e ->
        AlertDialog(onDismissRequest = { saveError = null }, title = { Text("Couldn't save audio") }, text = { Text(e) }, confirmButton = { TextButton(onClick = { saveError = null }) { Text("OK") } })
    }
}

/** The current page as the student sees it: headings, paragraphs, points, figures and table rows. The sentence being read is highlighted; tap a sentence to read from there. */
@Composable
private fun PageView(lp: LPage?, current: Int, page: Int, pages: Int, highlight: Color, dark: Boolean, onTap: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val list = rememberLazyListState()
    val blocks = lp?.blocks ?: emptyList()
    val curBlock = blocks.indexOfFirst { current >= it.first && current < it.first + it.count }
    LaunchedEffect(page, curBlock) {
        if (curBlock >= 0) {
            val visible = list.layoutInfo.visibleItemsInfo
            val shown = visible.firstOrNull { it.index == curBlock + 1 }
            val bottom = list.layoutInfo.viewportEndOffset
            if (shown == null || shown.offset < 0 || shown.offset + shown.size > bottom - 40) list.animateScrollToItem(curBlock + 1, -120)
        }
    }
    LaunchedEffect(page) { if (curBlock < 0) list.scrollToItem(0) }
    val ink = if (dark) cs.onSurface else Color(0xFF1B1F1E)
    LazyColumn(state = list, modifier = Modifier.fillMaxSize().padding(start = 18.dp, end = 18.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(
                "Page ${page + 1} of $pages", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold,
                color = cs.onPrimaryContainer,
                modifier = Modifier.background(cs.primaryContainer, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        if (lp == null || lp.sentences.isEmpty()) item { Text("This page has no text to read.", color = cs.onSurfaceVariant) }
        else items(blocks.size) { bi ->
            val b = blocks[bi]
            val sents = lp.sentences.subList(b.first, b.first + b.count)
            val isCur = bi == curBlock
            when (b.kind) {
                LKind.FIGURE -> Row(
                    Modifier.fillMaxWidth()
                        .background(if (isCur) highlight else cs.surfaceContainerHigh.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        .border(1.5.dp, cs.outlineVariant, RoundedCornerShape(14.dp))
                        .clickable(enabled = b.count > 0) { onTap(b.first) }
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.Image, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        buildAnnotatedString {
                            append(b.label ?: "Diagram")
                            withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(" · labels skipped") }
                        },
                        style = MaterialTheme.typography.bodySmall, color = if (isCur) ink else cs.onSurfaceVariant
                    )
                }
                LKind.TABLE -> Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                    Icon(Icons.Outlined.TableChart, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Table · read row by row", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                }
                LKind.ROW -> {
                    val sh = sents.firstOrNull()?.show.orEmpty()
                    val title = sh.substringBefore('\n'); val rest = sh.substringAfter('\n', "")
                    Column(
                        Modifier.fillMaxWidth()
                            .background(if (isCur) highlight.copy(alpha = if (dark) 0.6f else 0.45f) else Color.Transparent, RoundedCornerShape(14.dp))
                            .border(1.5.dp, if (isCur) highlight else cs.outlineVariant, RoundedCornerShape(14.dp))
                            .clickable { onTap(b.first) }
                            .padding(horizontal = 12.dp, vertical = 9.dp)
                    ) {
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ink)
                        if (rest.isNotBlank()) Text(rest, fontSize = 14.sp, lineHeight = 20.sp, color = if (!isCur && b.first > current + 1) cs.onSurfaceVariant else ink)
                    }
                }
                else -> SentenceText(
                    sents.map { it.show }, b.first, current, highlight, ink, cs.onSurfaceVariant,
                    heading = b.kind == LKind.HEADING, point = b.kind == LKind.POINT, onTap = onTap
                )
            }
        }
    }
}

@Composable
private fun SentenceText(texts: List<String>, first: Int, current: Int, highlight: Color, ink: Color, soft: Color, heading: Boolean, point: Boolean, onTap: (Int) -> Unit) {
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val starts = remember(texts) {
        var pos = 0
        texts.map { s -> val st = pos; pos += s.length + 1; st }
    }
    val text = remember(texts, current, highlight, first) {
        buildAnnotatedString {
            texts.forEachIndexed { i, s ->
                val idx = first + i
                when {
                    idx == current -> withStyle(SpanStyle(background = highlight)) { append(s) }
                    idx > current + 1 -> withStyle(SpanStyle(color = soft)) { append(s) }
                    else -> append(s)
                }
                if (i < texts.size - 1) append(" ")
            }
        }
    }
    Text(
        text,
        style = if (heading) MaterialTheme.typography.titleMedium.copy(fontSize = 17.5.sp, lineHeight = 24.sp, fontWeight = FontWeight.ExtraBold)
        else MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp, lineHeight = 25.sp),
        color = ink,
        onTextLayout = { layout = it },
        modifier = Modifier.fillMaxWidth().padding(start = if (point) 6.dp else 0.dp, top = if (heading) 6.dp else 0.dp).pointerInput(texts) {
            detectTapGestures { p ->
                val l = layout ?: return@detectTapGestures
                val off = l.getOffsetForPosition(p)
                val i = starts.indexOfLast { it <= off }
                if (i >= 0) onTap(first + i)
            }
        }
    )
}

/** Material 3 Expressive wavy progress: a wave for the part done, a flat line for the rest. */
@Composable
private fun WavyProgress(progress: Float, moving: Boolean, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val phase by rememberInfiniteTransition(label = "wave").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "phase"
    )
    Canvas(modifier) {
        val w = size.width; val cy = size.height / 2
        val done = (w * progress.coerceIn(0f, 1f))
        val amp = 3.2.dp.toPx(); val period = 14.dp.toPx()
        val ph = if (moving) phase * period else 0f
        val path = Path()
        var x = 0f
        path.moveTo(0f, cy)
        while (x <= done) {
            path.lineTo(x, cy + amp * sin(((x + ph) / period) * 2 * PI).toFloat())
            x += 2f
        }
        val sw = 4.dp.toPx()
        if (done > 2f) drawPath(path, cs.primary, style = Stroke(sw, cap = StrokeCap.Round))
        if (done + 8.dp.toPx() < w) drawLine(cs.primaryContainer, Offset(done + 8.dp.toPx(), cy), Offset(w, cy), sw, StrokeCap.Round)
        drawCircle(cs.primary, 2.dp.toPx(), Offset(w - 1.dp.toPx(), cy))
    }
}

@Composable
private fun QuickChip(icon: ImageVector?, label: String?, selected: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) cs.primaryContainer else Color.Transparent,
        border = if (selected) null else BorderStroke(1.5.dp, cs.outlineVariant)
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) Icon(icon, contentDescription = label ?: "Save as audio", modifier = Modifier.size(17.dp))
            if (icon != null && label != null) Spacer(Modifier.width(5.dp))
            if (label != null) Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = if (selected) cs.onPrimaryContainer else cs.onSurface, maxLines = 1)
        }
    }
}

@Composable
private fun OptLabel(t: String, value: String? = null) {
    Row(Modifier.padding(top = 14.dp, bottom = 6.dp)) {
        Text(t, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (value != null) Text(" $value", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    }
}

/** Connected segmented buttons, as in the design (a tick on the chosen one when it fits). */
@Composable
private fun Segments(labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().height(42.dp).border(1.5.dp, cs.outline.copy(alpha = 0.6f), RoundedCornerShape(21.dp)).padding(1.5.dp)) {
        labels.forEachIndexed { i, l ->
            val on = i == selected
            val shape = when (i) { 0 -> RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp); labels.size - 1 -> RoundedCornerShape(topEnd = 20.dp, bottomEnd = 20.dp); else -> RoundedCornerShape(0.dp) }
            Box(
                Modifier.weight(1f).fillMaxSize().background(if (on) cs.primaryContainer else Color.Transparent, shape).clickable { onPick(i) },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (on && labels.size <= 3) { Icon(Icons.Outlined.Check, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)) }
                    Text(
                        l, fontSize = if (l.length > 9) 11.sp else 12.5.sp, lineHeight = 13.sp, maxLines = 2,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        color = if (on) cs.onPrimaryContainer else cs.onSurface, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
            if (i < labels.size - 1) Box(Modifier.width(1.5.dp).fillMaxSize().background(cs.outline.copy(alpha = 0.6f)))
        }
    }
}

@Composable
private fun OptionCard(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onClick, color = cs.surfaceContainer, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = cs.onPrimaryContainer)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
    }
}

// ------------------------------------------------------------------ voices

private val AVATARS = listOf(0xFF7E57C2, 0xFF0F7B6C, 0xFFC2185B, 0xFF1565C0, 0xFF6D4C41, 0xFFEF6C00, 0xFF2E7D32, 0xFF5D4037)

private fun voiceChipLabel(s: ListenState): String {
    val lang = if (s.voice == ListenVoice.HINDI) "hi" else "en"
    return s.chosenVoice(lang)?.label ?: "Voice"
}

@Composable
private fun listenPurple(): Pair<Color, Color> {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.4f
    return if (dark) Color(0xFFCFBCFF) to Color(0xFF2A2340) else Color(0xFF7E57C2) to Color(0xFFEFE6FF)
}

@Composable
private fun Badge(text: String, bg: Color, fg: Color) {
    Text(
        text, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = fg, maxLines = 1,
        modifier = Modifier.padding(end = 4.dp).background(bg, RoundedCornerShape(8.dp)).padding(horizontal = 7.dp, vertical = 2.dp)
    )
}

@Composable
private fun VoiceBadges(v: VoiceItem) {
    val cs = MaterialTheme.colorScheme
    Row {
        if (v.online) Badge("Online HD", Color(0xFFD6E3FF), Color(0xFF0B2E6B))
        else if (v.natural) Badge("Natural", cs.primaryContainer, cs.onPrimaryContainer)
        else Badge("Basic", Color(0xFFFFE7B8), Color(0xFF5C3B00))
        if (!v.online && v.natural) Badge("Offline", cs.surfaceContainerHighest, cs.onSurfaceVariant)
    }
}

@Composable
private fun Avatar(color: Long, size: Int = 42) {
    Box(Modifier.size(size.dp).background(Color(color), RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
        Icon(Icons.Outlined.Person, null, tint = Color.White, modifier = Modifier.size((size * 0.55f).dp))
    }
}

/** The voice in use, with "Change ›" (Listening options). */
@Composable
private fun CurrentVoiceCard(s: ListenState, onChange: () -> Unit) {
    val (purple, purpleBg) = listenPurple()
    val lang = if (s.voice == ListenVoice.HINDI) "hi" else "en"
    val v = s.chosenVoice(lang)
    Surface(onClick = onChange, color = purpleBg, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            val idx = if (v == null) 0 else s.voices.filter { it.lang == v.lang }.indexOf(v).coerceAtLeast(0)
            Avatar(AVATARS[idx % AVATARS.size])
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(if (v == null) "Phone voice" else "${v.label} · ${v.country.ifBlank { if (v.lang == "hi") "Hindi" else "English" }}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(3.dp))
                if (v != null) VoiceBadges(v) else Text("Tap Change to choose a natural voice", style = MaterialTheme.typography.bodySmall)
            }
            Text("Change", fontWeight = FontWeight.Bold, color = purple, fontSize = 13.sp)
            Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, null, tint = purple)
        }
    }
}

@Composable
private fun SwitchCard(icon: ImageVector, title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = { onChange(!on) }, color = cs.surfaceContainer, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = cs.onPrimaryContainer)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            Switch(checked = on, onCheckedChange = onChange)
        }
    }
}

/** "Choose a voice": every voice on the phone with ▶ to hear a sample. */
@Composable
private fun VoicePicker(s: ListenState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val (purple, purpleBg) = listenPurple()
    var tab by remember { mutableStateOf(if (s.voice == ListenVoice.HINDI) "hi" else "en") }
    // Coming back from the Play Store or the voice download screen: look for new voices.
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(owner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e -> if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) ListenPlayer.refreshVoices() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    androidx.compose.ui.window.Dialog(onDismissRequest = onClose, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(color = cs.background, modifier = Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
                    Text("Choose a voice", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
                    val usingGoogle = s.engine == ListenVoices.GOOGLE
                    val list = s.voices.filter { it.lang == tab }
                    if (!s.googleInstalled || !usingGoogle) {
                        Surface(color = Color(0xFFFFE7B8), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 10.dp)) {
                            Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                                Text(
                                    if (!s.googleInstalled) "Your phone uses its own basic voice engine." else "You're using the phone's own voice engine.",
                                    fontWeight = FontWeight.Bold, color = Color(0xFF3A2E00), fontSize = 13.sp
                                )
                                Text("Google's natural voices sound much more like a real person.", color = Color(0xFF3A2E00), fontSize = 12.5.sp)
                                Spacer(Modifier.height(8.dp))
                                Surface(onClick = {
                                    if (!s.googleInstalled) {
                                        try { ctx.startActivity(ListenVoices.getGoogleIntent()) } catch (e: Exception) { try { ctx.startActivity(ListenVoices.getGoogleWebIntent()) } catch (ignored: Exception) {} }
                                    } else ListenPlayer.usePhoneEngine(false)
                                }, color = Color(0xFF5C3B00), shape = RoundedCornerShape(14.dp)) {
                                    Text(
                                        if (!s.googleInstalled) "Get natural voices (free)" else "Use Google's natural voices",
                                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.5.sp,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                    Row(Modifier.padding(top = 4.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("en" to "English", "hi" to "हिन्दी").forEach { (k, l) ->
                            Surface(
                                onClick = { tab = k; ListenPlayer.stopSample() }, shape = RoundedCornerShape(14.dp),
                                color = if (tab == k) cs.primaryContainer else Color.Transparent,
                                border = if (tab == k) null else BorderStroke(1.5.dp, cs.outlineVariant)
                            ) { Text(l, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = if (tab == k) cs.onPrimaryContainer else cs.onSurface, modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)) }
                        }
                    }
                    if (s.voices.isEmpty()) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp); Spacer(Modifier.width(12.dp)); Text("Looking for voices…", color = cs.onSurfaceVariant)
                        }
                    } else if (list.isEmpty()) {
                        Text(
                            if (tab == "hi") "No Hindi voice is installed yet." else "No English voice is installed yet.",
                            color = cs.onSurfaceVariant, modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp)
                        )
                    }
                    val chosen = s.chosenVoice(tab)
                    val good = list.filter { it.natural }
                    val basic = list.filter { !it.natural }
                    if (good.isNotEmpty()) GroupLabel("NATURAL · BEST")
                    good.forEach { v -> VoiceRow(v, list.indexOf(v), v.name == chosen?.name, s.sampling == v.name, purple, purpleBg) }
                    val showPhone = s.googleInstalled && usingGoogle && s.phoneEngine != null && s.phoneEngine != ListenVoices.GOOGLE
                    if (basic.isNotEmpty() || showPhone) GroupLabel("BASIC")
                    basic.forEach { v -> VoiceRow(v, list.indexOf(v), v.name == chosen?.name, s.sampling == v.name, purple, purpleBg) }
                    if (showPhone) {
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { ListenPlayer.usePhoneEngine(true) }.padding(horizontal = 6.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(0xFF9AA6A2)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(buildAnnotatedString {
                                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("Phone voice") }
                                    withStyle(SpanStyle(color = cs.onSurfaceVariant, fontSize = 12.5.sp)) { append(" · ${s.phoneEngineLabel}") }
                                }, fontSize = 14.5.sp)
                                Spacer(Modifier.height(3.dp))
                                Badge("Robotic", Color(0xFFFFE7B8), Color(0xFF5C3B00))
                            }
                            Text("Use", color = purple, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(end = 8.dp))
                        }
                    }
                    Text(
                        "Tap ▶ to hear: “" + (if (tab == "hi") ListenVoices.SAMPLE_HI else ListenVoices.SAMPLE_EN) + "”",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 6.dp, vertical = 10.dp)
                    )
                    TextButton(onClick = { try { ctx.startActivity(ListenPlayer.installVoicesIntent()) } catch (e: Exception) {} }) {
                        Icon(Icons.Outlined.CloudDownload, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Download more voices")
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun GroupLabel(t: String) {
    Text(t, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.3.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp, top = 10.dp, bottom = 2.dp))
}

@Composable
private fun VoiceRow(v: VoiceItem, index: Int, selected: Boolean, playing: Boolean, purple: Color, purpleBg: Color) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(shape)
            .background(if (selected) purpleBg else Color.Transparent)
            .then(if (selected) Modifier.border(2.dp, purple, shape) else Modifier)
            .clickable { ListenPlayer.chooseVoice(v) }
            .padding(horizontal = 6.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(AVATARS[index % AVATARS.size])
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(buildAnnotatedString {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(v.label) }
                if (v.country.isNotBlank()) withStyle(SpanStyle(color = cs.onSurfaceVariant, fontSize = 12.5.sp)) { append(" · ${v.country}") }
            }, fontSize = 14.5.sp)
            Spacer(Modifier.height(3.dp))
            if (playing) WavyProgress(0.6f, true, Modifier.width(150.dp).height(14.dp)) else VoiceBadges(v)
        }
        Surface(
            onClick = { ListenPlayer.sample(v.name) }, shape = RoundedCornerShape(14.dp),
            color = if (playing) purple else cs.surfaceContainerHigh, modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(if (playing) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, if (playing) "Stop sample" else "Play sample", tint = if (playing) Color.White else cs.onPrimaryContainer)
            }
        }
        Spacer(Modifier.width(6.dp))
        if (selected) Icon(Icons.Outlined.Check, "Chosen", tint = purple) else Spacer(Modifier.width(24.dp))
    }
}
