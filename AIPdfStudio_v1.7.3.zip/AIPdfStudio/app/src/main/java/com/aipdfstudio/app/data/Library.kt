package com.aipdfstudio.app.data

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

enum class DocKind(val badge: String, val color: Int) {
    PDF("PDF", 0xE53935), WORD("DOC", 0x1E5BD8), EXCEL("XLS", 0x1B8A3A), PPT("PPT", 0xE8670C), EPUB("EPUB", 0x7E57C2), OTHER("FILE", 0x757575);

    companion object {
        fun of(name: String): DocKind = when (name.substringAfterLast('.', "").lowercase()) {
            "pdf" -> PDF
            "doc", "docx", "rtf", "odt" -> WORD
            "xls", "xlsx", "csv", "ods" -> EXCEL
            "ppt", "pptx", "odp" -> PPT
            "epub" -> EPUB
            else -> OTHER
        }
    }
}

/** One document in the Files list. [path] is known for files on the phone's storage. */
data class DocFile(val uri: String, val name: String, val size: Long, val modified: Long, val path: String? = null) {
    val kind: DocKind get() = DocKind.of(name)

    fun toJson(): JSONObject = JSONObject().put("u", uri).put("n", name).put("s", size).put("m", modified).put("p", path ?: "")

    companion object {
        fun fromJson(o: JSONObject) = DocFile(o.getString("u"), o.optString("n"), o.optLong("s"), o.optLong("m"), o.optString("p").ifBlank { null })
    }
}

/** Finds documents on the phone and keeps the app's own lists (imports, bookmarks, folders). */
object Library {
    private val EXTS = listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "epub")

    /** True when the app may read every document on the phone. */
    fun hasAllFiles(ctx: Context): Boolean = if (Build.VERSION.SDK_INT >= 30) {
        Environment.isExternalStorageManager()
    } else {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    /** Settings page where the user turns on "All files access" (Android 11 and newer). */
    fun allFilesIntent(ctx: Context): Intent = try {
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
    } catch (e: Throwable) {
        Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
    }

    /** Uri the app (and apps it shares with) can open for a file on the phone's storage. */
    fun uriForPath(ctx: Context, path: String): Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", File(path))

    /** Every PDF / Word / Excel / PowerPoint file on the phone (needs [hasAllFiles]). */
    fun scanDevice(ctx: Context): List<DocFile> {
        if (!hasAllFiles(ctx)) return emptyList()
        val out = ArrayList<DocFile>()
        val col = MediaStore.Files.getContentUri("external")
        @Suppress("DEPRECATION")
        val proj = arrayOf(MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.SIZE, MediaStore.Files.FileColumns.DATE_MODIFIED, MediaStore.Files.FileColumns.DATA)
        val sel = EXTS.joinToString(" OR ") { "lower(${MediaStore.Files.FileColumns.DISPLAY_NAME}) LIKE ?" }
        val args = EXTS.map { "%.$it" }.toTypedArray()
        try {
            ctx.contentResolver.query(col, proj, sel, args, null)?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val path = c.getString(3) ?: continue
                    val f = File(path)
                    if (!f.isFile || path.contains("/Android/data/") || path.contains("/.")) continue
                    out.add(DocFile(uriForPath(ctx, path).toString(), name, c.getLong(1), c.getLong(2) * 1000L, path))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    /** Files this app made (converted, signed, created...). */
    fun appFiles(ctx: Context): List<DocFile> =
        (Outputs.dir(ctx).listFiles() ?: emptyArray()).filter { it.isFile && DocKind.of(it.name) != DocKind.OTHER }.map {
            DocFile(Outputs.uri(ctx, it).toString(), it.name, it.length(), it.lastModified(), it.path)
        }

    /** Everything for the Files tab, newest first, without doubles. */
    fun all(ctx: Context): List<DocFile> {
        val seen = HashSet<String>()
        val list = ArrayList<DocFile>()
        fun add(d: DocFile) {
            val key = d.path ?: d.uri
            if (seen.add(key)) list.add(d)
        }
        appFiles(ctx).forEach { add(it) }
        scanDevice(ctx).forEach { add(it) }
        imports(ctx).forEach { add(it) }
        // Without "All files access", also show the PDFs opened before.
        if (!hasAllFiles(ctx)) RecentStore(ctx).load().forEach { r -> add(DocFile(r.uri, r.name, r.size, r.openedAt)) }
        return list.sortedByDescending { it.modified }
    }

    // ------------------------------------------------------------------ small stores (JSON in preferences)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("library", Context.MODE_PRIVATE)

    private fun readList(ctx: Context, key: String): List<DocFile> = try {
        val a = JSONArray(prefs(ctx).getString(key, "[]"))
        (0 until a.length()).map { DocFile.fromJson(a.getJSONObject(it)) }
    } catch (e: Exception) {
        emptyList()
    }

    private fun writeList(ctx: Context, key: String, list: List<DocFile>) {
        prefs(ctx).edit().putString(key, JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()).apply()
    }

    fun imports(ctx: Context) = readList(ctx, "imports")
    fun addImports(ctx: Context, docs: List<DocFile>) = writeList(ctx, "imports", (docs + imports(ctx)).distinctBy { it.uri }.take(500))

    fun bookmarks(ctx: Context) = readList(ctx, "bookmarks")
    fun isBookmarked(ctx: Context, d: DocFile) = bookmarks(ctx).any { it.uri == d.uri }
    fun toggleBookmark(ctx: Context, d: DocFile) {
        val b = bookmarks(ctx)
        writeList(ctx, "bookmarks", if (b.any { it.uri == d.uri }) b.filter { it.uri != d.uri } else listOf(d) + b)
    }

    /** Folder name -> its files. */
    fun folders(ctx: Context): Map<String, List<DocFile>> = try {
        val o = JSONObject(prefs(ctx).getString("folders", "{}"))
        o.keys().asSequence().toList().sorted().associateWith { k ->
            val a = o.getJSONArray(k)
            (0 until a.length()).map { DocFile.fromJson(a.getJSONObject(it)) }
        }
    } catch (e: Exception) {
        emptyMap()
    }

    private fun saveFolders(ctx: Context, f: Map<String, List<DocFile>>) {
        val o = JSONObject()
        f.forEach { (k, v) -> o.put(k, JSONArray().apply { v.forEach { put(it.toJson()) } }) }
        prefs(ctx).edit().putString("folders", o.toString()).apply()
    }

    /** Makes a folder; returns false if the name is empty or taken. */
    fun createFolder(ctx: Context, name: String): Boolean {
        val n = name.trim()
        val f = folders(ctx)
        if (n.isEmpty() || f.keys.any { it.equals(n, true) }) return false
        saveFolders(ctx, f + (n to emptyList()))
        return true
    }

    fun deleteFolder(ctx: Context, name: String) = saveFolders(ctx, folders(ctx) - name)

    fun addToFolder(ctx: Context, folder: String, docs: List<DocFile>) {
        val f = folders(ctx).toMutableMap()
        f[folder] = ((f[folder] ?: emptyList()) + docs).distinctBy { it.uri }
        saveFolders(ctx, f)
    }

    fun removeFromFolder(ctx: Context, folder: String, d: DocFile) {
        val f = folders(ctx).toMutableMap()
        f[folder] = (f[folder] ?: emptyList()).filter { it.uri != d.uri }
        saveFolders(ctx, f)
    }

    /** Forgets a file everywhere in the app's lists (after it was deleted or renamed). */
    fun forget(ctx: Context, d: DocFile) {
        writeList(ctx, "imports", imports(ctx).filter { it.uri != d.uri })
        writeList(ctx, "bookmarks", bookmarks(ctx).filter { it.uri != d.uri })
        saveFolders(ctx, folders(ctx).mapValues { (_, v) -> v.filter { it.uri != d.uri } })
        RecentStore(ctx).remove(d.uri)
    }

    // ------------------------------------------------------------------ file actions

    /** Deletes the file itself when the app can; otherwise only removes it from the lists. */
    fun delete(ctx: Context, d: DocFile): Boolean {
        val p = d.path
        val ok = if (p != null) File(p).delete() else false
        if (ok && p != null) MediaScannerConnection.scanFile(ctx, arrayOf(p), null, null)
        forget(ctx, d)
        return ok
    }

    /** Renames a file on the phone. Returns the new entry, or null if it couldn't. */
    fun rename(ctx: Context, d: DocFile, newName: String): DocFile? {
        val p = d.path ?: return null
        val src = File(p)
        var n = newName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (n.isEmpty()) return null
        val ext = src.extension
        if (ext.isNotEmpty() && !n.endsWith(".$ext", true)) n += ".$ext"
        val dst = File(src.parentFile, n)
        if (dst.exists() || !src.renameTo(dst)) return null
        MediaScannerConnection.scanFile(ctx, arrayOf(src.path, dst.path), null, null)
        forget(ctx, d)
        val uri = if (dst.path.startsWith(Outputs.dir(ctx).path)) Outputs.uri(ctx, dst) else uriForPath(ctx, dst.path)
        return DocFile(uri.toString(), dst.name, dst.length(), dst.lastModified(), dst.path)
    }

    fun mimeOf(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "pdf" -> "application/pdf"
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xls" -> "application/vnd.ms-excel"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "ppt" -> "application/vnd.ms-powerpoint"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "epub" -> "application/epub+zip"
        "txt" -> "text/plain"
        else -> Outputs.mimeOf(name)
    }

    /** Opens a Word / Excel / PowerPoint file in another app. */
    fun openElsewhere(ctx: Context, d: DocFile) {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(d.uri), mimeOf(d.name))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(Intent.createChooser(i, "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun share(ctx: Context, docs: List<DocFile>) {
        if (docs.isEmpty()) return
        val uris = ArrayList(docs.map { Uri.parse(it.uri) })
        val send = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        val types = docs.map { mimeOf(it.name) }.distinct()
        send.type = if (types.size == 1) types[0] else "*/*"
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** All pages of a PDF stacked into one tall picture (handy for WhatsApp and social media). */
object LongImage {
    /** Keeps the picture under this many pixels so phones can open it. */
    private const val MAX_PIXELS = 60_000_000L

    fun make(ctx: Context, uri: Uri, out: File, progress: (String) -> Unit) {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw UserError("Couldn't open the PDF")
        pfd.use { fd ->
            val r = try { PdfRenderer(fd) } catch (e: SecurityException) { throw UserError("This PDF is password protected. Unlock it first.") }
            r.use { renderer ->
                val n = renderer.pageCount
                if (n == 0) throw UserError("This PDF has no pages")
                val sizes = (0 until n).map { i -> renderer.openPage(i).use { it.width to it.height } }
                var width = 1080
                val gap = 12
                fun totalH(w: Int) = sizes.sumOf { (pw, ph) -> (w.toLong() * ph / max(1, pw)) } + gap.toLong() * (n - 1)
                while (width > 360 && width.toLong() * totalH(width) > MAX_PIXELS) width -= 90
                val total = totalH(width).toInt()
                val tall = Bitmap.createBitmap(width, total, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(tall)
                canvas.drawColor(Color.rgb(225, 228, 230))
                var y = 0
                for (i in 0 until n) {
                    progress("Page ${i + 1} of $n…")
                    renderer.openPage(i).use { p ->
                        val h = max(1, (width.toLong() * p.height / max(1, p.width)).toInt())
                        val b = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
                        b.eraseColor(Color.WHITE)
                        p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        canvas.drawBitmap(b, 0f, y.toFloat(), null)
                        b.recycle()
                        y += h + gap
                    }
                }
                progress("Saving picture…")
                FileOutputStream(out).use { tall.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                tall.recycle()
            }
        }
    }
}

/** Android picture decoder for Word → PDF (keeps transparency for PNGs). */
object WordImages {
    fun maker(): (com.tom_roush.pdfbox.pdmodel.PDDocument, ByteArray) -> com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject? = { doc, bytes ->
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (max(o.outWidth, o.outHeight) / (s * 2) >= 2000) s *= 2
        val b = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, android.graphics.BitmapFactory.Options().apply { inSampleSize = s })
        if (b == null) null else try {
            if (b.hasAlpha()) com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory.createFromImage(doc, b)
            else com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory.createFromImage(doc, b, 0.88f)
        } finally {
            b.recycle()
        }
    }
}

@Suppress("unused")
private fun clampInt(v: Int, lo: Int, hi: Int) = min(hi, max(lo, v))
