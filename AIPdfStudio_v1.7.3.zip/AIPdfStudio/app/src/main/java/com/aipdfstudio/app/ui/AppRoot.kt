package com.aipdfstudio.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.History
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aipdfstudio.app.data.RecentStore
import com.aipdfstudio.app.data.queryName
import kotlinx.coroutines.launch

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("files", "Files", Icons.Outlined.Folder),
    Tab("home", "Recent", Icons.Outlined.History),
    Tab("bookmarks", "Bookmarks", Icons.Outlined.Bookmark),
    Tab("tools", "Tools", Icons.Outlined.GridView),
    Tab("ai", "AI", Icons.Outlined.AutoAwesome)
)

@Composable
fun AppRoot(ai: AiViewModel, incoming: Uri?, onIncomingHandled: () -> Unit, openListen: Boolean = false, onListenHandled: () -> Unit = {}) {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    val store = remember { RecentStore(ctx) }
    var recents by remember { mutableStateOf(store.load()) }
    var viewerUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    LaunchedEffect(route) { recents = store.load() }

    var editorUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    // A file handed to a tool from the editor's "More tools" (null = the tool asks for a file).
    var toolInput by remember { mutableStateOf<Uri?>(null) }
    // Which convert to start with (from the Files "+" sheet), and which list "Select a file" shows.
    var convertMode by remember { mutableStateOf<String?>(null) }
    var pickMode by rememberSaveable { mutableStateOf("PDF_TO_WORD") }
    var listenUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    fun openListen(u: Uri) {
        listenUri = u
        nav.navigate("listen") { launchSingleTop = true }
    }

    fun openEditor(uri: Uri) {
        editorUri = uri
        nav.navigate("editor")
    }

    fun openViewer(uri: Uri) {
        viewerUri = uri
        nav.navigate("viewer")
    }

    fun goTab(r: String) {
        nav.navigate(r) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun soon(name: String) {
        scope.launch {
            snack.currentSnackbarData?.dismiss()
            snack.showSnackbar("$name is coming in the next update")
        }
    }

    fun keepAccess(uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (ignored: Exception) {
        }
    }

    val editPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            EditorVm.keepAccess(ctx, uri)
            openEditor(uri)
        }
    }

    fun goTool(route: String) {
        if (route == "listen") {
            val cur = com.aipdfstudio.app.data.ListenPlayer.state.value.uri
            if (cur != null) openListen(cur) else { pickMode = "LISTEN"; nav.navigate("pick") }
        } else if (route == "edit") {
            editPicker.launch(arrayOf("application/pdf"))
        } else {
            toolInput = null
            convertMode = null
            nav.navigate(route)
        }
    }

    val openPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            keepAccess(uri)
            openViewer(uri)
        }
    }
    val aiPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            keepAccess(uri)
            ai.setDocument(uri, queryName(ctx, uri))
        }
    }

    LaunchedEffect(openListen) {
        if (openListen) {
            com.aipdfstudio.app.data.ListenPlayer.state.value.uri?.let { openListen(it) }
            onListenHandled()
        }
    }
    LaunchedEffect(incoming) {
        if (incoming != null) {
            // E-books (and text files) open in Listen; PDFs open in the viewer.
            val name = try { queryName(ctx, incoming) } catch (e: Exception) { "" }
            val mime = try { ctx.contentResolver.getType(incoming) } catch (e: Exception) { null }
            if (com.aipdfstudio.app.data.ListenBooks.kindOf(name, mime) != com.aipdfstudio.app.data.ListenBooks.Kind.PDF && !name.endsWith(".pdf", true)) openListen(incoming)
            else openViewer(incoming)
            onIncomingHandled()
        }
    }

    val showBar = route != null && tabs.any { it.route == route }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = { goTab(t.route) },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "files", modifier = Modifier.padding(pad)) {
            composable("files") {
                FilesScreen(
                    FilesActions(
                        openPdf = { openViewer(it) },
                        tool = { goTool(it) },
                        convert = { mode, uri -> convertMode = mode; toolInput = uri; nav.navigate("convert") },
                        pick = { mode -> pickMode = mode; nav.navigate("pick") },
                        createPdf = { nav.navigate("create") },
                        listen = { openListen(it) },
                        settings = { nav.navigate("settings") }
                    )
                )
            }
            composable("bookmarks") {
                BookmarksScreen(
                    onOpenPdf = { openViewer(it) },
                    onConvert = { mode, uri -> convertMode = mode; toolInput = uri; nav.navigate("convert") }
                )
            }
            composable("pick") {
                SelectFileScreen(
                    mode = pickMode,
                    onBack = { nav.popBackStack() },
                    onChosen = { u ->
                        keepAccess(u)
                        if (pickMode == "LISTEN") {
                            listenUri = u
                            nav.navigate("listen") { popUpTo("pick") { inclusive = true } }
                        } else {
                            convertMode = pickMode
                            toolInput = u
                            nav.navigate("convert") { popUpTo("pick") { inclusive = true } }
                        }
                    }
                )
            }
            composable("listen") {
                ListenScreen(uri = listenUri ?: com.aipdfstudio.app.data.ListenPlayer.state.value.uri, onBack = { nav.popBackStack() })
            }
            composable("create") {
                CreatePdfScreen(onBack = { nav.popBackStack() }, onOpen = { u -> nav.popBackStack(); openViewer(u) })
            }
            composable("home") {
                HomeScreen(
                    recents = recents,
                    onOpenFile = { openPicker.launch(arrayOf("application/pdf")) },
                    onOpenRecent = { openViewer(Uri.parse(it.uri)) },
                    onRemove = { store.remove(it.uri); recents = store.load() },
                    onSettings = { nav.navigate("settings") },
                    onTool = { goTool(it) },
                    onSoon = { soon(it) }
                )
            }
            composable("tools") {
                ToolsScreen(
                    onOpenFile = { openPicker.launch(arrayOf("application/pdf")) },
                    onAi = { goTab("ai") },
                    onTool = { goTool(it) },
                    onSoon = { soon(it) }
                )
            }
            composable("ai") {
                AiScreen(
                    vm = ai,
                    recents = recents,
                    onPickFile = { aiPicker.launch(arrayOf("application/pdf")) },
                    onSettings = { nav.navigate("settings") }
                )
            }
            composable("viewer") {
                val u = viewerUri
                if (u == null) {
                    LaunchedEffect(Unit) { nav.popBackStack() }
                } else {
                    key(u) {
                        ViewerScreen(
                            uri = u,
                            recents = store,
                            onBack = { nav.popBackStack() },
                            onAskAi = { name ->
                                ai.setDocument(u, name)
                                goTab("ai")
                            },
                            onEdit = { openEditor(u) },
                            onListen = { openListen(u) }
                        )
                    }
                }
            }
            composable("merge") { MergeScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("split") { SplitScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }, initial = toolInput) }
            composable("pages") { PagesScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }, initial = toolInput) }
            composable("compress") { CompressScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }, initial = toolInput) }
            composable("lock") { LockScreen(unlock = false, onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }, initial = toolInput) }
            composable("unlock") { LockScreen(unlock = true, onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("sign") { SignScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("scan") { ScanScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("convert") {
                ConvertScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }, startMode = convertMode, initial = toolInput)
            }
            composable("ocr") { OcrScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }, initial = toolInput) }
            composable("editor") {
                val u = editorUri
                if (u == null) {
                    LaunchedEffect(Unit) { nav.popBackStack() }
                } else {
                    EditorScreen(
                        uri = u,
                        onClose = { nav.popBackStack() },
                        onOpenTool = { route, file -> toolInput = file; nav.navigate(route) }
                    )
                }
            }
            composable("redact") { RedactScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }, initial = toolInput) }
            composable("forms") { FormsScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }, initial = toolInput) }
            composable("compare") { CompareScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("link") { LinkScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("premium") { PremiumScreen(onBack = { nav.popBackStack() }) }
            composable("settings") {
                SettingsScreen(vm = ai, onBack = { nav.popBackStack() }, onPremium = { nav.navigate("premium") })
            }
        }
    }
}
