package com.aipdfstudio.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * "AI Teacher" voices: Google's Gemini speech voices, read in the style of a school teacher.
 * Audio is made a little ahead of the reading and kept on the phone, so a page read once
 * plays again without internet.
 */
object AiTeacher {
    const val MODEL = "gemini-3.8-flash-tts"
    /** Changing the notes below changes this, so audio made with the old style is made again. */
    private const val STYLE_VERSION = "t1"

    data class Voice(val id: String, val label: String, val short: String, val female: Boolean)

    val VOICES = listOf(
        Voice("Fola", "AI Female Teacher", "AI Female", true),
        Voice("Ludo", "AI Male Teacher", "AI Male", false)
    )

    fun voice(id: String?): Voice? = VOICES.firstOrNull { it.id == id }

    /** How the teacher reads (measured from a real classroom: half-second stops, short breaths, normal pace). */
    fun notes(hindi: Boolean): String = if (hindi)
        "A warm, clear Indian school teacher reading a lesson aloud to students in Hindi, with natural Hindi pronunciation. " +
            "Normal lively pace, not slow. Short breath at commas, about half a second pause after each \"।\" or full stop, " +
            "a slightly longer pause between paragraphs. Slightly slower and clearer on new or difficult words, a natural rise on questions. " +
            "Calm, friendly and confident, never dramatic. Read only the transcript."
    else
        "A friendly, clear Indian school teacher reading a lesson aloud to students in English, with a gentle Indian English accent. " +
            "Normal lively pace, not slow. Short breath at commas, about half a second pause after each full stop, " +
            "a slightly longer pause between paragraphs. Slightly slower and clearer on new or scientific words, a natural rise on questions. " +
            "Calm, friendly and confident, never dramatic. Read only the transcript."

    fun prompt(text: String, hindi: Boolean): String = "## Director's Notes:\n${notes(hindi)}\n\n## Transcript:\n$text"

    /** A problem making the voice; [quota] and [noKey] let the player say exactly what to do. */
    class Failure(message: String, val noKey: Boolean = false, val quota: Boolean = false) : Exception(message)

    /** The file the audio for [text] is (or will be) kept in. */
    fun cacheFile(dir: File, voiceId: String, text: String): File =
        File(dir, "listen_ai/" + ListenCache.key(STYLE_VERSION, MODEL, voiceId, text) + ".wav")

    /** Makes the audio for [text] (or reuses it) and returns the WAV file. */
    suspend fun audio(cacheDir: File, apiKey: String, voiceId: String, text: String): File = withContext(Dispatchers.IO) {
        val f = cacheFile(cacheDir, voiceId, text)
        if (f.isFile && f.length() > 1000) return@withContext f
        if (apiKey.isBlank()) throw Failure("Add your Gemini key (AI tab → settings) to use the AI teacher voice.", noKey = true)
        val (pcm, rate) = request(apiKey, voiceId, text, ListenText.isHindi(text))
        f.parentFile?.mkdirs()
        val tmp = File(f.path + ".tmp")
        writeWav(pcm, rate, tmp)
        tmp.renameTo(f)
        f
    }

    private fun request(apiKey: String, voiceId: String, text: String, hindi: Boolean): Pair<ByteArray, Int> {
        val body = org.json.JSONObject()
            .put("contents", org.json.JSONArray().put(
                org.json.JSONObject().put("role", "user").put("parts", org.json.JSONArray().put(org.json.JSONObject().put("text", prompt(text, hindi))))
            ))
            .put("generationConfig", org.json.JSONObject()
                .put("responseModalities", org.json.JSONArray().put("audio"))
                .put("temperature", 0.7)
                .put("speech_config", org.json.JSONObject().put("voice_config", org.json.JSONObject().put("prebuilt_voice_config", org.json.JSONObject().put("voice_name", voiceId)))))
        try {
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 120000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey.trim())
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            conn.disconnect()
            when {
                code in 200..299 -> return parse(raw)
                code == 429 -> throw Failure("The AI teacher voice has reached today's free limit.", quota = true)
                code == 400 && raw.contains("API key", true) || code == 401 || code == 403 -> throw Failure("Google didn't accept the Gemini key.", noKey = true)
                code == 404 -> throw Failure("The AI teacher voice isn't available for this key yet.")
                code in 500..599 -> throw Failure("Google's voice service is busy.")
                else -> throw Failure("The AI teacher voice failed (error $code).")
            }
        } catch (e: UnknownHostException) {
            throw Failure("No internet connection.")
        } catch (e: SocketTimeoutException) {
            throw Failure("The AI teacher voice took too long (slow internet).")
        } catch (e: Failure) {
            throw e
        } catch (e: Exception) {
            throw Failure("Couldn't reach Google's voice service.")
        }
    }

    /** Audio comes back as base64 PCM ("audio/L16;codec=pcm;rate=24000"). */
    fun parse(raw: String): Pair<ByteArray, Int> {
        val parts = org.json.JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw Failure("The AI teacher voice returned nothing.")
        val out = java.io.ByteArrayOutputStream()
        var rate = 24000
        for (i in 0 until parts.length()) {
            val d = parts.getJSONObject(i).optJSONObject("inlineData") ?: parts.getJSONObject(i).optJSONObject("inline_data") ?: continue
            val mime = d.optString("mimeType", d.optString("mime_type", ""))
            Regex("rate=(\\d+)").find(mime)?.let { rate = it.groupValues[1].toInt() }
            out.write(java.util.Base64.getMimeDecoder().decode(d.optString("data")))
        }
        if (out.size() == 0) throw Failure("The AI teacher voice returned no sound.")
        return out.toByteArray() to rate
    }

    /** 16-bit mono PCM to a WAV file. */
    fun writeWav(pcm: ByteArray, rate: Int, f: File) {
        RandomAccessFile(f, "rw").use { r ->
            r.setLength(0)
            fun i32(v: Int) { r.write(byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())) }
            fun i16(v: Int) { r.write(byteArrayOf(v.toByte(), (v shr 8).toByte())) }
            r.writeBytes("RIFF"); i32(36 + pcm.size); r.writeBytes("WAVE")
            r.writeBytes("fmt "); i32(16); i16(1); i16(1); i32(rate); i32(rate * 2); i16(2); i16(16)
            r.writeBytes("data"); i32(pcm.size); r.write(pcm)
        }
    }

    /**
     * Groups a page's blocks into pieces of about a paragraph or two (fewer requests, natural
     * flow). Returns, for each piece, the first and last sentence index.
     */
    fun pieces(p: LPage, maxChars: Int = 700): List<IntRange> {
        val out = ArrayList<IntRange>()
        var start = -1; var end = -1; var chars = 0
        fun close() { if (start >= 0) out.add(start..end); start = -1; chars = 0 }
        for (b in p.blocks) {
            if (b.count == 0) continue
            val len = (b.first until b.first + b.count).sumOf { p.sentences[it].say.length }
            // A heading starts a new piece (unless it would be alone at the very start), and pieces stay under the limit.
            if (start >= 0 && (chars + len > maxChars || b.kind == LKind.HEADING || b.kind == LKind.FIGURE)) close()
            if (start < 0) start = b.first
            end = b.first + b.count - 1
            chars += len
            if (b.kind == LKind.FIGURE) close()
        }
        close()
        return out
    }

    /** The text sent for sentences [from]..[to] of a page: blocks on their own lines, so the voice pauses there. */
    fun textOf(p: LPage, from: Int, to: Int): String {
        val sb = StringBuilder()
        var lastBlock: LBlock? = null
        for (i in from..to) {
            val b = p.blocks.firstOrNull { i >= it.first && i < it.first + it.count }
            if (sb.isNotEmpty()) sb.append(if (b != lastBlock) "\n\n" else " ")
            sb.append(p.sentences[i].say)
            lastBlock = b
        }
        return sb.toString()
    }
}
