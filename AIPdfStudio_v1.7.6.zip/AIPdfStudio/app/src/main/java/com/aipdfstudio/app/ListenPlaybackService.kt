package com.aipdfstudio.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import com.aipdfstudio.app.data.ListenPlayer

/**
 * Keeps Listen reading with the screen off, and shows the media controls in the notification
 * shade and on the lock screen (play / pause, back and forward one sentence).
 */
class ListenPlaybackService : Service() {
    private var session: MediaSession? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm?.createNotificationChannel(NotificationChannel(CHANNEL, "Listen", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Controls while a PDF is read aloud"
            setShowBadge(false)
        })
        session = MediaSession(this, "AIPdfStudioListen").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() = ListenPlayer.play()
                override fun onPause() = ListenPlayer.pause()
                override fun onSkipToNext() = ListenPlayer.nextSentence()
                override fun onSkipToPrevious() = ListenPlayer.prevSentence()
                override fun onFastForward() = ListenPlayer.nextSentence()
                override fun onRewind() = ListenPlayer.prevSentence()
                override fun onStop() = ListenPlayer.stop()
            })
            isActive = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_TOGGLE -> ListenPlayer.toggle()
            ACT_NEXT -> ListenPlayer.nextSentence()
            ACT_PREV -> ListenPlayer.prevSentence()
            ACT_STOP -> { ListenPlayer.stop(); return START_NOT_STICKY }
        }
        val n = build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NOTE_ID, n)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }

    private fun pending(action: String, code: Int): PendingIntent =
        PendingIntent.getService(this, code, Intent(this, ListenPlaybackService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun art(): Bitmap {
        // Headphones tile in the app's mint and teal.
        val b = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xFFA6F2E1.toInt()
        c.drawRoundRect(RectF(0f, 0f, 192f, 192f), 52f, 52f, p)
        p.color = 0xFF0B4F45.toInt(); p.style = Paint.Style.STROKE; p.strokeWidth = 14f
        c.drawArc(RectF(48f, 46f, 144f, 142f), 180f, 180f, false, p)
        p.style = Paint.Style.FILL
        c.drawRoundRect(RectF(42f, 100f, 74f, 150f), 10f, 10f, p)
        c.drawRoundRect(RectF(118f, 100f, 150f, 150f), 10f, 10f, p)
        return b
    }

    private fun build(): Notification {
        val s = ListenPlayer.state.value
        val sub = "${s.unit} ${s.page + 1}" + (s.chapterTitle?.let { " · $it" } ?: "") + " · AI PDF Studio"
        session?.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, s.name)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, sub)
                .putBitmap(MediaMetadata.METADATA_KEY_ART, art())
                .build()
        )
        session?.setPlaybackState(
            PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                    PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP)
                .setState(if (s.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, PlaybackState.PLAYBACK_POSITION_UNKNOWN, if (s.playing) 1f else 0f)
                .build()
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java).setAction(ACT_OPEN).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun action(icon: Int, title: String, act: String, code: Int) =
            Notification.Action.Builder(Icon.createWithResource(this, icon), title, pending(act, code)).build()
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle(s.name)
            .setContentText(sub)
            .setLargeIcon(art())
            .setContentIntent(open)
            .setDeleteIntent(pending(ACT_STOP, 9))
            .setOngoing(s.playing)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(action(android.R.drawable.ic_media_rew, "Back", ACT_PREV, 2))
            .addAction(
                if (s.playing) action(android.R.drawable.ic_media_pause, "Pause", ACT_TOGGLE, 3)
                else action(android.R.drawable.ic_media_play, "Play", ACT_TOGGLE, 3)
            )
            .addAction(action(android.R.drawable.ic_media_ff, "Forward", ACT_NEXT, 4))
            .setStyle(Notification.MediaStyle().setMediaSession(session?.sessionToken).setShowActionsInCompactView(0, 1, 2))
            .build()
    }

    companion object {
        private const val CHANNEL = "listen"
        private const val NOTE_ID = 7071
        const val ACT_TOGGLE = "listen.toggle"
        const val ACT_NEXT = "listen.next"
        const val ACT_PREV = "listen.prev"
        const val ACT_STOP = "listen.stop"
        const val ACT_OPEN = "listen.open"

        /** Connects [ListenPlayer] to this service (called once from [App]). */
        fun install() {
            com.aipdfstudio.app.data.ListenService.onStart = { c -> start(c) }
            com.aipdfstudio.app.data.ListenService.onRefresh = { c -> refresh(c) }
            com.aipdfstudio.app.data.ListenService.onStop = { c -> running = false; c.stopService(Intent(c, ListenPlaybackService::class.java)) }
        }

        private var running = false

        private fun start(c: Context) {
            running = true
            val i = Intent(c, ListenPlaybackService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {
                running = false
            }
        }

        private fun refresh(c: Context) {
            if (!running) return
            try { c.startService(Intent(c, ListenPlaybackService::class.java)) } catch (ignored: Exception) {}
        }
    }
}
