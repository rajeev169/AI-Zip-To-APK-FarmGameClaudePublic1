package com.aipdfstudio.app.data

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.coroutines.resume

/**
 * "Save as audio": speaks the chosen pages into files with the phone's voice and joins them into
 * one .m4a (small, plays in any music app). Falls back to .wav if the phone can't encode AAC.
 */
object AudioExport {
    suspend fun save(
        ctx: Context, name: String, pages: List<List<String>>, from: Int, to: Int,
        voice: ListenVoice, speed: Float, pitch: Float,
        engine: String? = null, voiceEn: String? = null, voiceHi: String? = null,
        progress: (String) -> Unit
    ): File {
        val chunks = ArrayList<String>()
        val sb = StringBuilder()
        for (p in from..minOf(to, pages.size - 1)) for (s in pages[p]) {
            if (sb.length + s.length > 2800) { chunks.add(sb.toString()); sb.setLength(0) }
            sb.append(s.replace("•", "")).append(if (s.trimEnd().lastOrNull()?.let { it in ".!?।:" } == true) " " else ". ")
        }
        if (sb.isNotBlank()) chunks.add(sb.toString())
        if (chunks.isEmpty()) throw UserError("Nothing to read in these pages")

        val tts = initTts(ctx, engine?.takeIf { it.isNotEmpty() }) ?: throw UserError("No text-to-speech voice on this phone")
        val dir = File(ctx.cacheDir, "tts_parts").apply { deleteRecursively(); mkdirs() }
        val parts = ArrayList<File>()
        try {
            tts.setSpeechRate(speed)
            tts.setPitch(pitch)
            for ((i, c) in chunks.withIndex()) {
                progress("Making audio ${i + 1} of ${chunks.size}…")
                val loc = when (voice) {
                    ListenVoice.ENGLISH -> Locale("en", "IN")
                    ListenVoice.HINDI -> Locale("hi", "IN")
                    ListenVoice.AUTO -> if (ListenText.isHindi(c)) Locale("hi", "IN") else Locale("en", "IN")
                }
                val chosen = ListenVoices.find(tts, if (loc.language == "hi") voiceHi else voiceEn)
                    ?.takeIf { !it.isNetworkConnectionRequired }   // files are made offline-safe
                if (chosen == null || tts.setVoice(chosen) != TextToSpeech.SUCCESS) { if (tts.setLanguage(loc) < 0) tts.setLanguage(Locale.US) }
                val f = File(dir, "p$i.wav")
                synth(tts, c, f, "x$i")
                if (f.length() > 44) parts.add(f)
            }
        } finally {
            tts.shutdown()
        }
        if (parts.isEmpty()) throw UserError("The voice couldn't make audio. Try another voice in Listening options.")
        progress("Joining audio…")
        val wav = File(dir, "all.wav")
        joinWavs(parts, wav)
        val base = name.replace(Regex("\\.pdf$", RegexOption.IGNORE_CASE), "")
        val out = Outputs.newFile(ctx, base, "audio", "m4a")
        return try {
            progress("Compressing…")
            wavToM4a(wav, out)
            out
        } catch (e: Throwable) {
            out.delete()
            val w = Outputs.newFile(ctx, base, "audio", "wav")
            wav.copyTo(w, overwrite = true)
            w
        } finally {
            dir.deleteRecursively()
        }
    }

    private suspend fun initTts(ctx: Context, pkg: String?): TextToSpeech? {
        var made: TextToSpeech? = null
        val ok = withTimeout(15_000) {
            suspendCancellableCoroutine<Boolean> { cont ->
                val l = TextToSpeech.OnInitListener { st -> if (cont.isActive) cont.resume(st == TextToSpeech.SUCCESS) }
                made = if (pkg != null) TextToSpeech(ctx.applicationContext, l, pkg) else TextToSpeech(ctx.applicationContext, l)
            }
        }
        return if (ok) made else { made?.shutdown(); null }
    }

    private suspend fun synth(tts: TextToSpeech, text: String, f: File, id: String) {
        withTimeout(180_000) {
            suspendCancellableCoroutine<Unit> { cont ->
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(u: String?) {}
                    override fun onDone(u: String?) { if (u == id && cont.isActive) cont.resume(Unit) }
                    @Deprecated("old API")
                    override fun onError(u: String?) { if (u == id && cont.isActive) cont.resume(Unit) }
                    override fun onError(u: String?, code: Int) { if (u == id && cont.isActive) cont.resume(Unit) }
                })
                if (tts.synthesizeToFile(text, Bundle(), f, id) != TextToSpeech.SUCCESS && cont.isActive) cont.resume(Unit)
            }
        }
    }

    private class Wav(val rate: Int, val channels: Int, val bits: Int, val dataStart: Long, val dataLen: Long)

    private fun readWav(f: File): Wav? = RandomAccessFile(f, "r").use { r ->
        val head = ByteArray(12); r.readFully(head)
        if (String(head, 0, 4) != "RIFF" || String(head, 8, 4) != "WAVE") return null
        var rate = 22050; var ch = 1; var bits = 16
        while (r.filePointer + 8 <= r.length()) {
            val id = ByteArray(4); r.readFully(id)
            val lenB = ByteArray(4); r.readFully(lenB)
            val len = ByteBuffer.wrap(lenB).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
            val tag = String(id)
            if (tag == "fmt ") {
                val b = ByteArray(len.toInt()); r.readFully(b)
                val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
                ch = bb.getShort(2).toInt(); rate = bb.getInt(4); bits = bb.getShort(14).toInt()
            } else if (tag == "data") {
                val start = r.filePointer
                val real = if (len == 0L || start + len > r.length()) r.length() - start else len
                return Wav(rate, ch, bits, start, real)
            } else r.seek(r.filePointer + len + (len and 1))
        }
        null
    }

    /** Joins WAV parts (same voice, so same format) into one WAV. */
    private fun joinWavs(parts: List<File>, out: File) {
        val infos = parts.mapNotNull { f -> readWav(f)?.let { f to it } }
        val first = infos.firstOrNull()?.second ?: throw UserError("Audio parts were empty")
        val total = infos.filter { it.second.rate == first.rate && it.second.channels == first.channels }.sumOf { it.second.dataLen }
        RandomAccessFile(out, "rw").use { w ->
            w.setLength(0)
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()).putInt((36 + total).toInt()).put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(first.channels.toShort()).putInt(first.rate)
                .putInt(first.rate * first.channels * first.bits / 8).putShort((first.channels * first.bits / 8).toShort()).putShort(first.bits.toShort())
            h.put("data".toByteArray()).putInt(total.toInt())
            w.write(h.array())
            val buf = ByteArray(64 * 1024)
            for ((f, info) in infos) {
                if (info.rate != first.rate || info.channels != first.channels) continue
                RandomAccessFile(f, "r").use { r ->
                    r.seek(info.dataStart)
                    var left = info.dataLen
                    while (left > 0) {
                        val n = r.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n <= 0) break
                        w.write(buf, 0, n); left -= n
                    }
                }
            }
        }
    }

    /** Encodes 16-bit PCM WAV to AAC in an .m4a file. */
    private fun wavToM4a(wav: File, out: File) {
        val info = readWav(wav) ?: throw IllegalStateException("bad wav")
        if (info.bits != 16) throw IllegalStateException("not 16-bit")
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, info.rate, info.channels).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 64_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        val bytesPerSec = info.rate * info.channels * 2L
        RandomAccessFile(wav, "r").use { r ->
            r.seek(info.dataStart)
            var left = info.dataLen
            var sent = 0L
            var inputDone = false
            val bi = MediaCodec.BufferInfo()
            val chunk = ByteArray(8192)
            while (true) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val ib = codec.getInputBuffer(ii)!!
                        ib.clear()
                        val n = if (left > 0) r.read(chunk, 0, minOf(minOf(chunk.size, ib.remaining()).toLong(), left).toInt()) else -1
                        val pts = sent * 1_000_000L / bytesPerSec
                        if (n <= 0) {
                            codec.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            ib.put(chunk, 0, n)
                            codec.queueInputBuffer(ii, 0, n, pts, 0)
                            sent += n; left -= n
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(bi, 10_000)
                when {
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> { track = muxer.addTrack(codec.outputFormat); muxer.start() }
                    oi >= 0 -> {
                        val ob = codec.getOutputBuffer(oi)!!
                        if (bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) bi.size = 0
                        if (bi.size > 0 && track >= 0) { ob.position(bi.offset); ob.limit(bi.offset + bi.size); muxer.writeSampleData(track, ob, bi) }
                        codec.releaseOutputBuffer(oi, false)
                        if (bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                    }
                }
            }
        }
        codec.stop(); codec.release()
        muxer.stop(); muxer.release()
    }
}
