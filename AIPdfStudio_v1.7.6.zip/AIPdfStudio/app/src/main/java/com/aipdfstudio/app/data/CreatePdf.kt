package com.aipdfstudio.app.data

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import java.io.File

enum class PageStyle(val label: String) { BLANK("Blank"), LINE("Line"), GRID("Grid"), GRAPH("Graph") }

enum class PageSize(val label: String, val w: Float, val h: Float) {
    A4("A4", 595.28f, 841.89f),
    LETTER("Letter", 612f, 792f),
    LEGAL("Legal", 612f, 1008f),
    A5("A5", 419.53f, 595.28f)
}

/** Page colours offered on the Create PDF screen: white, mint, cream, light blue. */
val PageColors = listOf(0xFFFFFF, 0xDDF3E4, 0xFBF5DF, 0xE0E8F7)

/** Makes a new PDF of empty pages: plain, lined, grid or graph paper, in a chosen size and colour. */
object CreatePdf {
    fun make(out: File, style: PageStyle, size: PageSize, color: Int, landscape: Boolean, count: Int) {
        val n = count.coerceIn(1, 500)
        val w = if (landscape) size.h else size.w
        val h = if (landscape) size.w else size.h
        PDDocument().use { doc ->
            repeat(n) {
                val page = PDPage(PDRectangle(w, h))
                doc.addPage(page)
                PDPageContentStream(doc, page).use { cs -> paint(cs, style, color, w, h) }
            }
            doc.documentInformation.creator = "AI PDF Studio"
            doc.save(out)
        }
    }

    private fun rgb(cs: PDPageContentStream, c: Int, stroke: Boolean) {
        val r = ((c shr 16) and 255) / 255f
        val g = ((c shr 8) and 255) / 255f
        val b = (c and 255) / 255f
        if (stroke) cs.setStrokingColor(r, g, b) else cs.setNonStrokingColor(r, g, b)
    }

    private fun paint(cs: PDPageContentStream, style: PageStyle, color: Int, w: Float, h: Float) {
        if (color != 0xFFFFFF) {
            rgb(cs, color, false)
            cs.addRect(0f, 0f, w, h)
            cs.fill()
        }
        val m = 36f // lines stop short of the edge, like printed paper
        when (style) {
            PageStyle.BLANK -> Unit
            PageStyle.LINE -> {
                rgb(cs, 0xBFC7CC, true)
                cs.setLineWidth(0.6f)
                var y = h - 72f
                while (y > m) {
                    cs.moveTo(m, y); cs.lineTo(w - m, y)
                    y -= 24f
                }
                cs.stroke()
                // Red margin line on the left, as on notebook paper.
                rgb(cs, 0xE8A0A0, true)
                cs.setLineWidth(0.8f)
                cs.moveTo(m + 36f, h - m); cs.lineTo(m + 36f, m)
                cs.stroke()
            }
            PageStyle.GRID -> grid(cs, w, h, m, 18f, 0xC9D1D5, 0.5f)
            PageStyle.GRAPH -> {
                grid(cs, w, h, m, 7.2f, 0xDCE3E6, 0.3f)
                grid(cs, w, h, m, 36f, 0xAEB9BE, 0.7f)
            }
        }
    }

    private fun grid(cs: PDPageContentStream, w: Float, h: Float, m: Float, step: Float, c: Int, lw: Float) {
        rgb(cs, c, true)
        cs.setLineWidth(lw)
        val cols = ((w - 2 * m) / step).toInt()
        val rows = ((h - 2 * m) / step).toInt()
        val gw = cols * step
        val gh = rows * step
        val x0 = (w - gw) / 2
        val y0 = (h - gh) / 2
        for (i in 0..cols) { val x = x0 + i * step; cs.moveTo(x, y0); cs.lineTo(x, y0 + gh) }
        for (j in 0..rows) { val y = y0 + j * step; cs.moveTo(x0, y); cs.lineTo(x0 + gw, y) }
        cs.stroke()
    }
}
