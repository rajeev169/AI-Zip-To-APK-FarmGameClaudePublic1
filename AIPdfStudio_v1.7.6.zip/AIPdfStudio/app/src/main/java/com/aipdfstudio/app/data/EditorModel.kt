package com.aipdfstudio.app.data

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType0Font
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.blend.BlendMode
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationText
import com.tom_roush.pdfbox.util.Matrix
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class MarkKind { HIGHLIGHT, UNDERLINE, STRIKE }
enum class ShapeKind { RECT, OVAL, LINE, ARROW, CHECK, CROSS, DOT }

/**
 * Everything the editor can add or change. All positions are fractions (0..1) of the page as
 * displayed (top-left origin); sizes in points. Objects are immutable: edits make copies.
 */
sealed class EdObj {
    abstract val id: Long
    abstract val page: Int
}

/** An existing paragraph that was changed (or deleted). */
data class ParaObj(
    override val id: Long,
    override val page: Int,
    val paraIndex: Int,
    val origBox: FBox,
    val firstBaseline: Float,
    val lineGapPt: Float,
    val origText: String,
    val origStyle: TStyle,
    val font: FontRef?,
    val text: String,
    val style: TStyle,
    val deleted: Boolean = false,
    /** Widest the text may wrap to (fraction of page width). Headings may grow to the margin. */
    val maxW: Float = origBox.w,
    /** When the text grows past its space: [FLOW_AUTO], [FLOW_PUSH] or [FLOW_FIT]. */
    val flow: Int = FLOW_AUTO
) : EdObj() {
    val changed get() = deleted || text != origText || style != origStyle
}

/** Push the text below down; if the page is full, make the text smaller instead. */
const val FLOW_AUTO = 0
/** Always push the text below down (even if some goes off the page). */
const val FLOW_PUSH = 1
/** Always keep the paragraph in its space by making its text smaller. */
const val FLOW_FIT = 2

/** What happened to an edited paragraph that grew: pushed the text below down, or was made smaller. */
data class FlowResult(val pushedPt: Float, val linesMoved: Int, val fitScale: Float, val pageFull: Boolean)

/** New text box. [l],[t] top-left, [w] width (fractions). */
data class TextObj(
    override val id: Long,
    override val page: Int,
    val l: Float,
    val t: Float,
    val w: Float,
    val text: String,
    val style: TStyle
) : EdObj()

/**
 * A picture or signature. [box] is the unrotated box; [rot] turns it (degrees, clockwise on screen)
 * around its centre. [tint] recolours a signature; [thick] is its pen thickness (1..16).
 */
data class ImageObj(
    override val id: Long,
    override val page: Int,
    val box: FBox,
    val path: String,
    val signature: Boolean = false,
    val rot: Float = 0f,
    val tint: Int? = null,
    val thick: Float? = null
) : EdObj() {
    /** True if the point (page fractions) is inside the turned box. [aspect] = page width / height. */
    fun hit(x: Float, y: Float, aspect: Float, slop: Float = 0f): Boolean {
        val cx = (box.l + box.r) / 2
        val cy = (box.t + box.b) / 2
        val a = Math.toRadians(-rot.toDouble())
        val dx = (x - cx) * aspect
        val dy = y - cy
        val lx = (dx * cos(a) - dy * sin(a)).toFloat()
        val ly = (dx * sin(a) + dy * cos(a)).toFloat()
        return kotlin.math.abs(lx) <= box.w * aspect / 2 + slop && kotlin.math.abs(ly) <= box.h / 2 + slop
    }
}

/**
 * A hand-drawn signature kept as pen strokes, so its colour and thickness can change after placing.
 * Points are fractions (0..1) of the signature picture; [baseW] is the pen width as a fraction of its width.
 */
data class SigInk(val strokes: List<List<Pair<Float, Float>>>, val baseW: Float, val color: Int) {
    /** The drawn thickness on the editor's 1..16 scale. */
    val baseThick: Float get() = (baseW / THICK_UNIT).coerceIn(1f, 16f)

    fun encode(): String = buildString {
        append("sig1 ").append(baseW).append(' ').append(color).append('\n')
        strokes.forEach { st ->
            append(st.joinToString(" ") { (x, y) -> String.format(java.util.Locale.US, "%.4f,%.4f", x, y) }).append('\n')
        }
    }

    companion object {
        /** Pen width per thickness step, as a fraction of the signature's width. */
        const val THICK_UNIT = 0.004f

        fun decode(text: String): SigInk? = try {
            val lines = text.lines().filter { it.isNotBlank() }
            val head = lines.first().split(' ')
            require(head[0] == "sig1")
            val strokes = lines.drop(1).map { ln ->
                ln.trim().split(' ').map { pt -> val (x, y) = pt.split(','); x.toFloat() to y.toFloat() }
            }.filter { it.size > 1 }
            if (strokes.isEmpty()) null else SigInk(strokes, head[1].toFloat(), head[2].toInt() and 0xFFFFFF)
        } catch (e: Exception) {
            null
        }
    }
}

data class MarkObj(
    override val id: Long,
    override val page: Int,
    val kind: MarkKind,
    val boxes: List<FBox>,
    val color: Int
) : EdObj()

data class InkObj(
    override val id: Long,
    override val page: Int,
    val points: List<Pair<Float, Float>>,
    val color: Int,
    val widthPt: Float
) : EdObj()

data class ShapeObj(
    override val id: Long,
    override val page: Int,
    val kind: ShapeKind,
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float,
    val color: Int,
    val widthPt: Float
) : EdObj()

data class NoteObj(
    override val id: Long,
    override val page: Int,
    val x: Float,
    val y: Float,
    val text: String,
    val color: Int = 0xFFC107
) : EdObj()

/** Writes editor objects into a PDF. Shared by the live preview and Save. */
object EditorRender {
    private const val UNI_FONT = "com/tom_roush/pdfbox/resources/ttf/LiberationSans-Regular.ttf"

    fun standardFont(s: TStyle): PDType1Font = when (s.family) {
        Family.SERIF -> when {
            s.bold && s.italic -> PDType1Font.TIMES_BOLD_ITALIC
            s.bold -> PDType1Font.TIMES_BOLD
            s.italic -> PDType1Font.TIMES_ITALIC
            else -> PDType1Font.TIMES_ROMAN
        }
        Family.MONO -> when {
            s.bold && s.italic -> PDType1Font.COURIER_BOLD_OBLIQUE
            s.bold -> PDType1Font.COURIER_BOLD
            s.italic -> PDType1Font.COURIER_OBLIQUE
            else -> PDType1Font.COURIER
        }
        Family.SANS -> when {
            s.bold && s.italic -> PDType1Font.HELVETICA_BOLD_OBLIQUE
            s.bold -> PDType1Font.HELVETICA_BOLD
            s.italic -> PDType1Font.HELVETICA_OBLIQUE
            else -> PDType1Font.HELVETICA
        }
    }

    /** Fonts made during one save, so the Unicode fallback is embedded only once. */
    /**
     * Fonts made during one save. Unicode fallbacks (for symbols like ₹ or accents the standard fonts
     * lack) come from the phone's own fonts first, then the font bundled with the PDF library.
     */
    class FontCache(private val doc: PDDocument) {
        private val writers = java.util.IdentityHashMap<PDFont, FontWriter>()
        private val loaded = ArrayList<PDFont>()
        private var next = 0
        fun writer(f: PDFont): FontWriter = writers.getOrPut(f) { FontWriter(f) }

        private fun load(i: Int): PDFont? = try {
            if (i < SYSTEM_FONTS.size) {
                val f = java.io.File(SYSTEM_FONTS[i])
                if (f.isFile) PDType0Font.load(doc, f) else null
            } else {
                val stream = try {
                    PDFBoxResourceLoader.getStream(UNI_FONT)
                } catch (e: Throwable) {
                    null
                } ?: EditorRender::class.java.classLoader?.getResourceAsStream(UNI_FONT)
                stream?.use { PDType0Font.load(doc, it, true) }
            }
        } catch (e: Throwable) {
            null
        }

        /** A Unicode font that can draw [text] (or the most complete one available). */
        fun unicodeFor(text: String): PDFont? {
            loaded.firstOrNull { writer(it).canDraw(text) }?.let { return it }
            while (next <= SYSTEM_FONTS.size) {
                val f = load(next++) ?: continue
                loaded.add(f)
                if (writer(f).canDraw(text)) return f
            }
            return loaded.firstOrNull()
        }
    }

    private val SYSTEM_FONTS = listOf(
        "/system/fonts/Roboto-Regular.ttf",
        "/system/fonts/RobotoStatic-Regular.ttf",
        "/system/fonts/NotoSans-Regular.ttf",
        "/system/fonts/DroidSans.ttf",
        // Hindi and other Indian scripts.
        "/system/fonts/NotoSansDevanagari-Regular.ttf",
        "/system/fonts/NotoSansDevanagari-Regular.otf",
        "/system/fonts/NotoSansDevanagariUI-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    )

    /**
     * Fonts for one piece of text: the main font, plus a Unicode font only for the few characters
     * (like ₹) the main font can't draw, so a paragraph keeps its look.
     */
    class FontChain(val primary: FontWriter, val fallback: FontWriter?) {
        private fun fontFor(cp: String): FontWriter? = when {
            primary.canDraw(cp) -> primary
            fallback != null && fallback.canDraw(cp) -> fallback
            else -> null
        }

        fun runs(s: String): List<Pair<FontWriter, String>> {
            val out = ArrayList<Pair<FontWriter, String>>()
            var i = 0
            while (i < s.length) {
                val cp = s.codePointAt(i)
                val ch = String(Character.toChars(cp))
                i += Character.charCount(cp)
                val f = (if (ch == " ") primary.takeIf { it.canDraw(" ") } else null) ?: fontFor(ch) ?: continue
                if (out.isNotEmpty() && out.last().first === f) out[out.size - 1] = f to out.last().second + ch else out.add(f to ch)
            }
            return out
        }

        fun width(s: String, sizePt: Float) = runs(s).sumOf { (f, t) -> f.width(t, sizePt).toDouble() }.toFloat()

        /** Keeps only characters some font can draw. */
        fun clean(s: String) = s.split('\n').joinToString("\n") { line -> runs(line).joinToString("") { it.second } }
    }

    /**
     * Chooses fonts: the paragraph's own font if the look is unchanged and it has every letter,
     * else the closest standard font, with a Unicode font for anything the standard font lacks.
     */
    fun pickFont(page: PDPage, ref: FontRef?, origStyle: TStyle?, style: TStyle, text: String, cache: FontCache): Pair<FontChain, String> {
        val clean = text.replace('\t', ' ').replace("\r", "")
        val flat = clean.replace("\n", "")
        val sameLook = origStyle != null && origStyle.bold == style.bold && origStyle.italic == style.italic && origStyle.family == style.family
        if (sameLook) {
            FontStyle.lookup(page, ref)?.let { f -> val w = cache.writer(f); if (w.canDraw(flat)) return FontChain(w, null) to clean }
        }
        val std = cache.writer(standardFont(style))
        if (std.canDraw(flat)) return FontChain(std, null) to clean
        val missing = flat.filter { !std.canDraw(it.toString()) }
        val uni = cache.unicodeFor(missing)?.let { cache.writer(it) }
        val chain = FontChain(std, uni)
        return chain to chain.clean(clean)
    }

    private fun rgb(c: Int) = floatArrayOf(((c shr 16) and 255) / 255f, ((c shr 8) and 255) / 255f, (c and 255) / 255f)

    /** Draws in display fractions on a page, whatever its rotation. */
    private class Painter(val cs: PDPageContentStream, val pm: PageMath) {
        val W = pm.dispW
        val H = pm.dispH
        fun pt(x: Float, y: Float) = pm.toUser(x * W, y * H)
        fun moveTo(x: Float, y: Float) { val p = pt(x, y); cs.moveTo(p[0], p[1]) }
        fun lineTo(x: Float, y: Float) { val p = pt(x, y); cs.lineTo(p[0], p[1]) }
        fun curveTo(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
            val a = pt(x1, y1); val b = pt(x2, y2); val c = pt(x3, y3)
            cs.curveTo(a[0], a[1], b[0], b[1], c[0], c[1])
        }
        fun rect(b: FBox) { moveTo(b.l, b.t); lineTo(b.r, b.t); lineTo(b.r, b.b); lineTo(b.l, b.b); cs.closePath() }
        fun oval(b: FBox) {
            val k = 0.5523f
            val cx = (b.l + b.r) / 2; val cy = (b.t + b.b) / 2; val rx = b.w / 2; val ry = b.h / 2
            moveTo(cx + rx, cy)
            curveTo(cx + rx, cy + ry * k, cx + rx * k, cy + ry, cx, cy + ry)
            curveTo(cx - rx * k, cy + ry, cx - rx, cy + ry * k, cx - rx, cy)
            curveTo(cx - rx, cy - ry * k, cx - rx * k, cy - ry, cx, cy - ry)
            curveTo(cx + rx * k, cy - ry, cx + rx, cy - ry * k, cx + rx, cy)
            cs.closePath()
        }
        fun fill(c: Int) { val f = rgb(c); cs.setNonStrokingColor(f[0], f[1], f[2]) }
        fun stroke(c: Int, wPt: Float) { val f = rgb(c); cs.setStrokingColor(f[0], f[1], f[2]); cs.setLineWidth(wPt) }
        fun text(fonts: FontChain, sizePt: Float, color: Int, leftF: Float, baselineF: Float, s: String) {
            val runs = fonts.runs(s)
            if (runs.isEmpty()) return
            val tm = pm.textMatrix(leftF * W, baselineF * H, 1f)
            fill(color)
            cs.beginText()
            cs.setTextMatrix(Matrix(tm[0], tm[1], tm[2], tm[3], tm[4], tm[5]))
            // Each run continues where the previous one ended.
            for ((f, t) in runs) {
                cs.setFont(f.font, sizePt)
                f.show(cs, t)
            }
            cs.endText()
        }
    }

    /** Height (fraction of page) a text box will take once wrapped. */
    fun textHeight(lines: Int, sizePt: Float, gapPt: Float, dispH: Float) =
        (sizePt * 1.0f + (lines - 1).coerceAtLeast(0) * gapPt + sizePt * 0.25f) / dispH

    /**
     * Applies [objs] to [doc]. [skipDraw] (the item being edited on screen) still has its old text
     * removed but is not drawn, because the screen draws it live.
     */
    /** Key of the PDF image for a picture (recoloured signatures need their own copy). */
    fun imageKey(o: ImageObj): String = if (o.signature && o.tint != null) o.path + "#" + o.tint else o.path

    /** Maps a point of a box (page fractions) to PDF user space, turning it [rot] degrees around the box centre. */
    private fun turner(pm: PageMath, b: FBox, rot: Float): (Float, Float) -> FloatArray {
        val W = pm.dispW
        val H = pm.dispH
        val cx = (b.l + b.r) / 2 * W
        val cy = (b.t + b.b) / 2 * H
        val a = Math.toRadians(rot.toDouble())
        val c = cos(a).toFloat()
        val s = sin(a).toFloat()
        return { x, y ->
            val dx = x * W - cx
            val dy = y * H - cy
            pm.toUser(cx + dx * c - dy * s, cy + dx * s + dy * c)
        }
    }

    /** Matrix that draws a 1x1 image into [b], turned [rot] degrees. */
    fun boxMatrix(pm: PageMath, b: FBox, rot: Float): FloatArray {
        val t = turner(pm, b, rot)
        val bl = t(b.l, b.b)
        val br = t(b.r, b.b)
        val tl = t(b.l, b.t)
        return floatArrayOf(br[0] - bl[0], br[1] - bl[1], tl[0] - bl[0], tl[1] - bl[1], bl[0], bl[1])
    }

    private fun drawSigInk(pm: PageMath, cs: PDPageContentStream, im: ImageObj, ink: SigInk) {
        val t = turner(pm, im.box, im.rot)
        val b = im.box
        val wPt = max(0.3f, (im.thick ?: ink.baseThick) * SigInk.THICK_UNIT * b.w * pm.dispW)
        val f = rgb(im.tint ?: ink.color)
        cs.saveGraphicsState()
        cs.setLineCapStyle(1)
        cs.setLineJoinStyle(1)
        cs.setStrokingColor(f[0], f[1], f[2])
        cs.setLineWidth(wPt)
        ink.strokes.forEach { st ->
            val p0 = t(b.l + st[0].first * b.w, b.t + st[0].second * b.h)
            cs.moveTo(p0[0], p0[1])
            for (i in 1 until st.size) {
                val q = t(b.l + st[i].first * b.w, b.t + st[i].second * b.h)
                cs.lineTo(q[0], q[1])
            }
        }
        cs.stroke()
        cs.restoreGraphicsState()
    }

    /** An edited paragraph laid out for drawing (size and lines may shrink to fit). */
    private class Lay(val para: ParaObj, val font: FontChain, val txt: String, var size: Float, var lines: List<String>, var gap: Float)

    private fun contentBytes(page: PDPage): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val it = page.contentStreams
        while (it.hasNext()) { it.next().createInputStream().use { s -> s.copyTo(out) }; out.write('\n'.code) }
        return out.toByteArray()
    }

    /**
     * The page's own content as one form, with only the text inside [band] kept (text elsewhere is
     * taken out, so moved text isn't found twice by search or copy). Lines and pictures stay; the
     * drawing is clipped to the band anyway.
     */
    private fun snapshot(doc: PDDocument, page: PDPage, band: FBox): com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject {
        val cos = com.tom_roush.pdfbox.cos.COSName.FLATE_DECODE
        var bytes = contentBytes(page)
        val tmp = PDPage(page.mediaBox)
        tmp.cropBox = page.cropBox
        tmp.rotation = page.rotation
        tmp.resources = page.resources
        tmp.setContents(com.tom_roush.pdfbox.pdmodel.common.PDStream(doc, java.io.ByteArrayInputStream(bytes), cos))
        doc.addPage(tmp)
        try {
            val outside = listOf(FBox(0f, 0f, 1f, band.t), FBox(0f, band.t, band.l, 1f), FBox(band.r, band.t, 1f, 1f)).filter { it.w > 0f && it.h > 0f }
            TextRemover.remove(doc, doc.numberOfPages - 1, outside)
            bytes = contentBytes(tmp)
        } catch (e: Exception) {
        } finally {
            doc.removePage(tmp)
        }
        val form = com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject(
            com.tom_roush.pdfbox.pdmodel.common.PDStream(doc, java.io.ByteArrayInputStream(bytes), cos)
        )
        form.resources = page.resources
        form.bBox = page.mediaBox
        return form
    }

    /** User-space rectangle (x, y, w, h) of a display box. */
    private fun userRect(pm: PageMath, b: FBox): FloatArray {
        val a = pm.toUser(b.l * pm.dispW, b.t * pm.dispH)
        val c = pm.toUser(b.r * pm.dispW, b.b * pm.dispH)
        return floatArrayOf(min(a[0], c[0]), min(a[1], c[1]), kotlin.math.abs(c[0] - a[0]), kotlin.math.abs(c[1] - a[1]))
    }

    private fun shifted(o: EdObj, dy: Float): EdObj = when (o) {
        is TextObj -> o.copy(t = o.t + dy)
        is ImageObj -> o.copy(box = FBox(o.box.l, o.box.t + dy, o.box.r, o.box.b + dy))
        is MarkObj -> o.copy(boxes = o.boxes.map { FBox(it.l, it.t + dy, it.r, it.b + dy) })
        is InkObj -> o.copy(points = o.points.map { (x, y) -> x to y + dy })
        is ShapeObj -> o.copy(y1 = o.y1 + dy, y2 = o.y2 + dy)
        is NoteObj -> o.copy(y = o.y + dy)
        is ParaObj -> o
    }

    private fun topOf(o: EdObj): Float = when (o) {
        is TextObj -> o.t
        is ImageObj -> o.box.t
        is MarkObj -> o.boxes.minOf { it.t }
        is InkObj -> o.points.minOf { it.second }
        is ShapeObj -> min(o.y1, o.y2)
        is NoteObj -> o.y
        is ParaObj -> o.origBox.t
    }

    private fun leftOf(o: EdObj): Float = when (o) {
        is TextObj -> o.l
        is ImageObj -> o.box.l
        is MarkObj -> o.boxes.minOf { it.l }
        is InkObj -> o.points.minOf { it.first }
        is ShapeObj -> min(o.x1, o.x2)
        is NoteObj -> o.x
        is ParaObj -> o.origBox.l
    }

    /**
     * Applies [objs] to [doc]. Returns, for edited paragraphs that grew past their space, whether
     * the text below was pushed down or the paragraph was made smaller to fit.
     */
    fun apply(
        doc: PDDocument,
        objs: List<EdObj>,
        images: Map<String, PDImageXObject>,
        skipDraw: Long? = null,
        inks: Map<String, SigInk> = emptyMap()
    ): Map<Long, FlowResult> {
        val results = HashMap<Long, FlowResult>()
        val cache = FontCache(doc)
        for ((pageIndex, list) in objs.groupBy { it.page }.toSortedMap()) {
            if (pageIndex !in 0 until doc.numberOfPages) continue
            val page = doc.getPage(pageIndex)
            val cb = page.cropBox
            val pm = PageMath(cb.lowerLeftX, cb.lowerLeftY, cb.width, cb.height, page.rotation)

            val paras = list.filterIsInstance<ParaObj>().filter { it.changed || it.id == skipDraw }
            val W = pm.dispW
            val H = pm.dispH

            // 0. Lay out edited paragraphs, and find ones that grew past their space.
            fun layout(para: ParaObj, size: Float): Lay {
                val (font, txt) = pickFont(page, para.font, para.origStyle, para.style.copy(sizePt = size), para.text, cache)
                // Smaller text wraps in a narrower width too, so lines break at the same words.
                val maxW = (max(para.origBox.w, para.maxW) * W + para.style.sizePt * 0.6f) * size / para.style.sizePt
                val lines = TextWrap.wrap(txt, maxW) { font.width(it, size) }
                var gap = para.lineGapPt * size / para.origStyle.sizePt
                if (gap < size * 0.95f) gap = size * 1.2f
                return Lay(para, font, txt, size, lines, gap)
            }
            fun bottomOf(l: Lay) = l.para.firstBaseline + ((l.lines.size - 1) * l.gap + l.size * 0.28f) / H
            val lays = paras.filter { !it.deleted }.map { layout(it, it.style.sizePt) }.toMutableList()
            var push: Pair<FBox, Float>? = null
            val grown = lays.filter { l -> l.lines.size > 1 && (bottomOf(l) - l.para.origBox.b) * H > 1f }.sortedBy { it.para.origBox.t }
            if (grown.isNotEmpty()) {
                val pageParas = try { Paragraphs.read(doc, pageIndex) } catch (e: Exception) { emptyList() }
                for (l in grown) {
                    val o = l.para.origBox
                    // The column this paragraph is in: stop at blocks of text standing beside it.
                    // Only real blocks of text count as another column (not bullets, numbers or short labels).
                    val near = pageParas.filter { q -> q.box.b > o.b && q.box.t < o.b + 0.35f && (q.box.w > 0.15f || q.box.h > 0.08f) }
                    val rightSide = near.filter { it.box.l >= o.r - 0.002f && it.box.l > o.l + 0.05f }
                    val leftSide = near.filter { it.box.r <= o.l + 0.002f }
                    val x1 = if (rightSide.size >= 2 || rightSide.any { it.box.h > 0.08f }) rightSide.minOf { it.box.l } - 0.006f else 1f
                    val x0 = if (leftSide.size >= 2 || leftSide.any { it.box.h > 0.08f }) leftSide.maxOf { it.box.r } + 0.006f else 0f
                    val below = pageParas.filter { q -> q.box.t >= o.b - 0.001f && q.box.l < x1 && q.box.r > x0 && !(kotlin.math.abs(q.box.t - o.t) < 0.001f && kotlin.math.abs(q.box.l - o.l) < 0.001f) }
                    val nextTop = below.minOfOrNull { it.box.t } ?: (1f - 18f / H)
                    val lowest = below.maxOfOrNull { it.box.b } ?: o.b
                    val freePt = (nextTop - o.b) * H - 1.5f
                    val needPt = (bottomOf(l) - o.b) * H
                    if (needPt <= freePt) { results[l.para.id] = FlowResult(0f, 0, 1f, false); continue }
                    // Keep the gap that was above the next text (up to 12 pt), so headings don't stick to it.
                    val keepGap = min(max(freePt, 0f), 12f)
                    val pushPt = needPt - (freePt - keepGap)
                    val roomPt = ((1f - 12f / H) - lowest) * H
                    val fit = l.para.flow == FLOW_FIT || (l.para.flow == FLOW_AUTO && (pushPt > roomPt || push != null))
                    if (!fit) {
                        push = FBox(x0, o.b + 0.5f / H, x1, 1f) to pushPt
                        results[l.para.id] = FlowResult(pushPt, max(1, kotlin.math.round(pushPt / l.gap).toInt()), 1f, false)
                    } else {
                        // Make the text smaller until it fits in its own space and the gap below it.
                        val target = o.b + freePt / H
                        var k = 1f
                        var best = l
                        while (k > 0.5f) {
                            k -= 0.03f
                            best = layout(l.para, l.para.style.sizePt * k)
                            if (bottomOf(best) <= target) break
                        }
                        lays[lays.indexOf(l)] = best
                        results[l.para.id] = FlowResult(0f, 0, best.size / l.para.style.sizePt, l.para.flow == FLOW_AUTO)
                    }
                }
            }

            // 1. Remove old words of changed paragraphs. Where something can't be removed, cover it.
            val wipe = paras.map { it.origBox.pad(0.002f, 0.002f) }
            val cover = ArrayList<FBox>()
            if (wipe.isNotEmpty()) {
                TextRemover.remove(doc, pageIndex, wipe)
                val left = try { TextGeometry.read(doc, pageIndex) } catch (e: Exception) { null }
                if (left != null) {
                    for (w in wipe) {
                        val still = left.lines.any { ln -> ln.chars.any { (c, b) -> c != ' ' && w.contains((b.l + b.r) / 2, (b.t + b.b) / 2) } }
                        if (still) cover.add(w)
                    }
                }
            }

            // 1b. Pushing down: keep a copy of everything below, then take its text off the page.
            val band = push?.first
            val pushPt = push?.second ?: 0f
            val form = if (band != null) {
                val f = snapshot(doc, page, band)
                TextRemover.remove(doc, pageIndex, listOf(band))
                f
            } else null
            val dy = pushPt / H
            fun inBand(o: EdObj) = band != null && topOf(o) >= band.t - 0.001f && leftOf(o) >= band.l - 0.001f && leftOf(o) < band.r
            val list = if (band == null) list else list.map { o -> if (o !is ParaObj && inBand(o)) shifted(o, dy) else o }

            PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                val p = Painter(cs, pm)
                cover.forEach { b -> p.fill(0xFFFFFF); p.rect(b); cs.fill() }
                if (band != null && form != null) {
                    // Blank the band, then draw what was there lower down (text, lines and pictures move together).
                    val r = userRect(pm, band)
                    cs.saveGraphicsState()
                    cs.setNonStrokingColor(1f, 1f, 1f)
                    cs.addRect(r[0], r[1], r[2], r[3]); cs.fill()
                    cs.restoreGraphicsState()
                    cs.saveGraphicsState()
                    cs.addRect(r[0], r[1], r[2], r[3]); cs.clip()
                    val d = pm.dir(0f, pushPt)
                    cs.transform(Matrix.getTranslateInstance(d[0], d[1]))
                    cs.drawForm(form)
                    cs.restoreGraphicsState()
                }

                // 2. Highlights first (multiply blend keeps the text readable), then lines and shapes.
                list.filterIsInstance<MarkObj>().filter { it.id != skipDraw }.forEach { m ->
                    cs.saveGraphicsState()
                    when (m.kind) {
                        MarkKind.HIGHLIGHT -> {
                            val gs = PDExtendedGraphicsState()
                            gs.blendMode = BlendMode.MULTIPLY
                            cs.setGraphicsStateParameters(gs)
                            p.fill(m.color)
                            m.boxes.forEach { b -> p.rect(b) }
                            cs.fill()
                        }
                        MarkKind.UNDERLINE, MarkKind.STRIKE -> {
                            m.boxes.forEach { b ->
                                val th = max(0.6f, b.h * pm.dispH * 0.07f)
                                p.stroke(m.color, th)
                                val y = if (m.kind == MarkKind.UNDERLINE) b.b - b.h * 0.12f else (b.t + b.b) / 2 + b.h * 0.08f
                                p.moveTo(b.l, y); p.lineTo(b.r, y); cs.stroke()
                            }
                        }
                    }
                    cs.restoreGraphicsState()
                }
                list.filterIsInstance<InkObj>().filter { it.id != skipDraw && it.points.size > 1 }.forEach { ink ->
                    cs.saveGraphicsState()
                    cs.setLineCapStyle(1)
                    cs.setLineJoinStyle(1)
                    p.stroke(ink.color, ink.widthPt)
                    p.moveTo(ink.points[0].first, ink.points[0].second)
                    for (i in 1 until ink.points.size) p.lineTo(ink.points[i].first, ink.points[i].second)
                    cs.stroke()
                    cs.restoreGraphicsState()
                }
                list.filterIsInstance<ShapeObj>().filter { it.id != skipDraw }.forEach { s -> drawShape(p, cs, s) }

                // 3. Pictures and signatures.
                list.filterIsInstance<ImageObj>().filter { it.id != skipDraw }.forEach { im ->
                    // Drawn signatures go in as sharp pen strokes in their chosen colour and thickness.
                    val ink = if (im.signature) inks[im.path] else null
                    if (ink != null) {
                        drawSigInk(pm, cs, im, ink)
                        return@forEach
                    }
                    val img = images[imageKey(im)] ?: images[im.path] ?: return@forEach
                    val m = boxMatrix(pm, im.box, im.rot)
                    cs.drawImage(img, Matrix(m[0], m[1], m[2], m[3], m[4], m[5]))
                }

                // 4. Text: changed paragraphs at their old place (wrapped to their width), then new text boxes.
                lays.filter { it.para.id != skipDraw }.forEach { l ->
                    val para = l.para
                    // Other edited paragraphs inside a pushed-down band move with it.
                    val off = if (band != null && para.origBox.t >= band.t - 0.001f && para.origBox.l >= band.l - 0.001f && para.origBox.l < band.r) dy else 0f
                    l.lines.forEachIndexed { i, line ->
                        p.text(l.font, l.size, para.style.color, para.origBox.l, para.firstBaseline + off + i * l.gap / p.H, line)
                    }
                }
                list.filterIsInstance<TextObj>().filter { it.id != skipDraw }.forEach { t ->
                    val (font, txt) = pickFont(page, null, null, t.style, t.text, cache)
                    val lines = TextWrap.wrap(txt, t.w * p.W) { font.width(it, t.style.sizePt) }
                    val gap = t.style.sizePt * 1.2f
                    lines.forEachIndexed { i, line ->
                        p.text(font, t.style.sizePt, t.style.color, t.l, t.t + (t.style.sizePt * 0.9f + i * gap) / p.H, line)
                    }
                }

                // 5. Sticky-note icons.
                list.filterIsInstance<NoteObj>().filter { it.id != skipDraw }.forEach { n ->
                    val s = 16f
                    val b = FBox(n.x, n.y, n.x + s / p.W, n.y + s / p.H)
                    p.fill(n.color); p.rect(b); cs.fill()
                    p.stroke(0x795548, 0.8f); p.rect(b); cs.stroke()
                    p.stroke(0x5D4037, 0.8f)
                    for (k in 1..3) { val y = b.t + b.h * k / 4.2f; p.moveTo(b.l + b.w * 0.2f, y); p.lineTo(b.r - b.w * 0.2f, y) }
                    cs.stroke()
                }
            }
            // Real comment annotations so other PDF apps show the note text too.
            list.filterIsInstance<NoteObj>().filter { it.id != skipDraw && it.text.isNotBlank() }.forEach { n ->
                val a = pm.toUser(n.x * pm.dispW, n.y * pm.dispH)
                val note = PDAnnotationText()
                note.contents = n.text
                note.rectangle = PDRectangle(a[0], a[1] - 16f, 16f, 16f)
                note.color = PDColor(rgb(n.color), PDDeviceRGB.INSTANCE)
                note.isNoView = true // the icon is already drawn on the page
                page.annotations.add(note)
            }
        }
        return results
    }

    private fun drawShape(p: Painter, cs: PDPageContentStream, s: ShapeObj) {
        cs.saveGraphicsState()
        cs.setLineCapStyle(1)
        cs.setLineJoinStyle(1)
        p.stroke(s.color, s.widthPt)
        val b = FBox(min(s.x1, s.x2), min(s.y1, s.y2), max(s.x1, s.x2), max(s.y1, s.y2))
        when (s.kind) {
            ShapeKind.RECT -> { p.rect(b); cs.stroke() }
            ShapeKind.OVAL -> { p.oval(b); cs.stroke() }
            ShapeKind.LINE -> { p.moveTo(s.x1, s.y1); p.lineTo(s.x2, s.y2); cs.stroke() }
            ShapeKind.ARROW -> {
                p.moveTo(s.x1, s.y1); p.lineTo(s.x2, s.y2); cs.stroke()
                // Arrow head drawn in points so it isn't stretched on wide pages.
                val ax = s.x2 * p.W; val ay = s.y2 * p.H
                val ang = atan2(ay - s.y1 * p.H, ax - s.x1 * p.W)
                val len = max(8f, s.widthPt * 4f)
                fun at(a: Double) = ((ax - len * cos(a)).toFloat() / p.W) to ((ay - len * sin(a)).toFloat() / p.H)
                val (lx, ly) = at(ang - 0.45)
                val (rx, ry) = at(ang + 0.45)
                p.fill(s.color)
                p.moveTo(s.x2, s.y2); p.lineTo(lx, ly); p.lineTo(rx, ry); cs.closePath(); cs.fill()
            }
            ShapeKind.CHECK -> {
                p.moveTo(b.l, b.t + b.h * 0.55f); p.lineTo(b.l + b.w * 0.38f, b.b); p.lineTo(b.r, b.t); cs.stroke()
            }
            ShapeKind.CROSS -> {
                p.moveTo(b.l, b.t); p.lineTo(b.r, b.b); p.moveTo(b.r, b.t); p.lineTo(b.l, b.b); cs.stroke()
            }
            ShapeKind.DOT -> { p.fill(s.color); p.oval(b); cs.fill() }
        }
        cs.restoreGraphicsState()
    }
}

/** Starts editing a paragraph (nothing changes until its text or look is changed). */
fun Paragraph.toObj(id: Long): ParaObj = ParaObj(
    id = id,
    page = page,
    paraIndex = index,
    origBox = box,
    firstBaseline = firstBaseline,
    lineGapPt = lineGapPt,
    origText = text,
    origStyle = style,
    font = font,
    text = text,
    style = style,
    // One-line paragraphs (headings, labels) may grow to the right margin; others keep their width.
    maxW = if (lines.size == 1) max(box.w, 0.95f - box.l) else box.w
)
