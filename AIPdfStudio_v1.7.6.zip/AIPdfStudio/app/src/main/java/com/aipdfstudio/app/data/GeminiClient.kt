package com.aipdfstudio.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

object GeminiClient {
    sealed class Result {
        data class Ok(val text: String) : Result()
        data class Err(val message: String) : Result()
    }

    /** contents: ordered (role, text) pairs where role is "user" or "model". */
    suspend fun generate(
        apiKey: String,
        model: String,
        system: String,
        contents: List<Pair<String, String>>
    ): Result = withContext(Dispatchers.IO) {
        val m = model.trim().removePrefix("models/").ifBlank { DEFAULT_MODEL }
        try {
            val arr = JSONArray()
            contents.forEach { (role, text) ->
                arr.put(
                    JSONObject().put("role", role)
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            }
            val body = JSONObject()
                .put("contents", arr)
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))

            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 120000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey.trim())
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            conn.disconnect()

            when {
                code in 200..299 -> parseOk(text)
                code == 400 && text.contains("API key", ignoreCase = true) ->
                    Result.Err("That key isn't valid. Check it and try again.")
                code == 400 ->
                    Result.Err("Google rejected the request. Try a shorter document or check the model name.")
                code == 401 || code == 403 ->
                    Result.Err("Google didn't accept this key. Make sure it's active and Gemini API access is enabled.")
                code == 404 -> Result.Err("Model not found. Check the model name in AI settings.")
                code == 429 -> Result.Err("You've reached your free limit for now. Wait a minute and try again.")
                code in 500..599 -> Result.Err("Google's AI service is busy. Try again soon.")
                else -> Result.Err("Something went wrong (error $code).")
            }
        } catch (e: UnknownHostException) {
            Result.Err("No internet connection.")
        } catch (e: SocketTimeoutException) {
            Result.Err("The request timed out. Try again.")
        } catch (e: Exception) {
            Result.Err("Couldn't reach the AI service.")
        }
    }

    private fun parseOk(raw: String): Result = try {
        val cands = JSONObject(raw).optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            Result.Err("The AI didn't return an answer. Try rephrasing.")
        } else {
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            }
            if (sb.isBlank()) Result.Err("The AI didn't return an answer. Try rephrasing.")
            else Result.Ok(sb.toString().trim())
        }
    } catch (e: Exception) {
        Result.Err("Couldn't read the AI response.")
    }
}
