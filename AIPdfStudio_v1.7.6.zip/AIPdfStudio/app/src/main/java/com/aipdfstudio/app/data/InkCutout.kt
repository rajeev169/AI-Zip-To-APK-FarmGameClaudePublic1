package com.aipdfstudio.app.data

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Turns a photo of a signature on paper into clean ink on a transparent background.
 *
 * How: the paper's brightness is estimated around every pixel (so shadows and uneven light don't
 * matter), pixels clearly darker than their paper become ink, tiny specks are dropped, the ink gets one
 * even colour, and the result is cropped tight around the ink. Pure Kotlin so it can be tested off-device.
 */
object InkCutout {
    /** ARGB pixels of the cut-out (transparent where there is no ink), its size, and the ink colour (RGB). */
    class Cut(val px: IntArray, val w: Int, val h: Int, val color: Int, val inkShare: Float)

    fun extract(src: IntArray, w: Int, h: Int): Cut? {
        if (w < 8 || h < 8 || src.size < w * h) return null
        val n = w * h
        val lum = FloatArray(n)
        for (i in 0 until n) {
            val c = src[i]
            lum[i] = 0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)
        }

        // 1. Paper brightness: a wide local average, done twice so the ink itself doesn't darken it.
        val r = max(6, min(w, h) / 10)
        var bg = boxBlur(lum, w, h, r)
        val clipped = FloatArray(n) { i -> if (lum[i] < bg[i] * 0.88f) bg[i] else lum[i] }
        bg = boxBlur(clipped, w, h, r)

        // 2. Ink strength 0..1 from how much darker a pixel is than its paper.
        val a = FloatArray(n)
        for (i in 0 until n) {
            val b = bg[i]
            val t0 = max(16f, b * 0.12f)
            val t1 = t0 + max(22f, b * 0.16f)
            val d = b - lum[i]
            a[i] = ((d - t0) / (t1 - t0)).coerceIn(0f, 1f)
        }

        // 3. Drop specks (dust, paper grain) smaller than a few pixels.
        dropSpecks(a, w, h, max(6, (n * 0.00004f).roundToInt()))

        // 4. One even ink colour: the average of the strongest ink, a little deeper.
        var sr = 0L; var sg = 0L; var sb = 0L; var cnt = 0
        var inkPx = 0
        for (i in 0 until n) {
            if (a[i] > 0.15f) inkPx++
            if (a[i] > 0.85f) {
                val c = src[i]
                sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255; cnt++
            }
        }
        if (cnt == 0) return null
        val color = (((sr / cnt) * 0.75).toInt() shl 16) or (((sg / cnt) * 0.75).toInt() shl 8) or ((sb / cnt) * 0.75).toInt()

        // 5. Crop around the ink with a small margin.
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) for (x in 0 until w) {
            if (a[y * w + x] > 0.15f) {
                if (x < minX) minX = x; if (x > maxX) maxX = x
                if (y < minY) minY = y; if (y > maxY) maxY = y
            }
        }
        if (maxX < 0) return null
        val pad = max(4, (max(maxX - minX, maxY - minY) * 0.03f).roundToInt())
        minX = max(0, minX - pad); minY = max(0, minY - pad)
        maxX = min(w - 1, maxX + pad); maxY = min(h - 1, maxY + pad)
        val cw = maxX - minX + 1
        val ch = maxY - minY + 1
        val out = IntArray(cw * ch)
        for (y in 0 until ch) for (x in 0 until cw) {
            val al = (a[(y + minY) * w + (x + minX)] * 255f).roundToInt()
            out[y * cw + x] = (al shl 24) or color
        }
        return Cut(out, cw, ch, color, inkPx.toFloat() / n)
    }

    /** Average over a (2r+1)² square, using a summed-area table. */
    private fun boxBlur(v: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val sat = DoubleArray((w + 1) * (h + 1))
        for (y in 0 until h) {
            var row = 0.0
            for (x in 0 until w) {
                row += v[y * w + x]
                sat[(y + 1) * (w + 1) + (x + 1)] = sat[y * (w + 1) + (x + 1)] + row
            }
        }
        val out = FloatArray(w * h)
        for (y in 0 until h) {
            val y0 = max(0, y - r); val y1 = min(h, y + r + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - r); val x1 = min(w, x + r + 1)
                val s = sat[y1 * (w + 1) + x1] - sat[y0 * (w + 1) + x1] - sat[y1 * (w + 1) + x0] + sat[y0 * (w + 1) + x0]
                out[y * w + x] = (s / ((x1 - x0) * (y1 - y0))).toFloat()
            }
        }
        return out
    }

    /** Clears connected ink blobs smaller than [minArea] pixels. */
    private fun dropSpecks(a: FloatArray, w: Int, h: Int, minArea: Int) {
        val seen = BooleanArray(w * h)
        val stack = IntArray(w * h)
        val blob = IntArray(w * h)
        for (start in 0 until w * h) {
            if (seen[start] || a[start] <= 0.15f) continue
            var sp = 0; var bn = 0
            stack[sp++] = start; seen[start] = true
            while (sp > 0) {
                val i = stack[--sp]
                blob[bn++] = i
                val x = i % w; val y = i / w
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val j = ny * w + nx
                    if (!seen[j] && a[j] > 0.15f) { seen[j] = true; stack[sp++] = j }
                }
            }
            if (bn < minArea) for (k in 0 until bn) a[blob[k]] = 0f
        }
    }
}
