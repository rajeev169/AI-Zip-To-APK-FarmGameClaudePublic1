package com.aipdfstudio.app.data

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.URLDecoder
import java.util.zip.ZipInputStream

/** Builds one Listen page block by block (used for e-books, Word and text files). */
class PageBuilder {
    private val sents = ArrayList<LSent>()
    private val blocks = ArrayList<LBlock>()
    val isEmpty get() = sents.isEmpty()
    val blockCount get() = blocks.size

    fun text(kind: LKind, t: String) {
        val clean = ListenLayout.cleanChars(t).replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty() || !clean.any { it.isLetterOrDigit() }) return
        val start = sents.size
        val parts = if (kind == LKind.HEADING) listOf(clean) else ListenText.split(clean)
        for (s in parts) sents.add(LSent(s, ListenLayout.sayText(s)))
        if (sents.size > start) blocks.add(LBlock(kind, start, sents.size - start))
    }

    fun figure(caption: String?) {
        val c = caption?.replace(Regex("\\s+"), " ")?.trim()?.takeIf { it.isNotEmpty() }
        val last = blocks.lastOrNull()
        if (c == null && last?.kind == LKind.FIGURE) return            // several pictures in a row: one note
        if (c != null && last?.kind == LKind.FIGURE && last.count == 0) blocks.removeAt(blocks.size - 1)
        val start = sents.size
        if (c != null) sents.add(LSent(c, ListenLayout.sayText(c)))
        blocks.add(LBlock(LKind.FIGURE, start, sents.size - start, c ?: "Picture"))
    }

    /** A table, read row by row with the column names (first row = column names). */
    fun table(rowsIn: List<List<String>>, rowByRow: Boolean) {
        val rows = rowsIn.map { r -> r.map { it.replace(Regex("\\s+"), " ").trim() } }.filter { r -> r.any { it.isNotEmpty() } }
        if (rows.isEmpty()) return
        val cols = rows.maxOf { it.size }
        if (!rowByRow || rows.size < 2 || cols < 2) {
            for (r in rows) text(LKind.PARA, r.filter { it.isNotEmpty() }.joinToString(", ").let { if (it.lastOrNull()?.let { c -> c in ".!?।" } == true) it else "$it." })
            return
        }
        val head = rows.first()
        blocks.add(LBlock(LKind.TABLE, sents.size, 0, head.joinToString(" · ")))
        for (r in rows.drop(1)) {
            val s0 = sents.size
            val first = r.getOrNull(0).orEmpty()
            val parts = r.drop(1).mapIndexedNotNull { i, v -> if (v.isBlank()) null else (head.getOrNull(i + 1)?.takeIf { h -> h.isNotBlank() }?.let { h -> "$h: $v" } ?: v) }
            val show = (first + "\n" + parts.joinToString(" · ")).trim()
            val say = (listOf(first) + parts).filter { p -> p.isNotBlank() }.joinToString(". ") { p -> p.trimEnd('.', ';', ',') } + "."
            if (show.isEmpty()) continue
            sents.add(LSent(show, ListenLayout.sayText(say)))
            blocks.add(LBlock(LKind.ROW, s0, 1))
        }
    }

    fun firstHeading(): String? = blocks.firstOrNull { it.kind == LKind.HEADING }?.let { sents[it.first].show }

    fun build(): LPage {
        // A table note with no rows after it is dropped.
        val keep = blocks.filterIndexed { i, b -> b.kind != LKind.TABLE || blocks.getOrNull(i + 1)?.kind == LKind.ROW }
        return LPage(ArrayList(sents), keep)
    }
}

/** A book ready for Listen: its pages (chapters or parts), contents, and what to call a page. */
data class ListenBook(val pages: List<LPage>, val chapters: List<OutlineEntry>, val unit: String)

/** Reads e-books (EPUB), Word (.docx) and text (.txt) files for Listen. Pure Kotlin, so it is tested off the phone. */
object ListenBooks {
    enum class Kind { PDF, EPUB, DOCX, TXT, ZIP, IMAGE }

    fun kindOf(name: String, mime: String?): Kind {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            ext == "epub" || mime == "application/epub+zip" -> Kind.EPUB
            ext == "zip" || mime == "application/zip" || mime == "application/x-zip-compressed" -> Kind.ZIP
            ext in setOf("jpg", "jpeg", "png", "webp") || mime?.startsWith("image/") == true -> Kind.IMAGE
            ext == "docx" || mime == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" -> Kind.DOCX
            ext == "txt" || ext == "text" || mime?.startsWith("text/plain") == true -> Kind.TXT
            else -> Kind.PDF
        }
    }

    // ------------------------------------------------------------------ a forgiving HTML / XML reader

    class Tag(val name: String, val attrs: Map<String, String>, val closing: Boolean, val selfClosing: Boolean)

    /** Walks markup, calling [onTag] for tags and [onText] for text (entities decoded). */
    fun walk(s: String, onTag: (Tag) -> Unit, onText: (String) -> Unit) {
        var i = 0
        val n = s.length
        while (i < n) {
            val lt = s.indexOf('<', i)
            if (lt < 0) { onText(decode(s.substring(i))); break }
            if (lt > i) onText(decode(s.substring(i, lt)))
            when {
                s.startsWith("<!--", lt) -> { val e = s.indexOf("-->", lt + 4); i = if (e < 0) n else e + 3 }
                s.startsWith("<![CDATA[", lt) -> { val e = s.indexOf("]]>", lt + 9); onText(s.substring(lt + 9, if (e < 0) n else e)); i = if (e < 0) n else e + 3 }
                s.startsWith("<!", lt) || s.startsWith("<?", lt) -> { val e = s.indexOf('>', lt); i = if (e < 0) n else e + 1 }
                else -> {
                    // Find the end of the tag, skipping ">" inside quoted attribute values.
                    var j = lt + 1
                    var q = 0.toChar()
                    while (j < n) {
                        val c = s[j]
                        if (q != 0.toChar()) { if (c == q) q = 0.toChar() }
                        else if (c == '"' || c == '\'') q = c
                        else if (c == '>') break
                        j++
                    }
                    val body = s.substring(lt + 1, minOf(j, n)).trim()
                    i = j + 1
                    if (body.isEmpty()) continue
                    val closing = body.startsWith("/")
                    val self = body.endsWith("/")
                    val inner = body.removePrefix("/").removeSuffix("/").trim()
                    val name = inner.takeWhile { !it.isWhitespace() }.substringAfter(':').lowercase()
                    onTag(Tag(name, if (closing) emptyMap() else attrs(inner.drop(name.length.coerceAtMost(inner.length))), closing, self))
                }
            }
        }
    }

    private val ATTR = Regex("([\\w:.-]+)\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))")
    private fun attrs(s: String): Map<String, String> {
        val m = HashMap<String, String>()
        for (a in ATTR.findAll(s)) {
            val k = a.groupValues[1].lowercase()
            val v = a.groups[3]?.value ?: a.groups[4]?.value ?: a.groupValues[5]
            m[k] = decode(v)
            m.putIfAbsent(k.substringAfter(':'), decode(v))
        }
        return m
    }

    private val NAMED = mapOf(
        "amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ", "mdash" to "—", "ndash" to "–",
        "hellip" to "…", "rsquo" to "’", "lsquo" to "‘", "rdquo" to "”", "ldquo" to "“", "copy" to "©", "reg" to "®", "deg" to "°",
        "times" to "×", "middot" to "·", "bull" to "•", "shy" to "", "zwj" to "\u200D", "zwnj" to "\u200C", "eacute" to "é", "rarr" to "→"
    )
    private val ENT = Regex("&(#x[0-9a-fA-F]+|#[0-9]+|[a-zA-Z]+);")
    fun decode(s: String): String = if ('&' !in s) s else ENT.replace(s) { m ->
        val e = m.groupValues[1]
        when {
            e.startsWith("#x") || e.startsWith("#X") -> e.drop(2).toIntOrNull(16)?.let { String(Character.toChars(it)) } ?: m.value
            e.startsWith("#") -> e.drop(1).toIntOrNull()?.let { String(Character.toChars(it)) } ?: m.value
            else -> NAMED[e] ?: NAMED[e.lowercase()] ?: m.value
        }
    }

    // ------------------------------------------------------------------ ZIP books (NCERT "complete book" downloads)

    private val READABLE = setOf("pdf", "epub", "docx", "txt", "jpg", "jpeg", "png", "webp")

    /** Front pages of an NCERT book ("hhml1ps.pdf") or files named like prelims / contents. */
    fun isFront(name: String): Boolean {
        val base = name.substringAfterLast('/').substringBeforeLast('.').lowercase()
        return Regex("\\dps$|^ps$|prelim|front ?matter|^contents?$|^index$|^cover$").containsMatchIn(base)
    }

    /** Sorts like a person would: "2" before "10"; front pages first. */
    val naturalOrder: Comparator<String> = Comparator { a, b ->
        val fa = isFront(a); val fb = isFront(b)
        if (fa != fb) return@Comparator if (fa) -1 else 1
        val ra = Regex("\\d+|\\D+").findAll(a.lowercase()).map { it.value }.toList()
        val rb = Regex("\\d+|\\D+").findAll(b.lowercase()).map { it.value }.toList()
        for (i in 0 until minOf(ra.size, rb.size)) {
            val x = ra[i]; val y = rb[i]
            val c = if (x[0].isDigit() && y[0].isDigit()) (x.toBigInteger().compareTo(y.toBigInteger())).let { if (it == 0) x.length - y.length else it } else x.compareTo(y)
            if (c != 0) return@Comparator c
        }
        ra.size - rb.size
    }

    /**
     * Unpacks the readable files of a ZIP (PDFs, e-books, Word, text, photos) into [dir],
     * in reading order. Folders inside the ZIP are kept in the names so order is right.
     */
    fun unzipBook(input: InputStream, dir: java.io.File): List<java.io.File> {
        dir.mkdirs()
        val out = ArrayList<java.io.File>()
        try {
            ZipInputStream(input).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    val name = e.name.replace('\\', '/')
                    val base = name.substringAfterLast('/')
                    if (e.isDirectory || name.startsWith("__MACOSX") || base.startsWith(".")) continue
                    if (base.substringAfterLast('.', "").lowercase() !in READABLE) continue
                    val safe = name.split('/').filter { it.isNotEmpty() && it != ".." }.joinToString("__")
                    val f = java.io.File(dir, safe)
                    f.outputStream().use { z.copyTo(it) }
                    out.add(f)
                }
            }
        } catch (e: java.util.zip.ZipException) {
            if (e.message?.contains("encrypt", true) == true) throw UserError("This ZIP has a password. Unzip it first, then open the files.")
            throw UserError("This ZIP can't be opened (it may be damaged or not fully downloaded).")
        }
        if (out.isEmpty()) throw UserError("No PDFs or books found in this ZIP.")
        return out.sortedWith(compareBy(naturalOrder) { it.name })
    }

    // ------------------------------------------------------------------ HTML chapter → blocks

    private val BLOCK_TAGS = setOf("p", "div", "section", "article", "blockquote", "li", "dt", "dd", "pre", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "td", "th", "table", "figcaption", "figure", "ul", "ol", "header", "footer", "aside", "nav", "body", "caption", "hr")
    private val SKIP_TAGS = setOf("head", "script", "style", "svg", "math", "title")

    /** Adds the readable parts of one HTML/XHTML chapter to [pb]. */
    fun html(s: String, pb: PageBuilder, prefs: ListenReadPrefs) {
        val buf = StringBuilder()
        var kind = LKind.PARA
        var skip = 0
        val lists = ArrayList<IntArray>()      // [ordered(1/0), counter]
        var table: ArrayList<MutableList<String>>? = null
        var tableDepth = 0
        var cell: StringBuilder? = null
        var inCaption = false
        var pendingPrefix = ""

        fun flush() {
            val t = buf.toString().replace(Regex("\\s+"), " ").trim()
            buf.setLength(0)
            if (t.isEmpty()) { pendingPrefix = ""; return }
            if (inCaption) pb.figure(t) else pb.text(kind, pendingPrefix + t)
            pendingPrefix = ""
        }
        walk(s, onTag = tag@{ t ->
            val n = t.name
            if (n in SKIP_TAGS) {
                if (n == "svg" && !t.closing && t.attrs.isNotEmpty()) pb.figure(null)
                if (!t.selfClosing) { if (t.closing) skip = (skip - 1).coerceAtLeast(0) else skip++ }
                return@tag
            }
            if (skip > 0) return@tag
            // Tables: collect cells, then read row by row.
            if (n == "table") {
                if (!t.closing) { if (tableDepth == 0) { flush(); table = ArrayList() }; tableDepth++ }
                else { tableDepth--; if (tableDepth == 0) { table?.let { pb.table(it, prefs.tableRows) }; table = null; cell = null } }
                return@tag
            }
            val tb = table
            if (tb != null && tableDepth == 1) {
                when (n) {
                    "tr" -> if (!t.closing) tb.add(ArrayList())
                    "td", "th" -> if (!t.closing) { if (tb.isEmpty()) tb.add(ArrayList()); cell = StringBuilder() }
                        else { cell?.let { c -> tb.last().add(c.toString().replace(Regex("\\s+"), " ").trim()) }; cell = null }
                    "br", "p", "div", "li" -> cell?.append(' ')
                }
                return@tag
            }
            if (tb != null) { if (n in BLOCK_TAGS || n == "br") cell?.append(' '); return@tag }
            when (n) {
                "img", "image" -> if (!t.closing) {
                    flush()
                    val alt = t.attrs["alt"]?.trim().orEmpty()
                    pb.figure(null)
                    if (alt.length > 3 && !alt.contains(".jpg", true) && !alt.contains(".png", true) && !alt.equals("image", true)) pb.figure("Picture: $alt")
                }
                "br" -> buf.append(' ')
                "ul", "ol" -> { flush(); if (!t.closing) lists.add(intArrayOf(if (n == "ol") 1 else 0, (t.attrs["start"]?.toIntOrNull() ?: 1) - 1)) else if (lists.isNotEmpty()) lists.removeAt(lists.size - 1) }
                "li" -> {
                    flush()
                    if (!t.closing) {
                        kind = LKind.POINT
                        val l = lists.lastOrNull()
                        pendingPrefix = if (l != null && l[0] == 1) { l[1]++; "${l[1]}. " } else "• "
                    } else kind = LKind.PARA
                }
                "h1", "h2", "h3", "h4", "h5", "h6" -> { flush(); kind = if (t.closing) LKind.PARA else LKind.HEADING }
                "figcaption", "caption" -> { flush(); inCaption = !t.closing }
                else -> if (n in BLOCK_TAGS) { flush(); if (t.closing && kind == LKind.HEADING) kind = LKind.PARA }
            }
        }, onText = { txt ->
            if (skip > 0) return@walk
            val c = cell
            if (table != null) { c?.append(txt); return@walk }
            buf.append(txt)
        })
        flush()
    }

    // ------------------------------------------------------------------ EPUB

    private fun unzip(input: InputStream, want: (String) -> Boolean): Map<String, ByteArray> {
        val out = HashMap<String, ByteArray>()
        ZipInputStream(input).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (!e.isDirectory && want(e.name)) {
                    val b = ByteArrayOutputStream()
                    z.copyTo(b)
                    out[e.name] = b.toByteArray()
                }
            }
        }
        return out
    }

    private fun resolve(base: String, href: String): String {
        val h = try { URLDecoder.decode(href.substringBefore('#').replace("+", "%2B"), "UTF-8") } catch (e: Exception) { href.substringBefore('#') }
        if (h.startsWith("/")) return h.drop(1)
        val parts = (if (base.isEmpty()) emptyList() else base.split('/')).toMutableList()
        for (p in h.split('/')) when (p) { "", "." -> {}; ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1); else -> parts.add(p) }
        return parts.joinToString("/")
    }

    private fun text(b: ByteArray?): String {
        if (b == null) return ""
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return String(b, Charsets.UTF_16LE).drop(1)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return String(b, Charsets.UTF_16BE).drop(1)
        return String(b, Charsets.UTF_8).removePrefix("\uFEFF")
    }

    fun epub(input: InputStream, prefs: ListenReadPrefs): ListenBook {
        val files = unzip(input) { n -> val l = n.lowercase(); l.endsWith(".xhtml") || l.endsWith(".html") || l.endsWith(".htm") || l.endsWith(".opf") || l.endsWith(".ncx") || l.endsWith(".xml") }
        val container = text(files["META-INF/container.xml"])
        var opfPath: String? = null
        walk(container, { t -> if (t.name == "rootfile" && opfPath == null) opfPath = t.attrs["full-path"] }, {})
        val opf = opfPath ?: files.keys.firstOrNull { it.endsWith(".opf", true) } ?: throw UserError("This e-book can't be opened (it may be damaged).")
        val opfDir = opf.substringBeforeLast('/', "")
        val manifest = HashMap<String, Pair<String, String>>()   // id -> (path, media type)
        val props = HashMap<String, String>()
        val spine = ArrayList<String>()
        var ncxId: String? = null
        var encrypted = false
        walk(text(files[opf]), { t ->
            when (t.name) {
                "item" -> { val id = t.attrs["id"] ?: return@walk; val href = t.attrs["href"] ?: return@walk
                    manifest[id] = resolve(opfDir, href) to (t.attrs["media-type"] ?: ""); t.attrs["properties"]?.let { props[id] = it } }
                "itemref" -> if (!t.closing && t.attrs["linear"] != "no") t.attrs["idref"]?.let { spine.add(it) }
                "spine" -> if (!t.closing) ncxId = t.attrs["toc"]
            }
        }, {})
        if (files.keys.any { it.equals("META-INF/encryption.xml", true) }) encrypted = true
        // Contents: EPUB 3 nav page, or the older toc.ncx.
        val titles = LinkedHashMap<String, String>()
        val navId = props.entries.firstOrNull { it.value.split(' ').contains("nav") }?.key
        if (navId != null) {
            val path = manifest[navId]?.first
            val dir = path?.substringBeforeLast('/', "") ?: ""
            var inToc = false; var href: String? = null; val sb = StringBuilder()
            walk(text(files[path]), { t ->
                if (t.name == "nav") { if (!t.closing) inToc = (t.attrs["type"] ?: "toc").contains("toc") || navId != null && t.attrs["type"] == null else inToc = false }
                if (inToc && t.name == "a") { if (!t.closing) { href = t.attrs["href"]; sb.setLength(0) } else { href?.let { h -> titles.putIfAbsent(resolve(dir, h), sb.toString().replace(Regex("\\s+"), " ").trim()) }; href = null } }
            }, { s -> if (href != null) sb.append(s) })
        }
        if (titles.isEmpty()) {
            val path = ncxId?.let { manifest[it]?.first } ?: files.keys.firstOrNull { it.endsWith(".ncx", true) }
            val dir = path?.substringBeforeLast('/', "") ?: ""
            var label = StringBuilder(); var inText = false
            walk(text(files[path]), { t ->
                when (t.name) {
                    "navlabel" -> if (!t.closing) label = StringBuilder()
                    "text" -> inText = !t.closing
                    "content" -> t.attrs["src"]?.let { src -> titles.putIfAbsent(resolve(dir, src), label.toString().replace(Regex("\\s+"), " ").trim()) }
                }
            }, { s -> if (inText) label.append(s) })
        }
        val pages = ArrayList<LPage>()
        val chapters = ArrayList<OutlineEntry>()
        for (id in spine) {
            val (path, type) = manifest[id] ?: continue
            if (!(type.contains("html") || path.endsWith("html", true) || path.endsWith(".htm", true))) continue
            val pb = PageBuilder()
            html(text(files[path]), pb, prefs)
            if (pb.isEmpty) continue
            val title = titles[path]?.takeIf { it.isNotBlank() } ?: pb.firstHeading()
            if (title != null) chapters.add(OutlineEntry(title.take(80), pages.size, 0))
            pages.add(pb.build())
        }
        if (pages.isEmpty()) {
            if (encrypted) throw UserError("This e-book is locked (DRM), so only the store's own app can open it.")
            throw UserError("No text found in this e-book to read aloud.")
        }
        return ListenBook(pages, chapters, "Part")
    }

    // ------------------------------------------------------------------ Word (.docx)

    private val HEADING_STYLE = Regex("(?i)^(heading|title|berschrift|titre|titolo|h)\\s*\\d*$|^(heading|title)")

    fun docx(input: InputStream, prefs: ListenReadPrefs): ListenBook {
        val files = unzip(input) { it == "word/document.xml" }
        val xml = text(files["word/document.xml"]).ifEmpty { throw UserError("This Word file can't be opened (it may be damaged).") }
        val pages = ArrayList<LPage>()
        val chapters = ArrayList<OutlineEntry>()
        var pb = PageBuilder()
        val para = StringBuilder()
        var style = ""
        var numbered = false
        var outline = -1
        var tableDepth = 0
        val rows = ArrayList<MutableList<String>>()
        var cell: StringBuilder? = null
        var inText = false
        fun newPage() { if (!pb.isEmpty) { pages.add(pb.build()); pb = PageBuilder() } }
        fun endPara() {
            val t = para.toString().replace(Regex("\\s+"), " ").trim()
            para.setLength(0)
            if (t.isEmpty()) return
            val heading = HEADING_STYLE.containsMatchIn(style) || outline in 0..2
            val big = heading && (style.contains("1") || style.equals("title", true) || outline == 0)
            if (big) { newPage(); chapters.add(OutlineEntry(t.take(80), pages.size, 0)) }
            else if (pb.blockCount > 60) newPage()
            pb.text(if (heading) LKind.HEADING else if (numbered) LKind.POINT else LKind.PARA, if (numbered && !heading) "• $t" else t)
        }
        walk(xml, { t ->
            when (t.name) {
                "p" -> if (!t.closing) { para.setLength(0); style = ""; numbered = false; outline = -1 } else {
                    if (tableDepth > 0) { cell?.append(para)?.append(' '); para.setLength(0) } else endPara()
                }
                "pstyle" -> { style = t.attrs["val"] ?: ""; if (style.contains("list", true) || style.contains("bullet", true)) numbered = true }
                "numpr" -> if (!t.closing) numbered = true
                "outlinelvl" -> outline = t.attrs["val"]?.toIntOrNull() ?: -1
                "t" -> inText = !t.closing && !t.selfClosing
                "tab", "br", "cr" -> para.append(' ')
                "tbl" -> if (!t.closing) { if (tableDepth == 0) rows.clear(); tableDepth++ } else { tableDepth--; if (tableDepth == 0) { pb.table(rows.map { it.toList() }, prefs.tableRows); rows.clear() } }
                "tr" -> if (!t.closing && tableDepth == 1) rows.add(ArrayList())
                "tc" -> if (tableDepth == 1) { if (!t.closing) cell = StringBuilder() else { cell?.let { c -> if (rows.isEmpty()) rows.add(ArrayList()); rows.last().add(c.toString().trim()) }; cell = null } }
            }
        }, { s -> if (inText) para.append(s) })
        newPage()
        if (pages.isEmpty()) throw UserError("No text found in this Word file to read aloud.")
        return ListenBook(pages, chapters, "Part")
    }

    // ------------------------------------------------------------------ plain text (.txt)

    private val CHAPTER_LINE = Regex("^(chapter|chap\\.|part|book|section|lesson|unit|अध्याय|पाठ|भाग|इकाई)\\b.{0,60}$|^[IVXLC]{1,7}\\.?$|^\\d{1,3}\\.\\s+\\S.{0,50}$", RegexOption.IGNORE_CASE)

    fun txtDecode(b: ByteArray): String {
        if (b.size >= 2 && (b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte() || b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())) return text(b)
        val dec = Charsets.UTF_8.newDecoder()
        return try { dec.decode(java.nio.ByteBuffer.wrap(b)).toString().removePrefix("\uFEFF") } catch (e: Exception) { String(b, Charsets.ISO_8859_1) }
    }

    fun txt(raw: String, prefs: ListenReadPrefs): ListenBook {
        var s = raw.replace("\r\n", "\n").replace('\r', '\n')
        // Project Gutenberg books: keep only the book between the START and END lines.
        Regex("\\*\\*\\* ?START OF (THE|THIS) PROJECT GUTENBERG[^\\n]*\\n", RegexOption.IGNORE_CASE).find(s)?.let { s = s.substring(it.range.last + 1) }
        Regex("\\n[^\\n]*\\*\\*\\* ?END OF (THE|THIS) PROJECT GUTENBERG", RegexOption.IGNORE_CASE).find(s)?.let { s = s.substring(0, it.range.first) }
        val hasBlank = Regex("\\n[ \\t]*\\n").containsMatchIn(s)
        val paras: List<List<String>> = if (hasBlank) s.split(Regex("\\n[ \\t]*\\n")).map { p -> p.split('\n').map { it.trim() }.filter { it.isNotEmpty() } }
            else s.split('\n').map { listOf(it.trim()) }
        val pages = ArrayList<LPage>()
        val chapters = ArrayList<OutlineEntry>()
        var pb = PageBuilder()
        fun newPage() { if (!pb.isEmpty) { pages.add(pb.build()); pb = PageBuilder() } }
        for (p in paras) {
            if (p.isEmpty()) continue
            val one = p.size == 1 && p[0].length <= 70 && p[0].lastOrNull()?.let { it in ".,;:!?।\"”'" } != true
            val chapter = one && (CHAPTER_LINE.matches(p[0]) || (p[0].length > 3 && p[0] == p[0].uppercase() && p[0].any { it.isLetter() } && p[0].any { it in 'A'..'Z' }))
            if (chapter) {
                newPage()
                chapters.add(OutlineEntry(p[0].take(80), pages.size, 0))
                pb.text(LKind.HEADING, p[0])
                continue
            }
            if (pb.blockCount > 60) newPage()
            val first = p[0]
            val kind = if (Regex("^([•●▪\\-*]|\\d{1,2}[.)])\\s+").containsMatchIn(first)) LKind.POINT else if (one && p[0].length < 50) LKind.HEADING else LKind.PARA
            if (kind == LKind.POINT && p.size > 1 && p.drop(1).all { Regex("^([•●▪\\-*]|\\d{1,2}[.)])\\s+").containsMatchIn(it) }) p.forEach { pb.text(LKind.POINT, it) }
            else pb.text(kind, ListenLayout.joinLines(p))
        }
        newPage()
        if (pages.isEmpty()) throw UserError("This text file is empty.")
        return ListenBook(pages, chapters, "Part")
    }
}
