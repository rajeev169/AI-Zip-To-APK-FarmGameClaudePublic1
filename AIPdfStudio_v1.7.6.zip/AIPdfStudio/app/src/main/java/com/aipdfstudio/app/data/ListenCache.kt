package com.aipdfstudio.app.data

import java.io.File

/**
 * Keeps prepared Listen pages on the phone (OCR is slow, so a page is read only once).
 * Pages are stored in a small text format; pure Kotlin so it is tested off the phone.
 */
object ListenCache {
    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t")
    private fun unesc(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) { 'n' -> sb.append('\n'); 't' -> sb.append('\t'); else -> sb.append(s[i + 1]) }
                i += 2
            } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    fun encode(p: LPage): String = buildString {
        append("LP1\n")
        for (s in p.sentences) append("S\t").append(esc(s.show)).append('\t').append(esc(s.say)).append('\n')
        for (b in p.blocks) append("B\t").append(b.kind.name).append('\t').append(b.first).append('\t').append(b.count).append('\t').append(esc(b.label ?: "\u0000")).append('\n')
        for (k in p.skipped) append("K\t").append(esc(k)).append('\n')
    }

    fun decode(s: String): LPage? {
        val lines = s.split('\n')
        if (lines.firstOrNull() != "LP1") return null
        val sents = ArrayList<LSent>(); val blocks = ArrayList<LBlock>(); val skipped = ArrayList<String>()
        for (l in lines.drop(1)) {
            if (l.isEmpty()) continue
            val f = l.split('\t')
            when (f[0]) {
                "S" -> if (f.size >= 3) sents.add(LSent(unesc(f[1]), unesc(f[2])))
                "B" -> if (f.size >= 5) {
                    val kind = try { LKind.valueOf(f[1]) } catch (e: Exception) { return null }
                    blocks.add(LBlock(kind, f[2].toIntOrNull() ?: return null, f[3].toIntOrNull() ?: return null, unesc(f[4]).takeIf { it != "\u0000" }))
                }
                "K" -> if (f.size >= 2) skipped.add(unesc(f[1]))
            }
        }
        if (blocks.any { it.first + it.count > sents.size }) return null
        return LPage(sents, blocks, skipped = skipped)
    }

    fun read(f: File): LPage? = try { if (f.isFile) decode(f.readText()) else null } catch (e: Exception) { null }

    fun write(f: File, p: LPage) {
        try { f.parentFile?.mkdirs(); val t = File(f.path + ".tmp"); t.writeText(encode(p)); t.renameTo(f) } catch (ignored: Exception) {}
    }

    /** A short, stable name for a file or a set of files (for cache folders and saved positions). */
    fun key(vararg parts: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-1")
        parts.forEach { md.update(it.toByteArray()); md.update(0) }
        return md.digest().take(10).joinToString("") { "%02x".format(it) }
    }
}
