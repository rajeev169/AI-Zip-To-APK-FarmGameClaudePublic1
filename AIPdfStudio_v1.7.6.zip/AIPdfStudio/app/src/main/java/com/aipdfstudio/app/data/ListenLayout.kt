package com.aipdfstudio.app.data

import android.graphics.Path
import android.graphics.PointF
import com.tom_roush.pdfbox.contentstream.PDFGraphicsStreamEngine
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImage
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** What kind of thing a block on a Listen page is. */
enum class LKind { HEADING, PARA, POINT, FIGURE, TABLE, ROW }

/** One thing read aloud: [show] is what the screen shows, [say] what the voice reads. */
data class LSent(val show: String, val say: String)

/** A block of the page (a heading, a paragraph, a point, a figure, a table row) and its sentences. */
data class LBlock(val kind: LKind, val first: Int, val count: Int, val label: String? = null)

/** One page ready for listening. */
data class LPage(
    val sentences: List<LSent>,
    val blocks: List<LBlock>,
    val needsOcr: Boolean = false,
    /** What was left out on purpose (header, footer, page number, watermark), shown as a small note. */
    val skipped: List<String> = emptyList(),
    /** Not read yet (it is prepared when the voice gets near it, or when the student jumps to it). */
    val pending: Boolean = false
) {
    val says: List<String> get() = sentences.map { it.say }
    val text: String get() = sentences.joinToString(" ") { it.say }
}

/** The switches under "What to read". */
data class ListenReadPrefs(val skipNumbers: Boolean = true, val skipFigures: Boolean = true, val tableRows: Boolean = true)

/**
 * Turns a PDF page into headings, paragraphs, points, figures and table rows for Listen.
 * Uses where text and drawings sit on the page, so it can tell diagram labels, tables and
 * page numbers apart from the text a student wants to hear.
 */
object ListenLayout {

    // ------------------------------------------------------------------ text with positions

    private class Glyph(val s: String, val x: Float, val y: Float, val w: Float, val size: Float, val bold: Boolean)

    class Line(val text: String, val l: Float, val t: Float, val r: Float, val b: Float, val size: Float, val bold: Boolean, val chunks: List<Chunk>, val words: List<Chunk> = chunks) {
        val h get() = b - t
        val cx get() = (l + r) / 2
        val cy get() = (t + b) / 2
    }

    class Chunk(val text: String, val l: Float, val r: Float)

    /** PDFBox text with /ActualText honoured (the real letters behind special-shaped glyphs). */
    private class Collector(private val rot: Int) : PDFTextStripper() {
        val glyphs = ArrayList<Glyph>()
        /** Letters the PDF maps to control codes: a sign its text layer is damaged. */
        var damaged = 0
        private val actual = ArrayList<String?>()
        private var actualUsed = false
        private val replace = IdentityHashMap<TextPosition, String>()

        init {
            // The text reader skips marked content by default; it is needed for /ActualText.
            addOperator(com.tom_roush.pdfbox.contentstream.operator.markedcontent.BeginMarkedContentSequenceWithProperties())
            addOperator(com.tom_roush.pdfbox.contentstream.operator.markedcontent.BeginMarkedContentSequence())
            addOperator(com.tom_roush.pdfbox.contentstream.operator.markedcontent.EndMarkedContentSequence())
        }

        override fun beginMarkedContentSequence(tag: COSName?, properties: COSDictionary?) {
            val a = properties?.getString(COSName.getPDFName("ActualText"))
            actual.add(a)
            if (a != null) actualUsed = false
            super.beginMarkedContentSequence(tag, properties)
        }

        override fun endMarkedContentSequence() {
            if (actual.isNotEmpty()) actual.removeAt(actual.size - 1)
            super.endMarkedContentSequence()
        }

        override fun processTextPosition(text: TextPosition) {
            val a = actual.lastOrNull { it != null }
            if (a != null) {
                replace[text] = if (!actualUsed) a else ""
                actualUsed = true
            }
            super.processTextPosition(text)
        }

        override fun writeString(text: String?, positions: MutableList<TextPosition>?) {
            if (positions.isNullOrEmpty()) return
            for (p in positions) {
                // Rotated text (vertical labels, watermarks) is left out.
                if (((p.dir.toInt() - rot) % 360 + 360) % 360 != 0) continue
                val u = (replace[p] ?: p.unicode ?: continue)
                if (u.any { it.code in 1..31 && it != '\t' && it != '\n' && it != '\r' }) damaged++
                val clean = cleanChars(u)
                if (clean.isEmpty() && u.isNotEmpty() && replace[p] == null) continue
                val fs = p.fontSizeInPt.takeIf { it > 0f } ?: p.heightDir
                val name = p.font?.name.orEmpty()
                val bold = name.contains("Bold", true) || name.contains("Black", true) || name.contains("Heavy", true) ||
                    name.contains("Semibold", true) || name.contains("SemiBold") || (p.font?.fontDescriptor?.isForceBold == true) ||
                    ((p.font?.fontDescriptor?.fontWeight ?: 0f) >= 600f)
                glyphs.add(Glyph(clean, p.x, p.y, max(p.width, 0f), fs, bold))
            }
            glyphs.add(Glyph(" ", Float.NaN, Float.NaN, 0f, 0f, false))   // word break
        }
    }

    /** Removes letters from the private-use area (fonts' special shapes with no real letter behind them). */
    fun cleanChars(s: String): String = buildString {
        for (c in s) {
            val code = c.code
            if (code in 0xE000..0xF8FF || code == 0xFFFD || code == 0xAD || code in 0..31) continue
            append(c)
        }
    }

    private fun deva(s: String) = s.any { it.code in 0x0900..0x097F }

    private fun lines(g: List<Glyph>): List<Line> {
        val out = ArrayList<Line>()
        var cur = ArrayList<Glyph>()
        var pendingSpace = false
        fun flush() {
            if (cur.isEmpty()) return
            val size = cur.maxOf { it.size }
            // Split the line into chunks at wide gaps (table columns, labels side by side).
            val chunks = ArrayList<Chunk>()
            val sb = StringBuilder(); var cl = cur[0].x; var cr = cur[0].x
            val all = StringBuilder()
            val words = ArrayList<Chunk>()
            val wb = StringBuilder(); var wl = cur[0].x; var wr = cur[0].x
            fun endWord() { if (wb.isNotBlank()) words.add(Chunk(wb.toString().trim(), wl, wr)); wb.setLength(0) }
            var prev: Glyph? = null
            var right = -Float.MAX_VALUE
            for (x in cur) {
                if (prev != null) {
                    // Measured from the furthest right edge so far: vowel signs often have no width.
                    val gap = x.x - max(right, prev.x + prev.w)
                    if (gap > size * 1.1f) {
                        chunks.add(Chunk(sb.toString().trim(), cl, cr)); sb.setLength(0); cl = x.x
                        all.append("  ")
                        endWord()
                    } else if (x.s == " ") {
                        endWord()
                    } else if (gap > size * (if (deva(prev.s) && deva(x.s)) 0.3f else 0.12f) && !prev.s.endsWith('\u094D') && sb.isNotEmpty() && sb.last() != ' ' && x.s.firstOrNull() != ' ') {
                        sb.append(' '); all.append(' ')
                        endWord()
                    }
                }
                if (x.s != " ") { if (wb.isEmpty()) wl = x.x; wb.append(x.s); wr = x.x + x.w }
                sb.append(x.s); all.append(x.s); cr = max(cr, x.x + x.w)
                if (x.s != " ") right = max(right, x.x + x.w)
                prev = x
            }
            endWord()
            chunks.add(Chunk(sb.toString().trim(), cl, cr))
            val text = all.toString().replace(Regex("[ \\t]+"), " ").trim()
            if (text.isNotEmpty()) {
                val boldChars = cur.count { it.bold && it.s.isNotBlank() }
                val chars = cur.count { it.s.isNotBlank() }.coerceAtLeast(1)
                out.add(Line(
                    text, cur.minOf { it.x }, cur.minOf { it.y - it.size * 0.8f }, cur.maxOf { it.x + it.w }, cur.maxOf { it.y + it.size * 0.22f },
                    size, boldChars * 2 > chars, chunks.filter { it.text.isNotEmpty() }, words
                ))
            }
            cur = ArrayList()
        }
        for (x in g) {
            if (x.x.isNaN() || x.s == " ") { pendingSpace = true; continue }
            if (x.s.isEmpty()) { if (cur.isNotEmpty()) cur.add(x); continue }   // no letter, but it takes up room
            if (cur.isNotEmpty()) {
                val last = cur.last()
                val sameLine = abs(x.y - last.y) <= max(x.size, last.size) * 0.45f
                if (!sameLine || x.x < last.x - last.size * 2) flush()
                else if (pendingSpace && x.s != " " && last.s != " ") {
                    // The text reader guesses word breaks; in Hindi it often guesses wrong inside a
                    // word (vowel signs have no width), so check the real gap there.
                    val right = cur.takeLast(5).maxOf { it.x + it.w }
                    val lastLetter = cur.lastOrNull { it.s.isNotEmpty() }?.s.orEmpty()
                    val hindi = deva(lastLetter) || deva(x.s)
                    val real = !hindi || (x.x - right > x.size * 0.15f && !lastLetter.endsWith('\u094D'))
                    if (real) cur.add(Glyph(" ", last.x + last.w, last.y, 0f, last.size, last.bold))
                }
            }
            pendingSpace = false
            if (x.s == " " && cur.isEmpty()) continue
            cur.add(x)
        }
        flush()
        return out
    }

    // ------------------------------------------------------------------ drawings (figures)

    class Shape(val l: Float, val t: Float, val r: Float, val b: Float, val curved: Boolean, val image: Boolean)

    private class Drawings(page: PDPage, private val toDisp: (Float, Float) -> FloatArray) : PDFGraphicsStreamEngine(page) {
        val shapes = ArrayList<Shape>()
        private var minX = Float.MAX_VALUE; private var minY = Float.MAX_VALUE
        private var maxX = -Float.MAX_VALUE; private var maxY = -Float.MAX_VALUE
        private var curved = false
        private var cur = PointF(0f, 0f)

        private fun add(x: Float, y: Float) {
            val d = toDisp(x, y)
            minX = min(minX, d[0]); maxX = max(maxX, d[0]); minY = min(minY, d[1]); maxY = max(maxY, d[1])
        }
        private fun reset() { minX = Float.MAX_VALUE; minY = Float.MAX_VALUE; maxX = -Float.MAX_VALUE; maxY = -Float.MAX_VALUE; curved = false }
        private fun emit() {
            if (minX <= maxX) shapes.add(Shape(minX, minY, maxX, maxY, curved, false))
            reset()
        }

        override fun appendRectangle(p0: PointF, p1: PointF, p2: PointF, p3: PointF) { add(p0.x, p0.y); add(p1.x, p1.y); add(p2.x, p2.y); add(p3.x, p3.y); cur = p0 }
        override fun moveTo(x: Float, y: Float) { add(x, y); cur = PointF(x, y) }
        override fun lineTo(x: Float, y: Float) { add(x, y); cur = PointF(x, y) }
        override fun curveTo(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) { add(x1, y1); add(x2, y2); add(x3, y3); curved = true; cur = PointF(x3, y3) }
        override fun getCurrentPoint(): PointF = cur
        override fun closePath() {}
        override fun endPath() { reset() }
        override fun strokePath() { emit() }
        override fun fillPath(windingRule: Path.FillType?) { emit() }
        override fun fillAndStrokePath(windingRule: Path.FillType?) { emit() }
        override fun clip(windingRule: Path.FillType?) {}
        override fun shadingFill(shadingName: COSName?) {}
        override fun drawImage(pdImage: PDImage?) {
            val m = graphicsState.currentTransformationMatrix
            val pts = listOf(0f to 0f, 1f to 0f, 0f to 1f, 1f to 1f).map { (u, v) -> toDisp(m.scaleX * u + m.shearX * v + m.translateX, m.shearY * u + m.scaleY * v + m.translateY) }
            shapes.add(Shape(pts.minOf { it[0] }, pts.minOf { it[1] }, pts.maxOf { it[0] }, pts.maxOf { it[1] }, false, true))
        }
        // Text drawn as glyphs is not a drawing.
        override fun showTextString(string: ByteArray?) {}
        override fun showTextStrings(array: com.tom_roush.pdfbox.cos.COSArray?) {}
    }

    class Region(val l: Float, val t: Float, val r: Float, val b: Float) {
        fun contains(x: Float, y: Float) = x in l..r && y in t..b
    }

    /** Areas of the page that hold a diagram or picture. */
    fun figures(shapes: List<Shape>, pw: Float, ph: Float): List<Region> {
        val pageArea = pw * ph
        // Drawings that make up pictures: curves and images. Straight lines and boxes are left out
        // (table borders, underlines, frames), and so are page-sized backgrounds.
        val parts = shapes.filter { s ->
            val a = (s.r - s.l) * (s.b - s.t)
            a < pageArea * 0.6f && (s.curved || (s.image && a > pageArea * 0.01f)) && (s.r - s.l) < pw * 0.98f
        }
        // Group nearby parts.
        val groups = ArrayList<MutableList<Shape>>()
        val pad = min(pw, ph) * 0.02f
        for (s in parts) {
            val hit = groups.filter { g -> g.any { o -> s.l - pad <= o.r && o.l - pad <= s.r && s.t - pad <= o.b && o.t - pad <= s.b } }
            if (hit.isEmpty()) groups.add(mutableListOf(s))
            else {
                val merged = hit.flatten().toMutableList().also { it.add(s) }
                groups.removeAll(hit.toSet()); groups.add(merged)
            }
        }
        val out = ArrayList<Region>()
        for (g in groups) {
            val l = g.minOf { it.l }; val t = g.minOf { it.t }; val r = g.maxOf { it.r }; val b = g.maxOf { it.b }
            val area = (r - l) * (b - t)
            val picture = g.any { it.image } || g.size >= 6
            if (picture && area > pageArea * 0.01f) out.add(Region(l, t, r, b))
        }
        return out
    }

    // ------------------------------------------------------------------ page → blocks

    private val PAGE_NUM = Regex("^(page|pg\\.?|पृष्ठ)?\\s*[-–—(]?\\s*\\d{1,4}\\s*[-–—)]?\\s*((/|of|से|का)\\s*\\d{1,4})?$", RegexOption.IGNORE_CASE)
    private val BULLET = Regex("^([•●▪◦‣■□➢►✓\\-–*]|\\(?\\d{1,2}[.)]|\\(?[a-hA-H][.)]|\\(?[ivx]{1,4}[.)])\\s+")
    private val REPRINT = Regex("(?i)^(reprint|first edition|reprinted)\\s+\\d{4}")
    private val WATERMARK = Regex("(?i)not to be republished|©\\s*NCERT|do not copy|for review only")
    private val PRINTER = Regex("(?i)\\.indd\\b|\\b\\d{1,2}-\\d{1,2}-\\d{4}\\s+\\d{1,2}[.:]\\d{2}")
    private val CAPTION = Regex("^(figure|fig\\.?|diagram|चित्र|आकृति)\\s*\\d", RegexOption.IGNORE_CASE)

    /** The page's lines (for tests). */
    fun debugLines(doc: PDDocument, index: Int): List<Line> {
        val c = Collector(((doc.getPage(index).rotation % 360) + 360) % 360)
        c.sortByPosition = true; c.startPage = index + 1; c.endPage = index + 1; c.getText(doc)
        return lines(c.glyphs)
    }

    var lastDamaged = 0

    fun read(doc: PDDocument, index: Int, prefs: ListenReadPrefs): LPage {
        val page = doc.getPage(index)
        val box = page.cropBox
        val pm = PageMath(box.lowerLeftX, box.lowerLeftY, box.width, box.height, page.rotation)
        val c = Collector(pm.rot)
        c.sortByPosition = true
        c.startPage = index + 1
        c.endPage = index + 1
        c.getText(doc)
        val ls = lines(c.glyphs)
        val llx = box.lowerLeftX; val lly = box.lowerLeftY; val w = box.width; val h = box.height
        val toDisp: (Float, Float) -> FloatArray = { x, y ->
            when (pm.rot) {
                90 -> floatArrayOf(y - lly, x - llx)
                180 -> floatArrayOf(llx + w - x, y - lly)
                270 -> floatArrayOf(lly + h - y, llx + w - x)
                else -> floatArrayOf(x - llx, lly + h - y)
            }
        }
        val figs = if (prefs.skipFigures && ls.isNotEmpty()) {
            try {
                val d = Drawings(page, toDisp); d.processPage(page); figures(d.shapes, pm.dispW, pm.dispH)
            } catch (e: Throwable) { emptyList() }
        } else emptyList()
        val built = build(ls, figs, pm.dispW, pm.dispH, prefs)
        val text = built.text
        lastDamaged = c.damaged
        val broken = ListenText.isHindi(text) && (c.damaged >= 3 || looksBrokenHindi(text))
        return if (broken) built.copy(needsOcr = true) else built
    }

    private class Item(val kind: LKind, val top: Float, val texts: List<String>, val label: String? = null, val rows: List<List<String>>? = null)

    fun build(all: List<Line>, figs: List<Region>, pw: Float, ph: Float, prefs: ListenReadPrefs): LPage {
        // Stray marks (a lone letter or symbol) are never read.
        var lines = all.filter { l -> l.text.trim().let { t -> t.length >= 2 || t.any { it.isDigit() } } }
        val skipped = LinkedHashSet<String>()
        if (prefs.skipNumbers) {
            val sorted = lines.sortedBy { it.t }
            lines = lines.filterNot { l ->
                val t = l.text.trim()
                val words = t.split(Regex("\\s+")).size
                val above = sorted.lastOrNull { it.b <= l.t + 1f && it !== l }
                val below = sorted.firstOrNull { it.t >= l.b - 1f && it !== l }
                val aloneBelow = above == null || l.t - above.b > l.h * 1.2f
                val aloneAbove = below == null || below.t - l.b > l.h * 1.2f
                val bottom = l.t > ph * 0.9f && aloneBelow
                val top = l.b < ph * 0.08f && aloneAbove
                val reason = when {
                    WATERMARK.containsMatchIn(t) -> "watermark"
                    REPRINT.containsMatchIn(t) -> "footer “${t.take(30)}”"
                    PRINTER.containsMatchIn(t) -> "printer marks"
                    (bottom || top) && PAGE_NUM.matches(t) -> "page number"
                    bottom && words <= 5 && t.length <= 40 -> "footer “${t.take(30)}”"
                    top && words <= 4 && t.length <= 40 -> "header “${t.take(30)}”"
                    else -> null
                }
                if (reason != null) skipped.add(reason)
                reason != null
            }
        }
        if (lines.isEmpty()) return LPage(emptyList(), emptyList(), skipped = skipped.toList())
        val body = median(lines.flatMap { l -> List(l.text.length.coerceAtMost(200)) { l.size } })

        val items = ArrayList<Item>()
        // Blocks keep the reading order of the lines (columns are read one after the other);
        // a figure goes where the first line below it starts.
        val order = java.util.IdentityHashMap<Line, Int>().also { m -> lines.forEachIndexed { i, l -> m[l] = i } }
        fun orderAt(top: Float): Float = (lines.indexOfFirst { it.t >= top }.let { if (it < 0) lines.size else it }) - 0.5f
        // Diagrams: their labels are skipped, the caption (if any) is read.
        val usedCaption = HashSet<Line>()
        val inFig = HashSet<Line>()
        for (f in figs) {
            val all = lines.filter { l -> f.contains(l.cx, l.cy) && !CAPTION.containsMatchIn(l.text) }
            // Text printed over a picture (a poem on an illustrated page) is real text, not labels.
            val wordy = all.count { l -> l.chunks.any { c -> val n = wordCount(c.text); n >= 7 || n >= 4 && c.text.trimEnd().lastOrNull()?.let { it in ",.;?!।॥" } == true } }
            if (wordy >= 2) continue
            // Only short labels ("Xylem", "Vascular bundles in a ring") are skipped, also when several sit on one line.
            val inside = all.filter { l -> l.chunks.all { c -> wordCount(c.text) <= 5 && c.text.length <= 40 } }
            val near = lines.filter { l -> l !in inside && CAPTION.containsMatchIn(l.text) && (abs(l.t - f.b) < ph * 0.05f || abs(f.t - l.b) < ph * 0.05f) }
                .minByOrNull { l -> min(abs(l.t - f.b), abs(f.t - l.b)) }
            var cap: String? = null
            if (near != null) {
                // A caption can run over two lines.
                val capLines = arrayListOf(near)
                lines.filter { it !in inside && it != near && it.t > near.t && it.t - capLines.last().b < near.h * 0.6f && abs(it.size - near.size) < 0.6f && !CAPTION.containsMatchIn(it.text) }
                    .sortedBy { it.t }.forEach { if (it.t - capLines.last().b < near.h * 0.6f) capLines.add(it) }
                usedCaption.addAll(capLines)
                cap = capLines.joinToString(" ") { it.text }
            }
            // A picture without labels or caption (decoration) gets no note.
            if (inside.isEmpty() && cap == null) continue
            inFig.addAll(inside)
            items.add(Item(LKind.FIGURE, orderAt(f.t), listOfNotNull(cap), label = cap ?: "Diagram"))
        }
        val rest = lines.filter { it !in inFig && it !in usedCaption }

        // Tables: rows with 2+ columns that line up, read row by row.
        val tableLines = HashSet<Line>()
        if (prefs.tableRows) for (t in tables(rest)) {
            tableLines.addAll(t.lines)
            items.add(Item(LKind.TABLE, (order[t.lines.first()] ?: 0).toFloat(), emptyList(), rows = t.rows))
        }
        val text = rest.filter { it !in tableLines }

        // Headings, points and paragraphs.
        var cur = ArrayList<Line>()
        var curKind = LKind.PARA
        fun flush() {
            if (cur.isEmpty()) return
            val joined = joinLines(cur.map { it.text })
            items.add(Item(curKind, (order[cur.first()] ?: 0).toFloat(), listOf(joined)))
            cur = ArrayList()
        }
        // Right edge of full lines, to spot short lines (list items without bullets, last lines).
        // Usual space between lines of one paragraph (OCR line boxes vary in height, so this is
        // measured instead of assumed).
        val medGap = text.zipWithNext { a, b -> b.t - a.b }.filter { it > 0f && it < 2.5f * body }.sorted().let { g -> if (g.isEmpty()) 0f else g[g.size / 2] }
        val colRight = text.map { it.r }.sorted().let { r -> if (r.isEmpty()) pw else r[(r.size * 0.9f).toInt().coerceAtMost(r.size - 1)] }
        var prev: Line? = null
        for (l in text) {
            val heading = isHeading(l, body)
            val bullet = BULLET.containsMatchIn(l.text)
            val kind = when { heading -> LKind.HEADING; bullet -> LKind.POINT; else -> null }
            val p = prev
            val gap = if (p == null) 0f else l.t - p.b
            val newBlock = p == null || kind != null || isHeading(p, body) && !heading ||
                gap > max(l.h, p.h) * 0.75f && gap > medGap * 1.6f || gap < -p.h ||
                abs(l.size - p.size) > max(0.8f, max(l.size, p.size) * 0.18f) ||
                (curKind == LKind.POINT && l.l < cur.first().l + l.size * 0.3f && !l.text.first().isLowerCase()) ||
                (p.text.trimEnd().lastOrNull()?.let { it in ".!?।:" } == true && p.r < maxRight(cur) - l.size * 4) ||
                (p.r < colRight - p.size * 8 && l.text.first().isUpperCase() && p.text.trimEnd().lastOrNull()?.let { it in ",;-–" } != true)
            val continuesHeading = heading && curKind == LKind.HEADING && p != null && gap < p.h * 0.6f && abs(l.size - p.size) < max(0.6f, p.size * 0.12f)
            if (newBlock && !continuesHeading) {
                flush()
                curKind = kind ?: LKind.PARA
            }
            cur.add(l)
            prev = l
        }
        flush()

        // In page order, then sentences.
        items.sortBy { it.top }
        val sents = ArrayList<LSent>()
        val blocks = ArrayList<LBlock>()
        for (it in items) {
            val start = sents.size
            when (it.kind) {
                LKind.FIGURE -> {
                    it.texts.forEach { cap -> sents.add(LSent(cap, sayText(cap))) }
                    blocks.add(LBlock(LKind.FIGURE, start, sents.size - start, it.label))
                }
                LKind.TABLE -> {
                    val rows = it.rows ?: continue
                    val head = rows.first()
                    blocks.add(LBlock(LKind.TABLE, start, 0, head.joinToString(" · ")))
                    for (r in rows.drop(1)) {
                        val s0 = sents.size
                        val first = r.getOrNull(0).orEmpty()
                        val parts = r.drop(1).mapIndexedNotNull { i, v -> if (v.isBlank()) null else (head.getOrNull(i + 1)?.takeIf { h -> h.isNotBlank() }?.let { h -> "$h: $v" } ?: v) }
                        val show = first + "\n" + parts.joinToString(" · ")
                        val say = (listOf(first) + parts).filter { p -> p.isNotBlank() }.joinToString(". ") { p -> p.trimEnd('.', ';', ',') } + "."
                        sents.add(LSent(show.trim(), sayText(say)))
                        blocks.add(LBlock(LKind.ROW, s0, 1))
                    }
                }
                else -> {
                    for (t in it.texts) for (s in ListenText.split(t)) sents.add(LSent(s, sayText(s)))
                    if (sents.size > start) blocks.add(LBlock(it.kind, start, sents.size - start))
                }
            }
        }
        return LPage(sents, blocks, skipped = skipped.toList())
    }

    private fun wordCount(s: String) = s.trim().split(Regex("\\s+")).count { w -> w.any { it.isLetterOrDigit() } }

    /**
     * A page from OCR lines (scanned pages, or pages whose Hindi text is damaged). Uses each line's
     * position and height, so headings, points and tables still look right, and headers and
     * footers are left out. [w] and [h] are the size of the picture that was read.
     */
    fun fromOcr(lines: List<Line>, w: Float, h: Float, prefs: ListenReadPrefs): LPage {
        var ls = mergeMarkers(lines.sortedBy { it.t })
        // A number alone (a chapter number in a circle) is not read.
        ls = ls.filter { l -> l.text.any { it.isLetter() } }
        return build(columns(ls, w), emptyList(), w, h, prefs)
    }

    private val MARKER_LINE = Regex("^\\(?([0-9]{1,2}|[a-hA-H]|[क-ह])[.)]?\\)?$")

    /** "3." read as its own line next to its question: put them back together. */
    private fun mergeMarkers(ls: List<Line>): List<Line> {
        val out = ArrayList<Line>()
        val used = HashSet<Line>()
        for (m in ls) {
            if (m in used) continue
            if (MARKER_LINE.matches(m.text.trim())) {
                val next = ls.filter { it !== m && it !in used && it.l > m.r - 2f && abs(it.cy - m.cy) < max(it.h, m.h) * 0.6f }.minByOrNull { it.l }
                if (next != null) {
                    used.add(next)
                    out.add(Line(m.text.trim() + " " + next.text, m.l, min(m.t, next.t), next.r, max(m.b, next.b), max(m.size, next.size), next.bold,
                        listOf(Chunk(m.text.trim() + " " + (next.chunks.firstOrNull()?.text ?: ""), m.l, next.chunks.firstOrNull()?.r ?: next.r)) + next.chunks.drop(1),
                        listOf(Chunk(m.text.trim(), m.l, m.r)) + next.words))
                    continue
                }
            }
            out.add(m)
        }
        return out
    }

    /**
     * Two columns side by side (a "match the columns" exercise, a two-column page): read the
     * left column to the end, then the right one, instead of jumping across on every row.
     */
    fun columns(lines: List<Line>, pw: Float): List<Line> {
        if (lines.size < 6) return lines.sortedWith(compareBy<Line>({ it.t }, { it.l }))
        // Rows: lines that overlap vertically.
        val rows = ArrayList<MutableList<Line>>()
        for (l in lines.sortedBy { it.t }) {
            val r = rows.lastOrNull()
            if (r != null && l.t < r.maxOf { it.b } - min(l.h, r.first().h) * 0.4f) r.add(l) else rows.add(mutableListOf(l))
        }
        fun splitOf(r: List<Line>): Float? {
            if (r.size < 2) return null
            val s = r.sortedBy { it.l }
            var best = 0f; var at: Float? = null
            for (i in 1 until s.size) { val g = s[i].l - s.subList(0, i).maxOf { it.r }; if (g > best) { best = g; at = (s.subList(0, i).maxOf { it.r } + s[i].l) / 2 } }
            val size = r.map { it.size }.average().toFloat()
            return if (best > max(size * 2f, pw * 0.04f)) at else null
        }
        val out = ArrayList<Line>()
        var i = 0
        while (i < rows.size) {
            val split = splitOf(rows[i])
            if (split == null) { out.addAll(rows[i].sortedBy { it.l }); i++; continue }
            // Grow the section while rows are split at about the same place, or sit on one side.
            var j = i
            var splitRows = 0
            while (j < rows.size) {
                val r = rows[j]
                val sp = splitOf(r)
                val oneSide = r.all { it.r < split + pw * 0.01f } || r.all { it.l > split - pw * 0.01f }
                if (sp != null && abs(sp - split) < pw * 0.08f) splitRows++
                else if (!oneSide) break
                j++
            }
            if (splitRows >= 3) {
                val sec = rows.subList(i, j).flatten()
                out.addAll(sec.filter { it.cx < split }.sortedBy { it.t })
                out.addAll(sec.filter { it.cx >= split }.sortedBy { it.t })
                i = j
            } else { out.addAll(rows[i].sortedBy { it.l }); i++ }
        }
        return out
    }

    /** A chapter's name from its first page: the first heading (without a leading number), else its first words. */
    fun titleOf(p: LPage): String? {
        val b = p.blocks.firstOrNull { it.kind == LKind.HEADING && it.count > 0 && p.sentences[it.first].show.count { c -> c.isLetter() } >= 2 }
        val raw = if (b != null) p.sentences[b.first].show else p.sentences.firstOrNull()?.show ?: return null
        val t = raw.replace(Regex("^\\s*\\(?\\d{1,3}[.):]?\\s*"), "").trim()
        return (if (t.length > 50) t.take(48).substringBeforeLast(' ') + "…" else t).ifBlank { null }
    }

    private fun maxRight(cur: List<Line>) = cur.maxOfOrNull { it.r } ?: 0f

    private fun isHeading(l: Line, body: Float): Boolean {
        val t = l.text.trim()
        if (t.length > 90 || t.isEmpty()) return false
        if (l.size >= body * 1.25f) return true
        return l.bold && t.length < 70 && t.last() !in ".,;" && t.split(' ').size <= 10 && !BULLET.containsMatchIn(t)
    }

    /** Joins the lines of one paragraph, mending words split with a hyphen at the line end. */
    fun joinLines(ls: List<String>): String {
        val sb = StringBuilder()
        for (l in ls) {
            val t = l.trim()
            if (sb.isEmpty()) { sb.append(t); continue }
            if (sb.last() == '-' && sb.length > 1 && sb[sb.length - 2].isLetter() && t.firstOrNull()?.isLowerCase() == true) sb.setLength(sb.length - 1)
            else sb.append(' ')
            sb.append(t)
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /** What the voice reads: "9–11" becomes "9 to 11", bullets and odd marks go. */
    fun sayText(s: String): String = s
        .replace(Regex("^[•●▪◦‣■□➢►✓*]\\s*"), "")
        .replace(Regex("(\\d)\\s*–\\s*(\\d)"), "$1 to $2")
        .replace(Regex("\\s+"), " ").trim()

    private fun median(v: List<Float>): Float = if (v.isEmpty()) 10f else v.sorted()[v.size / 2]

    // ------------------------------------------------------------------ tables

    class Table(val lines: List<Line>, val rows: List<List<String>>)

    /**
     * Finds tables: a header line with 2+ short cells, then lines whose cells line up under the
     * same columns. A line with text only in later columns continues the row above (wrapped cells).
     */
    fun tables(lines: List<Line>): List<Table> {
        val out = ArrayList<Table>()
        var i = 0
        while (i < lines.size) {
            val head = lines[i]
            val ok = head.chunks.size >= 2 && head.chunks.all { it.text.length <= 32 } && head.chunks.first().text.length <= 30
            if (!ok) { i++; continue }
            val cols = head.chunks.map { it.l }
            val tol = head.size * 1.5f
            fun colOf(x: Float): Int = cols.indices.minByOrNull { abs(cols[it] - x) }!!.let { c -> if (abs(cols[c] - x) <= tol || x > cols[c]) c else -1 }
            val rows = ArrayList<MutableList<String>>()
            rows.add(head.chunks.map { it.text }.toMutableList())
            val used = arrayListOf(head)
            var j = i + 1
            var prev = head
            var rowSize = 0f
            while (j < lines.size) {
                val l = lines[j]
                if (l.t - prev.b > prev.h * 2.5f) break
                if (l.l < cols[0] - tol) break
                if (rowSize > 0f && abs(l.size - rowSize) > 0.8f) break
                if (rows.size > 2 && l.bold && l.chunks.size == 1 && l.l <= cols[0] + tol && (cols.size < 2 || l.r > cols[1])) break
                // One long chunk spanning the columns is a paragraph, not part of the table.
                if (l.chunks.size == 1 && cols.size > 1 && l.r > cols[1] + (l.r - l.l) * 0.5f && l.l <= cols[0] + tol && l.text.length > 40) break
                if (rowSize == 0f) rowSize = l.size
                val cells = MutableList(cols.size) { "" }
                for (wd in l.words) {
                    val c = cols.indices.lastOrNull { cols[it] <= wd.l + tol * 0.5f } ?: 0
                    cells[c] = (cells[c] + " " + wd.text).trim()
                }
                val startsRow = cells[0].isNotEmpty() && (rows.size == 1 || l.t - prev.b > prev.h * 0.2f)
                if (startsRow || rows.size == 1) rows.add(cells)
                else {
                    val last = rows.last()
                    for (c in cells.indices) if (cells[c].isNotEmpty()) last[c] = joinLines(listOf(last[c], cells[c]))
                }
                used.add(l); prev = l; j++
            }
            if (rows.size >= 3) { out.add(Table(used, rows)); i = j } else i++
        }
        return out
    }

    // ------------------------------------------------------------------ plain text (OCR) pages

    /** A page from plain text (scanned pages read by OCR): paragraphs and points only. */
    fun fromText(text: String, prefs: ListenReadPrefs): LPage {
        var lines = text.replace("\r", "").split('\n')
        if (prefs.skipNumbers) {
            // Drop a lone page number among the first or last two lines.
            val n = lines.size
            lines = lines.filterIndexed { i, l -> !((i < 2 || i >= n - 2) && PAGE_NUM.matches(l.trim()) && l.isNotBlank()) }
        }
        val sents = ArrayList<LSent>()
        val blocks = ArrayList<LBlock>()
        for (b in ListenText.blocks(lines.joinToString("\n"))) {
            val start = sents.size
            for (s in b) sents.add(LSent(s, sayText(s)))
            if (sents.size > start) blocks.add(LBlock(if (BULLET.containsMatchIn(b.first())) LKind.POINT else LKind.PARA, start, sents.size - start))
        }
        return LPage(sents, blocks)
    }

    // ------------------------------------------------------------------ broken Hindi

    private fun isSign(c: Char) = c.code in 0x093E..0x094C || c.code in 0x0962..0x0963
    private fun isDeva(c: Char) = c.code in 0x0900..0x097F

    /**
     * True when Hindi text came out of the PDF jumbled (vowel signs doubled or in the wrong
     * place), which happens with some PDF fonts. Such pages are read with OCR instead.
     */
    fun looksBrokenHindi(s: String): Boolean {
        val deva = s.count { isDeva(it) }
        if (deva < 30) return false
        var bad = 0
        for (i in s.indices) {
            val c = s[i]
            if (!isSign(c)) continue
            val p = s.getOrNull(i - 1)
            if (p == null || p == ' ' || isSign(p) || p.code == 0x094D) bad++
        }
        return bad * 100 >= deva * 2
    }
}
