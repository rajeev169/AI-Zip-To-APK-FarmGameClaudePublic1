package com.aipdfstudio.app.data

/** Turns page text into sentences that read well aloud (pure Kotlin, tested off-device). */
object ListenText {
    private val DEVANAGARI = Regex("[\\u0900-\\u097F]")
    private val LETTER = Regex("\\p{L}")

    /** True when most letters in [s] are Hindi (Devanagari). */
    fun isHindi(s: String): Boolean {
        val all = LETTER.findAll(s).count()
        if (all == 0) return false
        return DEVANAGARI.findAll(s).count() * 2 >= all
    }

    /**
     * Sentences of one page. Lines broken in the middle of a sentence are joined, words split
     * with a hyphen at a line end are put back together, bullets become separate sentences,
     * and very long sentences are cut at commas so the highlight stays readable.
     */
    fun sentences(page: String): List<String> = blocks(page).flatten()

    /** Sentences of one paragraph that is already joined into one line. */
    fun split(paragraph: String): List<String> {
        val out = ArrayList<String>()
        // A list number ("1.", "(b)") before or after a full stop is not the end of a sentence.
        val pieces = ArrayList<String>()
        for (p in paragraph.split(END)) {
            val last = pieces.lastOrNull()
            if (last != null && (MARKER_ONLY.matches(last.trim()) || MARKER_END.containsMatchIn(last) || INITIAL_END.containsMatchIn(last))) pieces[pieces.size - 1] = "$last $p" else pieces.add(p)
        }
        for (s in pieces) {
            val t = s.replace(Regex("\\s+"), " ").trim()
            if (t.isEmpty() || !LETTER.containsMatchIn(t) && !t.any { it.isDigit() }) continue
            out.addAll(cutLong(t))
        }
        return out
    }

    private val MARKER_ONLY = Regex("^\\(?(\\d{1,2}|[a-hA-H]|[ivx]{1,4})[.)]$")
    /** "R.M." or "Dr." at the end: an initial or title, not the end of a sentence. */
    private val INITIAL_END = Regex("((^|[\\s.])\\p{Lu}\\.|\\b(Dr|Mr|Mrs|Ms|St|No|Fig|vs|etc|e\\.g|i\\.e)\\.)$")
    private val MARKER_END = Regex("(^|\\s)\\(?\\d{1,2}[.)]$")
    private val END = Regex("(?<=[.!?।॥])\\s+(?=[\"'“(\\[]?[\\p{Lu}\\p{N}\\u0900-\\u097F])")

    /** The page split into blocks (headings, points, paragraphs), each a list of sentences. */
    fun blocks(page: String): List<List<String>> {
        val text = page.replace("\r", "")
            .replace(Regex("(\\p{L})-\\n(\\p{Ll})"), "$1$2")
        // Decide for each line whether it continues the previous one (a sentence broken across lines)
        // or starts something new (a heading, a bullet, a new paragraph).
        val blocks = ArrayList<String>()
        val cur = StringBuilder()
        var prev = ""
        fun flush() { if (cur.isNotBlank()) blocks.add(cur.toString().trim()); cur.setLength(0); prev = "" }
        val bulletRe = Regex("^([•●▪◦‣*]|[-–]|\\d{1,3}[.)])\\s+.*")
        for (raw in text.split('\n')) {
            val line = raw.trim()
            if (line.isEmpty()) { flush(); continue }
            val bullet = line.matches(bulletRe)
            val continues = prev.isNotEmpty() && !bullet && !prev.contains(Regex("[.!?।॥:]$")) &&
                (line.first().isLowerCase() || prev.length >= 45)
            if (!continues) flush()
            cur.append(if (cur.isEmpty()) "" else " ").append(line.replace(Regex("^[•●▪◦‣*]\\s*"), ""))
            prev = line
        }
        flush()
        return blocks.map { split(it) }.filter { it.isNotEmpty() }
    }

    /** Very long runs (no full stop for a long time) are cut so the highlight stays readable. */
    private fun cutLong(s: String, max: Int = 600): List<String> {
        if (s.length <= max) return listOf(s)
        val out = ArrayList<String>()
        var rest = s
        while (rest.length > max) {
            var cut = listOf(", ", "; ", ": ", " – ", " - ").map { rest.lastIndexOf(it, max) }.maxOrNull() ?: -1
            if (cut < max / 3) cut = rest.lastIndexOf(' ', max)
            if (cut <= 0) cut = max
            out.add(rest.substring(0, cut + 1).trim())
            rest = rest.substring(cut + 1).trim()
        }
        if (rest.isNotEmpty()) out.add(rest)
        return out
    }

    /** Rough listening time in minutes for [chars] characters at [speed]. */
    fun minutesFor(chars: Int, speed: Float): Int = kotlin.math.max(1, (chars / (14.5f * 60f * speed)).toInt())
}
