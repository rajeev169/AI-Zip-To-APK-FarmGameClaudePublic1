package com.aipdfstudio.app.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/** One voice in "Choose a voice". [name] is the engine's own id (like "en-in-x-ena-local"). */
data class VoiceItem(
    val name: String,
    val label: String,
    val lang: String,          // "en" or "hi"
    val country: String,       // "India", "US", …
    val online: Boolean,       // needs internet (usually the most natural)
    val natural: Boolean,
    val engine: String,
    /** "Female" or "Male", worked out from the voice's pitch (Android doesn't say). */
    val gender: String? = null
)

/** Finds the phone's voices and picks the most natural one. */
object ListenVoices {
    const val GOOGLE = "com.google.android.tts"

    fun googleInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(GOOGLE, 0); true
    } catch (e: Exception) { false }

    /** The phone's default speech engine (package name), or null if none. */
    fun defaultEngine(ctx: Context): String? = try {
        android.provider.Settings.Secure.getString(ctx.contentResolver, "tts_default_synth")
    } catch (e: Exception) { null }

    fun engineLabel(ctx: Context, pkg: String?): String {
        if (pkg == null) return "Phone voice"
        if (pkg == GOOGLE) return "Google"
        return try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { "Phone voice" }
    }

    private fun countryName(l: Locale): String = when (l.country.uppercase()) {
        "IN" -> "India"; "US" -> "US"; "GB" -> "UK"; "AU" -> "Australia"; "NG" -> "Nigeria"; "" -> ""
        else -> l.getDisplayCountry(Locale.ENGLISH)
    }

    /** English and Hindi voices that are ready to use, best first, named "Voice 1", "Voice 2"… per language. */
    fun list(tts: TextToSpeech?, engine: String): List<VoiceItem> {
        val all: Set<Voice> = try { tts?.voices ?: emptySet() } catch (e: Exception) { emptySet() }
        val out = ArrayList<VoiceItem>()
        for (lang in listOf("en", "hi")) {
            val vs = all.filter { v ->
                val l = v.locale
                l.language == lang &&
                    !(v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) ?: false) &&
                    !v.name.contains("legacy", ignoreCase = true)
            }.sortedWith(compareBy<Voice>(
                { if (it.locale.country.equals("IN", true)) 0 else if (it.locale.country.equals("US", true)) 1 else if (it.locale.country.equals("GB", true)) 2 else 3 },
                { if (it.isNetworkConnectionRequired) 1 else 0 },
                { -it.quality },
                { it.name }
            ))
            vs.forEachIndexed { i, v ->
                out.add(VoiceItem(
                    name = v.name, label = "Voice ${i + 1}", lang = lang, country = countryName(v.locale),
                    online = v.isNetworkConnectionRequired,
                    natural = engine == GOOGLE || v.quality >= Voice.QUALITY_HIGH,
                    engine = engine
                ))
            }
        }
        return out
    }

    /** The voice to use for [lang] when the user hasn't picked one: an offline Indian voice if possible. */
    fun best(list: List<VoiceItem>, lang: String): VoiceItem? =
        list.filter { it.lang == lang }.let { l -> l.firstOrNull { !it.online && it.natural } ?: l.firstOrNull { !it.online } ?: l.firstOrNull() }

    fun find(tts: TextToSpeech?, name: String?): Voice? {
        if (name == null || tts == null) return null
        return try { tts.voices?.firstOrNull { it.name == name } } catch (e: Exception) { null }
    }

    /** Opens Google's speech app in the Play Store (to install the natural voices). */
    fun getGoogleIntent(): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$GOOGLE")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun getGoogleWebIntent(): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$GOOGLE")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Opens the engine's "download voices" screen. */
    fun installVoicesIntent(engine: String?): Intent =
        Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).apply { if (engine != null) setPackage(engine) }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Voices of one family ("en-in-x-ena-local" / "-network") sound alike: the family part of the name. */
    fun family(name: String): String = Regex("-x-([a-z]+)").find(name)?.groupValues?.get(1)?.let { name.substringBefore("-x-") + "-" + it } ?: name

    /** Gives voices names like "Female 1", "Male 2" (per language) once their pitch is known. */
    fun labelled(list: List<VoiceItem>, genders: Map<String, String>): List<VoiceItem> {
        val out = ArrayList<VoiceItem>()
        for (lang in listOf("en", "hi")) {
            val counts = HashMap<String, Int>()
            var plain = 0
            for (v in list.filter { it.lang == lang }) {
                val g = genders[v.name] ?: genders[family(v.name)]
                val label = if (g != null) { val n = (counts[g] ?: 0) + 1; counts[g] = n; "$g $n" } else { plain++; "Voice $plain" }
                out.add(v.copy(label = label, gender = g))
            }
        }
        return out
    }

    /**
     * Typical pitch of a voice in Hz (autocorrelation over voiced 40 ms frames). Women's voices
     * are usually above ~165 Hz, men's below ~150 Hz.
     */
    fun pitchHz(pcm: ShortArray, rate: Int): Float? {
        val frame = (rate * 0.04).toInt()
        val hop = frame / 2
        val minLag = rate / 400; val maxLag = rate / 70
        val rms = pcm.map { it.toDouble() * it }.average().let { kotlin.math.sqrt(it) }
        val found = ArrayList<Float>()
        var i = 0
        while (i + frame + maxLag < pcm.size) {
            var e = 0.0
            for (k in 0 until frame) e += pcm[i + k].toDouble() * pcm[i + k]
            if (kotlin.math.sqrt(e / frame) > rms * 0.6) {
                var best = 0.0; var bestLag = 0
                for (lag in minLag..maxLag) {
                    var c = 0.0
                    for (k in 0 until frame) c += pcm[i + k].toDouble() * pcm[i + k + lag]
                    if (c > best) { best = c; bestLag = lag }
                }
                if (bestLag > 0 && best > 0.45 * e) found.add(rate.toFloat() / bestLag)
            }
            i += hop
        }
        if (found.size < 5) return null
        found.sort()
        return found[found.size / 2]
    }

    fun genderOf(hz: Float?): String? = when { hz == null -> null; hz >= 165f -> "Female"; hz <= 150f -> "Male"; else -> null }

    const val SAMPLE_EN_TEACHER = "Good morning, students. Today we will learn about the leaf. A leaf makes food for the plant, and this process is called photosynthesis. Now tell me, where does the leaf get sunlight from? Very good!"
    const val SAMPLE_HI_TEACHER = "आज हम संज्ञा के बारे में पढ़ेंगे। संज्ञा का अर्थ है किसी व्यक्ति, वस्तु, स्थान या भाव का नाम। अब आप बताइए, गंगा किसका नाम है? बिल्कुल सही!"
    const val SAMPLE_EN = "Plants make their own food using sunlight, water and carbon dioxide."
    const val SAMPLE_HI = "पौधे सूर्य के प्रकाश, पानी और कार्बन डाइऑक्साइड से अपना भोजन बनाते हैं।"
}
