package com.aipdfstudio.app.data

import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Converts positions on a page *as the user sees it* (top-left origin, in points, after the
 * page's /Rotate is applied) into PDF user space (bottom-left origin, unrotated).
 * Pure Kotlin so it can be unit tested without Android.
 *
 * [llx], [lly], [w], [h] describe the page's crop box; [rotation] is the page's /Rotate value.
 */
class PageMath(
    private val llx: Float,
    private val lly: Float,
    private val w: Float,
    private val h: Float,
    rotation: Int
) {
    val rot: Int = ((rotation % 360) + 360) % 360
    private val sideways = rot == 90 || rot == 270

    /** Width and height of the page as displayed. */
    val dispW: Float get() = if (sideways) h else w
    val dispH: Float get() = if (sideways) w else h

    /** Display point (dx, dy) -> user space (x, y). */
    fun toUser(dx: Float, dy: Float): FloatArray = when (rot) {
        90 -> floatArrayOf(llx + dy, lly + dx)
        180 -> floatArrayOf(llx + w - dx, lly + dy)
        270 -> floatArrayOf(llx + w - dy, lly + h - dx)
        else -> floatArrayOf(llx + dx, lly + h - dy)
    }

    /** Linear part only (a direction vector in display space -> user space). */
    fun dir(dx: Float, dy: Float): FloatArray {
        val a = toUser(dx, dy)
        val o = toUser(0f, 0f)
        return floatArrayOf(a[0] - o[0], a[1] - o[1])
    }

    /**
     * PDF matrix [a b c d e f] that maps the unit square onto the display rectangle
     * (left, top, width, height), upright for the viewer. Used to draw images.
     */
    fun rectMatrix(left: Float, top: Float, width: Float, height: Float): FloatArray {
        val xAxis = dir(width, 0f)
        val yAxis = dir(0f, -height)
        val origin = toUser(left, top + height)
        return floatArrayOf(xAxis[0], xAxis[1], yAxis[0], yAxis[1], origin[0], origin[1])
    }

    /**
     * Text matrix for a line starting at display (left, baseline), reading left to right as seen,
     * with horizontal stretch [scaleX].
     */
    fun textMatrix(left: Float, baseline: Float, scaleX: Float): FloatArray {
        val x = dir(1f, 0f)
        val y = dir(0f, -1f)
        val o = toUser(left, baseline)
        return floatArrayOf(x[0] * scaleX, x[1] * scaleX, y[0], y[1], o[0], o[1])
    }
}

/** Keeps only characters the standard Helvetica font (WinAnsi) can draw. */
fun winAnsiOnly(s: String): String = buildString {
    for (c in s) {
        if (c.code in 32..126 || c.code in 160..255) append(c)
        else if (c == '\t') append(' ')
    }
}

/** Builds a simple .docx (Word) file containing plain paragraphs, one page per entry. */
object Docx {
    private fun clean(s: String): String = buildString {
        for (c in s) {
            val ok = c == '\t' || c.code >= 0x20 && c.code != 0xFFFE && c.code != 0xFFFF
            if (ok) append(
                when (c) {
                    '&' -> "&amp;"
                    '<' -> "&lt;"
                    '>' -> "&gt;"
                    '"' -> "&quot;"
                    else -> c.toString()
                }
            )
        }
    }

    /** Splits page text into paragraphs: blank lines separate paragraphs; lines inside are joined. */
    fun paragraphs(pageText: String): List<String> =
        pageText.replace("\r\n", "\n").replace('\r', '\n')
            .split(Regex("\n\\s*\n"))
            .map { block -> block.lines().joinToString(" ") { it.trim() }.trim() }
            .filter { it.isNotEmpty() }

    fun documentXml(pages: List<String>): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        append("<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>")
        pages.forEachIndexed { i, page ->
            if (i > 0) append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
            val paras = paragraphs(page)
            if (paras.isEmpty()) append("<w:p/>")
            paras.forEach { p ->
                append("<w:p><w:r><w:t xml:space=\"preserve\">").append(clean(p)).append("</w:t></w:r></w:p>")
            }
        }
        append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>")
        append("<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"709\" w:footer=\"709\" w:gutter=\"0\"/>")
        append("</w:sectPr></w:body></w:document>")
    }

    fun write(pages: List<String>, out: OutputStream) {
        val zip = ZipOutputStream(out)
        fun put(name: String, text: String) {
            zip.putNextEntry(ZipEntry(name))
            zip.write(text.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
        put(
            "[Content_Types].xml",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                "</Types>"
        )
        put(
            "_rels/.rels",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                "</Relationships>"
        )
        put("word/document.xml", documentXml(pages))
        zip.finish()
        zip.flush()
    }
}
