package com.aipdfstudio.app.data

import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDVectorFont
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.ByteArrayInputStream
import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class Family { SANS, SERIF, MONO }

/** How text looks. [sizePt] is in PDF points; [color] is 0xRRGGBB. */
data class TStyle(
    val sizePt: Float,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val family: Family = Family.SANS,
    val color: Int = 0x111111
)

/** Points at a font in the page's resources, so the original font can be reused when saving. */
data class FontRef(val resName: String, val baseName: String)

/** A line of text with its look. [baseline] is a fraction of the displayed page height. */
class StyledLine(
    val text: String,
    val box: FBox,
    val baseline: Float,
    val sizePt: Float,
    val style: TStyle,
    val font: FontRef?
)

/** A paragraph found on a page, ready to be edited. Positions are fractions of the displayed page. */
class Paragraph(
    val page: Int,
    val index: Int,
    val lines: List<StyledLine>,
    val box: FBox,
    val text: String,
    val style: TStyle,
    val font: FontRef?,
    val firstBaseline: Float,
    val lineGapPt: Float
)

object FontStyle {
    fun cleanName(font: PDFont?): String = (font?.name ?: "").substringAfter('+')

    /** Guesses bold / italic / family from the font's name and description. */
    fun of(font: PDFont?): Triple<Boolean, Boolean, Family> {
        val name = cleanName(font).lowercase()
        val d = try { font?.fontDescriptor } catch (e: Exception) { null }
        val bold = Regex("bold|black|heavy|semibold|demi|extrabold").containsMatchIn(name) ||
            (d?.fontWeight ?: 0f) >= 600f || (d?.isForceBold ?: false)
        val italic = Regex("italic|oblique|-it\\b|,it\\b").containsMatchIn(name) ||
            (d?.isItalic ?: false) || abs(d?.italicAngle ?: 0f) > 0.5f
        val family = when {
            Regex("courier|mono|consol|fixed|typewriter").containsMatchIn(name) || (d?.isFixedPitch ?: false) -> Family.MONO
            name.contains("sans") -> Family.SANS
            Regex("times|serif|georgia|garamond|cambria|roman|minion|palatino|book|baskerville|caslon|bodoni|didot")
                .containsMatchIn(name) || (d?.isSerif ?: false) -> Family.SERIF
            else -> Family.SANS
        }
        return Triple(bold, italic, family)
    }

    /** True if [font] can draw every character of [text] (including glyphs present in a subset font). */
    fun canDraw(font: PDFont, text: String): Boolean {
        try {
            var i = 0
            while (i < text.length) {
                val cp = text.codePointAt(i)
                val s = String(Character.toChars(cp))
                val bytes = font.encode(s)
                if (bytes.isEmpty()) return false
                if (font is PDVectorFont && !Character.isWhitespace(cp)) {
                    val code = font.readCode(ByteArrayInputStream(bytes))
                    if (!font.hasGlyph(code)) return false
                }
                i += Character.charCount(cp)
            }
            return true
        } catch (e: Exception) {
            return false
        }
    }

    /** Name under which [font] is listed in the page's resources (only page-level fonts). */
    fun resourceName(page: PDPage, font: PDFont?): String? {
        if (font == null) return null
        val res = page.resources ?: return null
        for (n in res.fontNames) {
            val f = try { res.getFont(n) } catch (e: Exception) { null } ?: continue
            if (f === font || f.cosObject === font.cosObject) return n.name
        }
        return null
    }

    fun lookup(page: PDPage, ref: FontRef?): PDFont? {
        if (ref == null) return null
        return try { page.resources?.getFont(COSName.getPDFName(ref.resName)) } catch (e: Exception) { null }
    }
}

object Paragraphs {
    private class Glyph(val ch: Char, val box: FBox, val baseline: Float, val sizePt: Float, val styleId: Int)

    private class Collector(
        private val page: PDPage,
        private val dispW: Float,
        private val dispH: Float,
        private val rot: Int
    ) : PDFTextStripper() {
        val glyphs = ArrayList<Glyph>()
        val wordBreaks = HashSet<Int>()
        val styles = ArrayList<Pair<TStyle, FontRef?>>()
        private val styleIds = HashMap<String, Int>()
        private val colors = IdentityHashMap<TextPosition, Int>()
        private val fontRefs = IdentityHashMap<PDFont, FontRef?>()

        init {
            // The plain text reader ignores colour commands; turn them on so we know each word's colour.
            addOperator(com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingColorSpace())
            addOperator(com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingColor())
            addOperator(com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingColorN())
            addOperator(com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingDeviceGrayColor())
            addOperator(com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingDeviceRGBColor())
            addOperator(com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingDeviceCMYKColor())
        }

        override fun processTextPosition(text: TextPosition) {
            val c = try {
                graphicsState.nonStrokingColor.toRGB()
            } catch (e: Exception) {
                0x111111
            }
            colors[text] = c and 0xFFFFFF
            super.processTextPosition(text)
        }

        private fun styleId(p: TextPosition, sizePt: Float): Int {
            val font = p.font
            val (bold, italic, family) = FontStyle.of(font)
            val color = colors[p] ?: 0x111111
            val ref = if (font == null) null else fontRefs.getOrPut(font) {
                FontStyle.resourceName(page, font)?.let { FontRef(it, FontStyle.cleanName(font)) }
            }
            val key = "${ref?.resName}|$bold|$italic|$family|$color|${(sizePt * 2).toInt()}"
            return styleIds.getOrPut(key) {
                styles.add(TStyle(sizePt, bold, italic, family, color) to ref)
                styles.size - 1
            }
        }

        override fun writeString(text: String?, textPositions: MutableList<TextPosition>?) {
            if (textPositions.isNullOrEmpty()) return
            if (glyphs.isNotEmpty()) wordBreaks.add(glyphs.size)
            for (p in textPositions) {
                if (((p.dir.toInt() - rot) % 360 + 360) % 360 != 0) continue
                val fs = p.fontSizeInPt.takeIf { it > 0f } ?: p.heightDir
                val u = p.unicode ?: continue
                val w = max(p.width, 0f)
                val sid = styleId(p, fs)
                u.forEachIndexed { i, ch ->
                    val part = w / u.length
                    glyphs.add(
                        Glyph(
                            ch,
                            FBox((p.x + part * i) / dispW, (p.y - fs * 0.8f) / dispH, (p.x + part * (i + 1)) / dispW, (p.y + fs * 0.22f) / dispH),
                            p.y / dispH, fs, sid
                        )
                    )
                }
            }
        }
    }

    /** Reads all styled lines on a page. */
    fun lines(doc: PDDocument, index: Int): Pair<List<StyledLine>, PageMath> {
        val page = doc.getPage(index)
        val cb = page.cropBox
        val pm = PageMath(cb.lowerLeftX, cb.lowerLeftY, cb.width, cb.height, page.rotation)
        val c = Collector(page, pm.dispW, pm.dispH, pm.rot)
        c.sortByPosition = true
        c.startPage = index + 1
        c.endPage = index + 1
        c.getText(doc)
        return groupLines(c, pm.dispW) to pm
    }

    private fun groupLines(c: Collector, dispW: Float): List<StyledLine> {
        val out = ArrayList<StyledLine>()
        var cur = ArrayList<Glyph>()
        fun flush() {
            val g = cur.dropWhile { it.ch == ' ' }.dropLastWhile { it.ch == ' ' }
            cur = ArrayList()
            if (g.isEmpty()) return
            val real = g.filter { it.ch != ' ' }
            val box = real.map { it.box }.reduce { a, b -> a.union(b) }
            // The look used by most letters wins (a bold word inside a line doesn't make the line bold).
            val sid = real.groupingBy { it.styleId }.eachCount().maxByOrNull { it.value }!!.key
            val (style, ref) = c.styles[sid]
            val size = real.maxOf { it.sizePt }
            val base = real.groupingBy { it.baseline }.eachCount().maxByOrNull { it.value }!!.key
            out.add(StyledLine(String(g.map { it.ch }.toCharArray()), box, base, size, style.copy(sizePt = size), ref))
        }
        for (i in c.glyphs.indices) {
            val gl = c.glyphs[i]
            if (cur.isNotEmpty()) {
                val last = cur.last()
                val sameLine = abs(gl.baseline - last.baseline) * 1000 < 1 ||
                    abs(gl.box.t - last.box.t) < max(gl.box.h, last.box.h) * 0.45f
                // A big jump in size, or a wide gap (another column / table cell), starts a new line.
                val sizeJump = max(gl.sizePt, last.sizePt) > 1.5f * min(gl.sizePt, last.sizePt)
                // Measure from the last real letter: PDFs often contain explicit space characters.
                val lastReal = cur.lastOrNull { it.ch != ' ' } ?: last
                val gapPt = (gl.box.l - lastReal.box.r) * dispW
                val farApart = gapPt > 0.8f * max(gl.sizePt, last.sizePt) || gapPt < -0.5f * max(gl.sizePt, last.sizePt)
                if (!sameLine || sizeJump || farApart) flush()
            }
            if (cur.isNotEmpty() && i in c.wordBreaks && cur.last().ch != ' ') {
                val prev = cur.last()
                cur.add(Glyph(' ', FBox(prev.box.r, prev.box.t, max(prev.box.r, gl.box.l), prev.box.b), prev.baseline, prev.sizePt, prev.styleId))
            }
            cur.add(gl)
        }
        flush()
        return out
    }

    /** Joins the lines of a paragraph into one text (removing end-of-line hyphenation). */
    fun join(lines: List<String>): String {
        val sb = StringBuilder()
        lines.forEachIndexed { i, raw ->
            val l = raw.trim()
            if (i == 0) {
                sb.append(l)
            } else {
                val prev = sb.toString()
                if (prev.endsWith("-") && l.firstOrNull()?.isLowerCase() == true && prev.length > 1 && prev[prev.length - 2].isLetter()) {
                    sb.setLength(sb.length - 1)
                    sb.append(l)
                } else {
                    sb.append(' ').append(l)
                }
            }
        }
        return sb.toString()
    }

    /**
     * Groups lines into paragraphs: same look and size, close line spacing, overlapping left/right.
     * Works with two columns because each line joins the best paragraph above it, not just the last one.
     */
    fun group(lines: List<StyledLine>, dispW: Float, dispH: Float): List<List<StyledLine>> {
        val sorted = lines.sortedWith(compareBy({ it.box.t }, { it.box.l }))
        val paras = ArrayList<MutableList<StyledLine>>()
        for (line in sorted) {
            val sz = line.sizePt
            var best: MutableList<StyledLine>? = null
            var bestGap = Float.MAX_VALUE
            for (p in paras) {
                val last = p.last()
                val st = last.style
                if (st.bold != line.style.bold || st.family != line.style.family || st.italic != line.style.italic) continue
                if (abs(st.color - line.style.color) != 0 && colorDistance(st.color, line.style.color) > 60) continue
                if (abs(last.sizePt - sz) > 0.15f * max(last.sizePt, sz)) continue
                val gapPt = (line.baseline - last.baseline) * dispH
                if (gapPt < 0.5f * sz || gapPt > 1.9f * sz) continue
                val overlap = min(last.box.r, line.box.r) - max(last.box.l, line.box.l)
                if (overlap <= 0f) continue
                if (abs(line.box.l - p.first().box.l) * dispW > 4f * sz) continue
                if (p.size >= 2) {
                    val prevGap = (p[p.size - 1].baseline - p[p.size - 2].baseline) * dispH
                    if (abs(gapPt - prevGap) > 0.35f * sz) continue
                }
                if (gapPt < bestGap) {
                    bestGap = gapPt
                    best = p
                }
            }
            if (best != null) best.add(line) else paras.add(mutableListOf(line))
        }
        return paras
    }

    private fun colorDistance(a: Int, b: Int): Int =
        abs(((a shr 16) and 255) - ((b shr 16) and 255)) + abs(((a shr 8) and 255) - ((b shr 8) and 255)) + abs((a and 255) - (b and 255))

    fun read(doc: PDDocument, index: Int): List<Paragraph> {
        val (lines, pm) = lines(doc, index)
        return group(lines, pm.dispW, pm.dispH).mapIndexed { i, ls ->
            val box = ls.map { it.box }.reduce { a, b -> a.union(b) }
            val gap = if (ls.size >= 2) (ls.last().baseline - ls.first().baseline) * pm.dispH / (ls.size - 1) else ls[0].sizePt * 1.2f
            Paragraph(index, i, ls, box, join(ls.map { it.text }), ls[0].style, ls[0].font, ls[0].baseline, gap)
        }
    }
}

object TextWrap {
    /** Greedy word wrap. Keeps the user's own line breaks. Very long words are broken by letters. */
    fun wrap(text: String, maxWidth: Float, measure: (String) -> Float): List<String> {
        val out = ArrayList<String>()
        for (hard in text.split('\n')) {
            val words = hard.split(' ')
            var line = ""
            for (w in words) {
                val candidate = if (line.isEmpty()) w else "$line $w"
                if (measure(candidate) <= maxWidth || line.isEmpty() && measure(w) <= maxWidth) {
                    line = candidate
                    continue
                }
                if (line.isNotEmpty()) {
                    out.add(line)
                    line = ""
                }
                if (measure(w) <= maxWidth) {
                    line = w
                } else {
                    var piece = ""
                    for (ch in w) {
                        if (piece.isNotEmpty() && measure(piece + ch) > maxWidth) {
                            out.add(piece)
                            piece = ""
                        }
                        piece += ch
                    }
                    line = piece
                }
            }
            out.add(line)
        }
        return out
    }
}

/**
 * Turns text into the byte codes of one font. Normal fonts use the font's own encoding. Subset
 * fonts with private codes (common in PDFs made by Word, LibreOffice or Chrome) are handled by
 * reading the font's Unicode table backwards, so letters already used in the document can be
 * written again in the original font.
 */
class FontWriter(val font: PDFont) {
    /** null = the font encodes text itself; otherwise Unicode code point -> bytes. */
    private val reverse: Map<Int, ByteArray>? = build()
    private val twoByte = font is com.tom_roush.pdfbox.pdmodel.font.PDType0Font

    private fun nativeOk(): Boolean = try {
        font.encode("a")
        true
    } catch (e: Exception) {
        false
    }

    private fun build(): Map<Int, ByteArray>? {
        if (nativeOk()) return null
        val map = HashMap<Int, ByteArray>()
        try {
            val max = if (font is com.tom_roush.pdfbox.pdmodel.font.PDType0Font) {
                val cmap = font.cMap
                if (cmap == null || !cmap.name.orEmpty().startsWith("Identity")) return map
                0xFFFF
            } else 0xFF
            for (code in 0..max) {
                val u = try { font.toUnicode(code) } catch (e: Exception) { null } ?: continue
                if (u.codePointCount(0, u.length) != 1) continue
                val cp = u.codePointAt(0)
                if (map.containsKey(cp)) continue
                if (font is PDVectorFont && cp != ' '.code && !(try { font.hasGlyph(code) } catch (e: Exception) { false })) continue
                map[cp] = if (max > 0xFF) byteArrayOf((code shr 8).toByte(), (code and 0xFF).toByte()) else byteArrayOf(code.toByte())
            }
        } catch (e: Exception) {
        }
        return map
    }

    val usesRawCodes get() = reverse != null

    fun canDraw(text: String): Boolean {
        val r = reverse ?: return FontStyle.canDraw(font, text)
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            if (!r.containsKey(cp)) return false
            i += Character.charCount(cp)
        }
        return true
    }

    fun bytes(text: String): ByteArray {
        val r = reverse ?: return font.encode(text)
        val out = java.io.ByteArrayOutputStream()
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            r[cp]?.let { out.write(it) }
            i += Character.charCount(cp)
        }
        return out.toByteArray()
    }

    fun width(text: String, sizePt: Float): Float = try {
        if (reverse == null) {
            font.getStringWidth(text) / 1000f * sizePt
        } else {
            val b = bytes(text)
            var w = 0f
            val input = ByteArrayInputStream(b)
            while (input.available() > 0) w += font.getWidth(font.readCode(input))
            w / 1000f * sizePt
        }
    } catch (e: Exception) {
        text.length * sizePt * 0.5f
    }

    /** Writes the text-show command. Must be inside BT/ET after setFont. */
    fun show(cs: com.tom_roush.pdfbox.pdmodel.PDPageContentStream, text: String) {
        if (reverse == null) {
            cs.showText(text)
            return
        }
        val hex = bytes(text).joinToString("") { "%02X".format(it.toInt() and 0xFF) }
        cs.appendRawCommands("<$hex> Tj\n")
    }
}
