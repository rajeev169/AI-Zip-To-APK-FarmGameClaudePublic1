package com.aipdfstudio.app.data

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

object PdfText {
    /** Extracts selectable text from a PDF. Scanned PDFs return little or nothing. */
    suspend fun extract(context: Context, uri: Uri, maxChars: Int = 120_000): String =
        withContext(Dispatchers.IO) {
            val input = context.contentResolver.openInputStream(uri) ?: throw IOException("Can't open file")
            input.use { stream ->
                val doc = PDDocument.load(stream)
                try {
                    PDFTextStripper().getText(doc).trim().take(maxChars)
                } finally {
                    doc.close()
                }
            }
        }
}
