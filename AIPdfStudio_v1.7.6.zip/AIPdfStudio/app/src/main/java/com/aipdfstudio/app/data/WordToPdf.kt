package com.aipdfstudio.app.data

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.math.max
import kotlin.math.min

/**
 * Turns a Word file (.docx) into a PDF on the phone.
 *
 * Kept: paragraphs with bold / italic / underline / size / colour, headings and title styles,
 * left / centre / right / justified alignment, indents and spacing, bulleted and numbered lists,
 * tables (with column widths, merged columns and cell shading), pictures, line and page breaks,
 * page size and margins. Simplified: text boxes, columns, headers/footers, footnotes and fonts
 * (mapped to the closest of sans, serif and mono; other scripts use a Unicode font).
 */
object WordToPdf {
    private const val W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val A = "http://schemas.openxmlformats.org/drawingml/2006/main"
    private const val WP = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
    private const val PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"

    // ------------------------------------------------------------------ model

    private data class RStyle(
        val size: Float = 11f, val bold: Boolean = false, val italic: Boolean = false,
        val underline: Boolean = false, val color: Int = 0x000000, val family: Family = Family.SANS
    )
    private class Run(val text: String, val s: RStyle)
    private sealed class Block
    private class Para(
        val runs: List<Run>, val align: Char, val indent: Float, val firstIndent: Float,
        val before: Float, val after: Float, val lineMul: Float, val prefix: Run?, val pageBreakBefore: Boolean,
        val shade: Int?
    ) : Block()
    private class Img(val bytes: ByteArray, val w: Float, val h: Float, val align: Char) : Block()
    private class Cell(val blocks: List<Block>, val span: Int, val shade: Int?)
    private class Table(val grid: List<Float>, val rows: List<List<Cell>>) : Block()
    private object PageBreak : Block()

    private class StyleDef(val basedOn: String?, val r: Map<String, String>, val p: Map<String, String>)

    // ------------------------------------------------------------------ public

    /**
     * Converts [docx] (the file's bytes) into [out]. [image] turns picture bytes into a PDF image
     * (the app passes an Android decoder); pictures it can't read are left out.
     * Returns the number of pages.
     */
    fun convert(docx: InputStream, out: File, image: (PDDocument, ByteArray) -> PDImageXObject?): Int {
        val parts = HashMap<String, ByteArray>()
        ZipInputStream(docx).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory) parts[e.name.trimStart('/')] = z.readBytes()
                e = z.nextEntry
            }
        }
        val body = parts["word/document.xml"]
            ?: throw UserError("This isn't a Word .docx file. Old .doc files need to be saved as .docx first.")
        val ctx = Ctx(parts)
        ctx.readStyles()
        ctx.readNumbering()
        ctx.readRels()
        val doc = parse(body)
        val bodyEl = first(doc.documentElement, W, "body") ?: throw UserError("This Word file looks empty.")
        ctx.readSection(bodyEl)
        val blocks = ctx.blocks(bodyEl)
        PDDocument().use { pdf ->
            val pages = Layout(pdf, ctx, image).run(blocks)
            pdf.documentInformation.creator = "AI PDF Studio"
            pdf.save(out)
            return pages
        }
    }

    // ------------------------------------------------------------------ XML helpers

    private fun parse(b: ByteArray) = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }
        .newDocumentBuilder().parse(ByteArrayInputStream(b))

    private fun kids(e: Element): List<Element> {
        val out = ArrayList<Element>()
        val n = e.childNodes
        for (i in 0 until n.length) { val c = n.item(i); if (c is Element) out.add(c) }
        return out
    }
    private fun Element.isW(name: String) = namespaceURI == W && localName == name
    private fun first(e: Element?, ns: String, name: String): Element? = e?.let { kids(it).firstOrNull { c -> c.namespaceURI == ns && c.localName == name } }
    private fun wAttr(e: Element?, name: String): String? = e?.getAttributeNS(W, name)?.takeIf { it.isNotEmpty() }
    private fun descendants(e: Element, ns: String, name: String): List<Element> {
        val nl = e.getElementsByTagNameNS(ns, name)
        return (0 until nl.length).map { nl.item(it) as Element }
    }
    private fun hex(s: String?): Int? = s?.takeIf { it.length == 6 && it != "auto" }?.toIntOrNull(16)

    /** Properties of an rPr / pPr element as simple name → value pairs (booleans as "1"/"0"). */
    private fun props(e: Element?): Map<String, String> {
        val m = HashMap<String, String>()
        if (e == null) return m
        for (c in kids(e)) {
            if (c.namespaceURI != W) continue
            when (c.localName) {
                "b", "i" -> m[c.localName] = if (wAttr(c, "val") in listOf("0", "false", "off")) "0" else "1"
                "u" -> m["u"] = if (wAttr(c, "val") in listOf(null, "none", "0")) (if (wAttr(c, "val") == null) "1" else "0") else "1"
                "sz" -> wAttr(c, "val")?.let { m["sz"] = it }
                "color" -> wAttr(c, "val")?.let { m["color"] = it }
                "rFonts" -> (wAttr(c, "ascii") ?: wAttr(c, "hAnsi"))?.let { m["font"] = it }
                "jc" -> wAttr(c, "val")?.let { m["jc"] = it }
                "spacing" -> {
                    wAttr(c, "before")?.let { m["before"] = it }
                    wAttr(c, "after")?.let { m["after"] = it }
                    wAttr(c, "line")?.let { m["line"] = it }
                    wAttr(c, "lineRule")?.let { m["lineRule"] = it }
                }
                "ind" -> {
                    (wAttr(c, "left") ?: wAttr(c, "start"))?.let { m["indL"] = it }
                    wAttr(c, "firstLine")?.let { m["indF"] = it }
                    wAttr(c, "hanging")?.let { m["indH"] = it }
                }
                "shd" -> wAttr(c, "fill")?.let { m["shd"] = it }
                "pageBreakBefore" -> m["pbb"] = "1"
                "numPr" -> {
                    wAttr(first(c, W, "numId"), "val")?.let { m["numId"] = it }
                    wAttr(first(c, W, "ilvl"), "val")?.let { m["ilvl"] = it }
                }
            }
        }
        return m
    }

    // ------------------------------------------------------------------ reading the document

    private class Ctx(val parts: Map<String, ByteArray>) {
        val styles = HashMap<String, StyleDef>()
        var defR: Map<String, String> = emptyMap()
        var defP: Map<String, String> = emptyMap()
        val numFmt = HashMap<String, Pair<String, String>>() // "numId:ilvl" -> (format, level text)
        val counters = HashMap<String, Int>()
        val rels = HashMap<String, String>()
        var pageW = 595.28f; var pageH = 841.89f
        var mL = 72f; var mR = 72f; var mT = 72f; var mB = 72f

        fun readStyles() {
            val b = parts["word/styles.xml"] ?: return
            val d = parse(b).documentElement
            first(d, W, "docDefaults")?.let { dd ->
                defR = props(first(first(dd, W, "rPrDefault"), W, "rPr"))
                defP = props(first(first(dd, W, "pPrDefault"), W, "pPr"))
            }
            for (s in kids(d).filter { it.isW("style") }) {
                val id = wAttr(s, "styleId") ?: continue
                val r = HashMap(props(first(s, W, "rPr")))
                val p = props(first(s, W, "pPr"))
                val name = wAttr(first(s, W, "name"), "val")?.lowercase() ?: ""
                // Built-in headings often carry their look only in the theme: give them one.
                val lvl = Regex("heading (\\d)").find(name)?.groupValues?.get(1)?.toIntOrNull()
                if (lvl != null || name == "title") {
                    if ("sz" !in r) r["sz"] = when (lvl) { null -> "52"; 1 -> "36"; 2 -> "30"; 3 -> "26"; else -> "24" }
                    if ("b" !in r) r["b"] = "1"
                }
                styles[id] = StyleDef(wAttr(first(s, W, "basedOn"), "val"), r, p)
            }
        }

        fun readNumbering() {
            val b = parts["word/numbering.xml"] ?: return
            val d = parse(b).documentElement
            val abs = HashMap<String, Map<String, Pair<String, String>>>()
            for (a in kids(d).filter { it.isW("abstractNum") }) {
                val id = wAttr(a, "abstractNumId") ?: continue
                abs[id] = kids(a).filter { it.isW("lvl") }.associate { l ->
                    (wAttr(l, "ilvl") ?: "0") to ((wAttr(first(l, W, "numFmt"), "val") ?: "bullet") to (wAttr(first(l, W, "lvlText"), "val") ?: "•"))
                }
            }
            for (n in kids(d).filter { it.isW("num") }) {
                val id = wAttr(n, "numId") ?: continue
                val a = wAttr(first(n, W, "abstractNumId"), "val") ?: continue
                abs[a]?.forEach { (lvl, v) -> numFmt["$id:$lvl"] = v }
            }
        }

        fun readRels() {
            val b = parts["word/_rels/document.xml.rels"] ?: return
            val d = parse(b).documentElement
            for (r in kids(d)) {
                if (r.localName != "Relationship") continue
                val id = r.getAttribute("Id"); val t = r.getAttribute("Target")
                if (id.isNotEmpty() && t.isNotEmpty() && r.getAttribute("TargetMode") != "External") {
                    rels[id] = if (t.startsWith("/")) t.trimStart('/') else "word/" + t.removePrefix("./")
                }
            }
        }

        fun readSection(body: Element) {
            val sp = first(body, W, "sectPr") ?: return
            first(sp, W, "pgSz")?.let { s ->
                wAttr(s, "w")?.toFloatOrNull()?.let { pageW = it / 20f }
                wAttr(s, "h")?.toFloatOrNull()?.let { pageH = it / 20f }
            }
            first(sp, W, "pgMar")?.let { m ->
                wAttr(m, "left")?.toFloatOrNull()?.let { mL = it / 20f }
                wAttr(m, "right")?.toFloatOrNull()?.let { mR = it / 20f }
                wAttr(m, "top")?.toFloatOrNull()?.let { mT = max(18f, it / 20f) }
                wAttr(m, "bottom")?.toFloatOrNull()?.let { mB = max(18f, it / 20f) }
            }
            if (pageW < 144f || pageH < 144f) { pageW = 595.28f; pageH = 841.89f }
        }

        private fun styleChain(id: String?): List<StyleDef> {
            val out = ArrayList<StyleDef>()
            var cur = id
            var guard = 0
            while (cur != null && guard++ < 12) {
                val s = styles[cur] ?: break
                out.add(0, s)
                cur = s.basedOn
            }
            return out
        }

        private fun merged(pStyle: String?, rStyle: String?, own: Map<String, String>): Map<String, String> {
            val m = HashMap(defR)
            styleChain(pStyle).forEach { m.putAll(it.r) }
            styleChain(rStyle).forEach { m.putAll(it.r) }
            m.putAll(own)
            return m
        }

        private fun rstyle(m: Map<String, String>): RStyle {
            val font = (m["font"] ?: "").lowercase()
            val fam = when {
                listOf("times", "cambria", "georgia", "garamond", "book", "serif", "minion", "palatino").any { font.contains(it) } && !font.contains("sans") -> Family.SERIF
                listOf("courier", "consolas", "mono", "lucida console").any { font.contains(it) } -> Family.MONO
                else -> Family.SANS
            }
            return RStyle(
                size = ((m["sz"]?.toFloatOrNull() ?: 22f) / 2f).coerceIn(4f, 96f),
                bold = m["b"] == "1", italic = m["i"] == "1", underline = m["u"] == "1",
                color = hex(m["color"]) ?: 0x000000, family = fam
            )
        }

        fun blocks(container: Element): List<Block> {
            val out = ArrayList<Block>()
            for (c in kids(container)) {
                when {
                    c.isW("p") -> paragraph(c, out)
                    c.isW("tbl") -> table(c)?.let { out.add(it) }
                    c.isW("sdt") -> first(c, W, "sdtContent")?.let { out.addAll(blocks(it)) }
                }
            }
            return out
        }

        private fun paragraph(p: Element, out: MutableList<Block>) {
            val pPr = first(p, W, "pPr")
            val pStyle = wAttr(first(pPr, W, "pStyle"), "val")
            val pp = HashMap(defP)
            styleChain(pStyle).forEach { pp.putAll(it.p) }
            pp.putAll(props(pPr))
            val align = when (pp["jc"]) { "center" -> 'C'; "right", "end" -> 'R'; "both", "distribute" -> 'J'; else -> 'L' }
            var indent = (pp["indL"]?.toFloatOrNull() ?: 0f) / 20f
            val first = ((pp["indF"]?.toFloatOrNull() ?: 0f) - (pp["indH"]?.toFloatOrNull() ?: 0f)) / 20f
            val before = (pp["before"]?.toFloatOrNull() ?: 0f) / 20f
            // Word's own defaults when the file doesn't say: no space after, single line spacing.
            val after = (pp["after"]?.toFloatOrNull() ?: 0f) / 20f
            val lineMul = if (pp["lineRule"] == null || pp["lineRule"] == "auto") ((pp["line"]?.toFloatOrNull() ?: 240f) / 240f).coerceIn(0.8f, 3f) else 1.0f
            val paraR = merged(pStyle, null, props(first(pPr, W, "rPr")))

            // List bullet or number.
            var prefix: Run? = null
            // The list can be set on the paragraph or come from its style (e.g. "List Bullet").
            if (pp["numId"] != null) {
                val numId = pp["numId"]
                val lvl = pp["ilvl"] ?: "0"
                if (numId != null && numId != "0") {
                    val (fmt, txt) = numFmt["$numId:$lvl"] ?: ("bullet" to "•")
                    val key = "$numId:$lvl"
                    // A new item at one level restarts the numbering of deeper levels.
                    counters.keys.filter { it.startsWith("$numId:") && (it.substringAfter(':').toIntOrNull() ?: 0) > (lvl.toIntOrNull() ?: 0) }.forEach { counters.remove(it) }
                    val n = (counters[key] ?: 0) + 1
                    counters[key] = n
                    val label = when (fmt) {
                        "bullet" -> if (txt.any { it.code in 0x20..0x7E || it == '•' || it == '–' }) txt.filter { it.code < 0xF000 }.ifBlank { "•" } else "•"
                        "lowerLetter" -> txt.replace(Regex("%\\d"), ('a' + (n - 1) % 26).toString())
                        "upperLetter" -> txt.replace(Regex("%\\d"), ('A' + (n - 1) % 26).toString())
                        "lowerRoman" -> txt.replace(Regex("%\\d"), roman(n).lowercase())
                        "upperRoman" -> txt.replace(Regex("%\\d"), roman(n))
                        else -> txt.replace(Regex("%(\\d)")) { mr ->
                            val l = (mr.groupValues[1].toIntOrNull() ?: 1) - 1
                            (counters["$numId:$l"] ?: if (l.toString() == lvl) n else 1).toString()
                        }
                    }
                    prefix = Run(label + "  ", rstyle(paraR))
                    if (indent == 0f) indent = 18f * ((lvl.toIntOrNull() ?: 0) + 1)
                }
            }

            val runs = ArrayList<Run>()
            var pageBreakBefore = pp["pbb"] == "1"
            fun flush(force: Boolean) {
                if (runs.isNotEmpty() || force || prefix != null) {
                    out.add(Para(ArrayList(runs), align, indent, first, before, after, lineMul, prefix, pageBreakBefore, hex(pp["shd"])))
                    runs.clear(); prefix = null; pageBreakBefore = false
                }
            }
            var any = false
            fun walk(e: Element) {
                for (c in kids(e)) {
                    if (c.namespaceURI != W) {
                        // Pictures can sit in mc:AlternateContent; look inside for a drawing.
                        if (c.localName == "AlternateContent") kids(c).firstOrNull()?.let { walk(it) }
                        continue
                    }
                    when (c.localName) {
                        "pPr", "del", "moveFrom", "rPr" -> Unit
                        "r" -> {
                            val rPr = first(c, W, "rPr")
                            val st = rstyle(merged(pStyle, wAttr(first(rPr, W, "rStyle"), "val"), props(rPr)))
                            for (k in kids(c)) {
                                if (k.namespaceURI != W) { if (k.localName == "AlternateContent") walk(k); continue }
                                when (k.localName) {
                                    "t" -> { runs.add(Run(k.textContent ?: "", st)); any = true }
                                    "tab" -> runs.add(Run("    ", st))
                                    "noBreakHyphen" -> runs.add(Run("-", st))
                                    "br", "cr" -> if (wAttr(k, "type") == "page") { flush(false); out.add(PageBreak) } else runs.add(Run("\n", st))
                                    "drawing", "pict" -> {
                                        val blip = descendants(k, A, "blip").firstOrNull()
                                        val rid = blip?.getAttributeNS(R, "embed")?.takeIf { it.isNotEmpty() }
                                            ?: descendants(k, "urn:schemas-microsoft-com:vml", "imagedata").firstOrNull()?.getAttributeNS(R, "id")
                                        val bytes = rid?.let { rels[it] }?.let { parts[it] }
                                        if (bytes != null) {
                                            val ext = descendants(k, WP, "extent").firstOrNull()
                                            val cx = ext?.getAttribute("cx")?.toFloatOrNull()?.div(12700f) ?: 200f
                                            val cy = ext?.getAttribute("cy")?.toFloatOrNull()?.div(12700f) ?: 150f
                                            flush(false)
                                            out.add(Img(bytes, cx, cy, align))
                                        }
                                    }
                                }
                            }
                        }
                        else -> walk(c) // hyperlink, ins, smartTag, fldSimple, sdt...
                    }
                }
            }
            walk(p)
            flush(force = !any)
        }

        private fun table(t: Element): Table? {
            val grid = first(t, W, "tblGrid")?.let { g -> kids(g).filter { it.isW("gridCol") }.map { (wAttr(it, "w")?.toFloatOrNull() ?: 0f) / 20f } } ?: emptyList()
            val rows = kids(t).filter { it.isW("tr") }.map { tr ->
                kids(tr).filter { it.isW("tc") }.map { tc ->
                    val tcPr = first(tc, W, "tcPr")
                    val span = wAttr(first(tcPr, W, "gridSpan"), "val")?.toIntOrNull() ?: 1
                    Cell(blocks(tc), span, hex(wAttr(first(tcPr, W, "shd"), "fill")))
                }
            }.filter { it.isNotEmpty() }
            if (rows.isEmpty()) return null
            val cols = max(grid.size, rows.maxOf { r -> r.sumOf { it.span } })
            val g = if (grid.size == cols && grid.all { it > 0f }) grid else List(cols) { 1f }
            return Table(g, rows)
        }
    }

    private fun roman(n: Int): String {
        var x = n
        val v = listOf(1000 to "M", 900 to "CM", 500 to "D", 400 to "CD", 100 to "C", 90 to "XC", 50 to "L", 40 to "XL", 10 to "X", 9 to "IX", 5 to "V", 4 to "IV", 1 to "I")
        return buildString { for ((k, s) in v) while (x >= k) { append(s); x -= k } }
    }

    // ------------------------------------------------------------------ layout and drawing

    private class Seg(val text: String, val s: RStyle, val chain: EditorRender.FontChain, var x: Float, val w: Float)
    private class Line(val segs: List<Seg>, val width: Float, val height: Float, val ascent: Float, val spaces: Int, val last: Boolean)

    private class Layout(val pdf: PDDocument, val c: Ctx, val image: (PDDocument, ByteArray) -> PDImageXObject?) {
        val cache = EditorRender.FontCache(pdf)
        var page: PDPage? = null
        var cs: PDPageContentStream? = null
        var y = 0f // distance from the top of the page
        var pages = 0
        val contentW = max(100f, c.pageW - c.mL - c.mR)
        val bottom get() = c.pageH - c.mB

        fun newPage() {
            cs?.close()
            val p = PDPage(PDRectangle(c.pageW, c.pageH))
            pdf.addPage(p)
            page = p
            cs = PDPageContentStream(pdf, p)
            y = c.mT
            pages++
        }

        fun chainFor(s: RStyle, text: String): EditorRender.FontChain {
            val primary = cache.writer(EditorRender.standardFont(TStyle(s.size, s.bold, s.italic, s.family, s.color)))
            if (primary.canDraw(text.replace("\n", ""))) return EditorRender.FontChain(primary, null)
            val uni = cache.unicodeFor(text)?.let { cache.writer(it) }
            return EditorRender.FontChain(primary, uni)
        }

        fun run(blocks: List<Block>): Int {
            newPage()
            for (b in blocks) block(b, c.mL, contentW)
            cs?.close()
            return pages
        }

        fun block(b: Block, x0: Float, width: Float) {
            when (b) {
                is PageBreak -> newPage()
                is Para -> para(b, x0, width, draw = true)
                is Img -> img(b, x0, width)
                is Table -> table(b, x0, width)
            }
        }

        /** Splits a paragraph into lines that fit [width]. */
        fun lines(p: Para, width: Float): List<Line> {
            val tokens = ArrayList<Pair<String, RStyle>>()
            p.prefix?.let { tokens.add(it.text to it.s) }
            for (r in p.runs) {
                var buf = StringBuilder()
                for (ch in r.text) {
                    when (ch) {
                        '\n' -> { if (buf.isNotEmpty()) tokens.add(buf.toString() to r.s); tokens.add("\n" to r.s); buf = StringBuilder() }
                        ' ' -> { if (buf.isNotEmpty()) tokens.add(buf.toString() to r.s); tokens.add(" " to r.s); buf = StringBuilder() }
                        else -> buf.append(ch)
                    }
                }
                if (buf.isNotEmpty()) tokens.add(buf.toString() to r.s)
            }
            val baseSize = (p.runs.firstOrNull()?.s?.size ?: p.prefix?.s?.size ?: 11f)
            val out = ArrayList<Line>()
            var cur = ArrayList<Seg>()
            var curW = 0f
            var firstLine = true
            fun avail() = width - p.indent - (if (firstLine) p.firstIndent else 0f)
            fun close(last: Boolean) {
                while (cur.isNotEmpty() && cur.last().text == " ") { curW -= cur.last().w; cur.removeAt(cur.size - 1) }
                val maxSize = cur.maxOfOrNull { it.s.size } ?: baseSize
                out.add(Line(cur, curW, maxSize * 1.17f * p.lineMul, maxSize * 0.93f, cur.count { it.text == " " }, last))
                cur = ArrayList(); curW = 0f; firstLine = false
            }
            for ((t, s) in tokens) {
                if (t == "\n") { close(true); continue }
                if (t == " " && cur.isEmpty()) continue
                val ch = chainFor(s, t)
                val clean = ch.clean(t)
                if (clean.isEmpty()) continue
                var w = ch.width(clean, s.size)
                if (curW + w > avail() && cur.isNotEmpty() && t != " ") close(false)
                // A single word wider than the line is cut into pieces.
                var piece = clean
                while (w > avail() && piece.length > 1) {
                    var k = piece.length - 1
                    while (k > 1 && ch.width(piece.substring(0, k), s.size) > avail()) k--
                    val head = piece.substring(0, k)
                    cur.add(Seg(head, s, ch, 0f, ch.width(head, s.size))); curW += cur.last().w
                    close(false)
                    piece = piece.substring(k)
                    w = ch.width(piece, s.size)
                }
                cur.add(Seg(piece, s, ch, 0f, w))
                curW += w
            }
            if (cur.isNotEmpty() || out.isEmpty()) close(true)
            else out[out.size - 1] = out.last().let { Line(it.segs, it.width, it.height, it.ascent, it.spaces, true) }
            return out
        }

        /** Lays out (and draws if [draw]) a paragraph at the current position. Returns its height. */
        fun para(p: Para, x0: Float, width: Float, draw: Boolean, measureOnly: Boolean = false, top: Float = y): Float {
            if (p.pageBreakBefore && draw && !measureOnly && y > c.mT + 1f) newPage()
            val ls = lines(p, width)
            if (measureOnly) return p.before + ls.sumOf { it.height.toDouble() }.toFloat() + p.after
            var ty = top + p.before
            if (draw) y = ty
            for ((i, l) in ls.withIndex()) {
                if (draw && y + l.height > bottom && y > c.mT + 1f) { newPage(); ty = y }
                val ind = p.indent + if (i == 0) p.firstIndent else 0f
                val avail = width - ind
                val startX = x0 + ind + when (p.align) { 'C' -> (avail - l.width) / 2; 'R' -> avail - l.width; else -> 0f }
                val extra = if (p.align == 'J' && !l.last && l.spaces > 0) (avail - l.width) / l.spaces else 0f
                p.shade?.let { if (draw) fillRect(x0, ty, width, l.height, it) }
                drawLine(l, startX, ty + l.ascent, extra)
                ty += l.height
                if (draw) y = ty
            }
            ty += p.after
            if (draw) y = ty
            return ty - top
        }

        fun drawLine(l: Line, x: Float, baselineFromTop: Float, extraPerSpace: Float) {
            val s = cs ?: return
            var cx = x
            val by = c.pageH - baselineFromTop
            for (g in l.segs) {
                if (g.text == " ") { cx += g.w + extraPerSpace; continue }
                val col = g.s.color
                s.setNonStrokingColor(((col shr 16) and 255) / 255f, ((col shr 8) and 255) / 255f, (col and 255) / 255f)
                s.beginText()
                s.newLineAtOffset(cx, by)
                for ((f, t) in g.chain.runs(g.text)) {
                    s.setFont(f.font, g.s.size)
                    f.show(s, t)
                }
                s.endText()
                if (g.s.underline) {
                    s.setStrokingColor(((col shr 16) and 255) / 255f, ((col shr 8) and 255) / 255f, (col and 255) / 255f)
                    s.setLineWidth(max(0.5f, g.s.size * 0.06f))
                    s.moveTo(cx, by - g.s.size * 0.12f); s.lineTo(cx + g.w, by - g.s.size * 0.12f); s.stroke()
                }
                cx += g.w
            }
        }

        fun fillRect(x: Float, top: Float, w: Float, h: Float, color: Int) {
            val s = cs ?: return
            s.setNonStrokingColor(((color shr 16) and 255) / 255f, ((color shr 8) and 255) / 255f, (color and 255) / 255f)
            s.addRect(x, c.pageH - top - h, w, h)
            s.fill()
        }

        fun img(b: Img, x0: Float, width: Float) {
            val im = try { image(pdf, b.bytes) } catch (e: Throwable) { null } ?: return
            var w = b.w; var h = b.h
            val maxH = c.pageH - c.mT - c.mB
            val k = min(1f, min(width / w, maxH / h))
            w *= k; h *= k
            if (y + h > bottom && y > c.mT + 1f) newPage()
            val x = x0 + when (b.align) { 'C' -> (width - w) / 2; 'R' -> width - w; else -> 0f }
            cs?.drawImage(im, x, c.pageH - y - h, w, h)
            y += h + 4f
        }

        fun table(t: Table, x0: Float, width: Float) {
            val total = t.grid.sum()
            val scale = if (total > width || total <= 0f) width / max(1f, total) else 1f
            val cols = t.grid.map { it * scale }
            val pad = 4f
            for (row in t.rows) {
                // Cell widths from the grid columns each cell spans.
                var gi = 0
                val cells = row.map { cell ->
                    val w = cols.subList(min(gi, cols.size), min(gi + cell.span, cols.size)).sum().let { if (it <= 0f) width / row.size else it }
                    val x = x0 + cols.subList(0, min(gi, cols.size)).sum()
                    gi += cell.span
                    Triple(cell, x, w)
                }
                fun cellHeight(cell: Cell, w: Float): Float = cell.blocks.sumOf { b ->
                    when (b) {
                        is Para -> para(b.copyTight(), 0f, w - 2 * pad, draw = false, measureOnly = true).toDouble()
                        is Img -> (b.h * min(1f, (w - 2 * pad) / b.w)).toDouble()
                        is Table -> 14.0 * b.rows.size
                        else -> 0.0
                    }
                }.toFloat() + 2 * pad
                val h = max(14f, cells.maxOf { (cell, _, w) -> cellHeight(cell, w) })
                if (y + h > bottom && y > c.mT + 1f) newPage()
                val top = y
                for ((cell, x, w) in cells) {
                    cell.shade?.let { fillRect(x, top, w, h, it) }
                    var cy = top + pad
                    for (b in cell.blocks) {
                        when (b) {
                            is Para -> { val tight = b.copyTight(); cy += para(tight, x + pad, w - 2 * pad, draw = false, top = cy) }
                            is Img -> {
                                val im = try { image(pdf, b.bytes) } catch (e: Throwable) { null }
                                if (im != null) {
                                    val k = min(1f, (w - 2 * pad) / b.w); val iw = b.w * k; val ih = b.h * k
                                    cs?.drawImage(im, x + pad, c.pageH - cy - ih, iw, ih); cy += ih
                                }
                            }
                            else -> Unit
                        }
                    }
                }
                // Borders.
                cs?.let { s ->
                    s.setStrokingColor(0.55f, 0.55f, 0.55f); s.setLineWidth(0.5f)
                    for ((_, x, w) in cells) s.addRect(x, c.pageH - top - h, w, h)
                    s.stroke()
                }
                y = top + h
            }
            y += 8f
        }

        private fun Para.copyTight() = Para(runs, align, indent, firstIndent, before, min(after, 2f), lineMul, prefix, false, shade)
    }
}
