@file:OptIn(ExperimentalMaterial3Api::class)

package com.aipdfstudio.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Summarize
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aipdfstudio.app.data.RecentFile
import android.net.Uri

private val languages = listOf(
    "Hindi", "Spanish", "French", "German", "Arabic", "Portuguese",
    "Chinese", "Japanese", "Russian", "Indonesian"
)

@Composable
fun AiScreen(vm: AiViewModel, recents: List<RecentFile>, onPickFile: () -> Unit, onSettings: () -> Unit) {
    LaunchedEffect(Unit) { vm.refreshKey() }
    val cs = MaterialTheme.colorScheme

    Scaffold(
        containerColor = cs.background,
        contentWindowInsets = WindowInsets.statusBars,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("AI studio", fontWeight = FontWeight.Medium)
                        Text(
                            "Gemini",
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.onPrimaryContainer,
                            modifier = Modifier.padding(start = 8.dp)
                                .background(cs.primaryContainer, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Outlined.Settings, contentDescription = "AI settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            when {
                !vm.hasKey -> KeySetupCard(onSettings)
                vm.docUri == null -> DocPicker(recents, vm, onPickFile)
                else -> Chat(vm, onPickFile)
            }
        }
    }
}

@Composable
private fun KeySetupCard(onSettings: () -> Unit) {
    Card(
        modifier = Modifier.padding(16.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        )
    ) {
        Column(Modifier.padding(20.dp)) {
            Icon(Icons.Outlined.Key, contentDescription = null)
            Spacer(Modifier.height(10.dp))
            Text("Add your free Gemini key", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text(
                "AI features run on your own Google AI Studio key, so they cost you nothing to start. " +
                    "Get a key, paste it in settings, and test it. It takes about a minute.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onSettings) { Text("Set up key") }
        }
    }
}

@Composable
private fun DocPicker(recents: List<RecentFile>, vm: AiViewModel, onPickFile: () -> Unit) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Choose a document", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
        Text(
            "Pick a PDF to summarize, translate, or ask questions about.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(4.dp))
        recents.take(4).forEach { f ->
            Surface(
                onClick = { vm.setDocument(Uri.parse(f.uri), f.name) },
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceContainer
            ) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.PictureAsPdf, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Text(
                        f.name,
                        modifier = Modifier.padding(start = 12.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Button(onClick = onPickFile) { Text("Open another PDF") }
    }
}

@Composable
private fun ColumnScope.Chat(vm: AiViewModel, onPickFile: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var input by remember { mutableStateOf("") }
    var langMenu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val total = vm.messages.size + if (vm.busy) 1 else 0

    LaunchedEffect(total) {
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = cs.surfaceContainer,
        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()
    ) {
        Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp, end = 0.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.PictureAsPdf, contentDescription = null, tint = cs.error, modifier = Modifier.size(22.dp))
            Text(
                vm.docName,
                modifier = Modifier.weight(1f).padding(start = 10.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
            IconButton(onClick = { vm.clearDocument() }) {
                Icon(Icons.Outlined.Close, contentDescription = "Choose a different document")
            }
        }
    }

    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AssistChip(
            onClick = {
                vm.ask(
                    "Summarize",
                    "Summarize this document in a short overview of 3 to 5 sentences, then list the key points as bullets."
                )
            },
            label = { Text("Summarize") },
            leadingIcon = { Icon(Icons.Outlined.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp)) },
            shape = RoundedCornerShape(12.dp)
        )
        AssistChip(
            onClick = { vm.ask("Key points", "List the 6 to 8 most important points of this document as short bullets.") },
            label = { Text("Key points") },
            leadingIcon = { Icon(Icons.Outlined.Summarize, contentDescription = null, modifier = Modifier.size(18.dp)) },
            shape = RoundedCornerShape(12.dp)
        )
        Box {
            AssistChip(
                onClick = { langMenu = true },
                label = { Text("Translate") },
                leadingIcon = { Icon(Icons.Outlined.Translate, contentDescription = null, modifier = Modifier.size(18.dp)) },
                shape = RoundedCornerShape(12.dp)
            )
            DropdownMenu(expanded = langMenu, onDismissRequest = { langMenu = false }) {
                languages.forEach { lang ->
                    DropdownMenuItem(
                        text = { Text(lang) },
                        onClick = {
                            langMenu = false
                            vm.ask(
                                "Translate to $lang",
                                "Translate the main content of this document into $lang. Keep the structure. " +
                                    "If the document is very long, translate the first part and say that you did."
                            )
                        }
                    )
                }
            }
        }
    }

    Box(Modifier.weight(1f).fillMaxWidth()) {
        if (vm.messages.isEmpty() && !vm.busy) {
            Text(
                "Tap Summarize, or ask a question about this document.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(32.dp)
            )
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vm.messages) { m -> Bubble(m) }
                if (vm.busy) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                            Text("Thinking…", modifier = Modifier.padding(start = 10.dp), color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    Row(
        Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Ask about this document") },
            maxLines = 3,
            shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedContainerColor = cs.surfaceContainer,
                unfocusedContainerColor = cs.surfaceContainer
            )
        )
        Spacer(Modifier.size(8.dp))
        FilledIconButton(
            onClick = {
                val q = input.trim()
                if (q.isNotEmpty() && !vm.busy) {
                    vm.ask(q, q)
                    input = ""
                }
            }
        ) { Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "Send") }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val cs = MaterialTheme.colorScheme
    val bg = when {
        m.fromUser -> cs.primary
        m.isError -> cs.errorContainer
        else -> cs.surfaceContainer
    }
    val fg = when {
        m.fromUser -> cs.onPrimary
        m.isError -> cs.onErrorContainer
        else -> cs.onSurface
    }
    val shape = if (m.fromUser) RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp)
    else RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(shape = shape, color = bg, contentColor = fg, modifier = Modifier.widthIn(max = 320.dp)) {
            SelectionContainer {
                Text(m.text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
