package com.aipdfstudio.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.ConvertOps
import com.aipdfstudio.app.data.Outputs

private enum class ConvertMode(val title: String, val sub: String) {
    IMAGES_TO_PDF("Images to PDF", "Turn photos into one PDF"),
    WORD_TO_PDF("Word to PDF", ".docx to PDF with text, lists, tables and pictures"),
    PDF_TO_WORD("PDF to Word", "Editable .docx with the text (no layout or pictures)"),
    PDF_TO_JPG("PDF to images", "Save every page as a JPG"),
    LONG_IMAGE("PDF to long image", "All pages in one tall picture, easy to share"),
    PDF_TO_TEXT("PDF to text", "Plain .txt file you can copy from")
}

@Composable
fun ConvertScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel(), startMode: String? = null, initial: Uri? = null) {
    val ctx = LocalContext.current
    val first = ConvertMode.entries.firstOrNull { it.name == startMode } ?: ConvertMode.IMAGES_TO_PDF
    var mode by rememberSaveable { mutableStateOf(first) }
    var docx by rememberSaveable { mutableStateOf(if (first == ConvertMode.WORD_TO_PDF) initial else null) }
    if (first != ConvertMode.WORD_TO_PDF && first != ConvertMode.IMAGES_TO_PDF) Preselect(vm, initial)
    val docxPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { docx = uri; vm.clearOutcome() }
    }
    fun kindOf(m: ConvertMode) = when (m) { ConvertMode.IMAGES_TO_PDF -> 0; ConvertMode.WORD_TO_PDF -> 1; else -> 2 }
    var a4 by rememberSaveable { mutableStateOf(true) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.addImages(uris)
    }
    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri), replace = true)
    }
    val pickImages = { imagePicker.launch(arrayOf("image/*")) }

    val images = mode == ConvertMode.IMAGES_TO_PDF
    val word = mode == ConvertMode.WORD_TO_PDF
    val p = vm.single
    val pdfReady = !images && !word && p != null && !p.locked && !p.broken
    val ready = when { images -> vm.files.isNotEmpty(); word -> docx != null; else -> pdfReady }

    ToolPage(
        title = "Convert",
        vm = vm,
        onBack = onBack,
        actionLabel = when {
            images && vm.files.isEmpty() -> "Add photos"
            images -> "Make PDF from ${vm.files.size} image${if (vm.files.size == 1) "" else "s"}"
            word && docx == null -> "Choose a Word file"
            word -> "Convert to PDF"
            p == null -> "Choose a PDF"
            else -> "Convert"
        },
        actionEnabled = ready,
        onAction = act@{
            when (mode) {
                ConvertMode.IMAGES_TO_PDF -> {
                    val list = vm.files.map { it.uri }
                    val first = vm.files.firstOrNull()?.name ?: "Images"
                    val fit = a4
                    vm.run("Making PDF…") { progress ->
                        val out = Outputs.newFile(ctx, first, "images")
                        ConvertOps.imagesToPdf(ctx, list, fit, out, progress)
                        listOf(out) to null
                    }
                }
                ConvertMode.WORD_TO_PDF -> {
                    val src = docx ?: return@act
                    val name = com.aipdfstudio.app.data.queryName(ctx, src)
                    vm.run("Making PDF from Word…") {
                        val out = Outputs.newFile(ctx, name.replace(Regex("\\.(docx?|rtf)$", RegexOption.IGNORE_CASE), ""), "")
                        val pages = ctx.contentResolver.openInputStream(src)?.use { input ->
                            com.aipdfstudio.app.data.WordToPdf.convert(input, out, com.aipdfstudio.app.data.WordImages.maker())
                        } ?: throw com.aipdfstudio.app.data.UserError("Couldn't open the Word file")
                        listOf(out) to "Made a $pages-page PDF. Text boxes, columns and headers are simplified."
                    }
                }
                ConvertMode.LONG_IMAGE -> {
                    val src = p ?: return@act
                    vm.run("Making long image…") { progress ->
                        val out = Outputs.newFile(ctx, src.name, "long", "jpg")
                        com.aipdfstudio.app.data.LongImage.make(ctx, src.uri, out, progress)
                        listOf(out) to "All pages are in one tall picture."
                    }
                }
                ConvertMode.PDF_TO_JPG -> {
                    val src = p ?: return@act
                    vm.run("Saving pages as images…") { progress ->
                        ConvertOps.pdfToImages(ctx, src.uri, src.name, progress) to null
                    }
                }
                ConvertMode.PDF_TO_WORD -> {
                    val src = p ?: return@act
                    vm.run("Making Word file…") {
                        val out = Outputs.newFile(ctx, src.name, "", "docx")
                        ConvertOps.pdfToWord(ctx, src.uri, out)
                        listOf(out) to "Word file made from the PDF's text. Pictures and exact layout aren't copied."
                    }
                }
                ConvertMode.PDF_TO_TEXT -> {
                    val src = p ?: return@act
                    vm.run("Reading text…") {
                        val out = Outputs.newFile(ctx, src.name, "", "txt")
                        val text = ConvertOps.pdfToText(ctx, src.uri, out)
                        vm.postText(text)
                        listOf(out) to null
                    }
                }
            }
        }
    ) {
        item(key = "modeTitle") {
            Text("What do you want to convert?", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
        }
        ConvertMode.entries.forEach { m ->
            item(key = "mode_" + m.name) {
                ChoiceRow(m.title, m.sub, mode == m) {
                    if (mode != m) {
                        val changedKind = kindOf(mode) != kindOf(m)
                        mode = m
                        if (changedKind) vm.clearFiles() else vm.clearOutcome()
                    }
                }
            }
        }
        if (images) {
            item(key = "imgTitle") {
                Text("Photos (in page order)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            }
            if (vm.files.isEmpty()) {
                item(key = "pickImg") { PickedCard(null, vm.loading, pickImages) }
            } else {
                itemsIndexed(vm.files, key = { _, f -> f.uri.toString() }) { i, f ->
                    FileRow(
                        f.copy(pages = 1),
                        leading = {
                            Column {
                                IconButton(onClick = { vm.move(i, -1) }, enabled = i > 0, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Outlined.KeyboardArrowUp, contentDescription = "Move up")
                                }
                                IconButton(onClick = { vm.move(i, 1) }, enabled = i < vm.files.size - 1, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = "Move down")
                                }
                            }
                            Spacer(Modifier.width(4.dp))
                        },
                        trailing = {
                            IconButton(onClick = { vm.removeAt(i) }) { Icon(Icons.Outlined.Close, contentDescription = "Remove") }
                        }
                    )
                }
                item(key = "addImg") {
                    OutlinedButton(onClick = pickImages, enabled = !vm.loading, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Outlined.Add, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Add more photos")
                    }
                }
            }
            item(key = "size1") { ChoiceRow("A4 pages", "Photo centred on a standard A4 page", a4) { a4 = true; vm.clearOutcome() } }
            item(key = "size2") { ChoiceRow("Same shape as the photo", "No white border", !a4) { a4 = false; vm.clearOutcome() } }
        } else if (word) {
            item(key = "docx") {
                val d = docx
                OutlinedButton(
                    onClick = { docxPicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (d == null) "Choose a Word file (.docx)" else com.aipdfstudio.app.data.queryName(ctx, d), maxLines = 1)
                }
            }
        } else {
            item(key = "pdf") { PickedCard(p, vm.loading) { pdfPicker.launch(arrayOf("application/pdf")) } }
            if (p != null && p.locked) {
                item(key = "locked") { MessageCard("This PDF is password protected. Unlock it first with the Unlock tool.", isError = true) }
            }
        }
        outcome(vm, onOpen)
    }
}
