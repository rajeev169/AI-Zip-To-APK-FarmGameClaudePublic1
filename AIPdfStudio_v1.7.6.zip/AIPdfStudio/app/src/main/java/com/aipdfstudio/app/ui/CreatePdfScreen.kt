package com.aipdfstudio.app.ui

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.CropLandscape
import androidx.compose.material.icons.outlined.CropPortrait
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aipdfstudio.app.data.CreatePdf
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PageColors
import com.aipdfstudio.app.data.PageSize
import com.aipdfstudio.app.data.PageStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Create PDF: page style, file name, size, colour, orientation and page count, then Create. */
@Composable
fun CreatePdfScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var style by rememberSaveable { mutableStateOf(PageStyle.BLANK) }
    var name by rememberSaveable { mutableStateOf("AIPDF_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())) }
    var size by rememberSaveable { mutableStateOf(PageSize.A4) }
    var color by rememberSaveable { mutableIntStateOf(PageColors[0]) }
    var landscape by rememberSaveable { mutableStateOf(false) }
    var count by rememberSaveable { mutableIntStateOf(1) }
    var editName by remember { mutableStateOf(false) }
    var showSizes by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    Scaffold(containerColor = cs.background, contentWindowInsets = WindowInsets.statusBars) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
                Text("Create PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Text("Page style", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 10.dp))
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PageStyle.entries.forEach { s ->
                        Column(Modifier.weight(1f).clickable { style = s }, horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.fillMaxWidth().height(92.dp)
                                    .background(Color(0xFF000000.toInt() or color), RoundedCornerShape(8.dp))
                                    .border(if (style == s) 2.dp else 1.5.dp, if (style == s) cs.primary else Color(0xFFD9DEDC), RoundedCornerShape(8.dp))
                            ) {
                                StylePreview(s)
                                if (style == s) Box(
                                    Modifier.align(Alignment.BottomEnd).padding(4.dp).size(18.dp).background(cs.primary, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Outlined.Check, contentDescription = "Selected", tint = cs.onPrimary, modifier = Modifier.size(13.dp)) }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(s.label, fontSize = 12.5.sp, color = if (style == s) cs.primary else cs.outline, fontWeight = if (style == s) FontWeight.SemiBold else FontWeight.Normal)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                OptionRow("File name") {
                    Row(Modifier.clickable { editName = true }, verticalAlignment = Alignment.CenterVertically) {
                        Text("$name.pdf", fontSize = 13.5.sp, maxLines = 1)
                        Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = cs.outline, modifier = Modifier.size(18.dp))
                    }
                }
                OptionRow("Page size") {
                    Box {
                        Row(Modifier.clickable { showSizes = true }, verticalAlignment = Alignment.CenterVertically) {
                            Text(size.label, fontSize = 13.5.sp)
                            Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = cs.outline, modifier = Modifier.size(18.dp))
                        }
                        DropdownMenu(expanded = showSizes, onDismissRequest = { showSizes = false }) {
                            PageSize.entries.forEach { s -> DropdownMenuItem(text = { Text(s.label) }, onClick = { size = s; showSizes = false }) }
                        }
                    }
                }
                OptionRow("Page colour") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PageColors.forEach { c ->
                            Box(
                                Modifier.size(24.dp).background(Color(0xFF000000.toInt() or c), RoundedCornerShape(5.dp))
                                    .border(1.dp, Color(0xFFD0D6D4), RoundedCornerShape(5.dp)).clickable { color = c },
                                contentAlignment = Alignment.Center
                            ) { if (color == c) Icon(Icons.Outlined.Check, contentDescription = "Selected", tint = Color(0xFF1B1F1E), modifier = Modifier.size(15.dp)) }
                        }
                    }
                }
                OptionRow("Orientation") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(false to Icons.Outlined.CropPortrait, true to Icons.Outlined.CropLandscape).forEach { (l, icon) ->
                            Box(
                                Modifier.size(32.dp).background(if (landscape == l) cs.primaryContainer else Color.Transparent, RoundedCornerShape(7.dp)).clickable { landscape = l },
                                contentAlignment = Alignment.Center
                            ) { Icon(icon, contentDescription = if (l) "Landscape" else "Portrait", tint = if (landscape == l) cs.primary else cs.onSurfaceVariant) }
                        }
                    }
                }
                OptionRow("Page count") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { if (count > 1) count-- }, enabled = count > 1) { Icon(Icons.Outlined.Remove, contentDescription = "Fewer pages") }
                        Text("$count", fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        IconButton(onClick = { if (count < 500) count++ }) { Icon(Icons.Outlined.Add, contentDescription = "More pages") }
                    }
                }
            }
            Button(
                onClick = {
                    busy = true
                    scope.launch {
                        val out = withContext(Dispatchers.IO) {
                            try {
                                val f = Outputs.newFile(ctx, name, "")
                                CreatePdf.make(f, style, size, color, landscape, count)
                                f
                            } catch (e: Throwable) {
                                null
                            }
                        }
                        busy = false
                        if (out == null) Toast.makeText(ctx, "Couldn't create the PDF", Toast.LENGTH_LONG).show()
                        else onOpen(Outputs.uri(ctx, out))
                    }
                },
                enabled = !busy,
                shape = RoundedCornerShape(25.dp),
                modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 18.dp).height(50.dp)
            ) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = cs.onPrimary, strokeWidth = 2.dp) else Text("Create", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        }
    }

    if (editName) {
        var n by remember { mutableStateOf(name) }
        AlertDialog(
            onDismissRequest = { editName = false },
            title = { Text("File name") },
            text = { OutlinedTextField(value = n, onValueChange = { n = it.take(80) }, singleLine = true, suffix = { Text(".pdf") }) },
            confirmButton = { TextButton(onClick = { if (n.isNotBlank()) name = n.trim().removeSuffix(".pdf"); editName = false }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { editName = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun OptionRow(label: String, content: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        content()
    }
}

/** Small drawing of each paper style for the style picker. */
@Composable
private fun StylePreview(s: PageStyle) {
    Canvas(Modifier.fillMaxSize().padding(5.dp)) {
        val w = size.width; val h = size.height
        when (s) {
            PageStyle.BLANK -> Unit
            PageStyle.LINE -> { var y = 11f.dp.toPx(); while (y < h) { drawLine(Color(0xFFD9DEDC), Offset(0f, y), Offset(w, y), 1.5f); y += 11.dp.toPx() } }
            PageStyle.GRID -> grid(w, h, 9.dp.toPx(), Color(0xFFD9DEDC), 1.2f)
            PageStyle.GRAPH -> { grid(w, h, 4.5f.dp.toPx(), Color(0xFFE6EAE8), 0.8f); grid(w, h, 18.dp.toPx(), Color(0xFFC9CFCD), 1.3f) }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.grid(w: Float, h: Float, step: Float, c: Color, lw: Float) {
    var x = 0f
    while (x <= w) { drawLine(c, Offset(x, 0f), Offset(x, h), lw); x += step }
    var y = 0f
    while (y <= h) { drawLine(c, Offset(0f, y), Offset(w, y), lw); y += step }
}
