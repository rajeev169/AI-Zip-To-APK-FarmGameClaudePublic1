@file:OptIn(ExperimentalMaterial3Api::class)

package com.aipdfstudio.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FitScreen
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.Compress
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.RotateRight
import androidx.compose.material.icons.automirrored.outlined.HelpOutline
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.BorderColor
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.CropSquare
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Done
import androidx.compose.material.icons.outlined.Draw
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.FontDownload
import androidx.compose.material.icons.outlined.FormatBold
import androidx.compose.material.icons.outlined.FormatItalic
import androidx.compose.material.icons.outlined.FormatStrikethrough
import androidx.compose.material.icons.outlined.FormatUnderlined
import androidx.compose.material.icons.outlined.Gesture
import androidx.compose.material.icons.outlined.HorizontalRule
import androidx.compose.material.icons.outlined.NorthEast
import androidx.compose.material.icons.outlined.OpenWith
import androidx.compose.material.icons.outlined.TextDecrease
import androidx.compose.material.icons.outlined.TextFields
import androidx.compose.material.icons.outlined.TextIncrease
import androidx.compose.material.icons.outlined.Title
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.EdObj
import com.aipdfstudio.app.data.FBox
import com.aipdfstudio.app.data.Family
import com.aipdfstudio.app.data.ImageObj
import com.aipdfstudio.app.data.InkObj
import com.aipdfstudio.app.data.MarkKind
import com.aipdfstudio.app.data.MarkObj
import com.aipdfstudio.app.data.NoteObj
import com.aipdfstudio.app.data.ParaObj
import com.aipdfstudio.app.data.ShapeKind
import com.aipdfstudio.app.data.ShapeObj
import com.aipdfstudio.app.data.SigInk
import com.aipdfstudio.app.data.Signatures
import java.io.File
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.OpenInFull
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import com.aipdfstudio.app.data.TStyle
import com.aipdfstudio.app.data.TextObj
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private fun col(c: Int, alpha: Float = 1f) = Color(0xFF000000.toInt() or c).copy(alpha = alpha)

private fun family(f: Family) = when (f) {
    Family.SERIF -> FontFamily.Serif
    Family.MONO -> FontFamily.Monospace
    Family.SANS -> FontFamily.SansSerif
}

/** Compose text style matching a PDF style, with [pxPerPt] screen pixels per PDF point. */
private fun textStyle(s: TStyle, pxPerPt: Float, lineGapPt: Float, density: Density) = with(density) {
    TextStyle(
        fontFamily = family(s.family),
        fontWeight = if (s.bold) FontWeight.Bold else FontWeight.Normal,
        fontStyle = if (s.italic) FontStyle.Italic else FontStyle.Normal,
        fontSize = (s.sizePt * pxPerPt).toSp(),
        lineHeight = (lineGapPt * pxPerPt).toSp(),
        color = col(s.color)
    )
}

private const val MIN_Z = 1f
private const val MAX_Z = 4f

@Composable
fun EditorScreen(
    uri: Uri,
    onClose: () -> Unit,
    onOpenTool: (route: String, uri: Uri) -> Unit,
    vm: EditorVm = viewModel()
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(uri) { vm.open(uri) }

    var zoom by remember { mutableFloatStateOf(1f) }
    var gesture by remember { mutableFloatStateOf(1f) }
    var pivot by remember { mutableStateOf(Offset.Zero) }
    var viewport by remember { mutableStateOf(IntSize(1, 1)) }
    val zoomNow by rememberUpdatedState(zoom)
    val listState = rememberLazyListState()
    val hScroll = rememberScrollState()

    var confirmLeave by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showMore by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var showSaveMenu by remember { mutableStateOf(false) }
    var showSigPad by remember { mutableStateOf(false) }
    var noteEdit by remember { mutableStateOf<NoteObj?>(null) }
    var hint by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch {
            val path = withContext(Dispatchers.IO) { vm.copyImage(u) }
            vm.pendingImage = path
            vm.tool = EdTool.INSERT_IMAGE
            if (path != null) hint = "Tap the page where the picture should go"
        }
    }

    fun leave(action: () -> Unit) {
        vm.setSelected(null)
        if (vm.dirty) confirmLeave = action else action()
    }
    BackHandler { leave(onClose) }

    // Hints like the "Tap any content to edit" bubble.
    LaunchedEffect(vm.mode, vm.tool) {
        hint = when (vm.tool) {
            EdTool.EDIT_TEXT -> "Tap any content to edit"
            EdTool.INSERT_TEXT, EdTool.FILL_TEXT -> "Tap where the text should go"
            EdTool.HIGHLIGHT, EdTool.UNDERLINE, EdTool.STRIKE -> "Drag over the text. Use two fingers to scroll."
            EdTool.PEN -> "Draw with one finger. Use two fingers to scroll."
            EdTool.RECT, EdTool.OVAL, EdTool.LINE, EdTool.ARROW -> "Drag to draw. Use two fingers to scroll."
            EdTool.NOTE -> "Tap to add a note"
            EdTool.SIGN -> "Tap the page to place your signature"
            EdTool.CHECK, EdTool.CROSS, EdTool.DOT, EdTool.DATE -> "Tap where it should go"
            EdTool.INSERT_IMAGE -> if (vm.pendingImage == null) null else "Tap the page where the picture should go"
        }
    }
    LaunchedEffect(hint) { if (hint != null) { delay(2600); hint = null } }
    LaunchedEffect(vm.toast) { if (vm.toast != null) { delay(2600); vm.toast = null } }
    // A new sticky note asks for its text.
    val sel = vm.selected
    LaunchedEffect(sel?.id) { if (sel is NoteObj && sel.text.isBlank()) noteEdit = sel }

    fun commitZoom(factor: Float, focus: Offset) {
        val old = zoomNow
        val new = (old * factor).coerceIn(MIN_Z, MAX_Z)
        gesture = 1f
        val f = new / old
        if (abs(f - 1f) < 0.01f) return
        val index = listState.firstVisibleItemIndex
        val off = listState.firstVisibleItemScrollOffset
        val hx = hScroll.value
        zoom = new
        scope.launch {
            withFrameNanos { }
            val newOff = (off + focus.y) * f - focus.y
            listState.scrollToItem(index, max(0, newOff.roundToInt()))
            if (newOff < 0) listState.scrollBy(newOff)
            withFrameNanos { }
            hScroll.scrollTo(((hx + focus.x) * f - focus.x).roundToInt().coerceIn(0, hScroll.maxValue.coerceAtLeast(0)))
        }
    }

    val cfg = LocalConfiguration.current
    val density = LocalDensity.current
    val pageWidthDp = (cfg.screenWidthDp * zoom).dp
    val renderPx = with(density) { pageWidthDp.roundToPx() }.coerceAtMost(2200)

    /** The page in the middle of the screen, and the middle point of what's visible of it (fractions). */
    fun visibleSpot(): Triple<Int, Float, Float> {
        val info = listState.layoutInfo
        val items = info.visibleItemsInfo
        if (items.isEmpty()) return Triple(0, 0.5f, 0.5f)
        val mid = (info.viewportStartOffset + info.viewportEndOffset) / 2f
        val item = items.firstOrNull { mid >= it.offset && mid < it.offset + it.size }
            ?: items.minBy { abs(it.offset + it.size / 2f - mid) }
        val fy = ((mid - item.offset) / item.size.coerceAtLeast(1)).coerceIn(0.1f, 0.9f)
        val pagePx = with(density) { pageWidthDp.toPx() }
        val fx = ((hScroll.value + viewport.width / 2f) / pagePx).coerceIn(0.2f, 0.8f)
        return Triple(item.index, fx, fy)
    }
    fun dropSignature(f: File) {
        val (pg, fx, fy) = visibleSpot()
        vm.dropSignature(f, pg, fx, fy)
    }

    Scaffold(
        topBar = {
            Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp) {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().height(56.dp).padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { leave(onClose) }) { Icon(Icons.Outlined.Close, contentDescription = "Close") }
                    IconButton(onClick = { showHelp = true }) { Icon(Icons.AutoMirrored.Outlined.HelpOutline, contentDescription = "Help") }
                    Text(vm.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f).padding(horizontal = 4.dp))
                    IconButton(onClick = { vm.setSelected(null); vm.undo() }, enabled = vm.canUndo) {
                        Icon(Icons.AutoMirrored.Outlined.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = { vm.redo() }, enabled = vm.canRedo) {
                        Icon(Icons.AutoMirrored.Outlined.Redo, contentDescription = "Redo")
                    }
                    Box {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = { vm.save(asCopy = false) },
                                enabled = vm.dirty && vm.busy == null,
                                contentPadding = PaddingValues(horizontal = 14.dp)
                            ) { Text("Save") }
                            IconButton(onClick = { showSaveMenu = true }) { Icon(Icons.Outlined.ArrowDropDown, contentDescription = "More save options") }
                        }
                        DropdownMenu(expanded = showSaveMenu, onDismissRequest = { showSaveMenu = false }) {
                            DropdownMenuItem(text = { Text("Save") }, enabled = vm.dirty, onClick = { showSaveMenu = false; vm.save(false) })
                            DropdownMenuItem(text = { Text("Save as a copy") }, enabled = vm.dirty, onClick = { showSaveMenu = false; vm.save(true) })
                            DropdownMenuItem(text = { Text("Share") }, onClick = { showSaveMenu = false; leave { vm.share() } })
                        }
                    }
                }
            }
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surfaceContainer, shadowElevation = 6.dp) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding()) {
                    val s = vm.selected
                    val styling = s is ImageObj && vm.styleOpen
                    when {
                        s is ImageObj && vm.styleOpen -> SigStylePanel(vm, s)
                        s is ParaObj || s is TextObj -> TextFormatBar(vm, s)
                        s is ImageObj && s.signature && vm.mode == EdMode.SIGN ->
                            SigTray(vm, onNew = { showSigPad = true }, onDrop = { dropSignature(it) })
                        s != null -> ObjectBar(vm, s, onEditNote = { if (s is NoteObj) noteEdit = s })
                        else -> ToolRow(
                            vm,
                            onPickImage = { imagePicker.launch(arrayOf("image/*")) },
                            onNewSignature = { showSigPad = true },
                            onDropSignature = { dropSignature(it) },
                            onFormFields = { leave { vm.uri?.let { onOpenTool("forms", it) } } }
                        )
                    }
                    if (s !is ParaObj && s !is TextObj && !styling) {
                        HorizontalDivider()
                        ModeBar(vm) { m ->
                            if (m == EdMode.MORE) showMore = true
                            else {
                                vm.setSelected(null)
                                vm.mode = m
                                vm.tool = EdTool.entries.first { it.mode == m }
                            }
                        }
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad).background(MaterialTheme.colorScheme.surfaceContainerHigh)) {
            val err = vm.error
            when {
                err != null -> Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(err)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onClose) { Text("Go back") }
                }
                vm.aspects.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                else -> Box(
                    Modifier
                        .fillMaxSize()
                        .onSizeChanged { viewport = it }
                        .pointerInput(Unit) {
                            // Two fingers: zoom and scroll (one finger is for the tools).
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                var pinching = false
                                var scale = 1f
                                var center = Offset.Zero
                                do {
                                    val event = awaitPointerEvent(PointerEventPass.Initial)
                                    if (event.changes.count { it.pressed } >= 2) {
                                        if (!pinching) {
                                            pinching = true
                                            center = event.calculateCentroid(useCurrent = true)
                                            pivot = center
                                        }
                                        scale = (scale * event.calculateZoom()).coerceIn(MIN_Z / zoomNow, MAX_Z / zoomNow)
                                        gesture = scale
                                        val pan = event.calculatePan()
                                        listState.dispatchRawDelta(-pan.y)
                                        hScroll.dispatchRawDelta(-pan.x)
                                        event.changes.forEach { if (it.positionChanged()) it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                                if (pinching) commitZoom(scale, center)
                            }
                        }
                ) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = gesture
                                scaleY = gesture
                                transformOrigin = TransformOrigin(
                                    (pivot.x / viewport.width.coerceAtLeast(1)).coerceIn(0f, 1f),
                                    (pivot.y / viewport.height.coerceAtLeast(1)).coerceIn(0f, 1f)
                                )
                            }
                            .horizontalScroll(hScroll)
                    ) {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.width(pageWidthDp).fillMaxHeight(),
                            contentPadding = PaddingValues(vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(vm.aspects.size) { i -> EditorPage(vm, i, renderPx) }
                        }
                    }
                }
            }

            // Page counter, like "5/5", at the top-left.
            if (vm.aspects.isNotEmpty() && vm.error == null) {
                val curPage by remember { derivedStateOf { visibleSpot().first } }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0x99000000),
                    modifier = Modifier.align(Alignment.TopStart).padding(10.dp)
                ) {
                    Text(
                        "${curPage + 1}/${vm.aspects.size}",
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Bubbles at the top: hints, results.
            val bubble = vm.toast ?: hint
            if (bubble != null) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (vm.toast != null) MaterialTheme.colorScheme.inverseSurface else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                ) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (vm.toast?.startsWith("Saved") == true) {
                            Icon(Icons.Outlined.Check, contentDescription = null, tint = MaterialTheme.colorScheme.inverseOnSurface, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                        }
                        Text(
                            bubble,
                            color = if (vm.toast != null) MaterialTheme.colorScheme.inverseOnSurface else MaterialTheme.colorScheme.onPrimary,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
            if (zoom > 1.01f) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.align(Alignment.BottomStart).padding(12.dp).clickable { commitZoom(1f / zoom, Offset.Zero) }
                ) { Text("${(zoom * 100).roundToInt()}%  ✕", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge) }
            }
        }
    }

    vm.busy?.let { b ->
        AlertDialog(onDismissRequest = {}, confirmButton = {}, text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                Spacer(Modifier.width(16.dp))
                Text(b)
            }
        })
    }

    confirmLeave?.let { action ->
        AlertDialog(
            onDismissRequest = { confirmLeave = null },
            title = { Text("Save your changes?") },
            text = { Text("You have changes that aren't saved yet.") },
            confirmButton = {
                TextButton(onClick = { confirmLeave = null; vm.save(false) { action() } }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmLeave = null; action() }) { Text("Don't save") }
                    TextButton(onClick = { confirmLeave = null }) { Text("Cancel") }
                }
            }
        )
    }

    if (showMore) {
        MoreToolsSheet(onDismiss = { showMore = false }) { route ->
            showMore = false
            if (route == "share") leave { vm.share() } else leave { vm.uri?.let { onOpenTool(route, it) } }
        }
    }
    if (showHelp) HelpSheet { showHelp = false }
    if (showSigPad) {
        SignatureAdder(onDismiss = { showSigPad = false }) { f ->
            vm.mode = EdMode.SIGN
            vm.tool = EdTool.SIGN
            showSigPad = false
            // Like tapping it in the tray: the new signature goes straight onto the page.
            dropSignature(f)
        }
    }
    noteEdit?.let { n ->
        var text by remember(n.id) { mutableStateOf(n.text) }
        AlertDialog(
            onDismissRequest = { noteEdit = null },
            title = { Text("Note") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, minLines = 3, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(onClick = {
                    val cur = vm.objs.firstOrNull { it.id == n.id } as? NoteObj
                    if (cur != null) vm.change(cur.copy(text = text))
                    noteEdit = null
                }) { Text("Done") }
            },
            dismissButton = { TextButton(onClick = { noteEdit = null }) { Text("Cancel") } }
        )
    }
}

// ------------------------------------------------------------------ one page

@Composable
private fun EditorPage(vm: EditorVm, index: Int, renderPx: Int) {
    val aspect = vm.aspects.getOrElse(index) { 0.707f }
    var bmp by remember(index) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(vm.version, index, renderPx) {
        val b = withContext(Dispatchers.IO) { vm.pageBitmap(index, renderPx) }
        if (b != null) bmp = b
    }
    LaunchedEffect(index, vm.mode, vm.tool) {
        if (vm.mode == EdMode.EDIT) vm.ensureParagraphs(index)
        if (vm.tool == EdTool.HIGHLIGHT || vm.tool == EdTool.UNDERLINE || vm.tool == EdTool.STRIKE) vm.preloadText(index)
    }
    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(aspect).background(Color.White)) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.toPx() }
        val hPx = with(density) { maxHeight.toPx() }
        val pageWpt = vm.pageSizes.getOrNull(index)?.first ?: 595f
        val pxPerPt = wPx / pageWpt
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), contentDescription = "Page ${index + 1}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        else CircularProgressIndicator(Modifier.align(Alignment.Center).size(28.dp))

        // Dashed boxes around every paragraph in Edit text mode.
        val paras = vm.paragraphs[index]
        if (vm.tool == EdTool.EDIT_TEXT && vm.selectedId == null && paras != null) {
            val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
            val c = MaterialTheme.colorScheme.outline
            Canvas(Modifier.fillMaxSize()) {
                paras.forEach { p ->
                    val bx = p.box.pad(0.004f, 0.003f)
                    drawRect(c, Offset(bx.l * size.width, bx.t * size.height), Size(bx.w * size.width, bx.h * size.height), style = Stroke(1.5f, pathEffect = dash))
                }
            }
        }

        // Things changed since the last preview picture, drawn approximately on top.
        val sel = vm.selectedId
        vm.objs.filter { it.page == index && it.id != sel && (it !is ParaObj || it.changed) && vm.inPreview[it.id] != it }.forEach { o ->
            Ghost(o, wPx, hPx, pxPerPt, b)
        }

        // Live drawing while dragging.
        var dragStart by remember { mutableStateOf<Offset?>(null) }
        var dragNow by remember { mutableStateOf<Offset?>(null) }
        val inkPts = remember { mutableStateListOf<Offset>() }
        var liveMarks by remember { mutableStateOf<List<FBox>>(emptyList()) }
        val tool = vm.tool
        Canvas(
            Modifier.fillMaxSize()
                .pointerInput(tool, index, wPx, hPx) {
                    detectTapGestures(onTap = { p -> vm.tap(index, p.x / wPx, p.y / hPx) })
                }
                .then(
                    if (tool.drags) Modifier.pointerInput(tool, index, wPx, hPx) {
                        detectDragGestures(
                            onDragStart = { p ->
                                vm.setSelected(null)
                                dragStart = p; dragNow = p
                                inkPts.clear(); inkPts.add(p)
                            },
                            onDragEnd = {
                                val s = dragStart
                                val e = dragNow
                                if (s != null && e != null) {
                                    when (tool) {
                                        EdTool.HIGHLIGHT, EdTool.UNDERLINE, EdTool.STRIKE -> vm.addMark(index, liveMarks)
                                        EdTool.PEN -> vm.addInk(index, inkPts.map { it.x / wPx to it.y / hPx })
                                        else -> vm.addShape(index, s.x / wPx, s.y / hPx, e.x / wPx, e.y / hPx)
                                    }
                                }
                                dragStart = null; dragNow = null; inkPts.clear(); liveMarks = emptyList()
                            },
                            onDragCancel = { dragStart = null; dragNow = null; inkPts.clear(); liveMarks = emptyList() }
                        ) { change, _ ->
                            change.consume()
                            dragNow = change.position
                            if (tool == EdTool.PEN) inkPts.add(change.position)
                            val s = dragStart
                            if (s != null && (tool == EdTool.HIGHLIGHT || tool == EdTool.UNDERLINE || tool == EdTool.STRIKE)) {
                                liveMarks = vm.selectText(index, s.x / wPx, s.y / hPx, change.position.x / wPx, change.position.y / hPx)
                            }
                        }
                    } else Modifier
                )
        ) {
            val s = dragStart
            val e = dragNow
            when (tool) {
                EdTool.HIGHLIGHT, EdTool.UNDERLINE, EdTool.STRIKE -> liveMarks.forEach { bx ->
                    drawRect(col(if (tool == EdTool.HIGHLIGHT) vm.markColor else vm.inkColor, 0.4f), Offset(bx.l * size.width, bx.t * size.height), Size(bx.w * size.width, bx.h * size.height))
                }
                EdTool.PEN -> if (inkPts.size > 1) {
                    val path = Path().apply { moveTo(inkPts[0].x, inkPts[0].y); inkPts.drop(1).forEach { lineTo(it.x, it.y) } }
                    drawPath(path, col(vm.inkColor), style = Stroke(vm.penWidth * pxPerPt, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                else -> if (s != null && e != null) {
                    drawShape(
                        when (tool) { EdTool.OVAL -> ShapeKind.OVAL; EdTool.LINE -> ShapeKind.LINE; EdTool.ARROW -> ShapeKind.ARROW; else -> ShapeKind.RECT },
                        s, e, col(vm.inkColor), vm.penWidth * pxPerPt
                    )
                }
            }
        }

        // The selected item, editable.
        vm.selected?.takeIf { it.page == index }?.let { SelectedOverlay(vm, it, wPx, hPx, pxPerPt, b) }
    }
}

private fun sampleBg(b: Bitmap?, box: FBox): Color {
    if (b == null) return Color.White
    val x = ((box.l - 0.006f) * b.width).toInt().coerceIn(0, b.width - 1)
    val y = (((box.t + box.b) / 2) * b.height).toInt().coerceIn(0, b.height - 1)
    return Color(b.getPixel(x, y))
}

private fun DrawScope.drawShape(kind: ShapeKind, s: Offset, e: Offset, c: Color, w: Float) {
    val tl = Offset(min(s.x, e.x), min(s.y, e.y))
    val sz = Size(abs(e.x - s.x), abs(e.y - s.y))
    val st = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (kind) {
        ShapeKind.RECT -> drawRect(c, tl, sz, style = st)
        ShapeKind.OVAL -> drawOval(c, tl, sz, style = st)
        ShapeKind.LINE -> drawLine(c, s, e, w, StrokeCap.Round)
        ShapeKind.ARROW -> {
            drawLine(c, s, e, w, StrokeCap.Round)
            val ang = atan2((e.y - s.y).toDouble(), (e.x - s.x).toDouble())
            val len = max(18f, w * 4f)
            val p = Path().apply {
                moveTo(e.x, e.y)
                lineTo((e.x - len * cos(ang - 0.45)).toFloat(), (e.y - len * sin(ang - 0.45)).toFloat())
                lineTo((e.x - len * cos(ang + 0.45)).toFloat(), (e.y - len * sin(ang + 0.45)).toFloat())
                close()
            }
            drawPath(p, c)
        }
        ShapeKind.CHECK -> drawPath(Path().apply {
            moveTo(tl.x, tl.y + sz.height * 0.55f); lineTo(tl.x + sz.width * 0.38f, tl.y + sz.height); lineTo(tl.x + sz.width, tl.y)
        }, c, style = st)
        ShapeKind.CROSS -> {
            drawLine(c, tl, Offset(tl.x + sz.width, tl.y + sz.height), w, StrokeCap.Round)
            drawLine(c, Offset(tl.x + sz.width, tl.y), Offset(tl.x, tl.y + sz.height), w, StrokeCap.Round)
        }
        ShapeKind.DOT -> drawOval(c, tl, sz)
    }
}

/** Approximate on-screen drawing of an item (the exact result is in the next preview picture). */
@Composable
private fun Ghost(o: EdObj, wPx: Float, hPx: Float, pxPerPt: Float, bmp: Bitmap?) {
    val density = LocalDensity.current
    fun dp(px: Float) = with(density) { px.toDp() }
    when (o) {
        is ParaObj -> {
            val bg = sampleBg(bmp, o.origBox)
            Box(Modifier.offset { IntOffset((o.origBox.l * wPx).roundToInt() - 3, (o.origBox.t * hPx).roundToInt() - 3) }
                .size(dp(o.origBox.w * wPx + 6), dp(o.origBox.h * hPx + 6)).background(bg))
            if (!o.deleted) {
                val gapPx = o.lineGapPt * pxPerPt * o.style.sizePt / o.origStyle.sizePt
                Text(
                    o.text,
                    style = textStyle(o.style, pxPerPt, o.lineGapPt * o.style.sizePt / o.origStyle.sizePt, density),
                    modifier = Modifier.offset { IntOffset((o.origBox.l * wPx).roundToInt(), (o.firstBaseline * hPx - 0.79f * gapPx).roundToInt()) }
                        .requiredWidth(dp(max(o.origBox.w, o.maxW) * wPx + o.style.sizePt * 0.6f * pxPerPt))
                )
            }
        }
        is TextObj -> Text(
            o.text,
            style = textStyle(o.style, pxPerPt, o.style.sizePt * 1.2f, density),
            modifier = Modifier.offset { IntOffset((o.l * wPx).roundToInt(), (o.t * hPx).roundToInt()) }.requiredWidth(dp(o.w * wPx))
        )
        is ImageObj -> Box(
            Modifier.offset { IntOffset((o.box.l * wPx).roundToInt(), (o.box.t * hPx).roundToInt()) }
                .size(dp(o.box.w * wPx), dp(o.box.h * hPx))
                .graphicsLayer { rotationZ = o.rot }
        ) { ImageContent(o) }
        is MarkObj -> Canvas(Modifier.fillMaxSize()) {
            o.boxes.forEach { bx ->
                val l = bx.l * size.width; val t = bx.t * size.height; val r = bx.r * size.width; val bt = bx.b * size.height
                when (o.kind) {
                    MarkKind.HIGHLIGHT -> drawRect(col(o.color, 0.45f), Offset(l, t), Size(r - l, bt - t))
                    MarkKind.UNDERLINE -> drawLine(col(o.color), Offset(l, bt - (bt - t) * 0.12f), Offset(r, bt - (bt - t) * 0.12f), max(2f, (bt - t) * 0.07f))
                    MarkKind.STRIKE -> drawLine(col(o.color), Offset(l, (t + bt) / 2), Offset(r, (t + bt) / 2), max(2f, (bt - t) * 0.07f))
                }
            }
        }
        is InkObj -> Canvas(Modifier.fillMaxSize()) {
            val path = Path().apply {
                moveTo(o.points[0].first * size.width, o.points[0].second * size.height)
                o.points.drop(1).forEach { (x, y) -> lineTo(x * size.width, y * size.height) }
            }
            drawPath(path, col(o.color), style = Stroke(o.widthPt * pxPerPt, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        is ShapeObj -> Canvas(Modifier.fillMaxSize()) {
            drawShape(o.kind, Offset(o.x1 * size.width, o.y1 * size.height), Offset(o.x2 * size.width, o.y2 * size.height), col(o.color), o.widthPt * pxPerPt)
        }
        is NoteObj -> Box(
            Modifier.offset { IntOffset((o.x * wPx).roundToInt(), (o.y * hPx).roundToInt()) }
                .size(dp(16 * pxPerPt), dp(16 * pxPerPt)).background(col(o.color)).border(1.dp, Color(0xFF795548))
        )
    }
}

/** A picture or signature filling its box: pen strokes for drawn signatures, else the picture (recoloured if asked). */
@Composable
private fun ImageContent(o: ImageObj) {
    val ink = remember(o.path) { if (o.signature) Signatures.ink(o.path) else null }
    if (ink != null) {
        Canvas(Modifier.fillMaxSize()) {
            val c = col(o.tint ?: ink.color)
            val w = max(1f, (o.thick ?: ink.baseThick) * SigInk.THICK_UNIT * size.width)
            ink.strokes.forEach { st ->
                val path = Path().apply {
                    moveTo(st[0].first * size.width, st[0].second * size.height)
                    for (i in 1 until st.size) lineTo(st[i].first * size.width, st[i].second * size.height)
                }
                drawPath(path, c, style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    } else {
        val img = remember(o.path) { decodeSmall(o.path) }
        if (img != null) Image(
            img.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            colorFilter = o.tint?.let { ColorFilter.tint(col(it), BlendMode.SrcIn) },
            modifier = Modifier.fillMaxSize()
        )
    }
}

private fun decodeSmall(path: String): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    var s = 1
    while (max(o.outWidth, o.outHeight) / (s * 2) >= 900) s *= 2
    return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
}

/** The selected item: text you can type into, or a box you can move and resize. */
@Composable
private fun SelectedOverlay(vm: EditorVm, o: EdObj, wPx: Float, hPx: Float, pxPerPt: Float, bmp: Bitmap?) {
    val density = LocalDensity.current
    fun dp(px: Float) = with(density) { px.toDp() }
    val accent = MaterialTheme.colorScheme.primary
    when (o) {
        is ParaObj, is TextObj -> {
            val focus = remember { FocusRequester() }
            val text = if (o is ParaObj) o.text else (o as TextObj).text
            var tfv by remember(o.id) { mutableStateOf(TextFieldValue(text, androidx.compose.ui.text.TextRange(text.length))) }
            if (tfv.text != text) tfv = TextFieldValue(text, androidx.compose.ui.text.TextRange(text.length))
            LaunchedEffect(o.id) { try { focus.requestFocus() } catch (ignored: Exception) {} }
            val left: Float
            val top: Float
            val width: Float
            val style: TextStyle
            if (o is ParaObj) {
                // Hide the old words (the preview removes them for real a moment later).
                val bg = sampleBg(bmp, o.origBox)
                Box(Modifier.offset { IntOffset((o.origBox.l * wPx).roundToInt() - 3, (o.origBox.t * hPx).roundToInt() - 3) }
                    .size(dp(o.origBox.w * wPx + 6), dp(o.origBox.h * hPx + 6)).background(bg))
                // Shown at the smaller size when the paragraph was made smaller to fit.
                val fit = vm.flowInfo[o.id]?.fitScale ?: 1f
                val shownStyle = if (fit < 1f) o.style.copy(sizePt = o.style.sizePt * fit) else o.style
                val gapPt = o.lineGapPt * shownStyle.sizePt / o.origStyle.sizePt
                left = o.origBox.l * wPx
                top = o.firstBaseline * hPx - 0.79f * gapPt * pxPerPt
                width = (max(o.origBox.w, o.maxW) * wPx + o.style.sizePt * 0.6f * pxPerPt) * fit
                style = textStyle(shownStyle, pxPerPt, gapPt, density)
            } else {
                o as TextObj
                left = o.l * wPx
                top = o.t * hPx
                width = o.w * wPx
                style = textStyle(o.style, pxPerPt, o.style.sizePt * 1.2f, density)
            }
            val fitted = (vm.flowInfo[o.id]?.fitScale ?: 1f) < 1f
            Box(
                Modifier.offset { IntOffset(left.roundToInt() - 4, top.roundToInt() - 4) }
                    .border(1.5.dp, if (fitted) Color(0xFFF59E0B) else Color(0xFFE53935), RoundedCornerShape(2.dp))
                    .background(if (fitted) Color(0x22F59E0B) else Color.Transparent)
                    .padding(4.dp)
            ) {
                BasicTextField(
                    value = tfv,
                    onValueChange = { v ->
                        tfv = v
                        val cur = vm.objs.firstOrNull { it.id == o.id } ?: return@BasicTextField
                        when (cur) {
                            is ParaObj -> vm.typed(cur.copy(text = v.text))
                            is TextObj -> vm.typed(cur.copy(text = v.text))
                            else -> Unit
                        }
                    },
                    textStyle = style,
                    cursorBrush = SolidColor(Color(0xFFE53935)),
                    modifier = Modifier.requiredWidth(dp(width)).focusRequester(focus)
                )
            }
            if (o is TextObj) {
                // Move handle (top-left) and width handle (right edge).
                Box(
                    Modifier.offset { IntOffset(left.roundToInt() - 22, top.roundToInt() - 22) }
                        .size(26.dp).background(accent, CircleShape)
                        .pointerInput(o.id) {
                            detectDragGestures(onDragStart = { vm.beginLive() }, onDragEnd = { vm.endLive() }) { c, d ->
                                c.consume()
                                val cur = vm.objs.firstOrNull { it.id == o.id } as? TextObj ?: return@detectDragGestures
                                vm.live(cur.copy(l = (cur.l + d.x / wPx).coerceIn(0f, 0.95f), t = (cur.t + d.y / hPx).coerceIn(0f, 0.97f)))
                            }
                        },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.OpenWith, contentDescription = "Move", tint = Color.White, modifier = Modifier.size(16.dp)) }
                Box(
                    Modifier.offset { IntOffset((left + width).roundToInt() - 4, top.roundToInt() + 6) }
                        .size(14.dp, 28.dp).background(accent, RoundedCornerShape(7.dp))
                        .pointerInput(o.id) {
                            detectDragGestures(onDragStart = { vm.beginLive() }, onDragEnd = { vm.endLive() }) { c, d ->
                                c.consume()
                                val cur = vm.objs.firstOrNull { it.id == o.id } as? TextObj ?: return@detectDragGestures
                                vm.live(cur.copy(w = (cur.w + d.x / wPx).coerceIn(0.08f, 1f - cur.l)))
                            }
                        }
                )
            }
        }
        is ImageObj -> ImageFrame(vm, o, wPx, hPx)
        else -> {
            Ghost(o, wPx, hPx, pxPerPt, bmp)
            val b = when (o) {
                is ShapeObj -> FBox(min(o.x1, o.x2), min(o.y1, o.y2), max(o.x1, o.x2), max(o.y1, o.y2))
                is NoteObj -> FBox(o.x, o.y, o.x + 16 * pxPerPt / wPx, o.y + 16 * pxPerPt / hPx)
                is InkObj -> FBox(o.points.minOf { it.first }, o.points.minOf { it.second }, o.points.maxOf { it.first }, o.points.maxOf { it.second })
                is MarkObj -> o.boxes.reduce { a, c -> a.union(c) }
                else -> return
            }.pad(0.004f, 0.004f)
            val movable = o is ShapeObj || o is NoteObj || o is InkObj
            Box(
                Modifier.offset { IntOffset((b.l * wPx).roundToInt(), (b.t * hPx).roundToInt()) }
                    .size(dp(b.w * wPx), dp(b.h * hPx))
                    .border(BorderStroke(1.5.dp, accent))
                    .then(
                        if (movable) Modifier.pointerInput(o.id) {
                            detectDragGestures(onDragStart = { vm.beginLive() }, onDragEnd = { vm.endLive() }) { c, d ->
                                c.consume()
                                val dx = d.x / wPx
                                val dy = d.y / hPx
                                when (val cur = vm.objs.firstOrNull { it.id == o.id }) {
                                    is ShapeObj -> vm.live(cur.copy(x1 = cur.x1 + dx, y1 = cur.y1 + dy, x2 = cur.x2 + dx, y2 = cur.y2 + dy))
                                    is NoteObj -> vm.live(cur.copy(x = cur.x + dx, y = cur.y + dy))
                                    is InkObj -> vm.live(cur.copy(points = cur.points.map { (x, y) -> x + dx to y + dy }))
                                    else -> Unit
                                }
                            }
                        } else Modifier
                    )
            )
            if (o is ShapeObj) {
                // Resize handle (bottom-right).
                Box(
                    Modifier.offset { IntOffset((b.r * wPx).roundToInt() - 14, (b.b * hPx).roundToInt() - 14) }
                        .size(28.dp).background(accent, CircleShape)
                        .pointerInput(o.id) {
                            detectDragGestures(onDragStart = { vm.beginLive() }, onDragEnd = { vm.endLive() }) { c, d ->
                                c.consume()
                                when (val cur = vm.objs.firstOrNull { it.id == o.id }) {
                                    is ShapeObj -> vm.live(cur.copy(x2 = cur.x2 + d.x / wPx, y2 = cur.y2 + d.y / hPx))
                                    else -> Unit
                                }
                            }
                        }
                )
            }
        }
    }
}

// ------------------------------------------------------------------ pictures and signatures

private val FrameRed = Color(0xFFE53935)

/** Ink colours for signatures, in the same order as the colour row of the style panel. */
val SigColors = listOf(
    0x000000, 0xFFFFFF, 0x8C8C8C, 0xE53935, 0x1ED41E, 0x1E3AF2, 0xE91E8C, 0xF4511E,
    0xFBC02D, 0x9CCC65, 0x69F0AE, 0x4DD0E1, 0x29B6F6, 0x7E22CE, 0x0D2B6B, 0x795548
)

private fun normDeg(d: Float): Float {
    var a = d % 360f
    if (a > 180f) a -= 360f
    if (a <= -180f) a += 360f
    return a
}

/**
 * The selected picture or signature: a red frame you drag from anywhere inside, with ✕ (remove),
 * ✏️ (thickness and colour, signatures only) and a corner handle that resizes and turns it.
 * While moving, red dashed guide lines show when it lines up with the page centre or another item.
 */
@Composable
private fun ImageFrame(vm: EditorVm, o: ImageObj, wPx: Float, hPx: Float) {
    val density = LocalDensity.current
    fun dp(px: Float) = with(density) { px.toDp() }
    val padPx = with(density) { 6.dp.toPx() }
    val handlePx = with(density) { 26.dp.toPx() }
    val snapPx = with(density) { 6.dp.toPx() }
    var guideX by remember(o.id) { mutableStateOf<Float?>(null) }
    var guideY by remember(o.id) { mutableStateOf<Float?>(null) }

    fun current() = vm.objs.firstOrNull { it.id == o.id } as? ImageObj
    fun frameCorner(im: ImageObj, sx: Float, sy: Float): Offset {
        val cx = (im.box.l + im.box.r) / 2 * wPx
        val cy = (im.box.t + im.box.b) / 2 * hPx
        val dx = sx * (im.box.w * wPx / 2 + padPx)
        val dy = sy * (im.box.h * hPx / 2 + padPx)
        val a = Math.toRadians(im.rot.toDouble())
        return Offset(cx + (dx * cos(a) - dy * sin(a)).toFloat(), cy + (dx * sin(a) + dy * cos(a)).toFloat())
    }

    // Guide lines across the whole page.
    if (guideX != null || guideY != null) {
        val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
        Canvas(Modifier.fillMaxSize()) {
            guideX?.let { gx -> drawLine(FrameRed, Offset(gx * size.width, 0f), Offset(gx * size.width, size.height), 2f, pathEffect = dash) }
            guideY?.let { gy -> drawLine(FrameRed, Offset(0f, gy * size.height), Offset(size.width, gy * size.height), 2f, pathEffect = dash) }
        }
    }

    // The frame itself (turned with the item). Drag anywhere inside to move.
    val fw = o.box.w * wPx + 2 * padPx
    val fh = o.box.h * hPx + 2 * padPx
    val cx = (o.box.l + o.box.r) / 2 * wPx
    val cy = (o.box.t + o.box.b) / 2 * hPx
    Box(
        Modifier
            .offset { IntOffset((cx - fw / 2).roundToInt(), (cy - fh / 2).roundToInt()) }
            .size(dp(fw), dp(fh))
            .graphicsLayer { rotationZ = o.rot }
            .border(1.5.dp, FrameRed)
            .pointerInput(o.id, wPx, hPx) {
                var rawX = 0f
                var rawY = 0f
                detectDragGestures(
                    onDragStart = {
                        val cur = current()
                        if (cur != null) {
                            rawX = (cur.box.l + cur.box.r) / 2
                            rawY = (cur.box.t + cur.box.b) / 2
                        }
                        vm.beginLive()
                    },
                    onDragEnd = { guideX = null; guideY = null; vm.endLive() },
                    onDragCancel = { guideX = null; guideY = null; vm.endLive() }
                ) { change, d ->
                    change.consume()
                    val cur = current() ?: return@detectDragGestures
                    // The drag comes in the frame's own (turned) directions; turn it back to the page.
                    val a = Math.toRadians(cur.rot.toDouble())
                    val gx = (d.x * cos(a) - d.y * sin(a)).toFloat()
                    val gy = (d.x * sin(a) + d.y * cos(a)).toFloat()
                    rawX += gx / wPx
                    rawY += gy / hPx
                    // Snap the centre to the page centre or another item's centre.
                    val others = vm.objs.filter { it is ImageObj && it.page == cur.page && it.id != cur.id }.map { it as ImageObj }
                    val tx = listOf(0.5f) + others.map { (it.box.l + it.box.r) / 2 }
                    val ty = listOf(0.5f) + others.map { (it.box.t + it.box.b) / 2 }
                    val sx = tx.minByOrNull { abs(it - rawX) }?.takeIf { abs(it - rawX) * wPx < snapPx }
                    val sy = ty.minByOrNull { abs(it - rawY) }?.takeIf { abs(it - rawY) * hPx < snapPx }
                    guideX = sx
                    guideY = sy
                    val nx = sx ?: rawX
                    val ny = sy ?: rawY
                    val hw = cur.box.w / 2
                    val hh = cur.box.h / 2
                    vm.live(cur.copy(box = FBox(nx - hw, ny - hh, nx + hw, ny + hh)))
                }
            }
    ) {
        Box(Modifier.fillMaxSize().padding(dp(padPx))) { ImageContent(o) }
    }

    @Composable
    fun Handle(sx: Float, sy: Float, modifier: Modifier, content: @Composable () -> Unit) {
        val c = frameCorner(o, sx, sy)
        Box(
            Modifier
                .offset { IntOffset((c.x - handlePx / 2).roundToInt(), (c.y - handlePx / 2).roundToInt()) }
                .size(26.dp)
                .background(Color.White, CircleShape)
                .border(1.5.dp, FrameRed, CircleShape)
                .then(modifier),
            contentAlignment = Alignment.Center
        ) { content() }
    }

    // ✕ remove (top-left).
    Handle(-1f, -1f, Modifier.clickable { vm.delete(o.id) }) {
        Icon(Icons.Outlined.Close, contentDescription = "Remove", tint = FrameRed, modifier = Modifier.size(16.dp))
    }
    // ✏️ thickness and colour (top-right), for signatures.
    if (o.signature) {
        Handle(1f, -1f, Modifier.clickable { vm.styleOpen = !vm.styleOpen }) {
            Icon(Icons.Outlined.Edit, contentDescription = "Thickness and colour", tint = FrameRed, modifier = Modifier.size(15.dp))
        }
    }
    // A plain corner mark (bottom-left), as in the frame design.
    run {
        val c = frameCorner(o, -1f, 1f)
        val r = with(density) { 5.dp.toPx() }
        Box(
            Modifier.offset { IntOffset((c.x - r).roundToInt(), (c.y - r).roundToInt()) }
                .size(10.dp).background(Color.White, CircleShape).border(1.5.dp, FrameRed, CircleShape)
        )
    }
    // Resize and turn (bottom-right): the item follows the handle around its centre.
    Handle(1f, 1f, Modifier.pointerInput(o.id, wPx, hPx) {
        var start: ImageObj? = null
        var centre = Offset.Zero
        var v0 = Offset.Zero
        var p = Offset.Zero
        detectDragGestures(
            onDragStart = {
                val cur = current()
                start = cur
                if (cur != null) {
                    centre = Offset((cur.box.l + cur.box.r) / 2 * wPx, (cur.box.t + cur.box.b) / 2 * hPx)
                    p = frameCorner(cur, 1f, 1f)
                    v0 = p - centre
                }
                vm.beginLive()
            },
            onDragEnd = { start = null; vm.endLive() },
            onDragCancel = { start = null; vm.endLive() }
        ) { change, d ->
            change.consume()
            val s0 = start ?: return@detectDragGestures
            p += d
            val v = p - centre
            val len0 = v0.getDistance()
            if (len0 < 1f || v.getDistance() < 1f) return@detectDragGestures
            // Size: the frame corner stays under the finger (the frame padding doesn't grow).
            val scale = ((v.getDistance() - padPx * 1.41f) / (len0 - padPx * 1.41f)).coerceAtLeast(0.05f)
            var ang = normDeg(s0.rot + Math.toDegrees((atan2(v.y, v.x) - atan2(v0.y, v0.x)).toDouble()).toFloat())
            // Gentle snap to straight angles.
            val straight = (ang / 90f).roundToInt() * 90f
            if (abs(ang - straight) < 4f) ang = normDeg(straight)
            val nw = (s0.box.w * scale).coerceIn(0.05f, 1.2f)
            val k = nw / s0.box.w
            val nh = s0.box.h * k
            val cxf = centre.x / wPx
            val cyf = centre.y / hPx
            vm.live(s0.copy(box = FBox(cxf - nw / 2, cyf - nh / 2, cxf + nw / 2, cyf + nh / 2), rot = ang))
        }
    }) {
        Icon(Icons.Outlined.OpenInFull, contentDescription = "Resize and turn", tint = FrameRed, modifier = Modifier.size(14.dp))
    }
}

/** Saved signatures along the bottom: "+ Add" makes a new one; tap one to put it on the page. */
@Composable
private fun SigTray(vm: EditorVm, onNew: () -> Unit, onDrop: (File) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var saved by remember { mutableStateOf(Signatures.list(ctx)) }
    var askDelete by remember { mutableStateOf<File?>(null) }
    LaunchedEffect(vm.signature) { saved = Signatures.list(ctx) }
    val dash = remember { PathEffect.dashPathEffect(floatArrayOf(10f, 8f)) }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            Modifier.size(64.dp)
                .drawBehind {
                    drawRoundRect(
                        cs.outline, cornerRadius = androidx.compose.ui.geometry.CornerRadius(10.dp.toPx()),
                        style = Stroke(1.5f, pathEffect = dash)
                    )
                }
                .clickable(onClick = onNew),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Outlined.Add, contentDescription = null)
            Text("Add", style = MaterialTheme.typography.labelSmall)
        }
        Box(Modifier.width(1.dp).height(44.dp).background(cs.outlineVariant))
        if (saved.isEmpty()) {
            Text("Tap Add to draw your signature", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        saved.forEach { f ->
            val thumb = remember(f) { BitmapFactory.decodeFile(f.path) }
            Box(Modifier.size(width = 124.dp, height = 70.dp)) {
                Surface(
                    onClick = { onDrop(f) },
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, cs.outlineVariant),
                    modifier = Modifier.align(Alignment.BottomStart).size(width = 116.dp, height = 62.dp)
                ) {
                    if (thumb != null) Image(
                        thumb.asImageBitmap(), contentDescription = "Saved signature",
                        contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(6.dp)
                    )
                }
                Box(
                    Modifier.align(Alignment.TopEnd).size(20.dp).background(Color(0xFF9E9E9E), CircleShape).clickable { askDelete = f },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.Close, contentDescription = "Delete signature", tint = Color.White, modifier = Modifier.size(13.dp)) }
            }
        }
    }
    askDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { askDelete = null },
            title = { Text("Delete this signature?") },
            text = { Text("It will be removed from your saved signatures. Signatures already placed stay on the page.") },
            confirmButton = {
                TextButton(onClick = {
                    Signatures.delete(f)
                    saved = Signatures.list(ctx)
                    if (vm.signature == f) vm.signature = saved.firstOrNull()
                    askDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { askDelete = null }) { Text("Cancel") } }
        )
    }
}

/** Thickness slider and colour squares for the selected signature (changes show live). */
@Composable
private fun SigStylePanel(vm: EditorVm, o: ImageObj) {
    val cs = MaterialTheme.colorScheme
    val ink = remember(o.path) { if (o.signature) Signatures.ink(o.path) else null }
    val thick = o.thick ?: ink?.baseThick ?: 3f
    val colour = o.tint ?: ink?.color
    var sliding by remember { mutableStateOf(false) }
    fun current() = vm.objs.firstOrNull { it.id == o.id } as? ImageObj
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(top = 8.dp, bottom = 14.dp)) {
        Box(
            Modifier.align(Alignment.CenterHorizontally).size(width = 36.dp, height = 4.dp)
                .background(cs.outlineVariant, RoundedCornerShape(2.dp)).clickable { vm.styleOpen = false }
        )
        Spacer(Modifier.height(10.dp))
        Text("Thickness", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Slider(
                value = thick,
                onValueChange = { v ->
                    val cur = current() ?: return@Slider
                    if (!sliding) { sliding = true; vm.beginLive() }
                    vm.live(cur.copy(thick = v))
                },
                onValueChangeFinished = { sliding = false; vm.endLive() },
                valueRange = 1f..16f,
                steps = 14,
                enabled = ink != null,
                colors = SliderDefaults.colors(thumbColor = FrameRed, activeTrackColor = FrameRed, activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent),
                modifier = Modifier.weight(1f)
            )
            Text("${thick.roundToInt()}", style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(32.dp).padding(start = 8.dp))
        }
        if (ink == null) {
            Text("Thickness can be changed for signatures drawn with Add.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text("Color", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SigColors.forEach { c ->
                val light = c == 0xFFFFFF || c == 0xFBC02D || c == 0x69F0AE || c == 0x9CCC65 || c == 0x4DD0E1
                Box(
                    Modifier.size(30.dp)
                        .background(col(c), RoundedCornerShape(5.dp))
                        .border(1.dp, if (c == 0xFFFFFF) Color(0xFFBDBDBD) else Color.Transparent, RoundedCornerShape(5.dp))
                        .clickable { current()?.let { vm.change(it.copy(tint = c)) } },
                    contentAlignment = Alignment.Center
                ) {
                    if (colour == c) Icon(Icons.Outlined.Check, contentDescription = "Selected", tint = if (light) Color.Black else Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ bars

@Composable
private fun BarItem(icon: ImageVector, label: String, selected: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.clickable(enabled = enabled, onClick = onClick)
            .background(if (selected) cs.secondaryContainer else Color.Transparent, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.35f), modifier = Modifier.size(22.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, color = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.35f))
    }
}

@Composable
private fun ModeBar(vm: EditorVm, onMode: (EdMode) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        BarItem(Icons.Outlined.Edit, "Edit", vm.mode == EdMode.EDIT) { onMode(EdMode.EDIT) }
        BarItem(Icons.Outlined.BorderColor, "Annotate", vm.mode == EdMode.ANNOTATE) { onMode(EdMode.ANNOTATE) }
        BarItem(Icons.Outlined.Draw, "Sign", vm.mode == EdMode.SIGN) { onMode(EdMode.SIGN) }
        BarItem(Icons.Outlined.EditNote, "Fill out", vm.mode == EdMode.FILL) { onMode(EdMode.FILL) }
        BarItem(Icons.Outlined.Apps, "More tools") { onMode(EdMode.MORE) }
    }
}

@Composable
private fun ColorDots(colors: List<Int>, current: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        colors.forEach { c ->
            Box(
                Modifier.size(26.dp).background(col(c), CircleShape)
                    .border(if (c == current) 3.dp else 1.dp, if (c == current) MaterialTheme.colorScheme.primary else Color(0x33000000), CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
private fun ToolRow(vm: EditorVm, onPickImage: () -> Unit, onNewSignature: () -> Unit, onDropSignature: (File) -> Unit, onFormFields: () -> Unit) {
    if (vm.mode == EdMode.SIGN) {
        SigTray(vm, onNew = onNewSignature, onDrop = onDropSignature)
        return
    }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            fun t(tool: EdTool) = vm.tool == tool
            when (vm.mode) {
                EdMode.EDIT -> {
                    BarItem(Icons.Outlined.TextFields, "Edit text", t(EdTool.EDIT_TEXT)) { vm.tool = EdTool.EDIT_TEXT }
                    BarItem(Icons.Outlined.Title, "Insert text", t(EdTool.INSERT_TEXT)) { vm.tool = EdTool.INSERT_TEXT }
                    BarItem(Icons.Outlined.AddPhotoAlternate, "Insert image", t(EdTool.INSERT_IMAGE)) { onPickImage() }
                }
                EdMode.ANNOTATE -> {
                    BarItem(Icons.Outlined.BorderColor, "Highlight", t(EdTool.HIGHLIGHT)) { vm.tool = EdTool.HIGHLIGHT }
                    BarItem(Icons.Outlined.FormatUnderlined, "Underline", t(EdTool.UNDERLINE)) { vm.tool = EdTool.UNDERLINE }
                    BarItem(Icons.Outlined.FormatStrikethrough, "Strike", t(EdTool.STRIKE)) { vm.tool = EdTool.STRIKE }
                    BarItem(Icons.Outlined.Gesture, "Pen", t(EdTool.PEN)) { vm.tool = EdTool.PEN }
                    BarItem(Icons.Outlined.CropSquare, "Box", t(EdTool.RECT)) { vm.tool = EdTool.RECT }
                    BarItem(Icons.Outlined.Circle, "Circle", t(EdTool.OVAL)) { vm.tool = EdTool.OVAL }
                    BarItem(Icons.Outlined.HorizontalRule, "Line", t(EdTool.LINE)) { vm.tool = EdTool.LINE }
                    BarItem(Icons.Outlined.NorthEast, "Arrow", t(EdTool.ARROW)) { vm.tool = EdTool.ARROW }
                    BarItem(Icons.Outlined.ChatBubbleOutline, "Note", t(EdTool.NOTE)) { vm.tool = EdTool.NOTE }
                }
                EdMode.SIGN -> Unit
                EdMode.FILL -> {
                    BarItem(Icons.Outlined.TextFields, "Text", t(EdTool.FILL_TEXT)) { vm.tool = EdTool.FILL_TEXT }
                    BarItem(Icons.Outlined.Check, "Tick", t(EdTool.CHECK)) { vm.tool = EdTool.CHECK }
                    BarItem(Icons.Outlined.Close, "Cross", t(EdTool.CROSS)) { vm.tool = EdTool.CROSS }
                    BarItem(Icons.Outlined.Circle, "Dot", t(EdTool.DOT)) { vm.tool = EdTool.DOT }
                    BarItem(Icons.Outlined.CalendarToday, "Date", t(EdTool.DATE)) { vm.tool = EdTool.DATE }
                    if (vm.hasForm) BarItem(Icons.Outlined.EditNote, "Form fields") { onFormFields() }
                }
                EdMode.MORE -> Unit
            }
        }
        if (vm.mode == EdMode.ANNOTATE) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 4.dp).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                if (vm.tool == EdTool.HIGHLIGHT) ColorDots(MarkColors, vm.markColor) { vm.markColor = it }
                else if (vm.tool != EdTool.NOTE) {
                    ColorDots(EdColors.filter { it != 0xFFFFFF }, vm.inkColor) { vm.inkColor = it }
                    if (vm.tool != EdTool.UNDERLINE && vm.tool != EdTool.STRIKE) {
                        Spacer(Modifier.width(12.dp))
                        listOf(1f, 2f, 4f).forEach { w ->
                            Box(
                                Modifier.padding(horizontal = 3.dp).size(30.dp)
                                    .background(if (vm.penWidth == w) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent, CircleShape)
                                    .clickable { vm.penWidth = w },
                                contentAlignment = Alignment.Center
                            ) { Box(Modifier.size((4 + w * 3).dp).background(MaterialTheme.colorScheme.onSurface, CircleShape)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TextFormatBar(vm: EditorVm, o: EdObj) {
    val style = when (o) { is ParaObj -> o.style; is TextObj -> o.style; else -> return }
    var showColors by remember { mutableStateOf(false) }
    fun set(s: TStyle) {
        when (val cur = vm.objs.firstOrNull { it.id == o.id }) {
            is ParaObj -> vm.change(cur.copy(style = s))
            is TextObj -> vm.change(cur.copy(style = s))
            else -> Unit
        }
    }
    val flow = if (o is ParaObj) vm.flowInfo[o.id] else null
    fun setFlow(f: Int) {
        val cur = vm.objs.firstOrNull { it.id == o.id } as? ParaObj ?: return
        vm.change(cur.copy(flow = if (cur.flow == f) com.aipdfstudio.app.data.FLOW_AUTO else f))
    }
    Column {
        if (flow != null && (flow.pushedPt > 0f || flow.fitScale < 1f)) {
            val pushed = flow.pushedPt > 0f
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
                    .background(if (pushed) Color(0xFFCDEDE6) else Color(0xFFFFE7B8), RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (pushed) Icons.Outlined.ArrowDownward else Icons.Outlined.WarningAmber, contentDescription = null,
                    tint = if (pushed) Color(0xFF0B4F45) else Color(0xFF7A4B00), modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    when {
                        pushed -> "Text below moved down ${flow.linesMoved} line${if (flow.linesMoved == 1) "" else "s"}"
                        flow.pageFull -> "Page is full · text made smaller to fit"
                        else -> "Text made smaller to fit its space"
                    },
                    style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold,
                    color = if (pushed) Color(0xFF0B4F45) else Color(0xFF5C3B00)
                )
            }
        }
        if (showColors) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                ColorDots(EdColors, style.color) { set(style.copy(color = it)); showColors = false }
            }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BarItem(Icons.Outlined.FormatBold, "Bold", style.bold) { set(style.copy(bold = !style.bold)) }
            BarItem(Icons.Outlined.FormatItalic, "Italic", style.italic) { set(style.copy(italic = !style.italic)) }
            BarItem(Icons.Outlined.TextDecrease, "Smaller") { set(style.copy(sizePt = max(4f, style.sizePt - 1f))) }
            Text("${style.sizePt.roundToInt()}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(horizontal = 4.dp))
            BarItem(Icons.Outlined.TextIncrease, "Bigger") { set(style.copy(sizePt = min(96f, style.sizePt + 1f))) }
            BarItem(Icons.Outlined.FontDownload, when (style.family) { Family.SANS -> "Sans"; Family.SERIF -> "Serif"; Family.MONO -> "Mono" }) {
                set(style.copy(family = Family.entries[(style.family.ordinal + 1) % Family.entries.size]))
            }
            Box(Modifier.padding(horizontal = 8.dp).size(26.dp).background(col(style.color), CircleShape).border(1.dp, Color(0x55000000), CircleShape).clickable { showColors = !showColors })
            if (o is ParaObj) {
                val cur = vm.objs.firstOrNull { it.id == o.id } as? ParaObj
                FlowChip(Icons.Outlined.FitScreen, "Fit", on = cur?.flow == com.aipdfstudio.app.data.FLOW_FIT || (flow?.fitScale ?: 1f) < 1f) { setFlow(com.aipdfstudio.app.data.FLOW_FIT) }
                Spacer(Modifier.width(6.dp))
                FlowChip(Icons.Outlined.ArrowDownward, "Push down", on = cur?.flow == com.aipdfstudio.app.data.FLOW_PUSH || (flow?.pushedPt ?: 0f) > 0f) { setFlow(com.aipdfstudio.app.data.FLOW_PUSH) }
                Spacer(Modifier.width(6.dp))
            }
            BarItem(Icons.Outlined.ContentCopy, "Duplicate") { vm.duplicate(o.id) }
            BarItem(Icons.Outlined.Delete, "Delete") { vm.delete(o.id) }
            BarItem(Icons.Outlined.Done, "Done") { vm.setSelected(null) }
        }
    }
}

@Composable
private fun FlowChip(icon: ImageVector, label: String, on: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onClick, shape = RoundedCornerShape(12.dp), color = if (on) cs.primaryContainer else cs.surface) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = if (on) cs.onPrimaryContainer else cs.onSurface, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun ObjectBar(vm: EditorVm, o: EdObj, onEditNote: () -> Unit) {
    Column {
        if (o is ShapeObj || o is InkObj || o is MarkObj) {
            val current = when (o) { is ShapeObj -> o.color; is InkObj -> o.color; is MarkObj -> o.color; else -> 0 }
            val palette = if (o is MarkObj && o.kind == MarkKind.HIGHLIGHT) MarkColors else EdColors.filter { it != 0xFFFFFF }
            Row(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                ColorDots(palette, current) { c ->
                    when (o) {
                        is ShapeObj -> vm.change(o.copy(color = c))
                        is InkObj -> vm.change(o.copy(color = c))
                        is MarkObj -> vm.change(o.copy(color = c))
                        else -> Unit
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            if (o is NoteObj) BarItem(Icons.Outlined.Edit, "Edit note") { onEditNote() }
            if (o !is MarkObj) BarItem(Icons.Outlined.ContentCopy, "Duplicate") { vm.duplicate(o.id) }
            BarItem(Icons.Outlined.Delete, "Delete") { vm.delete(o.id) }
            BarItem(Icons.Outlined.Done, "Done") { vm.setSelected(null) }
        }
    }
}

// ------------------------------------------------------------------ sheets

@Composable
private fun MoreToolsSheet(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val mint = cs.primaryContainer to cs.onPrimaryContainer
    val yellow = cs.tertiaryContainer to cs.onTertiaryContainer
    val pink = cs.errorContainer to cs.onErrorContainer
    // route, title, description, icon, colours (same icons as the Tools screen)
    val items = listOf(
        MoreTool("pages", "Page tools", "Rotate, delete, reorder", Icons.Outlined.RotateRight, mint),
        MoreTool("split", "Split or extract", "Pick pages or split up", Icons.Outlined.ContentCut, yellow),
        MoreTool("compress", "Compress", "Shrink file size", Icons.Outlined.Compress, mint),
        MoreTool("redact", "Redact", "Hide private info", Icons.Outlined.VisibilityOff, pink),
        MoreTool("ocr", "OCR", "Make scanned text searchable", Icons.Outlined.TextFields, mint),
        MoreTool("forms", "Fill form fields", "Type into PDF forms", Icons.Outlined.EditNote, yellow),
        MoreTool("lock", "Lock", "Add a password", Icons.Outlined.Lock, pink),
        MoreTool("share", "Share", "Send to WhatsApp, Gmail…", Icons.Outlined.Share, mint)
    )
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 12.dp)) {
            Text(
                "More tools",
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 17.sp),
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 10.dp)
            )
            items.forEach { t ->
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.6f))
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(t.route) }.padding(horizontal = 20.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(36.dp).background(t.colors.first, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(t.icon, contentDescription = null, tint = t.colors.second, modifier = Modifier.size(17.dp)) }
                    Spacer(Modifier.width(15.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                        Text(t.sub, style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp), color = cs.onSurfaceVariant)
                    }
                    Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = cs.outline, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

private class MoreTool(val route: String, val title: String, val sub: String, val icon: ImageVector, val colors: Pair<Color, Color>)

@Composable
private fun HelpSheet(onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("How to edit", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            listOf(
                "Edit → Edit text: tap a paragraph and type. Use the bar above the keyboard for bold, size, font and colour.",
                "Edit → Insert text / Insert image: tap the page where it should go. Drag the round handle to move, the side handle to resize.",
                "Annotate: drag over text to highlight, underline or strike it. Draw with the pen, add boxes, circles, arrows or notes.",
                "Sign: tap Add to draw your signature once. Tap it in the tray to put it on the page. Drag it to move (red guide lines help you line it up), use the corner handle to resize and turn it, ✕ to remove it and ✏️ to change its thickness and colour.",
                "Fill out: tap to add text, ticks, crosses or today's date.",
                "Two fingers: zoom and scroll. Undo and Redo are at the top.",
                "Save writes your changes into the file (a backup is kept). Use Save as a copy to keep the original.",
                "Editing works for English and other Latin-script text. The original font is reused when it has all the letters you type."
            ).forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
            FilledTonalButton(onClick = onDismiss) { Text("Got it") }
        }
    }
}
