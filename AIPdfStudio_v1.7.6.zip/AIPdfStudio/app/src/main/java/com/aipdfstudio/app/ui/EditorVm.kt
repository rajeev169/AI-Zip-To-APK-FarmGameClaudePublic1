package com.aipdfstudio.app.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aipdfstudio.app.data.ConvertOps
import com.aipdfstudio.app.data.EdObj
import com.aipdfstudio.app.data.EditorRender
import com.aipdfstudio.app.data.FBox
import com.aipdfstudio.app.data.ImageObj
import com.aipdfstudio.app.data.InkObj
import com.aipdfstudio.app.data.MarkKind
import com.aipdfstudio.app.data.MarkObj
import com.aipdfstudio.app.data.NoteObj
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PageText
import com.aipdfstudio.app.data.ParaObj
import com.aipdfstudio.app.data.Paragraph
import com.aipdfstudio.app.data.Paragraphs
import com.aipdfstudio.app.data.PdfOps
import com.aipdfstudio.app.data.RecentFile
import com.aipdfstudio.app.data.RecentStore
import com.aipdfstudio.app.data.ShapeKind
import com.aipdfstudio.app.data.ShapeObj
import com.aipdfstudio.app.data.SigInk
import com.aipdfstudio.app.data.Signatures
import com.aipdfstudio.app.data.TStyle
import com.aipdfstudio.app.data.TextGeometry
import com.aipdfstudio.app.data.TextObj
import com.aipdfstudio.app.data.queryName
import com.aipdfstudio.app.data.toObj
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class EdMode(val label: String) { EDIT("Edit"), ANNOTATE("Annotate"), SIGN("Sign"), FILL("Fill out"), MORE("More tools") }

enum class EdTool(val label: String, val mode: EdMode, val drags: Boolean = false) {
    EDIT_TEXT("Edit text", EdMode.EDIT),
    INSERT_TEXT("Insert text", EdMode.EDIT),
    INSERT_IMAGE("Insert image", EdMode.EDIT),
    HIGHLIGHT("Highlight", EdMode.ANNOTATE, true),
    UNDERLINE("Underline", EdMode.ANNOTATE, true),
    STRIKE("Strike", EdMode.ANNOTATE, true),
    PEN("Pen", EdMode.ANNOTATE, true),
    RECT("Box", EdMode.ANNOTATE, true),
    OVAL("Circle", EdMode.ANNOTATE, true),
    LINE("Line", EdMode.ANNOTATE, true),
    ARROW("Arrow", EdMode.ANNOTATE, true),
    NOTE("Note", EdMode.ANNOTATE),
    SIGN("Place", EdMode.SIGN),
    FILL_TEXT("Text", EdMode.FILL),
    CHECK("Tick", EdMode.FILL),
    CROSS("Cross", EdMode.FILL),
    DOT("Dot", EdMode.FILL),
    DATE("Date", EdMode.FILL)
}

val EdColors = listOf(0x111111, 0xC62828, 0x1565C0, 0x2E7D32, 0xEF6C00, 0x6A1B9A, 0xFFFFFF, 0x757575)
val MarkColors = listOf(0xFFEB3B, 0x8BC34A, 0x4FC3F7, 0xF48FB1, 0xFFB74D)

/** Renders pages of one PDF file; one page at a time (PdfRenderer allows only one open page). */
private class PageSource(val pfd: ParcelFileDescriptor) {
    val renderer = PdfRenderer(pfd)
    private var closed = false

    @Synchronized
    fun render(index: Int, widthPx: Int): Bitmap? {
        if (closed || index !in 0 until renderer.pageCount) return null
        val page = renderer.openPage(index)
        try {
            val h = max(1, (widthPx.toFloat() * page.height / page.width).toInt())
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(AColor.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            page.close()
        }
    }

    @Synchronized
    fun close() {
        if (closed) return
        closed = true
        try { renderer.close() } catch (ignored: Exception) {}
        try { pfd.close() } catch (ignored: Exception) {}
    }
}

class EditorVm(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>()

    var uri by mutableStateOf<Uri?>(null)
        private set
    var name by mutableStateOf("")
        private set
    var aspects by mutableStateOf<List<Float>>(emptyList())
        private set
    /** Displayed page sizes in points (width, height). */
    var pageSizes by mutableStateOf<List<Pair<Float, Float>>>(emptyList())
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var hasForm by mutableStateOf(false)
        private set

    val objs = mutableStateListOf<EdObj>()
    var selectedId by mutableStateOf<Long?>(null)
        private set
    var mode by mutableStateOf(EdMode.EDIT)
    var tool by mutableStateOf(EdTool.EDIT_TEXT)
    var inkColor by mutableIntStateOf(0xC62828)
    var markColor by mutableIntStateOf(0xFFEB3B)
    var penWidth by mutableStateOf(2f)
    var signature by mutableStateOf<File?>(null)
    var pendingImage by mutableStateOf<String?>(null)
    /** The thickness and colour panel of the selected signature is open. */
    var styleOpen by mutableStateOf(false)
    /** Edited paragraphs that grew: text below pushed down, or made smaller to fit (from the last preview). */
    var flowInfo by mutableStateOf<Map<Long, com.aipdfstudio.app.data.FlowResult>>(emptyMap())
        private set

    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var busy by mutableStateOf<String?>(null)
        private set
    var toast by mutableStateOf<String?>(null)

    /** Bumps when the picture of the pages changes (new preview), so pages re-render. */
    var version by mutableIntStateOf(0)
        private set
    /** Objects exactly as drawn in the current preview (id -> object). */
    var inPreview by mutableStateOf<Map<Long, EdObj>>(emptyMap())
        private set

    val paragraphs = mutableStateMapOf<Int, List<Paragraph>>()

    private val undo = ArrayDeque<List<EdObj>>()
    private val redo = ArrayDeque<List<EdObj>>()
    private var nextId = 1L
    private var typingSnapshot = false

    private var original: PageSource? = null
    private var preview: PageSource? = null
    private var previewFile: File? = null
    private val bitmaps = LruCache<String, Bitmap>(10)
    private var previewJob: Job? = null

    private val readLock = Any()
    private var readDoc: PDDocument? = null
    private val texts = HashMap<Int, PageText>()

    val dirty get() = objs.any { it !is ParaObj || it.changed }
    val selected: EdObj? get() = selectedId?.let { id -> objs.firstOrNull { it.id == id } }

    // ------------------------------------------------------------ open / close

    fun open(u: Uri) {
        if (u == uri) return
        closeAll()
        uri = u
        name = queryName(ctx, u)
        error = null
        objs.clear()
        undo.clear(); redo.clear(); updateUndo()
        selectedId = null
        paragraphs.clear()
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val pfd = ctx.contentResolver.openFileDescriptor(u, "r") ?: throw IOException("Can't open file")
                    val src = try { PageSource(pfd) } catch (e: Exception) { pfd.close(); throw e }
                    val r = src.renderer
                    val a = (0 until r.pageCount).map { i -> r.openPage(i).use { p -> p.width.toFloat() to p.height.toFloat() } }
                    val form = try {
                        PdfOps.load(ctx, u).use { d -> (d.documentCatalog.acroForm?.fields?.size ?: 0) > 0 }
                    } catch (e: Exception) {
                        false
                    }
                    Triple(src, a, form)
                } catch (e: SecurityException) {
                    "This PDF is password protected. Unlock it first with Tools → Unlock."
                } catch (e: Exception) {
                    "Couldn't open this file for editing. It may be damaged."
                }
            }
            if (result is Triple<*, *, *>) {
                @Suppress("UNCHECKED_CAST")
                original = result.first as PageSource
                @Suppress("UNCHECKED_CAST")
                pageSizes = result.second as List<Pair<Float, Float>>
                aspects = pageSizes.map { it.first / it.second }
                hasForm = result.third as Boolean
                version++
                RecentStore(ctx).let { rs ->
                    val old = rs.find(u.toString())
                    rs.upsert(RecentFile(u.toString(), name, aspects.size, old?.lastPage ?: 0, System.currentTimeMillis(), old?.size ?: 0))
                }
            } else {
                error = result as String
            }
        }
    }

    private fun closeAll() {
        previewJob?.cancel()
        original?.close(); original = null
        preview?.close(); preview = null
        previewFile?.delete(); previewFile = null
        bitmaps.evictAll()
        inPreview = emptyMap()
        synchronized(readLock) {
            try { readDoc?.close() } catch (ignored: Exception) {}
            readDoc = null
            texts.clear()
        }
    }

    override fun onCleared() {
        closeAll()
        super.onCleared()
    }

    // ------------------------------------------------------------ pages

    /** Picture of a page (blocking; call on IO). */
    fun pageBitmap(index: Int, widthPx: Int): Bitmap? {
        val v = version
        val key = "$v:$index:$widthPx"
        bitmaps.get(key)?.let { return it }
        val src = preview ?: original ?: return null
        val b = try { src.render(index, widthPx) } catch (e: Exception) { null } ?: return null
        bitmaps.put(key, b)
        return b
    }

    private fun <T> withReadDoc(block: (PDDocument) -> T): T? = synchronized(readLock) {
        try {
            val d = readDoc ?: PdfOps.load(ctx, uri ?: return null).also { readDoc = it }
            block(d)
        } catch (e: Exception) {
            null
        }
    }

    fun ensureParagraphs(page: Int) {
        if (paragraphs.containsKey(page)) return
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { withReadDoc { Paragraphs.read(it, page) } } ?: emptyList()
            paragraphs[page] = list
        }
    }

    fun preloadText(page: Int) {
        viewModelScope.launch(Dispatchers.IO) { pageText(page) }
    }

    private fun pageText(page: Int): PageText? = synchronized(readLock) {
        texts[page] ?: withReadDoc { TextGeometry.read(it, page) }?.also { texts[page] = it }
    }

    // ------------------------------------------------------------ undo / changes

    private fun updateUndo() {
        canUndo = undo.isNotEmpty()
        canRedo = redo.isNotEmpty()
    }

    private fun snapshot() {
        undo.addLast(objs.toList())
        if (undo.size > 60) undo.removeFirst()
        redo.clear()
        updateUndo()
    }

    fun undo() {
        val prev = undo.removeLastOrNull() ?: return
        redo.addLast(objs.toList())
        objs.clear(); objs.addAll(prev)
        if (objs.none { it.id == selectedId }) selectedId = null
        typingSnapshot = false
        updateUndo()
        schedulePreview()
    }

    fun redo() {
        val next = redo.removeLastOrNull() ?: return
        undo.addLast(objs.toList())
        objs.clear(); objs.addAll(next)
        if (objs.none { it.id == selectedId }) selectedId = null
        updateUndo()
        schedulePreview()
    }

    private fun replace(o: EdObj) {
        val i = objs.indexOfFirst { it.id == o.id }
        if (i >= 0) objs[i] = o else objs.add(o)
    }

    /** A discrete change (move end, style, add, delete): one undo step. */
    fun change(o: EdObj) {
        snapshot()
        replace(o)
        schedulePreview()
    }

    /** Live change while dragging or typing; call [beginLive] first. */
    fun live(o: EdObj) {
        replace(o)
    }

    fun beginLive() = snapshot()

    fun endLive() = schedulePreview()

    fun typed(o: EdObj) {
        if (!typingSnapshot) {
            snapshot()
            typingSnapshot = true
        }
        replace(o)
        // Re-lay the page shortly after typing stops, so text below moves down as lines are added.
        schedulePreview()
    }

    fun add(o: EdObj, select: Boolean = true) {
        snapshot()
        objs.add(o)
        if (select) setSelected(o.id) else schedulePreview()
    }

    fun newId() = nextId++

    fun delete(id: Long) {
        val o = objs.firstOrNull { it.id == id } ?: return
        snapshot()
        if (o is ParaObj) replace(o.copy(deleted = true)) else objs.removeAll { it.id == id }
        selectedId = null
        schedulePreview()
    }

    fun duplicate(id: Long) {
        val o = objs.firstOrNull { it.id == id } ?: return
        val d = 0.03f
        val copy: EdObj = when (o) {
            is ParaObj -> TextObj(newId(), o.page, o.origBox.l, min(0.95f, o.origBox.b + 0.01f), max(o.origBox.w, 0.2f), o.text, o.style)
            is TextObj -> o.copy(id = newId(), t = min(0.95f, o.t + d), l = min(0.9f, o.l + d))
            is ImageObj -> o.copy(id = newId(), box = shift(o.box, d))
            is ShapeObj -> o.copy(id = newId(), x1 = o.x1 + d, y1 = o.y1 + d, x2 = o.x2 + d, y2 = o.y2 + d)
            is NoteObj -> o.copy(id = newId(), x = o.x + d, y = o.y + d)
            is InkObj -> o.copy(id = newId(), points = o.points.map { (x, y) -> x + d to y + d })
            is MarkObj -> return
        }
        add(copy)
    }

    private fun shift(b: FBox, d: Float) = FBox(b.l + d, b.t + d, b.r + d, b.b + d)

    // ------------------------------------------------------------ selection

    fun setSelected(id: Long?) {
        if (id == selectedId) return
        val old = selected
        // Drop empty new text boxes and paragraphs that were opened but not changed.
        when (old) {
            is TextObj -> if (old.text.isBlank()) objs.removeAll { it.id == old.id }
            is ParaObj -> if (!old.changed) objs.removeAll { it.id == old.id }
            else -> Unit
        }
        selectedId = id
        typingSnapshot = false
        styleOpen = false
        schedulePreview()
    }

    // ------------------------------------------------------------ taps and drags

    /** Height (fraction) of a text box, estimated from its text (exact layout happens on save). */
    fun textBoxHeight(t: TextObj, pageAspect: Float): Float {
        // Assume an A4-wide page (595 pt) for the estimate; the real layout is done when saving.
        val pageW = 595f
        val pageH = pageW / pageAspect
        val charsPerLine = max(1f, t.w * pageW / (t.style.sizePt * 0.5f))
        val lines = t.text.split('\n').sumOf { max(1, kotlin.math.ceil(it.length / charsPerLine.toDouble()).toInt()) }
        return t.style.sizePt * (1.2f * lines + 0.2f) / pageH
    }

    private fun bounds(o: EdObj, aspect: Float): FBox? = when (o) {
        is TextObj -> FBox(o.l, o.t, o.l + o.w, o.t + max(0.03f, textBoxHeight(o, aspect)))
        is ImageObj -> o.box
        is ShapeObj -> FBox(min(o.x1, o.x2), min(o.y1, o.y2), max(o.x1, o.x2), max(o.y1, o.y2)).pad(0.01f, 0.01f)
        is NoteObj -> FBox(o.x, o.y, o.x + 0.04f, o.y + 0.04f * aspect)
        is InkObj -> FBox(o.points.minOf { it.first }, o.points.minOf { it.second }, o.points.maxOf { it.first }, o.points.maxOf { it.second }).pad(0.01f, 0.01f)
        is MarkObj -> o.boxes.reduce { a, b -> a.union(b) }
        is ParaObj -> if (o.deleted) null else o.origBox
    }

    fun tap(page: Int, x: Float, y: Float) {
        val aspect = aspects.getOrElse(page) { 0.707f }
        // 1. An object already added? Select it (newest first).
        objs.lastOrNull {
            it.page == page && it !is ParaObj && (if (it is ImageObj) it.hit(x, y, aspect) else bounds(it, aspect)?.contains(x, y) == true)
        }?.let {
            setSelected(it.id)
            return
        }
        // 2. Tapping empty page while something is selected just lets go of it.
        if (selectedId != null && (tool == EdTool.SIGN || selected is ImageObj)) {
            setSelected(null)
            return
        }
        when (tool) {
            EdTool.EDIT_TEXT -> {
                objs.lastOrNull { it is ParaObj && it.page == page && !it.deleted && it.origBox.pad(0.005f, 0.004f).contains(x, y) }?.let {
                    setSelected(it.id); return
                }
                val p = paragraphs[page]?.firstOrNull { it.box.pad(0.005f, 0.004f).contains(x, y) }
                if (p == null) {
                    setSelected(null)
                    toast = "No editable text here. Use Insert text to add new text."
                    return
                }
                val o = p.toObj(newId())
                objs.add(o) // not an undo step until something changes
                setSelected(o.id)
            }
            EdTool.INSERT_TEXT, EdTool.FILL_TEXT -> {
                val o = TextObj(newId(), page, x, y, min(0.5f, 0.97f - x).coerceAtLeast(0.1f), "", TStyle(12f, color = 0x111111))
                add(o)
            }
            EdTool.DATE -> {
                val d = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
                add(TextObj(newId(), page, x, y, min(0.35f, 0.97f - x).coerceAtLeast(0.1f), d, TStyle(12f, color = 0x111111)), select = false)
            }
            EdTool.INSERT_IMAGE -> {
                val path = pendingImage ?: run { toast = "Pick a picture first"; return }
                val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                android.graphics.BitmapFactory.decodeFile(path, o)
                val w = 0.4f
                val h = if (o.outWidth > 0) w * aspect * o.outHeight / o.outWidth else 0.2f
                add(ImageObj(newId(), page, FBox(x, y, min(1f, x + w), min(1f, y + h)), path))
            }
            EdTool.SIGN -> {
                val f = signature ?: run { toast = "Tap Add to create your signature"; return }
                dropSignature(f, page, x, y)
            }
            EdTool.CHECK, EdTool.CROSS, EdTool.DOT -> {
                val s = 0.022f
                val kind = when (tool) { EdTool.CHECK -> ShapeKind.CHECK; EdTool.CROSS -> ShapeKind.CROSS; else -> ShapeKind.DOT }
                val col = when (tool) { EdTool.CHECK -> 0x2E7D32; EdTool.CROSS -> 0xC62828; else -> 0x111111 }
                add(ShapeObj(newId(), page, kind, x - s / 2, y - s * aspect / 2, x + s / 2, y + s * aspect / 2, col, 2f), select = false)
            }
            EdTool.NOTE -> add(NoteObj(newId(), page, x, y, ""))
            else -> setSelected(null)
        }
    }

    /** Puts a saved signature on [page] centred at ([x], [y]) and selects it, ready to move, turn or restyle. */
    fun dropSignature(f: File, page: Int, x: Float, y: Float) {
        if (page !in aspects.indices) return
        signature = f
        val aspect = aspects[page]
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(f.path, o)
        val w = 0.36f
        val h = if (o.outWidth > 0) min(0.4f, w * aspect * o.outHeight / o.outWidth) else 0.1f
        val cx = x.coerceIn(w / 2, 1f - w / 2)
        val cy = y.coerceIn(h / 2, 1f - h / 2)
        add(ImageObj(newId(), page, FBox(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2), f.path, signature = true))
    }

    /** Characters between two points, as one box per line (for highlight / underline / strike). */
    fun selectText(page: Int, x1: Float, y1: Float, x2: Float, y2: Float): List<FBox> {
        val pt = pageText(page) ?: return emptyList()
        val chars = ArrayList<Pair<Int, FBox>>() // line index, box
        pt.lines.sortedWith(compareBy({ it.box.t }, { it.box.l })).forEachIndexed { li, line ->
            line.chars.forEach { (c, b) -> if (c != ' ') chars.add(li to b) }
        }
        if (chars.isEmpty()) return emptyList()
        fun nearest(x: Float, y: Float): Int {
            var best = 0
            var bestD = Float.MAX_VALUE
            chars.forEachIndexed { i, (_, b) ->
                val dx = if (x < b.l) b.l - x else if (x > b.r) x - b.r else 0f
                val dy = if (y < b.t) b.t - y else if (y > b.b) y - b.b else 0f
                val d = dx + dy * 3f
                if (d < bestD) { bestD = d; best = i }
            }
            return best
        }
        val a = nearest(x1, y1)
        val b = nearest(x2, y2)
        return chars.subList(min(a, b), max(a, b) + 1)
            .groupBy { it.first }.values
            .map { list -> list.map { it.second }.reduce { p, q -> p.union(q) } }
    }

    fun addMark(page: Int, boxes: List<FBox>) {
        if (boxes.isEmpty()) return
        val kind = when (tool) { EdTool.UNDERLINE -> MarkKind.UNDERLINE; EdTool.STRIKE -> MarkKind.STRIKE; else -> MarkKind.HIGHLIGHT }
        val color = if (kind == MarkKind.HIGHLIGHT) markColor else inkColor
        add(MarkObj(newId(), page, kind, boxes, color), select = false)
    }

    fun addInk(page: Int, pts: List<Pair<Float, Float>>) {
        if (pts.size < 2) return
        add(InkObj(newId(), page, pts, inkColor, penWidth), select = false)
    }

    fun addShape(page: Int, x1: Float, y1: Float, x2: Float, y2: Float) {
        if (abs(x2 - x1) < 0.01f && abs(y2 - y1) < 0.01f) return
        val kind = when (tool) { EdTool.OVAL -> ShapeKind.OVAL; EdTool.LINE -> ShapeKind.LINE; EdTool.ARROW -> ShapeKind.ARROW; else -> ShapeKind.RECT }
        add(ShapeObj(newId(), page, kind, x1, y1, x2, y2, inkColor, penWidth), select = false)
    }

    fun copyImage(src: Uri): String? = try {
        val dir = File(ctx.filesDir, "edit_images").apply { mkdirs() }
        val out = File(dir, "img_${System.currentTimeMillis()}")
        ctx.contentResolver.openInputStream(src)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        out.path
    } catch (e: Exception) {
        null
    }

    // ------------------------------------------------------------ preview and save

    private fun loadImages(doc: PDDocument, list: List<EdObj>): Map<String, PDImageXObject> {
        val out = HashMap<String, PDImageXObject>()
        list.filterIsInstance<ImageObj>().distinctBy { EditorRender.imageKey(it) }.forEach { im ->
            val path = im.path
            val sig = im.signature
            // Drawn signatures are written as pen strokes instead (see loadInks).
            if (sig && Signatures.ink(path) != null) return@forEach
            try {
                if (sig) {
                    val b = android.graphics.BitmapFactory.decodeFile(path) ?: return@forEach
                    val tint = im.tint
                    if (tint != null) {
                        val m = b.copy(Bitmap.Config.ARGB_8888, true)
                        val px = IntArray(m.width * m.height)
                        m.getPixels(px, 0, m.width, 0, 0, m.width, m.height)
                        for (i in px.indices) px[i] = (px[i] and 0xFF000000.toInt()) or tint
                        m.setPixels(px, 0, m.width, 0, 0, m.width, m.height)
                        out[EditorRender.imageKey(im)] = LosslessFactory.createFromImage(doc, m)
                        m.recycle()
                    } else {
                        out[path] = LosslessFactory.createFromImage(doc, b)
                    }
                    b.recycle()
                } else {
                    val b = ConvertOps.decodeImage(ctx, Uri.fromFile(File(path)), 2000) ?: return@forEach
                    out[path] = JPEGFactory.createFromImage(doc, b, 0.9f)
                    b.recycle()
                }
            } catch (e: Exception) {
            }
        }
        return out
    }

    private fun loadInks(list: List<EdObj>): Map<String, SigInk> =
        list.filterIsInstance<ImageObj>().filter { it.signature }.map { it.path }.distinct()
            .mapNotNull { p -> Signatures.ink(p)?.let { p to it } }.toMap()

    private fun build(list: List<EdObj>, skip: Long?, out: File): Map<Long, com.aipdfstudio.app.data.FlowResult> {
        val u = uri ?: throw IOException("No file")
        PdfOps.load(ctx, u).use { doc ->
            val r = EditorRender.apply(doc, list, loadImages(doc, list), skip, loadInks(list))
            doc.save(out)
            return r
        }
    }

    private fun schedulePreview() {
        previewJob?.cancel()
        previewJob = viewModelScope.launch {
            delay(450)
            val list = objs.toList()
            val skip = selectedId
            val relevant = list.filter { it !is ParaObj || it.changed || it.id == skip }
            if (relevant.isEmpty()) {
                flowInfo = emptyMap()
                if (preview != null) {
                    preview?.close(); preview = null
                    previewFile?.delete(); previewFile = null
                    bitmaps.evictAll()
                    inPreview = emptyMap()
                    version++
                }
                return@launch
            }
            val result = withContext(Dispatchers.IO) {
                try {
                    val f = File(ctx.cacheDir, "edit_preview_${System.nanoTime()}.pdf")
                    val flows = build(relevant, skip, f)
                    val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                    Triple(f, PageSource(pfd), flows)
                } catch (e: Exception) {
                    null
                }
            } ?: return@launch
            val oldSrc = preview
            val oldFile = previewFile
            preview = result.second
            previewFile = result.first
            flowInfo = result.third
            bitmaps.evictAll()
            inPreview = relevant.filter { it.id != skip }.associateBy { it.id }
            version++
            withContext(Dispatchers.IO) {
                oldSrc?.close()
                oldFile?.delete()
            }
        }
    }

    /**
     * Saves the changes. Writes over the original when the app may (keeping a backup copy),
     * otherwise saves a copy. Returns a message for the user.
     */
    fun save(asCopy: Boolean, onDone: (Uri) -> Unit = {}) {
        val u = uri ?: return
        if (busy != null) return
        setSelected(null)
        busy = "Saving…"
        viewModelScope.launch {
            val list = objs.filter { it !is ParaObj || it.changed }
            val msg = withContext(Dispatchers.IO) {
                try {
                    val tmp = File(ctx.cacheDir, "edit_save.pdf")
                    build(list, null, tmp)
                    var target: Uri? = null
                    var text = "Saved successfully"
                    if (!asCopy) {
                        try {
                            backup(u)
                            val out = ctx.contentResolver.openOutputStream(u, "wt") ?: throw IOException()
                            out.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                            target = u
                        } catch (e: Exception) {
                            text = "Couldn't change the original file, so a copy was saved"
                        }
                    }
                    if (target == null) {
                        val f = Outputs.newFile(ctx, name, "edited")
                        tmp.copyTo(f, overwrite = true)
                        target = Outputs.uri(ctx, f)
                        if (asCopy) text = "Saved a copy: ${f.name}"
                    }
                    tmp.delete()
                    target to text
                } catch (e: Throwable) {
                    null to PdfOps.friendly(e)
                }
            }
            busy = null
            toast = msg.second
            val target = msg.first ?: return@launch
            // Start fresh on the saved file: the edits are now part of it.
            val reopen = uri
            uri = null
            open(target)
            if (reopen == target) Unit
            onDone(target)
        }
    }

    private fun backup(u: Uri) {
        val dir = File(ctx.filesDir, "backups").apply { mkdirs() }
        val f = File(dir, "backup_${System.currentTimeMillis()}.pdf")
        ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(5)?.forEach { it.delete() }
    }

    fun share() {
        val u = uri ?: return
        try {
            Outputs.shareUri(ctx, u, name)
        } catch (e: Exception) {
            toast = "No app available to share with"
        }
    }

    companion object {
        fun keepAccess(ctx: Context, u: Uri) {
            try {
                ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (e: Exception) {
                try {
                    ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (ignored: Exception) {
                }
            }
        }
    }
}
