package com.aipdfstudio.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.Sort
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CheckBox
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.NoteAdd
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ViewDay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.aipdfstudio.app.data.ConvertOps
import com.aipdfstudio.app.data.DocFile
import com.aipdfstudio.app.data.DocKind
import com.aipdfstudio.app.data.Library
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.fmtSize
import com.aipdfstudio.app.data.queryName
import com.aipdfstudio.app.data.querySize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Tile colours from the approved design.
internal val TileBlue = Color(0xFFDCE6FF) to Color(0xFF16367A)
internal val TilePink = Color(0xFFFFD9D9) to Color(0xFF6B1010)
internal val TileYellow = Color(0xFFFFE08A) to Color(0xFF3A2E00)
internal val TileGreen = Color(0xFFD9F2DF) to Color(0xFF1B6B34)
internal val TileCyan = Color(0xFFD4F3F5) to Color(0xFF0B5F66)
internal val TileViolet = Color(0xFFE9DDFF) to Color(0xFF3D1C7A)

private val DOC_MIMES = arrayOf(
    "application/pdf", "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "application/epub+zip"
)

private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
internal fun DocFile.meta() = (if (modified > 0) dateFmt.format(Date(modified)) + " · " else "") + fmtSize(size)

private enum class SortBy(val label: String) { DATE("Date (newest)"), NAME("Name (A–Z)"), SIZE("Size (largest)") }

/** The document icon with a coloured PDF / DOC / XLS / PPT badge. */
@Composable
internal fun DocIcon(kind: DocKind) {
    Box(Modifier.size(width = 34.dp, height = 40.dp)) {
        Canvas(Modifier.size(width = 30.dp, height = 38.dp).offset(x = 4.dp)) {
            val w = size.width; val h = size.height; val f = w * 0.3f
            val page = Path().apply { moveTo(0f, 0f); lineTo(w - f, 0f); lineTo(w, f); lineTo(w, h); lineTo(0f, h); close() }
            drawPath(page, Color.White)
            drawPath(page, Color(0xFFDADFDD), style = Stroke(2f))
            drawPath(Path().apply { moveTo(w - f, 0f); lineTo(w - f, f); lineTo(w, f); close() }, Color(0xFFECEFEE))
        }
        Text(
            kind.badge,
            color = Color.White,
            fontSize = 8.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.align(Alignment.BottomStart).padding(bottom = 8.dp)
                .background(Color(0xFF000000.toInt() or kind.color), RoundedCornerShape(3.dp))
                .padding(horizontal = 3.dp, vertical = 0.dp)
        )
    }
}

@Composable
internal fun TileIcon(icon: ImageVector, colors: Pair<Color, Color>, box: Int = 46, iconSize: Int = 26) {
    Box(Modifier.size(box.dp).background(colors.first, RoundedCornerShape((box * 0.28f).dp)), contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = null, tint = colors.second, modifier = Modifier.size(iconSize.dp))
    }
}

/** One document row: icon, name, "date · size", and a ⋮ menu (or a checkbox / radio). */
@Composable
internal fun DocRow(
    d: DocFile,
    onClick: () -> Unit,
    checked: Boolean? = null,
    radio: Boolean = false,
    menu: (@Composable (close: () -> Unit) -> Unit)? = null
) {
    var open by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (radio) { RadioButton(selected = false, onClick = onClick); Spacer(Modifier.width(2.dp)) }
        if (checked != null) Checkbox(checked = checked, onCheckedChange = { onClick() })
        DocIcon(d.kind)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(d.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(d.meta(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (menu != null && checked == null) {
            Box {
                IconButton(onClick = { open = true }) { Icon(Icons.Outlined.MoreVert, contentDescription = "More", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) { menu { open = false } }
            }
        }
    }
}

/** Opens a document the right way: PDFs in the app, Word/Excel/PowerPoint in another app. */
internal fun openDoc(ctx: Context, d: DocFile, onPdf: (Uri) -> Unit, onBook: ((Uri) -> Unit)? = null) {
    if (d.kind == DocKind.PDF) onPdf(Uri.parse(d.uri))
    else if ((d.kind == DocKind.EPUB || d.kind == DocKind.ZIP) && onBook != null) onBook(Uri.parse(d.uri))
    else try {
        Library.openElsewhere(ctx, d)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app on this phone can open ${d.kind.badge} files", Toast.LENGTH_LONG).show()
    }
}

/** What the Files screen asks the app to do. */
class FilesActions(
    val openPdf: (Uri) -> Unit,
    val tool: (String) -> Unit,
    val convert: (mode: String, uri: Uri?) -> Unit,
    val pick: (mode: String) -> Unit,
    val createPdf: () -> Unit,
    val settings: () -> Unit,
    val listen: (Uri) -> Unit = {}
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesScreen(act: FilesActions) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val prefs = remember { ctx.getSharedPreferences("files_ui", Context.MODE_PRIVATE) }

    var docs by remember { mutableStateOf<List<DocFile>?>(null) }
    var granted by remember { mutableStateOf(Library.hasAllFiles(ctx)) }
    var skipped by remember { mutableStateOf(prefs.getBoolean("skip_access", false)) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var sort by rememberSaveable { mutableStateOf(SortBy.entries.getOrElse(prefs.getInt("sort", 0)) { SortBy.DATE }) }
    var query by rememberSaveable { mutableStateOf("") }
    var searching by rememberSaveable { mutableStateOf(false) }
    var view by rememberSaveable { mutableStateOf("") } // "" list, "recent", "folders", "folder:<name>"
    var selecting by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var showPlus by remember { mutableStateOf(false) }
    var showSort by remember { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf(false) }
    var folderFor by remember { mutableStateOf<List<DocFile>?>(null) }
    var renaming by remember { mutableStateOf<DocFile?>(null) }
    var deleting by remember { mutableStateOf<List<DocFile>?>(null) }
    var wordChoice by remember { mutableStateOf<DocFile?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) } // bumps when lists (folders, bookmarks) change

    fun reload() {
        scope.launch {
            granted = Library.hasAllFiles(ctx)
            docs = withContext(Dispatchers.IO) { Library.all(ctx) }
            tick++
        }
    }
    LaunchedEffect(Unit) { reload() }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) reload() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val legacyPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { reload() }
    fun askAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try { ctx.startActivity(Library.allFilesIntent(ctx)) } catch (e: Exception) {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else legacyPerm.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        scope.launch {
            val added = withContext(Dispatchers.IO) {
                uris.map { u ->
                    try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (ignored: Exception) {}
                    DocFile(u.toString(), queryName(ctx, u), querySize(ctx, u), System.currentTimeMillis())
                }
            }
            Library.addImports(ctx, added)
            Toast.makeText(ctx, "Imported ${added.size} file${if (added.size == 1) "" else "s"}", Toast.LENGTH_SHORT).show()
            reload()
        }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        busy = "Importing…"
        scope.launch {
            val out = withContext(Dispatchers.IO) {
                try {
                    val f = Outputs.newFile(ctx, "Images_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()), "")
                    ConvertOps.imagesToPdf(ctx, uris, true, f) { msg -> busy = msg }
                    f
                } catch (e: Throwable) {
                    null
                }
            }
            busy = null
            if (out != null) { reload(); act.openPdf(Outputs.uri(ctx, out)) }
            else Toast.makeText(ctx, "Couldn't make a PDF from those pictures", Toast.LENGTH_LONG).show()
        }
    }
    fun pickImages() = imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))

    // ------------------------------------------------------------ first launch: ask for access
    if (!granted && !skipped) {
        AccessScreen(
            onAllow = { askAccess() },
            onLater = { prefs.edit().putBoolean("skip_access", true).apply(); skipped = true }
        )
        return
    }

    BackHandler(enabled = view.isNotEmpty() || selecting || searching) {
        when {
            selecting -> { selecting = false; selected = emptySet() }
            searching -> { searching = false; query = "" }
            view.startsWith("folder:") -> view = "folders"
            else -> view = ""
        }
    }

    val all = docs
    val now = System.currentTimeMillis()
    val recentCut = now - 3L * 24 * 3600 * 1000
    val tabs = listOf("All", "PDF", "Word", "Excel", "PPT")
    val folders = remember(tick) { Library.folders(ctx) }
    val shown: List<DocFile> = run {
        val base = when {
            all == null -> emptyList()
            view == "recent" -> all.filter { it.modified >= now - 7L * 24 * 3600 * 1000 }
            view.startsWith("folder:") -> folders[view.removePrefix("folder:")] ?: emptyList()
            else -> all
        }
        val byTab = when (tab) { 1 -> base.filter { it.kind == DocKind.PDF }; 2 -> base.filter { it.kind == DocKind.WORD }; 3 -> base.filter { it.kind == DocKind.EXCEL }; 4 -> base.filter { it.kind == DocKind.PPT }; else -> base }
        val q = query.trim()
        val found = if (q.isEmpty()) byTab else byTab.filter { it.name.contains(q, true) }
        when (sort) {
            SortBy.DATE -> found.sortedByDescending { it.modified }
            SortBy.NAME -> found.sortedBy { it.name.lowercase() }
            SortBy.SIZE -> found.sortedByDescending { it.size }
        }
    }

    fun rowMenu(d: DocFile, inFolder: String?): @Composable (() -> Unit) -> Unit = { close ->
        DropdownMenuItem(text = { Text("Open") }, onClick = { close(); if (d.kind == DocKind.WORD) wordChoice = d else openDoc(ctx, d, act.openPdf, act.listen) })
        if (d.kind == DocKind.WORD) DropdownMenuItem(text = { Text("Convert to PDF") }, onClick = { close(); act.convert("WORD_TO_PDF", Uri.parse(d.uri)) })
        if (d.kind == DocKind.PDF || d.kind == DocKind.EPUB || d.kind == DocKind.ZIP || d.name.endsWith(".docx", true)) DropdownMenuItem(text = { Text("Listen") }, onClick = { close(); act.listen(Uri.parse(d.uri)) })
        DropdownMenuItem(text = { Text("Share") }, onClick = { close(); Library.share(ctx, listOf(d)) })
        val marked = remember(tick) { Library.isBookmarked(ctx, d) }
        DropdownMenuItem(text = { Text(if (marked) "Remove bookmark" else "Bookmark") }, onClick = { close(); Library.toggleBookmark(ctx, d); tick++ })
        if (inFolder != null) DropdownMenuItem(text = { Text("Remove from folder") }, onClick = { close(); Library.removeFromFolder(ctx, inFolder, d); tick++ })
        else DropdownMenuItem(text = { Text("Add to folder") }, onClick = { close(); folderFor = listOf(d) })
        if (d.path != null) DropdownMenuItem(text = { Text("Rename") }, onClick = { close(); renaming = d })
        DropdownMenuItem(text = { Text(if (d.path != null) "Delete" else "Remove from list") }, onClick = { close(); deleting = listOf(d) })
    }

    Scaffold(
        containerColor = cs.background,
        contentWindowInsets = WindowInsets.statusBars,
        floatingActionButton = {
            if (!selecting) FloatingActionButton(onClick = { showPlus = true }, containerColor = cs.primary, contentColor = cs.onPrimary, shape = RoundedCornerShape(18.dp)) {
                Icon(Icons.Outlined.Add, contentDescription = "Add", modifier = Modifier.size(30.dp))
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            // ---------------------------------------------------- top bar
            Row(Modifier.fillMaxWidth().height(56.dp).padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                when {
                    selecting -> {
                        IconButton(onClick = { selecting = false; selected = emptySet() }) { Icon(Icons.Outlined.Close, contentDescription = "Cancel") }
                        Text("${selected.size} selected", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        val sel = shown.filter { it.uri in selected }
                        IconButton(onClick = { Library.share(ctx, sel) }, enabled = sel.isNotEmpty()) { Icon(Icons.Outlined.Share, contentDescription = "Share") }
                        IconButton(onClick = { folderFor = sel }, enabled = sel.isNotEmpty()) { Icon(Icons.Outlined.CreateNewFolder, contentDescription = "Add to folder") }
                        IconButton(onClick = { deleting = sel }, enabled = sel.isNotEmpty()) { Icon(Icons.Outlined.Delete, contentDescription = "Delete") }
                    }
                    searching -> {
                        IconButton(onClick = { searching = false; query = "" }) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
                        TextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            placeholder = { Text("Search files") },
                            colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    view.isNotEmpty() -> {
                        IconButton(onClick = { view = if (view.startsWith("folder:")) "folders" else "" }) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
                        Text(
                            when { view == "recent" -> "Recently added"; view == "folders" -> "Folders"; else -> view.removePrefix("folder:") },
                            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                        )
                        if (view == "folders") IconButton(onClick = { newFolder = true }) { Icon(Icons.Outlined.CreateNewFolder, contentDescription = "New folder") }
                    }
                    else -> {
                        Text(
                            buildAnnotatedString { append("AI PDF "); withStyle(SpanStyle(color = cs.primary)) { append("Studio") } },
                            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                        )
                    }
                }
                if (!selecting && !searching) {
                    IconButton(onClick = { searching = true }) { Icon(Icons.Outlined.Search, contentDescription = "Search") }
                    Box {
                        IconButton(onClick = { showSort = true }) { Icon(Icons.AutoMirrored.Outlined.Sort, contentDescription = "Sort") }
                        DropdownMenu(expanded = showSort, onDismissRequest = { showSort = false }) {
                            SortBy.entries.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s.label, fontWeight = if (s == sort) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = { sort = s; prefs.edit().putInt("sort", s.ordinal).apply(); showSort = false }
                                )
                            }
                        }
                    }
                    if (view != "folders") IconButton(onClick = { selecting = true; selected = emptySet() }) { Icon(Icons.Outlined.CheckBox, contentDescription = "Select files") }
                    Box {
                        IconButton(onClick = { showMore = true }) { Icon(Icons.Outlined.MoreVert, contentDescription = "More") }
                        DropdownMenu(expanded = showMore, onDismissRequest = { showMore = false }) {
                            DropdownMenuItem(text = { Text("Refresh") }, onClick = { showMore = false; reload() })
                            DropdownMenuItem(text = { Text("Folders") }, onClick = { showMore = false; view = "folders" })
                            if (!granted) DropdownMenuItem(text = { Text("Show all documents on phone") }, onClick = { showMore = false; askAccess() })
                            DropdownMenuItem(text = { Text("Settings") }, onClick = { showMore = false; act.settings() })
                        }
                    }
                }
            }

            if (view == "folders") {
                FoldersList(folders, onOpen = { view = "folder:$it" }, onNew = { newFolder = true }, onDelete = { Library.deleteFolder(ctx, it); tick++ })
                return@Column
            }

            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
                if (view.isEmpty() && !selecting && !searching) {
                    item(key = "tiles") {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BigTile("Import files", Icons.Outlined.Download, TileBlue, Modifier.weight(1f)) { importer.launch(DOC_MIMES) }
                            BigTile("Image to PDF", Icons.Outlined.Image, TilePink, Modifier.weight(1f)) { pickImages() }
                            BigTile("Folder", Icons.Outlined.Folder, TileYellow, Modifier.weight(1f)) { view = "folders" }
                        }
                    }
                }
                item(key = "tabs") {
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp, start = 6.dp, end = 6.dp), horizontalArrangement = Arrangement.SpaceAround) {
                        tabs.forEachIndexed { i, t ->
                            Column(Modifier.clickable { tab = i }.padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    t, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp),
                                    color = if (tab == i) cs.primary else cs.onSurfaceVariant,
                                    fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal
                                )
                                Box(Modifier.width(28.dp).height(3.dp).background(if (tab == i) cs.primary else Color.Transparent, RoundedCornerShape(2.dp)))
                            }
                        }
                    }
                    HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.6f))
                }
                if (!granted && view.isEmpty()) {
                    item(key = "banner") {
                        Surface(
                            onClick = { askAccess() }, color = cs.secondaryContainer, shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 10.dp)
                        ) {
                            Text("Showing only files you opened or imported. Tap to show all documents on your phone.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
                if (view.isEmpty() && !selecting && !searching) {
                    item(key = "recent") {
                        val n = all?.count { it.modified >= recentCut } ?: 0
                        Surface(
                            onClick = { view = "recent" }, color = cs.surfaceContainer, shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 4.dp)
                        ) {
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Folder, contentDescription = null, tint = Color(0xFFE9A800))
                                Spacer(Modifier.width(10.dp))
                                Text("Recently added", fontWeight = FontWeight.SemiBold)
                                if (n > 0) {
                                    Spacer(Modifier.width(8.dp))
                                    Text("+$n", color = Color(0xFFB3261E), fontSize = 11.sp, modifier = Modifier.background(Color(0xFFFFD9D9), RoundedCornerShape(9.dp)).padding(horizontal = 7.dp, vertical = 1.dp))
                                }
                                Spacer(Modifier.weight(1f))
                                Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = cs.outline)
                            }
                        }
                    }
                }
                when {
                    all == null -> item(key = "loading") {
                        Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    }
                    shown.isEmpty() -> item(key = "empty") {
                        Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                when { query.isNotBlank() -> "Nothing matches \"$query\""; view.startsWith("folder:") -> "This folder is empty. Use ⋮ → Add to folder on any file."; else -> "No documents here yet" },
                                color = cs.onSurfaceVariant
                            )
                            if (view.isEmpty() && query.isBlank()) {
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = { importer.launch(DOC_MIMES) }) { Text("Import files") }
                            }
                        }
                    }
                    else -> items(shown, key = { it.uri }) { d ->
                        val inFolder = if (view.startsWith("folder:")) view.removePrefix("folder:") else null
                        DocRow(
                            d,
                            onClick = {
                                if (selecting) selected = if (d.uri in selected) selected - d.uri else selected + d.uri
                                else if (d.kind == DocKind.WORD) wordChoice = d
                                else openDoc(ctx, d, act.openPdf, act.listen)
                            },
                            checked = if (selecting) d.uri in selected else null,
                            menu = rowMenu(d, inFolder)
                        )
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ sheets and dialogs
    if (showPlus) {
        PlusSheet(
            onDismiss = { showPlus = false },
            onPick = { what ->
                showPlus = false
                when (what) {
                    "files" -> importer.launch(DOC_MIMES)
                    "images" -> pickImages()
                    "scan" -> act.tool("scan")
                    "create" -> act.createPdf()
                    "folder" -> newFolder = true
                    else -> act.pick(what)
                }
            }
        )
    }
    if (newFolder) {
        CreateFolderDialog(onDismiss = { newFolder = false }) { name ->
            if (Library.createFolder(ctx, name)) {
                newFolder = false
                tick++
                folderFor?.let { list -> Library.addToFolder(ctx, name.trim(), list); folderFor = null; selecting = false; selected = emptySet(); Toast.makeText(ctx, "Added to $name", Toast.LENGTH_SHORT).show() }
                    ?: run { view = "folders" }
            } else Toast.makeText(ctx, "That folder already exists", Toast.LENGTH_SHORT).show()
        }
    }
    folderFor?.let { list ->
        if (!newFolder) AlertDialog(
            onDismissRequest = { folderFor = null },
            title = { Text("Add to folder") },
            text = {
                Column {
                    folders.keys.forEach { name ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                Library.addToFolder(ctx, name, list); folderFor = null; selecting = false; selected = emptySet(); tick++
                                Toast.makeText(ctx, "Added to $name", Toast.LENGTH_SHORT).show()
                            }.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Folder, contentDescription = null, tint = Color(0xFFE9A800)); Spacer(Modifier.width(12.dp)); Text(name)
                        }
                    }
                    Row(Modifier.fillMaxWidth().clickable { newFolder = true }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.CreateNewFolder, contentDescription = null, tint = cs.primary); Spacer(Modifier.width(12.dp)); Text("New folder", color = cs.primary)
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { folderFor = null }) { Text("Cancel") } }
        )
    }
    renaming?.let { d ->
        var name by remember(d.uri) { mutableStateOf(d.name.substringBeforeLast('.')) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, suffix = { Text("." + d.name.substringAfterLast('.', "")) }) },
            confirmButton = {
                TextButton(onClick = {
                    val r = Library.rename(ctx, d, name)
                    if (r == null) Toast.makeText(ctx, "Couldn't rename (the name may be taken)", Toast.LENGTH_LONG).show()
                    renaming = null; reload()
                }) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } }
        )
    }
    deleting?.let { list ->
        val onPhone = list.any { it.path != null }
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(if (list.size == 1) "Delete \"${list[0].name}\"?" else "Delete ${list.size} files?") },
            text = { Text(if (onPhone) "The file is removed from your phone. This can't be undone." else "It is removed from this list. The file itself stays where it is.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        withContext(Dispatchers.IO) { list.forEach { Library.delete(ctx, it) } }
                        deleting = null; selecting = false; selected = emptySet(); reload()
                    }
                }) { Text("Delete", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
    wordChoice?.let { d ->
        AlertDialog(
            onDismissRequest = { wordChoice = null },
            title = { Text(d.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = { Text("Turn this Word file into a PDF you can view and edit here, listen to it read aloud, or open it in another app.") },
            confirmButton = {
                Row {
                    if (d.name.endsWith(".docx", true)) TextButton(onClick = { wordChoice = null; act.listen(Uri.parse(d.uri)) }) { Text("Listen") }
                    TextButton(onClick = { wordChoice = null; act.convert("WORD_TO_PDF", Uri.parse(d.uri)) }) { Text("Convert to PDF") }
                }
            },
            dismissButton = { TextButton(onClick = { wordChoice = null; openDoc(ctx, d, act.openPdf) }) { Text("Open with…") } }
        )
    }
    busy?.let { b ->
        AlertDialog(onDismissRequest = {}, confirmButton = {}, text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp); Spacer(Modifier.width(16.dp)); Text(b)
            }
        })
    }
}

@Composable
private fun BigTile(label: String, icon: ImageVector, colors: Pair<Color, Color>, modifier: Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, color = MaterialTheme.colorScheme.surfaceContainer, shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(Modifier.padding(vertical = 12.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            TileIcon(icon, colors)
            Spacer(Modifier.height(8.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1)
        }
    }
}

@Composable
private fun FoldersList(folders: Map<String, List<DocFile>>, onOpen: (String) -> Unit, onNew: () -> Unit, onDelete: (String) -> Unit) {
    var confirm by remember { mutableStateOf<String?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
        if (folders.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.Folder, contentDescription = null, tint = Color(0xFFF2B400), modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(8.dp))
                Text("No folders yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onNew) { Text("Create folder") }
            }
        }
        items(folders.keys.toList(), key = { it }) { name ->
            var open by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().clickable { onOpen(name) }.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Folder, contentDescription = null, tint = Color(0xFFF2B400), modifier = Modifier.size(38.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                    val n = folders[name]?.size ?: 0
                    Text("$n file${if (n == 1) "" else "s"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box {
                    IconButton(onClick = { open = true }) { Icon(Icons.Outlined.MoreVert, contentDescription = "More") }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        DropdownMenuItem(text = { Text("Delete folder") }, onClick = { open = false; confirm = name })
                    }
                }
            }
        }
    }
    confirm?.let { name ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Delete folder \"$name\"?") },
            text = { Text("Only the folder is removed. The files in it stay on your phone.") },
            confirmButton = { TextButton(onClick = { onDelete(name); confirm = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}

/** The red "+" button's sheet: Import, Create and Convert, as in the approved design. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlusSheet(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 18.dp)) {
            @Composable
            fun Section(t: String) = Text(t, style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 2.dp, top = 6.dp, bottom = 8.dp))
            @Composable
            fun Big(label: String, icon: ImageVector, colors: Pair<Color, Color>, key: String, modifier: Modifier) {
                Surface(onClick = { onPick(key) }, color = colors.first, shape = RoundedCornerShape(14.dp), modifier = modifier.height(84.dp)) {
                    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(icon, contentDescription = null, tint = colors.second, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.height(6.dp))
                        Text(label, fontWeight = FontWeight.Medium, color = Color(0xFF1B1F1E))
                    }
                }
            }
            @Composable
            fun Small(label: String, icon: ImageVector, tint: Color, key: String, modifier: Modifier) {
                Surface(onClick = { onPick(key) }, color = cs.surfaceContainer, shape = RoundedCornerShape(12.dp), modifier = modifier.height(50.dp)) {
                    Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 2)
                    }
                }
            }
            Section("Import")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Big("Files", Icons.Outlined.Download, TileBlue, "files", Modifier.weight(1f))
                Big("Images", Icons.Outlined.Image, TileGreen, "images", Modifier.weight(1f))
                Big("Scan", Icons.Outlined.DocumentScanner, TileCyan, "scan", Modifier.weight(1f))
            }
            Section("Create")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Small("Create PDF", Icons.Outlined.NoteAdd, TilePink.second, "create", Modifier.weight(1f))
                Small("Create folder", Icons.Outlined.CreateNewFolder, TileYellow.second, "folder", Modifier.weight(1f))
            }
            Section("Convert")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Small("Word to PDF", Icons.Outlined.NoteAdd, TileBlue.second, "WORD_TO_PDF", Modifier.weight(1f))
                Small("PDF to Word", Icons.Outlined.NoteAdd, TileViolet.second, "PDF_TO_WORD", Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Small("PDF to Image", Icons.Outlined.Image, TilePink.second, "PDF_TO_JPG", Modifier.weight(1f))
                Small("PDF to Long Image", Icons.Outlined.ViewDay, TileYellow.second, "LONG_IMAGE", Modifier.weight(1f))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CreateFolderDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf(androidx.compose.ui.text.input.TextFieldValue("New folder", androidx.compose.ui.text.TextRange(0, 10))) }
    val focus = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (ignored: Exception) {} }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp).padding(bottom = 18.dp)) {
            Icon(Icons.Outlined.Folder, contentDescription = null, tint = Color(0xFFF2B400), modifier = Modifier.size(56.dp))
            Text("Create folder", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
            TextField(
                value = name, onValueChange = { name = it }, singleLine = true,
                trailingIcon = { IconButton(onClick = { name = androidx.compose.ui.text.input.TextFieldValue("") }) { Icon(Icons.Outlined.Close, contentDescription = "Clear") } },
                colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().focusRequester(focus)
            )
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f).height(44.dp).background(MaterialTheme.colorScheme.surfaceContainer, RoundedCornerShape(22.dp))
                ) { Text("Cancel", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface) }
                Button(onClick = { onCreate(name.text) }, enabled = name.text.isNotBlank(), modifier = Modifier.weight(1f).height(44.dp)) { Text("Create", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

/** First launch: ask for "All files access" so every document on the phone can be listed. */
@Composable
private fun AccessScreen(onAllow: () -> Unit, onLater: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxSize().background(cs.background).padding(horizontal = 28.dp).padding(top = 110.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(96.dp).background(cs.primaryContainer, RoundedCornerShape(26.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Folder, contentDescription = null, tint = cs.onPrimaryContainer, modifier = Modifier.size(46.dp))
        }
        Text("Show all your documents", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 12.dp))
        Text(
            buildAnnotatedString {
                append("To list every PDF, Word, Excel and PowerPoint file on your phone, AI PDF Studio needs ")
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("All files access") }
                append(".\n\nYour files stay on your phone. Nothing is uploaded.")
            },
            style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Button(onClick = onAllow, modifier = Modifier.fillMaxWidth().padding(top = 26.dp, bottom = 12.dp).height(50.dp), shape = RoundedCornerShape(25.dp)) {
            Text("Allow access", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        TextButton(onClick = onLater) { Text("Not now (show only files I open)", fontWeight = FontWeight.SemiBold) }
    }
}

// ------------------------------------------------------------------ select a file

private val modeTitles = mapOf(
    "WORD_TO_PDF" to "Word to PDF", "PDF_TO_WORD" to "PDF to Word",
    "PDF_TO_JPG" to "PDF to Image", "LONG_IMAGE" to "PDF to Long Image", "LISTEN" to "Listen"
)

/** "Select a file" list for a convert tool: every matching document, with search. */
@Composable
fun SelectFileScreen(mode: String, onBack: () -> Unit, onChosen: (Uri) -> Unit, onChosenMany: (List<Uri>) -> Unit = {}) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val word = mode == "WORD_TO_PDF"
    val listen = mode == "LISTEN"
    var docs by remember { mutableStateOf<List<DocFile>?>(null) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(mode) {
        docs = withContext(Dispatchers.IO) { Library.all(ctx) }.filter {
            when {
                word -> it.kind == DocKind.WORD && it.name.endsWith(".docx", true)
                listen -> it.kind == DocKind.PDF || it.kind == DocKind.EPUB || it.kind == DocKind.ZIP || it.name.endsWith(".docx", true) || it.name.endsWith(".txt", true)
                else -> it.kind == DocKind.PDF
            }
        }
    }
    val browse = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) onChosen(u) }
    val browseMany = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        if (us.size == 1) onChosen(us[0]) else if (us.size > 1) onChosenMany(us)
    }
    val shown = docs?.filter { query.isBlank() || it.name.contains(query, true) } ?: emptyList()
    Scaffold(containerColor = cs.background, contentWindowInsets = WindowInsets.statusBars) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
                Text("${modeTitles[mode] ?: "Convert"} · Select a file", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            TextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Search…") },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                shape = RoundedCornerShape(22.dp),
                colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
            )
            if (listen) Row(Modifier.padding(start = 16.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("PDF · EPUB · Word · Text · ", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Text("ZIP book", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant)
                Text("NEW", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, modifier = Modifier.padding(start = 6.dp).background(Color(0xFF7E57C2), RoundedCornerShape(8.dp)).padding(horizontal = 6.dp, vertical = 1.dp))
            }
            Text("${shown.size} in all", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 2.dp))
            LazyColumn(Modifier.weight(1f)) {
                if (docs == null) item { Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
                items(shown, key = { it.uri }) { d -> DocRow(d, onClick = { onChosen(Uri.parse(d.uri)) }, radio = true) }
                if (word) item {
                    Text(
                        "Keeps text, headings, bold/italic, lists, tables and pictures.",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth().padding(16.dp).background(cs.surfaceContainer, RoundedCornerShape(10.dp)).padding(12.dp)
                    )
                }
            }
            TextButton(
                onClick = {
                    browse.launch(
                        when {
                            word -> arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                            listen -> arrayOf("application/pdf", "application/epub+zip", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain", "application/zip", "application/x-zip-compressed")
                            else -> arrayOf("application/pdf")
                        }
                    )
                },
                modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(8.dp)
            ) { Text("Browse phone for another file") }
            if (listen) TextButton(
                onClick = { browseMany.launch(arrayOf("application/pdf", "application/epub+zip", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain", "image/*")) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp).padding(bottom = 8.dp)
            ) { Text("Pick several files as one book") }
        }
    }
}

// ------------------------------------------------------------------ bookmarks tab

@Composable
fun BookmarksScreen(onOpenPdf: (Uri) -> Unit, onConvert: (String, Uri?) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var tick by remember { mutableIntStateOf(0) }
    val list = remember(tick) { Library.bookmarks(ctx) }
    Scaffold(containerColor = cs.background, contentWindowInsets = WindowInsets.statusBars) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Text("Bookmarks", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp))
            if (list.isEmpty()) {
                Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = cs.outline, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("No bookmarks yet.\nIn Files, tap ⋮ → Bookmark on any file.", color = cs.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
            LazyColumn {
                items(list, key = { it.uri }) { d ->
                    DocRow(
                        d,
                        onClick = { if (d.kind == DocKind.WORD) onConvert("WORD_TO_PDF", Uri.parse(d.uri)) else openDoc(ctx, d, onOpenPdf) },
                        menu = { close ->
                            DropdownMenuItem(text = { Text("Share") }, leadingIcon = { Icon(Icons.Outlined.Share, null) }, onClick = { close(); Library.share(ctx, listOf(d)) })
                            DropdownMenuItem(text = { Text("Remove bookmark") }, leadingIcon = { Icon(Icons.Outlined.Bookmark, null) }, onClick = { close(); Library.toggleBookmark(ctx, d); tick++ })
                        }
                    )
                }
            }
        }
    }
}

@Suppress("unused")
private fun Modifier.thinBorder() = this.border(1.dp, Color(0x22000000), CircleShape)
@Suppress("unused")
private val unusedOffset = Offset.Zero
