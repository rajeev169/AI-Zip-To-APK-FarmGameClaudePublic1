package com.aipdfstudio.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.CloudLinks
import com.aipdfstudio.app.data.CompareOps
import com.aipdfstudio.app.data.DiffKind
import com.aipdfstudio.app.data.FieldType
import com.aipdfstudio.app.data.FormOps
import com.aipdfstudio.app.data.Monetization
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PageDiff
import com.aipdfstudio.app.data.Picked
import com.aipdfstudio.app.data.RecentFile
import com.aipdfstudio.app.data.RecentStore
import com.aipdfstudio.app.data.fmtSize
import java.io.File

// ------------------------------------------------------------------ Forms

@Composable
fun FormsScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel(), initial: Uri? = null) {
    Preselect(vm, initial)
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri), replace = true)
    }
    var flatten by rememberSaveable { mutableStateOf(false) }
    val p = vm.single
    val usable = p != null && !p.locked && !p.broken
    val fields = vm.formFields
    // Load the fields once a new file has been probed.
    androidx.compose.runtime.LaunchedEffect(p?.uri, vm.loading) {
        if (!vm.loading && p != null && fields.isEmpty() && vm.error == null) vm.loadForm()
    }

    ToolPage(
        title = "Fill form",
        vm = vm,
        onBack = onBack,
        actionLabel = if (fields.isEmpty()) "Choose a PDF form" else "Save filled form",
        actionEnabled = usable && fields.isNotEmpty(),
        onAction = act@{
            val src = p ?: return@act
            val values = vm.formValues.toMap()
            val flat = flatten
            vm.run("Saving form…") {
                val out = Outputs.newFile(ctx, src.name, "filled")
                FormOps.save(ctx, src.uri, values, flat, out)
                listOf(out) to if (flat) "Saved. The answers are now part of the page and can't be changed." else "Saved. You can still change the answers later."
            }
        }
    ) {
        item(key = "hint") { Hint("Fill in PDF forms that have boxes to type in, tick boxes and choices.") }
        item(key = "file") { PickedCard(p, vm.loading) { picker.launch(arrayOf("application/pdf")) } }
        if (p != null && p.locked) {
            item(key = "locked") { MessageCard("This PDF is password protected. Unlock it first with the Unlock tool.", isError = true) }
        }
        if (fields.isNotEmpty()) {
            item(key = "count") {
                Text("${fields.size} field${if (fields.size == 1) "" else "s"}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            }
            fields.forEach { f ->
                item(key = "f_" + f.name) {
                    val v = vm.formValues[f.name] ?: ""
                    fun set(x: String) { vm.formValues[f.name] = x; vm.clearOutcome() }
                    when (f.type) {
                        FieldType.TEXT, FieldType.MULTILINE -> OutlinedTextField(
                            value = v,
                            onValueChange = { set(it) },
                            label = { Text(f.label) },
                            enabled = !f.readOnly,
                            singleLine = f.type == FieldType.TEXT,
                            minLines = if (f.type == FieldType.MULTILINE) 3 else 1,
                            modifier = Modifier.fillMaxWidth()
                        )
                        FieldType.CHECKBOX -> Row(
                            Modifier.fillMaxWidth().clickable(enabled = !f.readOnly) { set((v != "true").toString()) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = v == "true", onCheckedChange = { set(it.toString()) }, enabled = !f.readOnly)
                            Text(f.label)
                        }
                        FieldType.RADIO, FieldType.CHOICE -> Column {
                            Text(f.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            if (f.type == FieldType.RADIO) {
                                f.options.forEach { o ->
                                    Row(
                                        Modifier.fillMaxWidth().clickable(enabled = !f.readOnly) { set(o) },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(selected = v == o, onClick = { set(o) }, enabled = !f.readOnly)
                                        Text(o)
                                    }
                                }
                            } else {
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    f.options.forEach { o ->
                                        FilterChip(selected = v == o, onClick = { set(o) }, enabled = !f.readOnly, label = { Text(o) })
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item(key = "flatten") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Lock the answers", fontWeight = FontWeight.Medium)
                        Hint("Turn the answers into normal page content so nobody can change them.")
                    }
                    Switch(checked = flatten, onCheckedChange = { flatten = it })
                }
            }
        }
        outcome(vm, onOpen)
    }
}

// ------------------------------------------------------------------ Compare

@Composable
fun CompareScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val pickA = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.pickCompare(u, true) }
    val pickB = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.pickCompare(u, false) }
    var visual by rememberSaveable { mutableStateOf(false) }
    val a = vm.compareA
    val b = vm.compareB
    fun ok(x: Picked?) = x != null && !x.locked && !x.broken

    ToolPage(
        title = "Compare PDFs",
        vm = vm,
        onBack = onBack,
        actionLabel = if (ok(a) && ok(b)) "Compare" else "Choose both PDFs",
        actionEnabled = ok(a) && ok(b),
        onAction = act@{
            val x = a ?: return@act
            val y = b ?: return@act
            val withVisual = visual
            vm.run("Comparing…") { progress ->
                val files = ArrayList<File>()
                var textDiffs: List<PageDiff>? = null
                try {
                    textDiffs = CompareOps.text(ctx, x.uri, y.uri)
                } catch (e: com.aipdfstudio.app.data.UserError) {
                    if (!withVisual) throw e
                }
                textDiffs?.let { d ->
                    vm.postDiffs(d)
                    val rep = Outputs.newFile(ctx, y.name, "comparison", "txt")
                    rep.writeText(CompareOps.report(x.name, y.name, d))
                    files.add(rep)
                }
                var visualNote = ""
                if (withVisual) {
                    val out = Outputs.newFile(ctx, y.name, "visual_comparison")
                    val n = CompareOps.visual(ctx, x.uri, y.uri, out, progress)
                    files.add(0, out)
                    visualNote = " Visual check: $n page${if (n == 1) "" else "s"} look different (marked in red)."
                }
                val changed = textDiffs?.count { it.changed }
                val summary = when {
                    changed == null -> "No text to compare."
                    changed == 0 -> "The text is the same."
                    else -> "Text changed on $changed page${if (changed == 1) "" else "s"}."
                }
                files to (summary + visualNote)
            }
        }
    ) {
        item(key = "hint") { Hint("Find what changed between two versions of a document, page by page.") }
        item(key = "a") { CompareSlot("Original", a) { pickA.launch(arrayOf("application/pdf")) } }
        item(key = "b") { CompareSlot("Changed version", b) { pickB.launch(arrayOf("application/pdf")) } }
        item(key = "visual") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Also compare how pages look", fontWeight = FontWeight.Medium)
                    Hint("Makes a PDF with differences in red. Works for scans and pictures too.")
                }
                Switch(checked = visual, onCheckedChange = { visual = it; vm.clearOutcome() })
            }
        }
        outcome(vm, onOpen)
        vm.diffs?.filter { it.changed }?.forEach { d ->
            item(key = "diff_${d.page}") { DiffCard(d) }
        }
    }
}

@Composable
private fun CompareSlot(title: String, p: Picked?, onPick: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
        PickedCard(p, false, onPick)
    }
}

@Composable
private fun DiffCard(d: PageDiff) {
    var all by remember { mutableStateOf(false) }
    val lines = d.lines.filter { it.kind != DiffKind.SAME }
    val shown = if (all) lines else lines.take(20)
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Page ${d.page + 1}  ·  ${d.added} added, ${d.removed} removed", fontWeight = FontWeight.Medium)
            shown.forEach { l ->
                val added = l.kind == DiffKind.ADDED
                Text(
                    (if (added) "+ " else "− ") + l.text,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (added) Color(0xFF0B5E2E) else Color(0xFF9B1C1C),
                    modifier = Modifier.fillMaxWidth()
                        .background(if (added) Color(0xFFDDF5E5) else Color(0xFFFBE0E0), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            if (lines.size > shown.size) {
                Text(
                    "Show all ${lines.size} changes",
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clickable { all = true }.padding(vertical = 6.dp)
                )
            }
        }
    }
}

// ------------------------------------------------------------------ Open from link

@Composable
fun LinkScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val recents = remember { RecentStore(ctx) }
    var link by rememberSaveable { mutableStateOf("") }
    val valid = CloudLinks.isWebLink(link)

    ToolPage(
        title = "Open from link",
        vm = vm,
        onBack = onBack,
        actionLabel = "Download and open",
        actionEnabled = valid,
        onAction = {
            val l = link.trim()
            vm.run("Connecting…") { progress ->
                val f = CloudLinks.download(ctx, l, progress)
                val u = Outputs.uri(ctx, f)
                recents.upsert(RecentFile(u.toString(), f.name, 0, 0, System.currentTimeMillis(), f.length()))
                listOf(f) to "Downloaded ${fmtSize(f.length())}. It's also in your recent files."
            }
        }
    ) {
        item(key = "hint") {
            Hint("Paste a link to a PDF from Google Drive, Google Docs, Dropbox or any website. The file must be shared publicly (\"Anyone with the link\").")
        }
        item(key = "field") {
            OutlinedTextField(
                value = link,
                onValueChange = { link = it.trim(); vm.clearOutcome() },
                label = { Text("Link") },
                placeholder = { Text("https://…") },
                singleLine = true,
                isError = link.isNotEmpty() && !valid,
                supportingText = { if (link.isNotEmpty() && !valid) Text("A link starts with https://") },
                trailingIcon = {
                    IconButton(onClick = { clipboard.getText()?.text?.let { link = it.trim(); vm.clearOutcome() } }) {
                        Icon(Icons.Outlined.ContentPaste, contentDescription = "Paste")
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
        outcome(vm, onOpen)
    }
}

// ------------------------------------------------------------------ Ads and Premium (switched off)

/** Space for a banner ad. Shows nothing while Monetization.ADS_ENABLED is false. */
@Composable
fun AdSlot(modifier: Modifier = Modifier) {
    if (!Monetization.ADS_ENABLED) return
    Box(
        modifier.fillMaxWidth().height(56.dp)
            .background(MaterialTheme.colorScheme.surfaceContainerHighest, RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        // Replace with the AdMob banner when ads are switched on (see README).
        Text("Ad", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Premium page. Only reachable from Settings when Monetization.PREMIUM_ENABLED is true. */
@Composable
fun PremiumScreen(onBack: () -> Unit, vm: ToolVm = viewModel()) {
    ToolPage(title = "Premium", vm = vm, onBack = onBack, actionLabel = "Coming soon", actionEnabled = false) {
        item(key = "head") {
            Text("AI PDF Studio Premium", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Medium)
        }
        Monetization.premiumPerks.forEach { perk ->
            item(key = perk) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Star, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Text(perk, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
