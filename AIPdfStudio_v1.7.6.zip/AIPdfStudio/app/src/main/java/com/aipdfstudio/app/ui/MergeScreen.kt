package com.aipdfstudio.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PdfOps

@Composable
fun MergeScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.addFiles(uris, replace = false)
    }
    val pickPdfs = { picker.launch(arrayOf("application/pdf")) }
    val blocked = vm.files.any { it.locked || it.broken }
    val totalPages = vm.files.sumOf { maxOf(it.pages, 0) }

    ToolPage(
        title = "Merge PDFs",
        vm = vm,
        onBack = onBack,
        actionLabel = if (vm.files.size < 2) "Add at least 2 PDFs" else "Merge ${vm.files.size} files · $totalPages pages",
        actionEnabled = vm.files.size >= 2 && !blocked,
        onAction = {
            val list = vm.files.toList()
            vm.run("Merging ${list.size} files…") {
                val out = Outputs.newFile(ctx, list.first().name, "merged")
                PdfOps.merge(ctx, list.map { it.uri }, out)
                listOf(out) to null
            }
        }
    ) {
        item(key = "hint") {
            Hint("Add PDFs, put them in the order you want, then merge them into one file.")
        }
        if (vm.files.isEmpty()) {
            item(key = "pick") { PickedCard(null, vm.loading, pickPdfs) }
        } else {
            itemsIndexed(vm.files, key = { _, p -> p.uri.toString() }) { i, p ->
                FileRow(
                    p,
                    leading = {
                        Column {
                            IconButton(onClick = { vm.move(i, -1) }, enabled = i > 0, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Outlined.KeyboardArrowUp, contentDescription = "Move up")
                            }
                            IconButton(onClick = { vm.move(i, 1) }, enabled = i < vm.files.size - 1, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = "Move down")
                            }
                        }
                        Spacer(Modifier.width(4.dp))
                    },
                    trailing = {
                        IconButton(onClick = { vm.removeAt(i) }) {
                            Icon(Icons.Outlined.Close, contentDescription = "Remove")
                        }
                    }
                )
            }
            item(key = "add") {
                OutlinedButton(onClick = pickPdfs, enabled = !vm.loading, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (vm.loading) "Adding…" else "Add more PDFs")
                }
            }
            if (blocked) {
                item(key = "blocked") {
                    Text(
                        "Remove files that are password protected or can't be read. You can unlock a file with the Unlock tool first.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
        outcome(vm, onOpen)
    }
}
