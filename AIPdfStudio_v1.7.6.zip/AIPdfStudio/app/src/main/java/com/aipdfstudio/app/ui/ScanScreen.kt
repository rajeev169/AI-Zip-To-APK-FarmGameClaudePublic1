package com.aipdfstudio.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.Outputs
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun ScanScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val scanner = remember {
        GmsDocumentScanning.getClient(
            GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(60)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build()
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val pdf = GmsDocumentScanningResult.fromActivityResultIntent(res.data)?.pdf
        if (pdf == null) {
            vm.error = "The scanner didn't return a PDF. Please try again."
            return@rememberLauncherForActivityResult
        }
        val pages = pdf.pageCount
        vm.run("Saving your scan…") {
            val stamp = SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())
            val out = Outputs.newFile(ctx, "Scan_$stamp", "")
            val input = ctx.contentResolver.openInputStream(pdf.uri) ?: throw IOException("Can't read the scan")
            input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            listOf(out) to "Scanned $pages page${if (pages == 1) "" else "s"}. Tip: use OCR to make the text searchable."
        }
    }

    fun start() {
        val activity = ctx.findActivity()
        if (activity == null) {
            vm.error = "Couldn't start the scanner."
            return
        }
        vm.clearOutcome()
        scanner.getStartScanIntent(activity)
            .addOnSuccessListener { sender -> launcher.launch(IntentSenderRequest.Builder(sender).build()) }
            .addOnFailureListener {
                vm.error = "The scanner isn't available on this phone. It needs Google Play services. " +
                    "You can still use Convert → Images to PDF with photos."
            }
    }

    ToolPage(
        title = "Scan to PDF",
        vm = vm,
        onBack = onBack,
        actionLabel = if (vm.results.isEmpty()) "Start scanning" else "Scan another document",
        onAction = { start() }
    ) {
        item(key = "hero") {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Outlined.DocumentScanner,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("Scan paper documents", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Hint("Point your camera at the page. Edges are found automatically, and you can crop, rotate, clean up and add more pages before saving.")
                }
            }
        }
        outcome(vm, onOpen)
    }
}
