@file:OptIn(ExperimentalMaterial3Api::class)

package com.aipdfstudio.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.aipdfstudio.app.data.GeminiClient
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(vm: AiViewModel, onBack: () -> Unit, onPremium: () -> Unit = {}) {
    val cs = MaterialTheme.colorScheme
    val uriHandler = LocalUriHandler.current
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(vm.store.apiKey) }
    var model by remember { mutableStateOf(vm.store.model) }
    var show by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("AI settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (com.aipdfstudio.app.data.Monetization.PREMIUM_ENABLED) {
                OutlinedButton(onClick = onPremium, modifier = Modifier.fillMaxWidth()) { Text("Premium") }
            }
            Text("Your Gemini key", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            Text(
                "Get a free key from Google AI Studio, paste it here, then tap Test key.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant
            )
            OutlinedButton(onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") }) {
                Text("Get free key")
            }
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; status = null },
                label = { Text("API key") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { show = !show }) {
                        Icon(
                            if (show) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                            contentDescription = if (show) "Hide key" else "Show key"
                        )
                    }
                }
            )
            OutlinedTextField(
                value = model,
                onValueChange = { model = it; status = null },
                label = { Text("Model") },
                supportingText = { Text("Leave as is unless Google renames the model.") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(
                    onClick = {
                        if (key.isBlank()) {
                            ok = false
                            status = "Paste your key first."
                        } else {
                            testing = true
                            status = null
                            scope.launch {
                                val r = GeminiClient.generate(
                                    key.trim(), model, "Reply with the single word OK.", listOf("user" to "ping")
                                )
                                when (r) {
                                    is GeminiClient.Result.Ok -> { ok = true; status = "Key works." }
                                    is GeminiClient.Result.Err -> { ok = false; status = r.message }
                                }
                                testing = false
                            }
                        }
                    },
                    enabled = !testing
                ) { Text("Test key") }
                Button(onClick = {
                    vm.store.apiKey = key
                    vm.store.model = model
                    vm.refreshKey()
                    ok = true
                    status = "Saved."
                }) { Text("Save") }
                if (testing) CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
            }

            val s = status
            if (s != null) {
                Text(s, color = if (ok) cs.primary else cs.error, style = MaterialTheme.typography.bodyMedium)
            }

            if (vm.store.apiKey.isNotBlank()) {
                TextButton(onClick = {
                    vm.store.apiKey = ""
                    key = ""
                    vm.refreshKey()
                    ok = true
                    status = "Key removed."
                }) { Text("Remove saved key") }
            }

            Surface(shape = RoundedCornerShape(16.dp), color = cs.surfaceContainer) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Privacy", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
                    Text(
                        "Your key is stored encrypted on this device. When you use AI, the text of the PDF " +
                            "you pick is sent directly to Google's Gemini API using your key. On Google's free tier, " +
                            "Google may use that content to improve its products.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
