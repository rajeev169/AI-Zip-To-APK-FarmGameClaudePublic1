package com.aipdfstudio.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.Placement
import com.aipdfstudio.app.data.SignOps
import com.aipdfstudio.app.data.SigInk
import com.aipdfstudio.app.data.Signatures
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val InkColors = listOf("Black" to Color(0xFF111111), "Blue" to Color(0xFF1A3FB5))

@Composable
fun SignScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri), replace = true, forPages = true)
    }
    var saved by remember { mutableStateOf(Signatures.list(ctx)) }
    var showPad by remember { mutableStateOf(false) }
    LaunchedEffect(saved) {
        if (vm.signature == null && saved.isNotEmpty()) vm.signature = saved.first()
    }

    val p = vm.single
    val usable = p != null && !p.locked && !p.broken && p.pages > 0
    val sig = vm.signature
    val sigBmp = remember(sig) { sig?.let { BitmapFactory.decodeFile(it.path) } }
    val placedCount = vm.placements.size

    ToolPage(
        title = "Sign PDF",
        vm = vm,
        onBack = onBack,
        actionLabel = when {
            !usable -> "Choose a PDF"
            sig == null -> "Make your signature first"
            placedCount == 0 -> "Place your signature on a page"
            else -> "Save signed PDF ($placedCount page${if (placedCount == 1) "" else "s"})"
        },
        actionEnabled = usable && sig != null && placedCount > 0,
        onAction = act@{
            val src = p ?: return@act
            val s = sig ?: return@act
            val spots = vm.placements.toMap()
            vm.run("Signing…") {
                val out = Outputs.newFile(ctx, src.name, "signed")
                SignOps.sign(ctx, src.uri, s, spots, out)
                listOf(out) to "Signed on ${spots.size} page${if (spots.size == 1) "" else "s"}."
            }
        }
    ) {
        item(key = "hint") { Hint("Make your signature once, then drag it onto any page. Your original file is not changed.") }
        item(key = "file") { PickedCard(p, vm.loading) { picker.launch(arrayOf("application/pdf")) } }
        if (p != null && p.locked) {
            item(key = "locked") { MessageCard("This PDF is password protected. Unlock it first with the Unlock tool.", isError = true) }
        }
        item(key = "sigs") {
            SignaturePicker(
                saved = saved,
                selected = sig,
                onSelect = { vm.signature = it; vm.clearOutcome() },
                onNew = { showPad = true },
                onDelete = { f ->
                    Signatures.delete(f)
                    saved = Signatures.list(ctx)
                    if (vm.signature == f) vm.signature = saved.firstOrNull()
                }
            )
        }
        if (usable && sig != null && sigBmp != null) {
            item(key = "place") { PlacePanel(vm, p!!.pages, sigBmp) }
        }
        outcome(vm, onOpen)
    }

    if (showPad) {
        SignatureAdder(onDismiss = { showPad = false }) { f ->
            saved = Signatures.list(ctx)
            vm.signature = f
            showPad = false
        }
    }
}

@Composable
internal fun SignaturePicker(
    saved: List<File>,
    selected: File?,
    onSelect: (File) -> Unit,
    onNew: () -> Unit,
    onDelete: (File) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Your signature", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            saved.forEach { f ->
                val bmp = remember(f) { BitmapFactory.decodeFile(f.path) }
                val isSel = f == selected
                Surface(
                    onClick = { onSelect(f) },
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    border = BorderStroke(if (isSel) 2.dp else 1.dp, if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.size(width = 130.dp, height = 64.dp)
                ) {
                    Box {
                        if (bmp != null) {
                            Image(
                                bmp.asImageBitmap(),
                                contentDescription = "Saved signature",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize().padding(6.dp)
                            )
                        }
                        if (isSel) {
                            IconButton(onClick = { onDelete(f) }, modifier = Modifier.align(Alignment.TopEnd).size(28.dp)) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Delete signature", tint = Color(0xFF666666), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
            OutlinedButton(onClick = onNew, modifier = Modifier.height(64.dp)) {
                Icon(Icons.Outlined.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (saved.isEmpty()) "Create signature" else "New")
            }
        }
    }
}

@Composable
private fun PlacePanel(vm: ToolVm, pageCount: Int, sigBmp: Bitmap) {
    val page = vm.page.coerceIn(0, pageCount - 1)
    val thumbs = vm.thumbs
    var pageBmp by remember(thumbs, page) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(thumbs, page) { pageBmp = withContext(Dispatchers.IO) { thumbs?.get(page, 1000) } }
    val sigImage = remember(sigBmp) { sigBmp.asImageBitmap() }
    val sigRatio = sigBmp.height.toFloat() / max(1, sigBmp.width)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Place it", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            IconButton(onClick = { vm.page = page - 1 }, enabled = page > 0) {
                Icon(Icons.AutoMirrored.Outlined.KeyboardArrowLeft, contentDescription = "Previous page")
            }
            Text("Page ${page + 1} of $pageCount", style = MaterialTheme.typography.labelLarge)
            IconButton(onClick = { vm.page = page + 1 }, enabled = page < pageCount - 1) {
                Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = "Next page")
            }
        }
        val b = pageBmp
        if (b == null) {
            Box(Modifier.fillMaxWidth().aspectRatio(0.707f).background(Color.White), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(Modifier.size(28.dp))
            }
        } else {
            PlaceOnPage(vm, page, pageCount, b, sigImage, sigRatio)
        }
        if (vm.placements.isNotEmpty()) {
            Text(
                "Signed pages: " + vm.placements.keys.sorted().joinToString(", ") { (it + 1).toString() },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PlaceOnPage(
    vm: ToolVm,
    page: Int,
    pageCount: Int,
    b: Bitmap,
    sigImage: androidx.compose.ui.graphics.ImageBitmap,
    sigRatio: Float
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        val pageAspect = b.width.toFloat() / b.height
        fun spotHeight(fw: Float) = fw * pageAspect * sigRatio
        val spot = vm.placements[page]

        BoxWithConstraints(
            Modifier.fillMaxWidth().aspectRatio(pageAspect)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                .background(Color.White)
        ) {
            val density = LocalDensity.current
            val wPx = with(density) { maxWidth.toPx() }
            val hPx = with(density) { maxHeight.toPx() }
            Image(b.asImageBitmap(), contentDescription = "Page ${page + 1}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
            if (spot != null) {
                val boxW = with(density) { (spot.fw * wPx).toDp() }
                val boxH = with(density) { (spot.fh * hPx).toDp() }
                Box(
                    Modifier
                        .offset { IntOffset((spot.fx * wPx).roundToInt(), (spot.fy * hPx).roundToInt()) }
                        .size(boxW, boxH)
                        .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
                        .pointerInput(page, wPx, hPx) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                val cur = vm.placements[page] ?: return@detectDragGestures
                                vm.placements[page] = cur.copy(
                                    fx = (cur.fx + drag.x / wPx).coerceIn(0f, max(0f, 1f - cur.fw)),
                                    fy = (cur.fy + drag.y / hPx).coerceIn(0f, max(0f, 1f - cur.fh))
                                )
                            }
                        }
                ) {
                    Image(sigImage, contentDescription = "Your signature", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
            }
        }

        if (spot == null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                androidx.compose.material3.Button(onClick = {
                    val fw = 0.35f
                    val fh = min(0.5f, spotHeight(fw))
                    vm.placements[page] = Placement(0.55f, (0.85f - fh).coerceAtLeast(0f), fw, fh)
                    vm.clearOutcome()
                }) { Text("Add to this page") }
            }
        } else {
            Hint("Drag the signature to move it. Use the slider to change its size.")
            Slider(
                value = spot.fw,
                valueRange = 0.1f..0.9f,
                onValueChange = { fw ->
                    val fh = spotHeight(fw)
                    if (fh <= 1f) {
                        vm.placements[page] = spot.copy(
                            fw = fw,
                            fh = fh,
                            fx = spot.fx.coerceAtMost(max(0f, 1f - fw)),
                            fy = spot.fy.coerceAtMost(max(0f, 1f - fh))
                        )
                    }
                }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.placements.remove(page); vm.clearOutcome() }) { Text("Remove") }
                if (pageCount > 1) {
                    OutlinedButton(onClick = {
                        for (i in 0 until pageCount) vm.placements[i] = spot
                        vm.clearOutcome()
                    }) { Text("Same spot on all pages") }
                }
            }
        }
    }
}

@Composable
internal fun SignatureDialog(onDismiss: () -> Unit, onDone: (Bitmap, SigInk?) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var colorIdx by remember { mutableIntStateOf(0) }
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    val current = remember { mutableStateListOf<Offset>() }
    var typed by remember { mutableStateOf("") }
    val ink = InkColors[colorIdx].second
    val density = LocalDensity.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create signature") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Draw") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Type") })
                }
                if (tab == 0) {
                    Box(
                        Modifier.fillMaxWidth().height(180.dp)
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                    ) {
                        Canvas(
                            Modifier.fillMaxSize().pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { o -> current.clear(); current.add(o) },
                                    onDragEnd = {
                                        if (current.size > 1) strokes.add(current.toList())
                                        current.clear()
                                    },
                                    onDragCancel = { current.clear() }
                                ) { change, _ ->
                                    change.consume()
                                    current.add(change.position)
                                }
                            }
                        ) {
                            val w = with(density) { 3.dp.toPx() }
                            (strokes + listOf(current.toList())).forEach { pts ->
                                if (pts.size > 1) {
                                    val path = Path().apply {
                                        moveTo(pts[0].x, pts[0].y)
                                        for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y)
                                    }
                                    drawPath(path, ink, style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                                }
                            }
                        }
                        if (strokes.isEmpty() && current.isEmpty()) {
                            Text("Sign here with your finger", color = Color(0xFF999999), modifier = Modifier.align(Alignment.Center))
                        }
                    }
                    TextButton(onClick = { strokes.clear() }, enabled = strokes.isNotEmpty()) { Text("Clear") }
                } else {
                    OutlinedTextField(
                        value = typed,
                        onValueChange = { typed = it.take(40) },
                        label = { Text("Your name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Box(
                        Modifier.fillMaxWidth().height(90.dp).background(Color.White, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(typed.ifBlank { "Your name" }, style = TextStyle(fontFamily = FontFamily.Cursive, fontSize = 36.sp, color = if (typed.isBlank()) Color(0xFFBBBBBB) else ink))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InkColors.forEachIndexed { i, (name, _) ->
                        FilterChip(selected = colorIdx == i, onClick = { colorIdx = i }, label = { Text(name) })
                    }
                }
            }
        },
        confirmButton = {
            val ready = if (tab == 0) strokes.isNotEmpty() else typed.isNotBlank()
            TextButton(enabled = ready, onClick = {
                if (tab == 0) {
                    strokesToBitmap(strokes.toList(), ink.toArgb(), with(density) { 3.dp.toPx() })?.let { (bmp, sig) -> onDone(bmp, sig) }
                } else {
                    onDone(textToBitmap(typed.trim(), ink.toArgb()), null)
                }
            }) { Text("Use signature") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/**
 * Draws the strokes on a transparent bitmap cropped to the ink, at 2x for sharpness, and returns the
 * same strokes as fractions of that picture (so the editor can recolour and re-thicken them).
 */
internal fun strokesToBitmap(strokes: List<List<Offset>>, color: Int, strokePx: Float): Pair<Bitmap, SigInk>? {
    val pts = strokes.flatten()
    if (pts.isEmpty()) return null
    val scale = 2f
    val pad = strokePx * 2
    val minX = pts.minOf { it.x } - pad
    val minY = pts.minOf { it.y } - pad
    val maxX = pts.maxOf { it.x } + pad
    val maxY = pts.maxOf { it.y } + pad
    val w = max(1, ((maxX - minX) * scale).toInt())
    val h = max(1, ((maxY - minY) * scale).toInt())
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.STROKE
        strokeWidth = strokePx * scale
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    strokes.forEach { s ->
        if (s.size < 2) return@forEach
        val path = android.graphics.Path()
        path.moveTo((s[0].x - minX) * scale, (s[0].y - minY) * scale)
        for (i in 1 until s.size) path.lineTo((s[i].x - minX) * scale, (s[i].y - minY) * scale)
        c.drawPath(path, paint)
    }
    val bw = maxX - minX
    val bh = maxY - minY
    val sig = SigInk(
        strokes.filter { it.size > 1 }.map { st -> st.map { ((it.x - minX) / bw) to ((it.y - minY) / bh) } },
        strokePx / bw,
        color and 0xFFFFFF
    )
    return bmp to sig
}

/** Writes the name in a handwriting-style font on a transparent bitmap. */
internal fun textToBitmap(text: String, color: Int): Bitmap {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        textSize = 140f
        typeface = Typeface.create("cursive", Typeface.NORMAL)
    }
    val fm = paint.fontMetrics
    val w = max(1, (paint.measureText(text) + 40).toInt())
    val h = max(1, (fm.descent - fm.ascent + 20).toInt())
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    android.graphics.Canvas(bmp).drawText(text, 20f, 10f - fm.ascent, paint)
    return bmp
}
