package com.aipdfstudio.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF0F7B6C), onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEEE6), onPrimaryContainer = Color(0xFF064038),
    secondary = Color(0xFF4A635E), onSecondary = Color.White,
    secondaryContainer = Color(0xFFCCE8E1), onSecondaryContainer = Color(0xFF05201C),
    tertiary = Color(0xFF7A5900), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFE08A), onTertiaryContainer = Color(0xFF261A00),
    error = Color(0xFFBA1A1A), onError = Color.White,
    errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF4FBF9), onBackground = Color(0xFF161D1B),
    surface = Color(0xFFF4FBF9), onSurface = Color(0xFF161D1B),
    surfaceVariant = Color(0xFFDAE5E1), onSurfaceVariant = Color(0xFF3F4946),
    outline = Color(0xFF6F7976), outlineVariant = Color(0xFFBEC9C5),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFEDF7F4),
    surfaceContainer = Color(0xFFE6F4F0), surfaceContainerHigh = Color(0xFFDFEDE9),
    surfaceContainerHighest = Color(0xFFD9E7E3)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF6FD9C6), onPrimary = Color(0xFF00382F),
    primaryContainer = Color(0xFF005046), onPrimaryContainer = Color(0xFFCDEEE6),
    secondary = Color(0xFFB1CCC5), onSecondary = Color(0xFF1C3530),
    secondaryContainer = Color(0xFF334B46), onSecondaryContainer = Color(0xFFCCE8E1),
    tertiary = Color(0xFFE9C349), onTertiary = Color(0xFF3E2E00),
    tertiaryContainer = Color(0xFF5B4300), onTertiaryContainer = Color(0xFFFFE08A),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A), onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF0E1514), onBackground = Color(0xFFDDE4E1),
    surface = Color(0xFF0E1514), onSurface = Color(0xFFDDE4E1),
    surfaceVariant = Color(0xFF3F4946), onSurfaceVariant = Color(0xFFBEC9C5),
    outline = Color(0xFF899390), outlineVariant = Color(0xFF3F4946),
    surfaceContainerLowest = Color(0xFF090F0E), surfaceContainerLow = Color(0xFF161D1B),
    surfaceContainer = Color(0xFF1A2321), surfaceContainerHigh = Color(0xFF242C2A),
    surfaceContainerHighest = Color(0xFF2F3735)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
