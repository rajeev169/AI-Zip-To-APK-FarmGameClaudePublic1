@file:OptIn(ExperimentalMaterial3Api::class)

package com.aipdfstudio.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aipdfstudio.app.data.Account
import com.aipdfstudio.app.data.AccountUser
import kotlinx.coroutines.launch

private fun Context.activity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

/** Round account picture: the Google photo, or the first letter, or a person icon when signed out. */
@Composable
fun AccountAvatar(user: AccountUser?, size: Dp = 32.dp) {
    val cs = MaterialTheme.colorScheme
    val pic by produceState<ImageBitmap?>(null, user?.photoUrl) { value = Account.photo(user?.photoUrl) }
    Box(
        Modifier.size(size).clip(CircleShape).background(if (user == null) cs.surfaceContainerHigh else cs.primary),
        contentAlignment = Alignment.Center
    ) {
        val p = pic
        when {
            p != null -> Image(p, contentDescription = "Account", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            user != null -> Text(
                (user.name.ifBlank { user.email }).take(1).uppercase(),
                color = cs.onPrimary, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.45f).sp
            )
            else -> Icon(Icons.Outlined.AccountCircle, contentDescription = "Account", tint = cs.onSurfaceVariant, modifier = Modifier.size(size * 0.8f))
        }
    }
}

/** The white "Continue with Google" button with Google's coloured G. */
@Composable
fun GoogleButton(text: String, busy: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick, enabled = !busy, modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(26.dp),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White, contentColor = Color(0xFF1F1F1F))
    ) {
        if (busy) CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
        else Text("G", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF4285F4))
        Spacer(Modifier.width(12.dp))
        Text(if (busy) "Signing in…" else text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
    }
}

/** Shown once on first start: sign in with Google or skip. */
@Composable
fun WelcomeSignIn(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val user by Account.user.collectAsState()
    LaunchedEffect(user) { if (user != null) { Account.setIntroSeen(ctx); onDone() } }

    Column(
        Modifier.fillMaxSize().background(cs.background).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(72.dp))
        Box(Modifier.size(88.dp).clip(RoundedCornerShape(24.dp)).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.PictureAsPdf, contentDescription = null, tint = cs.onPrimaryContainer, modifier = Modifier.size(48.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Welcome to AI PDF Studio", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(
            "Sign in with your Google account, or skip and start using the app.",
            style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(40.dp))
        GoogleButton("Continue with Google", busy, Modifier.fillMaxWidth()) {
            val act = ctx.activity() ?: return@GoogleButton
            busy = true; error = null
            scope.launch {
                try { Account.signIn(act) } catch (e: Account.SignInError) { if (!e.cancelled) error = e.message }
                busy = false
            }
        }
        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = cs.error, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { Account.setIntroSeen(ctx); onDone() }, enabled = !busy) { Text("Skip for now") }
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Lock, contentDescription = null, tint = cs.onSurfaceVariant, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                "Your PDFs stay on your phone. Signing in only shares your name, email and photo with the app.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** Account page: sign in, or see the signed-in account and sign out / delete. */
@Composable
fun AccountScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val user by Account.user.collectAsState()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var askSignOut by remember { mutableStateOf(false) }
    var askDelete by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Account") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val u = user
            if (u == null) {
                Surface(shape = RoundedCornerShape(20.dp), color = cs.surfaceContainer) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        AccountAvatar(null, 64.dp)
                        Spacer(Modifier.height(12.dp))
                        Text("You're not signed in", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Sign in with your Google account. You can still use every feature without signing in.",
                            style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(18.dp))
                        if (Account.ready) {
                            GoogleButton("Sign in with Google", busy, Modifier.fillMaxWidth()) {
                                val act = ctx.activity() ?: return@GoogleButton
                                busy = true; msg = null
                                scope.launch {
                                    try { Account.signIn(act) } catch (e: Account.SignInError) { if (!e.cancelled) msg = e.message }
                                    busy = false
                                }
                            }
                        } else {
                            Text(
                                "Google sign-in isn't set up in this version of the app yet.",
                                style = MaterialTheme.typography.bodyMedium, color = cs.error, textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                Surface(shape = RoundedCornerShape(20.dp), color = cs.surfaceContainer) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        AccountAvatar(u, 72.dp)
                        Spacer(Modifier.height(12.dp))
                        if (u.name.isNotBlank()) Text(u.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(u.email, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(8.dp))
                        Surface(shape = RoundedCornerShape(10.dp), color = cs.primaryContainer) {
                            Text("Signed in with Google", color = cs.onPrimaryContainer, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                        }
                    }
                }
                OutlinedButton(onClick = { askSignOut = true }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                    Icon(Icons.AutoMirrored.Outlined.Logout, contentDescription = null)
                    Spacer(Modifier.width(8.dp)); Text("Sign out")
                }
                TextButton(
                    onClick = { askDelete = true }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColors(contentColor = cs.error)
                ) {
                    if (busy) CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                    else Icon(Icons.Outlined.DeleteForever, contentDescription = null)
                    Spacer(Modifier.width(8.dp)); Text("Delete account")
                }
            }
            msg?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodyMedium) }

            Surface(shape = RoundedCornerShape(16.dp), color = cs.surfaceContainer) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Privacy", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
                    Text(
                        "Signing in uses Google (Firebase Authentication) and gives the app your name, email and " +
                            "profile photo. Your PDFs, notes and Gemini key stay on this phone and are not uploaded.",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                    )
                }
            }
        }
    }

    if (askSignOut) AlertDialog(
        onDismissRequest = { askSignOut = false },
        title = { Text("Sign out?") },
        text = { Text("Your files on this phone stay as they are.") },
        confirmButton = { Button(onClick = { askSignOut = false; scope.launch { Account.signOut(ctx) } }) { Text("Sign out") } },
        dismissButton = { TextButton(onClick = { askSignOut = false }) { Text("Cancel") } }
    )
    if (askDelete) AlertDialog(
        onDismissRequest = { askDelete = false },
        title = { Text("Delete account?") },
        text = { Text("This removes your account from AI PDF Studio. Google will ask you to confirm your account first. Your files on this phone are not deleted.") },
        confirmButton = {
            Button(
                onClick = {
                    askDelete = false
                    val act = ctx.activity() ?: return@Button
                    busy = true; msg = null
                    scope.launch {
                        try { Account.deleteAccount(act) } catch (e: Account.SignInError) { if (!e.cancelled) msg = e.message }
                        busy = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = cs.error, contentColor = cs.onError)
            ) { Text("Delete") }
        },
        dismissButton = { TextButton(onClick = { askDelete = false }) { Text("Cancel") } }
    )
}

/** Small account row for the Settings screen. */
@Composable
fun AccountRow(onOpen: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val user by Account.user.collectAsState()
    Surface(onClick = onOpen, shape = RoundedCornerShape(16.dp), color = cs.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            AccountAvatar(user, 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                val u = user
                Text(if (u == null) "Sign in with Google" else u.name.ifBlank { u.email }, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (u == null) "Optional" else u.email, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
