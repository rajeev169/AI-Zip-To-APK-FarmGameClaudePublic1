package com.aipdfstudio.app.data

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.util.Locale

/** One file of a book made from a ZIP or from several files. */
data class BookPart(val name: String, val title: String, val pages: Int, val front: Boolean, val kind: ListenBooks.Kind)

/** "Open as one book": the parts found, before listening starts. */
data class BookPreview(val source: String, val parts: List<BookPart>, val includeFront: Boolean = false, val loading: String? = null) {
    val hasFront get() = parts.any { it.front }
    val chosen get() = parts.filter { includeFront || !it.front }
    val pageTotal get() = chosen.sumOf { it.pages }
    val pdfCount get() = chosen.count { it.kind == ListenBooks.Kind.PDF }
}

/** Which language the voice reads in. Auto picks Hindi or English for each sentence. */
enum class ListenVoice(val label: String) { ENGLISH("English"), HINDI("हिन्दी"), AUTO("Auto") }
enum class SleepMode(val label: String, val minutes: Int) { OFF("Off", 0), M15("15 min", 15), M30("30 min", 30), M60("60 min", 60), CHAPTER("End of chapter", -1) }

/** Everything the Listen screen shows. */
data class ListenState(
    val uri: Uri? = null,
    val name: String = "",
    val layouts: List<LPage> = emptyList(),
    val chapters: List<OutlineEntry> = emptyList(),
    val page: Int = 0,
    val sentence: Int = 0,
    val playing: Boolean = false,
    val loading: String? = null,
    val error: String? = null,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val voice: ListenVoice = ListenVoice.AUTO,
    val sleep: SleepMode = SleepMode.OFF,
    val sleepAt: Long = 0L,
    val fromPage: Int = 0,
    val toPage: Int = Int.MAX_VALUE,
    val missingVoice: String? = null,
    val ready: Boolean = false,
    val read: ListenReadPrefs = ListenReadPrefs(),
    /** What one page is called: "Page" for PDFs, "Part" for e-books, Word and text files. */
    val unit: String = "Page",
    val isPdf: Boolean = true,
    // Voices
    val voices: List<VoiceItem> = emptyList(),
    val voiceEn: String? = null,
    val voiceHi: String? = null,
    val engine: String? = null,          // engine in use (package name)
    val googleInstalled: Boolean = false,
    val phoneEngine: String? = null,     // the phone's default engine
    val phoneEngineLabel: String = "Phone voice",
    val usePhoneEngine: Boolean = false,
    val sampling: String? = null,        // voice name playing a sample
    /** AI teacher sample being fetched or made: "Getting sample…" / "Making sample…" (null = sound is playing or idle). */
    val sampleStage: String? = null,
    /** A message under one AI teacher row, keyed "Fola_hi". */
    val sampleMsg: Map<String, String> = emptyMap(),
    val note: String? = null,
    /** A page being prepared (OCR) before reading can go on. */
    val waitingPage: Int? = null,
    /** "Fola" / "Ludo" when an AI Teacher voice is chosen (null = phone voice). */
    val aiVoice: String? = null,
    /** The AI Teacher voice is being made for the next part. */
    val aiBusy: Boolean = false,
    val hasGeminiKey: Boolean = false,
    /** Female/Male labels are being worked out. */
    val measuring: Boolean = false,
    /** Shown before a ZIP or several files are read as one book. */
    val book: BookPreview? = null
) {
    /** What the voice reads, page by page. */
    val pages: List<List<String>> get() = layouts.map { it.says }
    val pageCount get() = layouts.size
    val lastPage get() = minOf(toPage, pageCount - 1)
    val current: String? get() = layouts.getOrNull(page)?.sentences?.getOrNull(sentence)?.say
    /** Average length of a page, used for pages not prepared yet. */
    private val avgLen: Int get() = layouts.filter { !it.pending && it.sentences.isNotEmpty() }.let { r -> if (r.isEmpty()) 1200 else r.sumOf { p -> p.sentences.sumOf { it.say.length } } / r.size }
    private fun len(p: Int, avg: Int) = if (layouts[p].pending) avg else layouts[p].sentences.sumOf { it.say.length }
    /** 0..1 through the chosen pages (by page, so the bar matches the page numbers). */
    val progress: Float get() {
        if (layouts.isEmpty()) return 0f
        val n = (lastPage - fromPage + 1).coerceAtLeast(1)
        val size = layouts.getOrNull(page)?.sentences?.size ?: 0
        val within = if (size == 0) 0f else sentence.toFloat() / size
        return (((page - fromPage) + within) / n).coerceIn(0f, 1f)
    }
    val charsLeft: Int get() {
        if (layouts.isEmpty()) return 0
        val avg = avgLen
        return (page..lastPage).sumOf { p -> if (p == page && !layouts[p].pending) layouts[p].sentences.drop(sentence).sumOf { it.say.length } else len(p, avg) }
    }
    /** Chapter a page belongs to (for the bubble on the bar and the "Go to page" sheet). */
    fun chapterOf(p: Int): String? = chapters.lastOrNull { it.page in 0..p }?.title
    /** Title of the chapter the current page is in (from the PDF's table of contents). */
    val chapterTitle: String? get() = chapters.lastOrNull { it.page in 0..page }?.title

    /** Language of the sentence being read ("hi" or "en"), for the voice chip. */
    val currentLang: String get() = when (voice) {
        ListenVoice.ENGLISH -> "en"; ListenVoice.HINDI -> "hi"
        ListenVoice.AUTO -> if (ListenText.isHindi(current ?: layouts.getOrNull(page)?.text?.take(400).orEmpty())) "hi" else "en"
    }

    fun chosenVoice(lang: String): VoiceItem? {
        val want = if (lang == "hi") voiceHi else voiceEn
        return voices.firstOrNull { it.name == want && it.lang == lang } ?: ListenVoices.best(voices, lang)
    }
}

/**
 * Reads a PDF aloud with the phone's text-to-speech voice. The next sentences are queued while
 * one is being read, so the voice flows without a stop between sentences.
 * Lives as long as the app; [ListenService] keeps it running with the screen off.
 */
object ListenPlayer {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(ListenState())
    val state: StateFlow<ListenState> = _state

    private var app: Context? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingPlay = false
    private var pendingSample: String? = null
    private var loadJob: Job? = null
    private var focus: AudioFocusRequest? = null

    // Queue: sentences handed to the voice ahead of time. Ids are "gen:page:sentence".
    private var gen = 0
    private var lastQueued: Pair<Int, Int>? = null
    private var pending = 0
    private var chapterStop: Pair<Int, Int>? = null
    /** The speed each queued sentence was handed over with (speed changes apply from the next sentence). */
    private val queuedSpeed = HashMap<String, Float>()
    /** Languages whose online voice failed (no internet): use an offline one until the app restarts. */
    private val offlineOnly = HashSet<String>()

    private fun set(f: (ListenState) -> ListenState) { _state.value = f(_state.value) }

    /** Voice name (or family) → "Female"/"Male", measured once and kept. */
    private val genders = HashMap<String, String>()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("listen", Context.MODE_PRIVATE)

    private fun ensureTts(ctx: Context) {
        if (tts != null) return
        app = ctx.applicationContext
        val p = prefs(ctx)
        set {
            it.copy(
                speed = p.getFloat("speed", 0.75f), pitch = p.getFloat("pitch", 1f),
                voice = ListenVoice.entries.getOrElse(p.getInt("voice", 2)) { ListenVoice.AUTO },
                read = ListenReadPrefs(p.getBoolean("skipNumbers", true), p.getBoolean("skipFigures", true), p.getBoolean("tableRows", true)),
                voiceEn = p.getString("voiceEn", null), voiceHi = p.getString("voiceHi", null),
                usePhoneEngine = p.getBoolean("phoneEngine", false),
                aiVoice = p.getString("aiVoice", null),
                hasGeminiKey = SecureStore(ctx).apiKey.isNotBlank()
            )
        }
        genders.putAll(p.all.filterKeys { it.startsWith("g:") }.mapNotNull { (k, v) -> (v as? String)?.let { k.removePrefix("g:") to it } })
        createTts(ctx.applicationContext)
    }

    private fun createTts(c: Context) {
        val google = ListenVoices.googleInstalled(c)
        val phone = ListenVoices.defaultEngine(c)
        // Google's voices sound the most natural, so they are used even if the phone's default engine is another one.
        val engine = if (google && !_state.value.usePhoneEngine) ListenVoices.GOOGLE else phone
        ttsReady = false
        set { it.copy(googleInstalled = google, phoneEngine = phone, phoneEngineLabel = ListenVoices.engineLabel(c, phone), engine = engine) }
        val init = TextToSpeech.OnInitListener { status ->
            main.post {
                ttsReady = status == TextToSpeech.SUCCESS
                if (!ttsReady) set { it.copy(error = "No text-to-speech voice on this phone. Install \"Speech Services by Google\" from Play Store.", playing = false) }
                else {
                    val t = tts ?: return@post
                    t.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    t.setOnUtteranceProgressListener(listener)
                    val used = try { t.defaultEngine } catch (e: Exception) { null }
                    val eng = engine ?: used ?: ""
                    set { it.copy(voices = ListenVoices.labelled(ListenVoices.list(t, eng), genders), engine = eng) }
                    pendingSample?.let { n -> pendingSample = null; sample(n) }
                    if (pendingPlay) { pendingPlay = false; play() }
                }
            }
        }
        tts = if (engine != null) TextToSpeech(c, init, engine) else TextToSpeech(c, init)
    }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(id: String?) { main.post { started(id) } }
        override fun onDone(id: String?) { main.post { finished(id, 0) } }
        @Deprecated("old API")
        override fun onError(id: String?) { main.post { finished(id, -1) } }
        override fun onError(id: String?, code: Int) { main.post { finished(id, code) } }
    }

    private fun parse(id: String?): Triple<Int, Int, Int>? {
        val p = id?.split(':') ?: return null
        if (p.size != 3) return null
        return Triple(p[0].toIntOrNull() ?: return null, p[1].toIntOrNull() ?: return null, p[2].toIntOrNull() ?: return null)
    }

    private fun started(id: String?) {
        if (id == "sample") return
        val (g, pg, se) = parse(id) ?: return
        if (g != gen || !_state.value.playing) return
        val sp = queuedSpeed.remove(id)
        if (sp != null && sp != _state.value.speed) {
            // Speed changed while this sentence was waiting: hand it over again at the new speed.
            set { it.copy(page = pg, sentence = se) }
            startFrom(pg, se)
            return
        }
        pending = (pending - 1).coerceAtLeast(0)
        if (pg != _state.value.page) offlineOnly.clear()   // try the online voice again on each new page
        set { it.copy(page = pg, sentence = se) }
        savePos()
        ListenService.refresh(app)
        fill()
        // Get the next pages ready while this one is read.
        request(pg + 1, pg + 2, pg + 3)
    }

    private fun finished(id: String?, code: Int) {
        if (id == "sample") { set { it.copy(sampling = null) }; return }
        val (g, pg, se) = parse(id) ?: return
        if (g != gen || !_state.value.playing) return
        // An online voice without internet: switch to an offline voice and carry on from here.
        if (code == TextToSpeech.ERROR_NETWORK || code == TextToSpeech.ERROR_NETWORK_TIMEOUT || code == TextToSpeech.ERROR_NOT_INSTALLED_YET) {
            val text = _state.value.layouts.getOrNull(pg)?.sentences?.getOrNull(se)?.say.orEmpty()
            val lang = langOf(text)
            if (lang !in offlineOnly) {
                offlineOnly.add(lang)
                set { it.copy(note = "The online voice needs internet. Reading with an offline voice for now.") }
                startFrom(pg, se)
                return
            }
        }
        if (Pair(pg, se) == lastQueued && pending == 0) {
            // Nothing more was queued: a page still being prepared, the end of the chapter, or the end.
            val stop = chapterStop
            val blocked = blockedAt
            if (blocked != null) waitFor(blocked)
            else if (stop != null) {
                set { it.copy(page = stop.first, sentence = stop.second) }
                pause(); set { it.copy(sleep = SleepMode.OFF) }
            } else {
                val s = _state.value
                set { it.copy(playing = false, page = s.fromPage, sentence = 0) }
                savePos(); abandonFocus(); ListenService.refresh(app)
            }
        }
    }

    /** Loads [uri] (skipped if it's already loaded) and goes to where the user stopped last time. */
    fun open(ctx: Context, uri: Uri, name: String) {
        ensureTts(ctx)
        if (_state.value.uri == uri && (_state.value.ready || _state.value.loading != null || _state.value.book != null)) return
        stop()
        lastBook = null; bookFiles = emptyList()
        set { it.copy(uri = uri, name = name, layouts = emptyList(), chapters = emptyList(), page = 0, sentence = 0, loading = "Getting your notes ready…", error = null, ready = false, fromPage = 0, toPage = Int.MAX_VALUE, book = null, waitingPage = null) }
        load(ctx, uri, keepPage = null)
    }

    /** Several files picked by hand, read as one book (in the order picked). */
    fun openMany(ctx: Context, uris: List<Uri>) {
        ensureTts(ctx)
        val key = ListenCache.key(*uris.map { it.toString() }.toTypedArray())
        val uri = Uri.parse("listen-book:$key")
        if (_state.value.uri == uri && (_state.value.ready || _state.value.book != null)) return
        stop()
        val files = uris.map { u -> u to (try { queryName(ctx, u) } catch (e: Exception) { u.lastPathSegment ?: "file" }) }
        bookFiles = files
        lastBook = null
        set { it.copy(uri = uri, name = "${files.size} files", layouts = emptyList(), chapters = emptyList(), page = 0, sentence = 0, loading = null, error = null, ready = false, fromPage = 0, toPage = Int.MAX_VALUE, waitingPage = null,
            book = BookPreview("${files.size} files you picked", emptyList(), loading = "Looking at the files…")) }
        previewBook(ctx)
    }

    // ------------------------------------------------------------------ pages prepared as you go

    /** Where a page comes from, when it still has to be read (PDF page or photo). */
    private class PageRef(val uri: Uri, val kind: ListenBooks.Kind, val index: Int)
    private var refs: List<PageRef?> = emptyList()
    private val docs = HashMap<Uri, PDDocument>()
    private val wanted = LinkedHashSet<Int>()
    private var workJob: Job? = null
    private val prepLock = Mutex()
    private val PENDING = LPage(emptyList(), emptyList(), pending = true)
    private var bookFiles: List<Pair<Uri, String>> = emptyList()
    private var readyParts = HashMap<Uri, ListenBook>()
    private var blockedAt: Int? = null
    private var lastBook: BookPreview? = null

    private fun prefsBits(p: ListenReadPrefs) = "${if (p.skipNumbers) 1 else 0}${if (p.skipFigures) 1 else 0}${if (p.tableRows) 1 else 0}"

    private fun cacheFile(c: Context, ref: PageRef, p: ListenReadPrefs): File =
        File(c.cacheDir, "listen/" + ListenCache.key(ref.uri.toString()) + "/" + ref.index + "_v2" + prefsBits(p) + ".lp")

    private fun closeDocs() {
        val all = docs.values.toList()
        docs.clear()
        scope.launch(Dispatchers.IO) { all.forEach { try { it.close() } catch (ignored: Exception) {} } }
    }

    /** Reads one page: the PDF's own text first, OCR when the page is scanned or its Hindi text is damaged. */
    private suspend fun process(c: Context, ref: PageRef, prefs: ListenReadPrefs): LPage = withContext(Dispatchers.IO) {
        val cf = cacheFile(c, ref, prefs)
        ListenCache.read(cf)?.let { return@withContext it }
        var lp: LPage
        if (ref.kind == ListenBooks.Kind.IMAGE) {
            lp = try { OcrOps.listenOcrImage(c, ref.uri, prefs) } catch (e: UserError) { main.post { set { it.copy(note = e.message) } }; return@withContext LPage(emptyList(), emptyList()) }
        } else {
            val doc = docs.getOrPut(ref.uri) { PdfOps.load(c, ref.uri) }
            lp = try { ListenLayout.read(doc, ref.index, prefs) } catch (e: Throwable) { LPage(emptyList(), emptyList(), needsOcr = true) }
            if (lp.needsOcr || lp.text.trim().length < 40) {
                val o = try { OcrOps.listenOcrPage(c, ref.uri, ref.index, prefs) } catch (e: UserError) {
                    main.post { set { it.copy(note = e.message) } }; null
                } catch (e: Throwable) { null }
                if (o != null && (o.text.trim().length >= maxOf(10, lp.text.trim().length / 2) || lp.needsOcr)) lp = o
            }
        }
        lp = lp.copy(needsOcr = false, pending = false)
        ListenCache.write(cf, lp)
        lp
    }

    /** Asks for pages to be prepared (the page being read or jumped to goes first). */
    private fun request(vararg pages: Int) {
        val s = _state.value
        for (p in pages) if (p in s.layouts.indices && s.layouts[p].pending) wanted.add(p)
        pump()
    }

    private fun pump() {
        if (workJob?.isActive == true) return
        val c = app ?: return
        workJob = scope.launch {
            while (true) {
                val s = _state.value
                wanted.removeAll { it !in s.layouts.indices || !s.layouts[it].pending }
                val next = (s.waitingPage?.takeIf { it in wanted }) ?: (s.page.takeIf { it in wanted }) ?: wanted.firstOrNull() ?: break
                wanted.remove(next)
                prepare(c, next)
            }
        }
    }

    private suspend fun prepare(c: Context, i: Int) {
        prepLock.withLock {
            val ref = refs.getOrNull(i) ?: return
            if (_state.value.layouts.getOrNull(i)?.pending != true) return
            val prefs = _state.value.read
            val lp = try { process(c, ref, prefs) } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                LPage(emptyList(), emptyList())
            }
            val s = _state.value
            if (i !in s.layouts.indices || refs.getOrNull(i) !== ref) return
            set { st -> st.copy(layouts = st.layouts.toMutableList().also { it[i] = lp }) }
            pageReady(i)
        }
    }

    private fun pageReady(i: Int) {
        val s = _state.value
        if (s.waitingPage != i) return
        set { it.copy(waitingPage = null) }
        if (s.playing) {
            val se = if (s.page == i) s.sentence else 0
            resumeAt(i, se)
        }
    }

    /** Gets every page in [from]..[to] ready (before "Save as audio"). */
    suspend fun prepareRange(from: Int, to: Int, progress: (String) -> Unit) {
        val c = app ?: return
        for (i in from..to) {
            if (_state.value.layouts.getOrNull(i)?.pending == true) {
                progress("Getting page ${i + 1} of ${to + 1} ready…")
                prepare(c, i)
            }
        }
    }

    private fun load(ctx: Context, uri: Uri, keepPage: Int?) {
        loadJob?.cancel()
        workJob?.cancel(); wanted.clear()
        closeDocs()
        val readPrefs = _state.value.read
        loadJob = scope.launch {
            try {
                val kind = ListenBooks.kindOf(_state.value.name, try { ctx.contentResolver.getType(uri) } catch (e: Exception) { null })
                if (kind == ListenBooks.Kind.ZIP) {
                    set { it.copy(loading = null, book = BookPreview(_state.value.name, emptyList(), loading = "Opening the ZIP…")) }
                    val files = withContext(Dispatchers.IO) {
                        val dir = File(ctx.filesDir, "books/" + ListenCache.key(uri.toString(), _state.value.name))
                        val done = File(dir, ".done")
                        val list = if (done.isFile) (dir.listFiles() ?: emptyArray()).filter { it.isFile && !it.name.startsWith(".") }.sortedWith(compareBy(ListenBooks.naturalOrder) { it.name })
                        else {
                            dir.deleteRecursively()
                            val l = (ctx.contentResolver.openInputStream(uri) ?: throw UserError("Can't open this file")).use { ListenBooks.unzipBook(it, dir) }
                            done.writeText("ok"); l
                        }
                        list.map { Uri.fromFile(it) to it.name.substringAfterLast("__") }
                    }
                    bookFiles = files
                    previewBook(ctx)
                    return@launch
                }
                val (pages, chapters, unit) = withContext(Dispatchers.IO) {
                    when (kind) {
                        ListenBooks.Kind.PDF -> {
                            val n = OcrOps.pageCount(ctx, uri)
                            refs = (0 until n).map { PageRef(uri, ListenBooks.Kind.PDF, it) }
                            Triple(List(n) { PENDING }, Outline.read(ctx, uri), "Page")
                        }
                        ListenBooks.Kind.IMAGE -> {
                            refs = listOf(PageRef(uri, ListenBooks.Kind.IMAGE, 0))
                            Triple(listOf(PENDING), emptyList(), "Page")
                        }
                        else -> {
                            val book = readText(ctx, uri, kind, readPrefs)
                            refs = book.pages.map { null }
                            Triple(book.pages, book.chapters, book.unit)
                        }
                    }
                }
                set { it.copy(unit = unit, isPdf = kind == ListenBooks.Kind.PDF) }
                start(ctx, uri, pages, chapters, keepPage)
            } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                set { it.copy(loading = null, book = null, error = PdfOps.friendly(e)) }
            }
        }
    }

    private fun readText(ctx: Context, uri: Uri, kind: ListenBooks.Kind, prefs: ListenReadPrefs): ListenBook =
        (ctx.contentResolver.openInputStream(uri) ?: throw UserError("Can't open this file")).use { input ->
            when (kind) {
                ListenBooks.Kind.EPUB -> ListenBooks.epub(input, prefs)
                ListenBooks.Kind.DOCX -> ListenBooks.docx(input, prefs)
                else -> ListenBooks.txt(ListenBooks.txtDecode(input.readBytes()), prefs)
            }
        }

    /** Pages are known: go to the saved place and get the first pages ready. */
    private fun start(ctx: Context, uri: Uri, pages: List<LPage>, chapters: List<OutlineEntry>, keepPage: Int?) {
        if (pages.isEmpty()) throw UserError("No text found to read aloud.")
        var pg: Int
        var se: Int
        if (keepPage != null) { pg = keepPage.coerceIn(0, pages.size - 1); se = 0 }
        else {
            val saved = prefs(ctx).getString("pos:$uri", null)?.split(':')
            pg = saved?.getOrNull(0)?.toIntOrNull()?.coerceIn(0, pages.size - 1) ?: 0
            se = saved?.getOrNull(1)?.toIntOrNull() ?: 0
        }
        if (!pages[pg].pending && se >= pages[pg].sentences.size) se = 0
        set { it.copy(layouts = pages, chapters = chapters.filter { c -> c.page >= 0 }, page = pg, sentence = se, loading = null, ready = true, book = null) }
        request(pg, pg + 1, pg + 2)
    }

    // ------------------------------------------------------------------ books (ZIP or several files)

    private fun previewBook(ctx: Context) {
        loadJob = scope.launch {
            try {
                val files = bookFiles
                val parts = ArrayList<BookPart>()
                readyParts = HashMap()
                val prefs = _state.value.read
                var i = 0
                while (i < files.size) {
                    val (u, name) = files[i]
                    val kind = ListenBooks.kindOf(name, null)
                    set { it.copy(book = it.book?.copy(loading = "Reading chapter names… ${i + 1} of ${files.size}")) }
                    if (kind == ListenBooks.Kind.IMAGE) {
                        // Photos in a row become one part.
                        var j = i
                        while (j < files.size && ListenBooks.kindOf(files[j].second, null) == ListenBooks.Kind.IMAGE) j++
                        parts.add(BookPart(name, if (j - i == 1) "Photo" else "Photos (${j - i})", j - i, false, kind))
                        i = j; continue
                    }
                    val part = withContext(Dispatchers.IO) {
                        when (kind) {
                            ListenBooks.Kind.PDF -> {
                                val n = OcrOps.pageCount(ctx, u)
                                val first = if (n > 0) try { process(ctx, PageRef(u, kind, 0), prefs) } catch (e: Throwable) { null } else null
                                // A first page with very little text (a cover) : try the next page for the name.
                                val title = first?.let { ListenLayout.titleOf(it) }
                                val front = ListenBooks.isFront(name)
                                BookPart(name, if (front) "Front pages" else title ?: name.substringBeforeLast('.'), n, front, kind)
                            }
                            ListenBooks.Kind.EPUB, ListenBooks.Kind.DOCX, ListenBooks.Kind.TXT -> {
                                val b = try { readText(ctx, u, kind, prefs) } catch (e: UserError) { null }
                                if (b == null) null else {
                                    readyParts[u] = b
                                    BookPart(name, b.chapters.firstOrNull()?.title ?: name.substringBeforeLast('.'), b.pages.size, ListenBooks.isFront(name), kind)
                                }
                            }
                            else -> null
                        }
                    }
                    if (part != null) parts.add(part)
                    i++
                }
                if (parts.isEmpty()) throw UserError("No PDFs or books found here.")
                set { it.copy(book = it.book?.copy(parts = parts, loading = null)) }
            } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                set { it.copy(book = null, error = PdfOps.friendly(e)) }
            }
        }
        closeDocs()
    }

    fun setIncludeFront(on: Boolean) = set { it.copy(book = it.book?.copy(includeFront = on)) }

    /** "Listen to book": joins the chosen parts into one long book. */
    fun startBook(ctx: Context, keepPage: Int? = null) {
        val b = _state.value.book ?: return
        val uri = _state.value.uri ?: return
        val prefs = _state.value.read
        lastBook = b
        loadJob?.cancel(); workJob?.cancel(); wanted.clear()
        set { it.copy(loading = "Getting your book ready…") }
        loadJob = scope.launch {
            try {
                val pages = ArrayList<LPage>()
                val rs = ArrayList<PageRef?>()
                val chapters = ArrayList<OutlineEntry>()
                for (part in b.parts) {
                    val chosen = b.includeFront || !part.front
                    val at = bookFiles.indexOfFirst { it.second == part.name }
                    if (at < 0 || !chosen) continue
                    if (part.kind == ListenBooks.Kind.IMAGE) {
                        chapters.add(OutlineEntry(part.title, pages.size, 0))
                        for (k in 0 until part.pages) { pages.add(PENDING); rs.add(PageRef(bookFiles[at + k].first, ListenBooks.Kind.IMAGE, 0)) }
                        continue
                    }
                    val u = bookFiles[at].first
                    chapters.add(OutlineEntry(part.title, pages.size, 0))
                    when (part.kind) {
                        ListenBooks.Kind.PDF -> for (k in 0 until part.pages) { pages.add(PENDING); rs.add(PageRef(u, ListenBooks.Kind.PDF, k)) }
                        else -> {
                            val book = readyParts[u] ?: withContext(Dispatchers.IO) { readText(ctx, u, part.kind, prefs) }
                            book.pages.forEach { pages.add(it); rs.add(null) }
                            book.chapters.drop(1).forEach { c -> chapters.add(OutlineEntry(c.title, pages.size - book.pages.size + c.page, 1)) }
                        }
                    }
                }
                refs = rs
                // Pages read before (chapter names) are already on the phone: use them straight away.
                val ready = withContext(Dispatchers.IO) { pages.indices.map { i -> rs[i]?.let { r -> ListenCache.read(cacheFile(ctx, r, prefs)) } ?: pages[i] } }
                set { it.copy(unit = "Page", isPdf = b.parts.any { p -> p.kind == ListenBooks.Kind.PDF }) }
                start(ctx, uri, ready, chapters, keepPage)
            } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                set { it.copy(loading = null, error = PdfOps.friendly(e)) }
            }
        }
    }

    /** Joins the book's PDFs into one PDF file ("Save as one PDF"). */
    suspend fun saveBookPdf(ctx: Context): File {
        val b = _state.value.book ?: throw UserError("Nothing to save")
        val pdfs = b.chosen.filter { it.kind == ListenBooks.Kind.PDF }.mapNotNull { p -> bookFiles.firstOrNull { it.second == p.name }?.first }
        if (pdfs.isEmpty()) throw UserError("There are no PDFs in this book to join.")
        val base = _state.value.name.substringBeforeLast('.').ifBlank { "Book" }
        return withContext(Dispatchers.IO) {
            val out = Outputs.newFile(ctx, base, "book", "pdf")
            if (pdfs.size == 1) ctx.contentResolver.openInputStream(pdfs[0])?.use { i -> out.outputStream().use { i.copyTo(it) } }
            else PdfOps.merge(ctx, pdfs, out)
            out
        }
    }

    fun closeBook() { stop(); set { it.copy(book = null, uri = null, ready = false, layouts = emptyList()) } }

    private fun savePos() {
        val s = _state.value
        val c = app ?: return
        if (s.uri != null) prefs(c).edit().putString("pos:${s.uri}", "${s.page}:${s.sentence}").apply()
    }

    private fun langOf(text: String): String = when (_state.value.voice) {
        ListenVoice.ENGLISH -> "en"
        ListenVoice.HINDI -> "hi"
        ListenVoice.AUTO -> if (ListenText.isHindi(text)) "hi" else "en"
    }

    /** Sets the voice for a sentence in [lang]; falls back to the language if no voice is available. */
    private fun applyVoice(t: TextToSpeech, lang: String) {
        val s = _state.value
        var v = s.chosenVoice(lang)
        if (v != null && v.online && lang in offlineOnly) v = s.voices.firstOrNull { it.lang == lang && !it.online }
        val voice = ListenVoices.find(t, v?.name)
        if (voice != null && t.setVoice(voice) == TextToSpeech.SUCCESS) return
        val loc = if (lang == "hi") Locale("hi", "IN") else Locale("en", "IN")
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            val fallback = if (lang == "hi") Locale("en", "IN") else Locale.US
            if (t.setLanguage(fallback) < 0) t.setLanguage(Locale.US)
            if (s.missingVoice == null) set { it.copy(missingVoice = if (lang == "hi") "Hindi" else "English (India)") }
        }
    }

    /**
     * Next sentence after (p, s) within the chosen pages, or null at the end, at a chapter stop,
     * or at a page that is still being prepared ([blockedAt]).
     */
    private fun nextPos(p: Int, s: Int): Pair<Int, Int>? {
        val st = _state.value
        var pg = p
        var se = s + 1
        while (true) {
            if (pg > st.lastPage) return null
            val lp = st.layouts.getOrNull(pg) ?: return null
            if (lp.pending) { blockedAt = pg; request(pg, pg + 1, pg + 2); return null }
            if (se < lp.sentences.size) return pg to se
            pg++; se = 0
            // "End of chapter": stop where the next chapter (or, without contents, the next page) starts.
            if (st.sleep == SleepMode.CHAPTER && pg <= st.lastPage && (st.chapters.isEmpty() || st.chapters.any { it.page == pg })) {
                chapterStop = pg to 0
                return null
            }
        }
    }

    /** Reading reached a page that isn't ready: wait for it (the screen shows "Reading page N…"). */
    private fun waitFor(pg: Int) {
        gen++
        tts?.stop()
        pending = 0
        lastQueued = null
        set { it.copy(page = pg, sentence = 0, waitingPage = pg) }
        request(pg, pg + 1, pg + 2)
        if (_state.value.layouts.getOrNull(pg)?.pending == false) pageReady(pg)
    }

    /** Extra silence after sentence [s] of page [p], in ms (measured from a real class: 0.4–0.7 s between sentences). */
    private fun pauseAfter(p: Int, s: Int): Int {
        val lp = _state.value.layouts.getOrNull(p) ?: return 0
        val text = lp.sentences.getOrNull(s)?.say?.trimEnd() ?: return 0
        val ended = text.lastOrNull()?.let { it in ".!?।॥:\"”" } == true
        val block = lp.blocks.firstOrNull { s >= it.first && s < it.first + it.count }
        val lastInBlock = block != null && s == block.first + block.count - 1
        if (!lastInBlock) return if (ended) 280 else 120
        // A sentence that runs on to the next page: no stop.
        if (s == lp.sentences.size - 1 && !ended) return 0
        val next = lp.blocks.firstOrNull { it.first > s && it.count > 0 }
        return when {
            block?.kind == LKind.HEADING -> 600
            next?.kind == LKind.HEADING || next?.kind == LKind.FIGURE -> 900
            next?.kind == LKind.POINT && block?.kind != LKind.POINT -> 700
            block?.kind == LKind.POINT || block?.kind == LKind.ROW -> 450
            else -> 650
        }
    }

    private fun blockEnds(p: Int, s: Int): Boolean {
        val lp = _state.value.layouts.getOrNull(p) ?: return false
        return lp.blocks.any { it.count > 0 && it.first + it.count - 1 == s }
    }

    private fun enqueue(p: Int, s: Int, flush: Boolean) {
        val t = tts ?: return
        val st = _state.value
        val text = st.layouts.getOrNull(p)?.sentences?.getOrNull(s)?.say ?: return
        applyVoice(t, langOf(text))
        t.setSpeechRate(st.speed)
        t.setPitch(st.pitch)
        t.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, Bundle(), "$gen:$p:$s")
        queuedSpeed["$gen:$p:$s"] = st.speed
        // Pauses like a teacher in class: ~half a second after a sentence, longer after a
        // paragraph and before a new heading or question (the voice adds a little itself).
        val ms = pauseAfter(p, s)
        if (ms > 0) t.playSilentUtterance((ms / st.speed.coerceAtLeast(0.5f)).toLong(), TextToSpeech.QUEUE_ADD, "$gen:pause")
        lastQueued = p to s
        pending++
    }

    /** Keeps two sentences waiting after the one being read. */
    private fun fill() {
        while (pending < 2) {
            val last = lastQueued ?: return
            val n = nextPos(last.first, last.second) ?: return
            enqueue(n.first, n.second, flush = false)
        }
    }

    private fun startFrom(p: Int, s: Int) {
        gen++
        queuedSpeed.clear()
        pending = 0
        chapterStop = null
        blockedAt = null
        lastQueued = null
        if (_state.value.layouts.getOrNull(p)?.pending == true) { waitFor(p); return }
        set { it.copy(waitingPage = null) }
        if (_state.value.layouts.getOrNull(p)?.sentences?.getOrNull(s) == null) {
            val n = nextPos(p, s - 1)
            if (n == null) {
                val b = blockedAt
                if (b != null) waitFor(b) else pause()
                return
            }
            enqueue(n.first, n.second, flush = true)
        } else enqueue(p, s, flush = true)
        fill()
    }

    fun play() {
        val c = app ?: return
        val s = _state.value
        if (!s.ready) return
        if (!ttsReady) { pendingPlay = true; return }
        if (!requestFocus(c)) return
        var pg = s.page.coerceIn(s.fromPage, s.lastPage)
        var se = if (pg != s.page) 0 else s.sentence
        while (pg < s.lastPage && !s.layouts[pg].pending && s.layouts[pg].sentences.isEmpty()) { pg++; se = 0 }
        set { it.copy(playing = true, page = pg, sentence = se, error = null, sampling = null) }
        ListenService.start(c)
        val m = mp
        if (aiActive() && m != null && aiPaused && aiAt == (pg to se)) {
            aiPaused = false
            try { m.start(); startTick() } catch (e: Exception) { resumeAt(pg, se) }
        } else resumeAt(pg, se)
    }

    // ------------------------------------------------------------------ AI Teacher voice

    private var mp: android.media.MediaPlayer? = null
    private var aiPaused = false
    private var aiAt: Pair<Int, Int>? = null
    private var aiPiece: Triple<Int, Int, Int>? = null      // page, first sentence, last sentence
    private var aiJob: Job? = null
    /** After a failure the phone voice takes over until the user picks the AI voice again. */
    private var aiFailed = false

    private fun aiActive(): Boolean {
        val s = _state.value
        return s.aiVoice != null && !aiFailed
    }

    /** Starts reading at (p, s) with the voice in use. */
    private fun resumeAt(p: Int, s: Int) { if (aiActive()) aiStart(p, s) else startFrom(p, s) }

    private fun releaseMp() {
        main.removeCallbacks(tick)
        aiPaused = false
        try { mp?.release() } catch (ignored: Exception) {}
        mp = null
    }

    private fun aiStart(p: Int, s: Int) {
        gen++
        val g = gen
        chapterStop = null
        blockedAt = null
        tts?.stop()
        releaseMp()
        aiJob?.cancel()
        val st = _state.value
        val lp = st.layouts.getOrNull(p) ?: return
        if (lp.pending) { set { it.copy(page = p, sentence = 0, waitingPage = p) }; request(p, p + 1, p + 2); return }
        // Find the piece (a paragraph or two) that holds sentence s; read from s to its end.
        val piece = AiTeacher.pieces(lp).firstOrNull { s in it }
        if (piece == null) {
            val n = nextPos(p, (lp.sentences.size - 1).coerceAtLeast(s))
            if (n != null) aiStart(n.first, n.second)
            else aiEnd()
            return
        }
        val from = maxOf(s, piece.first)
        set { it.copy(page = p, sentence = from, waitingPage = null, aiBusy = true) }
        savePos(); ListenService.refresh(app)
        aiPiece = Triple(p, from, piece.last)
        val c = app ?: return
        val voice = st.aiVoice ?: return
        val key = SecureStore(c).apiKey
        val text = AiTeacher.textOf(lp, from, piece.last)
        aiJob = scope.launch {
            try {
                val f = AiTeacher.audio(c.cacheDir, key, voice, text)
                if (g != gen || !_state.value.playing) return@launch
                set { it.copy(aiBusy = false) }
                val m = android.media.MediaPlayer()
                m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                m.setDataSource(f.path)
                m.prepare()
                try { m.playbackParams = m.playbackParams.setSpeed(aiSpeed()) } catch (ignored: Exception) {}
                m.setOnCompletionListener { done -> main.post { if (mp === done && _state.value.playing) aiNext() } }
                mp = m
                aiAt = p to from
                m.start()
                startTick()
                prefetchAi(p, piece.last, voice, key)
            } catch (e: AiTeacher.Failure) {
                if (g != gen) return@launch
                aiFallback(e.message ?: "The AI teacher voice isn't available.", p, from)
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                if (g != gen) return@launch
                aiFallback("The AI teacher voice couldn't play.", p, from)
            }
        }
    }

    /** The AI voice speaks at normal speed at 1×; the speed chip still works. */
    private fun aiSpeed() = _state.value.speed.coerceIn(0.5f, 2f)

    private fun aiFallback(msg: String, p: Int, s: Int) {
        aiFailed = true
        set { it.copy(aiBusy = false, note = "$msg Reading with the phone voice for now.") }
        startFrom(p, s)
    }

    /** Moves the highlight through the piece as the audio plays (by length of each sentence). */
    private val tick: Runnable = object : Runnable {
        override fun run() {
            val m = mp ?: return
            val piece = aiPiece ?: return
            try {
                if (!m.isPlaying) return
                val lp = _state.value.layouts.getOrNull(piece.first) ?: return
                val lens = (piece.second..piece.third).map { lp.sentences[it].say.length + 12 }
                val total = lens.sum().coerceAtLeast(1)
                val pos = m.currentPosition.toFloat() / m.duration.coerceAtLeast(1)
                var acc = 0f; var idx = piece.second
                for ((k, l) in lens.withIndex()) { acc += l.toFloat() / total; if (pos <= acc) { idx = piece.second + k; break }; idx = piece.third }
                if (idx != _state.value.sentence) { set { it.copy(sentence = idx) }; aiAt = piece.first to idx; savePos() }
            } catch (ignored: Exception) {}
            main.postDelayed(this, 200)
        }
    }

    private fun startTick() { main.removeCallbacks(tick); main.post(tick) }

    private fun aiNext() {
        val piece = aiPiece ?: return
        val n = nextPos(piece.first, piece.third)
        if (n != null) { aiStart(n.first, n.second); return }
        val b = blockedAt
        val stop = chapterStop
        when {
            b != null -> { blockedAt = null; aiStart(b, 0) }
            stop != null -> { chapterStop = null; releaseMp(); set { it.copy(page = stop.first, sentence = stop.second) }; pause(); set { it.copy(sleep = SleepMode.OFF) } }
            else -> aiEnd()
        }
    }

    private fun aiEnd() {
        releaseMp()
        val s = _state.value
        set { it.copy(playing = false, page = s.fromPage, sentence = 0, aiBusy = false) }
        savePos(); abandonFocus(); ListenService.refresh(app)
    }

    /** Makes the next two pieces while this one plays, so there is no wait between them. */
    private fun prefetchAi(p: Int, last: Int, voice: String, key: String) {
        val c = app ?: return
        scope.launch {
            var page = p; var sent = last
            repeat(2) {
                val st = _state.value
                var pg = page; var se = sent + 1
                while (pg <= st.lastPage && (st.layouts.getOrNull(pg)?.let { !it.pending && se >= it.sentences.size } == true)) { pg++; se = 0 }
                val lp = st.layouts.getOrNull(pg) ?: return@launch
                if (pg > st.lastPage || lp.pending) { request(pg, pg + 1); return@launch }
                val piece = AiTeacher.pieces(lp).firstOrNull { se in it } ?: return@launch
                try { AiTeacher.audio(c.cacheDir, key, voice, AiTeacher.textOf(lp, maxOf(se, piece.first), piece.last)) } catch (e: Exception) { return@launch }
                page = pg; sent = piece.last
            }
        }
    }

    /** Chooses an AI Teacher voice (null = back to the phone voice). */
    fun chooseAi(id: String?) {
        val c = app ?: return
        prefs(c).edit().putString("aiVoice", id).apply()
        aiFailed = false
        set { it.copy(aiVoice = id, note = null, hasGeminiKey = SecureStore(c).apiKey.isNotBlank()) }
        // The AI teacher already speaks at a teacher's pace: slowing it down sounds dragged.
        if (id != null && _state.value.speed < 1f) {
            setSpeed(1f)
            set { it.copy(note = "Speed set to 1× — the AI teacher already reads at a classroom pace.") }
        }
        restartIfPlaying()
    }

    /** Tapped an AI teacher (to read with it) without a key: say what's needed under that row. */
    fun aiNeedsKey(id: String, lang: String) {
        set { it.copy(sampleMsg = it.sampleMsg + ((id + "_" + lang) to "To read books in this voice, add your free Gemini key above.")) }
    }

    fun saveGeminiKey(ctx: Context, key: String) {
        SecureStore(ctx).apiKey = key
        aiFailed = false
        set { it.copy(hasGeminiKey = key.isNotBlank(), note = null, sampleMsg = emptyMap()) }
    }

    /**
     * Plays a short sample of an AI Teacher voice in [lang]. The sample comes from the phone, else
     * from the shared copy in Firestore, else it is made with the user's key and saved in both.
     */
    fun sampleAi(id: String, lang: String) {
        val c = app ?: return
        if (_state.value.playing) pause()
        if (_state.value.sampling == id) { releaseMp(); set { it.copy(sampling = null, sampleStage = null) }; return }
        releaseMp(); tts?.stop()
        val k = id + "_" + lang
        set { it.copy(sampling = id, sampleStage = null, sampleMsg = it.sampleMsg - k) }
        val g = ++gen
        scope.launch {
            try {
                val f = AiSamples.get(c, id, lang, SecureStore(c).apiKey) { stage ->
                    main.post {
                        if (g == gen) set { it.copy(sampleStage = if (stage == AiSamples.Stage.MAKING) "Making sample…" else "Getting sample…") }
                    }
                }
                if (g != gen) return@launch
                val m = android.media.MediaPlayer()
                m.setDataSource(f.path); m.prepare()
                m.setOnCompletionListener { main.post { if (_state.value.sampling == id) set { s -> s.copy(sampling = null, sampleStage = null) }; releaseMp() } }
                mp = m; m.start()
                set { it.copy(sampleStage = null) }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                if (g != gen) return@launch
                val msg = (e as? AiSamples.Problem)?.message ?: "Couldn't play the sample — tap ▶ to try again."
                set { it.copy(sampling = null, sampleStage = null, sampleMsg = it.sampleMsg + (k to msg)) }
            }
        }
    }

    /**
     * Works out which phone voices are female or male by measuring their pitch once (Android
     * doesn't say). Runs in the background while "Choose a voice" is open.
     */
    fun measureVoices() {
        val c = app ?: return
        val s = _state.value
        if (s.measuring) return
        val todo = s.voices.filter { !it.online && genders[it.name] == null && genders[ListenVoices.family(it.name)] == null }.take(24)
        if (todo.isEmpty()) return
        set { it.copy(measuring = true) }
        val engine = s.engine?.takeIf { it.isNotEmpty() }
        var probe: TextToSpeech? = null
        val onInit = TextToSpeech.OnInitListener { st ->
            if (st != TextToSpeech.SUCCESS) { main.post { set { it.copy(measuring = false) } }; return@OnInitListener }
            scope.launch(Dispatchers.IO) {
                val t = probe ?: return@launch
                val dir = File(c.cacheDir, "voice_probe").apply { mkdirs() }
                for (v in todo) {
                    val voice = ListenVoices.find(t, v.name) ?: continue
                    t.setVoice(voice)
                    val f = File(dir, "p.wav"); f.delete()
                    val done = java.util.concurrent.CountDownLatch(1)
                    t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { done.countDown() }
                        @Deprecated("old API") override fun onError(id: String?) { done.countDown() }
                    })
                    t.synthesizeToFile(if (v.lang == "hi") ListenVoices.SAMPLE_HI else ListenVoices.SAMPLE_EN, Bundle(), f, "probe")
                    done.await(8, java.util.concurrent.TimeUnit.SECONDS)
                    val g = try { readPcm(f)?.let { (pcm, rate) -> ListenVoices.genderOf(ListenVoices.pitchHz(pcm, rate)) } } catch (e: Exception) { null } ?: continue
                    genders[v.name] = g
                    genders[ListenVoices.family(v.name)] = g
                    prefs(c).edit().putString("g:" + v.name, g).putString("g:" + ListenVoices.family(v.name), g).apply()
                    main.post { set { st2 -> st2.copy(voices = ListenVoices.labelled(st2.voices, genders)) } }
                }
                try { t.shutdown() } catch (ignored: Exception) {}
                main.post { set { it.copy(measuring = false) } }
            }
        }
        probe = if (engine != null) TextToSpeech(c, onInit, engine) else TextToSpeech(c, onInit)
    }

    /** 16-bit PCM of a WAV file (enough of it to measure pitch). */
    private fun readPcm(f: File): Pair<ShortArray, Int>? {
        if (!f.isFile || f.length() < 1000) return null
        val b = f.readBytes()
        val rate = (b[24].toInt() and 0xFF) or ((b[25].toInt() and 0xFF) shl 8) or ((b[26].toInt() and 0xFF) shl 16)
        var i = 12
        while (i + 8 < b.size) {
            val id = String(b, i, 4, Charsets.US_ASCII)
            val len = (b[i + 4].toInt() and 0xFF) or ((b[i + 5].toInt() and 0xFF) shl 8) or ((b[i + 6].toInt() and 0xFF) shl 16) or ((b[i + 7].toInt() and 0xFF) shl 24)
            if (id == "data") {
                val start = i + 8
                val n = minOf(len, b.size - start, rate * 2 * 4) / 2
                return ShortArray(n) { k -> ((b[start + 2 * k].toInt() and 0xFF) or (b[start + 2 * k + 1].toInt() shl 8)).toShort() } to rate
            }
            i += 8 + len
        }
        return null
    }

    fun pause() {
        gen++
        tts?.stop()
        aiJob?.cancel()
        main.removeCallbacks(tick)
        val m = mp
        if (m != null) { try { if (m.isPlaying) { m.pause(); aiPaused = true } else releaseMp() } catch (e: Exception) { releaseMp() } }
        set { it.copy(aiBusy = false) }
        set { it.copy(playing = false, waitingPage = null) }
        savePos()
        abandonFocus()
        ListenService.refresh(app)
    }

    fun toggle() = if (_state.value.playing) pause() else play()

    /** Jump to a sentence (and keep playing if it was). */
    fun seek(page: Int, sentence: Int) {
        val s = _state.value
        if (s.layouts.isEmpty()) return
        val pg = page.coerceIn(0, s.layouts.size - 1)
        val se = if (s.layouts[pg].pending) 0 else sentence.coerceIn(0, maxOf(0, s.layouts[pg].sentences.size - 1))
        set { it.copy(page = pg, sentence = se) }
        savePos()
        request(pg, pg + 1, pg + 2)
        if (aiPaused) releaseMp()
        if (s.playing) resumeAt(pg, se)
        ListenService.refresh(app)
    }

    /** Jump to the top of a page (the bar, "Go to page", a chapter). */
    fun seekPage(page: Int) = seek(page, 0)

    fun nextSentence() {
        val s = _state.value
        if (s.sentence + 1 < (s.layouts.getOrNull(s.page)?.sentences?.size ?: 0)) seek(s.page, s.sentence + 1) else nextPage()
    }

    fun prevSentence() {
        val s = _state.value
        if (s.sentence > 0) seek(s.page, s.sentence - 1)
        else if (s.page > 0) seek(s.page - 1, (s.layouts[s.page - 1].sentences.size - 1).coerceAtLeast(0))
    }

    fun nextPage() { val s = _state.value; if (s.page + 1 < s.pageCount) seek(s.page + 1, 0) }
    fun prevPage() { val s = _state.value; if (s.sentence > 0) seek(s.page, 0) else if (s.page > 0) seek(s.page - 1, 0) }

    private fun restartIfPlaying() { val s = _state.value; if (aiPaused) releaseMp(); if (s.playing) resumeAt(s.page, s.sentence) }

    /** New speed: the sentence being read finishes as it is, the next one uses the new speed. */
    fun setSpeed(v: Float) {
        set { it.copy(speed = v) }; app?.let { prefs(it).edit().putFloat("speed", v).apply() }
        mp?.let { m -> try { val was = m.isPlaying; m.playbackParams = m.playbackParams.setSpeed(aiSpeed()); if (!was && !aiPaused) m.pause() } catch (ignored: Exception) {} }
    }
    fun setPitch(v: Float) { set { it.copy(pitch = v) }; app?.let { prefs(it).edit().putFloat("pitch", v).apply() } }
    fun setVoice(v: ListenVoice) {
        set { it.copy(voice = v, missingVoice = null) }
        app?.let { prefs(it).edit().putInt("voice", v.ordinal).apply() }
        restartIfPlaying()
    }

    /** Picks a voice from "Choose a voice". */
    fun chooseVoice(item: VoiceItem) {
        val c = app ?: return
        if (item.lang == "hi") set { it.copy(voiceHi = item.name, aiVoice = null) } else set { it.copy(voiceEn = item.name, aiVoice = null) }
        prefs(c).edit().putString(if (item.lang == "hi") "voiceHi" else "voiceEn", item.name).remove("aiVoice").apply()
        offlineOnly.remove(item.lang)
        set { it.copy(missingVoice = null, note = null) }
        restartIfPlaying()
    }

    /** Plays a short sample in [name] (stops reading first). */
    fun sample(name: String) {
        val t = tts
        if (t == null || !ttsReady) { pendingSample = name; return }
        if (_state.value.playing) pause()
        if (_state.value.sampling == name) { t.stop(); set { it.copy(sampling = null) }; return }
        releaseMp()
        val item = _state.value.voices.firstOrNull { it.name == name } ?: return
        ListenVoices.find(t, name)?.let { t.setVoice(it) }
        t.setSpeechRate(_state.value.speed)
        t.setPitch(_state.value.pitch)
        set { it.copy(sampling = name) }
        t.speak(if (item.lang == "hi") ListenVoices.SAMPLE_HI else ListenVoices.SAMPLE_EN, TextToSpeech.QUEUE_FLUSH, Bundle(), "sample")
    }

    fun stopSample() { if (_state.value.sampling != null) { tts?.stop(); if (!_state.value.playing && !aiPaused) releaseMp(); set { it.copy(sampling = null) } } }

    /** Switch between Google's natural voices and the phone's own engine. */
    fun usePhoneEngine(on: Boolean) {
        val c = app ?: return
        if (_state.value.usePhoneEngine == on) return
        val wasPlaying = _state.value.playing
        if (wasPlaying) pause()
        prefs(c).edit().putBoolean("phoneEngine", on).apply()
        set { it.copy(usePhoneEngine = on, voices = emptyList()) }
        try { tts?.shutdown() } catch (ignored: Exception) {}
        tts = null
        createTts(c)
        if (wasPlaying) pendingPlay = true
    }

    /** After the user installed voices or Google's speech app: look again. */
    fun refreshVoices() {
        val c = app ?: return
        val google = ListenVoices.googleInstalled(c)
        if (google != _state.value.googleInstalled || tts == null) {
            try { tts?.shutdown() } catch (ignored: Exception) {}
            tts = null
            createTts(c)
        } else {
            val t = tts ?: return
            set { it.copy(voices = ListenVoices.labelled(ListenVoices.list(t, it.engine ?: ""), genders)) }
        }
    }

    /** Changes a "What to read" switch and gets the pages again (staying on this page). */
    fun setReadPrefs(ctx: Context, p: ListenReadPrefs) {
        val s = _state.value
        if (p == s.read) return
        prefs(ctx).edit().putBoolean("skipNumbers", p.skipNumbers).putBoolean("skipFigures", p.skipFigures).putBoolean("tableRows", p.tableRows).apply()
        set { it.copy(read = p) }
        val uri = s.uri ?: return
        if (s.playing) pause()
        val lb = lastBook
        if (lb != null && (uri.scheme == "listen-book" || ListenBooks.kindOf(s.name, null) == ListenBooks.Kind.ZIP)) {
            // The book is read again with the new switches; it keeps its parts and choice.
            readyParts = HashMap()
            set { it.copy(book = lb) }
            startBook(ctx, s.page)
            return
        }
        set { it.copy(loading = "Updating…", ready = false) }
        load(ctx, uri, keepPage = s.page)
    }

    private val sleepRunnable = Runnable { pause(); set { it.copy(sleep = SleepMode.OFF, sleepAt = 0L) } }
    fun setSleep(m: SleepMode) {
        main.removeCallbacks(sleepRunnable)
        val at = if (m.minutes > 0) System.currentTimeMillis() + m.minutes * 60_000L else 0L
        if (m.minutes > 0) main.postDelayed(sleepRunnable, m.minutes * 60_000L)
        set { it.copy(sleep = m, sleepAt = at) }
        restartIfPlaying()
    }

    /** Read only pages [from]..[to] (1-based, as the user types them). */
    fun setRange(from: Int, to: Int) {
        val s = _state.value
        val f = (from - 1).coerceIn(0, maxOf(0, s.pageCount - 1))
        val t = (to - 1).coerceIn(f, maxOf(0, s.pageCount - 1))
        set { it.copy(fromPage = f, toPage = t) }
        if (s.page !in f..t) seek(f, 0) else restartIfPlaying()
    }

    /** Stops reading and closes the notification. */
    fun stop() {
        gen++
        tts?.stop()
        aiJob?.cancel()
        releaseMp()
        set { it.copy(waitingPage = null) }
        if (_state.value.playing) savePos()
        set { it.copy(playing = false, sampling = null) }
        abandonFocus()
        main.removeCallbacks(sleepRunnable)
        ListenService.stop(app)
    }

    fun clearMissingVoice() = set { it.copy(missingVoice = null) }
    fun clearNote() = set { it.copy(note = null) }

    fun installVoicesIntent(): Intent = ListenVoices.installVoicesIntent(_state.value.engine?.takeIf { it.isNotEmpty() })

    // ------------------------------------------------------------ audio focus (pause for calls and other audio)

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) main.post { if (_state.value.playing) pause() }
    }

    private fun requestFocus(c: Context): Boolean {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setOnAudioFocusChangeListener(focusListener)
            .build()
        focus = req
        return am.requestAudioFocus(req) != AudioManager.AUDIOFOCUS_REQUEST_FAILED
    }

    private fun abandonFocus() {
        val c = app ?: return
        val f = focus ?: return
        (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(f)
        focus = null
    }
}

/** Hooks so the data layer can drive the notification without knowing the service class. */
object ListenService {
    var onStart: ((Context) -> Unit)? = null
    var onRefresh: ((Context) -> Unit)? = null
    var onStop: ((Context) -> Unit)? = null
    fun start(c: Context?) { c?.let { onStart?.invoke(it) } }
    fun refresh(c: Context?) { c?.let { onRefresh?.invoke(it) } }
    fun stop(c: Context?) { c?.let { onStop?.invoke(it) } }
}
