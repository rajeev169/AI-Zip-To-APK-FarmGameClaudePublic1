package com.aipdfstudio.app.data

import android.app.Activity
import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.gms.tasks.Task
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** The signed-in Google account (shown in the app; nothing else is uploaded). */
data class AccountUser(val uid: String, val name: String, val email: String, val photoUrl: String?)

/**
 * Optional Google sign-in through Firebase Authentication.
 * Works only when the build contains app/google-services.json; otherwise [ready] is false and
 * the app simply hides sign-in features.
 */
object Account {
    private val _user = MutableStateFlow<AccountUser?>(null)
    val user: StateFlow<AccountUser?> = _user

    private var started = false
    private var auth: FirebaseAuth? = null
    private var webClientId: String? = null
    private var photo: Pair<String, ImageBitmap>? = null

    /** Call once at start-up. Safe when Firebase isn't set up. */
    fun init(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        webClientId = app.resources.getIdentifier("default_web_client_id", "string", app.packageName)
            .takeIf { it != 0 }?.let { app.getString(it) }
        auth = try {
            if (FirebaseApp.getApps(app).isEmpty()) FirebaseApp.initializeApp(app)
            if (FirebaseApp.getApps(app).isEmpty()) null else FirebaseAuth.getInstance()
        } catch (e: Exception) { null }
        auth?.addAuthStateListener { a ->
            _user.value = a.currentUser?.let { u -> AccountUser(u.uid, u.displayName ?: "", u.email ?: "", u.photoUrl?.toString()) }
            // AI teacher samples made while signed out are shared now.
            if (a.currentUser != null) AiSamples.uploadPending(app)
        }
        _user.value = auth?.currentUser?.let { u -> AccountUser(u.uid, u.displayName ?: "", u.email ?: "", u.photoUrl?.toString()) }
    }

    /** True when this build has Firebase set up (needed for the shared AI teacher samples). */
    val firebaseReady: Boolean get() = auth != null

    /** True when this build can sign in (Firebase file and Google client id are present). */
    val ready: Boolean get() = auth != null && !webClientId.isNullOrBlank()

    class SignInError(message: String, val cancelled: Boolean = false) : Exception(message)

    /** Shows Google's account chooser and signs in. Throws [SignInError] with a friendly message. */
    suspend fun signIn(activity: Activity) {
        val token = googleIdToken(activity)
        val a = auth ?: throw SignInError("Google sign-in isn't set up in this version of the app.")
        try {
            a.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
        } catch (e: Exception) {
            throw SignInError(networkOr(e, "Couldn't sign in. Please try again."))
        }
    }

    /** Signs out of the app (and makes Google ask which account next time). */
    suspend fun signOut(ctx: Context) {
        try { auth?.signOut() } catch (_: Exception) {}
        try { CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest()) } catch (_: Exception) {}
        photo = null
    }

    /**
     * Deletes the account from the app's sign-in list. Google asks the user to confirm their
     * account first (Firebase needs a fresh sign-in to delete).
     */
    suspend fun deleteAccount(activity: Activity) {
        val a = auth ?: return
        val u = a.currentUser ?: return
        val token = googleIdToken(activity)
        try {
            u.reauthenticate(GoogleAuthProvider.getCredential(token, null)).await()
            u.delete().await()
        } catch (e: Exception) {
            throw SignInError(networkOr(e, "Couldn't delete the account. Please try again."))
        }
        signOut(activity)
    }

    private suspend fun googleIdToken(activity: Activity): String {
        val id = webClientId
        if (auth == null || id.isNullOrBlank()) throw SignInError("Google sign-in isn't set up in this version of the app.")
        val option = GetSignInWithGoogleOption.Builder(id).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = try {
            CredentialManager.create(activity).getCredential(activity, request)
        } catch (e: GetCredentialCancellationException) {
            throw SignInError("Sign-in cancelled.", cancelled = true)
        } catch (e: NoCredentialException) {
            throw SignInError("No Google account found. Add a Google account in the phone's Settings and try again.")
        } catch (e: GetCredentialException) {
            throw SignInError("Couldn't open Google sign-in. Check your internet and try again.")
        }
        val c = result.credential
        if (c is CustomCredential && c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            return try { GoogleIdTokenCredential.createFrom(c.data).idToken } catch (e: Exception) {
                throw SignInError("Google sent an unexpected reply. Please try again.")
            }
        }
        throw SignInError("Google sent an unexpected reply. Please try again.")
    }

    private fun networkOr(e: Exception, fallback: String): String {
        val n = e.javaClass.simpleName
        return if (n.contains("Network", true)) "No internet. Please connect and try again." else fallback
    }

    /** The account photo (small), loaded once and kept in memory. */
    suspend fun photo(url: String?): ImageBitmap? {
        if (url.isNullOrBlank()) return null
        photo?.let { if (it.first == url) return it.second }
        return withContext(Dispatchers.IO) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) } ?: return@withContext null
                bmp.asImageBitmap().also { photo = url to it }
            } catch (e: Exception) { null }
        }
    }

    // ---- remembers whether the welcome screen was shown ----
    fun introSeen(ctx: Context): Boolean =
        ctx.getSharedPreferences("account", Context.MODE_PRIVATE).getBoolean("intro_seen", false)

    fun setIntroSeen(ctx: Context) {
        ctx.getSharedPreferences("account", Context.MODE_PRIVATE).edit().putBoolean("intro_seen", true).apply()
    }
}

/** Waits for a Google Play services task without extra libraries. */
private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}
