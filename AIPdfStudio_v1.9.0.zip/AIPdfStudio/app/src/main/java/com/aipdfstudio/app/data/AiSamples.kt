package com.aipdfstudio.app.data

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.Blob
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * The AI Teacher sample voices ("AI Female Teacher · हिन्दी" …).
 *
 * Each sample is kept in two places at once:
 *  - on the phone, in the app's files folder (fast, works offline, not cleared with the cache);
 *  - in Firestore, collection [COLLECTION], shared by every user of the app.
 *
 * The first user who makes a sample (with their own Gemini key) uploads it; everyone after
 * that downloads it, without a key. Only signed-in users may upload, and nobody can change a
 * sample once it is there (see the Firestore rules). A sample made while signed out waits on the
 * phone and is uploaded after the user signs in.
 */
object AiSamples {
    const val COLLECTION = "ai_samples"
    /** Firestore allows 1 MiB per document; keep well under it. */
    const val MAX_BYTES = 900_000

    enum class Stage { GETTING, MAKING }

    /** Clear reasons a sample can't be played; [noKey] means "nobody has made it yet and you have no key". */
    class Problem(message: String, val noKey: Boolean = false) : Exception(message)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()

    fun text(lang: String) = if (lang == "hi") ListenVoices.SAMPLE_HI_TEACHER else ListenVoices.SAMPLE_EN_TEACHER

    /** Same name on every phone, e.g. "t2_Fola_hi_c14133d0": style, voice, language, sample text. */
    fun id(voiceId: String, lang: String): String =
        "${AiTeacher.STYLE_VERSION}_${voiceId}_${lang}_" + ListenCache.key(AiTeacher.STYLE_VERSION, AiTeacher.MODEL, voiceId, text(lang)).take(8)

    private fun dir(ctx: Context) = File(ctx.applicationContext.filesDir, "ai_samples").apply { mkdirs() }
    private fun audioFile(ctx: Context, id: String, ext: String) = File(dir(ctx), "$id.$ext")
    private fun pendingFile(ctx: Context, id: String) = File(dir(ctx), "$id.pending")

    /** The sample already on this phone, or null. */
    fun onPhone(ctx: Context, voiceId: String, lang: String): File? {
        val id = id(voiceId, lang)
        return listOf("m4a", "wav").map { audioFile(ctx, id, it) }.firstOrNull { it.isFile && it.length() > 1000 }
    }

    /**
     * Returns the sample file to play: from the phone, else from Firestore, else made with the
     * user's Gemini key (and then saved on the phone and in Firestore at the same time).
     */
    suspend fun get(ctx: Context, voiceId: String, lang: String, apiKey: String, onStage: (Stage) -> Unit): File = withContext(Dispatchers.IO) {
        onPhone(ctx, voiceId, lang)?.let { return@withContext it }
        lock.withLock {
            onPhone(ctx, voiceId, lang)?.let { return@withContext it }
            val id = id(voiceId, lang)

            // 1) Shared copy in Firestore.
            onStage(Stage.GETTING)
            var offline = false
            val db = firestore(ctx)
            if (db != null) {
                try {
                    val snap = withTimeout(15000) { db.collection(COLLECTION).document(id).get().await() }
                    val bytes = if (snap.exists()) snap.getBlob("audio")?.toBytes() else null
                    if (bytes != null && bytes.size > 1000) {
                        val ext = if (snap.getString("mime") == "audio/wav") "wav" else "m4a"
                        return@withContext save(audioFile(ctx, id, ext), bytes)
                    }
                } catch (e: Exception) {
                    if (e is kotlinx.coroutines.CancellationException && e !is kotlinx.coroutines.TimeoutCancellationException) throw e
                    offline = true
                }
            }

            // 2) Nobody has made it yet: make it with this user's key.
            if (apiKey.isBlank()) {
                throw if (offline) Problem("No internet — tap ▶ to try again.")
                else Problem("Sample not ready yet — add a free Gemini key to make it.", noKey = true)
            }
            onStage(Stage.MAKING)
            val (pcm, rate) = try { AiTeacher.makePcm(apiKey, voiceId, text(lang)) } catch (e: AiTeacher.Failure) {
                throw Problem(e.message ?: "Couldn't make the sample.", noKey = e.noKey)
            }
            val m4a = audioFile(ctx, id, "m4a")
            val f = if (encodeAac(pcm, rate, m4a)) m4a else {
                m4a.delete()
                val w = audioFile(ctx, id, "wav")
                AiTeacher.writeWav(pcm, rate, w); w
            }
            // Saved on the phone; now the shared copy (or remember it for after sign-in).
            pendingFile(ctx, id).writeText(JSONObject().put("voice", voiceId).put("lang", lang).put("file", f.name).toString())
            scope.launch { upload(ctx, id) }
            f
        }
    }

    /** Uploads every sample made while signed out (call after sign-in and at start-up). */
    fun uploadPending(ctx: Context) {
        val app = ctx.applicationContext
        scope.launch {
            dir(app).listFiles { f -> f.name.endsWith(".pending") }?.forEach { upload(app, it.name.removeSuffix(".pending")) }
        }
    }

    private suspend fun upload(ctx: Context, id: String) {
        val pending = pendingFile(ctx, id)
        if (!pending.isFile) return
        val uid = Account.user.value?.uid ?: return            // only signed-in users may add samples
        val db = firestore(ctx) ?: return
        try {
            val info = JSONObject(pending.readText())
            val f = File(dir(ctx), info.getString("file"))
            if (!f.isFile) { pending.delete(); return }
            val bytes = f.readBytes()
            if (bytes.size > MAX_BYTES) { pending.delete(); return }
            val doc = db.collection(COLLECTION).document(id)
            if (doc.get().await().exists()) { pending.delete(); return }   // someone shared it first
            doc.set(
                hashMapOf(
                    "audio" to Blob.fromBytes(bytes),
                    "mime" to if (f.name.endsWith(".wav")) "audio/wav" else "audio/mp4",
                    "voice" to info.getString("voice"),
                    "lang" to info.getString("lang"),
                    "style" to AiTeacher.STYLE_VERSION,
                    "model" to AiTeacher.MODEL,
                    "text" to text(info.getString("lang")),
                    "size" to bytes.size.toLong(),
                    "uid" to uid,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            pending.delete()
        } catch (e: Exception) {
            // No internet or not allowed (e.g. it was added a moment ago): try again next time.
            if (e.javaClass.simpleName == "FirebaseFirestoreException" && e.message?.contains("PERMISSION_DENIED") == true) {
                try { if (db.collection(COLLECTION).document(id).get().await().exists()) pending.delete() } catch (_: Exception) {}
            }
        }
    }

    private fun firestore(ctx: Context): FirebaseFirestore? {
        Account.init(ctx)
        if (!Account.firebaseReady) return null
        return try { FirebaseFirestore.getInstance() } catch (e: Exception) { null }
    }

    private fun save(f: File, bytes: ByteArray): File {
        val tmp = File(f.path + ".tmp")
        tmp.writeBytes(bytes)
        if (!tmp.renameTo(f)) { f.writeBytes(bytes); tmp.delete() }
        return f
    }

    /**
     * Compresses 16-bit mono PCM to AAC in an .m4a file (about 32 kbit/s: a 15-second sample is
     * ~60 KB instead of ~0.7 MB). Returns false if the phone's encoder isn't available.
     */
    fun encodeAac(pcm: ByteArray, rate: Int, out: File): Boolean {
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        val tmp = File(out.path + ".tmp")
        try {
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1)
            fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 32000)
            fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC); codec = c
            c.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            c.start()
            tmp.delete()
            val m = MediaMuxer(tmp.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); muxer = m
            val info = MediaCodec.BufferInfo()
            var pos = 0
            var inputDone = false
            var track = -1
            var started = false
            var written = 0
            val deadline = System.currentTimeMillis() + 30000
            while (System.currentTimeMillis() < deadline) {
                if (!inputDone) {
                    val ii = c.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)!!
                        buf.clear()
                        val n = minOf(buf.remaining() - buf.remaining() % 2, pcm.size - pos)
                        val timeUs = (pos / 2).toLong() * 1_000_000L / rate
                        if (n <= 0) {
                            c.queueInputBuffer(ii, 0, 0, timeUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            buf.put(pcm, pos, n)
                            c.queueInputBuffer(ii, 0, n, timeUs, 0)
                            pos += n
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 10000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = m.addTrack(c.outputFormat); m.start(); started = true
                } else if (oi >= 0) {
                    val buf = c.getOutputBuffer(oi)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && started) {
                        buf.position(info.offset); buf.limit(info.offset + info.size)
                        m.writeSampleData(track, buf, info); written++
                    }
                    c.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                }
            }
            c.stop()
            if (started) m.stop()
            m.release(); muxer = null
            c.release(); codec = null
            if (!started || written < 5 || tmp.length() < 1000) { tmp.delete(); return false }
            out.delete()
            return tmp.renameTo(out)
        } catch (e: Exception) {
            tmp.delete()
            return false
        } finally {
            try { muxer?.release() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
        }
    }
}

/** Waits for a Google Play services task without extra libraries. */
private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}
