package com.aipdfstudio.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * "AI Teacher" voices: Google's Gemini speech voices, read in the style of a school teacher.
 * Audio is made a little ahead of the reading and kept on the phone, so a page read once
 * plays again without internet.
 */
object AiTeacher {
    const val MODEL = "gemini-3.8-flash-tts"
    /** Changing the notes below changes this, so audio made with the old style is made again. */
    const val STYLE_VERSION = "t2"   // t2: audio cleaned (no pop at the end)

    data class Voice(val id: String, val label: String, val short: String, val female: Boolean)

    val VOICES = listOf(
        Voice("Fola", "AI Female Teacher", "AI Female", true),
        Voice("Ludo", "AI Male Teacher", "AI Male", false)
    )

    fun voice(id: String?): Voice? = VOICES.firstOrNull { it.id == id }

    /** How the teacher reads (measured from a real classroom: half-second stops, short breaths, normal pace). */
    fun notes(hindi: Boolean): String = if (hindi)
        "A warm, clear Indian school teacher reading a lesson aloud to students in Hindi, with natural Hindi pronunciation. " +
            "Normal lively pace, not slow. Short breath at commas, about half a second pause after each \"।\" or full stop, " +
            "a slightly longer pause between paragraphs. Slightly slower and clearer on new or difficult words, a natural rise on questions. " +
            "Calm, friendly and confident, never dramatic. Read only the transcript."
    else
        "A friendly, clear Indian school teacher reading a lesson aloud to students in English, with a gentle Indian English accent. " +
            "Normal lively pace, not slow. Short breath at commas, about half a second pause after each full stop, " +
            "a slightly longer pause between paragraphs. Slightly slower and clearer on new or scientific words, a natural rise on questions. " +
            "Calm, friendly and confident, never dramatic. Read only the transcript."

    fun prompt(text: String, hindi: Boolean): String = "## Director's Notes:\n${notes(hindi)}\n\n## Transcript:\n$text"

    /** A problem making the voice; [quota] and [noKey] let the player say exactly what to do. */
    class Failure(message: String, val noKey: Boolean = false, val quota: Boolean = false) : Exception(message)

    /** The file the audio for [text] is (or will be) kept in. */
    fun cacheFile(dir: File, voiceId: String, text: String): File =
        File(dir, "listen_ai/" + ListenCache.key(STYLE_VERSION, MODEL, voiceId, text) + ".wav")

    /** Makes the audio for [text] (or reuses it) and returns the WAV file. */
    suspend fun audio(cacheDir: File, apiKey: String, voiceId: String, text: String): File = withContext(Dispatchers.IO) {
        val f = cacheFile(cacheDir, voiceId, text)
        if (f.isFile && f.length() > 1000) return@withContext f
        val (pcm, rate) = makePcm(apiKey, voiceId, text)
        f.parentFile?.mkdirs()
        val tmp = File(f.path + ".tmp")
        writeWav(pcm, rate, tmp)
        tmp.renameTo(f)
        f
    }

    /** Asks Google for the voice and returns cleaned 16-bit mono PCM and its sample rate (no saving). */
    fun makePcm(apiKey: String, voiceId: String, text: String): Pair<ByteArray, Int> {
        if (apiKey.isBlank()) throw Failure("Add your Gemini key (AI tab → settings) to use the AI teacher voice.", noKey = true)
        val (raw, rate) = request(apiKey, voiceId, text, ListenText.isHindi(text))
        return clean(raw, rate) to rate
    }

    private fun request(apiKey: String, voiceId: String, text: String, hindi: Boolean): Pair<ByteArray, Int> {
        val body = org.json.JSONObject()
            .put("contents", org.json.JSONArray().put(
                org.json.JSONObject().put("role", "user").put("parts", org.json.JSONArray().put(org.json.JSONObject().put("text", prompt(text, hindi))))
            ))
            .put("generationConfig", org.json.JSONObject()
                .put("responseModalities", org.json.JSONArray().put("audio"))
                .put("temperature", 0.7)
                .put("speech_config", org.json.JSONObject().put("voice_config", org.json.JSONObject().put("prebuilt_voice_config", org.json.JSONObject().put("voice_name", voiceId)))))
        try {
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 120000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey.trim())
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            conn.disconnect()
            when {
                code in 200..299 -> return parse(raw)
                code == 429 -> throw Failure("The AI teacher voice has reached today's free limit.", quota = true)
                code == 400 && raw.contains("API key", true) || code == 401 || code == 403 -> throw Failure("Google didn't accept the Gemini key.", noKey = true)
                code == 404 -> throw Failure("The AI teacher voice isn't available for this key yet.")
                code in 500..599 -> throw Failure("Google's voice service is busy.")
                else -> throw Failure("The AI teacher voice failed (error $code).")
            }
        } catch (e: UnknownHostException) {
            throw Failure("No internet connection.")
        } catch (e: SocketTimeoutException) {
            throw Failure("The AI teacher voice took too long (slow internet).")
        } catch (e: Failure) {
            throw e
        } catch (e: Exception) {
            throw Failure("Couldn't reach Google's voice service.")
        }
    }

    /** Audio comes back as base64 PCM ("audio/L16;codec=pcm;rate=24000"). */
    fun parse(raw: String): Pair<ByteArray, Int> {
        val parts = org.json.JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw Failure("The AI teacher voice returned nothing.")
        val out = java.io.ByteArrayOutputStream()
        var rate = 24000
        for (i in 0 until parts.length()) {
            val d = parts.getJSONObject(i).optJSONObject("inlineData") ?: parts.getJSONObject(i).optJSONObject("inline_data") ?: continue
            val mime = d.optString("mimeType", d.optString("mime_type", "")).lowercase()
            if (!mime.startsWith("audio")) continue
            Regex("rate=(\\d+)").find(mime)?.let { rate = it.groupValues[1].toInt() }
            var bytes = java.util.Base64.getMimeDecoder().decode(d.optString("data"))
            // A WAV piece carries a header: keep only its sound data.
            if (bytes.size > 44 && String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF") {
                rate = (bytes[24].toInt() and 0xFF) or ((bytes[25].toInt() and 0xFF) shl 8) or ((bytes[26].toInt() and 0xFF) shl 16)
                bytes = bytes.copyOfRange(44, bytes.size)
            }
            out.write(bytes, 0, bytes.size - bytes.size % 2)
        }
        if (out.size() == 0) throw Failure("The AI teacher voice returned no sound.")
        return out.toByteArray() to rate
    }

    /**
     * Tidies the sound before it is saved: removes a short loud burst after the voice has
     * finished (it sounds like a pop or knock), keeps only a little silence at the start and end
     * (so parts flow on), and fades the very start and end so pieces never click.
     * [pcm] is 16-bit little-endian mono.
     */
    fun clean(pcm: ByteArray, rate: Int): ByteArray {
        val n = pcm.size / 2
        if (n < rate / 10) return pcm
        val s = ShortArray(n) { k -> ((pcm[2 * k].toInt() and 0xFF) or (pcm[2 * k + 1].toInt() shl 8)).toShort() }
        val fr = rate / 100                         // 10 ms frames
        val nf = n / fr
        val db = FloatArray(nf); val peak = FloatArray(nf)
        for (f in 0 until nf) {
            var e = 0.0; var pk = 0
            for (k in f * fr until (f + 1) * fr) { val v = s[k].toInt(); e += v.toDouble() * v; if (kotlin.math.abs(v) > pk) pk = kotlin.math.abs(v) }
            db[f] = (20 * kotlin.math.log10(kotlin.math.sqrt(e / fr) / 32768.0 + 1e-9)).toFloat()
            peak[f] = pk / 32768f
        }
        val sorted = db.sorted()
        val loudRef = sorted[(nf * 0.95).toInt().coerceAtMost(nf - 1)]
        val thr = maxOf(-50f, loudRef - 35f)
        val voiced = BooleanArray(nf) { db[it] > thr }
        val speech = db.filterIndexed { i, _ -> voiced[i] }.sorted().let { if (it.isEmpty()) -20f else it[it.size / 2] }
        // Runs of sound, as frame ranges.
        val runs = ArrayList<IntRange>()
        var i = 0
        while (i < nf) {
            if (!voiced[i]) { i++; continue }
            var j = i
            while (j < nf && (voiced[j] || (j + 1 < nf && voiced[j + 1]))) j++
            runs.add(i until j); i = j
        }
        fun junk(r: IntRange, gapBefore: Int, gapAfter: Int): Boolean {
            val len = r.last - r.first + 1
            val loud = r.maxOf { db[it] }
            val clip = r.maxOf { peak[it] }
            // Short, cut off from the speech by a pause, and much louder than the voice (or clipping).
            return len <= 40 && (gapBefore >= 25 || gapAfter >= 25) && (loud > speech + 14f || clip >= 0.95f)
        }
        val keep = runs.toMutableList()
        while (keep.size > 1) {
            val last = keep.last(); val prev = keep[keep.size - 2]
            if (junk(last, last.first - prev.last - 1, nf - last.last - 1)) keep.removeAt(keep.size - 1) else break
        }
        while (keep.size > 1) {
            val first = keep.first(); val next = keep[1]
            if (junk(first, first.first, next.first - first.last - 1)) keep.removeAt(0) else break
        }
        if (keep.isEmpty()) return pcm
        val start = maxOf(0, keep.first().first * fr - rate * 15 / 100)        // ≤ 0.15 s before
        val end = minOf(n, (keep.last().last + 1) * fr + rate * 30 / 100)      // ≤ 0.3 s after
        val outS = s.copyOfRange(start, end)
        val fadeIn = minOf(outS.size / 4, rate * 15 / 1000)
        val fadeOut = minOf(outS.size / 4, rate * 25 / 1000)
        for (k in 0 until fadeIn) outS[k] = (outS[k] * (k.toFloat() / fadeIn)).toInt().toShort()
        for (k in 0 until fadeOut) { val idx = outS.size - 1 - k; outS[idx] = (outS[idx] * (k.toFloat() / fadeOut)).toInt().toShort() }
        val out = ByteArray(outS.size * 2)
        for (k in outS.indices) { out[2 * k] = outS[k].toInt().toByte(); out[2 * k + 1] = (outS[k].toInt() shr 8).toByte() }
        return out
    }

    /** 16-bit mono PCM to a WAV file. */
    fun writeWav(pcm: ByteArray, rate: Int, f: File) {
        RandomAccessFile(f, "rw").use { r ->
            r.setLength(0)
            fun i32(v: Int) { r.write(byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())) }
            fun i16(v: Int) { r.write(byteArrayOf(v.toByte(), (v shr 8).toByte())) }
            r.writeBytes("RIFF"); i32(36 + pcm.size); r.writeBytes("WAVE")
            r.writeBytes("fmt "); i32(16); i16(1); i16(1); i32(rate); i32(rate * 2); i16(2); i16(16)
            r.writeBytes("data"); i32(pcm.size); r.write(pcm)
        }
    }

    /**
     * Groups a page's blocks into pieces of about a paragraph or two (fewer requests, natural
     * flow). Returns, for each piece, the first and last sentence index.
     */
    fun pieces(p: LPage, maxChars: Int = 700): List<IntRange> {
        val out = ArrayList<IntRange>()
        var start = -1; var end = -1; var chars = 0
        fun close() { if (start >= 0) out.add(start..end); start = -1; chars = 0 }
        for (b in p.blocks) {
            if (b.count == 0) continue
            val len = (b.first until b.first + b.count).sumOf { p.sentences[it].say.length }
            // A heading starts a new piece (unless it would be alone at the very start), and pieces stay under the limit.
            if (start >= 0 && (chars + len > maxChars || b.kind == LKind.HEADING || b.kind == LKind.FIGURE)) close()
            if (start < 0) start = b.first
            end = b.first + b.count - 1
            chars += len
            if (b.kind == LKind.FIGURE) close()
        }
        close()
        return out
    }

    /** The text sent for sentences [from]..[to] of a page: blocks on their own lines, so the voice pauses there. */
    fun textOf(p: LPage, from: Int, to: Int): String {
        val sb = StringBuilder()
        var lastBlock: LBlock? = null
        for (i in from..to) {
            val b = p.blocks.firstOrNull { i >= it.first && i < it.first + it.count }
            if (sb.isNotEmpty()) sb.append(if (b != lastBlock) "\n\n" else " ")
            sb.append(p.sentences[i].say)
            lastBlock = b
        }
        return sb.toString()
    }
}
