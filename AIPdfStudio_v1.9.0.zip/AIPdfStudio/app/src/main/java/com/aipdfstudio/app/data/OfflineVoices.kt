package com.aipdfstudio.app.data

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * "Offline AI" voices: free neural voices (Piper) that run on the phone itself.
 * They are not inside the APK. The student downloads a voice once (about 67 MB); it is
 * unpacked into the app's files folder and then reads any book with no internet and no key.
 */
object OfflineVoices {

    /** One downloadable voice. [file] is the voice's name inside the download. */
    data class Voice(
        val id: String,          // e.g. "hi_priyamvada"
        val name: String,        // shown in the list
        val lang: String,        // "hi" or "en"
        val female: Boolean,
        val file: String,        // "hi_IN-priyamvada-medium"
        val sizeMb: Int,
        val asset: String        // bundled 10-second sample in assets/
    ) {
        val url get() = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-$file.tar.bz2"
        val chip get() = if (lang == "hi") "Offline AI · हिन्दी" else "Offline AI · English"
    }

    val VOICES = listOf(
        Voice("hi_priyamvada", "Priyamvada", "hi", true, "hi_IN-priyamvada-medium", 67, "offline_samples/hi_priyamvada.m4a"),
        Voice("hi_rohan", "Rohan", "hi", false, "hi_IN-rohan-medium", 67, "offline_samples/hi_rohan.m4a"),
        Voice("en_amy", "Amy", "en", true, "en_US-amy-medium", 67, "offline_samples/en_amy.m4a"),
        Voice("en_ryan", "Ryan", "en", false, "en_US-ryan-medium", 67, "offline_samples/en_ryan.m4a")
    )

    /** In ListenState.aiVoice an offline voice is kept as "off:<id>" (AI Teacher ids are "Fola"/"Ludo"). */
    const val PREFIX = "off:"
    fun isOffline(aiVoice: String?) = aiVoice?.startsWith(PREFIX) == true
    fun of(aiVoice: String?): Voice? = if (isOffline(aiVoice)) voice(aiVoice!!.removePrefix(PREFIX)) else null
    fun voice(id: String): Voice? = VOICES.firstOrNull { it.id == id }

    private fun root(ctx: Context) = File(ctx.applicationContext.filesDir, "voices").apply { mkdirs() }
    private fun dir(ctx: Context, v: Voice) = File(root(ctx), v.id)
    /** espeak-ng-data is the same in every voice download, so it is kept once for all voices. */
    private fun espeak(ctx: Context) = File(root(ctx), "espeak-ng-data")

    fun isDownloaded(ctx: Context, v: Voice): Boolean =
        File(dir(ctx, v), ".ok").isFile && File(dir(ctx, v), "model.onnx").isFile && File(espeak(ctx), "phontab").isFile

    /** Removes half-finished downloads (the app may have been closed during one). */
    fun cleanUp(ctx: Context) {
        root(ctx).listFiles()?.filter { it.name.endsWith(".part") }?.forEach { it.deleteRecursively() }
    }

    class DownloadError(message: String) : Exception(message)

    /** Set to true to stop a running download. */
    @Volatile var cancelled: String? = null

    /**
     * Downloads and unpacks [v]. [progress] gets (MB done, MB total). Runs on the IO thread.
     * The voice only counts as downloaded once everything is unpacked.
     */
    suspend fun download(ctx: Context, v: Voice, progress: (Int, Int) -> Unit) = withContext(Dispatchers.IO) {
        val app = ctx.applicationContext
        cancelled = null
        val freeMb = root(app).usableSpace / 1_000_000
        if (freeMb < v.sizeMb + 120) throw DownloadError("Not enough space. Free about ${v.sizeMb + 120 - freeMb} MB and try again.")
        val part = File(root(app), v.id + ".part").apply { deleteRecursively(); mkdirs() }
        val needEspeak = !File(espeak(app), "phontab").isFile
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(v.url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20000; readTimeout = 30000; instanceFollowRedirects = true
            }
            val code = conn.responseCode
            if (code !in 200..299) throw DownloadError("Download failed (error $code). Try again later.")
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: (v.sizeMb * 1_000_000L)
            val totalMb = (total / 1_000_000).toInt().coerceAtLeast(1)
            var lastMb = -1
            val counted = object : FilterInputStream(conn.inputStream) {
                var n = 0L
                private fun add(k: Int) {
                    if (cancelled == v.id) throw DownloadError("cancelled")
                    if (k > 0) { n += k; val mb = (n / 1_000_000).toInt(); if (mb != lastMb) { lastMb = mb; progress(mb, totalMb) } }
                }
                override fun read(): Int { val b = super.read(); if (b >= 0) add(1); return b }
                override fun read(b: ByteArray, off: Int, len: Int): Int { val k = super.read(b, off, len); add(k); return k }
            }
            TarArchiveInputStream(BZip2CompressorInputStream(BufferedInputStream(counted, 1 shl 16))).use { tar ->
                while (true) {
                    val e = tar.nextEntry ?: break
                    if (e.isDirectory) continue
                    // "vits-piper-xx/<file>": keep the model, its tokens and (once) espeak-ng-data.
                    val rel = e.name.substringAfter('/', "")
                    if (rel.isEmpty() || rel.contains("..")) continue
                    val out: File? = when {
                        rel.endsWith(".onnx") -> File(part, "model.onnx")
                        rel == "tokens.txt" -> File(part, "tokens.txt")
                        rel.startsWith("espeak-ng-data/") && needEspeak -> File(part, rel)
                        else -> null
                    }
                    if (out == null) continue
                    out.parentFile?.mkdirs()
                    out.outputStream().use { o -> copy(tar, o) }
                }
            }
            if (!File(part, "model.onnx").isFile || !File(part, "tokens.txt").isFile) throw DownloadError("The voice download was incomplete. Try again.")
            if (needEspeak) {
                val e = File(part, "espeak-ng-data")
                if (!File(e, "phontab").isFile) throw DownloadError("The voice download was incomplete. Try again.")
                espeak(app).deleteRecursively()
                if (!e.renameTo(espeak(app))) throw DownloadError("Couldn't save the voice. Try again.")
            }
            File(part, ".ok").writeText(v.file)
            val dest = dir(app, v)
            dest.deleteRecursively()
            if (!part.renameTo(dest)) throw DownloadError("Couldn't save the voice. Try again.")
            progress(totalMb, totalMb)
        } catch (e: DownloadError) {
            part.deleteRecursively(); throw e
        } catch (e: java.net.UnknownHostException) {
            part.deleteRecursively(); throw DownloadError("No internet. Connect and try again.")
        } catch (e: java.io.IOException) {
            part.deleteRecursively(); throw DownloadError("The download stopped (internet problem). Try again.")
        } catch (e: Exception) {
            part.deleteRecursively()
            if (e is kotlinx.coroutines.CancellationException) throw e
            throw DownloadError("Couldn't download the voice. Try again.")
        } finally {
            conn?.disconnect()
        }
    }

    private fun copy(i: InputStream, o: java.io.OutputStream) {
        val buf = ByteArray(1 shl 16)
        while (true) { val k = i.read(buf); if (k < 0) break; o.write(buf, 0, k) }
    }

    /** Deletes a downloaded voice (espeak-ng-data goes too when no voice is left). */
    fun remove(ctx: Context, v: Voice) {
        synchronized(this) { if (engineFor == v.id) { try { engine?.release() } catch (_: Exception) {}; engine = null; engineFor = null } }
        dir(ctx, v).deleteRecursively()
        if (VOICES.none { isDownloaded(ctx, it) }) espeak(ctx).deleteRecursively()
    }

    // ------------------------------------------------------------------ speaking

    private var engine: OfflineTts? = null
    private var engineFor: String? = null
    private val lock = Mutex()

    private fun engine(ctx: Context, v: Voice): OfflineTts {
        synchronized(this) {
            engine?.let { if (engineFor == v.id) return it }
            try { engine?.release() } catch (_: Exception) {}
            engine = null; engineFor = null
            val d = dir(ctx, v)
            val vits = OfflineTtsVitsModelConfig(
                model = File(d, "model.onnx").path,
                tokens = File(d, "tokens.txt").path,
                dataDir = espeak(ctx).path
            )
            val cores = Runtime.getRuntime().availableProcessors()
            val cfg = OfflineTtsConfig(
                model = OfflineTtsModelConfig(vits = vits, numThreads = if (cores >= 8) 4 else 2, provider = "cpu"),
                maxNumSentences = 2
            )
            val t = OfflineTts(null, cfg)
            engine = t; engineFor = v.id
            return t
        }
    }

    class SpeakError(message: String) : Exception(message)

    /**
     * Makes the audio for [text] with voice [v] and returns a WAV file (kept in the cache, so a
     * part read twice is not made twice).
     */
    suspend fun audio(ctx: Context, v: Voice, text: String): File = withContext(Dispatchers.IO) {
        val f = File(ctx.applicationContext.cacheDir, "listen_off/" + ListenCache.key("p1", v.id, text) + ".wav")
        if (f.isFile && f.length() > 1000) return@withContext f
        if (!isDownloaded(ctx, v)) throw SpeakError("The ${v.name} voice isn't downloaded.")
        lock.withLock {
            if (f.isFile && f.length() > 1000) return@withContext f
            val a = try { engine(ctx, v).generate(text, 0, 1.0f) } catch (e: Throwable) {
                throw SpeakError("The offline voice couldn't read this part.")
            }
            val s = a.samples
            if (s.isEmpty()) throw SpeakError("The offline voice couldn't read this part.")
            val pcm = ByteArray(s.size * 2)
            for (i in s.indices) {
                val x = (s[i].coerceIn(-1f, 1f) * 32767f).toInt()
                pcm[2 * i] = (x and 0xFF).toByte(); pcm[2 * i + 1] = (x shr 8).toByte()
            }
            f.parentFile?.mkdirs()
            val tmp = File(f.path + ".tmp")
            AiTeacher.writeWav(pcm, a.sampleRate, tmp)
            tmp.renameTo(f)
            f
        }
    }

    /** The voice to use for a part in [lang]: the chosen one, else a downloaded voice of that language (same gender first). */
    fun forLang(ctx: Context, chosen: Voice, lang: String): Voice? {
        if (chosen.lang == lang) return chosen
        val ready = VOICES.filter { it.lang == lang && isDownloaded(ctx, it) }
        return ready.firstOrNull { it.female == chosen.female } ?: ready.firstOrNull()
    }

    // ------------------------------------------------------------------ phone voice into a file
    // For a part in the other language when no offline voice of that language is downloaded.

    private var phone: TextToSpeech? = null
    private var phoneReady = false
    private val phoneLock = Mutex()

    suspend fun phoneAudio(ctx: Context, engine: String?, voiceName: String?, text: String): File = withContext(Dispatchers.IO) {
        val f = File(ctx.applicationContext.cacheDir, "listen_off/" + ListenCache.key("ph1", engine ?: "", voiceName ?: "", text) + ".wav")
        if (f.isFile && f.length() > 1000) return@withContext f
        phoneLock.withLock {
            if (phone == null || !phoneReady) {
                val ready = CountDownLatch(1)
                var ok = false
                val t = TextToSpeech(ctx.applicationContext, { st -> ok = st == TextToSpeech.SUCCESS; ready.countDown() }, engine)
                ready.await(10, TimeUnit.SECONDS)
                if (!ok) { try { t.shutdown() } catch (_: Exception) {}; throw SpeakError("The phone voice isn't ready.") }
                phone = t; phoneReady = true
            }
            val t = phone!!
            ListenVoices.find(t, voiceName)?.let { t.voice = it }
            f.parentFile?.mkdirs(); f.delete()
            val done = CountDownLatch(1)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { done.countDown() }
                @Deprecated("old API") override fun onError(id: String?) { done.countDown() }
            })
            t.synthesizeToFile(text, Bundle(), f, "offfile")
            done.await(60, TimeUnit.SECONDS)
            if (!f.isFile || f.length() < 1000) throw SpeakError("The phone voice couldn't read this part.")
            f
        }
    }
}
