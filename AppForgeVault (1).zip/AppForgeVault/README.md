# AppForge Vault — Password Manager (v1.0)

Package: `com.appforge.vault` · Kotlin + Jetpack Compose (Material 3) · minSdk 26 · targetSdk 35

## Features
- **Email + password account** (Create account / Sign in / Forgot password). No Google sign-in.
- **Auto-save & autofill**: Android Autofill Service. When you log in to any email, app or website, Android asks to save the login. Next time, it fills it in after you unlock with your fingerprint or PIN.
- **Encryption**: AES-256-GCM. The vault key is protected by Android Keystore on the phone. Backups are encrypted with your account password before upload, so Firebase only stores scrambled data.
- **App lock**: 4–6 digit PIN and optional fingerprint. Auto-lock timer. 5 wrong PINs trigger a waiting period.
- **Menu (drawer)**: Passwords, Password generator, Security check, Settings, About, Lock app, Sign out.
- **Settings**: Automatic backup toggle, Back up now, Restore, Autofill service, Offer to save, Fingerprint, Change PIN, Auto-lock, Clear clipboard timer, Block screenshots, Export/Import, Theme, Change account password, Sign out, Delete account.
- **Password generator**: length from 8 to 64; capital letters, small letters, numbers and symbols.
- **Security check**: health score, weak passwords, reused passwords.
- **Export/Import**: encrypted `.json` export protected by a password you choose. Imports that file or CSV files from Google Password Manager, Chrome, Bitwarden and others.

## Before building: Firebase setup (one time)
1. Go to https://console.firebase.google.com and create a project, or use an existing one.
2. **Add Android app** with package name `com.appforge.vault`.
3. Download **google-services.json** and put it in the `app/` folder (next to `app/build.gradle.kts`).
   The build will fail without this file.
4. **Authentication › Sign-in method** › enable **Email/Password**.
5. **Firestore Database** › Create database (production mode) › **Rules** tab › paste:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

No SHA-1 key is needed (email/password login doesn't use it).

## Using it on the phone
1. Install, then tap **Create account**, set a PIN, and choose fingerprint and automatic backup.
2. Tap **Turn on** on the home screen and pick **AppForge Vault** as the autofill service.
3. **Chrome only:** Chrome › Settings › Autofill services › choose **Autofill using another service**, then restart Chrome.
4. Log in anywhere. Android asks "Save to AppForge Vault?". Tap Save.

## Forgot password? Three ways to unlock the backup
After "Forgot password?" and signing in with the new password, the **Unlock your backup** screen offers:
1. **Fingerprint or app PIN.** Works on a phone that still has the app and its passwords. The key stored on the phone re-locks the backup with the new password.
2. **Recovery Key.** Works on any phone. This is the 24-character code (`XXXX-XXXX-XXXX-XXXX-XXXX-XXXX`) shown after Create account. You can copy it or save it as a .txt file. You can make a new one in Settings › Recovery Key, which makes the old one stop working.
3. **Old password.**
If none of these work, "start fresh" deletes the old backup.
