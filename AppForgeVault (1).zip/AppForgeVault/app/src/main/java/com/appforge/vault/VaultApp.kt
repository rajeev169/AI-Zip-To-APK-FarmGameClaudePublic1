package com.appforge.vault

import android.app.Application
import com.appforge.vault.data.BackupManager
import com.appforge.vault.data.Prefs
import com.appforge.vault.data.VaultRepository

class VaultApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        VaultRepository.init(this)
        runCatching { BackupManager.applySchedule(this) }
    }
}
