package com.appforge.vault.autofill

import android.app.assist.AssistStructure
import android.content.Intent
import android.os.Bundle
import android.service.autofill.Dataset
import android.service.autofill.FillResponse
import android.view.WindowManager
import android.view.autofill.AutofillManager
import android.view.autofill.AutofillValue
import androidx.activity.compose.setContent
import androidx.core.content.IntentCompat
import androidx.fragment.app.FragmentActivity
import com.appforge.vault.data.VaultRepository
import com.appforge.vault.ui.screens.LockScreen
import com.appforge.vault.ui.theme.VaultTheme

/** Asks for fingerprint / PIN, then hands the matching logins back to Android to fill. */
class AutofillAuthActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            VaultTheme {
                LockScreen(
                    activity = this,
                    subtitle = "Unlock to fill your password",
                    onUnlocked = { finishWithLogins() },
                )
            }
        }
    }

    private fun finishWithLogins() {
        val structure = IntentCompat.getParcelableExtra(
            intent, AutofillManager.EXTRA_ASSIST_STRUCTURE, AssistStructure::class.java
        )
        if (structure == null) { setResult(RESULT_CANCELED); finish(); return }
        val f = FieldParser.parse(structure)
        val matches = if (FieldParser.isGoogle(f.webDomain, f.packageName))
            VaultRepository.findMatches("accounts.google.com", f.packageName)
        else VaultRepository.findMatches(f.webDomain, f.packageName)
        val response = FillResponse.Builder()
        var count = 0
        for (e in matches) {
            @Suppress("DEPRECATION")
            val ds = Dataset.Builder(
                VaultAutofillService.presentation(packageName, e.title, e.username.ifEmpty { "(no username)" })
            )
            var any = false
            if (e.username.isNotEmpty()) f.usernameIds.forEach {
                @Suppress("DEPRECATION") ds.setValue(it, AutofillValue.forText(e.username)); any = true
            }
            f.passwordIds.forEach {
                @Suppress("DEPRECATION") ds.setValue(it, AutofillValue.forText(e.password)); any = true
            }
            if (any) { response.addDataset(ds.build()); count++ }
        }
        if (count == 0) { setResult(RESULT_CANCELED); finish(); return }
        setResult(RESULT_OK, Intent().putExtra(AutofillManager.EXTRA_AUTHENTICATION_RESULT, response.build()))
        finish()
    }
}
