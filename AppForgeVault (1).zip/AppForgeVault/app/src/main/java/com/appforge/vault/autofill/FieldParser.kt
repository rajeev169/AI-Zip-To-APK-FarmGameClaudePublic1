package com.appforge.vault.autofill

import android.app.assist.AssistStructure
import android.text.InputType
import android.view.View
import android.view.autofill.AutofillId

/** Finds the username/email and password boxes on a login screen. */
class ParsedFields {
    val usernameIds = mutableListOf<AutofillId>()
    val passwordIds = mutableListOf<AutofillId>()
    var webDomain: String? = null
    var packageName: String = ""
    var usernameValue: String? = null
    var passwordValue: String? = null
    /** An email address shown as plain text on the screen (e.g. Google's password page). */
    var visibleEmail: String? = null
    /** Text of the browser's address bar (compatibility-mode browsers). */
    var urlBarText: String? = null
    val hasLoginFields get() = passwordIds.isNotEmpty() || usernameIds.isNotEmpty()
}

object FieldParser {
    private val passwordWords = listOf("password", "passwd", "pwd", "pass", "पासवर्ड")
    private val userWords = listOf("email", "e-mail", "user", "login", "account", "phone", "mobile", "identifier", "username")

    fun parse(structure: AssistStructure): ParsedFields {
        val f = ParsedFields()
        f.packageName = structure.activityComponent?.packageName.orEmpty()
        val textFields = mutableListOf<AssistStructure.ViewNode>()
        for (i in 0 until structure.windowNodeCount) {
            visit(structure.getWindowNodeAt(i).rootViewNode, f, textFields)
        }
        // Browsers in compatibility mode don't report the website, so read it from the address bar.
        if (f.webDomain == null && f.packageName in compatBrowsers) {
            f.webDomain = f.urlBarText?.let { hostFromUrlBar(it) }
        }
        // A password box with no obvious username box: use the text box right before it.
        if (f.usernameIds.isEmpty() && f.passwordIds.isNotEmpty()) {
            val firstPw = textFields.indexOfFirst { it.autofillId == f.passwordIds.first() }
            if (firstPw > 0) {
                val prev = textFields[firstPw - 1]
                prev.autofillId?.let { f.usernameIds += it; f.usernameValue = prev.textValue() }
            }
        }
        return f
    }

    private fun visit(node: AssistStructure.ViewNode, f: ParsedFields, textFields: MutableList<AssistStructure.ViewNode>) {
        node.webDomain?.takeIf { it.isNotBlank() }?.let { f.webDomain = it }
        if (f.urlBarText == null) {
            val idName = node.idEntry?.lowercase()
            if (idName != null && urlBarIds.any { idName.contains(it) }) {
                node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { f.urlBarText = it }
            }
        }
        if (f.visibleEmail == null) {
            val t = node.text?.toString()?.trim()
            if (t != null && t.length in 6..100 && EMAIL.matches(t)) f.visibleEmail = t
        }
        val id = node.autofillId
        if (id != null && node.autofillType == View.AUTOFILL_TYPE_TEXT && node.visibility == View.VISIBLE) {
            textFields += node
            when (classify(node)) {
                Kind.PASSWORD -> { f.passwordIds += id; node.textValue()?.let { if (it.isNotEmpty()) f.passwordValue = it } }
                Kind.USERNAME -> { f.usernameIds += id; node.textValue()?.let { if (it.isNotEmpty()) f.usernameValue = it } }
                Kind.OTHER -> {}
            }
        }
        for (i in 0 until node.childCount) visit(node.getChildAt(i), f, textFields)
    }

    private val EMAIL = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    /** Must match the compatibility-package list in res/xml/autofill_service.xml. */
    val compatBrowsers = setOf(
        "com.jio.web", "com.opera.browser", "com.opera.browser.beta", "com.opera.mini.native", "com.opera.gx",
        "com.UCMobile.intl", "com.uc.browser.en", "com.brave.browser", "com.duckduckgo.mobile.android",
        "com.vivaldi.browser", "com.kiwibrowser.browser", "com.mi.globalbrowser", "com.heytap.browser",
        "com.android.browser", "com.yandex.browser", "org.mozilla.focus",
    )

    private val urlBarIds = listOf(
        "url_bar", "url_field", "urlbar", "address_bar", "addressbar", "url_edit", "url_view",
        "location_bar", "omnibox", "search_box", "toolbar_url", "mozac_browser_toolbar_url_view", "url",
    )

    /**
     * "https://www.gmail.com/mail" → "gmail.com", "accounts.google.com" → "accounts.google.com".
     * Returns null for search words or anything that isn't a web address.
     */
    fun hostFromUrlBar(text: String): String? {
        var t = text.trim().lowercase()
        if (t.isEmpty() || t.contains(' ')) return null
        t = t.substringAfter("://").substringBefore('/').substringBefore('?').substringBefore('#').substringBefore(':')
        t = t.removePrefix("www.")
        val ok = Regex("^[a-z0-9-]+(\\.[a-z0-9-]+)+$").matches(t) && t.substringAfterLast('.').length >= 2 &&
            !t.substringAfterLast('.').all { it.isDigit() }
        return if (ok) t else null
    }

    /** Is this a Google sign-in (website or Google's own sign-in screens)? */
    fun isGoogle(webDomain: String?, packageName: String): Boolean =
        webDomain?.lowercase()?.let { it == "accounts.google.com" || it.endsWith(".accounts.google.com") } == true ||
            (webDomain == null && packageName == "com.google.android.gms")

    private enum class Kind { USERNAME, PASSWORD, OTHER }

    private fun classify(node: AssistStructure.ViewNode): Kind {
        node.autofillHints?.forEach { h ->
            val hint = h.lowercase()
            if (hint.contains("password") && !hint.contains("new")) return Kind.PASSWORD
            if (hint.contains("password")) return Kind.PASSWORD
            if (hint.contains("username") || hint.contains("email") || hint.contains("phone")) return Kind.USERNAME
        }
        node.htmlInfo?.attributes?.forEach { a ->
            if (a.first.equals("type", true)) {
                when (a.second?.lowercase()) {
                    "password" -> return Kind.PASSWORD
                    "email", "tel" -> return Kind.USERNAME
                }
            }
            if (a.first.equals("autocomplete", true)) {
                val v = a.second?.lowercase().orEmpty()
                if (v.contains("password")) return Kind.PASSWORD
                if (v.contains("username") || v.contains("email")) return Kind.USERNAME
            }
        }
        val type = node.inputType
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_CLASS_TEXT && (
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
        ) return Kind.PASSWORD
        if (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD) return Kind.PASSWORD
        if (cls == InputType.TYPE_CLASS_TEXT && (
                variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS)
        ) return Kind.USERNAME

        val text = listOfNotNull(node.idEntry, node.hint?.toString(), node.contentDescription?.toString())
            .joinToString(" ").lowercase()
        if (text.isNotEmpty()) {
            if (passwordWords.any { text.contains(it) }) return Kind.PASSWORD
            if (userWords.any { text.contains(it) }) return Kind.USERNAME
        }
        return Kind.OTHER
    }

    private fun AssistStructure.ViewNode.textValue(): String? =
        autofillValue?.takeIf { it.isText }?.textValue?.toString()
}
