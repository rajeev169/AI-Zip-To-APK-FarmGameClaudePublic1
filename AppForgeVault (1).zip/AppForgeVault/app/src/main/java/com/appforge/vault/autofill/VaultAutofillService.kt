package com.appforge.vault.autofill

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.SaveCallback
import android.service.autofill.SaveInfo
import android.service.autofill.SaveRequest
import android.widget.RemoteViews
import com.appforge.vault.R
import com.appforge.vault.data.Prefs
import com.appforge.vault.data.VaultRepository

/**
 * Android Autofill service:
 *  - When you log in anywhere, Android shows "Save to AppForge Vault?" and the login is stored.
 *  - Next time, the login box offers your saved account (after fingerprint / PIN).
 */
class VaultAutofillService : AutofillService() {

    override fun onFillRequest(request: FillRequest, cancellationSignal: CancellationSignal, callback: FillCallback) {
        try {
            val structure = request.fillContexts.last().structure
            val f = FieldParser.parse(structure)
            val browserWithoutAddress = f.packageName in FieldParser.compatBrowsers && f.webDomain == null
            if (!f.hasLoginFields || f.packageName == packageName || !VaultRepository.hasKey() || !Prefs.setupDone ||
                browserWithoutAddress
            ) {
                callback.onSuccess(null); return
            }
            val matches = if (FieldParser.isGoogle(f.webDomain, f.packageName))
                VaultRepository.findMatches("accounts.google.com", f.packageName)
            else VaultRepository.findMatches(f.webDomain, f.packageName)
            val builder = FillResponse.Builder()
            var hasContent = false

            if (matches.isNotEmpty()) {
                val ids = (f.usernameIds + f.passwordIds).toTypedArray()
                val intent = Intent(this, AutofillAuthActivity::class.java)
                val sender = PendingIntent.getActivity(
                    this, nextRequestCode(), intent,
                    PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_MUTABLE
                ).intentSender
                val label = if (matches.size == 1) "1 saved login" else "${matches.size} saved logins"
                @Suppress("DEPRECATION")
                builder.setAuthentication(ids, sender, presentation(this.packageName, "AppForge Vault", "Unlock to fill · $label"))
                hasContent = true
            }

            if (f.passwordIds.isEmpty() && f.usernameIds.isNotEmpty() && Prefs.autofillSaveEnabled &&
                Build.VERSION.SDK_INT >= 29
            ) {
                // Page 1 of a two-page login (email first, password next): keep the email
                // and ask to save only after the password page.
                val save = SaveInfo.Builder(SaveInfo.SAVE_DATA_TYPE_USERNAME, f.usernameIds.toTypedArray())
                    .setFlags(SaveInfo.FLAG_DELAY_SAVE)
                builder.setSaveInfo(save.build())
                hasContent = true
            } else if (f.passwordIds.isNotEmpty() && Prefs.autofillSaveEnabled) {
                var type = SaveInfo.SAVE_DATA_TYPE_PASSWORD
                if (f.usernameIds.isNotEmpty()) type = type or SaveInfo.SAVE_DATA_TYPE_USERNAME
                val save = SaveInfo.Builder(type, f.passwordIds.toTypedArray())
                if (f.usernameIds.isNotEmpty()) save.setOptionalIds(f.usernameIds.toTypedArray())
                builder.setSaveInfo(save.build())
                hasContent = true
            }

            callback.onSuccess(if (hasContent) builder.build() else null)
        } catch (e: Exception) {
            callback.onSuccess(null)
        }
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        try {
            var username: String? = null
            var password: String? = null
            var domain: String? = null
            var pkg = ""
            var shownEmail: String? = null
            // With a two-page login, fillContexts holds both pages: email page first, then password page.
            for (ctx in request.fillContexts) {
                val f = FieldParser.parse(ctx.structure)
                f.usernameValue?.takeIf { it.isNotBlank() }?.let { username = it }
                f.visibleEmail?.let { shownEmail = it }
                f.passwordValue?.let { password = it }
                f.webDomain?.let { domain = it }
                if (f.packageName.isNotEmpty()) pkg = f.packageName
            }
            val pw = password
            if (pw.isNullOrEmpty() || !VaultRepository.hasKey()) {
                callback.onFailure("Nothing to save"); return
            }
            if (pkg in FieldParser.compatBrowsers && domain == null) {
                callback.onFailure("Couldn't read the website address"); return
            }
            if (username.isNullOrBlank()) username = shownEmail
            val google = FieldParser.isGoogle(domain, pkg)
            val label = if (google) "Google account" else runCatching {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            }.getOrDefault(pkg)
            // Save Google sign-ins under accounts.google.com so they fill in Chrome and in apps.
            if (google) domain = "accounts.google.com"
            VaultRepository.saveFromAutofill(domain, pkg, label, username.orEmpty(), pw)
            callback.onSuccess()
        } catch (e: Exception) {
            callback.onFailure("Could not save: ${e.message}")
        }
    }

    companion object {
        private var requestCode = 1000
        @Synchronized fun nextRequestCode() = ++requestCode

        fun presentation(pkg: String, title: String, subtitle: String) =
            RemoteViews(pkg, R.layout.autofill_item).apply {
                setTextViewText(R.id.title, title)
                setTextViewText(R.id.subtitle, subtitle)
            }
    }
}
