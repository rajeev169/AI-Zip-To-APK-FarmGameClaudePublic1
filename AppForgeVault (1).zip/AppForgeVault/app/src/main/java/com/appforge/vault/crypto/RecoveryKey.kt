package com.appforge.vault.crypto

/**
 * Recovery Key: a one-time code like "K7QM-2XPA-9WTR-HC4N-B8ZD-F3JY" (120 bits of randomness).
 * It unlocks the backup on any phone when the account password is forgotten.
 * Letters that look alike (I, L, O, U) are not used; typing them is forgiven.
 */
object RecoveryKey {
    private const val ALPHABET = "ABCDEFGHJKMNPQRSTVWXYZ0123456789" // 32 symbols = 5 bits each
    private const val LENGTH = 24
    const val KDF_ITERATIONS = 20_000 // the code itself is long and random, so this can be lighter

    fun generate(): String {
        val bytes = Crypto.randomBytes(LENGTH)
        val raw = buildString { bytes.forEach { append(ALPHABET[(it.toInt() and 0xFF) % 32]) } }
        return format(raw)
    }

    /** Uppercases, removes spaces/dashes and fixes look-alike letters. Null if not a valid code. */
    fun normalize(input: String): String? {
        val s = input.uppercase()
            .filter { it.isLetterOrDigit() }
            .map { when (it) { 'O' -> '0'; 'I', 'L' -> '1'; 'U' -> 'V'; else -> it } }
            .joinToString("")
        return if (s.length == LENGTH && s.all { it in ALPHABET }) s else null
    }

    fun format(raw: String): String = raw.chunked(4).joinToString("-")

    /** Encrypts the vault key with the recovery code. Returns salt and wrapped key. */
    fun wrap(code: String, vaultKey: ByteArray): Pair<ByteArray, ByteArray> {
        val norm = normalize(code) ?: error("Invalid recovery key")
        val salt = Crypto.randomBytes(16)
        return salt to Crypto.encrypt(Crypto.deriveKey(norm, salt, KDF_ITERATIONS), vaultKey)
    }

    /** Throws GeneralSecurityException if the code is wrong. */
    fun unwrap(code: String, salt: ByteArray, wrapped: ByteArray, iterations: Int = KDF_ITERATIONS): ByteArray {
        val norm = normalize(code) ?: throw java.security.GeneralSecurityException("Invalid recovery key")
        return Crypto.decrypt(Crypto.deriveKey(norm, salt, iterations), wrapped)
    }
}
