package com.appforge.vault.data

import android.content.Context
import com.appforge.vault.crypto.Crypto
import com.appforge.vault.crypto.RecoveryKey
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.security.GeneralSecurityException

/**
 * Email + password accounts (Firebase Authentication — no Google sign-in).
 *
 * Firestore document users/{uid} holds only encrypted data:
 *   salt, wrappedKey (vault key encrypted with the account password),
 *   vault (encrypted backup), vaultUpdatedAt, count.
 */
object AuthManager {
    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    val user: FirebaseUser? get() = auth.currentUser
    val email: String get() = auth.currentUser?.email.orEmpty()

    fun userDoc(): DocumentReference =
        db.collection("users").document(user?.uid ?: error("Not signed in"))

    sealed class SignInResult {
        data class Ok(val restored: Int) : SignInResult()
        /** Backup was locked with a different (old) password, e.g. after "Forgot password". */
        data object NeedsOldPassword : SignInResult()
    }

    /** Returns the new Recovery Key, which must be shown to the user once. */
    suspend fun createAccount(email: String, password: String): String {
        auth.createUserWithEmailAndPassword(email.trim(), password).await()
        clearIfOtherUsersData()
        VaultRepository.clearLocal() // a brand-new account starts with an empty vault
        val raw = Crypto.randomBytes(32)
        uploadWrappedKey(raw, password)
        saveKey(raw)
        VaultRepository.ensureLoaded()
        return uploadRecoveryKey(raw)
    }

    suspend fun signIn(email: String, password: String): SignInResult {
        auth.signInWithEmailAndPassword(email.trim(), password).await()
        clearIfOtherUsersData()
        return unlockCloudKey(password)
    }

    private suspend fun unlockCloudKey(password: String): SignInResult {
        val doc = userDoc().get().await()
        val salt = doc.getString("salt")
        val wrapped = doc.getString("wrappedKey")
        if (!doc.exists() || salt == null || wrapped == null) {
            // Keep this phone's key (and passwords) if they already belong to this account.
            val local = if (Prefs.keyOwnerUid == user?.uid) VaultRepository.rawKey() else null
            if (local == null) VaultRepository.clearLocal()
            val raw = local ?: Crypto.randomBytes(32)
            uploadWrappedKey(raw, password)
            saveKey(raw)
            VaultRepository.ensureLoaded()
            return SignInResult.Ok(0)
        }
        val iter = doc.getLong("kdfIter")?.toInt() ?: Crypto.KDF_ITERATIONS
        val raw = try {
            Crypto.decrypt(derive(password, Crypto.unb64(salt), iter), Crypto.unb64(wrapped))
        } catch (e: GeneralSecurityException) {
            return SignInResult.NeedsOldPassword
        }
        val samePhoneKey = VaultRepository.hasKey() && VaultRepository.rawKey()?.contentEquals(raw) == true
        saveKey(raw)
        val restored = doc.getString("vault")?.let { blob ->
            if (samePhoneKey) VaultRepository.merge(VaultRepository.entriesFromBlob(raw, Crypto.unb64(blob)))
            else VaultRepository.replaceFromBlob(Crypto.unb64(blob))
        } ?: run { VaultRepository.ensureLoaded(); 0 }
        Prefs.autoBackup = true // a backup exists, so this account uses backup
        return SignInResult.Ok(restored)
    }

    /** After a password reset: open the old backup with the old password, then re-lock it with the new one. */
    suspend fun recoverWithOldPassword(oldPassword: String, currentPassword: String): Int {
        val doc = userDoc().get().await()
        val salt = Crypto.unb64(doc.getString("salt")!!)
        val iter = doc.getLong("kdfIter")?.toInt() ?: Crypto.KDF_ITERATIONS
        val raw = Crypto.decrypt(derive(oldPassword, salt, iter), Crypto.unb64(doc.getString("wrappedKey")!!))
        uploadWrappedKey(raw, currentPassword)
        val samePhoneKey = VaultRepository.hasKey() && VaultRepository.rawKey()?.contentEquals(raw) == true
        if (!samePhoneKey) VaultRepository.clearLocal()
        saveKey(raw)
        Prefs.autoBackup = true
        return doc.getString("vault")?.let { blob ->
            if (samePhoneKey) VaultRepository.merge(VaultRepository.entriesFromBlob(raw, Crypto.unb64(blob)))
            else VaultRepository.replaceFromBlob(Crypto.unb64(blob))
        } ?: run { VaultRepository.ensureLoaded(); 0 }
    }

    /**
     * True when this phone still holds the vault key of the signed-in account, so the
     * backup can be unlocked with fingerprint / app PIN instead of the old password.
     */
    fun canUnlockWithThisPhone(): Boolean =
        user != null && VaultRepository.hasKey() && Prefs.pinSet && Prefs.keyOwnerUid == user?.uid

    /**
     * After a password reset: the user proved it's them with fingerprint / PIN, so use the
     * vault key stored on this phone and re-lock the backup with the new password.
     * Returns how many passwords from the backup were added to this phone.
     */
    suspend fun recoverWithThisPhone(currentPassword: String): Int {
        val raw = VaultRepository.rawKey() ?: error("No key on this phone")
        val doc = userDoc().get().await()
        val cloudVault = doc.getString("vault")?.let { Crypto.unb64(it) }
        // Make sure this phone's key really opens this account's backup before re-locking it.
        val cloudEntries = cloudVault?.let {
            try { withContext(Dispatchers.Default) { VaultRepository.entriesFromBlob(raw, it) } }
            catch (e: GeneralSecurityException) { throw IllegalStateException("This phone's key doesn't match your backup.") }
        }
        uploadWrappedKey(raw, currentPassword)
        VaultRepository.ensureLoaded()
        val added = cloudEntries?.let { VaultRepository.merge(it) } ?: 0
        if (Prefs.autoBackup) runCatching { BackupManager.backupNow() }
        return added
    }

    /** Makes a new Recovery Key (the old one stops working). Returns the code to show. */
    suspend fun createRecoveryKey(): String {
        val raw = VaultRepository.rawKey() ?: error("Vault locked")
        return uploadRecoveryKey(raw)
    }

    private suspend fun uploadRecoveryKey(raw: ByteArray): String {
        val code = RecoveryKey.generate()
        val (salt, wrapped) = withContext(Dispatchers.Default) { RecoveryKey.wrap(code, raw) }
        userDoc().set(
            mapOf(
                "recoverySalt" to Crypto.b64(salt),
                "recoveryWrappedKey" to Crypto.b64(wrapped),
                "recoveryIter" to RecoveryKey.KDF_ITERATIONS,
                "recoveryCreatedAt" to System.currentTimeMillis(),
            ),
            SetOptions.merge()
        ).await()
        Prefs.recoveryKeyCreatedAt = System.currentTimeMillis()
        return code
    }

    suspend fun hasCloudRecoveryKey(): Boolean =
        runCatching { userDoc().get().await().getString("recoveryWrappedKey") != null }.getOrDefault(false)

    /** Forgot password on any phone: open the backup with the Recovery Key, then re-lock it with the new password. */
    suspend fun recoverWithRecoveryKey(code: String, currentPassword: String): Int {
        val doc = userDoc().get().await()
        val salt = doc.getString("recoverySalt") ?: error("No recovery key was set up for this account.")
        val wrapped = doc.getString("recoveryWrappedKey")!!
        val iter = doc.getLong("recoveryIter")?.toInt() ?: RecoveryKey.KDF_ITERATIONS
        val raw = withContext(Dispatchers.Default) { RecoveryKey.unwrap(code, Crypto.unb64(salt), Crypto.unb64(wrapped), iter) }
        uploadWrappedKey(raw, currentPassword)
        val samePhoneKey = VaultRepository.hasKey() && VaultRepository.rawKey()?.contentEquals(raw) == true
        if (!samePhoneKey) VaultRepository.clearLocal()
        saveKey(raw)
        Prefs.autoBackup = true
        return doc.getString("vault")?.let { blob ->
            if (samePhoneKey) VaultRepository.merge(VaultRepository.entriesFromBlob(raw, Crypto.unb64(blob)))
            else VaultRepository.replaceFromBlob(Crypto.unb64(blob))
        } ?: run { VaultRepository.ensureLoaded(); 0 }
    }

    /** Throw away the old (unreadable) backup and start with an empty vault. */
    suspend fun startFresh(currentPassword: String): String {
        val raw = Crypto.randomBytes(32)
        uploadWrappedKey(raw, currentPassword)
        userDoc().update(mapOf("vault" to FieldValue.delete(), "count" to 0)).await()
        VaultRepository.clearLocal()
        saveKey(raw)
        VaultRepository.ensureLoaded()
        return uploadRecoveryKey(raw) // old recovery key no longer matches, so make a new one
    }

    suspend fun sendPasswordReset(email: String) {
        auth.sendPasswordResetEmail(email.trim()).await()
    }

    suspend fun changePassword(oldPassword: String, newPassword: String) {
        val u = user ?: error("Not signed in")
        u.reauthenticate(EmailAuthProvider.getCredential(u.email!!, oldPassword)).await()
        u.updatePassword(newPassword).await()
        val raw = VaultRepository.rawKey() ?: error("Vault locked")
        uploadWrappedKey(raw, newPassword)
    }

    suspend fun deleteAccount(context: Context, password: String) {
        val u = user ?: error("Not signed in")
        u.reauthenticate(EmailAuthProvider.getCredential(u.email!!, password)).await()
        userDoc().delete().await()
        u.delete().await()
        clearLocal(context)
    }

    /** Sign out of the account only; passwords and the key stay on this phone. */
    fun signOutKeepLocal() {
        auth.signOut()
    }

    /** Records which account the key on this phone belongs to (also fixes older installs). */
    fun rememberKeyOwner() {
        val uid = user?.uid ?: return
        if (VaultRepository.hasKey() && Prefs.keyOwnerUid == null) Prefs.keyOwnerUid = uid
    }

    private fun saveKey(raw: ByteArray) {
        VaultRepository.setKey(raw)
        Prefs.keyOwnerUid = user?.uid
    }

    /** A different account signs in on this phone: remove the previous account's passwords. */
    private fun clearIfOtherUsersData() {
        val owner = Prefs.keyOwnerUid
        if (VaultRepository.hasKey() && owner != null && owner != user?.uid) {
            VaultRepository.clearLocal()
            Prefs.clearAll()
        }
    }

    fun signOut(context: Context) {
        auth.signOut()
        clearLocal(context)
    }

    private fun clearLocal(context: Context) {
        BackupManager.cancelAll(context)
        VaultRepository.clearLocal()
        Prefs.clearAll()
    }

    private suspend fun uploadWrappedKey(raw: ByteArray, password: String) {
        val salt = Crypto.randomBytes(16)
        val wrapped = Crypto.encrypt(derive(password, salt), raw)
        userDoc().set(
            mapOf(
                "salt" to Crypto.b64(salt),
                "wrappedKey" to Crypto.b64(wrapped),
                "kdfIter" to Crypto.KDF_ITERATIONS,
                "keyUpdatedAt" to System.currentTimeMillis(),
            ),
            SetOptions.merge()
        ).await()
    }

    /** Key derivation is slow on purpose; keep it off the UI thread. */
    private suspend fun derive(password: String, salt: ByteArray, iterations: Int = Crypto.KDF_ITERATIONS) =
        withContext(Dispatchers.Default) { Crypto.deriveKey(password, salt, iterations) }

    fun friendlyError(e: Throwable): String {
        val code = (e as? FirebaseAuthException)?.errorCode
        return when (code) {
            "ERROR_INVALID_EMAIL" -> "That email address doesn't look right."
            "ERROR_EMAIL_ALREADY_IN_USE" -> "An account with this email already exists. Sign in instead."
            "ERROR_WEAK_PASSWORD" -> "Password is too weak. Use at least 8 characters."
            "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL" -> "Email or password is incorrect."
            "ERROR_USER_NOT_FOUND" -> "No account found with this email."
            "ERROR_TOO_MANY_REQUESTS" -> "Too many attempts. Please wait and try again."
            "ERROR_USER_DISABLED" -> "This account has been disabled."
            "ERROR_REQUIRES_RECENT_LOGIN" -> "Please sign in again and retry."
            else -> when {
                e is GeneralSecurityException -> "That password or key could not unlock the backup."
                e is IllegalStateException && e.message != null -> e.message!!
                e.message?.contains("network", true) == true -> "No internet connection."
                else -> e.message ?: "Something went wrong."
            }
        }
    }
}
