package com.appforge.vault.data

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.appforge.vault.crypto.Crypto
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

/** Encrypted cloud backup to Firestore. Data is encrypted before it leaves the phone. */
object BackupManager {
    private const val ONE_TIME = "vault_backup_now"
    private const val PERIODIC = "vault_backup_daily"

    private val networkOnly = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    /** Called whenever a password is added, edited or deleted. */
    fun onVaultChanged(context: Context) {
        if (!Prefs.autoBackup || AuthManager.user == null) return
        val req = OneTimeWorkRequestBuilder<BackupWorker>()
            .setConstraints(networkOnly)
            .setInitialDelay(3, TimeUnit.SECONDS)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(ONE_TIME, ExistingWorkPolicy.REPLACE, req)
    }

    /** Daily safety backup while automatic backup is on. */
    fun applySchedule(context: Context) {
        val wm = WorkManager.getInstance(context)
        if (Prefs.autoBackup && AuthManager.user != null) {
            val req = PeriodicWorkRequestBuilder<BackupWorker>(24, TimeUnit.HOURS)
                .setConstraints(networkOnly).build()
            wm.enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req)
        } else {
            wm.cancelUniqueWork(PERIODIC)
        }
    }

    fun cancelAll(context: Context) {
        val wm = WorkManager.getInstance(context)
        wm.cancelUniqueWork(ONE_TIME); wm.cancelUniqueWork(PERIODIC)
    }

    suspend fun backupNow() {
        if (AuthManager.user == null) error("Not signed in")
        val blob = VaultRepository.encryptedBlob()
        val now = System.currentTimeMillis()
        AuthManager.userDoc().set(
            mapOf(
                "vault" to Crypto.b64(blob),
                "vaultUpdatedAt" to now,
                "count" to VaultRepository.entries.value.size,
            ),
            SetOptions.merge()
        ).await()
        Prefs.lastBackupAt = now
    }

    /** Returns number of restored entries, or -1 if there is no backup yet. */
    suspend fun restore(): Int {
        val doc = AuthManager.userDoc().get().await()
        val vault = doc.getString("vault") ?: return -1
        return VaultRepository.replaceFromBlob(Crypto.unb64(vault))
    }

    suspend fun cloudBackupTime(): Long? =
        AuthManager.userDoc().get().await().getLong("vaultUpdatedAt")
}

class BackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        if (!Prefs.autoBackup || AuthManager.user == null || !VaultRepository.hasKey()) Result.success()
        else { BackupManager.backupNow(); Result.success() }
    } catch (e: Exception) {
        if (runAttemptCount < 5) Result.retry() else Result.failure()
    }
}
