package com.appforge.vault.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Entry(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val username: String,
    val password: String,
    /** Website ("https://mail.google.com") or app ("android://com.example.app"). */
    val url: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("title", title).put("username", username)
        .put("password", password).put("url", url).put("notes", notes)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    /** Host for websites, package for apps, lower-cased. */
    val matchKey: String get() = Matching.keyOf(url)

    companion object {
        fun fromJson(o: JSONObject) = Entry(
            id = o.optString("id", UUID.randomUUID().toString()),
            title = o.optString("title"),
            username = o.optString("username"),
            password = o.optString("password"),
            url = o.optString("url"),
            notes = o.optString("notes"),
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
        )

        fun listToJson(list: List<Entry>): String =
            JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()

        fun listFromJson(text: String): List<Entry> {
            val arr = JSONArray(text)
            return (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }
        }
    }
}

object Matching {
    /** Normalises a saved URL / app link into a comparable key. */
    fun keyOf(url: String): String {
        var u = url.trim().lowercase()
        if (u.isEmpty()) return ""
        if (u.startsWith("android://")) {
            // Google Password Manager format: android://<hash>@<package>/
            u = u.removePrefix("android://").substringAfter('@').trimEnd('/')
            return u
        }
        u = u.substringAfter("://")
        u = u.substringBefore('/').substringBefore('?').substringBefore(':')
        return u.removePrefix("www.").removePrefix("m.")
    }

    fun hostMatches(saved: String, requested: String): Boolean {
        if (saved.isEmpty() || requested.isEmpty()) return false
        val r = requested.lowercase().removePrefix("www.").removePrefix("m.")
        return saved == r || r.endsWith(".$saved") || saved.endsWith(".$r")
    }
}
