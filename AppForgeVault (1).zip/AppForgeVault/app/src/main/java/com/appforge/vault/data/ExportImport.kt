package com.appforge.vault.data

import com.appforge.vault.crypto.Crypto
import org.json.JSONObject

/**
 * Export: an encrypted .json file protected by a password the user chooses.
 * Import: that encrypted file, or a CSV from Google Password Manager / Chrome / Bitwarden etc.
 */
object ExportImport {
    private const val FORMAT = "appforge-vault-export"

    fun export(entries: List<Entry>, password: String): String {
        val salt = Crypto.randomBytes(16)
        val data = Crypto.encrypt(
            Crypto.deriveKey(password, salt),
            Entry.listToJson(entries).toByteArray(Charsets.UTF_8)
        )
        return JSONObject()
            .put("format", FORMAT).put("version", 1)
            .put("kdfIter", Crypto.KDF_ITERATIONS)
            .put("salt", Crypto.b64(salt)).put("data", Crypto.b64(data))
            .put("count", entries.size)
            .toString(2)
    }

    fun isEncryptedExport(text: String): Boolean =
        text.trimStart().startsWith("{") && runCatching { JSONObject(text).optString("format") == FORMAT }.getOrDefault(false)

    /** Throws GeneralSecurityException if the password is wrong. */
    fun decryptExport(text: String, password: String): List<Entry> {
        val o = JSONObject(text)
        val key = Crypto.deriveKey(password, Crypto.unb64(o.getString("salt")), o.optInt("kdfIter", Crypto.KDF_ITERATIONS))
        val json = String(Crypto.decrypt(key, Crypto.unb64(o.getString("data"))), Charsets.UTF_8)
        return Entry.listFromJson(json)
    }

    fun parseCsv(text: String): List<Entry> {
        val rows = csvRows(text.removePrefix("﻿")).filter { r -> r.any { it.isNotBlank() } }
        if (rows.size < 2) return emptyList()
        val header = rows.first().map { it.trim().lowercase() }
        fun col(vararg names: String) = names.firstNotNullOfOrNull { n -> header.indexOf(n).takeIf { it >= 0 } }
        val iTitle = col("name", "title", "account")
        val iUrl = col("url", "login_uri", "website", "origin_url")
        val iUser = col("username", "login_username", "login", "email", "user")
        val iPass = col("password", "login_password", "pass") ?: return emptyList()
        val iNote = col("note", "notes", "extra", "comment")
        return rows.drop(1).mapNotNull { r ->
            fun at(i: Int?) = i?.let { r.getOrNull(it) }?.trim().orEmpty()
            val pw = at(iPass)
            if (pw.isEmpty()) return@mapNotNull null
            val url = at(iUrl)
            val title = at(iTitle).ifEmpty { Matching.keyOf(url).ifEmpty { "Imported login" } }
            Entry(title = title, username = at(iUser), password = pw, url = url, notes = at(iNote))
        }
    }

    private fun csvRows(text: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val cell = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') { cell.append('"'); i++ } else inQuotes = false
                } else cell.append(c)
            } else when (c) {
                '"' -> inQuotes = true
                ',' -> { row.add(cell.toString()); cell.clear() }
                '\r' -> {}
                '\n' -> { row.add(cell.toString()); cell.clear(); rows.add(row); row = mutableListOf() }
                else -> cell.append(c)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row.add(cell.toString()); rows.add(row) }
        return rows
    }
}
