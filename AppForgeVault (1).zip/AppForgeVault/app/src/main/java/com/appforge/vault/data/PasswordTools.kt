package com.appforge.vault.data

import java.security.SecureRandom

object PasswordTools {
    private const val UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    private const val LOWER = "abcdefghijkmnopqrstuvwxyz"
    private const val DIGITS = "23456789"
    private const val SYMBOLS = "!@#\$%^&*()-_=+[]{};:,.?"
    private val rnd = SecureRandom()

    fun generate(
        length: Int = 16,
        upper: Boolean = true,
        lower: Boolean = true,
        digits: Boolean = true,
        symbols: Boolean = true,
    ): String {
        val sets = buildList {
            if (upper) add(UPPER); if (lower) add(LOWER)
            if (digits) add(DIGITS); if (symbols) add(SYMBOLS)
        }.ifEmpty { listOf(LOWER) }
        val all = sets.joinToString("")
        val chars = mutableListOf<Char>()
        sets.forEach { chars += it[rnd.nextInt(it.length)] }          // at least one of each kind
        while (chars.size < length) chars += all[rnd.nextInt(all.length)]
        for (i in chars.indices.reversed()) {                          // shuffle
            val j = rnd.nextInt(i + 1); val t = chars[i]; chars[i] = chars[j]; chars[j] = t
        }
        return chars.take(length).joinToString("")
    }

    private val common = setOf(
        "password", "123456", "12345678", "123456789", "qwerty", "abc123", "111111",
        "password1", "iloveyou", "admin", "welcome", "000000", "1234567890", "india123"
    )

    enum class Strength(val label: String, val score: Int) {
        VERY_WEAK("Very weak", 0), WEAK("Weak", 1), FAIR("Fair", 2), GOOD("Good", 3), STRONG("Strong", 4)
    }

    fun strength(pw: String): Strength {
        if (pw.isEmpty() || pw.lowercase() in common) return Strength.VERY_WEAK
        var score = 0
        if (pw.length >= 8) score++
        if (pw.length >= 12) score++
        if (pw.length >= 16) score++
        val kinds = listOf(
            pw.any { it.isUpperCase() }, pw.any { it.isLowerCase() },
            pw.any { it.isDigit() }, pw.any { !it.isLetterOrDigit() }
        ).count { it }
        if (kinds >= 3) score++
        if (kinds == 4) score++
        if (pw.toSet().size <= 3) score = 0
        if (pw.length < 8) score = score.coerceAtMost(1)
        return when {
            score <= 0 -> Strength.VERY_WEAK
            score == 1 -> Strength.WEAK
            score == 2 -> Strength.FAIR
            score == 3 -> Strength.GOOD
            else -> Strength.STRONG
        }
    }
}
