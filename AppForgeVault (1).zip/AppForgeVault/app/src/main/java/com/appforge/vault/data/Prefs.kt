package com.appforge.vault.data

import android.content.Context
import android.content.SharedPreferences
import com.appforge.vault.crypto.Crypto
import java.security.MessageDigest

/** App settings. Nothing in here is a readable password. */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        sp = context.getSharedPreferences("vault_settings", Context.MODE_PRIVATE)
    }

    /** Vault key, encrypted by the phone's Keystore key. */
    var wrappedLocalKey: String?
        get() = sp.getString("wrapped_local_key", null)
        set(v) = sp.edit().putString("wrapped_local_key", v).apply()

    /** Firebase user id the vault key on this phone belongs to. */
    var keyOwnerUid: String?
        get() = sp.getString("key_owner_uid", null)
        set(v) = sp.edit().putString("key_owner_uid", v).apply()

    /** When the current Recovery Key was made (0 = none yet). */
    var recoveryKeyCreatedAt: Long
        get() = sp.getLong("recovery_created", 0L)
        set(v) = sp.edit().putLong("recovery_created", v).apply()

    var setupDone: Boolean
        get() = sp.getBoolean("setup_done", false)
        set(v) = sp.edit().putBoolean("setup_done", v).apply()

    var autoBackup: Boolean
        get() = sp.getBoolean("auto_backup", false)
        set(v) = sp.edit().putBoolean("auto_backup", v).apply()

    var lastBackupAt: Long
        get() = sp.getLong("last_backup_at", 0L)
        set(v) = sp.edit().putLong("last_backup_at", v).apply()

    var biometricEnabled: Boolean
        get() = sp.getBoolean("biometric", false)
        set(v) = sp.edit().putBoolean("biometric", v).apply()

    /** Auto-lock timeout in seconds (0 = immediately). */
    var lockTimeoutSec: Int
        get() = sp.getInt("lock_timeout", 30)
        set(v) = sp.edit().putInt("lock_timeout", v).apply()

    /** Seconds after which copied passwords are cleared (0 = never). */
    var clipboardClearSec: Int
        get() = sp.getInt("clip_clear", 30)
        set(v) = sp.edit().putInt("clip_clear", v).apply()

    var blockScreenshots: Boolean
        get() = sp.getBoolean("block_screenshots", true)
        set(v) = sp.edit().putBoolean("block_screenshots", v).apply()

    /** 0 = system, 1 = light, 2 = dark */
    var themeMode: Int
        get() = sp.getInt("theme_mode", 0)
        set(v) = sp.edit().putInt("theme_mode", v).apply()

    var autofillSaveEnabled: Boolean
        get() = sp.getBoolean("autofill_save", true)
        set(v) = sp.edit().putBoolean("autofill_save", v).apply()

    // ---------- PIN ----------
    val pinSet: Boolean get() = sp.getString("pin_hash", null) != null

    fun setPin(pin: String) {
        val salt = Crypto.randomBytes(16)
        sp.edit()
            .putString("pin_salt", Crypto.b64(salt))
            .putString("pin_hash", hashPin(pin, salt))
            .putInt("pin_fails", 0)
            .putLong("pin_locked_until", 0)
            .apply()
    }

    /** Seconds the user must still wait after too many wrong PINs. */
    fun pinWaitSeconds(): Int {
        val until = sp.getLong("pin_locked_until", 0)
        val left = until - System.currentTimeMillis()
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    fun verifyPin(pin: String): Boolean {
        if (pinWaitSeconds() > 0) return false
        val salt = sp.getString("pin_salt", null)?.let { Crypto.unb64(it) } ?: return false
        val expected = sp.getString("pin_hash", null) ?: return false
        val ok = MessageDigest.isEqual(hashPin(pin, salt).toByteArray(), expected.toByteArray())
        if (ok) {
            sp.edit().putInt("pin_fails", 0).apply()
        } else {
            val fails = sp.getInt("pin_fails", 0) + 1
            val e = sp.edit().putInt("pin_fails", fails)
            if (fails >= 5) {
                // 30s, 60s, 120s ... up to 15 minutes
                val wait = (30_000L shl (fails - 5).coerceAtMost(5)).coerceAtMost(900_000L)
                e.putLong("pin_locked_until", System.currentTimeMillis() + wait)
            }
            e.apply()
        }
        return ok
    }

    private fun hashPin(pin: String, salt: ByteArray): String =
        Crypto.b64(Crypto.deriveKey(pin, salt, 40_000).encoded)

    fun clearAll() {
        sp.edit().clear().apply()
    }
}
