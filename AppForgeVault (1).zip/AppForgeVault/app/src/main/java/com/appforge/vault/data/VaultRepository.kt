package com.appforge.vault.data

import android.content.Context
import com.appforge.vault.crypto.Crypto
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import javax.crypto.SecretKey

/** Encrypted on-device store of all saved logins. */
object VaultRepository {
    private lateinit var appContext: Context
    private val _entries = MutableStateFlow<List<Entry>>(emptyList())
    val entries: StateFlow<List<Entry>> = _entries.asStateFlow()

    private var vaultKey: SecretKey? = null
    private var loaded = false

    private val file: File get() = File(appContext.filesDir, "vault.bin")

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun hasKey(): Boolean = Prefs.wrappedLocalKey != null

    fun setKey(raw: ByteArray) {
        Prefs.wrappedLocalKey = Crypto.b64(Crypto.encrypt(Crypto.deviceKey(), raw))
        vaultKey = Crypto.aesKey(raw)
    }

    @Synchronized
    private fun key(): SecretKey? {
        vaultKey?.let { return it }
        val wrapped = Prefs.wrappedLocalKey ?: return null
        val raw = Crypto.decrypt(Crypto.deviceKey(), Crypto.unb64(wrapped))
        return Crypto.aesKey(raw).also { vaultKey = it }
    }

    fun rawKey(): ByteArray? = key()?.encoded

    @Synchronized
    fun ensureLoaded() {
        if (loaded) return
        val k = key() ?: return
        _entries.value = if (file.exists()) {
            sort(Entry.listFromJson(String(Crypto.decrypt(k, file.readBytes()), Charsets.UTF_8)))
        } else emptyList()
        loaded = true
    }

    /** Encrypted vault bytes, exactly as stored (used for cloud backup). */
    @Synchronized
    fun encryptedBlob(): ByteArray {
        ensureLoaded()
        if (!file.exists()) writeFile(_entries.value)
        return file.readBytes()
    }

    /** Replaces local data with a backup blob. Returns number of entries. */
    @Synchronized
    fun replaceFromBlob(blob: ByteArray): Int {
        val k = key() ?: error("No vault key")
        val list = Entry.listFromJson(String(Crypto.decrypt(k, blob), Charsets.UTF_8))
        writeFile(list)
        _entries.value = sort(list)
        loaded = true
        return list.size
    }

    /** Reads a backup blob with a given raw key without changing anything. */
    fun entriesFromBlob(raw: ByteArray, blob: ByteArray): List<Entry> =
        Entry.listFromJson(String(Crypto.decrypt(Crypto.aesKey(raw), blob), Charsets.UTF_8))

    fun get(id: String): Entry? = _entries.value.firstOrNull { it.id == id }

    fun upsert(entry: Entry) = mutate { list ->
        val i = list.indexOfFirst { it.id == entry.id }
        val e = entry.copy(updatedAt = System.currentTimeMillis())
        if (i >= 0) list.toMutableList().apply { set(i, e) } else list + e
    }

    fun delete(id: String) = mutate { list -> list.filterNot { it.id == id } }

    /** Called by the autofill service when Android asks to save a login. */
    fun saveFromAutofill(webDomain: String?, packageName: String, appLabel: String, username: String, password: String) {
        val url = if (!webDomain.isNullOrBlank()) "https://$webDomain" else "android://$packageName"
        val key = Matching.keyOf(url)
        mutate { list ->
            val i = list.indexOfFirst { it.matchKey == key && it.username.equals(username, ignoreCase = true) }
            if (i >= 0) {
                list.toMutableList().apply {
                    set(i, list[i].copy(password = password, updatedAt = System.currentTimeMillis()))
                }
            } else {
                val title = when {
                    webDomain == "accounts.google.com" -> "Google account"
                    !webDomain.isNullOrBlank() -> webDomain.removePrefix("www.")
                    else -> appLabel
                }
                list + Entry(title = title, username = username, password = password, url = url)
            }
        }
    }

    /** Adds entries that are not already saved. Returns how many were added. */
    fun merge(incoming: List<Entry>): Int {
        var added = 0
        mutate { list ->
            val out = list.toMutableList()
            for (e in incoming) {
                val dup = out.any {
                    it.matchKey == e.matchKey && it.username == e.username && it.password == e.password
                }
                if (!dup) {
                    out += e.copy(id = java.util.UUID.randomUUID().toString()); added++
                }
            }
            out
        }
        return added
    }

    fun findMatches(webDomain: String?, packageName: String): List<Entry> {
        ensureLoaded()
        return _entries.value.filter { e ->
            val k = e.matchKey
            if (!webDomain.isNullOrBlank()) Matching.hostMatches(k, webDomain)
            else k == packageName.lowercase()
        }
    }

    @Synchronized
    private fun mutate(block: (List<Entry>) -> List<Entry>) {
        ensureLoaded()
        val newList = block(_entries.value)
        writeFile(newList)
        _entries.value = sort(newList)
        BackupManager.onVaultChanged(appContext)
    }

    private fun writeFile(list: List<Entry>) {
        val k = key() ?: error("No vault key")
        val tmp = File(appContext.filesDir, "vault.tmp")
        tmp.writeBytes(Crypto.encrypt(k, Entry.listToJson(list).toByteArray(Charsets.UTF_8)))
        if (!tmp.renameTo(file)) {
            file.delete(); tmp.renameTo(file)
        }
    }

    private fun sort(list: List<Entry>) = list.sortedBy { it.title.lowercase() }

    @Synchronized
    fun clearLocal() {
        file.delete()
        vaultKey = null
        loaded = false
        _entries.value = emptyList()
    }
}
