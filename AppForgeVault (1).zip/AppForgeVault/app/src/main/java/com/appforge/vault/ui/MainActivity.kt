@file:OptIn(ExperimentalMaterial3Api::class)

package com.appforge.vault.ui

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.appforge.vault.data.AuthManager
import com.appforge.vault.data.Prefs
import com.appforge.vault.data.VaultRepository
import com.appforge.vault.ui.screens.AboutScreen
import com.appforge.vault.ui.screens.CreateAccountScreen
import com.appforge.vault.ui.screens.EditEntryScreen
import com.appforge.vault.ui.screens.EntryDetailScreen
import com.appforge.vault.ui.screens.GeneratorScreen
import com.appforge.vault.ui.screens.HomeScreen
import com.appforge.vault.ui.screens.LockScreen
import com.appforge.vault.ui.screens.RecoverBackupScreen
import com.appforge.vault.ui.screens.RecoveryKeyScreen
import com.appforge.vault.ui.screens.SecurityScreen
import com.appforge.vault.ui.screens.SetupScreen
import com.appforge.vault.ui.screens.SettingsScreen
import com.appforge.vault.ui.screens.SignInScreen
import com.appforge.vault.ui.theme.VaultTheme
import com.appforge.vault.util.AppLock
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        applyScreenshotSetting()
        setContent { VaultTheme { AppRoot(this) } }
    }

    fun applyScreenshotSetting() {
        if (Prefs.blockScreenshots) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    override fun onStart() { super.onStart(); AppLock.onStart() }
    override fun onStop() { super.onStop(); AppLock.onStop() }
}

private sealed class AuthStep {
    data object SignIn : AuthStep()
    data object Create : AuthStep()
    data class Recover(val password: String) : AuthStep()
}

@Composable
private fun AppRoot(activity: MainActivity) {
    var refresh by remember { mutableIntStateOf(0) }
    var authStep by remember { mutableStateOf<AuthStep>(AuthStep.SignIn) }
    var newRecoveryKey by remember { mutableStateOf<String?>(null) }
    val locked by AppLock.locked
    refresh.let { } // re-check sign-in state when this changes

    val signedIn = AuthManager.user != null && VaultRepository.hasKey()
    val onAuthDone: () -> Unit = { AppLock.locked.value = false; refresh++ }

    when {
        !signedIn -> when (val s = authStep) {
            AuthStep.SignIn -> SignInScreen(
                onDone = onAuthDone,
                onCreateAccount = { authStep = AuthStep.Create },
                onNeedsOldPassword = { authStep = AuthStep.Recover(it) }
            )
            AuthStep.Create -> CreateAccountScreen(
                onDone = { code -> newRecoveryKey = code; onAuthDone() },
                onBack = { authStep = AuthStep.SignIn }
            )
            is AuthStep.Recover -> RecoverBackupScreen(
                activity = activity,
                currentPassword = s.password,
                onDone = { authStep = AuthStep.SignIn; onAuthDone() },
                onNewRecoveryKey = { code -> newRecoveryKey = code; authStep = AuthStep.SignIn; onAuthDone() },
                // keep this phone's passwords and key, so fingerprint unlock still works next time
                onCancel = { AuthManager.signOutKeepLocal(); authStep = AuthStep.SignIn; refresh++ }
            )
        }
        newRecoveryKey != null -> RecoveryKeyScreen(newRecoveryKey!!, onDone = { newRecoveryKey = null })
        !Prefs.setupDone || !Prefs.pinSet -> SetupScreen(onDone = { AppLock.locked.value = false; refresh++ })
        locked -> {
            var askSignOut by remember { mutableStateOf(false) }
            LockScreen(
                activity = activity,
                onUnlocked = { AppLock.locked.value = false },
                onForgotPin = { askSignOut = true }
            )
            if (askSignOut) AlertDialog(
                onDismissRequest = { askSignOut = false },
                title = { Text("Forgot PIN?") },
                text = { Text("Sign out and sign in again with your account password. " +
                    if (Prefs.autoBackup) "Your backed-up passwords will be restored." else "Backup is off, so passwords on this phone will be lost.") },
                confirmButton = {
                    TextButton(onClick = { askSignOut = false; AuthManager.signOut(activity); authStep = AuthStep.SignIn; refresh++ }) { Text("Sign out") }
                },
                dismissButton = { TextButton(onClick = { askSignOut = false }) { Text("Cancel") } }
            )
        }
        else -> {
            LaunchedEffect(Unit) { VaultRepository.ensureLoaded(); AuthManager.rememberKeyOwner() }
            MainShell(activity, onSignedOut = { authStep = AuthStep.SignIn; refresh++ })
        }
    }
}

private data class DrawerItem(val route: String, val label: String, val icon: ImageVector)

private val drawerItems = listOf(
    DrawerItem("home", "Passwords", Icons.Filled.Key),
    DrawerItem("generator", "Password generator", Icons.Filled.Password),
    DrawerItem("security", "Security check", Icons.Filled.HealthAndSafety),
    DrawerItem("settings", "Settings", Icons.Filled.Settings),
    DrawerItem("about", "About", Icons.Filled.Info),
)

@Composable
private fun MainShell(activity: MainActivity, onSignedOut: () -> Unit) {
    val nav = rememberNavController()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val backEntry by nav.currentBackStackEntryAsState()
    val route = backEntry?.destination?.route ?: "home"
    val topLevel = drawerItems.any { it.route == route }
    val count by VaultRepository.entries.collectAsState()

    ModalNavigationDrawer(
        drawerState = drawer,
        gesturesEnabled = topLevel,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.padding(24.dp)) {
                    Icon(Icons.Filled.Shield, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
                    Text("AppForge Vault", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(AuthManager.email, style = MaterialTheme.typography.bodySmall)
                    Text("${count.size} saved passwords", style = MaterialTheme.typography.bodySmall)
                }
                HorizontalDivider()
                drawerItems.forEach { item ->
                    NavigationDrawerItem(
                        label = { Text(item.label) },
                        icon = { Icon(item.icon, null) },
                        selected = route == item.route,
                        onClick = {
                            scope.launch { drawer.close() }
                            nav.goTopLevel(item.route)
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                NavigationDrawerItem(
                    label = { Text("Lock app") }, icon = { Icon(Icons.Filled.Lock, null) }, selected = false,
                    onClick = { scope.launch { drawer.close() }; AppLock.lockNow() },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Sign out") }, icon = { Icon(Icons.AutoMirrored.Filled.Logout, null) }, selected = false,
                    onClick = { scope.launch { drawer.close() }; nav.goTopLevel("settings") },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(titleFor(route)) },
                    navigationIcon = {
                        if (topLevel) IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Filled.Menu, "Menu") }
                        else IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    },
                    actions = {
                        if (route.startsWith("detail/")) {
                            val id = backEntry?.arguments?.getString("id")
                            IconButton(onClick = { nav.navigate("edit/$id") }) { Icon(Icons.Filled.Edit, "Edit") }
                        }
                    }
                )
            },
            floatingActionButton = {
                if (route == "home") FloatingActionButton(onClick = { nav.navigate("add") }) { Icon(Icons.Filled.Add, "Add password") }
            }
        ) { pad ->
            NavHost(nav, startDestination = "home") {
                composable("home") { HomeScreen(onOpen = { nav.navigate("detail/$it") }, contentPadding = pad) }
                composable("detail/{id}") { b ->
                    val id = b.arguments?.getString("id").orEmpty()
                    EntryDetailScreen(id, onEdit = { nav.navigate("edit/$id") }, onDeleted = { nav.popBackStack() }, contentPadding = pad)
                }
                composable("add") { EditEntryScreen(null, onSaved = { nav.popBackStack() }, contentPadding = pad) }
                composable("edit/{id}") { b ->
                    EditEntryScreen(b.arguments?.getString("id"), onSaved = { nav.popBackStack() }, contentPadding = pad)
                }
                composable("generator") { GeneratorScreen(pad) }
                composable("security") { SecurityScreen(onOpen = { nav.navigate("detail/$it") }, contentPadding = pad) }
                composable("settings") {
                    SettingsScreen(pad, onScreenshotSettingChanged = { activity.applyScreenshotSetting() }, onSignedOut = onSignedOut)
                }
                composable("about") { AboutScreen(pad) }
            }
        }
    }
}

private fun NavHostController.goTopLevel(route: String) {
    navigate(route) {
        popUpTo("home") { saveState = false }
        launchSingleTop = true
    }
}

private fun titleFor(route: String) = when {
    route == "home" -> "Passwords"
    route == "generator" -> "Password generator"
    route == "security" -> "Security check"
    route == "settings" -> "Settings"
    route == "about" -> "About"
    route == "add" -> "Add password"
    route.startsWith("edit/") -> "Edit password"
    else -> "Password"
}
