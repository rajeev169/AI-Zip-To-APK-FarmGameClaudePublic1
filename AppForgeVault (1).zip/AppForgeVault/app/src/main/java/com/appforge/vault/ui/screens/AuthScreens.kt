package com.appforge.vault.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.appforge.vault.crypto.RecoveryKey
import com.appforge.vault.data.AuthManager
import com.appforge.vault.data.BackupManager
import com.appforge.vault.data.Prefs
import com.appforge.vault.util.AppLock
import com.appforge.vault.util.Biometric
import com.appforge.vault.util.Clipboard
import kotlinx.coroutines.launch

@Composable
private fun AuthFrame(title: String, subtitle: String, content: @Composable () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().imePadding()
                .verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            VSpace(32)
            Icon(Icons.Filled.Shield, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
            VSpace(12)
            Text("AppForge Vault", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            VSpace(24)
            Text(title, style = MaterialTheme.typography.titleLarge)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            VSpace(24)
            content()
        }
    }
}

@Composable
fun SignInScreen(onDone: () -> Unit, onCreateAccount: () -> Unit, onNeedsOldPassword: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf(AuthManager.email) }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }

    AuthFrame("Sign in", "Sign in with your AppForge Vault email and password") {
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        VSpace(12)
        PasswordField(password, { password = it }, "Password")
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
            TextButton(onClick = {
                if (email.isBlank()) { error = "Enter your email first"; return@TextButton }
                scope.launch {
                    runCatching { AuthManager.sendPasswordReset(email) }
                        .onSuccess { info = "Password reset link sent to $email"; error = null }
                        .onFailure { error = AuthManager.friendlyError(it) }
                }
            }) { Text("Forgot password?") }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        info?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        VSpace(12)
        Button(
            onClick = {
                error = null; busy = true
                scope.launch {
                    try {
                        when (AuthManager.signIn(email, password)) {
                            is AuthManager.SignInResult.Ok -> onDone()
                            AuthManager.SignInResult.NeedsOldPassword -> onNeedsOldPassword(password)
                        }
                    } catch (e: Exception) {
                        error = AuthManager.friendlyError(e)
                    } finally { busy = false }
                }
            },
            enabled = !busy && email.isNotBlank() && password.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text("Sign in") }
        VSpace(12)
        OutlinedButton(onClick = onCreateAccount, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text("Create account")
        }
    }
}

@Composable
fun CreateAccountScreen(onDone: (String) -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AuthFrame("Create account", "Your account password also locks your encrypted backup") {
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        VSpace(12)
        PasswordField(password, { password = it }, "Password (min 8 characters)")
        StrengthMeter(password)
        VSpace(12)
        PasswordField(confirm, { confirm = it }, "Confirm password")
        VSpace(12)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
            Text(
                "Remember this password. Your saved passwords are encrypted with it, so nobody — not even us — can read them.",
                Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall
            )
        }
        error?.let { VSpace(8); Text(it, color = MaterialTheme.colorScheme.error) }
        VSpace(16)
        Button(
            onClick = {
                error = when {
                    !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> "Enter a valid email"
                    password.length < 8 -> "Password must be at least 8 characters"
                    password != confirm -> "Passwords do not match"
                    else -> null
                }
                if (error != null) return@Button
                busy = true
                scope.launch {
                    try { onDone(AuthManager.createAccount(email, password)) }
                    catch (e: Exception) { error = AuthManager.friendlyError(e) }
                    finally { busy = false }
                }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text("Create account") }
        VSpace(8)
        TextButton(onClick = onBack) { Text("Already have an account? Sign in") }
    }
}

/**
 * Shown when the backup was locked with an old password (after "Forgot password").
 * Ways to unlock: fingerprint / app PIN (same phone), Recovery Key (any phone), old password.
 */
@Composable
fun RecoverBackupScreen(
    activity: FragmentActivity,
    currentPassword: String,
    onDone: () -> Unit,
    onNewRecoveryKey: (String) -> Unit,
    onCancel: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val canUsePhone = remember { AuthManager.canUnlockWithThisPhone() }
    var showLock by remember { mutableStateOf(false) }
    var recovery by remember { mutableStateOf("") }
    var old by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmFresh by remember { mutableStateOf(false) }

    fun run(block: suspend () -> Unit) {
        busy = true; error = null
        scope.launch {
            try { block() } catch (e: Exception) { error = AuthManager.friendlyError(e) } finally { busy = false }
        }
    }
    fun restored(n: Int) {
        Toast.makeText(ctx, if (n > 0) "Backup unlocked · $n passwords restored" else "Backup unlocked", Toast.LENGTH_LONG).show()
        onDone()
    }

    if (showLock) {
        LockScreen(
            activity = activity,
            subtitle = "Confirm it's you to unlock your backup",
            onUnlocked = { showLock = false; run { restored(AuthManager.recoverWithThisPhone(currentPassword)) } },
        )
        return
    }

    AuthFrame(
        "Unlock your backup",
        "Your backup is still locked with your old password. Choose a way to unlock it."
    ) {
        if (busy) { CircularProgressIndicator(); VSpace(12) }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error); VSpace(8) }

        if (canUsePhone) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("This phone has your passwords", fontWeight = FontWeight.SemiBold)
                    Text("Use your fingerprint or app PIN. Your backup will be locked with your new password.",
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
                    Button(onClick = { showLock = true }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                        Icon(Icons.Filled.Fingerprint, null); HSpace(8); Text("Unlock with fingerprint or PIN")
                    }
                }
            }
            VSpace(20)
        }

        Text("Use your Recovery Key", fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth())
        VSpace(6)
        OutlinedTextField(recovery, { recovery = it.uppercase() }, label = { Text("XXXX-XXXX-XXXX-XXXX-XXXX-XXXX") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        VSpace(8)
        OutlinedButton(
            onClick = {
                if (RecoveryKey.normalize(recovery) == null) { error = "A recovery key has 24 letters and numbers"; return@OutlinedButton }
                run { restored(AuthManager.recoverWithRecoveryKey(recovery, currentPassword)) }
            },
            enabled = !busy && recovery.isNotBlank(), modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Unlock with Recovery Key") }

        VSpace(20)
        Text("Or enter your old password", fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth())
        VSpace(6)
        PasswordField(old, { old = it }, "Old password")
        VSpace(8)
        OutlinedButton(
            onClick = { run { restored(AuthManager.recoverWithOldPassword(old, currentPassword)) } },
            enabled = !busy && old.isNotEmpty(), modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Unlock with old password") }

        VSpace(20)
        TextButton(onClick = { confirmFresh = true }, enabled = !busy) { Text("I can't unlock it — start fresh") }
        TextButton(onClick = onCancel, enabled = !busy) { Text("Cancel") }
    }
    if (confirmFresh) AlertDialog(
        onDismissRequest = { confirmFresh = false },
        title = { Text("Start fresh?") },
        text = { Text("Your old backup will be deleted and cannot be recovered. You'll get a new Recovery Key.") },
        confirmButton = {
            TextButton(onClick = {
                confirmFresh = false
                run { onNewRecoveryKey(AuthManager.startFresh(currentPassword)) }
            }) { Text("Delete & start fresh") }
        },
        dismissButton = { TextButton(onClick = { confirmFresh = false }) { Text("Cancel") } }
    )
}

/** Shows the Recovery Key once, with copy and save-to-file. */
@Composable
fun RecoveryKeyScreen(code: String, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var saved by remember { mutableStateOf(false) }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) runCatching {
            ctx.contentResolver.openOutputStream(uri)!!.use { it.write(recoveryFileText(code).toByteArray()) }
            Toast.makeText(ctx, "Recovery Key saved", Toast.LENGTH_SHORT).show()
            saved = true
        }
    }
    AuthFrame("Your Recovery Key", "If you forget your password and lose this phone, this key is the only way to unlock your backup.") {
        RecoveryKeyCard(code)
        VSpace(12)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { Clipboard.copy(ctx, "Recovery Key", code, sensitive = true); saved = true },
                modifier = Modifier.weight(1f)) { Icon(Icons.Filled.ContentCopy, null); HSpace(6); Text("Copy") }
            OutlinedButton(onClick = { AppLock.skipNextLock = true; saveLauncher.launch("AppForge-Vault-Recovery-Key.txt") },
                modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Download, null); HSpace(6); Text("Save file") }
        }
        VSpace(12)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
            Text("Write it on paper or keep the file somewhere safe (not only on this phone). Anyone with this key and your email could open your backup.",
                Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
        }
        VSpace(12)
        SettingRow("I have saved my Recovery Key", "", checked = saved) { saved = it }
        VSpace(12)
        Button(onClick = onDone, enabled = saved, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Continue") }
    }
}

@Composable
fun RecoveryKeyCard(code: String) {
    Card(Modifier.fillMaxWidth()) {
        Text(
            code, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp, horizontal = 12.dp)
        )
    }
}

fun recoveryFileText(code: String) = buildString {
    appendLine("AppForge Vault — Recovery Key")
    appendLine()
    appendLine("Account: ${AuthManager.email}")
    appendLine("Recovery Key: $code")
    appendLine()
    appendLine("Use this key on the \"Unlock your backup\" screen if you forget your account password.")
    appendLine("Keep it private and safe. Making a new key in Settings makes this one stop working.")
}

/** First-time setup on this phone: app PIN, fingerprint, automatic backup. */
@Composable
fun SetupScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var step by remember { mutableStateOf(0) }
    var firstPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }
    var useBio by remember { mutableStateOf(Biometric.available(ctx)) }
    var autoBackup by remember { mutableStateOf(Prefs.autoBackup) }

    when (step) {
        0 -> PinPad(
            title = "Create an app PIN",
            subtitle = "4 to 6 digits. Used to open the app and fill passwords.",
            error = pinError,
            onSubmit = { pin ->
                if (pin.length < 4) pinError = "PIN must be at least 4 digits"
                else { firstPin = pin; pinError = null; step = 1 }
            }
        )
        1 -> PinPad(
            title = "Confirm your PIN",
            subtitle = "Enter the same PIN again",
            error = pinError,
            onSubmit = { pin ->
                if (pin == firstPin) { Prefs.setPin(pin); pinError = null; step = 2 }
                else { pinError = "PINs didn't match. Try again."; step = 0 }
            }
        )
        else -> AuthFrame("Almost done", "Choose how you want AppForge Vault to work") {
            SettingRow("Unlock with fingerprint", "Use your fingerprint instead of the PIN",
                checked = useBio, enabled = Biometric.available(ctx)) { useBio = it }
            VSpace(8)
            SettingRow("Automatic backup", "Encrypted backup to your account whenever passwords change",
                checked = autoBackup) { autoBackup = it }
            VSpace(24)
            Button(onClick = {
                Prefs.biometricEnabled = useBio && Biometric.available(ctx)
                Prefs.autoBackup = autoBackup
                Prefs.setupDone = true
                BackupManager.applySchedule(ctx)
                if (autoBackup) BackupManager.onVaultChanged(ctx)
                onDone()
            }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Finish") }
        }
    }
}

@Composable
fun SettingRow(title: String, subtitle: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        HSpace(12)
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
