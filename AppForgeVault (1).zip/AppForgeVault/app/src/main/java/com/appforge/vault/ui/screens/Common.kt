package com.appforge.vault.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.appforge.vault.data.PasswordTools

@Composable
fun PasswordField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    trailingExtra: (@Composable () -> Unit)? = null,
) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = true, modifier = modifier,
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = {
            Row {
                trailingExtra?.invoke()
                IconButton(onClick = { visible = !visible }) {
                    Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Show password")
                }
            }
        }
    )
}

fun strengthColor(s: PasswordTools.Strength): Color = when (s) {
    PasswordTools.Strength.VERY_WEAK -> Color(0xFFD32F2F)
    PasswordTools.Strength.WEAK -> Color(0xFFF57C00)
    PasswordTools.Strength.FAIR -> Color(0xFFFBC02D)
    PasswordTools.Strength.GOOD -> Color(0xFF7CB342)
    PasswordTools.Strength.STRONG -> Color(0xFF2E7D32)
}

@Composable
fun StrengthMeter(password: String) {
    if (password.isEmpty()) return
    val s = PasswordTools.strength(password)
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        LinearProgressIndicator(
            progress = { (s.score + 1) / 5f },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = strengthColor(s), strokeCap = StrokeCap.Round,
        )
        Text(s.label, style = MaterialTheme.typography.labelMedium, color = strengthColor(s),
            modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
fun LetterAvatar(text: String, size: Int = 40) {
    val letter = text.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
    val palette = listOf(0xFF3949AB, 0xFF00897B, 0xFFD81B60, 0xFF6D4C41, 0xFF8E24AA, 0xFFF4511E, 0xFF1E88E5, 0xFF43A047)
    val c = Color(palette[(text.lowercase().hashCode() and 0x7fffffff) % palette.size])
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(c),
        contentAlignment = Alignment.Center
    ) { Text(letter, color = Color.White, fontWeight = FontWeight.Bold) }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp)
    )
}

@Composable
fun HSpace(w: Int) = Spacer(Modifier.width(w.dp))

@Composable
fun VSpace(h: Int) = Spacer(Modifier.height(h.dp))
