package com.appforge.vault.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.appforge.vault.data.Entry
import com.appforge.vault.data.PasswordTools
import com.appforge.vault.data.VaultRepository
import com.appforge.vault.util.Clipboard
import java.text.DateFormat
import java.util.Date

@Composable
fun EntryDetailScreen(id: String, onEdit: () -> Unit, onDeleted: () -> Unit, contentPadding: PaddingValues) {
    val ctx = LocalContext.current
    val entries by VaultRepository.entries.collectAsState()
    val e = entries.firstOrNull { it.id == id } ?: return
    var show by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val reused = entries.count { it.password == e.password } > 1

    Column(Modifier.fillMaxSize().padding(contentPadding).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LetterAvatar(e.title, 56)
            HSpace(16)
            Column {
                Text(e.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                if (e.url.isNotBlank()) Text(e.url, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        VSpace(20)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                FieldLine("Username / email", e.username.ifEmpty { "—" }) {
                    if (e.username.isNotEmpty()) Clipboard.copy(ctx, "Username", e.username, sensitive = false)
                }
                VSpace(12)
                Text("Password", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (show) e.password else "•".repeat(e.password.length.coerceIn(8, 16)),
                        fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { show = !show }) {
                        Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Show")
                    }
                    IconButton(onClick = { Clipboard.copy(ctx, "Password", e.password, sensitive = true) }) {
                        Icon(Icons.Filled.ContentCopy, "Copy password")
                    }
                }
                StrengthMeter(e.password)
                if (reused) Text("⚠ This password is used for more than one account",
                    color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp))
            }
        }
        if (e.notes.isNotBlank()) {
            VSpace(12)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Notes", style = MaterialTheme.typography.labelMedium)
                    Text(e.notes)
                }
            }
        }
        VSpace(12)
        val df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        Text("Last changed: ${df.format(Date(e.updatedAt))}", style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        VSpace(20)
        Row {
            Button(onClick = onEdit, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Edit, null); HSpace(6); Text("Edit")
            }
            HSpace(12)
            OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Delete, null); HSpace(6); Text("Delete")
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete this password?") },
        text = { Text("${e.title} will be removed from this phone and your backup.") },
        confirmButton = { TextButton(onClick = { VaultRepository.delete(e.id); confirmDelete = false; onDeleted() }) { Text("Delete") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
    )
}

@Composable
private fun FieldLine(label: String, value: String, onCopy: () -> Unit) {
    Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(value, modifier = Modifier.weight(1f))
        IconButton(onClick = onCopy) { Icon(Icons.Filled.ContentCopy, "Copy") }
    }
}

@Composable
fun EditEntryScreen(id: String?, onSaved: () -> Unit, contentPadding: PaddingValues) {
    val existing = remember(id) { id?.let { VaultRepository.get(it) } }
    var title by remember { mutableStateOf(existing?.title.orEmpty()) }
    var username by remember { mutableStateOf(existing?.username.orEmpty()) }
    var password by remember { mutableStateOf(existing?.password.orEmpty()) }
    var url by remember { mutableStateOf(existing?.url.orEmpty()) }
    var notes by remember { mutableStateOf(existing?.notes.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().padding(contentPadding).imePadding()
            .verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        OutlinedTextField(title, { title = it }, label = { Text("Name (e.g. Gmail)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        VSpace(10)
        OutlinedTextField(username, { username = it }, label = { Text("Username or email") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        VSpace(10)
        PasswordField(password, { password = it }, "Password", trailingExtra = {
            IconButton(onClick = { password = PasswordTools.generate(16) }) { Icon(Icons.Filled.Refresh, "Generate") }
        })
        StrengthMeter(password)
        VSpace(10)
        OutlinedTextField(url, { url = it }, label = { Text("Website or app (optional)") }, singleLine = true,
            placeholder = { Text("https://mail.google.com") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), modifier = Modifier.fillMaxWidth())
        VSpace(10)
        OutlinedTextField(notes, { notes = it }, label = { Text("Notes (optional)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        error?.let { VSpace(8); Text(it, color = MaterialTheme.colorScheme.error) }
        VSpace(20)
        Button(
            onClick = {
                if (title.isBlank() && url.isBlank()) { error = "Add a name"; return@Button }
                if (password.isEmpty()) { error = "Password can't be empty"; return@Button }
                val base = existing ?: Entry(title = "", username = "", password = "")
                VaultRepository.upsert(
                    base.copy(
                        title = title.ifBlank { url }.trim(), username = username.trim(),
                        password = password, url = url.trim(), notes = notes
                    )
                )
                onSaved()
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Save") }
    }
}
