package com.appforge.vault.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.autofill.AutofillManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.appforge.vault.data.VaultRepository
import com.appforge.vault.util.AppLock
import com.appforge.vault.util.Clipboard

fun isAutofillEnabled(ctx: android.content.Context): Boolean =
    ctx.getSystemService(AutofillManager::class.java)?.hasEnabledAutofillServices() == true

fun openAutofillSettings(ctx: android.content.Context) {
    AppLock.skipNextLock = true
    val i = Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE).setData(Uri.parse("package:${ctx.packageName}"))
    runCatching { ctx.startActivity(i) }.onFailure {
        ctx.startActivity(Intent(Settings.ACTION_SETTINGS))
    }
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit, contentPadding: PaddingValues) {
    val ctx = LocalContext.current
    val entries by VaultRepository.entries.collectAsState()
    var query by remember { mutableStateOf("") }
    var autofillOn by remember { mutableStateOf(isAutofillEnabled(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { autofillOn = isAutofillEnabled(ctx) }

    val shown = remember(entries, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) entries else entries.filter {
            it.title.lowercase().contains(q) || it.username.lowercase().contains(q) || it.url.lowercase().contains(q)
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = contentPadding) {
        item {
            OutlinedTextField(
                query, { query = it }, placeholder = { Text("Search passwords") }, singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(16.dp, 8.dp)
            )
        }
        if (!autofillOn) item {
            Card(
                Modifier.fillMaxWidth().padding(16.dp, 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.AutoAwesome, null)
                        HSpace(8)
                        Text("Turn on automatic saving", fontWeight = FontWeight.SemiBold)
                    }
                    Text(
                        "Set AppForge Vault as your autofill service. Then every time you log in to an email, app or website, it offers to save the password and fills it next time.",
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp)
                    )
                    Button(onClick = { openAutofillSettings(ctx) }) { Text("Turn on") }
                }
            }
        }
        if (shown.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Key, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
                VSpace(12)
                Text(
                    if (entries.isEmpty()) "No passwords yet.\nLog in to any app or tap + to add one."
                    else "No results for \"$query\"",
                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        items(shown, key = { it.id }) { e ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(e.id) }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LetterAvatar(e.title)
                HSpace(14)
                Column(Modifier.weight(1f)) {
                    Text(e.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(e.username.ifEmpty { "No username" }, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { Clipboard.copy(ctx, "Password", e.password, sensitive = true) }) {
                    Icon(Icons.Filled.ContentCopy, "Copy password")
                }
            }
        }
        item { Box(Modifier.padding(40.dp)) }
    }
}

@Composable
fun CountRow(label: String, count: Int) = Row(
    Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween
) { Text(label); Text(count.toString(), fontWeight = FontWeight.Bold) }
