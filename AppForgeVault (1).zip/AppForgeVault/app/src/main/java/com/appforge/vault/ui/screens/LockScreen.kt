package com.appforge.vault.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.appforge.vault.data.Prefs
import com.appforge.vault.util.Biometric
import kotlinx.coroutines.delay

@Composable
fun PinPad(
    title: String,
    subtitle: String,
    error: String? = null,
    showFingerprint: Boolean = false,
    onFingerprint: () -> Unit = {},
    extra: (@Composable () -> Unit)? = null,
    onSubmit: (String) -> Unit,
) {
    var pin by remember(title) { mutableStateOf("") }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Filled.Lock, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
            VSpace(12)
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            VSpace(24)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                repeat(6) { i ->
                    val filled = i < pin.length
                    Box(
                        Modifier.size(14.dp).clip(CircleShape)
                            .then(
                                if (filled) Modifier.background(MaterialTheme.colorScheme.primary)
                                else Modifier.border(2.dp, MaterialTheme.colorScheme.outline, CircleShape)
                            )
                    )
                }
            }
            VSpace(12)
            Text(error ?: " ", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            VSpace(16)
            val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("bio", "0", "ok"))
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                    row.forEach { key ->
                        Box(
                            Modifier.size(72.dp).clip(CircleShape)
                                .background(
                                    if (key in listOf("bio", "ok")) MaterialTheme.colorScheme.surface
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable {
                                    when (key) {
                                        "bio" -> if (showFingerprint) onFingerprint() else if (pin.isNotEmpty()) pin = pin.dropLast(1)
                                        "ok" -> { if (pin.isNotEmpty()) { onSubmit(pin); pin = "" } }
                                        else -> if (pin.length < 6) {
                                            pin += key
                                            if (pin.length == 6) { onSubmit(pin); pin = "" }
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            when (key) {
                                "bio" -> Icon(
                                    if (showFingerprint) Icons.Filled.Fingerprint else Icons.AutoMirrored.Filled.Backspace,
                                    if (showFingerprint) "Fingerprint" else "Delete"
                                )
                                "ok" -> Icon(Icons.Filled.Check, "OK", tint = MaterialTheme.colorScheme.primary)
                                else -> Text(key, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
            if (showFingerprint) {
                TextButton(onClick = { if (pin.isNotEmpty()) pin = pin.dropLast(1) }) { Text("Delete digit") }
            }
            extra?.invoke()
        }
    }
}

/** App lock screen: PIN or fingerprint. */
@Composable
fun LockScreen(activity: FragmentActivity, subtitle: String = "Enter your PIN", onUnlocked: () -> Unit, onForgotPin: (() -> Unit)? = null) {
    val bio = Prefs.biometricEnabled && Biometric.available(activity)
    var error by remember { mutableStateOf<String?>(null) }
    var wait by remember { mutableStateOf(Prefs.pinWaitSeconds()) }

    LaunchedEffect(Unit) {
        if (bio) Biometric.prompt(activity, "Unlock AppForge Vault", onUnlocked)
    }
    LaunchedEffect(wait) {
        if (wait > 0) { delay(1000); wait = Prefs.pinWaitSeconds(); if (wait == 0) error = null }
    }

    PinPad(
        title = "AppForge Vault",
        subtitle = subtitle,
        error = if (wait > 0) "Too many tries. Wait ${wait}s" else error,
        showFingerprint = bio,
        onFingerprint = { Biometric.prompt(activity, "Unlock AppForge Vault", onUnlocked) },
        extra = onForgotPin?.let { cb -> { TextButton(onClick = cb) { Text("Forgot PIN? Sign out") } } },
        onSubmit = { pin ->
            if (Prefs.pinWaitSeconds() > 0) { wait = Prefs.pinWaitSeconds() }
            else if (Prefs.verifyPin(pin)) { error = null; onUnlocked() }
            else { error = "Wrong PIN"; wait = Prefs.pinWaitSeconds() }
        }
    )
}
