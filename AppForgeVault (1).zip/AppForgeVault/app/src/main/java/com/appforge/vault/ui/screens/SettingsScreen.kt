package com.appforge.vault.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.appforge.vault.data.AuthManager
import com.appforge.vault.data.BackupManager
import com.appforge.vault.data.ExportImport
import com.appforge.vault.data.Prefs
import com.appforge.vault.data.VaultRepository
import com.appforge.vault.ui.theme.ThemeState
import com.appforge.vault.util.AppLock
import com.appforge.vault.util.Biometric
import com.appforge.vault.util.Clipboard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

private sealed class Dlg {
    data object Timeout : Dlg()
    data object Clip : Dlg()
    data object Theme : Dlg()
    data object ChangePin : Dlg()
    data object ExportPw : Dlg()
    data class ImportPw(val text: String) : Dlg()
    data object ChangePassword : Dlg()
    data object SignOut : Dlg()
    data object DeleteAccount : Dlg()
    data object Restore : Dlg()
    data object NewRecovery : Dlg()
    data class ShowRecovery(val code: String) : Dlg()
}

@Composable
fun SettingsScreen(
    contentPadding: PaddingValues,
    onScreenshotSettingChanged: () -> Unit,
    onSignedOut: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val entries by VaultRepository.entries.collectAsState()

    var autoBackup by remember { mutableStateOf(Prefs.autoBackup) }
    var lastBackup by remember { mutableStateOf(Prefs.lastBackupAt) }
    var bio by remember { mutableStateOf(Prefs.biometricEnabled) }
    var timeout by remember { mutableStateOf(Prefs.lockTimeoutSec) }
    var clip by remember { mutableStateOf(Prefs.clipboardClearSec) }
    var noShots by remember { mutableStateOf(Prefs.blockScreenshots) }
    var saveOffer by remember { mutableStateOf(Prefs.autofillSaveEnabled) }
    var theme by remember { mutableStateOf(Prefs.themeMode) }
    var autofillOn by remember { mutableStateOf(isAutofillEnabled(ctx)) }
    var busy by remember { mutableStateOf<String?>(null) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var exportPassword by remember { mutableStateOf("") }
    var recoveryAt by remember { mutableStateOf(Prefs.recoveryKeyCreatedAt) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        autofillOn = isAutofillEnabled(ctx); lastBackup = Prefs.lastBackupAt
    }
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val pw = exportPassword; exportPassword = ""
        scope.launch {
            busy = "Exporting…"
            runCatching {
                withContext(Dispatchers.IO) {
                    val text = ExportImport.export(VaultRepository.entries.value, pw)
                    ctx.contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray()) }
                }
            }.onSuccess { toast("Exported ${entries.size} passwords") }.onFailure { toast("Export failed: ${it.message}") }
            busy = null
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val text = runCatching {
            ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
        }.getOrElse { toast("Could not read file"); return@rememberLauncherForActivityResult }
        if (ExportImport.isEncryptedExport(text)) dlg = Dlg.ImportPw(text)
        else {
            val list = ExportImport.parseCsv(text)
            if (list.isEmpty()) toast("No passwords found in this file")
            else toast("Imported ${VaultRepository.merge(list)} new passwords")
        }
    }

    Column(Modifier.fillMaxSize().padding(contentPadding).verticalScroll(rememberScrollState())) {
        busy?.let {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(); HSpace(12); Text(it)
            }
        }

        SectionTitle("Backup")
        Item {
            SettingRow("Automatic backup", "Encrypted backup to your account whenever passwords change, and once a day", autoBackup) {
                autoBackup = it; Prefs.autoBackup = it
                BackupManager.applySchedule(ctx)
                if (it) BackupManager.onVaultChanged(ctx)
            }
        }
        val df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        Clickable("Back up now", if (lastBackup > 0) "Last backup: ${df.format(Date(lastBackup))}" else "Not backed up yet") {
            scope.launch {
                busy = "Backing up…"
                runCatching { BackupManager.backupNow() }
                    .onSuccess { lastBackup = Prefs.lastBackupAt; toast("Backup complete") }
                    .onFailure { toast("Backup failed: ${AuthManager.friendlyError(it)}") }
                busy = null
            }
        }
        Clickable("Restore from backup", "Replace passwords on this phone with your latest backup") { dlg = Dlg.Restore }

        SectionTitle("Autofill")
        Clickable("Autofill service", if (autofillOn) "On — AppForge Vault saves and fills passwords" else "Off — tap to turn on") {
            openAutofillSettings(ctx)
        }
        Item {
            SettingRow("Offer to save passwords", "Ask to save when you log in to apps and websites", saveOffer) {
                saveOffer = it; Prefs.autofillSaveEnabled = it
            }
        }

        SectionTitle("Security")
        Item {
            SettingRow("Unlock with fingerprint", if (Biometric.available(ctx)) "Use fingerprint instead of PIN" else "No fingerprint set up on this phone",
                bio, enabled = Biometric.available(ctx)) { bio = it; Prefs.biometricEnabled = it }
        }
        Clickable("Change app PIN", "") { dlg = Dlg.ChangePin }
        Clickable("Auto-lock", timeoutLabel(timeout)) { dlg = Dlg.Timeout }
        Clickable("Clear copied password", clipLabel(clip)) { dlg = Dlg.Clip }
        Item {
            SettingRow("Block screenshots", "Hide app content from screenshots and recent apps", noShots) {
                noShots = it; Prefs.blockScreenshots = it; onScreenshotSettingChanged()
            }
        }
        Clickable("Lock now", "") { AppLock.lockNow() }

        SectionTitle("Data")
        Clickable("Export passwords", "Save an encrypted file protected by a password you choose") { dlg = Dlg.ExportPw }
        Clickable("Import passwords", "From an AppForge Vault export, or a CSV from Google Password Manager, Chrome or others") {
            AppLock.skipNextLock = true
            importLauncher.launch(arrayOf("*/*"))
        }

        SectionTitle("Appearance")
        Clickable("Theme", listOf("System default", "Light", "Dark")[theme]) { dlg = Dlg.Theme }

        SectionTitle("Account")
        Clickable("Signed in as", AuthManager.email) {}
        Clickable("Change account password", "Also re-locks your backup with the new password") { dlg = Dlg.ChangePassword }
        Clickable(
            "Recovery Key",
            if (recoveryAt > 0) "Created ${df.format(Date(recoveryAt))} · tap to make a new one"
            else "Unlocks your backup if you forget your password · tap to create"
        ) { dlg = Dlg.NewRecovery }
        Clickable("Sign out", "Removes passwords from this phone") { dlg = Dlg.SignOut }
        Clickable("Delete account", "Permanently delete your account and backup", danger = true) { dlg = Dlg.DeleteAccount }
        VSpace(40)
    }

    // ------------- dialogs -------------
    when (val d = dlg) {
        Dlg.Timeout -> ChoiceDialog("Auto-lock", listOf(0, 30, 60, 300, 900), timeout, ::timeoutLabel, { dlg = null }) {
            timeout = it; Prefs.lockTimeoutSec = it
        }
        Dlg.Clip -> ChoiceDialog("Clear copied password", listOf(15, 30, 60, 120, 0), clip, ::clipLabel, { dlg = null }) {
            clip = it; Prefs.clipboardClearSec = it
        }
        Dlg.Theme -> ChoiceDialog("Theme", listOf(0, 1, 2), theme, { listOf("System default", "Light", "Dark")[it] }, { dlg = null }) {
            theme = it; Prefs.themeMode = it; ThemeState.mode.intValue = it
        }
        Dlg.ChangePin -> FieldsDialog("Change app PIN", listOf("Current PIN", "New PIN (4-6 digits)", "Confirm new PIN"), numeric = true,
            onDismiss = { dlg = null }) { v ->
            when {
                !Prefs.verifyPin(v[0]) -> "Current PIN is wrong"
                v[1].length !in 4..6 || !v[1].all(Char::isDigit) -> "New PIN must be 4 to 6 digits"
                v[1] != v[2] -> "New PINs don't match"
                else -> { Prefs.setPin(v[1]); toast("PIN changed"); null }
            }
        }
        Dlg.ExportPw -> FieldsDialog("Export password", listOf("Password for the file", "Confirm password"),
            note = "You will need this password to import the file later.", onDismiss = { dlg = null }) { v ->
            when {
                v[0].length < 6 -> "Use at least 6 characters"
                v[0] != v[1] -> "Passwords don't match"
                else -> {
                    exportPassword = v[0]; AppLock.skipNextLock = true
                    exportLauncher.launch("appforge-vault-backup.json"); null
                }
            }
        }
        is Dlg.ImportPw -> FieldsDialog("Unlock import file", listOf("File password"), onDismiss = { dlg = null }) { v ->
            runCatching { ExportImport.decryptExport(d.text, v[0]) }.fold(
                onSuccess = { toast("Imported ${VaultRepository.merge(it)} new passwords"); null },
                onFailure = { "Wrong password or damaged file" }
            )
        }
        Dlg.ChangePassword -> AsyncFieldsDialog("Change account password",
            listOf("Current password", "New password (min 8)", "Confirm new password"), onDismiss = { dlg = null }) { v ->
            when {
                v[1].length < 8 -> "New password must be at least 8 characters"
                v[1] != v[2] -> "New passwords don't match"
                else -> runCatching { AuthManager.changePassword(v[0], v[1]) }
                    .fold({ toast("Account password changed"); null }, { AuthManager.friendlyError(it) })
            }
        }
        Dlg.SignOut -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("Sign out?") },
            text = {
                Text(
                    if (Prefs.autoBackup) "Your passwords are backed up. They will be removed from this phone and restored when you sign in again."
                    else "Automatic backup is OFF. Your passwords will be deleted from this phone and cannot be restored. Turn on backup first to keep them."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    dlg = null
                    scope.launch {
                        busy = "Signing out…"
                        if (Prefs.autoBackup) runCatching { BackupManager.backupNow() }
                        AuthManager.signOut(ctx); busy = null; onSignedOut()
                    }
                }) { Text("Sign out") }
            },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Cancel") } }
        )
        Dlg.Restore -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("Restore from backup?") },
            text = { Text("Passwords on this phone will be replaced with your latest backup.") },
            confirmButton = {
                TextButton(onClick = {
                    dlg = null
                    scope.launch {
                        busy = "Restoring…"
                        runCatching { BackupManager.restore() }.fold(
                            { n -> toast(if (n < 0) "No backup found yet" else "Restored $n passwords") },
                            { toast("Restore failed: ${AuthManager.friendlyError(it)}") })
                        busy = null
                    }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Cancel") } }
        )
        Dlg.DeleteAccount -> AsyncFieldsDialog("Delete account",
            listOf("Enter your account password"),
            note = "This permanently deletes your account, your backup and all passwords on this phone.",
            confirmLabel = "Delete forever", onDismiss = { dlg = null }) { v ->
            runCatching { AuthManager.deleteAccount(ctx, v[0]) }
                .fold({ onSignedOut(); null }, { AuthManager.friendlyError(it) })
        }
        Dlg.NewRecovery -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text(if (recoveryAt > 0) "Make a new Recovery Key?" else "Create a Recovery Key?") },
            text = {
                Text(
                    (if (recoveryAt > 0) "Your old Recovery Key will stop working. " else "") +
                        "Keep the new key safe. It unlocks your backup on any phone if you forget your password."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    dlg = null
                    scope.launch {
                        busy = "Creating Recovery Key…"
                        runCatching { AuthManager.createRecoveryKey() }.fold(
                            { code -> recoveryAt = Prefs.recoveryKeyCreatedAt; dlg = Dlg.ShowRecovery(code) },
                            { toast("Failed: ${AuthManager.friendlyError(it)}") })
                        busy = null
                    }
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Cancel") } }
        )
        is Dlg.ShowRecovery -> {
            val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
                if (uri != null) runCatching {
                    ctx.contentResolver.openOutputStream(uri)!!.use { it.write(recoveryFileText(d.code).toByteArray()) }
                    toast("Recovery Key saved")
                }
            }
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Your new Recovery Key") },
                text = {
                    Column {
                        RecoveryKeyCard(d.code)
                        VSpace(8)
                        Text("Write it down or save the file somewhere safe. It is shown only now.",
                            style = MaterialTheme.typography.bodySmall)
                        Row {
                            TextButton(onClick = { Clipboard.copy(ctx, "Recovery Key", d.code, sensitive = true) }) { Text("Copy") }
                            TextButton(onClick = { AppLock.skipNextLock = true; saveLauncher.launch("AppForge-Vault-Recovery-Key.txt") }) { Text("Save file") }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { dlg = null }) { Text("I've saved it") } }
            )
        }
        null -> {}
    }
}

private fun timeoutLabel(s: Int) = when (s) { 0 -> "Immediately"; 30 -> "After 30 seconds"; 60 -> "After 1 minute"; 300 -> "After 5 minutes"; else -> "After ${s / 60} minutes" }
private fun clipLabel(s: Int) = if (s == 0) "Never" else if (s < 60) "After $s seconds" else "After ${s / 60} minute${if (s >= 120) "s" else ""}"

@Composable
private fun Item(content: @Composable () -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) { content() }
}

@Composable
private fun Clickable(title: String, subtitle: String, danger: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge,
            color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
        if (subtitle.isNotEmpty()) Text(subtitle, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    HorizontalDivider(Modifier.padding(start = 16.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
}

@Composable
private fun <T> ChoiceDialog(title: String, options: List<T>, selected: T, label: (T) -> String, onDismiss: () -> Unit, onPick: (T) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column {
                options.forEach { o ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(o); onDismiss() }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = o == selected, onClick = { onPick(o); onDismiss() })
                        Text(label(o))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

/** Dialog with text fields; onConfirm returns an error message, or null when done. */
@Composable
private fun FieldsDialog(
    title: String, labels: List<String>, numeric: Boolean = false, note: String? = null,
    confirmLabel: String = "OK", onDismiss: () -> Unit, onConfirm: (List<String>) -> String?,
) {
    val values = remember { labels.map { mutableStateOf("") } }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column {
                note?.let { Text(it, style = MaterialTheme.typography.bodySmall); VSpace(8) }
                labels.forEachIndexed { i, l ->
                    OutlinedTextField(values[i].value, { values[i].value = it }, label = { Text(l) }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.NumberPassword else KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                error = onConfirm(values.map { it.value })
                if (error == null) onDismiss()
            }) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun AsyncFieldsDialog(
    title: String, labels: List<String>, note: String? = null, confirmLabel: String = "OK",
    onDismiss: () -> Unit, onConfirm: suspend (List<String>) -> String?,
) {
    val scope = rememberCoroutineScope()
    val values = remember { labels.map { mutableStateOf("") } }
    var error by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { if (!working) onDismiss() }, title = { Text(title) },
        text = {
            Column {
                note?.let { Text(it, style = MaterialTheme.typography.bodySmall); VSpace(8) }
                labels.forEachIndexed { i, l ->
                    OutlinedTextField(values[i].value, { values[i].value = it }, label = { Text(l) }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
                }
                if (working) CircularProgressIndicator(Modifier.padding(8.dp))
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = !working, onClick = {
                working = true; error = null
                scope.launch {
                    val e = onConfirm(values.map { it.value })
                    working = false
                    if (e == null) onDismiss() else error = e
                }
            }) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(enabled = !working, onClick = onDismiss) { Text("Cancel") } }
    )
}
