package com.appforge.vault.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.vault.data.Entry
import com.appforge.vault.data.PasswordTools
import com.appforge.vault.data.VaultRepository
import com.appforge.vault.util.Clipboard

@Composable
fun GeneratorScreen(contentPadding: PaddingValues) {
    val ctx = LocalContext.current
    var length by remember { mutableFloatStateOf(16f) }
    var upper by remember { mutableStateOf(true) }
    var lower by remember { mutableStateOf(true) }
    var digits by remember { mutableStateOf(true) }
    var symbols by remember { mutableStateOf(true) }
    fun make() = PasswordTools.generate(length.toInt(), upper, lower, digits, symbols)
    var pw by remember { mutableStateOf(make()) }

    Column(Modifier.fillMaxSize().padding(contentPadding).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text(pw, fontFamily = FontFamily.Monospace, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                StrengthMeter(pw)
            }
        }
        VSpace(12)
        Row {
            Button(onClick = { Clipboard.copy(ctx, "Password", pw, sensitive = true) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.ContentCopy, null); HSpace(6); Text("Copy")
            }
            HSpace(12)
            OutlinedButton(onClick = { pw = make() }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Refresh, null); HSpace(6); Text("New")
            }
        }
        VSpace(20)
        Text("Length: ${length.toInt()}", fontWeight = FontWeight.SemiBold)
        Slider(value = length, onValueChange = { length = it; pw = make() }, valueRange = 8f..64f, steps = 55)
        SettingRow("Capital letters (A-Z)", "", upper) { upper = it; pw = make() }
        SettingRow("Small letters (a-z)", "", lower) { lower = it; pw = make() }
        SettingRow("Numbers (0-9)", "", digits) { digits = it; pw = make() }
        SettingRow("Symbols (!@#\$)", "", symbols) { symbols = it; pw = make() }
    }
}

@Composable
fun SecurityScreen(onOpen: (String) -> Unit, contentPadding: PaddingValues) {
    val entries by VaultRepository.entries.collectAsState()
    val weak = entries.filter { PasswordTools.strength(it.password).score <= 1 }
    val reusedGroups = entries.groupBy { it.password }.filter { it.value.size > 1 }
    val reused = reusedGroups.values.flatten()
    val problems = (weak + reused).map { it.id }.toSet().size
    val score = if (entries.isEmpty()) 100 else ((entries.size - problems) * 100 / entries.size)

    Column(Modifier.fillMaxSize().padding(contentPadding).verticalScroll(rememberScrollState())) {
        Card(Modifier.fillMaxWidth().padding(16.dp)) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$score%", fontSize = 44.sp, fontWeight = FontWeight.Bold,
                    color = when { score >= 80 -> Color(0xFF2E7D32); score >= 50 -> Color(0xFFF57C00); else -> Color(0xFFD32F2F) })
                Text("Password health")
                VSpace(12)
                CountRow("Saved passwords", entries.size)
                CountRow("Weak passwords", weak.size)
                CountRow("Reused passwords", reused.size)
            }
        }
        if (problems == 0) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF2E7D32)); HSpace(8)
                Text("All your passwords look good.")
            }
        }
        if (weak.isNotEmpty()) {
            SectionTitle("Weak — change these")
            weak.forEach { ProblemRow(it, PasswordTools.strength(it.password).label, onOpen) }
        }
        if (reused.isNotEmpty()) {
            SectionTitle("Reused — use a different password for each")
            reused.forEach { ProblemRow(it, "Used ${reusedGroups[it.password]?.size} times", onOpen) }
        }
        VSpace(32)
    }
}

@Composable
private fun ProblemRow(e: Entry, reason: String, onOpen: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onOpen(e.id) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LetterAvatar(e.title); HSpace(14)
        Column(Modifier.weight(1f)) {
            Text(e.title, fontWeight = FontWeight.SemiBold)
            Text(e.username, style = MaterialTheme.typography.bodySmall)
        }
        Icon(Icons.Filled.Warning, null, tint = Color(0xFFF57C00)); HSpace(4)
        Text(reason, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun AboutScreen(contentPadding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(contentPadding).verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("AppForge Vault", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Version 1.2 · by AppForge", color = MaterialTheme.colorScheme.onSurfaceVariant)
        VSpace(16)
        Text("How your passwords are protected", fontWeight = FontWeight.SemiBold)
        Text(
            "• Passwords are encrypted on your phone with AES-256 using a hardware-protected key.\n" +
                "• Backups are encrypted with your account password before they are uploaded, so the server only stores scrambled data.\n" +
                "• The app opens only with your PIN or fingerprint.\n" +
                "• Screenshots of the app can be blocked from Settings."
        )
        VSpace(16)
        Text("Automatic saving", fontWeight = FontWeight.SemiBold)
        Text(
            "After you set AppForge Vault as your autofill service, Android asks \"Save password?\" whenever you sign in to an email, app or website. " +
                "Next time, tap the login box and choose your saved account. In Chrome, also open Chrome Settings › Autofill services and choose \"Autofill using another service\"."
        )
    }
}
