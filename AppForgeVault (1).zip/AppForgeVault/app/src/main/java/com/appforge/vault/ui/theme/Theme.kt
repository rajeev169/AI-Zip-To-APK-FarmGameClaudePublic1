package com.appforge.vault.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.appforge.vault.data.Prefs

/** Current theme choice (0 system, 1 light, 2 dark); changing it recolours the app instantly. */
object ThemeState {
    val mode = mutableIntStateOf(0)
}

private val Light = lightColorScheme(
    primary = Color(0xFF3949AB), onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE1FF), onPrimaryContainer = Color(0xFF001257),
    secondary = Color(0xFF00897B), secondaryContainer = Color(0xFFB2F1E8),
)
private val Dark = darkColorScheme(
    primary = Color(0xFFB9C3FF), onPrimary = Color(0xFF0E2289),
    primaryContainer = Color(0xFF2C3D9A), onPrimaryContainer = Color(0xFFDDE1FF),
    secondary = Color(0xFF80CBC4),
)

@Composable
fun VaultTheme(content: @Composable () -> Unit) {
    if (ThemeState.mode.intValue == 0) ThemeState.mode.intValue = Prefs.themeMode
    val dark = when (ThemeState.mode.intValue) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> Dark
        else -> Light
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
