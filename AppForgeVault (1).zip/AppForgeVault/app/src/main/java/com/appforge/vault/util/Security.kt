package com.appforge.vault.util

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.os.SystemClock
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.appforge.vault.data.Prefs

/** Locks the app when it has been in the background longer than the chosen time. */
object AppLock {
    val locked = mutableStateOf(true)
    private var backgroundAt = 0L
    /** Set before opening file pickers etc. so returning doesn't lock the app. */
    var skipNextLock = false

    fun onStop() { backgroundAt = SystemClock.elapsedRealtime() }

    fun onStart() {
        if (skipNextLock) { skipNextLock = false; return }
        if (!Prefs.pinSet || backgroundAt == 0L) return
        val away = SystemClock.elapsedRealtime() - backgroundAt
        if (away >= Prefs.lockTimeoutSec * 1000L) locked.value = true
    }

    fun lockNow() { locked.value = true }
}

object Biometric {
    fun available(context: Context): Boolean =
        BiometricManager.from(context).canAuthenticate(BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

    fun prompt(activity: FragmentActivity, title: String, onSuccess: () -> Unit) {
        val prompt = BiometricPrompt(
            activity, ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onSuccess()
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle("Use your fingerprint")
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BIOMETRIC_WEAK)
            .build()
        prompt.authenticate(info)
    }
}

object Clipboard {
    private val handler = Handler(Looper.getMainLooper())

    fun copy(context: Context, label: String, text: String, sensitive: Boolean) {
        val cm = context.getSystemService(ClipboardManager::class.java)
        val clip = ClipData.newPlainText(label, text)
        if (sensitive) {
            clip.description.extras = PersistableBundle().apply {
                if (Build.VERSION.SDK_INT >= 33) putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
                else putBoolean("android.content.extra.IS_SENSITIVE", true)
            }
        }
        cm.setPrimaryClip(clip)
        val secs = Prefs.clipboardClearSec
        if (sensitive && secs > 0) {
            handler.postDelayed({
                val current = cm.primaryClip?.getItemAt(0)?.text?.toString()
                if (current == text) {
                    if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip()
                    else cm.setPrimaryClip(ClipData.newPlainText("", ""))
                }
            }, secs * 1000L)
        }
        if (Build.VERSION.SDK_INT < 33) {
            val extra = if (sensitive && secs > 0) " (clears in ${secs}s)" else ""
            Toast.makeText(context, "$label copied$extra", Toast.LENGTH_SHORT).show()
        }
    }
}
