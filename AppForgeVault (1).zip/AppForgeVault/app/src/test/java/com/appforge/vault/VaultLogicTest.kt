package com.appforge.vault

import com.appforge.vault.crypto.Crypto
import com.appforge.vault.data.Entry
import com.appforge.vault.data.ExportImport
import com.appforge.vault.data.Matching
import com.appforge.vault.data.PasswordTools
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.security.GeneralSecurityException

class CryptoTest {
    @Test fun encryptThenDecrypt_givesSameText() {
        val key = Crypto.aesKey(Crypto.randomBytes(32))
        val secret = "MyGmailPass@123".toByteArray()
        assertEquals("MyGmailPass@123", String(Crypto.decrypt(key, Crypto.encrypt(key, secret))))
    }

    @Test fun sameTextTwice_givesDifferentCipherText() {
        val key = Crypto.aesKey(Crypto.randomBytes(32))
        assertFalse(Crypto.encrypt(key, "abc".toByteArray()).contentEquals(Crypto.encrypt(key, "abc".toByteArray())))
    }

    @Test fun wrongKey_cannotDecrypt() {
        val blob = Crypto.encrypt(Crypto.aesKey(Crypto.randomBytes(32)), "secret".toByteArray())
        try { Crypto.decrypt(Crypto.aesKey(Crypto.randomBytes(32)), blob); fail("Should not decrypt") }
        catch (e: GeneralSecurityException) { /* expected */ }
    }

    @Test fun tamperedData_isRejected() {
        val key = Crypto.aesKey(Crypto.randomBytes(32))
        val blob = Crypto.encrypt(key, "secret".toByteArray())
        blob[blob.size - 1] = (blob[blob.size - 1].toInt() xor 1).toByte()
        try { Crypto.decrypt(key, blob); fail("Tampering not detected") }
        catch (e: GeneralSecurityException) { /* expected */ }
    }

    @Test fun backupKeyFromPassword_unlocksOnlyWithSamePassword() {
        val vaultKey = Crypto.randomBytes(32)
        val salt = Crypto.randomBytes(16)
        val wrapped = Crypto.encrypt(Crypto.deriveKey("Account#Pass1", salt, 1000), vaultKey)
        val opened = Crypto.decrypt(Crypto.deriveKey("Account#Pass1", salt, 1000), wrapped)
        assertTrue(opened.contentEquals(vaultKey))
        try { Crypto.decrypt(Crypto.deriveKey("WrongPass", salt, 1000), wrapped); fail("Wrong password worked") }
        catch (e: GeneralSecurityException) { /* expected */ }
    }

    @Test fun base64_roundTrip() {
        val bytes = Crypto.randomBytes(50)
        assertTrue(Crypto.unb64(Crypto.b64(bytes)).contentEquals(bytes))
    }
}

class PasswordToolsTest {
    @Test fun generator_respectsLength() {
        for (len in listOf(8, 16, 32, 64)) assertEquals(len, PasswordTools.generate(len).length)
    }

    @Test fun generator_includesEveryChosenKind() {
        repeat(50) {
            val p = PasswordTools.generate(12)
            assertTrue(p.any { it.isUpperCase() }); assertTrue(p.any { it.isLowerCase() })
            assertTrue(p.any { it.isDigit() }); assertTrue(p.any { !it.isLetterOrDigit() })
        }
    }

    @Test fun generator_digitsOnly() {
        val p = PasswordTools.generate(20, upper = false, lower = false, digits = true, symbols = false)
        assertTrue(p.all { it.isDigit() })
    }

    @Test fun generator_neverRepeatsAcrossRuns() {
        val set = (1..200).map { PasswordTools.generate(16) }.toSet()
        assertEquals(200, set.size)
    }

    @Test fun strength_ratings() {
        assertEquals(PasswordTools.Strength.VERY_WEAK, PasswordTools.strength("password"))
        assertEquals(PasswordTools.Strength.VERY_WEAK, PasswordTools.strength("123456"))
        assertTrue(PasswordTools.strength("abc").score <= 1)
        assertTrue(PasswordTools.strength("aaaaaaaaaaaaaaaa").score <= 1)
        assertEquals(PasswordTools.Strength.STRONG, PasswordTools.strength("G7#kq!Zp2@vLm9&w"))
    }
}

class MatchingTest {
    @Test fun websiteKeys() {
        assertEquals("mail.google.com", Matching.keyOf("https://www.mail.google.com/mail/u/0"))
        assertEquals("facebook.com", Matching.keyOf("https://m.facebook.com/login?x=1"))
        assertEquals("example.com", Matching.keyOf("example.com:8080/path"))
    }

    @Test fun appKeys() {
        assertEquals("com.instagram.android", Matching.keyOf("android://com.instagram.android"))
        assertEquals("com.facebook.katana", Matching.keyOf("android://AbCdHash==@com.facebook.katana/"))
    }

    @Test fun subdomainsMatch_butOtherSitesDont() {
        assertTrue(Matching.hostMatches("google.com", "accounts.google.com"))
        assertTrue(Matching.hostMatches("mail.google.com", "www.mail.google.com"))
        assertFalse(Matching.hostMatches("google.com", "evilgoogle.com"))
        assertFalse(Matching.hostMatches("google.com", "google.com.fake.in"))
    }
}

class ExportImportTest {
    private val sample = listOf(
        Entry(title = "Gmail", username = "rajeev@gmail.com", password = "Pass,with\"quote", url = "https://mail.google.com"),
        Entry(title = "Instagram", username = "rk_traveller", password = "Insta#2026", url = "android://com.instagram.android", notes = "line1\nline2"),
    )

    @Test fun entryJson_roundTrip() {
        assertEquals(sample, Entry.listFromJson(Entry.listToJson(sample)))
    }

    @Test fun encryptedExport_roundTrip() {
        val text = ExportImport.export(sample, "file-pass-123")
        assertTrue(ExportImport.isEncryptedExport(text))
        assertFalse(text.contains("Insta#2026"))          // no readable password in the file
        assertEquals(sample, ExportImport.decryptExport(text, "file-pass-123"))
    }

    @Test fun encryptedExport_wrongPasswordFails() {
        val text = ExportImport.export(sample, "file-pass-123")
        try { ExportImport.decryptExport(text, "nope"); fail("Wrong password worked") }
        catch (e: GeneralSecurityException) { /* expected */ }
    }

    @Test fun googlePasswordManagerCsv() {
        val csv = "name,url,username,password,note\r\n" +
            "mail.google.com,https://mail.google.com/,rajeev@gmail.com,\"a,b\"\"c\",\r\n" +
            "Instagram,android://hash@com.instagram.android/,rk,insta1,\"my\nnote\"\r\n" +
            "empty,https://x.com,user,,\r\n"
        val list = ExportImport.parseCsv("﻿" + csv)
        assertEquals(2, list.size)                          // row with empty password skipped
        assertEquals("a,b\"c", list[0].password)
        assertEquals("rajeev@gmail.com", list[0].username)
        assertEquals("my\nnote", list[1].notes)
        assertEquals("com.instagram.android", list[1].matchKey)
    }

    @Test fun bitwardenCsv() {
        val csv = "folder,favorite,type,name,notes,fields,reprompt,login_uri,login_username,login_password,login_totp\n" +
            ",,login,Amazon,,,0,https://www.amazon.in,raj@x.com,Amz@123,\n"
        val e = ExportImport.parseCsv(csv).single()
        assertEquals("Amazon", e.title); assertEquals("Amz@123", e.password); assertEquals("amazon.in", e.matchKey)
    }

    @Test fun plainCsvIsNotTreatedAsEncrypted() {
        assertFalse(ExportImport.isEncryptedExport("name,url,username,password\n"))
        assertNotEquals(0, ExportImport.parseCsv("title,username,password\nX,u,p\n").size)
    }
}

class RecoveryKeyTest {
    @Test fun generatedKey_hasSixGroupsOfFour() {
        val code = com.appforge.vault.crypto.RecoveryKey.generate()
        assertTrue(Regex("^[A-Z0-9]{4}(-[A-Z0-9]{4}){5}$").matches(code))
        assertNotEquals(code, com.appforge.vault.crypto.RecoveryKey.generate())
    }

    @Test fun typingIsForgiving() {
        val rk = com.appforge.vault.crypto.RecoveryKey
        val code = rk.generate()
        val messy = " " + code.lowercase().replace("-", " ") + " "
        assertEquals(rk.normalize(code), rk.normalize(messy))
        assertEquals(null, rk.normalize("ABCD-EFGH"))            // too short
    }

    @Test fun recoveryKeyUnlocksVaultKey_wrongKeyDoesNot() {
        val rk = com.appforge.vault.crypto.RecoveryKey
        val vaultKey = Crypto.randomBytes(32)
        val code = rk.generate()
        val (salt, wrapped) = rk.wrap(code, vaultKey)
        assertTrue(rk.unwrap(code.lowercase(), salt, wrapped).contentEquals(vaultKey))
        try { rk.unwrap(rk.generate(), salt, wrapped); fail("Wrong key worked") }
        catch (e: GeneralSecurityException) { /* expected */ }
        try { rk.unwrap("not a key", salt, wrapped); fail("Garbage worked") }
        catch (e: GeneralSecurityException) { /* expected */ }
    }

    @Test fun samePhoneKeyOpensBackupBlob() {
        // Simulates fingerprint recovery: the key on the phone must open the cloud backup.
        val raw = Crypto.randomBytes(32)
        val entries = listOf(Entry(title = "Gmail", username = "r@x.com", password = "p1"))
        val blob = Crypto.encrypt(Crypto.aesKey(raw), Entry.listToJson(entries).toByteArray())
        val opened = Entry.listFromJson(String(Crypto.decrypt(Crypto.aesKey(raw), blob)))
        assertEquals(entries, opened)
        try { Crypto.decrypt(Crypto.aesKey(Crypto.randomBytes(32)), blob); fail("Other phone's key worked") }
        catch (e: GeneralSecurityException) { /* expected */ }
    }
}

class GoogleLoginTest {
    @Test fun detectsGoogleSignIn() {
        val fp = com.appforge.vault.autofill.FieldParser
        assertTrue(fp.isGoogle("accounts.google.com", "com.android.chrome"))
        assertTrue(fp.isGoogle(null, "com.google.android.gms"))
        assertFalse(fp.isGoogle("accounts.google.com.evil.in", "com.android.chrome"))
        assertFalse(fp.isGoogle("example.com", "com.google.android.gms"))
    }

    @Test fun googleEntryMatchesGoogleSites() {
        val e = Entry(title = "Google account", username = "r@gmail.com", password = "x", url = "https://accounts.google.com")
        assertTrue(Matching.hostMatches(e.matchKey, "accounts.google.com"))
    }
}

class BrowserAddressBarTest {
    private val fp = com.appforge.vault.autofill.FieldParser

    @Test fun readsWebsiteFromAddressBar() {
        assertEquals("accounts.google.com", fp.hostFromUrlBar("https://accounts.google.com/v3/signin?x=1"))
        assertEquals("gmail.com", fp.hostFromUrlBar("www.gmail.com"))
        assertEquals("m.facebook.com", fp.hostFromUrlBar("m.facebook.com/login"))
        assertEquals("amazon.in", fp.hostFromUrlBar("HTTPS://WWW.AMAZON.IN"))
    }

    @Test fun ignoresSearchWordsAndJunk() {
        assertEquals(null, fp.hostFromUrlBar("gmail login"))
        assertEquals(null, fp.hostFromUrlBar("Search or type web address"))
        assertEquals(null, fp.hostFromUrlBar("192.168.1.1"))
        assertEquals(null, fp.hostFromUrlBar(""))
    }

    @Test fun jioBrowserIsInCompatibilityList() {
        assertTrue("com.jio.web" in fp.compatBrowsers)
        assertFalse("com.android.chrome" in fp.compatBrowsers)
    }
}
