# Coin Kamao — v1

Android rewards app: users watch rewarded videos, check in daily and invite friends to collect coins, then withdraw to UPI. You (admin) approve and pay each withdrawal by hand.

- Kotlin + Jetpack Compose (Material 3), minSdk 26, targetSdk 35
- Firebase Auth (Google sign-in) + Cloud Firestore (free Spark plan is enough)
- Google AdMob rewarded videos (Google TEST ads are set up now)
- Package: `com.rajeev.coinkamao`

## What's in v1

| Feature | Details |
|---|---|
| Rewarded videos | 5 coins per full video, 20 videos/day, 30 s gap between videos |
| Daily check-in | Day 1 = 10 coins, +5 each day, day 7 and after = 40. Missing a day restarts the streak |
| Refer a friend | Friend enters your code within 3 days of joining → friend gets 50. After the friend checks in on 3 different days, you claim 200 |
| Wallet | 100 coins = ₹1. Withdraw from ₹50 (5000 coins) to a UPI ID. One payout request at a time. Coin history + payout status (Pending / Paid with UTR / Rejected with reason) |
| Admin (hidden) | Only your Google account sees the Admin tab: pending payouts with total, copy UPI, "Pay in UPI app" button, Mark paid (with UTR), Reject (coins go back). Users tab: search by Gmail, see stats, Block / Unblock |
| Anti-cheat | One account per phone, daily video limit, cooldown, blocked users can't earn or withdraw. All limits are enforced by Firestore security rules, not only by the app |

## Setup (one time)

### 1. Firebase
1. Create a Firebase project (e.g. "Coin Kamao").
2. Add an **Android app** with package `com.rajeev.coinkamao`. Add the **SHA-1** of the key your GitHub pipeline signs with (same key as your other apps).
3. Download `google-services.json` and put it in the **`app/`** folder of this project, then zip and build.
   (Without it the app still builds, but sign-in shows "Google sign-in is not set up".)
4. **Authentication → Sign-in method → Google → Enable.**
5. **Firestore Database → Create database** (production mode, region `asia-south1` Mumbai).
6. **Firestore → Rules:** delete everything, paste the whole `firestore.rules` file from this project, click **Publish**. This step is important — the rules protect the coins.

### 2. Make yourself admin
1. Install the app and sign in once with your Google account.
2. Firebase console → **Authentication → Users** → copy your **User UID**.
3. **Firestore → Start collection** → collection ID `admins` → document ID = your UID → add any field, e.g. `name` (string) = `Rajeev`. Save.
4. Close and reopen the app. The **Admin** tab appears.

### 3. AdMob (before publishing)
Test ads work right away. For real money:
1. Create an AdMob account → add the app → create a **Rewarded** ad unit.
2. Replace the TEST App ID in `app/src/main/AndroidManifest.xml` (`com.google.android.gms.ads.APPLICATION_ID`).
3. Replace the TEST ad unit in `app/src/main/java/com/rajeev/coinkamao/ads/RewardedAds.kt` (`AdIds.REWARDED`).
4. Never click your own real ads — AdMob can ban the account. Keep test ads while testing.

## Paying users (daily routine)
1. Admin tab → Payouts. Tap **Check user** to see their stats (videos, check-ins, join date). Very fast earners or many accounts from same UPI = suspicious.
2. Tap **Pay in UPI app** (opens GPay/PhonePe with UPI ID and amount filled) or copy the UPI ID.
3. After the money is sent, tap **Mark paid** and paste the UTR.
4. If it looks like cheating: **Reject** (coins return) and/or block the user.

## Changing the coin numbers
The numbers live in **two places that must match**:
- `app/src/main/java/com/rajeev/coinkamao/data/Rules.kt`
- top of `firestore.rules` (then Publish the rules again)

Rough maths: in India a rewarded video earns you about ₹0.08–0.25. At 5 coins (₹0.05) per video you give users roughly 20–60% of ad income. Check your real AdMob eCPM after the first weeks and adjust.

## Firestore data
- `users/{uid}` — coins, streak, ads today, referral code, UPI, blocked
- `users/{uid}/history` — coin history
- `withdrawals/{id}` — payout requests (`pending` / `paid` / `rejected`)
- `referrals/{friendUid}` — who invited whom + friend's check-in progress
- `referralCodes/{code}`, `devices/{phoneId}`, `admins/{uid}`

To allow a second account on a phone (e.g. a family member's old phone), delete that phone's doc in `devices`.

## Play Store notes
- Data safety: collects name, email, device ID (fraud prevention), UPI ID (payouts); ads by AdMob.
- Declare "Contains ads". Content rating questionnaire as normal.
- Write clear payout terms in the store listing (minimum ₹50, manual review, 2–3 days).
