# Minify is off for v1. Rules kept here for later.
-keep class com.rajeev.coinkamao.data.** { *; }
