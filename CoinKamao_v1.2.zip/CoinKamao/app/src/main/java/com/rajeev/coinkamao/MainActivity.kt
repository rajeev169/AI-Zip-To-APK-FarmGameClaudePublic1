package com.rajeev.coinkamao

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.rajeev.coinkamao.ui.AppRoot
import com.rajeev.coinkamao.ui.AppViewModel
import com.rajeev.coinkamao.ui.theme.CoinTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CoinTheme { AppRoot(vm) }
        }
    }
}
