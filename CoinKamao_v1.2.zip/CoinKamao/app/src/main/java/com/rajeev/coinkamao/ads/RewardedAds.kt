package com.rajeev.coinkamao.ads

import android.app.Activity
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

object AdIds {
    // Google's official TEST rewarded ad unit. Replace with your own AdMob
    // rewarded ad unit ID before publishing (and the App ID in AndroidManifest.xml).
    const val REWARDED = "ca-app-pub-3940256099942544/5224354917"
}

/** Loads and shows one rewarded video at a time. */
class RewardedAds(private val appContext: Context) {
    private var ad: RewardedAd? = null

    var isLoading by mutableStateOf(false)
        private set
    var isReady by mutableStateOf(false)
        private set
    var lastError by mutableStateOf<String?>(null)
        private set

    fun load() {
        if (isLoading || ad != null) return
        isLoading = true
        lastError = null
        RewardedAd.load(appContext, AdIds.REWARDED, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(loaded: RewardedAd) {
                    ad = loaded
                    isLoading = false
                    isReady = true
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    ad = null
                    isLoading = false
                    isReady = false
                    lastError = if (error.code == AdRequest.ERROR_CODE_NO_FILL)
                        "No video available right now. Try again in a few minutes."
                    else "Video failed to load. Check internet and try again."
                }
            })
    }

    /**
     * Shows the video. [onEarned] runs only if the user watched it fully.
     * [onClosed] runs when the video screen closes (earned or not).
     */
    fun show(activity: Activity, onEarned: () -> Unit, onClosed: () -> Unit) {
        val current = ad ?: run { load(); return }
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                ad = null
                isReady = false
                onClosed()
                load()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                ad = null
                isReady = false
                lastError = "Video could not play. Try again."
                onClosed()
                load()
            }
        }
        current.show(activity) { onEarned() }
    }
}
