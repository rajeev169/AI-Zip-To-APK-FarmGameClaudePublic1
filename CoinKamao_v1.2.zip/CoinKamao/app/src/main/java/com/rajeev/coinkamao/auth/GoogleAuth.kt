package com.rajeev.coinkamao.auth

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.rajeev.coinkamao.data.AppException
import kotlinx.coroutines.tasks.await

object GoogleAuth {

    /** Web client ID that the google-services plugin generates from google-services.json. */
    @SuppressLint("DiscouragedApi")
    private fun webClientId(context: Context): String {
        val id = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        if (id == 0) throw AppException(
            "Google sign-in is not set up. Add google-services.json to the app folder and rebuild."
        )
        return context.getString(id)
    }

    /** Returns true when signed in, false when the user cancelled. */
    suspend fun signIn(activity: Activity): Boolean {
        val option = GetSignInWithGoogleOption.Builder(webClientId(activity)).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = try {
            CredentialManager.create(activity).getCredential(activity, request)
        } catch (e: GetCredentialCancellationException) {
            return false
        }
        val cred = result.credential
        if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            val google = GoogleIdTokenCredential.createFrom(cred.data)
            val firebaseCred = GoogleAuthProvider.getCredential(google.idToken, null)
            FirebaseAuth.getInstance().signInWithCredential(firebaseCred).await()
            return true
        }
        throw AppException("Unsupported sign-in type.")
    }

    suspend fun signOut(context: Context) {
        FirebaseAuth.getInstance().signOut()
        try {
            CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
        } catch (_: Exception) {
        }
    }
}
