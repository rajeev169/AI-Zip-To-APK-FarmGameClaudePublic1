package com.rajeev.coinkamao.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot

data class UserDoc(
    val uid: String,
    val name: String,
    val email: String,
    val photoUrl: String,
    val points: Long,
    val totalEarned: Long,
    val adsToday: Long,
    val adsDay: Long,
    val lastAdAt: Timestamp?,
    val streak: Long,
    val lastCheckInDay: Long,
    val checkInCount: Long,
    val referralCode: String,
    val referredBy: String?,
    val deviceId: String,
    val blocked: Boolean,
    val pendingWithdrawal: Boolean,
    val createdAt: Timestamp?,
    val upiId: String,
    val lastClaimedReferral: String,
    val lastWithdrawalId: String,
) {
    fun adsDoneToday(today: Long): Long = if (adsDay == today) adsToday else 0L
    fun checkedInToday(today: Long): Boolean = lastCheckInDay == today

    /** Streak that is still alive today (0 if a day was missed). */
    fun liveStreak(today: Long): Long =
        if (lastCheckInDay == today || lastCheckInDay == today - 1) streak else 0L

    /** Streak number the next check-in would give. */
    fun nextStreak(today: Long): Long = if (lastCheckInDay == today - 1) streak + 1 else 1L
}

data class Withdrawal(
    val id: String,
    val uid: String,
    val name: String,
    val email: String,
    val points: Long,
    val amount: Long,
    val upiId: String,
    val status: String,
    val createdAt: Timestamp?,
    val processedAt: Timestamp?,
    val note: String,
    val utr: String,
)

data class Referral(
    val id: String,
    val referrerUid: String,
    val newUid: String,
    val newName: String,
    val status: String,
    val friendCheckIns: Long,
    val createdAt: Timestamp?,
)

data class HistoryItem(
    val id: String,
    val type: String,
    val points: Long,
    val note: String,
    val at: Timestamp?,
)

private fun DocumentSnapshot.str(k: String) = getString(k) ?: ""
private fun DocumentSnapshot.num(k: String) = getLong(k) ?: 0L

fun DocumentSnapshot.toUser(): UserDoc = UserDoc(
    uid = id,
    name = str("name"),
    email = str("email"),
    photoUrl = str("photoUrl"),
    points = num("points"),
    totalEarned = num("totalEarned"),
    adsToday = num("adsToday"),
    adsDay = num("adsDay"),
    lastAdAt = getTimestamp("lastAdAt"),
    streak = num("streak"),
    lastCheckInDay = num("lastCheckInDay"),
    checkInCount = num("checkInCount"),
    referralCode = str("referralCode"),
    referredBy = getString("referredBy"),
    deviceId = str("deviceId"),
    blocked = getBoolean("blocked") ?: false,
    pendingWithdrawal = getBoolean("pendingWithdrawal") ?: false,
    createdAt = getTimestamp("createdAt"),
    upiId = str("upiId"),
    lastClaimedReferral = str("lastClaimedReferral"),
    lastWithdrawalId = str("lastWithdrawalId"),
)

fun DocumentSnapshot.toWithdrawal(): Withdrawal = Withdrawal(
    id = id,
    uid = str("uid"),
    name = str("name"),
    email = str("email"),
    points = num("points"),
    amount = num("amount"),
    upiId = str("upiId"),
    status = str("status"),
    createdAt = getTimestamp("createdAt"),
    processedAt = getTimestamp("processedAt"),
    note = str("note"),
    utr = str("utr"),
)

fun DocumentSnapshot.toReferral(): Referral = Referral(
    id = id,
    referrerUid = str("referrerUid"),
    newUid = str("newUid"),
    newName = str("newName"),
    status = str("status"),
    friendCheckIns = num("friendCheckIns"),
    createdAt = getTimestamp("createdAt"),
)

fun DocumentSnapshot.toHistory(): HistoryItem = HistoryItem(
    id = id,
    type = str("type"),
    points = num("points"),
    note = str("note"),
    at = getTimestamp("at"),
)
