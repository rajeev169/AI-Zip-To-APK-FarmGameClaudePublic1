package com.rajeev.coinkamao.data

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.Source
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest

class DeviceUsedException : Exception("This phone is already linked to another account.")
class AppException(message: String) : Exception(message)

object Repo {
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private fun users() = db.collection("users")
    private fun userRef(uid: String) = users().document(uid)
    private fun historyRef(uid: String) = userRef(uid).collection("history")

    // ---------------- Setup ----------------

    @SuppressLint("HardwareIds")
    fun deviceId(context: Context): String {
        val raw = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val hash = MessageDigest.getInstance("SHA-256").digest(("coinkamao:$raw").toByteArray())
        return hash.joinToString("") { "%02x".format(it) }.take(32)
    }

    private fun newReferralCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..7).map { chars.random() }.joinToString("")
    }

    /** Creates the user's account doc the first time. Throws DeviceUsedException if the phone has another account. */
    suspend fun ensureUser(context: Context, user: FirebaseUser) {
        val ref = userRef(user.uid)
        if (ref.get().await().exists()) return

        val devId = deviceId(context)
        val devRef = db.collection("devices").document(devId)
        val devSnap = devRef.get().await()
        if (devSnap.exists() && devSnap.getString("uid") != user.uid) throw DeviceUsedException()

        var lastError: Exception? = null
        repeat(4) {
            val code = newReferralCode()
            try {
                val batch = db.batch()
                if (!devSnap.exists()) {
                    batch.set(devRef, mapOf("uid" to user.uid, "createdAt" to FieldValue.serverTimestamp()))
                }
                batch.set(db.collection("referralCodes").document(code), mapOf("uid" to user.uid))
                batch.set(
                    ref, mapOf(
                        "uid" to user.uid,
                        "name" to (user.displayName ?: "User").take(80),
                        "email" to (user.email ?: ""),
                        "photoUrl" to (user.photoUrl?.toString() ?: ""),
                        "points" to 0L,
                        "totalEarned" to 0L,
                        "adsToday" to 0L,
                        "adsDay" to 0L,
                        "lastAdAt" to FieldValue.serverTimestamp(),
                        "streak" to 0L,
                        "lastCheckInDay" to 0L,
                        "checkInCount" to 0L,
                        "referralCode" to code,
                        "referredBy" to null,
                        "deviceId" to devId,
                        "blocked" to false,
                        "pendingWithdrawal" to false,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "lastSeen" to FieldValue.serverTimestamp(),
                        "upiId" to "",
                        "lastClaimedReferral" to "",
                        "lastWithdrawalId" to "",
                    )
                )
                batch.commit().await()
                return
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw lastError ?: AppException("Could not create your account. Try again.")
    }

    /** Returns (server time - phone time) in ms, so day counting matches Firebase. */
    suspend fun serverTimeOffset(uid: String): Long {
        val ref = userRef(uid)
        ref.update("lastSeen", FieldValue.serverTimestamp()).await()
        val snap = ref.get(Source.SERVER).await()
        val server = snap.getTimestamp("lastSeen")?.toDate()?.time ?: return 0L
        return server - System.currentTimeMillis()
    }

    suspend fun isAdmin(uid: String): Boolean = try {
        db.collection("admins").document(uid).get(Source.SERVER).await().exists()
    } catch (e: Exception) {
        false
    }

    // ---------------- Live data ----------------

    fun observeUser(uid: String): Flow<UserDoc?> = callbackFlow {
        val reg = userRef(uid).addSnapshotListener { snap, _ ->
            trySend(if (snap != null && snap.exists()) snap.toUser() else null)
        }
        awaitClose { reg.remove() }
    }

    fun observeMyWithdrawals(uid: String): Flow<List<Withdrawal>> = callbackFlow {
        val reg = db.collection("withdrawals").whereEqualTo("uid", uid)
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { it.toWithdrawal() }
                    ?.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } ?: emptyList()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    fun observeHistory(uid: String): Flow<List<HistoryItem>> = callbackFlow {
        val reg = historyRef(uid).orderBy("at", Query.Direction.DESCENDING).limit(50)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.documents?.map { it.toHistory() } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeMyReferrals(uid: String): Flow<List<Referral>> = callbackFlow {
        val reg = db.collection("referrals").whereEqualTo("referrerUid", uid)
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { it.toReferral() }
                    ?.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } ?: emptyList()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    // ---------------- Earning ----------------

    private fun historyMap(type: String, points: Long, note: String) = mapOf(
        "type" to type, "points" to points, "note" to note, "at" to FieldValue.serverTimestamp()
    )

    suspend fun rewardAd(u: UserDoc, today: Long) {
        val batch = db.batch()
        batch.update(
            userRef(u.uid), mapOf(
                "points" to FieldValue.increment(Rules.AD_POINTS),
                "totalEarned" to FieldValue.increment(Rules.AD_POINTS),
                "adsToday" to if (u.adsDay == today) FieldValue.increment(1) else 1L,
                "adsDay" to today,
                "lastAdAt" to FieldValue.serverTimestamp(),
            )
        )
        batch.set(historyRef(u.uid).document(), historyMap("ad", Rules.AD_POINTS, "Watched a video"))
        batch.commit().await()
    }

    suspend fun checkIn(u: UserDoc, today: Long) {
        val streak = u.nextStreak(today)
        val reward = Rules.checkInReward(streak)
        val batch = db.batch()
        batch.update(
            userRef(u.uid), mapOf(
                "points" to FieldValue.increment(reward),
                "totalEarned" to FieldValue.increment(reward),
                "streak" to streak,
                "lastCheckInDay" to today,
                "checkInCount" to FieldValue.increment(1),
            )
        )
        batch.set(historyRef(u.uid).document(), historyMap("checkin", reward, "Daily check-in (day $streak)"))
        batch.commit().await()

        // Tell the friend who invited us how active we are (best effort)
        if (u.referredBy != null) {
            try {
                db.collection("referrals").document(u.uid)
                    .update("friendCheckIns", u.checkInCount + 1).await()
            } catch (_: Exception) {
            }
        }
    }

    suspend fun applyReferralCode(u: UserDoc, rawCode: String) {
        val code = rawCode.trim().uppercase()
        if (code.length < 6) throw AppException("Enter a valid code.")
        if (code == u.referralCode) throw AppException("You can't use your own code.")
        val codeSnap = db.collection("referralCodes").document(code).get().await()
        val referrerUid = codeSnap.getString("uid") ?: throw AppException("This code doesn't exist.")
        if (referrerUid == u.uid) throw AppException("You can't use your own code.")

        val batch = db.batch()
        batch.set(
            db.collection("referrals").document(u.uid), mapOf(
                "referrerUid" to referrerUid,
                "newUid" to u.uid,
                "newName" to u.name.take(80),
                "status" to "pending",
                "friendCheckIns" to u.checkInCount,
                "createdAt" to FieldValue.serverTimestamp(),
                "claimedAt" to null,
            )
        )
        batch.update(
            userRef(u.uid), mapOf(
                "referredBy" to referrerUid,
                "points" to FieldValue.increment(Rules.JOIN_BONUS),
                "totalEarned" to FieldValue.increment(Rules.JOIN_BONUS),
            )
        )
        batch.set(historyRef(u.uid).document(), historyMap("join", Rules.JOIN_BONUS, "Joined with code $code"))
        batch.commit().await()
    }

    suspend fun claimReferral(u: UserDoc, r: Referral) {
        val batch = db.batch()
        batch.update(
            db.collection("referrals").document(r.id), mapOf(
                "status" to "claimed",
                "claimedAt" to FieldValue.serverTimestamp(),
            )
        )
        batch.update(
            userRef(u.uid), mapOf(
                "points" to FieldValue.increment(Rules.REF_BONUS),
                "totalEarned" to FieldValue.increment(Rules.REF_BONUS),
                "lastClaimedReferral" to r.id,
            )
        )
        batch.set(
            historyRef(u.uid).document(),
            historyMap("referral", Rules.REF_BONUS, "Friend bonus: ${r.newName}".take(100))
        )
        batch.commit().await()
    }

    // ---------------- Wallet ----------------

    suspend fun saveUpi(uid: String, upi: String) {
        userRef(uid).update("upiId", upi.trim()).await()
    }

    suspend fun requestWithdrawal(u: UserDoc, coins: Long, upi: String) {
        val wRef = db.collection("withdrawals").document()
        val batch = db.batch()
        batch.set(
            wRef, mapOf(
                "uid" to u.uid,
                "name" to u.name,
                "email" to u.email,
                "points" to coins,
                "amount" to coins / Rules.COINS_PER_RUPEE,
                "upiId" to upi.trim(),
                "status" to "pending",
                "createdAt" to FieldValue.serverTimestamp(),
                "processedAt" to null,
                "note" to "",
                "utr" to "",
            )
        )
        batch.update(
            userRef(u.uid), mapOf(
                "points" to FieldValue.increment(-coins),
                "pendingWithdrawal" to true,
                "lastWithdrawalId" to wRef.id,
                "upiId" to upi.trim(),
            )
        )
        batch.set(
            historyRef(u.uid).document(),
            historyMap("withdraw", -coins, "Withdrawal request ₹${coins / Rules.COINS_PER_RUPEE}")
        )
        batch.commit().await()
    }

    // ---------------- Admin ----------------

    fun observePendingWithdrawals(): Flow<List<Withdrawal>> = callbackFlow {
        val reg = db.collection("withdrawals").whereEqualTo("status", "pending")
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { it.toWithdrawal() }
                    ?.sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE } ?: emptyList()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    suspend fun markPaid(w: Withdrawal, utr: String) {
        val batch = db.batch()
        batch.update(
            db.collection("withdrawals").document(w.id), mapOf(
                "status" to "paid",
                "utr" to utr.trim(),
                "processedAt" to FieldValue.serverTimestamp(),
            )
        )
        batch.update(userRef(w.uid), "pendingWithdrawal", false)
        batch.set(historyRef(w.uid).document(), historyMap("paid", 0L, "₹${w.amount} sent to ${w.upiId}"))
        batch.commit().await()
    }

    suspend fun rejectWithdrawal(w: Withdrawal, reason: String) {
        val batch = db.batch()
        batch.update(
            db.collection("withdrawals").document(w.id), mapOf(
                "status" to "rejected",
                "note" to reason.trim(),
                "processedAt" to FieldValue.serverTimestamp(),
            )
        )
        batch.update(
            userRef(w.uid), mapOf(
                "pendingWithdrawal" to false,
                "points" to FieldValue.increment(w.points),
            )
        )
        batch.set(historyRef(w.uid).document(), historyMap("refund", w.points, "Withdrawal rejected — coins returned"))
        batch.commit().await()
    }

    suspend fun findUserByEmail(email: String): UserDoc? {
        val snap = users().whereEqualTo("email", email.trim().lowercase()).limit(1).get(Source.SERVER).await()
        val doc = snap.documents.firstOrNull()
            ?: users().whereEqualTo("email", email.trim()).limit(1).get(Source.SERVER).await().documents.firstOrNull()
        return doc?.toUser()
    }

    suspend fun getUser(uid: String): UserDoc? =
        userRef(uid).get(Source.SERVER).await().takeIf { it.exists() }?.toUser()

    suspend fun setBlocked(uid: String, blocked: Boolean) {
        userRef(uid).update("blocked", blocked).await()
    }

    fun friendlyError(e: Throwable): String = when {
        e is DeviceUsedException || e is AppException -> e.message ?: "Something went wrong."
        e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED ->
            "Not allowed right now. Please wait a moment and try again."
        e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.UNAVAILABLE ->
            "No internet connection. Please try again."
        else -> e.message ?: "Something went wrong."
    }
}
