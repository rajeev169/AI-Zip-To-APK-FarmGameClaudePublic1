package com.rajeev.coinkamao.data

import java.util.Locale

/**
 * Earning numbers. These MUST match the numbers at the top of firestore.rules,
 * otherwise Firebase will reject the coin updates.
 */
object Rules {
    const val AD_POINTS = 5L            // coins per rewarded video
    const val AD_LIMIT = 20L            // videos per day
    const val AD_COOLDOWN_SEC = 30L     // app waits 30s (rules allow 25s)
    const val JOIN_BONUS = 50L          // friend gets this for using a code
    const val REF_BONUS = 200L          // you get this when friend is active
    const val REF_DAYS = 3L             // friend check-in days needed
    const val REF_CODE_WINDOW_DAYS = 3L // new user can enter a code within 3 days
    const val MIN_WITHDRAW = 5000L      // coins (= Rs 50)
    const val COINS_PER_RUPEE = 100L

    /** Check-in coins for a streak day: day1 10, day2 15 ... day7 and after 40. */
    fun checkInReward(streak: Long): Long = if (streak >= 7) 40L else 5L + streak * 5L

    /** Day number in India time (UTC+5:30) — same formula as the rules. */
    fun dayNumber(millis: Long): Long = Math.floorDiv(millis + 19_800_000L, 86_400_000L)

    fun rupees(coins: Long): String =
        "₹" + String.format(Locale.US, "%.2f", coins.toDouble() / COINS_PER_RUPEE)

    fun rupeesWhole(coins: Long): Long = coins / COINS_PER_RUPEE
}
