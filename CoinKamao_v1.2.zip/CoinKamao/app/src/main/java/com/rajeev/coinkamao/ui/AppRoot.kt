package com.rajeev.coinkamao.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.coinkamao.data.Rules
import com.rajeev.coinkamao.ui.screens.AdminScreen
import com.rajeev.coinkamao.ui.screens.EarnScreen
import com.rajeev.coinkamao.ui.screens.ReferScreen
import com.rajeev.coinkamao.ui.screens.WalletScreen
import com.rajeev.coinkamao.ui.theme.Gold
import com.rajeev.coinkamao.ui.theme.GoldDeep

fun Context.findActivity(): Activity? {
    var c = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun AppRoot(vm: AppViewModel) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(it) }
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when (val s = vm.screen) {
            Screen.Loading -> Centered { CircularProgressIndicator() }
            Screen.SignedOut -> SignInScreen(vm, snackbar)
            Screen.DeviceUsed -> MessageScreen(
                title = "Phone already in use",
                body = "This phone is already linked to another Coin Kamao account. " +
                    "Only one account is allowed per phone. Sign in with that account instead.",
                button = "Sign out", onClick = vm::signOut
            )
            is Screen.Error -> MessageScreen(
                title = "Couldn't connect",
                body = s.message,
                button = "Try again", onClick = vm::retry,
                secondButton = "Sign out", onSecondClick = vm::signOut
            )
            Screen.Ready -> MainScaffold(vm, snackbar)
        }
    }
}

@Composable
fun Centered(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun CoinIcon(size: Int = 24) {
    Canvas(Modifier.size(size.dp)) {
        val r = this.size.minDimension / 2
        drawCircle(GoldDeep, r)
        drawCircle(Gold, r * 0.82f)
        drawCircle(GoldDeep, r * 0.52f, style = androidx.compose.ui.graphics.drawscope.Stroke(width = r * 0.12f))
        drawCircle(GoldDeep, r * 0.12f, center = Offset(center.x, center.y))
    }
}

@Composable
private fun MessageScreen(
    title: String, body: String, button: String, onClick: () -> Unit,
    secondButton: String? = null, onSecondClick: (() -> Unit)? = null
) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(body, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onClick) { Text(button) }
        if (secondButton != null && onSecondClick != null) {
            TextButton(onClick = onSecondClick) { Text(secondButton) }
        }
    }
}

@Composable
private fun SignInScreen(vm: AppViewModel, snackbar: SnackbarHostState) {
    val activity = LocalContext.current.findActivity()
    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CoinIcon(96)
            Spacer(Modifier.height(24.dp))
            Text("Coin Kamao", fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Watch videos, check in daily and invite friends.\nCollect coins and withdraw to UPI.",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(40.dp))
            Button(
                onClick = { activity?.let { vm.signIn(it) } },
                enabled = !vm.signingIn,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                if (vm.signingIn) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                else Text("Continue with Google", fontSize = 16.sp)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "${Rules.COINS_PER_RUPEE} coins = ₹1 · Minimum withdrawal ₹${Rules.MIN_WITHDRAW / Rules.COINS_PER_RUPEE}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private data class Tab(val label: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScaffold(vm: AppViewModel, snackbar: SnackbarHostState) {
    val tabs = buildList {
        add(Tab("Earn", Icons.Filled.PlayCircle))
        add(Tab("Refer", Icons.Filled.Groups))
        add(Tab("Wallet", Icons.Filled.AccountBalanceWallet))
        if (vm.isAdmin) add(Tab("Admin", Icons.Filled.AdminPanelSettings))
    }
    var selected by rememberSaveable { mutableIntStateOf(0) }
    if (selected >= tabs.size) selected = 0
    var menu by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var confirmSignOut by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Coin Kamao", fontWeight = FontWeight.Bold) },
                actions = {
                    vm.user?.let { u ->
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Row(
                                Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CoinIcon(18)
                                Spacer(Modifier.width(6.dp))
                                Text("${u.points}", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("How it works") },
                                leadingIcon = { Icon(Icons.Filled.Info, null) },
                                onClick = { menu = false; showHelp = true })
                            DropdownMenuItem(
                                text = { Text("Sign out") },
                                leadingIcon = { Icon(Icons.AutoMirrored.Filled.Logout, null) },
                                onClick = { menu = false; confirmSignOut = true })
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = selected == i,
                        onClick = { selected = i },
                        icon = { Icon(t.icon, null) },
                        label = { Text(t.label) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tabs[selected].label) {
                "Earn" -> EarnScreen(vm)
                "Refer" -> ReferScreen(vm)
                "Wallet" -> WalletScreen(vm)
                "Admin" -> AdminScreen(vm)
            }
        }
    }

    if (showHelp) HowItWorksDialog { showHelp = false }
    if (confirmSignOut) {
        AlertDialog(
            onDismissRequest = { confirmSignOut = false },
            title = { Text("Sign out?") },
            text = { Text("Your coins stay safe in your account.") },
            confirmButton = { TextButton(onClick = { confirmSignOut = false; vm.signOut() }) { Text("Sign out") } },
            dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun HowItWorksDialog(onDismiss: () -> Unit) {
    val r = Rules
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("How it works") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                HelpLine("Watch videos", "Get ${r.AD_POINTS} coins for each full video, up to ${r.AD_LIMIT} videos a day.")
                HelpLine("Daily check-in", "Day 1 gives 10 coins and grows every day up to 40 coins on day 7. Miss a day and the streak starts again.")
                HelpLine("Invite friends", "Your friend gets ${r.JOIN_BONUS} coins for using your code. You get ${r.REF_BONUS} coins after they check in on ${r.REF_DAYS} different days.")
                HelpLine("Withdraw", "${r.COINS_PER_RUPEE} coins = ₹1. From ₹${r.MIN_WITHDRAW / r.COINS_PER_RUPEE} you can request a UPI payout. Payouts are checked and sent by hand, usually within 2–3 days.")
                HelpLine("Fair play", "One account per phone. Fake accounts, emulators or tricks lead to a block and loss of coins.")
                HelpLine("Privacy", "We store your Google name, email, a phone ID for fraud checks, your coins and UPI ID. Videos are served by Google AdMob.")
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Got it") } }
    )
}

@Composable
private fun HelpLine(title: String, body: String) {
    Text(title, fontWeight = FontWeight.SemiBold)
    Text(body, style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(12.dp))
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
    )
}

@Composable
fun SmallOutlined(text: String, onClick: () -> Unit, enabled: Boolean = true) {
    OutlinedButton(onClick = onClick, enabled = enabled) { Text(text) }
}
