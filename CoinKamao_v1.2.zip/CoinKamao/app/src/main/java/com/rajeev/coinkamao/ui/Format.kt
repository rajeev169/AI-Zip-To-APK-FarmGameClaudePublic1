package com.rajeev.coinkamao.ui

import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Locale

private val fmt = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.ENGLISH)

fun Timestamp?.pretty(): String = this?.let { fmt.format(it.toDate()) } ?: "just now"
