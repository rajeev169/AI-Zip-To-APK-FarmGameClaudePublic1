package com.rajeev.coinkamao.ui.screens

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.rajeev.coinkamao.data.Rules
import com.rajeev.coinkamao.data.UserDoc
import com.rajeev.coinkamao.data.Withdrawal
import com.rajeev.coinkamao.ui.AppViewModel
import com.rajeev.coinkamao.ui.pretty

@Composable
fun AdminScreen(vm: AppViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Payouts (${vm.pendingPayouts.size})") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Users") })
        }
        when (tab) {
            0 -> PayoutsTab(vm, onOpenUser = { uid -> vm.openUserFromPayout(uid); tab = 1 })
            else -> UsersTab(vm)
        }
    }
}

@Composable
private fun PayoutsTab(vm: AppViewModel, onOpenUser: (String) -> Unit) {
    val ctx = LocalContext.current
    var payTarget by remember { mutableStateOf<Withdrawal?>(null) }
    var rejectTarget by remember { mutableStateOf<Withdrawal?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        val total = vm.pendingPayouts.sumOf { it.amount }
        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("${vm.pendingPayouts.size} pending payouts", fontWeight = FontWeight.SemiBold)
                Text("Total to pay: ₹$total", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    "Check each user before paying. Coins are already taken; Reject returns them.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        if (vm.pendingPayouts.isEmpty()) {
            Text("No pending payouts. 🎉", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        vm.pendingPayouts.forEach { w ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("₹${w.amount}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("${w.points} coins", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(w.name, fontWeight = FontWeight.SemiBold)
                    Text(w.email, style = MaterialTheme.typography.bodySmall)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("UPI: ${w.upiId}", modifier = Modifier.weight(1f))
                        IconButton(onClick = { copy(ctx, w.upiId) }) { Icon(Icons.Filled.ContentCopy, "Copy UPI") }
                    }
                    Text("Requested ${w.createdAt.pretty()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onOpenUser(w.uid) }) { Text("Check user") }
                        OutlinedButton(onClick = { openUpiApp(ctx, w) }) { Text("Pay in UPI app") }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { payTarget = w }, enabled = !vm.busy, modifier = Modifier.weight(1f)) {
                            Text("Mark paid")
                        }
                        Button(
                            onClick = { rejectTarget = w },
                            enabled = !vm.busy,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f)
                        ) { Text("Reject") }
                    }
                }
            }
        }
    }

    payTarget?.let { w ->
        var utr by remember(w.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { payTarget = null },
            title = { Text("Mark ₹${w.amount} as paid?") },
            text = {
                Column {
                    Text("Only do this after the money has been sent to ${w.upiId}.")
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = utr, onValueChange = { utr = it.take(40) },
                        label = { Text("UTR / reference (optional)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
            },
            confirmButton = { TextButton(onClick = { vm.markPaid(w, utr); payTarget = null }) { Text("Mark paid") } },
            dismissButton = { TextButton(onClick = { payTarget = null }) { Text("Cancel") } }
        )
    }

    rejectTarget?.let { w ->
        var reason by remember(w.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { rejectTarget = null },
            title = { Text("Reject ₹${w.amount}?") },
            text = {
                Column {
                    Text("${w.points} coins go back to the user.")
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = reason, onValueChange = { reason = it.take(100) },
                        label = { Text("Reason (user will see it)") }
                    )
                }
            },
            confirmButton = { TextButton(onClick = { vm.reject(w, reason); rejectTarget = null }) { Text("Reject") } },
            dismissButton = { TextButton(onClick = { rejectTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun UsersTab(vm: AppViewModel) {
    var email by rememberSaveable { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = email, onValueChange = { email = it.trim() },
                label = { Text("User's Gmail") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.searchUser(email) }, enabled = email.contains("@") && !vm.busy) { Text("Find") }
        }
        val found = vm.adminFoundUser
        if (found != null) UserCard(vm, found)
        else if (vm.adminSearchDone) Text("No user found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun UserCard(vm: AppViewModel, u: UserDoc) {
    var confirm by remember { mutableStateOf(false) }
    val today = vm.today()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(u.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(u.email, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
            Info("Coins now", "${u.points} (${Rules.rupees(u.points)})")
            Info("Total earned", "${u.totalEarned}")
            Info("Videos today", "${u.adsDoneToday(today)} / ${Rules.AD_LIMIT}")
            Info("Check-in days", "${u.checkInCount} (streak ${u.liveStreak(today)})")
            Info("Joined", u.createdAt.pretty())
            Info("Referral code", u.referralCode)
            Info("Invited by", if (u.referredBy == null) "—" else "yes")
            Info("UPI", u.upiId.ifBlank { "—" })
            Info("Payout pending", if (u.pendingWithdrawal) "yes" else "no")
            Info("Status", if (u.blocked) "BLOCKED" else "active")
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { confirm = true },
                enabled = !vm.busy,
                colors = if (u.blocked) ButtonDefaults.buttonColors()
                else ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (u.blocked) "Unblock user" else "Block user") }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(if (u.blocked) "Unblock ${u.name}?" else "Block ${u.name}?") },
            text = {
                Text(
                    if (u.blocked) "They can earn and withdraw again."
                    else "They won't be able to earn or withdraw. Reject their pending payout separately if needed."
                )
            },
            confirmButton = { TextButton(onClick = { confirm = false; vm.setBlocked(u, !u.blocked) }) { Text("Yes") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun Info(label: String, value: String) {
    Row {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.Medium)
    }
}

private fun copy(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("UPI", text))
    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
}

private fun openUpiApp(ctx: Context, w: Withdrawal) {
    val uri = Uri.Builder().scheme("upi").authority("pay")
        .appendQueryParameter("pa", w.upiId)
        .appendQueryParameter("pn", w.name.ifBlank { "Coin Kamao user" })
        .appendQueryParameter("am", "${w.amount}.00")
        .appendQueryParameter("cu", "INR")
        .appendQueryParameter("tn", "Coin Kamao payout")
        .build()
    try {
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW, uri), "Pay with"))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No UPI app found", Toast.LENGTH_SHORT).show()
    }
}
