package com.rajeev.coinkamao.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.coinkamao.data.Rules
import com.rajeev.coinkamao.ui.AppViewModel
import com.rajeev.coinkamao.ui.CoinIcon
import com.rajeev.coinkamao.ui.findActivity
import kotlinx.coroutines.delay

@Composable
fun EarnScreen(vm: AppViewModel) {
    val u = vm.user ?: return
    val activity = LocalContext.current.findActivity()

    // ticks every second for the cooldown timer and day change
    var now by remember { mutableLongStateOf(vm.nowMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = vm.nowMillis()
            delay(1000)
        }
    }
    val today = Rules.dayNumber(now)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (u.blocked) BlockedBanner()

        BalanceCard(u.points)

        // ---------- Daily check-in ----------
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Daily check-in", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                val live = u.liveStreak(today)
                Text(
                    if (live > 0) "$live day streak 🔥" else "Start your streak today",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(14.dp))
                val done = u.checkedInToday(today)
                // which of the 7 bubbles is "today"
                val cyclePos = if (done) ((live - 1) % 7) + 1 else ((u.nextStreak(today) - 1) % 7) + 1
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    for (d in 1L..7L) {
                        val reward = Rules.checkInReward(d)
                        val filled = if (done) d <= cyclePos else d < cyclePos
                        val isToday = d == cyclePos
                        DayBubble(d, reward, filled, isToday && !done)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = vm::checkIn,
                    enabled = !done && !vm.busy && !u.blocked,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (done) "Checked in ✓  Come back tomorrow"
                        else "Claim +${Rules.checkInReward(u.nextStreak(today))} coins"
                    )
                }
            }
        }

        // ---------- Rewarded videos ----------
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Watch a video", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            "+${Rules.AD_POINTS} coins for each full video",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    CoinIcon(36)
                }
                Spacer(Modifier.height(12.dp))
                val watched = u.adsDoneToday(today)
                LinearProgressIndicator(
                    progress = { watched.toFloat() / Rules.AD_LIMIT },
                    modifier = Modifier.fillMaxWidth().height(8.dp),
                )
                Spacer(Modifier.height(6.dp))
                Text("$watched / ${Rules.AD_LIMIT} videos today", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))

                val cooldown = vm.adCooldownLeft(now)
                val limitDone = watched >= Rules.AD_LIMIT
                val ads = vm.ads
                Button(
                    onClick = { activity?.let { vm.watchAd(it) } },
                    enabled = !limitDone && cooldown == 0L && ads.isReady && !vm.busy && !u.blocked,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    when {
                        limitDone -> Text("Daily limit done · Back tomorrow")
                        cooldown > 0 -> Text("Next video in ${cooldown}s")
                        ads.isLoading -> {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text("Loading video…")
                        }
                        ads.isReady -> {
                            Icon(Icons.Filled.PlayArrow, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Watch & earn ${Rules.AD_POINTS} coins")
                        }
                        else -> Text("No video yet")
                    }
                }
                val err = ads.lastError
                if (!ads.isReady && !ads.isLoading && !limitDone) {
                    Spacer(Modifier.height(6.dp))
                    if (err != null) Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    androidx.compose.material3.TextButton(onClick = { ads.load() }) { Text("Load video again") }
                }
            }
        }

        Text(
            "Tip: check in every day — day 7 gives 40 coins!",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}

@Composable
fun BalanceCard(points: Long) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("Your coins", color = MaterialTheme.colorScheme.onPrimaryContainer)
            Row(verticalAlignment = Alignment.CenterVertically) {
                CoinIcon(34)
                Spacer(Modifier.width(10.dp))
                Text(
                    "$points",
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            Text(
                "= ${Rules.rupees(points)}",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Spacer(Modifier.height(12.dp))
            val goal = Rules.MIN_WITHDRAW
            LinearProgressIndicator(
                progress = { (points.toFloat() / goal).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (points >= goal) "You can withdraw now — open Wallet"
                else "${goal - points} more coins to withdraw ₹${goal / Rules.COINS_PER_RUPEE}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@Composable
private fun DayBubble(day: Long, reward: Long, filled: Boolean, highlight: Boolean) {
    val cs = MaterialTheme.colorScheme
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(38.dp)
                .background(if (filled) cs.primary else cs.surfaceVariant, CircleShape)
                .then(if (highlight) Modifier.border(2.dp, cs.secondary, CircleShape) else Modifier),
            contentAlignment = Alignment.Center
        ) {
            if (filled) Icon(Icons.Filled.Check, null, tint = cs.onPrimary, modifier = Modifier.size(20.dp))
            else Text("$reward", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.height(4.dp))
        Text("Day $day", fontSize = 10.sp, color = cs.onSurfaceVariant)
    }
}

@Composable
fun BlockedBanner() {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Text(
            "Your account is blocked for unfair use. Earning and withdrawals are paused.",
            Modifier.padding(16.dp),
            color = MaterialTheme.colorScheme.onErrorContainer
        )
    }
}
