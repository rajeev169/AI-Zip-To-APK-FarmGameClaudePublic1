package com.rajeev.coinkamao.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.coinkamao.data.Rules
import com.rajeev.coinkamao.ui.AppViewModel
import com.rajeev.coinkamao.ui.SectionTitle

@Composable
fun ReferScreen(vm: AppViewModel) {
    val u = vm.user ?: return
    val ctx = LocalContext.current

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ---------- My code ----------
        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        ) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Invite friends, earn ${Rules.REF_BONUS} coins each", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Friend gets ${Rules.JOIN_BONUS} coins. You get ${Rules.REF_BONUS} after they check in on ${Rules.REF_DAYS} days.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(16.dp))
                Text("Your code", style = MaterialTheme.typography.labelMedium)
                Text(u.referralCode, fontSize = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { copy(ctx, u.referralCode) }) {
                        Icon(Icons.Filled.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text("Copy")
                    }
                    Button(onClick = { share(ctx, u.referralCode) }) {
                        Icon(Icons.Filled.Share, null); Spacer(Modifier.width(6.dp)); Text("Share")
                    }
                }
            }
        }

        // ---------- Enter a friend's code ----------
        if (vm.canEnterCode(u)) {
            var code by rememberSaveable { mutableStateOf("") }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Got a friend's code?", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Enter it within ${Rules.REF_CODE_WINDOW_DAYS} days of joining to get ${Rules.JOIN_BONUS} coins.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = code,
                            onValueChange = { code = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(10) },
                            label = { Text("Friend's code") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(10.dp))
                        Button(onClick = { vm.applyCode(code) }, enabled = code.length >= 6 && !vm.busy && !u.blocked) {
                            Text("Apply")
                        }
                    }
                }
            }
        }

        // ---------- My friends ----------
        SectionTitle("Your friends (${vm.referrals.size})")
        if (vm.referrals.isEmpty()) {
            Text(
                "No friends yet. Share your code on WhatsApp to start earning.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        vm.referrals.forEach { r ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(r.newName, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        if (r.status == "claimed") AssistChip(onClick = {}, label = { Text("+${Rules.REF_BONUS} claimed") })
                    }
                    if (r.status != "claimed") {
                        val p = r.friendCheckIns.coerceAtMost(Rules.REF_DAYS)
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { p.toFloat() / Rules.REF_DAYS },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("$p / ${Rules.REF_DAYS} check-in days", style = MaterialTheme.typography.bodySmall)
                        if (r.friendCheckIns >= Rules.REF_DAYS) {
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = { vm.claimReferral(r) },
                                enabled = !vm.busy && !u.blocked,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Claim ${Rules.REF_BONUS} coins") }
                        }
                    }
                }
            }
        }
    }
}

private fun copy(ctx: Context, code: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Referral code", code))
    Toast.makeText(ctx, "Code copied", Toast.LENGTH_SHORT).show()
}

private fun share(ctx: Context, code: String) {
    val link = "https://play.google.com/store/apps/details?id=${ctx.packageName}"
    val text = "Join me on Coin Kamao! Watch videos and earn coins you can withdraw to UPI. " +
        "Use my code $code to get ${Rules.JOIN_BONUS} bonus coins.\n$link"
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(send, "Share your code"))
}
