package com.rajeev.coinkamao.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.rajeev.coinkamao.data.Rules
import com.rajeev.coinkamao.data.Withdrawal
import com.rajeev.coinkamao.ui.AppViewModel
import com.rajeev.coinkamao.ui.SectionTitle
import com.rajeev.coinkamao.ui.pretty

@Composable
fun WalletScreen(vm: AppViewModel) {
    val u = vm.user ?: return
    var upi by rememberSaveable { mutableStateOf(u.upiId) }
    LaunchedEffect(u.upiId) { if (upi.isBlank()) upi = u.upiId }
    var confirm by remember { mutableStateOf(false) }
    val coins = vm.withdrawableCoins(u)
    val canWithdraw = coins >= Rules.MIN_WITHDRAW && !u.pendingWithdrawal && !u.blocked

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (u.blocked) BlockedBanner()
        BalanceCard(u.points)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Withdraw to UPI", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = upi,
                    onValueChange = { upi = it.trim().take(60) },
                    label = { Text("Your UPI ID") },
                    placeholder = { Text("name@okaxis") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth()
                )
                if (upi.isNotBlank() && upi != u.upiId) {
                    TextButton(onClick = { vm.saveUpi(upi) }, enabled = !vm.busy) { Text("Save UPI ID") }
                }
                Spacer(Modifier.height(10.dp))
                when {
                    u.pendingWithdrawal -> Text(
                        "Your payout request is being processed. You can request again after it's done.",
                        color = MaterialTheme.colorScheme.primary
                    )
                    coins < Rules.MIN_WITHDRAW -> Text(
                        "Minimum withdrawal is ₹${Rules.MIN_WITHDRAW / Rules.COINS_PER_RUPEE} (${Rules.MIN_WITHDRAW} coins).",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (vm.isValidUpi(upi.trim())) confirm = true else vm.withdraw(upi)
                    },
                    enabled = canWithdraw && !vm.busy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (coins >= Rules.MIN_WITHDRAW) "Withdraw ₹${coins / Rules.COINS_PER_RUPEE}" else "Withdraw")
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Payouts are checked by hand and usually arrive within 2–3 days.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        SectionTitle("Payouts")
        if (vm.withdrawals.isEmpty()) {
            Text("No payouts yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        vm.withdrawals.forEach { WithdrawalRow(it) }

        SectionTitle("Coin history")
        if (vm.history.isEmpty()) {
            Text("Your coin activity will show here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Card(Modifier.fillMaxWidth()) {
            Column {
                vm.history.forEachIndexed { i, h ->
                    if (i > 0) HorizontalDivider()
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(h.note.ifBlank { h.type }, style = MaterialTheme.typography.bodyMedium)
                            Text(h.at.pretty(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (h.points != 0L) {
                            Text(
                                (if (h.points > 0) "+" else "") + h.points,
                                fontWeight = FontWeight.SemiBold,
                                color = if (h.points > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Withdraw ₹${coins / Rules.COINS_PER_RUPEE}?") },
            text = { Text("${coins} coins will be sent as ₹${coins / Rules.COINS_PER_RUPEE} to:\n\n${upi.trim()}\n\nPlease check the UPI ID carefully. Money sent to a wrong ID can't be returned.") },
            confirmButton = { TextButton(onClick = { confirm = false; vm.withdraw(upi) }) { Text("Confirm") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun WithdrawalRow(w: Withdrawal) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("₹${w.amount}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                StatusChip(w.status)
            }
            Text("To ${w.upiId}", style = MaterialTheme.typography.bodyMedium)
            Text("Requested ${w.createdAt.pretty()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (w.status == "paid" && w.utr.isNotBlank()) Text("UTR: ${w.utr}", style = MaterialTheme.typography.bodySmall)
            if (w.status == "rejected" && w.note.isNotBlank()) {
                Text("Reason: ${w.note} (coins returned)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
fun StatusChip(status: String) {
    val (label, bg) = when (status) {
        "paid" -> "Paid" to Color(0xFF2E7D32)
        "rejected" -> "Rejected" to Color(0xFFC62828)
        else -> "Pending" to Color(0xFFB26A00)
    }
    Surface(shape = RoundedCornerShape(50), color = bg) {
        Text(label, color = Color.White, style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
    }
}
