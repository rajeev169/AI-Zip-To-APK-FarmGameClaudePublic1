package com.rajeev.coinkamao.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFF2B705)
val GoldDeep = Color(0xFFC98F00)
val Leaf = Color(0xFF1E7A55)

private val Light = lightColorScheme(
    primary = Color(0xFF1E7A55),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC9EFD9),
    onPrimaryContainer = Color(0xFF002114),
    secondary = Color(0xFF8A6200),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE08A),
    onSecondaryContainer = Color(0xFF2B1D00),
    tertiary = Color(0xFF3B6470),
    background = Color(0xFFF7FAF7),
    surface = Color(0xFFF7FAF7),
    surfaceVariant = Color(0xFFDDE5DE),
    surfaceContainer = Color(0xFFEDF2EE),
    surfaceContainerHigh = Color(0xFFE6EDE8),
    error = Color(0xFFB3261E),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF8DD6B0),
    onPrimary = Color(0xFF003824),
    primaryContainer = Color(0xFF005237),
    onPrimaryContainer = Color(0xFFC9EFD9),
    secondary = Color(0xFFF2C14E),
    onSecondary = Color(0xFF3F2E00),
    secondaryContainer = Color(0xFF5C4400),
    onSecondaryContainer = Color(0xFFFFE08A),
    tertiary = Color(0xFFA3CDDA),
    background = Color(0xFF101512),
    surface = Color(0xFF101512),
    surfaceVariant = Color(0xFF404943),
    surfaceContainer = Color(0xFF1C211E),
    surfaceContainerHigh = Color(0xFF262B28),
    error = Color(0xFFF2B8B5),
)

@Composable
fun CoinTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content
    )
}
