package com.rajeev.coinkamao.ui

import android.app.Activity
import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.rajeev.coinkamao.ads.RewardedAds
import com.rajeev.coinkamao.auth.GoogleAuth
import com.rajeev.coinkamao.data.DeviceUsedException
import com.rajeev.coinkamao.data.HistoryItem
import com.rajeev.coinkamao.data.Referral
import com.rajeev.coinkamao.data.Repo
import com.rajeev.coinkamao.data.Rules
import com.rajeev.coinkamao.data.UserDoc
import com.rajeev.coinkamao.data.Withdrawal
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

sealed interface Screen {
    data object Loading : Screen
    data object SignedOut : Screen
    data object DeviceUsed : Screen
    data class Error(val message: String) : Screen
    data object Ready : Screen
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val auth = FirebaseAuth.getInstance()
    val ads = RewardedAds(app)

    var screen by mutableStateOf<Screen>(Screen.Loading)
        private set
    var user by mutableStateOf<UserDoc?>(null)
        private set
    var isAdmin by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set
    var signingIn by mutableStateOf(false)
        private set

    val withdrawals = mutableStateListOf<Withdrawal>()
    val history = mutableStateListOf<HistoryItem>()
    val referrals = mutableStateListOf<Referral>()
    val pendingPayouts = mutableStateListOf<Withdrawal>()

    var adminFoundUser by mutableStateOf<UserDoc?>(null)
        private set
    var adminSearchDone by mutableStateOf(false)
        private set

    private var serverOffset = 0L
    private val jobs = mutableListOf<Job>()

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    private var lastUid: String? = null
    private val authListener = FirebaseAuth.AuthStateListener { fa ->
        val u = fa.currentUser
        if (u?.uid != lastUid) {
            lastUid = u?.uid
            onAuthChanged(u)
        }
    }

    init {
        auth.addAuthStateListener(authListener)
    }

    override fun onCleared() {
        auth.removeAuthStateListener(authListener)
        super.onCleared()
    }

    fun nowMillis(): Long = System.currentTimeMillis() + serverOffset
    fun today(): Long = Rules.dayNumber(nowMillis())

    private fun say(msg: String) {
        _messages.trySend(msg)
    }

    private fun stopListeners() {
        jobs.forEach { it.cancel() }
        jobs.clear()
        user = null
        isAdmin = false
        withdrawals.clear(); history.clear(); referrals.clear(); pendingPayouts.clear()
        adminFoundUser = null; adminSearchDone = false
    }

    private fun onAuthChanged(fu: FirebaseUser?) {
        stopListeners()
        if (fu == null) {
            screen = Screen.SignedOut
            return
        }
        setup(fu)
    }

    fun retry() {
        val current = auth.currentUser
        if (current != null) setup(current) else screen = Screen.SignedOut
    }

    private fun setup(fu: FirebaseUser) {
        screen = Screen.Loading
        viewModelScope.launch {
            try {
                Repo.ensureUser(getApplication<Application>(), fu)
                serverOffset = try { Repo.serverTimeOffset(fu.uid) } catch (_: Exception) { 0L }
                isAdmin = Repo.isAdmin(fu.uid)
                startListeners(fu.uid)
                screen = Screen.Ready
                ads.load()
            } catch (e: DeviceUsedException) {
                screen = Screen.DeviceUsed
            } catch (e: Exception) {
                screen = Screen.Error(Repo.friendlyError(e))
            }
        }
    }

    private fun startListeners(uid: String) {
        jobs += viewModelScope.launch { Repo.observeUser(uid).collect { user = it } }
        jobs += viewModelScope.launch {
            Repo.observeMyWithdrawals(uid).collect { withdrawals.clear(); withdrawals.addAll(it) }
        }
        jobs += viewModelScope.launch {
            Repo.observeHistory(uid).collect { history.clear(); history.addAll(it) }
        }
        jobs += viewModelScope.launch {
            Repo.observeMyReferrals(uid).collect { referrals.clear(); referrals.addAll(it) }
        }
        if (isAdmin) {
            jobs += viewModelScope.launch {
                Repo.observePendingWithdrawals().collect { pendingPayouts.clear(); pendingPayouts.addAll(it) }
            }
        }
    }

    // ---------------- Auth ----------------

    fun signIn(activity: Activity) {
        if (signingIn) return
        signingIn = true
        viewModelScope.launch {
            try {
                GoogleAuth.signIn(activity)
            } catch (e: Exception) {
                say(Repo.friendlyError(e))
            } finally {
                signingIn = false
            }
        }
    }

    fun signOut() {
        viewModelScope.launch { GoogleAuth.signOut(getApplication<Application>()) }
    }

    private fun act(block: suspend () -> Unit) {
        if (busy) return
        busy = true
        viewModelScope.launch {
            try {
                block()
            } catch (e: Exception) {
                say(Repo.friendlyError(e))
            } finally {
                busy = false
            }
        }
    }

    // ---------------- Earning ----------------

    /** Seconds left before the next video is allowed (0 = ready). */
    fun adCooldownLeft(now: Long): Long {
        val last = user?.lastAdAt?.toDate()?.time ?: return 0L
        val left = (last + Rules.AD_COOLDOWN_SEC * 1000 - now) / 1000
        return if (left > 0) left + 1 else 0L
    }

    fun watchAd(activity: Activity) {
        val u = user ?: return
        if (u.blocked) { say("Your account is blocked."); return }
        if (u.adsDoneToday(today()) >= Rules.AD_LIMIT) { say("Today's video limit is done. Come back tomorrow!"); return }
        if (adCooldownLeft(nowMillis()) > 0) { say("Please wait a few seconds."); return }
        if (!ads.isReady) { ads.load(); say("Loading video… try again in a moment."); return }
        var earned = false
        ads.show(activity,
            onEarned = { earned = true },
            onClosed = {
                if (earned) {
                    act {
                        val fresh = user ?: return@act
                        Repo.rewardAd(fresh, today())
                        say("+${Rules.AD_POINTS} coins added!")
                    }
                } else {
                    say("Watch the full video to get coins.")
                }
            })
    }

    fun checkIn() {
        val u = user ?: return
        if (u.checkedInToday(today())) { say("Already checked in today."); return }
        act {
            val reward = Rules.checkInReward(u.nextStreak(today()))
            Repo.checkIn(u, today())
            say("+$reward coins! Day ${u.nextStreak(today())} streak.")
        }
    }

    fun canEnterCode(u: UserDoc): Boolean {
        val created = u.createdAt?.toDate()?.time ?: return false
        return u.referredBy == null &&
            nowMillis() < created + Rules.REF_CODE_WINDOW_DAYS * 86_400_000L
    }

    fun applyCode(code: String) {
        val u = user ?: return
        act {
            Repo.applyReferralCode(u, code)
            say("Code applied! +${Rules.JOIN_BONUS} coins.")
        }
    }

    fun claimReferral(r: Referral) {
        val u = user ?: return
        act {
            Repo.claimReferral(u, r)
            say("+${Rules.REF_BONUS} coins for inviting ${r.newName}!")
        }
    }

    // ---------------- Wallet ----------------

    fun withdrawableCoins(u: UserDoc): Long = (u.points / Rules.COINS_PER_RUPEE) * Rules.COINS_PER_RUPEE

    fun withdraw(upi: String) {
        val u = user ?: return
        val clean = upi.trim()
        if (!isValidUpi(clean)) { say("Enter a valid UPI ID, like name@okaxis"); return }
        val coins = withdrawableCoins(u)
        if (coins < Rules.MIN_WITHDRAW) { say("You need ${Rules.MIN_WITHDRAW} coins to withdraw."); return }
        if (u.pendingWithdrawal) { say("You already have a payout in progress."); return }
        act {
            Repo.requestWithdrawal(u, coins, clean)
            say("Request sent! ₹${coins / Rules.COINS_PER_RUPEE} will reach your UPI soon.")
        }
    }

    fun saveUpi(upi: String) {
        val u = user ?: return
        val clean = upi.trim()
        if (!isValidUpi(clean)) { say("Enter a valid UPI ID, like name@okaxis"); return }
        act { Repo.saveUpi(u.uid, clean); say("UPI ID saved.") }
    }

    fun isValidUpi(upi: String) = Regex("^[a-zA-Z0-9._-]{2,}@[a-zA-Z0-9]{2,}$").matches(upi)

    // ---------------- Admin ----------------

    fun markPaid(w: Withdrawal, utr: String) = act {
        Repo.markPaid(w, utr)
        say("Marked ₹${w.amount} as paid.")
    }

    fun reject(w: Withdrawal, reason: String) = act {
        Repo.rejectWithdrawal(w, reason.ifBlank { "Rejected by admin" })
        say("Rejected. Coins returned to user.")
    }

    fun searchUser(email: String) {
        if (email.isBlank()) return
        act {
            adminFoundUser = Repo.findUserByEmail(email)
            adminSearchDone = true
        }
    }

    fun openUserFromPayout(uid: String) = act {
        adminFoundUser = Repo.getUser(uid)
        adminSearchDone = true
    }

    fun setBlocked(u: UserDoc, blocked: Boolean) = act {
        Repo.setBlocked(u.uid, blocked)
        adminFoundUser = Repo.getUser(u.uid)
        say(if (blocked) "User blocked." else "User unblocked.")
    }
}
