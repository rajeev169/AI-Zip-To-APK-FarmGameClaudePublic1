# Exam Prep (Bihar Police, BPSC, Railway)

Kotlin + Jetpack Compose (Material 3, Expressive styling), Firebase Auth (Google) + Firestore, AdMob banner.
Package: `com.appforge.examprep`  (change `applicationId` and `namespace` in `app/build.gradle.kts` if you want another one).

## Before the first real run
1. Firebase console: add an Android app with package `com.appforge.examprep` and your SHA-1 key(s).
2. Enable Authentication > Google. Create a Firestore database.
3. Replace `app/google-services.json` (it is only a placeholder) with the file from Firebase.
4. Firestore > Rules: paste `firestore.rules` and publish.
5. Admin panel is shown only to the emails in `Config.kt` (`ADMIN_EMAILS`). Same list is in `firestore.rules`.
6. AdMob: the manifest app id and `Config.BANNER_AD_UNIT` are Google TEST ids. Replace both before publishing.

## Adding questions (Admin panel > Upload questions)
Use `sample_questions.csv` as the template. Columns:
`exam, type, subject, testName, question_en, question_hi, a_en..d_en, a_hi..d_hi, answer, explanation_en, explanation_hi`
- exam: `Bihar Police`, `BPSC`, `Railway`, several joined with `|`, or `All`
- type: `practice` (subjects/daily quiz), `mock` (Mock tests), `pyp` (Previous-year papers)
- subject: Bihar GK, General knowledge, Hindi, Maths, Reasoning, Current affairs
- testName: required for mock and pyp (all rows with the same name form one test)
- answer: A, B, C or D. Hindi columns can stay empty; the app then shows English.
