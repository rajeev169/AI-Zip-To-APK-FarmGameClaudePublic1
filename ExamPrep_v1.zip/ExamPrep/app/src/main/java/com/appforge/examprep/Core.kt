package com.appforge.examprep

import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

object Config {
    // Only these Google accounts see the Admin panel (Firestore rules must allow the same emails).
    val ADMIN_EMAILS = listOf("rajeevkant932@gmail.com")
    val EXAMS = listOf("Bihar Police", "BPSC", "Railway")
    val SUBJECTS = listOf("Bihar GK", "General knowledge", "Hindi", "Maths", "Reasoning", "Current affairs")

    // Google test banner id. Replace with your own AdMob banner unit id before publishing.
    const val BANNER_AD_UNIT = "ca-app-pub-3940256099942544/6300978111"
    const val DAILY_QUIZ_SIZE = 10
    const val PRACTICE_SIZE = 10
}

data class Question(
    val id: String,
    val exam: String,
    val type: String,
    val subject: String,
    val testName: String,
    val qEn: String,
    val qHi: String,
    val optEn: List<String>,
    val optHi: List<String>,
    val answer: Int,
    val expEn: String,
    val expHi: String
) {
    fun text(hindi: Boolean): String = if (hindi && qHi.isNotBlank()) qHi else qEn

    fun options(hindi: Boolean): List<String> =
        if (hindi && optHi.size >= optEn.size && optHi.take(optEn.size).all { it.isNotBlank() }) optHi.take(optEn.size) else optEn

    fun explanation(hindi: Boolean): String = if (hindi && expHi.isNotBlank()) expHi else expEn
}

data class TestInfo(val id: String, val name: String, val exam: String, val type: String, val count: Int)

data class CaPost(
    val id: String,
    val date: String,
    val titleEn: String,
    val titleHi: String,
    val bodyEn: String,
    val bodyHi: String
) {
    fun title(hindi: Boolean): String = if (hindi && titleHi.isNotBlank()) titleHi else titleEn
    fun body(hindi: Boolean): String = if (hindi && bodyHi.isNotBlank()) bodyHi else bodyEn
}

data class ResultRow(
    val title: String,
    val correct: Int,
    val total: Int,
    val ts: Long,
    val subjects: List<String>,
    val corrects: List<Boolean>
)

data class ReportRow(val id: String, val text: String, val email: String)

class AppSettings(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var exam by mutableStateOf(sp.getString("exam", "Bihar Police") ?: "Bihar Police")
        private set
    var hindi by mutableStateOf(sp.getBoolean("hindi", false))
        private set
    var dark by mutableStateOf(sp.getBoolean("dark", false))
        private set
    var reminder by mutableStateOf(sp.getBoolean("reminder", false))
        private set

    fun updateExam(v: String) {
        exam = v
        sp.edit().putString("exam", v).apply()
    }

    fun updateHindi(v: Boolean) {
        hindi = v
        sp.edit().putBoolean("hindi", v).apply()
    }

    fun updateDark(v: Boolean) {
        dark = v
        sp.edit().putBoolean("dark", v).apply()
    }

    fun updateReminder(v: Boolean) {
        reminder = v
        sp.edit().putBoolean("reminder", v).apply()
    }
}

class QuizSession(val title: String, val subject: String, val questions: List<Question>) {
    val answers = mutableStateListOf<Int?>().also { list -> repeat(questions.size) { list.add(null) } }
    var index by mutableIntStateOf(0)
    var saved = false

    val correct: Int get() = questions.indices.count { answers[it] == questions[it].answer }
    val wrong: Int get() = questions.indices.count { answers[it] != null && answers[it] != questions[it].answer }
    val skipped: Int get() = questions.indices.count { answers[it] == null }
}

class AppState(val settings: AppSettings) {
    var user by mutableStateOf<FirebaseUser?>(FirebaseAuth.getInstance().currentUser)
    var session by mutableStateOf<QuizSession?>(null)
    var busy by mutableStateOf(false)
    var selectedPost by mutableStateOf<CaPost?>(null)
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val isAdmin: Boolean
        get() = Config.ADMIN_EMAILS.any { it.equals(user?.email, ignoreCase = true) }

    fun tr(en: String, hi: String): String = if (settings.hindi) hi else en

    fun startQuiz(
        ctx: Context,
        title: String,
        subject: String,
        onReady: () -> Unit,
        loader: suspend () -> List<Question>
    ) {
        if (busy) return
        busy = true
        appScope.launch {
            try {
                val qs = loader()
                if (qs.isEmpty()) {
                    Toast.makeText(ctx, tr("No questions here yet", "यहाँ अभी प्रश्न नहीं हैं"), Toast.LENGTH_SHORT).show()
                } else {
                    session = QuizSession(title, subject, qs)
                    onReady()
                }
            } catch (e: Exception) {
                Toast.makeText(
                    ctx,
                    tr("Couldn't load questions. Check your connection.", "प्रश्न लोड नहीं हुए। इंटरनेट जांचें।"),
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                busy = false
            }
        }
    }
}

val LocalApp = staticCompositionLocalOf<AppState> { error("AppState not provided") }

@Composable
fun t(en: String, hi: String): String = if (LocalApp.current.settings.hindi) hi else en
