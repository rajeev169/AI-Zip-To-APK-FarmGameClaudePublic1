package com.appforge.examprep

class ImportResult(val questions: List<Question>, val errors: List<String>)

object Csv {
    fun parse(input: String): List<List<String>> {
        val s = input.removePrefix("\uFEFF")
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < s.length && s[i + 1] == '"') {
                        sb.append('"')
                        i++
                    } else {
                        inQuotes = false
                    }
                } else {
                    sb.append(c)
                }
            } else {
                if (c == '"') {
                    inQuotes = true
                } else if (c == ',') {
                    row.add(sb.toString())
                    sb.setLength(0)
                } else if (c == '\r') {
                    // ignore
                } else if (c == '\n') {
                    row.add(sb.toString())
                    sb.setLength(0)
                    rows.add(row)
                    row = ArrayList()
                } else {
                    sb.append(c)
                }
            }
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) {
            row.add(sb.toString())
            rows.add(row)
        }
        return rows.filter { r -> r.any { it.isNotBlank() } }
    }

    private fun parseAnswer(raw: String): Int? {
        val v = raw.trim().uppercase()
        return when (v) {
            "A", "1" -> 0
            "B", "2" -> 1
            "C", "3" -> 2
            "D", "4" -> 3
            else -> null
        }
    }

    private fun parseExams(raw: String): List<String>? {
        val v = raw.trim()
        if (v.isEmpty()) return null
        if (v.equals("all", ignoreCase = true) || v == "*") return Config.EXAMS
        val result = ArrayList<String>()
        for (part in v.split('|', ';')) {
            val name = part.trim()
            if (name.isEmpty()) continue
            val match = Config.EXAMS.firstOrNull { it.equals(name, ignoreCase = true) } ?: return null
            if (!result.contains(match)) result.add(match)
        }
        return if (result.isEmpty()) null else result
    }

    fun toQuestions(text: String): ImportResult {
        val rows = parse(text)
        if (rows.size < 2) return ImportResult(emptyList(), listOf("The file has no question rows."))
        val header = rows[0].map { it.trim().lowercase() }

        fun col(r: List<String>, name: String): String {
            val i = header.indexOf(name)
            return if (i >= 0 && i < r.size) r[i].trim() else ""
        }

        val out = ArrayList<Question>()
        val errors = ArrayList<String>()
        for (n in 1 until rows.size) {
            val r = rows[n]
            val line = n + 1
            val qEn = col(r, "question_en")
            if (qEn.isEmpty()) {
                errors.add("Row $line: question_en is empty")
                continue
            }
            val optEn = listOf(col(r, "a_en"), col(r, "b_en"), col(r, "c_en"), col(r, "d_en")).takeWhile { it.isNotEmpty() }
            if (optEn.size < 2) {
                errors.add("Row $line: needs at least options a_en and b_en")
                continue
            }
            val ans = parseAnswer(col(r, "answer"))
            if (ans == null || ans >= optEn.size) {
                errors.add("Row $line: answer must be A, B, C or D and match an option")
                continue
            }
            val exams = parseExams(col(r, "exam"))
            if (exams == null) {
                errors.add("Row $line: exam must be Bihar Police, BPSC, Railway or All")
                continue
            }
            val type = when (col(r, "type").lowercase()) {
                "", "practice" -> "practice"
                "mock" -> "mock"
                "pyp", "previous", "previous-year", "previous year" -> "pyp"
                else -> null
            }
            if (type == null) {
                errors.add("Row $line: type must be practice, mock or pyp")
                continue
            }
            val testName = col(r, "testname")
            if (type != "practice" && testName.isEmpty()) {
                errors.add("Row $line: testName is required for mock and pyp rows")
                continue
            }
            var subject = col(r, "subject")
            if (subject.isEmpty()) {
                if (type == "practice") {
                    errors.add("Row $line: subject is empty")
                    continue
                }
                subject = "General knowledge"
            }
            subject = Config.SUBJECTS.firstOrNull { it.equals(subject, ignoreCase = true) } ?: subject
            val optHi = listOf(col(r, "a_hi"), col(r, "b_hi"), col(r, "c_hi"), col(r, "d_hi")).take(optEn.size)
            for (exam in exams) {
                out.add(
                    Question(
                        id = "",
                        exam = exam,
                        type = type,
                        subject = subject,
                        testName = if (type == "practice") "" else testName,
                        qEn = qEn,
                        qHi = col(r, "question_hi"),
                        optEn = optEn,
                        optHi = optHi,
                        answer = ans,
                        expEn = col(r, "explanation_en"),
                        expHi = col(r, "explanation_hi")
                    )
                )
            }
        }
        return ImportResult(out, errors)
    }
}
