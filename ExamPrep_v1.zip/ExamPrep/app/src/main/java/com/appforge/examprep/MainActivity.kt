package com.appforge.examprep

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.google.android.gms.ads.MobileAds

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        MobileAds.initialize(this) { }
        val state = AppState(AppSettings(applicationContext))
        setContent {
            CompositionLocalProvider(LocalApp provides state) {
                AppTheme(dark = state.settings.dark) {
                    Root(state)
                }
            }
        }
    }
}

@Composable
fun Root(app: AppState) {
    val nav = rememberNavController()
    val start = if (app.user != null) "home" else "login"
    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .imePadding()
    ) {
        NavHost(navController = nav, startDestination = start) {
            composable("login") {
                LoginScreen {
                    nav.navigate("home") { popUpTo("login") { inclusive = true } }
                }
            }
            composable("home") { HomeScreen(nav) }
            composable("practice") { PracticeScreen(nav) }
            composable(
                "tests/{kind}",
                arguments = listOf(navArgument("kind") { type = NavType.StringType })
            ) { entry ->
                TestsScreen(nav, entry.arguments?.getString("kind") ?: "mock")
            }
            composable("affairs") { AffairsScreen(nav) }
            composable("affairDetail") { AffairDetailScreen(nav) }
            composable("progress") { ProgressScreen(nav) }
            composable("quiz") { QuizScreen(nav) }
            composable("result") { ResultScreen(nav) }
            composable("review") { ReviewScreen(nav) }
            composable("settings") { SettingsScreen(nav) }
            composable("report") { ReportScreen(nav) }
            composable("about") { AboutScreen(nav) }
            composable("admin") { AdminScreen(nav) }
            composable("adminReports") { AdminReportsScreen(nav) }
        }
        if (app.busy) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.25f))
                    .clickable(enabled = true, onClick = { }),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = Purple)
            }
        }
    }
}
