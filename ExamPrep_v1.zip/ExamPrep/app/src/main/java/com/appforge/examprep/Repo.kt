package com.appforge.examprep

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.AggregateSource
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import java.time.LocalDate

object Repo {
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    private fun strList(v: Any?): List<String> = (v as? List<*>)?.map { it?.toString() ?: "" } ?: emptyList()

    private fun toQuestion(d: DocumentSnapshot): Question? {
        val qEn = d.getString("qEn") ?: return null
        val optEn = strList(d.get("optEn"))
        if (optEn.size < 2) return null
        val ans = (d.getLong("answer") ?: 0L).toInt()
        if (ans < 0 || ans >= optEn.size) return null
        return Question(
            id = d.id,
            exam = d.getString("exam") ?: "",
            type = d.getString("type") ?: "practice",
            subject = d.getString("subject") ?: "",
            testName = d.getString("testName") ?: "",
            qEn = qEn,
            qHi = d.getString("qHi") ?: "",
            optEn = optEn,
            optHi = strList(d.get("optHi")),
            answer = ans,
            expEn = d.getString("expEn") ?: "",
            expHi = d.getString("expHi") ?: ""
        )
    }

    suspend fun questions(exam: String, type: String, subject: String?, testName: String?, limit: Long): List<Question> {
        var q: Query = db.collection("questions").whereEqualTo("exam", exam).whereEqualTo("type", type)
        if (subject != null) q = q.whereEqualTo("subject", subject)
        if (testName != null) q = q.whereEqualTo("testName", testName)
        val snap = q.limit(limit).get().await()
        return snap.documents.mapNotNull { toQuestion(it) }
    }

    suspend fun tests(exam: String, type: String): List<TestInfo> {
        val snap = db.collection("tests").whereEqualTo("exam", exam).whereEqualTo("type", type).get().await()
        return snap.documents.map {
            TestInfo(it.id, it.getString("name") ?: it.id, exam, type, (it.getLong("count") ?: 0L).toInt())
        }.sortedBy { it.name }
    }

    suspend fun affairs(): List<CaPost> {
        val snap = db.collection("current_affairs").orderBy("date", Query.Direction.DESCENDING).limit(30).get().await()
        return snap.documents.map {
            CaPost(
                id = it.id,
                date = it.getString("date") ?: "",
                titleEn = it.getString("titleEn") ?: "",
                titleHi = it.getString("titleHi") ?: "",
                bodyEn = it.getString("bodyEn") ?: "",
                bodyHi = it.getString("bodyHi") ?: ""
            )
        }
    }

    suspend fun saveResult(
        uid: String,
        title: String,
        subjects: List<String>,
        corrects: List<Boolean>,
        correct: Int,
        total: Int
    ) {
        val u = db.collection("users").document(uid)
        val data = hashMapOf<String, Any>(
            "title" to title,
            "correct" to correct,
            "total" to total,
            "ts" to System.currentTimeMillis(),
            "subjects" to subjects,
            "corrects" to corrects
        )
        u.collection("results").add(data).await()
        val snap = u.get().await()
        val today = LocalDate.now()
        val last = snap.getString("lastDay")?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val streak = (snap.getLong("streak") ?: 0L).toInt()
        val newStreak = when {
            last == null -> 1
            last == today -> if (streak > 0) streak else 1
            last == today.minusDays(1) -> streak + 1
            else -> 1
        }
        u.set(hashMapOf<String, Any>("streak" to newStreak, "lastDay" to today.toString()), SetOptions.merge()).await()
    }

    suspend fun streak(uid: String): Int {
        val snap = db.collection("users").document(uid).get().await()
        val last = snap.getString("lastDay")?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: return 0
        val today = LocalDate.now()
        val streak = (snap.getLong("streak") ?: 0L).toInt()
        return if (last == today || last == today.minusDays(1)) streak else 0
    }

    suspend fun results(uid: String): List<ResultRow> {
        val snap = db.collection("users").document(uid).collection("results")
            .orderBy("ts", Query.Direction.DESCENDING).limit(50).get().await()
        return snap.documents.map {
            ResultRow(
                title = it.getString("title") ?: "",
                correct = (it.getLong("correct") ?: 0L).toInt(),
                total = (it.getLong("total") ?: 0L).toInt(),
                ts = it.getLong("ts") ?: 0L,
                subjects = strList(it.get("subjects")),
                corrects = (it.get("corrects") as? List<*>)?.map { v -> v == true } ?: emptyList()
            )
        }
    }

    suspend fun sendReport(text: String, email: String) {
        val data = hashMapOf<String, Any>("text" to text, "email" to email, "ts" to System.currentTimeMillis())
        db.collection("reports").add(data).await()
    }

    suspend fun reports(): List<ReportRow> {
        val snap = db.collection("reports").orderBy("ts", Query.Direction.DESCENDING).limit(100).get().await()
        return snap.documents.map { ReportRow(it.id, it.getString("text") ?: "", it.getString("email") ?: "") }
    }

    suspend fun deleteReport(id: String) {
        db.collection("reports").document(id).delete().await()
    }

    suspend fun countQuestions(): Long =
        db.collection("questions").count().get(AggregateSource.SERVER).await().count

    suspend fun countReports(): Long =
        db.collection("reports").count().get(AggregateSource.SERVER).await().count

    suspend fun postAffair(date: String, titleEn: String, titleHi: String, bodyEn: String, bodyHi: String) {
        val data = hashMapOf<String, Any>(
            "date" to date,
            "titleEn" to titleEn,
            "titleHi" to titleHi,
            "bodyEn" to bodyEn,
            "bodyHi" to bodyHi
        )
        db.collection("current_affairs").add(data).await()
    }

    suspend fun importQuestions(list: List<Question>, onProgress: (Int) -> Unit): Int {
        var done = 0
        for (chunk in list.chunked(400)) {
            val batch = db.batch()
            for (q in chunk) {
                val ref = db.collection("questions").document()
                val data = hashMapOf<String, Any>(
                    "exam" to q.exam,
                    "type" to q.type,
                    "subject" to q.subject,
                    "testName" to q.testName,
                    "qEn" to q.qEn,
                    "qHi" to q.qHi,
                    "optEn" to q.optEn,
                    "optHi" to q.optHi,
                    "answer" to q.answer,
                    "expEn" to q.expEn,
                    "expHi" to q.expHi
                )
                batch.set(ref, data)
            }
            batch.commit().await()
            done += chunk.size
            onProgress(done)
        }
        val counts = HashMap<String, Int>()
        val meta = HashMap<String, Question>()
        for (q in list) {
            if (q.testName.isNotEmpty() && (q.type == "mock" || q.type == "pyp")) {
                val key = q.exam + "|" + q.type + "|" + q.testName
                counts[key] = (counts[key] ?: 0) + 1
                meta[key] = q
            }
        }
        for (chunk in counts.keys.toList().chunked(400)) {
            val batch = db.batch()
            for (key in chunk) {
                val q = meta[key] ?: continue
                val ref = db.collection("tests").document(key.replace('/', '_'))
                val data = hashMapOf<String, Any>(
                    "name" to q.testName,
                    "exam" to q.exam,
                    "type" to q.type,
                    "count" to FieldValue.increment((counts[key] ?: 0).toLong())
                )
                batch.set(ref, data, SetOptions.merge())
            }
            batch.commit().await()
        }
        return done
    }

    fun currentEmail(): String = FirebaseAuth.getInstance().currentUser?.email ?: ""
}
