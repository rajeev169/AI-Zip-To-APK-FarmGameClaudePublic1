package com.appforge.examprep

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

fun AppState.startPractice(ctx: Context, nav: NavController, subject: String) {
    startQuiz(ctx, subject, subject, { nav.navigate("quiz") }) {
        Repo.questions(settings.exam, "practice", subject, null, 40).shuffled().take(Config.PRACTICE_SIZE)
    }
}

fun AppState.startDaily(ctx: Context, nav: NavController, title: String) {
    startQuiz(ctx, title, "Daily quiz", { nav.navigate("quiz") }) {
        Repo.questions(settings.exam, "practice", null, null, 60).shuffled().take(Config.DAILY_QUIZ_SIZE)
    }
}

@Composable
fun LoginScreen(onDone: () -> Unit) {
    val app = LocalApp.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        val shape = RoundedCornerShape(28.dp)
        Box(
            modifier = Modifier.size(84.dp).deepShadow(shape).background(Purple, shape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.School, contentDescription = null, tint = Color.White, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("Exam Prep", fontSize = 22.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        Text(
            t(
                "Bihar Police, BPSC and Railway practice in Hindi and English",
                "बिहार पुलिस, BPSC और रेलवे की तैयारी हिंदी और अंग्रेज़ी में"
            ),
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(40.dp))
        OutlineButton(
            text = if (loading) t("Signing in...", "साइन इन हो रहा है...") else t("Continue with Google", "Google से जारी रखें"),
            onClick = {
                if (!loading) {
                    loading = true
                    scope.launch {
                        val activity = ctx.findActivity()
                        val r: Result<Unit> = if (activity == null) {
                            Result.failure(IllegalStateException("Could not open sign-in"))
                        } else {
                            Auth.signIn(activity)
                        }
                        loading = false
                        if (r.isSuccess) {
                            app.user = FirebaseAuth.getInstance().currentUser
                            onDone()
                        } else {
                            Toast.makeText(ctx, r.exceptionOrNull()?.message ?: "Sign-in failed", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun DrawerRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    AppCard(modifier = Modifier.padding(bottom = 12.dp), onClick = onClick) {
        Icon(icon, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
        Text(label, fontSize = 14.sp)
    }
}

@Composable
fun HomeScreen(nav: NavController) {
    val app = LocalApp.current
    val s = app.settings
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    var streak by remember { mutableIntStateOf(0) }
    val uid = app.user?.uid
    LaunchedEffect(uid) {
        if (uid != null) {
            try {
                streak = Repo.streak(uid)
            } catch (e: Exception) {
                // offline: keep 0
            }
        }
    }
    val dailyTitle = t("Daily quiz", "डेली क्विज़")

    fun go(route: String) {
        scope.launch { drawer.close() }
        nav.navigate(route)
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 16.dp)) {
                        val name = app.user?.displayName ?: "Student"
                        Box(
                            modifier = Modifier.size(40.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                name.take(1).uppercase(),
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(name, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(
                                t("Signed in with Google", "Google से साइन इन"),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    DrawerRow(Icons.Outlined.Home, t("Home", "होम")) { scope.launch { drawer.close() } }
                    DrawerRow(Icons.Outlined.Description, t("Previous-year papers", "पिछले वर्षों के पेपर")) { go("tests/pyp") }
                    DrawerRow(Icons.Outlined.Newspaper, t("Current affairs", "करेंट अफेयर्स")) { go("affairs") }
                    DrawerRow(Icons.Outlined.BarChart, t("My progress", "मेरी प्रगति")) { go("progress") }
                    DrawerRow(Icons.Outlined.Flag, t("Report wrong question", "गलत प्रश्न बताएं")) { go("report") }
                    DrawerRow(Icons.Outlined.Settings, t("Settings", "सेटिंग्स")) { go("settings") }
                    if (app.isAdmin) {
                        DrawerRow(Icons.Outlined.AdminPanelSettings, "Admin panel") { go("admin") }
                    }
                    DrawerRow(Icons.Outlined.Info, t("About", "ऐप के बारे में")) { go("about") }
                }
            }
        }
    ) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Menu,
                        contentDescription = "Menu",
                        modifier = Modifier.size(26.dp).clickable { scope.launch { drawer.open() } }
                    )
                    AppChip(if (s.hindi) "हिन्दी" else "English", false) { s.updateHindi(!s.hindi) }
                    Icon(
                        Icons.Filled.Settings,
                        contentDescription = "Settings",
                        modifier = Modifier.size(26.dp).clickable { nav.navigate("settings") }
                    )
                }
                val first = app.user?.displayName?.substringBefore(' ') ?: ""
                Text(
                    (if (s.hindi) "नमस्ते" else "Hi") + (if (first.isNotEmpty()) ", $first" else ""),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    t("Ready for today's practice?", "आज के अभ्यास के लिए तैयार हैं?"),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                    for (e in Config.EXAMS) {
                        AppChip(e, e == s.exam) { s.updateExam(e) }
                    }
                }
                Tile(
                    bg = Purple,
                    fg = Color.White,
                    radius = 28.dp,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    onClick = { app.startDaily(ctx, nav, dailyTitle) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(t("Daily quiz", "डेली क्विज़"), fontSize = 12.sp)
                            Text(
                                "${Config.DAILY_QUIZ_SIZE} " + t("questions", "प्रश्न"),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Row(
                            modifier = Modifier
                                .background(Color(0xFFEEEDFE), RoundedCornerShape(20.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.LocalFireDepartment,
                                contentDescription = null,
                                tint = Color(0xFF3C3489),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text("$streak " + t("day streak", "दिन की स्ट्रीक"), fontSize = 13.sp, color = Color(0xFF3C3489))
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    val pill = RoundedCornerShape(20.dp)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .deepShadow(pill, 4.dp)
                            .background(Color(0xFFEEEDFE), pill)
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(t("Start quiz", "क्विज़ शुरू करें"), fontSize = 14.sp, color = Color(0xFF3C3489))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(bottom = 14.dp)) {
                    SubjectTile(
                        Modifier.weight(1f), Color(0xFFE1F5EE), Color(0xFF085041), Icons.Outlined.Place,
                        t("Bihar GK", "बिहार GK")
                    ) { app.startPractice(ctx, nav, "Bihar GK") }
                    SubjectTile(
                        Modifier.weight(1f), Color(0xFFFAECE7), Color(0xFF712B13), Icons.Outlined.Calculate,
                        t("Maths", "गणित")
                    ) { app.startPractice(ctx, nav, "Maths") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(bottom = 14.dp)) {
                    SubjectTile(
                        Modifier.weight(1f), Color(0xFFFBEAF0), Color(0xFF72243E), Icons.Outlined.Psychology,
                        t("Reasoning", "रीज़निंग")
                    ) { app.startPractice(ctx, nav, "Reasoning") }
                    SubjectTile(
                        Modifier.weight(1f), Color(0xFFFAEEDA), Color(0xFF633806), Icons.Outlined.Newspaper,
                        t("Current affairs", "करेंट अफेयर्स")
                    ) { nav.navigate("affairs") }
                }
                BannerAd(Modifier.padding(top = 4.dp))
            }
            BottomNav("home", nav)
        }
    }
}

@Composable
private fun SubjectTile(
    modifier: Modifier,
    bg: Color,
    fg: Color,
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Tile(bg = bg, fg = fg, modifier = modifier, onClick = onClick) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PracticeScreen(nav: NavController) {
    val app = LocalApp.current
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop(t("Practice by subject", "विषय के अनुसार अभ्यास"), onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            val items: List<Triple<String, String, ImageVector>> = listOf(
                Triple("Bihar GK", t("Bihar GK", "बिहार GK"), Icons.Outlined.Place),
                Triple("General knowledge", t("General knowledge", "सामान्य ज्ञान"), Icons.Outlined.Public),
                Triple("Hindi", t("Hindi", "हिंदी"), Icons.Outlined.Translate),
                Triple("Maths", t("Maths", "गणित"), Icons.Outlined.Calculate),
                Triple("Reasoning", t("Reasoning", "रीज़निंग"), Icons.Outlined.Psychology)
            )
            for (item in items) {
                AppCard(modifier = Modifier.padding(bottom = 12.dp), onClick = { app.startPractice(ctx, nav, item.first) }) {
                    Icon(item.third, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                    Text(item.second, fontSize = 14.sp)
                }
            }
        }
        BottomNav("practice", nav)
    }
}

@Composable
fun TestsScreen(nav: NavController, initialKind: String) {
    val app = LocalApp.current
    val s = app.settings
    val ctx = LocalContext.current
    var kind by remember { mutableStateOf(initialKind) }
    var tests by remember { mutableStateOf<List<TestInfo>?>(null) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(kind, s.exam) {
        tests = null
        failed = false
        try {
            tests = Repo.tests(s.exam, kind)
        } catch (e: Exception) {
            failed = true
            tests = emptyList()
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop(
            if (kind == "mock") t("Mock tests", "मॉक टेस्ट") else t("Previous-year papers", "पिछले वर्षों के पेपर"),
            onBack = { nav.popBackStack() }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 14.dp)) {
            AppChip(t("Mock tests", "मॉक टेस्ट"), kind == "mock") { kind = "mock" }
            AppChip(t("Previous-year papers", "पिछले वर्षों के पेपर"), kind == "pyp") { kind = "pyp" }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            val list = tests
            if (list == null) {
                CenterLoading()
            } else if (list.isEmpty()) {
                Text(
                    if (failed) t("Couldn't load tests. Check your connection.", "टेस्ट लोड नहीं हुए। इंटरनेट जांचें।")
                    else t("No tests here yet. Check back soon.", "यहाँ अभी कोई टेस्ट नहीं है। जल्द आएगा।"),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(8.dp)
                )
            } else {
                for (ti in list) {
                    AppCard(
                        modifier = Modifier.padding(bottom = 12.dp),
                        onClick = {
                            app.startQuiz(ctx, ti.name, ti.name, { nav.navigate("quiz") }) {
                                Repo.questions(s.exam, kind, null, ti.name, 200)
                            }
                        }
                    ) {
                        Icon(
                            if (kind == "mock") Icons.Outlined.Assignment else Icons.Outlined.Description,
                            contentDescription = null,
                            tint = Purple,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(ti.name, fontSize = 14.sp)
                            Text(
                                s.exam + " · " + ti.count + " " + t("questions", "प्रश्न"),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        BottomNav("tests/mock", nav)
    }
}

@Composable
fun AffairsScreen(nav: NavController) {
    val app = LocalApp.current
    val s = app.settings
    val ctx = LocalContext.current
    var posts by remember { mutableStateOf<List<CaPost>?>(null) }
    LaunchedEffect(Unit) {
        posts = try {
            Repo.affairs()
        } catch (e: Exception) {
            emptyList()
        }
    }
    val quizTitle = t("Current affairs", "करेंट अफेयर्स")
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop(quizTitle, onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            AppCard(
                modifier = Modifier.padding(bottom = 12.dp),
                onClick = {
                    app.startQuiz(ctx, quizTitle, "Current affairs", { nav.navigate("quiz") }) {
                        Repo.questions(s.exam, "practice", "Current affairs", null, 40).shuffled().take(Config.PRACTICE_SIZE)
                    }
                }
            ) {
                Icon(Icons.Outlined.Newspaper, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Column {
                    Text(t("Current affairs quiz", "करेंट अफेयर्स क्विज़"), fontSize = 14.sp)
                    Text(
                        t("Practice today's topics", "आज के विषयों का अभ्यास"),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            val list = posts
            if (list == null) {
                CenterLoading()
            } else if (list.isEmpty()) {
                Text(
                    t("No summaries posted yet.", "अभी कोई सारांश नहीं है।"),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(8.dp)
                )
            } else {
                for (p in list) {
                    AppCard(
                        modifier = Modifier.padding(bottom = 12.dp),
                        onClick = {
                            app.selectedPost = p
                            nav.navigate("affairDetail")
                        }
                    ) {
                        Icon(Icons.Outlined.CalendarToday, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                        Column {
                            Text(p.title(s.hindi), fontSize = 14.sp)
                            Text(p.date, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        BottomNav("affairs", nav)
    }
}

@Composable
fun AffairDetailScreen(nav: NavController) {
    val app = LocalApp.current
    val s = app.settings
    val ctx = LocalContext.current
    val post = app.selectedPost
    if (post == null) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    val quizTitle = t("Current affairs", "करेंट अफेयर्स")
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop(quizTitle, onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Text(post.title(s.hindi), fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Text(
                post.date,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 6.dp)
            )
            Text(post.body(s.hindi), fontSize = 15.sp, lineHeight = 24.sp)
        }
        Spacer(Modifier.height(10.dp))
        PrimaryButton(
            t("Start quiz", "क्विज़ शुरू करें"),
            onClick = {
                app.startQuiz(ctx, quizTitle, "Current affairs", { nav.navigate("quiz") }) {
                    Repo.questions(s.exam, "practice", "Current affairs", null, 40).shuffled().take(Config.PRACTICE_SIZE)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun ProgressScreen(nav: NavController) {
    val app = LocalApp.current
    val uid = app.user?.uid
    var results by remember { mutableStateOf<List<ResultRow>?>(null) }
    var streak by remember { mutableIntStateOf(0) }
    LaunchedEffect(uid) {
        if (uid == null) {
            results = emptyList()
        } else {
            try {
                streak = Repo.streak(uid)
                results = Repo.results(uid)
            } catch (e: Exception) {
                results = emptyList()
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop(t("My progress", "मेरी प्रगति"), onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            val list = results
            if (list == null) {
                CenterLoading()
            } else {
                val last = list.firstOrNull()
                val lastPct = if (last != null && last.total > 0) (last.correct * 100 / last.total) else null
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                    Tile(Color(0xFFEEEDFE), Color(0xFF3C3489), Modifier.weight(1f)) {
                        Text("$streak", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                        Text(t("Day streak", "दिन की स्ट्रीक"), fontSize = 12.sp)
                    }
                    Tile(Color(0xFFE1F5EE), Color(0xFF085041), Modifier.weight(1f)) {
                        Text(if (lastPct != null) "$lastPct%" else "-", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                        Text(t("Last test", "पिछला टेस्ट"), fontSize = 12.sp)
                    }
                }
                val stats = LinkedHashMap<String, IntArray>()
                for (r in list) {
                    for (i in r.subjects.indices) {
                        val arr = stats.getOrPut(r.subjects[i]) { IntArray(2) }
                        arr[1] += 1
                        if (r.corrects.getOrNull(i) == true) arr[0] += 1
                    }
                }
                if (stats.isEmpty()) {
                    Text(
                        t("Take a quiz to see your progress here.", "अपनी प्रगति देखने के लिए क्विज़ दें।"),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp
                    )
                } else {
                    Text(
                        t("Subject accuracy", "विषय के अनुसार सटीकता"),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    for ((subject, arr) in stats) {
                        val frac = if (arr[1] > 0) arr[0].toFloat() / arr[1] else 0f
                        val color = if (frac >= 0.7f) Color(0xFF1D9E75) else if (frac >= 0.5f) Color(0xFFBA7517) else Color(0xFFE24B4A)
                        Text(subject, fontSize = 13.sp)
                        Box(
                            Modifier.fillMaxWidth().height(8.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                        ) {
                            Box(
                                Modifier.fillMaxWidth(frac).fillMaxHeight().background(color, RoundedCornerShape(8.dp))
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                    val weak = stats.entries.filter { it.value[1] > 0 && it.value[0].toFloat() / it.value[1] < 0.6f }
                        .sortedBy { it.value[0].toFloat() / it.value[1] }.take(3).map { it.key }
                    if (weak.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        AppCardColumn {
                            Text(t("Weak topics", "कमज़ोर विषय"), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text(weak.joinToString(", "), fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        BottomNav("progress", nav)
    }
}
