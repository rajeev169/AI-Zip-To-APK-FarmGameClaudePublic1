package com.appforge.examprep

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.TrackChanges
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

@Composable
fun QuizScreen(nav: NavController) {
    val app = LocalApp.current
    val s = app.settings
    val session = app.session
    if (session == null) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    var secs by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            secs++
        }
    }
    var showError by remember { mutableStateOf(false) }
    val idx = session.index
    val q = session.questions[idx]
    val answered = session.answers[idx]
    val options = q.options(s.hindi)

    fun advance() {
        showError = false
        if (session.index < session.questions.size - 1) {
            session.index = session.index + 1
        } else {
            nav.navigate("result") { popUpTo("quiz") { inclusive = true } }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { nav.popBackStack() }, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Close")
            }
            val pill = RoundedCornerShape(20.dp)
            Row(
                modifier = Modifier
                    .deepShadow(pill, 5.dp)
                    .background(Color(0xFFFAECE7), pill)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Outlined.Schedule, contentDescription = null, tint = Color(0xFF712B13), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                val mm = (secs / 60).toString().padStart(2, '0')
                val ss = (secs % 60).toString().padStart(2, '0')
                Text("$mm:$ss", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF712B13))
            }
            AppChip("EN / हिं", false) { s.updateHindi(!s.hindi) }
        }
        val fraction = (idx + 1).toFloat() / session.questions.size
        Box(
            Modifier.fillMaxWidth().height(8.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
        ) {
            Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(Purple, RoundedCornerShape(8.dp)))
        }
        Text(
            t("Question ", "प्रश्न ") + (idx + 1) + t(" of ", " / ") + session.questions.size + " · " + session.title,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp, bottom = 14.dp)
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Text(
                q.text(s.hindi),
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 26.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            for (i in options.indices) {
                val isCorrect = i == q.answer
                val isWrongPick = answered != null && i == answered && !isCorrect
                val showCorrect = answered != null && isCorrect
                val shape = RoundedCornerShape(16.dp)
                val bg = if (showCorrect) Color(0xFFE1F5EE) else if (isWrongPick) Color(0xFFFCEBEB) else MaterialTheme.colorScheme.surface
                val fg = if (showCorrect) Color(0xFF085041) else if (isWrongPick) Color(0xFF791F1F) else MaterialTheme.colorScheme.onSurface
                val borderColor = if (showCorrect) Color(0xFF0F6E56) else if (isWrongPick) Color(0xFFA32D2D) else MaterialTheme.colorScheme.outline
                val borderWidth = if (showCorrect || isWrongPick) 2.dp else 0.5.dp
                Row(
                    modifier = Modifier
                        .padding(bottom = 12.dp)
                        .fillMaxWidth()
                        .deepShadow(shape)
                        .background(bg, shape)
                        .border(borderWidth, borderColor, shape)
                        .clip(shape)
                        .clickable {
                            if (session.answers[idx] == null) {
                                session.answers[idx] = i
                                showError = false
                            }
                        }
                        .padding(12.dp)
                ) {
                    Text("ABCD"[i].toString(), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = fg)
                    Spacer(Modifier.width(10.dp))
                    Text(options[i], fontSize = 14.sp, color = fg)
                }
            }
            if (answered != null) {
                val exp = q.explanation(s.hindi)
                val lead = if (answered == q.answer) t("Correct. ", "सही। ") else t("Not quite. ", "सही नहीं। ")
                Text(lead + exp, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (showError && answered == null) {
                Text(
                    t("Pick an answer or tap Skip", "कोई उत्तर चुनें या Skip दबाएं"),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlineButton(t("Skip", "छोड़ें"), onClick = { advance() }, modifier = Modifier.weight(1f))
            PrimaryButton(
                if (idx == session.questions.size - 1) t("Finish", "समाप्त") else t("Next", "अगला"),
                onClick = { if (session.answers[idx] == null) showError = true else advance() },
                modifier = Modifier.weight(2f)
            )
        }
    }
}

@Composable
fun ResultScreen(nav: NavController) {
    val app = LocalApp.current
    val s = app.settings
    val session = app.session
    if (session == null) {
        LaunchedEffect(Unit) { nav.popBackStack("home", false) }
        return
    }
    LaunchedEffect(Unit) {
        val uid = app.user?.uid
        if (!session.saved && uid != null) {
            session.saved = true
            val subjects = session.questions.map { it.subject }
            val corrects = session.questions.indices.map { session.answers[it] == session.questions[it].answer }
            val c = session.correct
            val n = session.questions.size
            val title = session.title
            app.appScope.launch {
                try {
                    Repo.saveResult(uid, title, subjects, corrects, c, n)
                } catch (e: Exception) {
                    // saved later by Firestore when online
                }
            }
        }
    }
    val total = session.questions.size
    val correct = session.correct
    val frac = if (total > 0) correct.toFloat() / total else 0f
    val track = MaterialTheme.colorScheme.primaryContainer
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(t("Test complete", "टेस्ट पूरा हुआ"), fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Text(
            s.exam + " · " + session.title,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )
        Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 16.dp.toPx()
                val sz = Size(size.width - sw, size.height - sw)
                val tl = Offset(sw / 2, sw / 2)
                drawArc(color = track, startAngle = -90f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(width = sw))
                drawArc(
                    color = Purple,
                    startAngle = -90f,
                    sweepAngle = 360f * frac,
                    useCenter = false,
                    topLeft = tl,
                    size = sz,
                    style = Stroke(width = sw, cap = StrokeCap.Round)
                )
            }
            Text("$correct/$total", fontSize = 28.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(bottom = 18.dp)) {
            Tile(Color(0xFFE1F5EE), Color(0xFF085041), Modifier.weight(1f)) {
                Text("$correct", fontSize = 20.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text(t("Correct", "सही"), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            Tile(Color(0xFFFCEBEB), Color(0xFF791F1F), Modifier.weight(1f)) {
                Text("${session.wrong}", fontSize = 20.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text(t("Wrong", "गलत"), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            Tile(Color(0xFFF1EFE8), Color(0xFF444441), Modifier.weight(1f)) {
                Text("${session.skipped}", fontSize = 20.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text(t("Skipped", "छोड़े"), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        PrimaryButton(t("Review answers", "उत्तर देखें"), onClick = { nav.navigate("review") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlineButton(t("Back to home", "होम पर जाएं"), onClick = { nav.popBackStack("home", false) }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun ReviewScreen(nav: NavController) {
    val app = LocalApp.current
    val s = app.settings
    val session = app.session
    if (session == null) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop(t("Review answers", "उत्तर देखें"), onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            for (i in session.questions.indices) {
                val q = session.questions[i]
                val a = session.answers[i]
                val opts = q.options(s.hindi)
                val ok = a == q.answer
                AppCardColumn(modifier = Modifier.padding(bottom = 12.dp)) {
                    Text("${i + 1}. " + q.text(s.hindi), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(4.dp))
                    val status = if (a == null) t("Skipped", "छोड़ा") else if (ok) t("Correct", "सही") else t("Your answer: ", "आपका उत्तर: ") + opts[a]
                    Text(status, fontSize = 12.sp, color = if (ok) Color(0xFF0F6E56) else Color(0xFFA32D2D))
                    Text(
                        t("Answer: ", "उत्तर: ") + opts[q.answer] + (if (q.explanation(s.hindi).isNotBlank()) ". " + q.explanation(s.hindi) else ""),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(nav: NavController) {
    val app = LocalApp.current
    val s = app.settings
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            s.updateReminder(true)
            Reminder.set(ctx, true)
        } else {
            Toast.makeText(ctx, app.tr("Allow notifications to get reminders", "रिमाइंडर के लिए नोटिफिकेशन की अनुमति दें"), Toast.LENGTH_LONG).show()
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop(t("Settings", "सेटिंग्स"), onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            AppCard(
                modifier = Modifier.padding(bottom = 12.dp),
                onClick = {
                    val next = Config.EXAMS[(Config.EXAMS.indexOf(s.exam) + 1) % Config.EXAMS.size]
                    s.updateExam(next)
                }
            ) {
                Icon(Icons.Outlined.TrackChanges, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Column(Modifier.weight(1f)) {
                    Text(t("Exam", "परीक्षा"), fontSize = 14.sp)
                    Text(s.exam, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            AppCard(modifier = Modifier.padding(bottom = 12.dp), onClick = { s.updateHindi(!s.hindi) }) {
                Icon(Icons.Outlined.Translate, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Column(Modifier.weight(1f)) {
                    Text(t("Language", "भाषा"), fontSize = 14.sp)
                    Text(if (s.hindi) "हिन्दी" else "English", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            AppCard(modifier = Modifier.padding(bottom = 12.dp), onClick = { s.updateDark(!s.dark) }) {
                Icon(Icons.Outlined.DarkMode, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Text(t("Dark mode", "डार्क मोड"), fontSize = 14.sp, modifier = Modifier.weight(1f))
                Switch(checked = s.dark, onCheckedChange = null, colors = SwitchDefaults.colors(checkedTrackColor = Purple))
            }
            AppCard(
                modifier = Modifier.padding(bottom = 12.dp),
                onClick = {
                    if (s.reminder) {
                        s.updateReminder(false)
                        Reminder.set(ctx, false)
                    } else if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) {
                        permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        s.updateReminder(true)
                        Reminder.set(ctx, true)
                    }
                }
            ) {
                Icon(Icons.Outlined.Notifications, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Text(t("Daily reminder", "रोज़ का रिमाइंडर"), fontSize = 14.sp, modifier = Modifier.weight(1f))
                Switch(checked = s.reminder, onCheckedChange = null, colors = SwitchDefaults.colors(checkedTrackColor = Purple))
            }
            AppCard(modifier = Modifier.padding(bottom = 12.dp), onClick = { nav.navigate("report") }) {
                Icon(Icons.Outlined.Flag, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Text(t("Report wrong question", "गलत प्रश्न बताएं"), fontSize = 14.sp)
            }
            AppCard(modifier = Modifier.padding(bottom = 12.dp), onClick = { nav.navigate("about") }) {
                Icon(Icons.Outlined.Info, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Text(t("About", "ऐप के बारे में"), fontSize = 14.sp)
            }
            AppCard(
                modifier = Modifier.padding(bottom = 12.dp),
                onClick = {
                    scope.launch {
                        Auth.signOut(ctx)
                        app.user = null
                        app.session = null
                        nav.navigate("login") { popUpTo(nav.graph.id) { inclusive = true } }
                    }
                }
            ) {
                Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Text(t("Sign out", "साइन आउट"), fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun ReportScreen(nav: NavController) {
    val app = LocalApp.current
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop(t("Report wrong question", "गलत प्रश्न बताएं"), onBack = { nav.popBackStack() })
        OutlinedTextField(
            value = text,
            onValueChange = {
                text = it
                error = false
            },
            modifier = Modifier.fillMaxWidth(),
            minLines = 5,
            placeholder = { Text(t("Tell us what's wrong with the question", "प्रश्न में क्या गलती है, बताएं")) }
        )
        if (error) {
            Text(
                t("Describe the problem first", "पहले समस्या लिखें"),
                color = MaterialTheme.colorScheme.error,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        Spacer(Modifier.height(12.dp))
        PrimaryButton(
            t("Send report", "रिपोर्ट भेजें"),
            onClick = {
                if (text.isBlank()) {
                    error = true
                } else {
                    val msg = text.trim()
                    val email = Repo.currentEmail()
                    app.appScope.launch {
                        try {
                            Repo.sendReport(msg, email)
                        } catch (e: Exception) {
                            // queued by Firestore when offline
                        }
                    }
                    Toast.makeText(ctx, app.tr("Report sent", "रिपोर्ट भेज दी गई"), Toast.LENGTH_SHORT).show()
                    nav.popBackStack()
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun AboutScreen(nav: NavController) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop(t("About", "ऐप के बारे में"), onBack = { nav.popBackStack() })
        Text(
            t(
                "Exam Prep helps students practice for Bihar Police, BPSC and Railway exams in Hindi and English. Version 1.0",
                "Exam Prep बिहार पुलिस, BPSC और रेलवे परीक्षा की तैयारी हिंदी और अंग्रेज़ी में कराता है। वर्जन 1.0"
            ),
            fontSize = 14.sp,
            lineHeight = 22.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun AdminScreen(nav: NavController) {
    val app = LocalApp.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    if (!app.isAdmin) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            ScreenTop("Admin panel", onBack = { nav.popBackStack() })
            Text("This area is only for the app admin.", fontSize = 14.sp)
        }
        return
    }
    var qCount by remember { mutableStateOf<Long?>(null) }
    var rCount by remember { mutableStateOf<Long?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    var showPost by remember { mutableStateOf(false) }

    fun refresh() {
        scope.launch {
            try {
                qCount = Repo.countQuestions()
                rCount = Repo.countReports()
            } catch (e: Exception) {
                // ignore
            }
        }
    }
    // Refresh when the screen is shown again (for example after fixing reports).
    val entry by nav.currentBackStackEntryAsState()
    LaunchedEffect(entry) { refresh() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            working = true
            scope.launch {
                try {
                    val text = withContext(Dispatchers.IO) {
                        ctx.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    }
                    val res = Csv.toQuestions(text)
                    var added = 0
                    if (res.questions.isNotEmpty()) {
                        added = Repo.importQuestions(res.questions) { }
                    }
                    val errs = if (res.errors.isEmpty()) "" else "\n" + res.errors.take(5).joinToString("\n")
                    message = "Added $added question entries. Skipped ${res.errors.size} rows." + errs
                    refresh()
                } catch (e: Exception) {
                    message = "Upload failed: " + (e.message ?: "unknown error")
                }
                working = false
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop("Admin panel", onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                Tile(Color(0xFFEEEDFE), Color(0xFF3C3489), Modifier.weight(1f)) {
                    Text(qCount?.toString() ?: "-", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    Text("Questions", fontSize = 12.sp)
                }
                Tile(Color(0xFFFAEEDA), Color(0xFF633806), Modifier.weight(1f)) {
                    Text(rCount?.toString() ?: "-", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    Text("Reported", fontSize = 12.sp)
                }
            }
            AppCard(modifier = Modifier.padding(bottom = 12.dp), onClick = { if (!working) picker.launch(arrayOf("*/*")) }) {
                Icon(Icons.Outlined.FileUpload, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Text(if (working) "Uploading..." else "Upload questions (CSV)", fontSize = 14.sp)
            }
            AppCard(modifier = Modifier.padding(bottom = 12.dp), onClick = { showPost = true }) {
                Icon(Icons.Outlined.Newspaper, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Text("Post current affairs", fontSize = 14.sp)
            }
            AppCard(modifier = Modifier.padding(bottom = 12.dp), onClick = { nav.navigate("adminReports") }) {
                Icon(Icons.Outlined.Flag, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
                Text("Fix reported questions", fontSize = 14.sp)
            }
        }
    }

    val msg = message
    if (msg != null) {
        AlertDialog(
            onDismissRequest = { message = null },
            confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } },
            title = { Text("Upload result") },
            text = { Text(msg) }
        )
    }
    if (showPost) {
        var titleEn by remember { mutableStateOf("") }
        var titleHi by remember { mutableStateOf("") }
        var bodyEn by remember { mutableStateOf("") }
        var bodyHi by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPost = false },
            confirmButton = {
                TextButton(onClick = {
                    if (titleEn.isBlank() || bodyEn.isBlank()) {
                        Toast.makeText(ctx, "English title and text are required", Toast.LENGTH_SHORT).show()
                    } else {
                        val date = LocalDate.now().toString()
                        showPost = false
                        scope.launch {
                            try {
                                Repo.postAffair(date, titleEn.trim(), titleHi.trim(), bodyEn.trim(), bodyHi.trim())
                                Toast.makeText(ctx, "Posted", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "Could not post: " + (e.message ?: ""), Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }) { Text("Post") }
            },
            dismissButton = { TextButton(onClick = { showPost = false }) { Text("Cancel") } },
            title = { Text("Post current affairs") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = titleEn, onValueChange = { titleEn = it }, label = { Text("Title (English)") }, singleLine = true)
                    OutlinedTextField(value = titleHi, onValueChange = { titleHi = it }, label = { Text("Title (Hindi)") }, singleLine = true)
                    OutlinedTextField(value = bodyEn, onValueChange = { bodyEn = it }, label = { Text("Text (English)") }, minLines = 3)
                    OutlinedTextField(value = bodyHi, onValueChange = { bodyHi = it }, label = { Text("Text (Hindi)") }, minLines = 3)
                }
            }
        )
    }
}

@Composable
fun AdminReportsScreen(nav: NavController) {
    val app = LocalApp.current
    val scope = rememberCoroutineScope()
    var reports by remember { mutableStateOf<List<ReportRow>?>(null) }
    fun load() {
        scope.launch {
            reports = try {
                Repo.reports()
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
    LaunchedEffect(Unit) { load() }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTop("Reported questions", onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            val list = reports
            if (!app.isAdmin) {
                Text("This area is only for the app admin.", fontSize = 14.sp)
            } else if (list == null) {
                CenterLoading()
            } else if (list.isEmpty()) {
                Text("No reports. All clear.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                for (r in list) {
                    AppCardColumn(modifier = Modifier.padding(bottom = 12.dp)) {
                        Text(r.text, fontSize = 14.sp)
                        Text(r.email, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = {
                            scope.launch {
                                try {
                                    Repo.deleteReport(r.id)
                                } catch (e: Exception) {
                                    // ignore
                                }
                                load()
                            }
                        }) { Text("Mark fixed") }
                    }
                }
            }
        }
    }
}
