package com.appforge.examprep

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

val Purple = Color(0xFF534AB7)
val PurpleLight = Color(0xFFEEEDFE)
val PurpleDark = Color(0xFF3C3489)

private val LightColors: ColorScheme = lightColorScheme(
    primary = Purple,
    onPrimary = Color.White,
    primaryContainer = PurpleLight,
    onPrimaryContainer = PurpleDark,
    background = Color.White,
    onBackground = Color(0xFF1F1F1D),
    surface = Color.White,
    onSurface = Color(0xFF1F1F1D),
    surfaceVariant = Color(0xFFF1EFE8),
    onSurfaceVariant = Color(0xFF5F5E5A),
    outline = Color(0xFFB4B2A9),
    outlineVariant = Color(0xFFD3D1C7),
    error = Color(0xFFA32D2D)
)

private val DarkColors: ColorScheme = darkColorScheme(
    primary = Color(0xFF7F77DD),
    onPrimary = Color.White,
    primaryContainer = PurpleDark,
    onPrimaryContainer = PurpleLight,
    background = Color(0xFF1E1E1C),
    onBackground = Color(0xFFF1EFE8),
    surface = Color(0xFF2C2C2A),
    onSurface = Color(0xFFF1EFE8),
    surfaceVariant = Color(0xFF3A3A37),
    onSurfaceVariant = Color(0xFFB4B2A9),
    outline = Color(0xFF888780),
    outlineVariant = Color(0xFF4A4A47),
    error = Color(0xFFF09595)
)

@Composable
fun AppTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}

fun Modifier.deepShadow(shape: Shape, elevation: Dp = 10.dp): Modifier =
    this.shadow(
        elevation = elevation,
        shape = shape,
        clip = false,
        ambientColor = Color.Black.copy(alpha = 0.30f),
        spotColor = Color.Black.copy(alpha = 0.40f)
    )

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    var m: Modifier = modifier
        .fillMaxWidth()
        .deepShadow(shape)
        .background(MaterialTheme.colorScheme.surface, shape)
        .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, shape)
        .clip(shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Row(
        modifier = m.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
fun AppCardColumn(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .deepShadow(shape)
            .background(MaterialTheme.colorScheme.surface, shape)
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .clip(shape)
            .padding(12.dp),
        content = content
    )
}

@Composable
fun Tile(
    bg: Color,
    fg: Color,
    modifier: Modifier = Modifier,
    radius: Dp = 20.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    var m: Modifier = modifier.deepShadow(shape).background(bg, shape).clip(shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    CompositionLocalProvider(LocalContentColor provides fg) {
        Column(modifier = m.padding(14.dp), content = content)
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = modifier
            .shadow(
                elevation = 10.dp,
                shape = shape,
                clip = false,
                ambientColor = Purple.copy(alpha = 0.5f),
                spotColor = Purple.copy(alpha = 0.7f)
            )
            .background(Purple, shape)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
    }
}

@Composable
fun OutlineButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = modifier
            .deepShadow(shape, 6.dp)
            .background(MaterialTheme.colorScheme.surface, shape)
            .border(BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline), shape)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center)
    }
}

@Composable
fun AppChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val bg = if (selected) Purple else MaterialTheme.colorScheme.surface
    val fg = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
    Box(
        modifier = Modifier
            .deepShadow(shape, 5.dp)
            .background(bg, shape)
            .border(0.5.dp, if (selected) Purple else MaterialTheme.colorScheme.outline, shape)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = fg, fontSize = 12.sp)
    }
}

@Composable
fun ScreenTop(title: String, onBack: (() -> Unit)?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
        } else {
            Spacer(Modifier.width(40.dp))
        }
        Text(
            title,
            modifier = Modifier.weight(1f),
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.width(40.dp))
    }
}

@Composable
fun BottomNav(current: String, nav: NavController) {
    val items: List<Triple<String, String, ImageVector>> = listOf(
        Triple("home", t("Home", "होम"), Icons.Outlined.Home),
        Triple("practice", t("Practice", "अभ्यास"), Icons.Outlined.Edit),
        Triple("tests/mock", t("Mock tests", "मॉक टेस्ट"), Icons.Outlined.Assignment),
        Triple("progress", t("Progress", "प्रगति"), Icons.Outlined.BarChart)
    )
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            for (item in items) {
                val route = item.first
                val tint = if (route == current) Purple else MaterialTheme.colorScheme.onSurfaceVariant
                Column(
                    modifier = Modifier
                        .clickable {
                            nav.navigate(route) {
                                popUpTo("home")
                                launchSingleTop = true
                            }
                        }
                        .padding(horizontal = 10.dp, vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(item.third, contentDescription = item.second, tint = tint, modifier = Modifier.size(22.dp))
                    Text(item.second, fontSize = 11.sp, color = tint)
                }
            }
        }
    }
}

@Composable
fun BannerAd(modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = Config.BANNER_AD_UNIT
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}

@Composable
fun CenterLoading() {
    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Purple)
    }
}
