# FileLite

A small Solid Explorer-style file manager for Android, written in Kotlin with Jetpack Compose.

## Features included

| Feature | Where |
|---|---|
| Dual-pane browsing (tap a pane to make it active) | Files tab |
| Copy / move between panes, delete, rename, new folder | Action bar under the panes |
| Multi-select (long-press a file) | Files tab |
| Zip and extract (zip-slip protected) | Action bar |
| Encrypt / decrypt files (AES-256-GCM, PBKDF2 password key) | Action bar |
| Built-in viewers: images, text, audio player | Tap a file |
| Other files open in another app (FileProvider) | Tap a file |
| Search by name | Search tab |
| Categories (images, audio, video, documents, APKs, archives) | Categories tab |
| Storage analysis (used / free, size per category) | Storage tab |
| Fingerprint / screen-lock app lock | Fingerprint icon in the top bar |
| Show hidden files, light / dark theme | Top bar |

## App data tab (Android/data and Android/obb)

| Android version | How it works |
|---|---|
| 10 and older | Opens the folders directly |
| 11 and 12 | Tap "Grant Android/data access", then "Use this folder" |
| 11 and newer | **Built-in ADB**: FileLite pairs with your phone's own Wireless debugging once, then runs shell commands itself. No other app needed. This is the only way on Android 13+. |

Pairing steps: Wi-Fi on, Developer options on, Wireless debugging on, "Pair device with pairing code", then type the port and 6-digit code in FileLite (use split-screen or a pop-up window so the box stays open). The key is saved in the app, so pairing is needed only once.

Tap a folder to enter it. Tap a file to copy it to `Download/FileLite_export` and open it. Tap the download icon to copy a file or a whole folder there. Then you can find it in the Files tab.

Libraries: `libadb-android` (JitPack), `sun-security-android`, `conscrypt-android`. The libadb version in `app/build.gradle.kts` was not verified, so check JitPack for the newest one. The library's own README says it has never had a security audit.

Warning: Google is discussing blocking apps on the same phone from connecting to its own ADB. If that ships in a future Android version, this feature (and Shizuku) would stop working there.

## Not included (needs much more work)

- Cloud accounts (Google Drive, Dropbox, OneDrive)
- Network storage (FTP, SFTP, SMB)
- Root explorer
- RAR / 7z extraction (only zip is supported)

## How to build

1. Install Android Studio (Koala or newer).
2. Choose **File → Open** and select this folder. Let Gradle sync; it downloads the wrapper and libraries.
3. Plug in a phone (USB debugging on) or start an emulator, then press **Run**.
4. On first start tap **Allow access** and switch on "Allow access to manage all files".

## Notes

- Android 11+ blocks apps from `Android/data` and `Android/obb` of other apps, even with all-files access. FileLite can browse them only on Android 10 and below.
- Apps with `MANAGE_EXTERNAL_STORAGE` need extra approval to be published on Google Play. For personal use it is fine.
- This code was written without a build environment, so expect to fix a small compile error or two on first sync.

## Project layout

```
app/src/main/java/com/example/filelite/
  MainActivity.kt        permission, app lock, theme
  ExplorerViewModel.kt   state for the two panes and the file actions
  FileOps.kt             copy, move, zip, unzip, search, storage, encryption
  ExplorerScreen.kt      all screens (files, search, categories, storage)
  Viewers.kt             image, text and audio viewers
```
