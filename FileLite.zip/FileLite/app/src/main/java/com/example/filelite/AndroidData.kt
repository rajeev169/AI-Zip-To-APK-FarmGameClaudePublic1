package com.example.filelite

import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.documentfile.provider.DocumentFile
import java.io.File

/** One item shown in the "App data" tab. [ref] is a file path or a document Uri, depending on the source. */
data class DEntry(val name: String, val isDir: Boolean, val ref: String)

interface DataSource {
    val label: String
    val roots: List<DEntry>
    fun list(ref: String): List<DEntry>
    /** Copies the entry (file or folder) into [dest] and returns the copy. */
    fun export(e: DEntry, dest: File): File
}

val EXPORT_DIR: File get() = File(Environment.getExternalStorageDirectory(), "Download/FileLite_export")

private val androidDir: File get() = File(Environment.getExternalStorageDirectory(), "Android")

private fun pathRoots() = listOf(
    DEntry("Android/data", true, File(androidDir, "data").path),
    DEntry("Android/obb", true, File(androidDir, "obb").path)
)

// ---------------------------------------------------------------- Android 10 and older

class DirectSource : DataSource {
    override val label = "Direct access"
    override val roots = pathRoots()

    override fun list(ref: String): List<DEntry> =
        (File(ref).listFiles() ?: emptyArray()).map { DEntry(it.name, it.isDirectory, it.path) }

    override fun export(e: DEntry, dest: File): File {
        dest.mkdirs()
        val src = File(e.ref)
        val out = File(dest, src.name)
        if (src.isDirectory) src.copyRecursively(out, overwrite = true) else src.copyTo(out, overwrite = true)
        return out
    }
}

// ---------------------------------------------------------------- Android 11 and 12 (folder access)

class SafSource(private val ctx: Context, private val treeUri: String) : DataSource {
    override val label = "Folder access"
    override val roots = listOf(DEntry("Android/data", true, treeUri))

    override fun list(ref: String): List<DEntry> =
        DocumentFile.fromTreeUri(ctx, Uri.parse(ref))?.listFiles()
            ?.map { DEntry(it.name ?: "?", it.isDirectory, it.uri.toString()) }
            ?: throw IllegalStateException("Cannot open this folder")

    override fun export(e: DEntry, dest: File): File {
        dest.mkdirs()
        val doc = DocumentFile.fromTreeUri(ctx, Uri.parse(e.ref))
            ?: throw IllegalStateException("Cannot open ${e.name}")
        return copyDoc(doc, dest)
    }

    private fun copyDoc(d: DocumentFile, destDir: File): File {
        val out = File(destDir, d.name ?: "unnamed")
        if (d.isDirectory) {
            out.mkdirs()
            d.listFiles().forEach { copyDoc(it, out) }
        } else {
            ctx.contentResolver.openInputStream(d.uri)?.use { i -> out.outputStream().use { i.copyTo(it) } }
        }
        return out
    }
}

// ---------------------------------------------------------------- Android 11+ : built-in ADB (no other app needed)

private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

class AdbSource(private val ctx: Context) : DataSource {
    override val label = "Built-in ADB"
    override val roots = pathRoots()

    override fun list(ref: String): List<DEntry> {
        val (code, out) = AdbShell.exec(ctx, "ls -1pA ${q(ref)}")
        if (code != 0) throw IllegalStateException(out.trim().ifEmpty { "Cannot list folder" })
        return out.lines().filter { it.isNotBlank() }.map {
            val dir = it.endsWith("/")
            val name = it.removeSuffix("/")
            DEntry(name, dir, ref.trimEnd('/') + "/" + name)
        }
    }

    override fun export(e: DEntry, dest: File): File {
        val d = q(dest.path)
        val (code, out) = AdbShell.exec(
            ctx,
            "mkdir -p $d && cp -rf ${q(e.ref)} $d/ && (chmod -R a+rX $d 2>/dev/null; true)"
        )
        if (code != 0) throw IllegalStateException(out.trim().ifEmpty { "Copy failed" })
        return File(dest, e.name)
    }
}
