package com.example.filelite

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Browse the Android/data and Android/obb folders of other apps.
 * Tap a file to copy it to Download/FileLite_export and open it; tap the download icon to copy a file or folder.
 */
@Composable
fun AndroidDataScreen(onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("filelite", Context.MODE_PRIVATE) }
    var tick by remember { mutableStateOf(0) }
    var safUri by remember { mutableStateOf(prefs.getString("saf_uri", null)) }

    // null = still checking, true / false = built-in ADB connected or not
    var adbOn by remember { mutableStateOf<Boolean?>(if (Build.VERSION.SDK_INT >= 30) null else false) }
    LaunchedEffect(tick) {
        if (Build.VERSION.SDK_INT >= 30) {
            adbOn = null
            adbOn = withContext(Dispatchers.IO) { AdbShell.ensureConnected(ctx) }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            prefs.edit().putString("saf_uri", uri.toString()).apply()
            safUri = uri.toString()
        }
    }

    val source: DataSource? = remember(adbOn, safUri) {
        when {
            Build.VERSION.SDK_INT <= 29 -> DirectSource()
            adbOn == true -> AdbSource(ctx)
            safUri != null && Build.VERSION.SDK_INT <= 32 -> SafSource(ctx, safUri!!)
            else -> null
        }
    }

    when {
        source != null -> Browser(source, ctx, onOpen)
        adbOn == null -> Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("Checking the built-in ADB connection…")
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 12.dp))
        }
        else -> SetupScreen(
            canUseFolderAccess = Build.VERSION.SDK_INT in 30..32,
            onFolderAccess = {
                val initial = DocumentsContract.buildDocumentUri(
                    "com.android.externalstorage.documents", "primary:Android/data"
                )
                picker.launch(initial)
            },
            onConnected = { tick++ },
            ctx = ctx
        )
    }
}

@Composable
private fun SetupScreen(
    canUseFolderAccess: Boolean,
    onFolderAccess: () -> Unit,
    onConnected: () -> Unit,
    ctx: Context
) {
    val scope = rememberCoroutineScope()
    var port by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Android/data is protected", style = MaterialTheme.typography.titleLarge)
        Text(
            "Android ${Build.VERSION.RELEASE} does not let normal apps open other apps' data folders. FileLite can connect to your phone's own Wireless debugging to get around this. You do this once.",
            modifier = Modifier.padding(vertical = 8.dp)
        )

        Text("Built-in ADB connection", style = MaterialTheme.typography.titleMedium)
        Text(
            "1. Connect to Wi-Fi.\n" +
                "2. Turn on Developer options (Settings → About phone → tap Build number 7 times).\n" +
                "3. In Developer options, turn on Wireless debugging.\n" +
                "4. Tap \"Pair device with pairing code\". Keep that box open and put FileLite next to it in split-screen or a pop-up window, because the box closes when you leave it.\n" +
                "5. Type the port number and the 6-digit code from that box below, then tap Pair."
        )
        OutlinedButton(
            onClick = { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) },
            modifier = Modifier.padding(top = 8.dp)
        ) { Text("Open Developer options") }

        OutlinedTextField(
            value = port,
            onValueChange = { port = it.filter(Char::isDigit) },
            label = { Text("Pairing port") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        OutlinedTextField(
            value = code,
            onValueChange = { code = it.filter(Char::isDigit) },
            label = { Text("Pairing code (6 digits)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        Row(Modifier.padding(top = 8.dp)) {
            Button(
                enabled = !busy && port.isNotEmpty() && code.length == 6,
                onClick = {
                    scope.launch {
                        busy = true
                        info = withContext(Dispatchers.IO) {
                            try {
                                if (!AdbShell.pair(ctx, port.toInt(), code)) "Pairing failed. Check the port and code."
                                else if (AdbShell.ensureConnected(ctx)) "OK" else "Paired, but could not connect. Make sure Wireless debugging is on, then tap Connect."
                            } catch (e: Exception) {
                                "Pairing error: ${e.message}"
                            }
                        }
                        busy = false
                        if (info == "OK") onConnected()
                    }
                }
            ) { Text("Pair") }
            OutlinedButton(
                enabled = !busy,
                onClick = {
                    scope.launch {
                        busy = true
                        val ok = withContext(Dispatchers.IO) { AdbShell.ensureConnected(ctx) }
                        busy = false
                        if (ok) onConnected()
                        else info = "Could not connect. Turn on Wireless debugging and pair first."
                    }
                },
                modifier = Modifier.padding(start = 8.dp)
            ) { Text("Connect") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        info?.takeIf { it != "OK" }?.let {
            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        }

        if (canUseFolderAccess) {
            HorizontalDivider(Modifier.padding(vertical = 16.dp))
            Text("Or: folder access (Android 11–12 only)", style = MaterialTheme.typography.titleMedium)
            Text("Tap the button, then press \"Use this folder\" while Android/data is open.")
            Button(onClick = onFolderAccess, modifier = Modifier.padding(top = 8.dp)) {
                Text("Grant Android/data access")
            }
        }
    }
}

@Composable
private fun Browser(source: DataSource, ctx: Context, onOpen: (File) -> Unit) {
    var stack by remember(source) { mutableStateOf(listOf<DEntry>()) }
    val current = stack.lastOrNull()
    val scope = rememberCoroutineScope()
    var working by remember { mutableStateOf(false) }

    val result by produceState<Pair<List<DEntry>, String?>?>(null, source, current) {
        value = null
        value = withContext(Dispatchers.IO) {
            try {
                val list = if (current == null) source.roots else source.list(current.ref)
                list.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() })) to null
            } catch (e: Exception) {
                emptyList<DEntry>() to (e.message ?: "Cannot open this folder")
            }
        }
    }

    fun export(e: DEntry, open: Boolean) {
        scope.launch {
            working = true
            val r = withContext(Dispatchers.IO) { runCatching { source.export(e, EXPORT_DIR) } }
            working = false
            r.onSuccess {
                Toast.makeText(ctx, "Saved to ${it.path}", Toast.LENGTH_LONG).show()
                if (open && it.isFile) onOpen(it)
            }.onFailure {
                Toast.makeText(ctx, "Error: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { stack = stack.dropLast(1) }, enabled = stack.isNotEmpty()) {
                Icon(Icons.Default.ArrowBack, "Back")
            }
            Text(
                if (stack.isEmpty()) "App data  (${source.label})" else stack.joinToString(" / ") { it.name },
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (working || result == null) LinearProgressIndicator(Modifier.fillMaxWidth())
        val (entries, error) = result ?: (emptyList<DEntry>() to null)
        if (error != null) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
        if (error == null && result != null && entries.isEmpty()) Text("Empty folder", modifier = Modifier.padding(16.dp))

        LazyColumn(Modifier.fillMaxSize()) {
            items(entries, key = { it.ref }) { e ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { if (e.isDir) stack = stack + e else export(e, open = true) }
                        .padding(start = 12.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (e.isDir) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                        null, Modifier.padding(end = 12.dp)
                    )
                    Text(e.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (stack.isNotEmpty()) {
                        IconButton(onClick = { export(e, open = false) }) {
                            Icon(Icons.Default.Download, "Copy to Download/FileLite_export")
                        }
                    }
                }
            }
        }
    }
}
