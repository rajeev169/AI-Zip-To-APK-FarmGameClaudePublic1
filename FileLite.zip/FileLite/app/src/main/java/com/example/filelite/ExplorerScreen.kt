package com.example.filelite

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

enum class Screen(val label: String, val icon: ImageVector) {
    FILES("Files", Icons.Default.Folder),
    SEARCH("Search", Icons.Default.Search),
    CATEGORIES("Categories", Icons.Default.Category),
    STORAGE("Storage", Icons.Default.Storage),
    DATA("App data", Icons.Default.Android)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExplorerApp(
    vm: ExplorerViewModel,
    dark: Boolean,
    lockOn: Boolean,
    onToggleDark: () -> Unit,
    onToggleLock: () -> Unit
) {
    var screen by remember { mutableStateOf(Screen.FILES) }
    var viewing by remember { mutableStateOf<File?>(null) }
    val snack = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { vm.refreshAll() }
    LaunchedEffect(vm.message) {
        vm.message?.let { snack.showSnackbar(it); vm.message = null }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("FileLite") },
                actions = {
                    IconButton(onClick = { vm.showHidden = !vm.showHidden; vm.refreshAll() }) {
                        Icon(
                            if (vm.showHidden) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            "Show hidden files"
                        )
                    }
                    IconButton(onClick = onToggleLock) {
                        Icon(
                            Icons.Default.Fingerprint, "App lock",
                            tint = if (lockOn) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = onToggleDark) {
                        Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Theme")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                Screen.values().forEach { s ->
                    NavigationBarItem(
                        selected = screen == s,
                        onClick = { screen = s },
                        icon = { Icon(s.icon, s.label) },
                        label = { Text(s.label) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (screen) {
                Screen.FILES -> FilesScreen(vm) { viewing = it }
                Screen.SEARCH -> SearchScreen(vm) { viewing = it }
                Screen.CATEGORIES -> CategoriesScreen(vm) { viewing = it }
                Screen.STORAGE -> StorageScreen(vm)
                Screen.DATA -> AndroidDataScreen { viewing = it }
            }
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        }
    }

    viewing?.let { FileViewer(it) { viewing = null } }
}

// ---------------------------------------------------------------- Files (dual pane)

@Composable
fun FilesScreen(vm: ExplorerViewModel, onOpen: (File) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        PaneView(vm, 0, Modifier.weight(1f), onOpen)
        HorizontalDivider(thickness = 2.dp)
        PaneView(vm, 1, Modifier.weight(1f), onOpen)
        HorizontalDivider()
        ActionBar(vm)
    }
}

@Composable
fun PaneView(vm: ExplorerViewModel, index: Int, modifier: Modifier, onOpen: (File) -> Unit) {
    val p = vm.pane(index)
    val isActive = vm.active == index
    Column(
        modifier
            .fillMaxWidth()
            .background(
                if (isActive) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f) else Color.Transparent
            )
            .clickable { vm.active = index }
    ) {
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.active = index; vm.up(p) }, enabled = vm.canGoUp(p)) {
                Icon(Icons.Default.ArrowUpward, "Up")
            }
            Text(
                p.dir.path.removePrefix(vm.root.path).ifEmpty { "/" },
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(p.items, key = { it.path }) { f ->
                FileRow(
                    f = f,
                    selected = f in p.selected,
                    selecting = p.selected.isNotEmpty(),
                    onClick = {
                        vm.active = index
                        when {
                            p.selected.isNotEmpty() -> vm.toggle(p, f)
                            f.isDirectory -> vm.open(p, f)
                            else -> onOpen(f)
                        }
                    },
                    onLong = { vm.active = index; vm.toggle(p, f) }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(f: File, selected: Boolean, selecting: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selecting) Checkbox(checked = selected, onCheckedChange = null, modifier = Modifier.padding(end = 8.dp))
        Icon(iconFor(f), null, Modifier.padding(end = 12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (f.isDirectory) FileOps.date(f) else "${FileOps.human(f.length())}  ·  ${FileOps.date(f)}",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

fun iconFor(f: File): ImageVector = if (f.isDirectory) Icons.Default.Folder else when (FileOps.catOf(f)) {
    Cat.IMAGES -> Icons.Default.Image
    Cat.AUDIO -> Icons.Default.MusicNote
    Cat.VIDEO -> Icons.Default.VideoFile
    Cat.DOCS -> Icons.Default.Description
    Cat.APKS -> Icons.Default.Android
    Cat.ARCHIVES -> Icons.Default.Archive
    Cat.OTHER -> Icons.Default.InsertDriveFile
}

// ---------------------------------------------------------------- Action bar + dialogs

@Composable
fun ActionBar(vm: ExplorerViewModel) {
    val p = vm.pane(vm.active)
    val sel = p.selected.toList()
    val has = sel.isNotEmpty()
    var dlg by remember { mutableStateOf<String?>(null) }

    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.Start
    ) {
        Action(Icons.Default.ContentCopy, "Copy to other pane", has) { vm.copyOrMove(false) }
        Action(Icons.Default.DriveFileMove, "Move to other pane", has) { vm.copyOrMove(true) }
        Action(Icons.Default.Delete, "Delete", has) { dlg = "delete" }
        Action(Icons.Default.Edit, "Rename", sel.size == 1) { dlg = "rename" }
        Action(Icons.Default.CreateNewFolder, "New folder", true) { dlg = "folder" }
        Action(Icons.Default.Archive, "Zip", has) { dlg = "zip" }
        Action(Icons.Default.Unarchive, "Extract zip", sel.size == 1 && sel[0].extension.lowercase() == "zip") {
            vm.unzip(sel[0])
        }
        Action(Icons.Default.Lock, "Encrypt", has) { dlg = "encrypt" }
        Action(Icons.Default.LockOpen, "Decrypt", has) { dlg = "decrypt" }
    }

    val close = { dlg = null }
    when (dlg) {
        "delete" -> AlertDialog(
            onDismissRequest = close,
            title = { Text("Delete ${sel.size} item(s)?") },
            text = { Text("This cannot be undone.") },
            confirmButton = { TextButton(onClick = { vm.delete(); close() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = close) { Text("Cancel") } }
        )
        "rename" -> InputDialog("Rename", "New name", sel.firstOrNull()?.name ?: "", false, close) {
            vm.rename(sel[0], it)
        }
        "folder" -> InputDialog("New folder", "Folder name", "", false, close) { vm.newFolder(it) }
        "zip" -> InputDialog("Create zip", "Archive name", "archive", false, close) { vm.zip(it) }
        "encrypt" -> InputDialog("Encrypt (AES-256)", "Password", "", true, close) { vm.encrypt(it) }
        "decrypt" -> InputDialog("Decrypt", "Password", "", true, close) { vm.decrypt(it) }
    }
}

@Composable
private fun Action(icon: ImageVector, desc: String, enabled: Boolean, onClick: () -> Unit) {
    IconButton(onClick = onClick, enabled = enabled) { Icon(icon, desc) }
}

@Composable
fun InputDialog(
    title: String,
    label: String,
    initial: String,
    password: Boolean,
    onDismiss: () -> Unit,
    onOk: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(label) },
                singleLine = true,
                visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None
            )
        },
        confirmButton = { TextButton(onClick = { onOk(text.trim()); onDismiss() }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ---------------------------------------------------------------- Search

@Composable
fun SearchScreen(vm: ExplorerViewModel, onOpen: (File) -> Unit) {
    var q by remember { mutableStateOf("") }
    val results by produceState(emptyList<File>(), q, vm.showHidden) {
        value = if (q.length < 2) emptyList() else {
            delay(300) // wait until typing pauses
            withContext(Dispatchers.IO) { FileOps.search(vm.root, q, vm.showHidden) }
        }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            label = { Text("Search by file name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        )
        FileList(results, onOpen)
    }
}

@Composable
fun FileList(files: List<File>, onOpen: (File) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(files, key = { it.path }) { f ->
            FileRow(f, false, false, onClick = { if (!f.isDirectory) onOpen(f) }, onLong = {})
        }
    }
}

// ---------------------------------------------------------------- Categories

@Composable
fun CategoriesScreen(vm: ExplorerViewModel, onOpen: (File) -> Unit) {
    var cat by remember { mutableStateOf(Cat.IMAGES) }
    val files by produceState(emptyList<File>(), cat) {
        value = emptyList()
        value = withContext(Dispatchers.IO) { FileOps.byCategory(vm.root, cat) }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Cat.values().filter { it != Cat.OTHER }.forEach { c ->
                FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c.label) })
            }
        }
        FileList(files, onOpen)
    }
}

// ---------------------------------------------------------------- Storage analysis

@Composable
fun StorageScreen(vm: ExplorerViewModel) {
    val usage by produceState<FileOps.Usage?>(null) {
        value = withContext(Dispatchers.IO) { FileOps.usage(vm.root) }
    }
    val u = usage
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (u == null) {
            Text("Analysing storage…")
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 12.dp))
            return@Column
        }
        val used = u.total - u.free
        Text("Used ${FileOps.human(used)} of ${FileOps.human(u.total)}", style = MaterialTheme.typography.titleMedium)
        Text("Free ${FileOps.human(u.free)}", style = MaterialTheme.typography.bodyMedium)
        LinearProgressIndicator(
            progress = { used.toFloat() / u.total.coerceAtLeast(1) },
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp).height(10.dp)
        )
        HorizontalDivider(Modifier.padding(bottom = 12.dp))
        val biggest = u.perCat.values.maxOrNull()?.coerceAtLeast(1) ?: 1
        u.perCat.entries.sortedByDescending { it.value }.forEach { (c, size) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(c.label)
                Text(FileOps.human(size))
            }
            LinearProgressIndicator(
                progress = { size.toFloat() / biggest },
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp)
            )
        }
    }
}
