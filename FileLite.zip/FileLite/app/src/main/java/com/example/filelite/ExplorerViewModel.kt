package com.example.filelite

import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class Pane(start: File) {
    var dir by mutableStateOf(start)
    var items by mutableStateOf(listOf<File>())
    var selected by mutableStateOf(setOf<File>())
}

class ExplorerViewModel : ViewModel() {
    val root: File = Environment.getExternalStorageDirectory()
    val left = Pane(root)
    val right = Pane(root)

    var active by mutableStateOf(0)
    var showHidden by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)

    fun pane(i: Int) = if (i == 0) left else right

    fun refresh(p: Pane) {
        p.items = FileOps.list(p.dir, showHidden)
        p.selected = p.selected.filter { it.exists() }.toSet()
    }

    fun refreshAll() { refresh(left); refresh(right) }

    fun canGoUp(p: Pane) = p.dir.path != root.path && p.dir.parentFile != null

    fun up(p: Pane) {
        if (!canGoUp(p)) return
        p.dir = p.dir.parentFile!!
        p.selected = emptySet()
        refresh(p)
    }

    fun open(p: Pane, f: File) {
        if (!f.isDirectory) return
        p.dir = f
        p.selected = emptySet()
        refresh(p)
    }

    fun toggle(p: Pane, f: File) {
        p.selected = if (f in p.selected) p.selected - f else p.selected + f
    }

    fun clearSelection() { pane(active).selected = emptySet() }

    /** Runs a file task off the main thread and shows the returned text as a message. */
    private fun run(task: () -> String) {
        viewModelScope.launch {
            busy = true
            val msg = withContext(Dispatchers.IO) {
                try { task() } catch (e: Exception) { "Error: ${e.message}" }
            }
            busy = false
            message = msg
            refreshAll()
        }
    }

    fun copyOrMove(move: Boolean) {
        val src = pane(active)
        val dest = pane(1 - active).dir
        val files = src.selected.toList()
        src.selected = emptySet()
        run {
            files.forEach { if (move) FileOps.move(it, dest) else FileOps.copy(it, dest) }
            "${if (move) "Moved" else "Copied"} ${files.size} item(s)"
        }
    }

    fun delete() {
        val p = pane(active)
        val files = p.selected.toList()
        p.selected = emptySet()
        run { files.forEach(FileOps::delete); "Deleted ${files.size} item(s)" }
    }

    fun rename(f: File, name: String) {
        pane(active).selected = emptySet()
        run { FileOps.rename(f, name); "Renamed" }
    }

    fun newFolder(name: String) {
        val dir = pane(active).dir
        run { FileOps.newFolder(dir, name); "Folder created" }
    }

    fun zip(name: String) {
        val p = pane(active)
        val files = p.selected.toList()
        val dir = p.dir
        p.selected = emptySet()
        run { FileOps.zip(files, dir, name); "Archive created" }
    }

    fun unzip(f: File) {
        val dir = pane(active).dir
        pane(active).selected = emptySet()
        run { FileOps.unzip(f, dir); "Extracted" }
    }

    fun encrypt(pw: String) {
        val p = pane(active)
        val files = p.selected.toList()
        p.selected = emptySet()
        run { files.forEach { FileOps.encrypt(it, pw) }; "Encrypted ${files.size} file(s)" }
    }

    fun decrypt(pw: String) {
        val p = pane(active)
        val files = p.selected.toList()
        p.selected = emptySet()
        run { files.forEach { FileOps.decrypt(it, pw) }; "Decrypted ${files.size} file(s)" }
    }
}
