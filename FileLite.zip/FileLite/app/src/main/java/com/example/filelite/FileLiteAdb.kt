package com.example.filelite

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import sun.security.x509.AlgorithmId
import sun.security.x509.CertificateAlgorithmId
import sun.security.x509.CertificateExtensions
import sun.security.x509.CertificateIssuerName
import sun.security.x509.CertificateSerialNumber
import sun.security.x509.CertificateSubjectName
import sun.security.x509.CertificateValidity
import sun.security.x509.CertificateVersion
import sun.security.x509.CertificateX509Key
import sun.security.x509.KeyIdentifier
import sun.security.x509.PrivateKeyUsageExtension
import sun.security.x509.SubjectKeyIdentifierExtension
import sun.security.x509.X500Name
import sun.security.x509.X509CertImpl
import sun.security.x509.X509CertInfo
import java.io.ByteArrayInputStream
import java.io.File
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.Random

/**
 * FileLite's own connection to this phone's "Wireless debugging" (adbd).
 * The RSA key is created once and stored in the app's private folder, so pairing is only needed once.
 */
class FileLiteAdb private constructor(ctx: Context) : AbsAdbConnectionManager() {

    private val key: PrivateKey
    private val cert: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val keyFile = File(ctx.filesDir, "adb_key.pk8")
        val certFile = File(ctx.filesDir, "adb_cert.der")

        var k: PrivateKey? = null
        var c: Certificate? = null
        if (keyFile.exists() && certFile.exists()) {
            try {
                k = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyFile.readBytes()))
                c = CertificateFactory.getInstance("X.509")
                    .generateCertificate(ByteArrayInputStream(certFile.readBytes()))
            } catch (e: Exception) {
                k = null; c = null
            }
        }
        if (k == null || c == null) {
            val gen = KeyPairGenerator.getInstance("RSA")
            gen.initialize(2048, SecureRandom.getInstance("SHA1PRNG"))
            val pair = gen.generateKeyPair()
            val pub = pair.public
            val priv = pair.private

            val algo = "SHA512withRSA"
            val notBefore = Date()
            val notAfter = Date(System.currentTimeMillis() + 10L * 365 * 24 * 3600 * 1000)
            val x500 = X500Name("CN=FileLite")

            val ext = CertificateExtensions()
            ext.set("SubjectKeyIdentifier", SubjectKeyIdentifierExtension(KeyIdentifier(pub).identifier))
            ext.set("PrivateKeyUsage", PrivateKeyUsageExtension(notBefore, notAfter))

            val info = X509CertInfo()
            info.set("version", CertificateVersion(2))
            info.set("serialNumber", CertificateSerialNumber(Random().nextInt() and Int.MAX_VALUE))
            info.set("algorithmID", CertificateAlgorithmId(AlgorithmId.get(algo)))
            info.set("subject", CertificateSubjectName(x500))
            info.set("key", CertificateX509Key(pub))
            info.set("validity", CertificateValidity(notBefore, notAfter))
            info.set("issuer", CertificateIssuerName(x500))
            info.set("extensions", ext)

            val impl = X509CertImpl(info)
            impl.sign(priv, algo)

            keyFile.writeBytes(priv.encoded)
            certFile.writeBytes(impl.encoded)
            k = priv
            c = impl
        }
        key = k
        cert = c
    }

    override fun getPrivateKey(): PrivateKey = key
    override fun getCertificate(): Certificate = cert
    override fun getDeviceName(): String = "FileLite"

    companion object {
        @Volatile private var inst: FileLiteAdb? = null

        fun get(ctx: Context): FileLiteAdb =
            inst ?: synchronized(this) {
                inst ?: FileLiteAdb(ctx.applicationContext).also { inst = it }
            }
    }
}

/** Small helpers around [FileLiteAdb]. Every function blocks, so call them from a background thread. */
object AdbShell {
    private fun mgr(ctx: Context) = FileLiteAdb.get(ctx)

    fun isConnected(ctx: Context): Boolean =
        runCatching { mgr(ctx).isConnected }.getOrDefault(false)

    /** Connects to Wireless debugging if it is on and this app was paired before. */
    fun ensureConnected(ctx: Context): Boolean {
        if (isConnected(ctx)) return true
        return runCatching { mgr(ctx).autoConnect(ctx, 5000L) }.getOrDefault(false)
    }

    /** [port] and [code] come from "Pair device with pairing code" in Developer options. */
    fun pair(ctx: Context, port: Int, code: String): Boolean =
        mgr(ctx).pair("127.0.0.1", port, code)

    /** Runs a shell command as the "shell" user and returns (exit code, output). */
    fun exec(ctx: Context, cmd: String): Pair<Int, String> {
        val stream = mgr(ctx).openStream("shell:($cmd) 2>&1; echo __EXIT_\$?")
        try {
            val text = stream.openInputStream().bufferedReader().use { it.readText() }
            val i = text.lastIndexOf("__EXIT_")
            if (i < 0) return -1 to text
            val code = text.substring(i + 7).trim().toIntOrNull() ?: -1
            return code to text.substring(0, i)
        } finally {
            runCatching { stream.close() }
        }
    }
}
