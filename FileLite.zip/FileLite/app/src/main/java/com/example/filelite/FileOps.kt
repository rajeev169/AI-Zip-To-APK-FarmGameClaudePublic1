package com.example.filelite

import android.os.StatFs
import java.io.File
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

enum class Cat(val label: String, val exts: Set<String>) {
    IMAGES("Images", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")),
    AUDIO("Audio", setOf("mp3", "wav", "m4a", "aac", "ogg", "flac", "opus")),
    VIDEO("Video", setOf("mp4", "mkv", "webm", "3gp", "avi", "mov")),
    DOCS("Documents", setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "csv", "json", "xml")),
    APKS("APKs", setOf("apk")),
    ARCHIVES("Archives", setOf("zip", "rar", "7z", "tar", "gz")),
    OTHER("Other", emptySet())
}

object FileOps {

    // ---------- helpers ----------

    fun catOf(f: File): Cat {
        val e = f.extension.lowercase()
        return Cat.values().firstOrNull { e in it.exts } ?: Cat.OTHER
    }

    fun human(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = bytes.toDouble()
        var i = -1
        while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
        return String.format(Locale.US, "%.1f %s", v, units[i])
    }

    fun date(f: File): String =
        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(f.lastModified()))

    private fun uniqueTarget(dir: File, name: String): File {
        var t = File(dir, name)
        if (!t.exists()) return t
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "").let { if (it.isEmpty()) "" else ".$it" }
        var n = 1
        while (t.exists()) { t = File(dir, "$base ($n)$ext"); n++ }
        return t
    }

    // ---------- browse ----------

    fun list(dir: File, showHidden: Boolean): List<File> =
        (dir.listFiles() ?: emptyArray())
            .filter { showHidden || !it.name.startsWith(".") }
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))

    // ---------- basic operations ----------

    fun copy(src: File, destDir: File) {
        if (src.isDirectory && destDir.canonicalPath.startsWith(src.canonicalPath))
            throw IllegalArgumentException("Cannot copy a folder into itself")
        val t = uniqueTarget(destDir, src.name)
        if (src.isDirectory) src.copyRecursively(t) else src.copyTo(t)
    }

    fun move(src: File, destDir: File) {
        if (src.isDirectory && destDir.canonicalPath.startsWith(src.canonicalPath))
            throw IllegalArgumentException("Cannot move a folder into itself")
        val t = uniqueTarget(destDir, src.name)
        if (!src.renameTo(t)) {
            copy(src, destDir)
            src.deleteRecursively()
        }
    }

    fun delete(f: File) {
        if (!f.deleteRecursively()) throw IllegalStateException("Could not delete ${f.name}")
    }

    fun rename(f: File, newName: String) {
        require(newName.isNotBlank() && !newName.contains('/')) { "Invalid name" }
        val t = File(f.parentFile, newName)
        require(!t.exists()) { "$newName already exists" }
        if (!f.renameTo(t)) throw IllegalStateException("Rename failed")
    }

    fun newFolder(parent: File, name: String) {
        require(name.isNotBlank() && !name.contains('/')) { "Invalid name" }
        val t = File(parent, name)
        require(!t.exists()) { "$name already exists" }
        if (!t.mkdirs()) throw IllegalStateException("Could not create folder")
    }

    // ---------- archives ----------

    fun zip(files: List<File>, dir: File, name: String): File {
        val out = uniqueTarget(dir, if (name.endsWith(".zip")) name else "$name.zip")
        ZipOutputStream(out.outputStream().buffered()).use { zos ->
            files.forEach { root ->
                val base = root.parentFile
                root.walkTopDown().filter { it.isFile }.forEach { f ->
                    zos.putNextEntry(ZipEntry(f.relativeTo(base).path.replace(File.separatorChar, '/')))
                    f.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        }
        return out
    }

    fun unzip(zip: File, destParent: File): File {
        val dest = uniqueTarget(destParent, zip.nameWithoutExtension)
        dest.mkdirs()
        val canonical = dest.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val out = File(dest, e.name)
                // protect against "zip slip" paths such as ../../x
                if (!out.canonicalPath.startsWith(canonical + File.separator))
                    throw SecurityException("Unsafe path in zip: ${e.name}")
                if (e.isDirectory) out.mkdirs()
                else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zis.copyTo(it) }
                }
                e = zis.nextEntry
            }
        }
        return dest
    }

    // ---------- search / categories / storage ----------

    fun search(root: File, query: String, showHidden: Boolean, limit: Int = 300): List<File> =
        root.walkTopDown()
            .onEnter { showHidden || !it.name.startsWith(".") || it == root }
            .filter { it != root && it.name.contains(query, ignoreCase = true) }
            .take(limit)
            .toList()

    fun byCategory(root: File, cat: Cat, limit: Int = 500): List<File> =
        root.walkTopDown()
            .onEnter { !it.name.startsWith(".") || it == root }
            .filter { it.isFile && catOf(it) == cat }
            .take(limit)
            .toList()

    data class Usage(val perCat: Map<Cat, Long>, val total: Long, val free: Long)

    fun usage(root: File): Usage {
        val sums = Cat.values().associateWith { 0L }.toMutableMap()
        root.walkTopDown().filter { it.isFile }.forEach {
            val c = catOf(it)
            sums[c] = sums.getValue(c) + it.length()
        }
        val st = StatFs(root.path)
        return Usage(sums, st.totalBytes, st.availableBytes)
    }

    // ---------- encryption (AES-256-GCM, key from password via PBKDF2) ----------

    private fun key(pw: String, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val bytes = f.generateSecret(PBEKeySpec(pw.toCharArray(), salt, 120_000, 256)).encoded
        return SecretKeySpec(bytes, "AES")
    }

    fun encrypt(src: File, pw: String): File {
        require(src.isFile) { "Only files can be encrypted" }
        require(pw.length >= 4) { "Password too short" }
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(pw, salt), GCMParameterSpec(128, iv))
        val out = uniqueTarget(src.parentFile!!, src.name + ".enc")
        out.outputStream().use { o ->
            o.write(salt); o.write(iv)
            CipherOutputStream(o, c).use { co -> src.inputStream().use { it.copyTo(co) } }
        }
        return out
    }

    fun decrypt(src: File, pw: String): File {
        require(src.isFile) { "Only files can be decrypted" }
        val outName = if (src.name.endsWith(".enc")) src.name.removeSuffix(".enc") else src.name + ".dec"
        val out = uniqueTarget(src.parentFile!!, outName)
        try {
            src.inputStream().use { i ->
                val salt = ByteArray(16); val iv = ByteArray(12)
                require(i.read(salt) == 16 && i.read(iv) == 12) { "Not an encrypted file" }
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, key(pw, salt), GCMParameterSpec(128, iv))
                out.outputStream().use { o -> CipherInputStream(i, c).use { it.copyTo(o) } }
            }
        } catch (e: Exception) {
            out.delete()
            throw IllegalArgumentException("Wrong password or damaged file")
        }
        return out
    }
}
