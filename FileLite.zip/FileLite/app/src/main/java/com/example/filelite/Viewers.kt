package com.example.filelite

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

private val TEXT_EXTS = setOf(
    "txt", "md", "csv", "json", "xml", "log", "kt", "java", "html", "js", "css", "yml", "yaml", "ini", "properties"
)

/** Built-in viewer for images, audio and text. Everything else is handed to another app. */
@Composable
fun FileViewer(file: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cat = FileOps.catOf(file)
    val isText = file.extension.lowercase() in TEXT_EXTS

    if (cat != Cat.IMAGES && cat != Cat.AUDIO && !isText) {
        LaunchedEffect(file) { openExternally(ctx, file); onClose() }
        return
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close") }
                    Text(file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                }
                when {
                    cat == Cat.IMAGES -> AsyncImage(
                        model = file,
                        contentDescription = file.name,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                    cat == Cat.AUDIO -> AudioPlayer(file)
                    else -> TextViewer(file)
                }
            }
        }
    }
}

@Composable
private fun TextViewer(file: File) {
    val text by produceState("Loading…", file) {
        value = withContext(Dispatchers.IO) {
            try {
                file.inputStream().use {
                    val buf = ByteArray(200_000) // only the first ~200 KB
                    val n = it.read(buf)
                    String(buf, 0, maxOf(n, 0))
                }
            } catch (e: Exception) {
                "Cannot read file: ${e.message}"
            }
        }
    }
    Text(
        text,
        fontFamily = FontFamily.Monospace,
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)
    )
}

@Composable
private fun AudioPlayer(file: File) {
    val mp = remember(file) {
        runCatching { MediaPlayer().apply { setDataSource(file.path); prepare() } }.getOrNull()
    }
    if (mp == null) {
        Text("Cannot play this file", modifier = Modifier.padding(24.dp))
        return
    }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0f) }

    DisposableEffect(mp) {
        mp.setOnCompletionListener { playing = false }
        onDispose { mp.release() }
    }
    LaunchedEffect(playing) {
        while (playing) {
            pos = mp.currentPosition.toFloat() / mp.duration.coerceAtLeast(1)
            delay(300)
        }
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.MusicNote, null, Modifier.size(96.dp))
        Slider(
            value = pos,
            onValueChange = { pos = it; mp.seekTo((it * mp.duration).toInt()) },
            modifier = Modifier.padding(vertical = 16.dp)
        )
        IconButton(onClick = {
            if (mp.isPlaying) { mp.pause(); playing = false } else { mp.start(); playing = true }
        }) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play / pause", Modifier.size(48.dp))
        }
    }
}

fun openExternally(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Open with"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    }
}
