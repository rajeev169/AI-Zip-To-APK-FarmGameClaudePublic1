# Guitar Studio (v1.0.0)

Kotlin + Jetpack Compose, Material 3 (Expressive styling on stable Material 3 1.3), minSdk 26, targetSdk 35.
Package: com.appforge.guitarstudio

Build: `./gradlew assembleDebug` (or push the zip to your Universal ZIP to APK workflow).
Release signing is not configured here, your pipeline signs the APK/AAB.

## What is inside
- Tune: chromatic tuner for 6 tunings (YIN pitch detection), metronome (tap tempo, 2-6 beats per bar)
- Chords: 38 chord shapes, diagrams (left-handed option), strum playback, "Check my chord" (names a string that is not ringing), 7 scales on a fretboard
- Learn: daily plan + streak, 7 lessons (2 with tabs and playback), original songs with lyrics and chords, capo and key change, chord-change trainer, fretboard quiz, ear training
- Studio: amp and effects (distortion, delay, reverb) on a demo riff or your recorded take, backing tracks (rock, pop, blues, folk), recorder with share, play-along game (mic), song-to-chords
- More: progress, help, privacy, settings (theme, left-handed, reference pitch, default tuning)

## Tested
core/ (music theory, pitch detection, chord detection, synth, metronome) is compiled and tested on a PC: `core-tests/run-tests.sh`.
The Android screens could not be compiled in the authoring environment (no access to Google's Maven), so the first Gradle build is the first compile of the UI layer.

## Not in v1
Video recording with tab overlay, home-screen widget, daily reminder notification, community feed, in-app language switch.
