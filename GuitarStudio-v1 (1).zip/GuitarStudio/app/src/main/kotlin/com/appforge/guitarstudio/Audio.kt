package com.appforge.guitarstudio

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import com.appforge.guitarstudio.core.MetronomeGenerator
import com.appforge.guitarstudio.core.Wav
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

const val SR = 44100

/** Microphone stream that keeps the last two seconds of audio in a ring buffer. */
class Mic {
    private val lock = Any()
    private val ring = FloatArray(SR * 2)
    private var writePos = 0
    private var filled = 0
    @Volatile private var running = false
    private var thread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (running) return true
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return false
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 16384))
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        rec.startRecording()
        running = true
        val t = Thread {
            val buf = ShortArray(2048)
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) push(buf, n) else if (n < 0) break
            }
            try { rec.stop() } catch (e: Exception) { }
            rec.release()
        }
        t.isDaemon = true
        t.start()
        thread = t
        return true
    }

    fun stop() {
        running = false
        thread = null
    }

    private fun push(b: ShortArray, n: Int) {
        synchronized(lock) {
            for (i in 0 until n) {
                ring[writePos] = b[i] / 32768f
                writePos = (writePos + 1) % ring.size
            }
            filled = minOf(ring.size, filled + n)
        }
    }

    /** The most recent [count] samples, or null if not enough audio has arrived yet. */
    fun snapshot(count: Int): FloatArray? {
        synchronized(lock) {
            if (filled < count) return null
            val out = FloatArray(count)
            var p = (writePos - count + ring.size) % ring.size
            for (i in 0 until count) {
                out[i] = ring[p]
                p = (p + 1) % ring.size
            }
            return out
        }
    }
}

/** Plays a finished buffer (optionally looping). Only one sound at a time. */
object Player {
    private var track: AudioTrack? = null

    @Synchronized
    fun play(x: FloatArray, loop: Boolean = false) {
        stop()
        if (x.isEmpty()) return
        val pcm = Wav.toShort(x)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        if (loop) t.setLoopPoints(0, pcm.size, -1)
        t.play()
        track = t
    }

    @Synchronized
    fun stop() {
        val t = track
        if (t != null) {
            try { t.stop() } catch (e: Exception) { }
            t.release()
        }
        track = null
    }
}

/** Streams metronome clicks on a background thread. */
class ClickPlayer {
    @Volatile private var running = false

    fun start(gen: MetronomeGenerator, onBeat: (Int) -> Unit) {
        if (running) return
        running = true
        gen.reset()
        val t = Thread {
            val min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SR)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(min, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            val f = FloatArray(1024)
            while (running) {
                gen.fill(f, onBeat)
                val pcm = Wav.toShort(f)
                track.write(pcm, 0, pcm.size)
            }
            try { track.stop() } catch (e: Exception) { }
            track.release()
        }
        t.isDaemon = true
        t.start()
    }

    fun stop() {
        running = false
    }
}

/** Records the microphone to a 16-bit mono WAV file. */
class WavRecorder(private val file: File) {
    @Volatile private var running = false
    private var thread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return false
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 16384))
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        file.parentFile?.mkdirs()
        val raf = RandomAccessFile(file, "rw")
        raf.setLength(0)
        raf.write(ByteArray(44))
        rec.startRecording()
        running = true
        val t = Thread {
            val buf = ShortArray(4096)
            val bytes = ByteArray(buf.size * 2)
            var total = 0L
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until n) bb.putShort(buf[i])
                raf.write(bytes, 0, n * 2)
                total += n * 2L
            }
            try { rec.stop() } catch (e: Exception) { }
            rec.release()
            raf.seek(0)
            raf.write(wavHeader(total))
            raf.close()
        }
        t.start()
        thread = t
        return true
    }

    /** Stops recording and waits until the file has been finished. */
    fun stop() {
        running = false
        thread?.join(2000)
        thread = null
    }

    private fun wavHeader(dataLen: Long): ByteArray {
        val bb = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt((36 + dataLen).toInt()); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(SR); bb.putInt(SR * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(dataLen.toInt())
        return bb.array()
    }
}

fun readWav(file: File): FloatArray {
    val raw = file.readBytes()
    if (raw.size <= 44) return FloatArray(0)
    val n = (raw.size - 44) / 2
    val bb = ByteBuffer.wrap(raw, 44, n * 2).order(ByteOrder.LITTLE_ENDIAN)
    return FloatArray(n) { bb.short / 32768f }
}
