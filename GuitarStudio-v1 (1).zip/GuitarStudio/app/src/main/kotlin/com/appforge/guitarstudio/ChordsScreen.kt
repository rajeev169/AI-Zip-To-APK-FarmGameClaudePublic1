@file:OptIn(ExperimentalMaterial3Api::class)

package com.appforge.guitarstudio

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.guitarstudio.core.Chord
import com.appforge.guitarstudio.core.ChordDetector
import com.appforge.guitarstudio.core.ChordLibrary
import com.appforge.guitarstudio.core.Notes
import com.appforge.guitarstudio.core.Quality
import com.appforge.guitarstudio.core.Scales
import com.appforge.guitarstudio.core.Synth
import com.appforge.guitarstudio.core.Tunings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private val QUALITY_NAMES = listOf("Major", "Minor", "7th", "Maj7", "Min7", "Sus2", "Sus4")
private val QUALITIES = listOf(Quality.MAJ, Quality.MIN, Quality.DOM7, Quality.MAJ7, Quality.MIN7, Quality.SUS2, Quality.SUS4)

@Composable
fun ChordsScreen(s: Settings) {
    var q by rememberSaveable { mutableIntStateOf(0) }
    var pick by rememberSaveable { mutableIntStateOf(0) }
    val list = ChordLibrary.ALL.filter { it.quality == QUALITIES[q] }
    val chord = list[pick.coerceIn(0, list.size - 1)]
    var scaleIdx by rememberSaveable { mutableIntStateOf(3) }
    var rootPc by rememberSaveable { mutableIntStateOf(9) }
    val scaleNames = Scales.ALL.keys.toList()
    val tuning = Tunings.ALL[s.tuningIdx.coerceIn(0, Tunings.ALL.size - 1)]

    ScreenColumn("Chords & Scales") {
        ChipRow(QUALITY_NAMES, q) { q = it; pick = 0 }
        ChipRow(list.map { it.name }, pick.coerceIn(0, list.size - 1)) {
            pick = it
            Player.play(Synth.chordAudio(list[it], Tunings.STANDARD, s.refHz.toDouble()))
        }
        SectionCard(hero = true) {
            Text(chord.name, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 48.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                ChordDiagram(chord, s.leftHanded)
            }
            val base = chord.baseFret()
            Text(
                (if (base > 1) "Starts at fret $base. " else "") + "Fingering low to high: " + chord.frets.joinToString(" ") { if (it < 0) "x" else it.toString() },
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Button(onClick = { Player.play(Synth.chordAudio(chord, Tunings.STANDARD, s.refHz.toDouble())) }) { Text("Strum") }
            }
        }
        MicGate { CheckChord(chord, s) }
        SectionCard {
            Text("Scales on the fretboard", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            ChipRow(scaleNames, scaleIdx) { scaleIdx = it }
            ChipRow(Notes.NAMES.toList(), rootPc) { rootPc = it }
            val notes = Scales.ALL[scaleNames[scaleIdx]]!!.joinToString(" ") { Notes.NAMES[(rootPc + it) % 12] }
            Text("${Notes.NAMES[rootPc]} ${scaleNames[scaleIdx]}: $notes", style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                Fretboard(tuning, Scales.ALL[scaleNames[scaleIdx]]!!, rootPc)
            }
            Text("Gold dots are the root note. Top line is the high e string.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun CheckChord(chord: Chord, s: Settings) {
    val mic = remember { Mic() }
    val det = remember { ChordDetector(SR) }
    var listening by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Press Check my chord, hold the chord and strum.") }
    var heard by remember { mutableStateOf("") }
    val tuning = Tunings.ALL[s.tuningIdx.coerceIn(0, Tunings.ALL.size - 1)]

    DisposableEffect(Unit) { onDispose { mic.stop() } }

    LaunchedEffect(listening, chord) {
        if (!listening) return@LaunchedEffect
        if (!mic.start()) { message = "Could not open the microphone"; listening = false; return@LaunchedEffect }
        message = "Listening... strum ${chord.name}"
        while (true) {
            delay(450)
            val buf = mic.snapshot(det.minSamples) ?: continue
            val result = withContext(Dispatchers.Default) {
                val r = det.analyze(buf, chord, Tunings.STANDARD, s.refHz.toDouble())
                val c = det.chroma(buf)
                Pair(r, if (c == null) null else det.detect(c))
            }
            val r = result.first
            val d = result.second
            if (r == null) { message = "Too quiet. Strum the chord clearly."; heard = ""; continue }
            heard = if (d != null && d.score > 0.8) "Heard: ${d.name}" else ""
            message = when {
                r.ok -> "Sounds right: ${chord.name}"
                r.missingStrings.isNotEmpty() -> "Check string " + r.missingStrings.joinToString(", ") { "${6 - it}" } +
                    ": the note is not ringing (press closer to the fret or lift the finger that touches it)"
                r.extra.isNotEmpty() -> "Unexpected notes: " + r.extra.joinToString(", ") { Notes.NAMES[it] }
                else -> "Not quite ${chord.name}. Check your finger positions."
            }
        }
    }

    SectionCard {
        Text("Check my chord", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(message, modifier = Modifier.fillMaxWidth())
        if (heard.isNotEmpty()) Text(heard, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        if (listening) {
            OutlinedButton(onClick = { listening = false; mic.stop(); message = "Stopped." }) { Text("Stop") }
        } else {
            FilledTonalButton(onClick = { listening = true }) { Text("Check my chord") }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Works best in a quiet room with a tuned guitar. It may miss a muted top string when a lower string covers the same note.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
