@file:OptIn(ExperimentalMaterial3Api::class)

package com.appforge.guitarstudio

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.guitarstudio.core.Chord
import com.appforge.guitarstudio.core.ChordLibrary
import com.appforge.guitarstudio.core.Lesson
import com.appforge.guitarstudio.core.Lessons
import com.appforge.guitarstudio.core.Notes
import com.appforge.guitarstudio.core.Practice
import com.appforge.guitarstudio.core.Song
import com.appforge.guitarstudio.core.Songs
import com.appforge.guitarstudio.core.Synth
import com.appforge.guitarstudio.core.Tunings
import kotlin.random.Random
import kotlinx.coroutines.delay

@Composable
fun LearnScreen(s: Settings) {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    var lessonId by rememberSaveable { mutableIntStateOf(-1) }
    var songIdx by rememberSaveable { mutableIntStateOf(-1) }
    ScreenColumn("Learn") {
        ChipRow(listOf("Path", "Songs", "Train"), sub) { sub = it; lessonId = -1; songIdx = -1; Player.stop() }
        when (sub) {
            0 -> if (lessonId >= 0) LessonDetail(Lessons.ALL.first { it.id == lessonId }, s) { lessonId = -1; Player.stop() }
                 else PathView(s) { lessonId = it }
            1 -> if (songIdx >= 0) SongDetail(Songs.ALL[songIdx], s) { songIdx = -1 }
                 else SongList { songIdx = it }
            else -> TrainView(s)
        }
    }
}

@Composable
fun PathView(s: Settings, openLesson: (Int) -> Unit) {
    SectionCard(hero = true) {
        Text("🔥 ${s.currentStreak()}-day streak", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Finish one task a day to keep it going.")
    }
    SectionCard {
        Text("Today's plan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Based on your best chord-change score.", style = MaterialTheme.typography.bodySmall)
        for (t in Practice.plan(s.bestChanges)) {
            Row(Modifier.fillMaxWidth().clickable { s.toggleTask(t.id) }, verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = t.id in s.doneToday, onCheckedChange = { s.toggleTask(t.id) })
                Text("${t.title} (${t.minutes} min)")
            }
        }
    }
    Text("Lessons", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
    for (l in Lessons.ALL) {
        SectionCard(Modifier.clickable { openLesson(l.id) }) {
            Text("${l.id}. ${l.title}${if (l.id.toString() in s.lessonsDone) "  ✓" else ""}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(l.summary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun LessonDetail(l: Lesson, s: Settings, back: () -> Unit) {
    var speedIdx by rememberSaveable { mutableIntStateOf(2) }
    var playing by remember { mutableStateOf(false) }
    var active by remember { mutableIntStateOf(-1) }
    val speeds = listOf(0.5, 0.75, 1.0)
    OutlinedButton(onClick = back) { Text("← Lessons") }
    SectionCard(hero = true) {
        Text(l.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(l.summary)
    }
    SectionCard {
        l.steps.forEachIndexed { i, step -> Text("${i + 1}. $step", modifier = Modifier.padding(vertical = 4.dp)) }
    }
    if (l.tab.isNotEmpty()) {
        val stepMs = (500 / speeds[speedIdx]).toLong()
        LaunchedEffect(playing, speedIdx) {
            if (!playing) { active = -1; return@LaunchedEffect }
            val total = l.tab.size
            val out = FloatArray((total * stepMs * SR / 1000).toInt() + SR)
            for ((i, n) in l.tab.withIndex()) {
                val midi = Tunings.noteAt(Tunings.STANDARD, n.string, n.fret)
                Synth.mixInto(out, Synth.pluck(Notes.freq(midi.toDouble(), s.refHz.toDouble()), 1.2, SR, 0.3, 5L + i), (i * stepMs * SR / 1000).toInt())
            }
            Player.play(out)
            for (i in 0 until total) { active = i; delay(stepMs) }
            delay(600)
            active = -1
            playing = false
        }
        SectionCard {
            Text("Tab (numbers are frets, bottom line is the low E string)", style = MaterialTheme.typography.bodySmall)
            Row(Modifier.horizontalScroll(rememberScrollState())) { TabView(l.tab, active) }
            ChipRow(listOf("0.5×", "0.75×", "1×"), speedIdx) { speedIdx = it; playing = false; Player.stop() }
            Button(onClick = { if (playing) { playing = false; Player.stop() } else playing = true }) { Text(if (playing) "Stop" else "Play") }
        }
    }
    val done = l.id.toString() in s.lessonsDone
    if (done) OutlinedButton(onClick = { s.toggleLesson(l.id) }) { Text("Completed ✓ (tap to undo)") }
    else Button(onClick = { s.toggleLesson(l.id) }) { Text("Mark as completed") }
}

@Composable
fun SongList(open: (Int) -> Unit) {
    for ((i, song) in Songs.ALL.withIndex()) {
        SectionCard(Modifier.clickable { open(i) }) {
            Text(song.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("${song.difficulty} · Key of ${song.key} · ${song.bpm} BPM", style = MaterialTheme.typography.bodySmall)
            Text(song.chords().joinToString("  "), style = MaterialTheme.typography.bodyMedium)
        }
    }
    Text("All songs are original and written for this app.", style = MaterialTheme.typography.bodySmall)
}

@Composable
fun SongDetail(song: Song, s: Settings, back: () -> Unit) {
    var capo by rememberSaveable { mutableIntStateOf(0) }
    var shift by rememberSaveable { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf<String?>(null) }
    OutlinedButton(onClick = back) { Text("← Songs") }
    SectionCard(hero = true) {
        Text(song.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("${song.difficulty} · Key of ${song.key} · ${song.bpm} BPM")
        Text("Strumming: ${song.strumming}")
    }
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Capo: $capo")
            FilledTonalButton(onClick = { capo = (capo - 1).coerceAtLeast(0) }) { Text("−") }
            FilledTonalButton(onClick = { capo = (capo + 1).coerceAtMost(7) }) { Text("+") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Key change: ${if (shift > 0) "+" else ""}$shift")
            FilledTonalButton(onClick = { shift = (shift - 1).coerceAtLeast(-6) }) { Text("−") }
            FilledTonalButton(onClick = { shift = (shift + 1).coerceAtMost(6) }) { Text("+") }
        }
        val shifted = song.chords().map { ChordLibrary.transpose(it, shift) }
        TextButton(onClick = { capo = ChordLibrary.bestCapo(shifted) }) { Text("Suggest easiest capo") }
        Text(
            if (capo == 0) "Chord shapes are shown as written." else "With capo $capo, play these shapes. The sound stays in the same key.",
            style = MaterialTheme.typography.bodySmall
        )
        Text("Chords to play: " + shifted.map { ChordLibrary.transpose(it, -capo) }.joinToString("  "), fontWeight = FontWeight.Bold)
    }
    SectionCard {
        for (line in song.lines) {
            val parts = Regex("\\[([^\\]]+)]([^\\[]*)").findAll(line).toList()
            val lead = line.substringBefore("[")
            if (lead.isNotEmpty()) Text(lead)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                for (m in parts) {
                    val shape = ChordLibrary.transpose(m.groupValues[1], shift - capo)
                    Column(Modifier.padding(end = 4.dp)) {
                        Text(shape, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { dialog = shape })
                        Text(m.groupValues[2], fontSize = 18.sp)
                    }
                }
            }
        }
        Text("Tap a chord to see its shape.", style = MaterialTheme.typography.bodySmall)
    }
    val d = dialog
    if (d != null) {
        val chord: Chord? = ChordLibrary.byName(d)
        AlertDialog(
            onDismissRequest = { dialog = null },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Close") } },
            title = { Text(d) },
            text = {
                if (chord != null) {
                    Column {
                        ChordDiagram(chord, s.leftHanded)
                        Button(onClick = { Player.play(Synth.chordAudio(chord, Tunings.STANDARD, s.refHz.toDouble())) }) { Text("Strum") }
                    }
                } else Text("This shape is not in the chord library yet.")
            }
        )
    }
}

@Composable
fun TrainView(s: Settings) {
    ChangeTrainer(s)
    FretboardQuiz(s)
    EarTraining(s)
}

private val PAIRS = listOf("G" to "C", "C" to "Am", "D" to "A", "Em" to "G", "A" to "E", "Am" to "F")

@Composable
fun ChangeTrainer(s: Settings) {
    var pair by rememberSaveable { mutableIntStateOf(0) }
    var showSecond by remember { mutableStateOf(false) }
    var last by remember { mutableStateOf(0L) }
    var result by remember { mutableStateOf("Switch chords and tap the button each time you change.") }
    val a = ChordLibrary.byName(PAIRS[pair].first)!!
    val b = ChordLibrary.byName(PAIRS[pair].second)!!
    val cur = if (showSecond) b else a
    SectionCard(hero = true) {
        Text("Chord-change trainer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        ChipRow(PAIRS.map { "${it.first} → ${it.second}" }, pair) { pair = it; showSecond = false; last = 0L; result = "Switch chords and tap the button each time you change." }
        Text(cur.name, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 48.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { ChordDiagram(cur, s.leftHanded) }
        Text(result, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Text("Best: ${if (s.bestChanges == 0) "-" else s.bestChanges.toString()} changes per minute", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Button(onClick = {
                val now = System.currentTimeMillis()
                if (last != 0L && now - last < 15000) {
                    val cpm = (60000.0 / (now - last)).toInt()
                    result = "$cpm changes per minute"
                    if (cpm > s.bestChanges) { s.bestChanges = cpm; result += " · new best!" }
                    s.markPracticed()
                }
                last = now
                showSecond = !showSecond
            }) { Text("I changed!") }
        }
    }
}

@Composable
fun FretboardQuiz(s: Settings) {
    val names = listOf("low E", "A", "D", "G", "B", "high e")
    var note by rememberSaveable { mutableIntStateOf(Random.nextInt(12)) }
    var str by rememberSaveable { mutableIntStateOf(Random.nextInt(6)) }
    var streak by rememberSaveable { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    SectionCard {
        Text("Fretboard quiz", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Find ${Notes.NAMES[note]} on the ${names[str]} string. Tap the fret.")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (f in 0..12) {
                FilledTonalButton(onClick = {
                    val midi = Tunings.STANDARD.strings[str] + f
                    Player.play(Synth.pluck(Notes.freq(midi.toDouble(), s.refHz.toDouble()), 1.2))
                    if (Notes.pc(midi) == note) {
                        streak++
                        msg = "Correct!"
                        note = Random.nextInt(12)
                        str = Random.nextInt(6)
                    } else {
                        streak = 0
                        msg = "Fret $f is ${Notes.name(midi)}. Try again."
                    }
                }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp)) { Text("$f") }
            }
        }
        Text("$msg  Streak: $streak")
    }
}

private val INTERVALS = listOf(3 to "Minor 3rd", 4 to "Major 3rd", 5 to "Perfect 4th", 7 to "Perfect 5th", 12 to "Octave")

@Composable
fun EarTraining(s: Settings) {
    var current by remember { mutableIntStateOf(-1) }
    var score by rememberSaveable { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("Press Play, then name the interval (low note first).") }
    fun play() {
        current = Random.nextInt(INTERVALS.size)
        val low = 55 + Random.nextInt(8)
        val iv = INTERVALS[current].first
        val out = FloatArray(SR * 2)
        Synth.mixInto(out, Synth.pluck(Notes.freq(low.toDouble(), s.refHz.toDouble()), 1.0), 0)
        Synth.mixInto(out, Synth.pluck(Notes.freq((low + iv).toDouble(), s.refHz.toDouble()), 1.0), SR * 6 / 10)
        Player.play(out)
        msg = "Which interval did you hear?"
    }
    SectionCard {
        Text("Ear training", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(msg)
        Button(onClick = { play() }) { Text(if (current < 0) "Play" else "Play next / repeat new") }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            INTERVALS.forEachIndexed { i, (_, name) ->
                FilledTonalButton(onClick = {
                    if (current < 0) { msg = "Press Play first." }
                    else if (i == current) { score++; msg = "Correct! It was a ${name.lowercase()}."; current = -1 }
                    else { msg = "Not quite. It was a ${INTERVALS[current].second.lowercase()}."; current = -1 }
                }) { Text(name) }
            }
        }
        Text("Score: $score")
    }
}
