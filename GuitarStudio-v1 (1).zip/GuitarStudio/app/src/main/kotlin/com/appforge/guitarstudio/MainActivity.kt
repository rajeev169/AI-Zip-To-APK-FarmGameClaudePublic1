package com.appforge.guitarstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settings = Settings(applicationContext)
        setContent {
            val dark = when (settings.themeMode) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            GuitarTheme(dark) { AppRoot(settings) }
        }
    }

    override fun onStop() {
        Player.stop()
        super.onStop()
    }
}

@Composable
fun AppRoot(settings: Settings) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val items = listOf("Tune" to "🎚", "Chords" to "🎸", "Learn" to "🎓", "Studio" to "🎛", "More" to "☰")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { i, item ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { Player.stop(); tab = i },
                        icon = { Text(item.second, fontSize = 22.sp) },
                        label = { Text(item.first) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> TuneScreen(settings)
                1 -> ChordsScreen(settings)
                2 -> LearnScreen(settings)
                3 -> StudioScreen(settings)
                else -> MoreScreen(settings)
            }
        }
    }
}
