@file:OptIn(ExperimentalMaterial3Api::class)

package com.appforge.guitarstudio

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.appforge.guitarstudio.core.Lessons
import com.appforge.guitarstudio.core.Tunings

@Composable
fun MoreScreen(s: Settings) {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    ScreenColumn("Menu") {
        ChipRow(listOf("Menu", "Settings"), sub) { sub = it }
        if (sub == 0) MenuView(s) else SettingsView(s)
    }
}

@Composable
fun MenuView(s: Settings) {
    val ctx = LocalContext.current
    val version = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    SectionCard(hero = true) {
        Text("Your progress", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Streak: ${s.currentStreak()} days")
        Text("Lessons completed: ${s.lessonsDone.size} of ${Lessons.ALL.size}")
        Text("Best chord changes: ${if (s.bestChanges == 0) "-" else "${s.bestChanges} per minute"}")
    }
    SectionCard {
        Text("How it works", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Tuner: finds the pitch of the string you play and shows how many cents sharp or flat it is. Within 5 cents is shown as in tune.")
        Spacer(Modifier.height(6.dp))
        Text("Check my chord: listens to your strum and compares it with the chord you chose. It can name a string that is not ringing.")
        Spacer(Modifier.height(6.dp))
        Text("Song to chords: finds the main chord in the sound once per half second. It knows major, minor and 7th chords.")
        Spacer(Modifier.height(6.dp))
        Text("For best results use a quiet room and a tuned guitar. Chord feedback is a guide, so trust your ears too.", style = MaterialTheme.typography.bodySmall)
    }
    SectionCard {
        Text("Privacy", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("The microphone is used only while a listening feature is open. Audio is analysed on your phone and is not uploaded. Recorded takes stay in the app until you share or delete them.")
    }
    SectionCard {
        Text("About", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Guitar Studio $version by AppForge")
        Spacer(Modifier.height(8.dp))
        FilledTonalButton(onClick = {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + ctx.packageName))
            try { ctx.startActivity(intent) } catch (e: Exception) { }
        }) { Text("Rate on Google Play") }
    }
}

@Composable
fun SettingsView(s: Settings) {
    SectionCard {
        Text("Theme", fontWeight = FontWeight.Bold)
        ChipRow(listOf("System", "Light", "Dark"), s.themeMode) { s.themeMode = it }
    }
    SectionCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Left-handed chord diagrams")
            Switch(checked = s.leftHanded, onCheckedChange = { s.leftHanded = it })
        }
    }
    SectionCard {
        Text("Reference pitch (A4)", fontWeight = FontWeight.Bold)
        Text("Standard is 440 Hz. Change it only if your group tunes differently.", style = MaterialTheme.typography.bodySmall)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { s.refHz = s.refHz - 1 }) { Text("−") }
            Text("${s.refHz} Hz", style = MaterialTheme.typography.titleMedium)
            OutlinedButton(onClick = { s.refHz = s.refHz + 1 }) { Text("+") }
            OutlinedButton(onClick = { s.refHz = 440 }) { Text("Reset") }
        }
    }
    SectionCard {
        Text("Default tuning", fontWeight = FontWeight.Bold)
        ChipRow(Tunings.ALL.map { it.name }, s.tuningIdx) { s.tuningIdx = it }
        Text(Tunings.ALL[s.tuningIdx.coerceIn(0, Tunings.ALL.size - 1)].label(), style = MaterialTheme.typography.bodySmall)
    }
}
