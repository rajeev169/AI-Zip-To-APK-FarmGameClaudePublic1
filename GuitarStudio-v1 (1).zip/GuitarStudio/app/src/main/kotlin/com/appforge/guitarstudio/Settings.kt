package com.appforge.guitarstudio

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.time.LocalDate

/** App settings and practice progress, saved on the phone. */
class Settings(context: Context) {
    private val sp = context.getSharedPreferences("guitar_studio", Context.MODE_PRIVATE)

    private val refState = mutableIntStateOf(sp.getInt("ref", 440))
    var refHz: Int
        get() = refState.intValue
        set(v) { refState.intValue = v.coerceIn(430, 450); sp.edit().putInt("ref", refState.intValue).apply() }

    private val tuningState = mutableIntStateOf(sp.getInt("tuning", 0))
    var tuningIdx: Int
        get() = tuningState.intValue
        set(v) { tuningState.intValue = v; sp.edit().putInt("tuning", v).apply() }

    private val leftState = mutableStateOf(sp.getBoolean("left", false))
    var leftHanded: Boolean
        get() = leftState.value
        set(v) { leftState.value = v; sp.edit().putBoolean("left", v).apply() }

    /** 0 = follow system, 1 = light, 2 = dark */
    private val themeState = mutableIntStateOf(sp.getInt("theme", 0))
    var themeMode: Int
        get() = themeState.intValue
        set(v) { themeState.intValue = v; sp.edit().putInt("theme", v).apply() }

    private val bestState = mutableIntStateOf(sp.getInt("bestCpm", 0))
    var bestChanges: Int
        get() = bestState.intValue
        set(v) { bestState.intValue = v; sp.edit().putInt("bestCpm", v).apply() }

    private val streakState = mutableIntStateOf(sp.getInt("streak", 0))
    var streak: Int
        get() = streakState.intValue
        private set(v) { streakState.intValue = v; sp.edit().putInt("streak", v).apply() }

    private val doneState = mutableStateOf(loadDone())
    val doneToday: Set<String> get() = doneState.value

    private val lessonsState = mutableStateOf(sp.getStringSet("lessons", emptySet())!!.toSet())
    val lessonsDone: Set<String> get() = lessonsState.value

    private fun today(): Long = LocalDate.now().toEpochDay()

    private fun loadDone(): Set<String> =
        if (sp.getLong("doneDay", -1L) == LocalDate.now().toEpochDay()) sp.getStringSet("done", emptySet())!!.toSet() else emptySet()

    fun toggleTask(id: String) {
        val cur = if (sp.getLong("doneDay", -1L) == today()) doneState.value else emptySet()
        val next = if (id in cur) cur - id else cur + id
        doneState.value = next
        sp.edit().putLong("doneDay", today()).putStringSet("done", next).apply()
        if (next.isNotEmpty()) markPracticed()
    }

    /** Keeps the daily streak: consecutive days with at least one finished task. */
    fun markPracticed() {
        val last = sp.getLong("lastDay", -1L)
        val t = today()
        if (last == t) return
        streak = if (last == t - 1) streak + 1 else 1
        sp.edit().putLong("lastDay", t).apply()
    }

    /** Streak shown to the user: resets to 0 if yesterday was missed. */
    fun currentStreak(): Int {
        val last = sp.getLong("lastDay", -1L)
        return if (last == today() || last == today() - 1) streak else 0
    }

    fun toggleLesson(id: Int) {
        val k = id.toString()
        val next = if (k in lessonsState.value) lessonsState.value - k else lessonsState.value + k
        lessonsState.value = next
        sp.edit().putStringSet("lessons", next).apply()
        if (k in next) markPracticed()
    }
}
