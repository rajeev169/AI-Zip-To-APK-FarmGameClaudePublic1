@file:OptIn(ExperimentalMaterial3Api::class)

package com.appforge.guitarstudio

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.appforge.guitarstudio.core.ChordDetector
import com.appforge.guitarstudio.core.ChordLibrary
import com.appforge.guitarstudio.core.Fx
import com.appforge.guitarstudio.core.Genre
import com.appforge.guitarstudio.core.Jam
import com.appforge.guitarstudio.core.Lessons
import com.appforge.guitarstudio.core.Notes
import com.appforge.guitarstudio.core.Synth
import com.appforge.guitarstudio.core.Tunings
import com.appforge.guitarstudio.core.Yin
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StudioScreen(s: Settings) {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    ScreenColumn("Studio") {
        ChipRow(listOf("Amp & FX", "Jam", "Record", "Game", "Detect"), sub) { sub = it; Player.stop() }
        when (sub) {
            0 -> AmpView(s)
            1 -> JamView(s)
            2 -> MicGate { RecordView() }
            3 -> MicGate { GameView(s) }
            else -> MicGate { DetectView(s) }
        }
    }
}

fun takesDir(ctx: Context): File = File(ctx.filesDir, "takes")

fun listTakes(ctx: Context): List<File> =
    (takesDir(ctx).listFiles()?.filter { it.extension == "wav" } ?: emptyList()).sortedByDescending { it.name }

private val PRESETS = listOf(
    "Clean" to floatArrayOf(0.0f, 0.15f, 0.2f),
    "Crunch" to floatArrayOf(0.3f, 0.2f, 0.2f),
    "Lead" to floatArrayOf(0.6f, 0.3f, 0.25f),
    "Metal" to floatArrayOf(0.9f, 0.1f, 0.1f),
    "Ambient" to floatArrayOf(0.05f, 0.5f, 0.7f)
)

@Composable
fun AmpView(s: Settings) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var drive by remember { mutableFloatStateOf(0.0f) }
    var delayMix by remember { mutableFloatStateOf(0.15f) }
    var reverb by remember { mutableFloatStateOf(0.2f) }
    var busy by remember { mutableStateOf(false) }
    var preset by remember { mutableIntStateOf(0) }
    var takeCount by remember { mutableIntStateOf(listTakes(ctx).size) }
    DisposableEffect(Unit) { onDispose { Player.stop() } }

    fun render(source: () -> FloatArray) {
        scope.launch {
            busy = true
            val out = withContext(Dispatchers.Default) { Fx.apply(source(), SR, drive.toDouble(), delayMix.toDouble(), reverb.toDouble()) }
            busy = false
            Player.play(out)
        }
    }

    SectionCard {
        Text("Amp & effects", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Effects are applied to the demo riff or to one of your recorded takes.", style = MaterialTheme.typography.bodySmall)
        ChipRow(PRESETS.map { it.first }, preset) {
            preset = it
            drive = PRESETS[it].second[0]
            delayMix = PRESETS[it].second[1]
            reverb = PRESETS[it].second[2]
        }
        Text("Distortion ${(drive * 100).roundToInt()}%")
        Slider(value = drive, onValueChange = { drive = it }, valueRange = 0f..1f)
        Text("Delay ${(delayMix * 100).roundToInt()}%")
        Slider(value = delayMix, onValueChange = { delayMix = it }, valueRange = 0f..1f)
        Text("Reverb ${(reverb * 100).roundToInt()}%")
        Slider(value = reverb, onValueChange = { reverb = it }, valueRange = 0f..1f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(enabled = !busy, onClick = {
                render {
                    val out = FloatArray(SR * 6)
                    val names = listOf("Em", "G", "A", "Em")
                    for ((i, n) in names.withIndex()) {
                        val c = ChordLibrary.byName(n)!!
                        Synth.mixInto(out, Synth.chordAudio(c, Tunings.STANDARD, s.refHz.toDouble(), 1.6), (i * 1.4 * SR).toInt())
                    }
                    out
                }
            }) { Text(if (busy) "Working..." else "Play demo riff") }
            FilledTonalButton(enabled = !busy, onClick = {
                val files = listTakes(ctx)
                takeCount = files.size
                if (files.isNotEmpty()) render { readWav(files[0]) }
            }) { Text("Use my last take") }
        }
        if (takeCount == 0) Text("Record a take in the Record tab to hear your own playing with effects.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun JamView(s: Settings) {
    val scope = rememberCoroutineScope()
    val genres = Genre.values()
    var genre by rememberSaveable { mutableIntStateOf(0) }
    var key by rememberSaveable { mutableIntStateOf(9) }
    var bpm by rememberSaveable { mutableIntStateOf(90) }
    var playing by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { Player.stop() } }

    fun stop() { Player.stop(); playing = false }

    val g = genres[genre]
    SectionCard(hero = true) {
        Text("Backing tracks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        ChipRow(genres.map { it.label }, genre) { stop(); genre = it }
        Text("Key")
        ChipRow(Notes.NAMES.toList(), key) { stop(); key = it }
        Text("Tempo: $bpm BPM")
        Slider(value = bpm.toFloat(), onValueChange = { bpm = it.roundToInt() }, onValueChangeFinished = { stop() }, valueRange = 60f..160f)
        val prog = (0 until g.bars).map { ChordLibrary.nameOf((key + g.degrees[it]) % 12, g.qualityAt(it)) }
        Text("Chords (one per bar): " + prog.joinToString(" - "), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        Button(enabled = !busy, onClick = {
            if (playing) stop() else scope.launch {
                busy = true
                val out = withContext(Dispatchers.Default) { Jam.render(g, key, bpm, SR, s.refHz.toDouble()) }
                busy = false
                Player.play(out, loop = true)
                playing = true
            }
        }) { Text(if (busy) "Preparing..." else if (playing) "Stop" else "Start jam") }
    }
}

@Composable
fun RecordView() {
    val ctx = LocalContext.current
    class Holder { var r: WavRecorder? = null }
    val holder = remember { Holder() }
    var recording by remember { mutableStateOf(false) }
    var secs by remember { mutableIntStateOf(0) }
    var takes by remember { mutableStateOf(listTakes(ctx)) }
    var error by remember { mutableStateOf("") }

    DisposableEffect(Unit) { onDispose { holder.r?.stop(); holder.r = null; Player.stop() } }
    LaunchedEffect(recording) {
        while (recording) { delay(1000); secs++ }
    }

    SectionCard(hero = true) {
        Text(
            "%02d:%02d".format(secs / 60, secs % 60),
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 56.sp, fontWeight = FontWeight.Bold
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Button(onClick = {
                if (recording) {
                    holder.r?.stop()
                    holder.r = null
                    recording = false
                    takes = listTakes(ctx)
                } else {
                    val name = "take_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".wav"
                    val r = WavRecorder(File(takesDir(ctx), name))
                    if (r.start()) { holder.r = r; secs = 0; recording = true; error = "" } else error = "Could not start recording"
                }
            }) { Text(if (recording) "Stop" else "Record") }
        }
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
    }
    for (f in takes) {
        SectionCard {
            Text(f.nameWithoutExtension.removePrefix("take_"), fontWeight = FontWeight.Bold)
            Text("${(f.length() / 2 / SR)} s", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { Player.play(readWav(f)) }) { Text("Play") }
                OutlinedButton(onClick = {
                    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                    val send = Intent(Intent.ACTION_SEND)
                    send.type = "audio/wav"
                    send.putExtra(Intent.EXTRA_STREAM, uri)
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    ctx.startActivity(Intent.createChooser(send, "Share take"))
                }) { Text("Share") }
                OutlinedButton(onClick = { f.delete(); takes = listTakes(ctx) }) { Text("Delete") }
            }
        }
    }
}

@Composable
fun GameView(s: Settings) {
    var level by rememberSaveable { mutableIntStateOf(0) }
    val tab = Lessons.ALL.first { it.id == (if (level == 0) 5 else 6) }.tab
    val mic = remember { Mic() }
    val yin = remember { Yin(SR) }
    var running by remember { mutableStateOf(false) }
    var t by remember { mutableLongStateOf(0L) }
    var score by remember { mutableIntStateOf(0) }
    var hits by remember { mutableStateOf(setOf<Int>()) }
    var done by remember { mutableStateOf(false) }
    val gapMs = 1800L
    val leadMs = 3000L

    DisposableEffect(Unit) { onDispose { mic.stop() } }
    LaunchedEffect(running, level) {
        if (!running) return@LaunchedEffect
        if (!mic.start()) { running = false; return@LaunchedEffect }
        hits = emptySet(); score = 0; t = 0L; done = false
        val startNs = System.nanoTime()
        val endT = leadMs + tab.size * gapMs + 600L
        var lastDetect = 0L
        try {
            while (t < endT) {
                delay(33)
                t = (System.nanoTime() - startNs) / 1_000_000L
                if (t - lastDetect > 90) {
                    lastDetect = t
                    val buf = mic.snapshot(yin.requiredSamples)
                    val p = if (buf == null) null else withContext(Dispatchers.Default) { yin.detect(buf) }
                    if (p != null && p.clarity > 0.85) {
                        val m = Notes.midiOf(p.hz, s.refHz.toDouble())
                        for ((i, n) in tab.withIndex()) {
                            if (i in hits) continue
                            val hitT = leadMs + i * gapMs
                            val target = Tunings.noteAt(Tunings.STANDARD, n.string, n.fret)
                            if (abs(t - hitT) <= 500L && abs(m - target) < 0.45) {
                                hits = hits + i
                                score += 100
                            }
                        }
                    }
                }
            }
            done = true
        } finally {
            mic.stop()
        }
        running = false
    }

    SectionCard(hero = true) {
        Text("Play-along game", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Play each falling note on your guitar when it reaches the line. The number in the circle is the fret.", style = MaterialTheme.typography.bodySmall)
        ChipRow(listOf("A minor arpeggio", "Pentatonic box 1"), level) { if (!running) level = it }
        Text("Score: $score of ${tab.size * 100}", fontWeight = FontWeight.Bold)
        val lane = MaterialTheme.colorScheme.outline
        val good = MaterialTheme.colorScheme.primary
        val wait = MaterialTheme.colorScheme.tertiary
        val line = MaterialTheme.colorScheme.onPrimaryContainer
        Canvas(Modifier.fillMaxWidth().height(320.dp)) {
            val laneW = size.width / 6f
            val hitY = size.height - 50f
            for (i in 0..5) drawLine(lane, Offset(laneW * (i + 0.5f), 0f), Offset(laneW * (i + 0.5f), size.height), strokeWidth = 2f)
            drawLine(line, Offset(0f, hitY), Offset(size.width, hitY), strokeWidth = 6f)
            drawIntoCanvas { c ->
                val p = android.graphics.Paint()
                p.isAntiAlias = true
                p.textAlign = android.graphics.Paint.Align.CENTER
                p.textSize = 30f
                p.color = line.toArgb()
                val names = listOf("E", "A", "D", "G", "B", "e")
                for (i in 0..5) c.nativeCanvas.drawText(names[i], laneW * (i + 0.5f), size.height - 8f, p)
            }
            if (running) {
                for ((i, n) in tab.withIndex()) {
                    val hitT = leadMs + i * gapMs
                    val progress = (t - (hitT - leadMs)).toFloat() / leadMs
                    if (progress < 0f || progress > 1.15f) continue
                    val y = progress * hitY
                    val cx = laneW * (n.string + 0.5f)
                    drawCircle(if (i in hits) good else wait, radius = 26f, center = Offset(cx, y), alpha = if (progress > 1.05f && i !in hits) 0.3f else 1f)
                    drawIntoCanvas { c ->
                        val p = android.graphics.Paint()
                        p.isAntiAlias = true
                        p.textAlign = android.graphics.Paint.Align.CENTER
                        p.textSize = 30f
                        p.color = android.graphics.Color.BLACK
                        c.nativeCanvas.drawText(n.fret.toString(), cx, y + 10f, p)
                    }
                }
            }
        }
        if (done && !running) Text("Finished! You hit ${hits.size} of ${tab.size} notes.", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { running = !running }) { Text(if (running) "Stop" else "Start") }
    }
}

@Composable
fun DetectView(s: Settings) {
    val mic = remember { Mic() }
    val det = remember { ChordDetector(SR) }
    var listening by remember { mutableStateOf(false) }
    var current by remember { mutableStateOf("") }
    val log = remember { mutableStateListOf<String>() }

    DisposableEffect(Unit) { onDispose { mic.stop() } }
    LaunchedEffect(listening) {
        if (!listening) return@LaunchedEffect
        if (!mic.start()) { listening = false; return@LaunchedEffect }
        log.clear()
        current = ""
        var last = ""
        var pending = ""
        var pendingCount = 0
        val start = System.currentTimeMillis()
        try {
            while (true) {
                delay(500)
                val buf = mic.snapshot(det.minSamples) ?: continue
                val d = withContext(Dispatchers.Default) {
                    val c = det.chroma(buf)
                    if (c == null) null else det.detect(c)
                }
                if (d != null && d.score > 0.82 && d.margin > 0.03) {
                    val name = d.name
                    if (name == pending) pendingCount++ else { pending = name; pendingCount = 1 }
                    if (pendingCount >= 2 && name != last) {
                        last = name
                        current = name
                        val sec = (System.currentTimeMillis() - start) / 1000
                        log.add("%d:%02d   %s".format(sec / 60, sec % 60, name))
                    }
                }
            }
        } finally {
            mic.stop()
        }
    }

    SectionCard(hero = true) {
        Text("Song to chords", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Play a song or a guitar near your phone. The app listens and writes down the chords it hears (major, minor and 7th chords).", style = MaterialTheme.typography.bodySmall)
        Text(
            if (current.isEmpty()) "-" else current,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 64.sp, fontWeight = FontWeight.Bold
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Button(onClick = { listening = !listening }) { Text(if (listening) "Stop" else "Start listening") }
        }
    }
    if (log.isNotEmpty()) {
        SectionCard {
            Text("Chords heard", fontWeight = FontWeight.Bold)
            for (e in log) Text(e)
        }
    }
    Text("Accuracy is best with a clear guitar. Songs with several instruments or singing can confuse the result.", style = MaterialTheme.typography.bodySmall)
}
