@file:OptIn(ExperimentalMaterial3Api::class)

package com.appforge.guitarstudio

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.appforge.guitarstudio.core.Chord
import com.appforge.guitarstudio.core.TabNote
import com.appforge.guitarstudio.core.Tuning

private val LightColors = lightColorScheme(
    primary = Color(0xFF00796B), onPrimary = Color.White,
    primaryContainer = Color(0xFFB2F0E0), onPrimaryContainer = Color(0xFF00201A),
    secondary = Color(0xFF4A635D), secondaryContainer = Color(0xFFCDE8E0), onSecondaryContainer = Color(0xFF05201B),
    tertiary = Color(0xFF8A6A00), tertiaryContainer = Color(0xFFFFE08A), onTertiaryContainer = Color(0xFF2A1F00),
    background = Color(0xFFF4FBF9), onBackground = Color(0xFF0B1F2A),
    surface = Color(0xFFF4FBF9), onSurface = Color(0xFF0B1F2A),
    surfaceVariant = Color(0xFFDBE5E1), onSurfaceVariant = Color(0xFF3F4946), outline = Color(0xFF6F7975),
    surfaceContainerLow = Color(0xFFEAF4F1), surfaceContainer = Color(0xFFE3EEEB), surfaceContainerHigh = Color(0xFFDCE8E5)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7EE8C8), onPrimary = Color(0xFF00382F),
    primaryContainer = Color(0xFF005046), onPrimaryContainer = Color(0xFFB2F0E0),
    secondary = Color(0xFFB1CCC5), secondaryContainer = Color(0xFF324B46), onSecondaryContainer = Color(0xFFCDE8E0),
    tertiary = Color(0xFFE9C349), tertiaryContainer = Color(0xFF574500), onTertiaryContainer = Color(0xFFFFE08A),
    background = Color(0xFF0B1F2A), onBackground = Color(0xFFE1ECE9),
    surface = Color(0xFF0B1F2A), onSurface = Color(0xFFE1ECE9),
    surfaceVariant = Color(0xFF3F4946), onSurfaceVariant = Color(0xFFBFC9C5), outline = Color(0xFF89938F),
    surfaceContainerLow = Color(0xFF10272F), surfaceContainer = Color(0xFF143039), surfaceContainerHigh = Color(0xFF1B3A44)
)

private val ExpressiveShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(24.dp),
    large = RoundedCornerShape(32.dp),
    extraLarge = RoundedCornerShape(44.dp)
)

@Composable
fun GuitarTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, shapes = ExpressiveShapes, content = content)
}

@Composable
fun ScreenColumn(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
        content()
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun SectionCard(modifier: Modifier = Modifier, hero: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = if (hero) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh
        )
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun ChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEachIndexed { i, s ->
            FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(s) })
        }
    }
}

/** Shows the content only when the microphone permission is granted; otherwise asks for it. */
@Composable
fun MicGate(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    if (granted) {
        content()
    } else {
        SectionCard {
            Text("Microphone access is needed to listen to your guitar. Audio is analysed on your phone and is never uploaded.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = { launcher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Allow microphone") }
        }
    }
}

@Composable
fun ChordDiagram(chord: Chord, left: Boolean, modifier: Modifier = Modifier) {
    val line = MaterialTheme.colorScheme.onSurface
    val dot = MaterialTheme.colorScheme.primary
    val base = chord.baseFret()
    Canvas(modifier.width(190.dp).height(220.dp)) {
        val w = size.width
        val h = size.height
        val l = w * 0.12f
        val r = w * 0.88f
        val top = h * 0.16f
        val bottom = h * 0.97f
        val sx = (r - l) / 5f
        val fy = (bottom - top) / 5f
        fun x(i: Int): Float = l + (if (left) 5 - i else i) * sx
        for (f in 0..5) {
            val nut = f == 0 && base == 1
            drawLine(line.copy(alpha = if (nut) 1f else 0.5f), Offset(l, top + f * fy), Offset(r, top + f * fy), strokeWidth = if (nut) 9f else 2f)
        }
        for (i in 0..5) drawLine(line.copy(alpha = 0.6f), Offset(x(i), top), Offset(x(i), bottom), strokeWidth = 2.5f)
        for (i in 0..5) {
            val f = chord.frets[i]
            if (f > 0) {
                drawCircle(dot, radius = sx * 0.38f, center = Offset(x(i), top + (f - base + 0.5f) * fy))
            } else if (f == 0) {
                drawCircle(line, radius = sx * 0.2f, center = Offset(x(i), top * 0.55f), style = Stroke(width = 3f))
            } else {
                val c = Offset(x(i), top * 0.55f)
                val d = sx * 0.18f
                drawLine(line, Offset(c.x - d, c.y - d), Offset(c.x + d, c.y + d), strokeWidth = 3f)
                drawLine(line, Offset(c.x - d, c.y + d), Offset(c.x + d, c.y - d), strokeWidth = 3f)
            }
        }
    }
}

/** Six-line tab. [active] highlights the note being played (-1 for none). */
@Composable
fun TabView(tab: List<TabNote>, active: Int, modifier: Modifier = Modifier) {
    val line = MaterialTheme.colorScheme.onSurface
    val hi = MaterialTheme.colorScheme.primary
    val bg = MaterialTheme.colorScheme.surface
    val widthDp = (tab.size * 34f + 40f).dp
    Canvas(modifier.width(widthDp).height(150.dp)) {
        val step = size.width / (tab.size + 1)
        val gap = size.height / 7f
        for (s in 0..5) drawLine(line.copy(alpha = 0.5f), Offset(0f, gap * (s + 1)), Offset(size.width, gap * (s + 1)), strokeWidth = 2f)
        drawIntoCanvas { c ->
            val p = android.graphics.Paint()
            p.isAntiAlias = true
            p.textSize = 34f
            p.textAlign = android.graphics.Paint.Align.CENTER
            for ((i, n) in tab.withIndex()) {
                val cx = step * (i + 1)
                val cy = gap * (6 - n.string)   // string 0 (low E) is the bottom line
                val on = i == active
                p.color = bg.toArgb()
                c.nativeCanvas.drawRect(cx - 18f, cy - 20f, cx + 18f, cy + 20f, p)
                p.color = (if (on) hi else line).toArgb()
                p.isFakeBoldText = on
                c.nativeCanvas.drawText(n.fret.toString(), cx, cy + 12f, p)
            }
        }
    }
}

/** Fret markers and note dots for a scale across 12 frets. */
@Composable
fun Fretboard(tuning: Tuning, scale: IntArray, rootPc: Int, modifier: Modifier = Modifier) {
    val line = MaterialTheme.colorScheme.onSurface
    val dot = MaterialTheme.colorScheme.primary
    val rootColor = MaterialTheme.colorScheme.tertiary
    Canvas(modifier.width(760.dp).height(190.dp)) {
        val left = 40f
        val fw = (size.width - left - 10f) / 12f
        val top = 24f
        val gap = (size.height - 60f) / 5f
        for (r in 0..5) drawLine(line.copy(alpha = 0.45f), Offset(left, top + r * gap), Offset(size.width - 10f, top + r * gap), strokeWidth = 2f)
        for (f in 0..12) drawLine(line.copy(alpha = if (f == 0) 0.9f else 0.35f), Offset(left + f * fw, top), Offset(left + f * fw, top + 5 * gap), strokeWidth = if (f == 0) 8f else 2f)
        for (r in 0..5) {
            val s = 5 - r   // top line is the high e string
            for (f in 0..12) {
                val m = tuning.strings[s] + f
                val pc = ((m - rootPc) % 12 + 12) % 12
                if (scale.contains(pc)) {
                    val cx = if (f == 0) left - 16f else left + (f - 0.5f) * fw
                    drawCircle(if (pc == 0) rootColor else dot, radius = 13f, center = Offset(cx, top + r * gap))
                }
            }
        }
        drawIntoCanvas { c ->
            val p = android.graphics.Paint()
            p.isAntiAlias = true
            p.textSize = 26f
            p.textAlign = android.graphics.Paint.Align.CENTER
            p.color = line.copy(alpha = 0.7f).toArgb()
            for (f in intArrayOf(3, 5, 7, 9, 12)) c.nativeCanvas.drawText(f.toString(), left + (f - 0.5f) * fw, size.height - 8f, p)
        }
    }
}

