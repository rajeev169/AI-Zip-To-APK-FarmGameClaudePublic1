package com.appforge.guitarstudio.core

/** String index 0 = low E ... 5 = high e. */
data class TabNote(val string: Int, val fret: Int)

data class Lesson(val id: Int, val title: String, val summary: String, val steps: List<String>, val tab: List<TabNote> = emptyList())

object Lessons {
    val ALL = listOf(
        Lesson(1, "Hold and tune your guitar", "Posture and standard tuning",
            listOf(
                "Sit up straight with the guitar body resting on your thigh and the neck angled slightly upward.",
                "Standard tuning from the thickest string to the thinnest is E A D G B E.",
                "Open the Tune tab, pluck one string at a time and match it. Tune up to the note rather than down, so the string stays stable.",
                "Re-check every string once you finish. Tightening one string slightly changes the others."
            )),
        Lesson(2, "Your first chords: Em, Am and C", "Three open chords you will use in countless songs",
            listOf(
                "Em: middle finger on the A string, 2nd fret. Ring finger on the D string, 2nd fret. Strum all six strings.",
                "Am: index finger on the B string, 1st fret. Middle on the D string, 2nd fret. Ring on the G string, 2nd fret. Strum from the A string down.",
                "C: ring finger on the A string, 3rd fret. Middle on the D string, 2nd fret. Index on the B string, 1st fret. Strum from the A string down.",
                "Use Check my chord in the Chords tab: the app listens and tells you if a note is missing."
            )),
        Lesson(3, "Strumming basics", "Steady rhythm with a metronome",
            listOf(
                "Start with four slow down-strums per bar, counting 1 2 3 4, with the metronome at 60 BPM.",
                "Add up-strums on the in-between counts: 1 & 2 & 3 & 4 &.",
                "Try the common pattern Down, Down-Up, Up-Down-Up: down on 1, down on 2, up on the & of 2, up on the & of 3, down on 4, up on the & of 4.",
                "Keep your strumming hand moving down and up all the time, even when you skip a strum. That keeps the rhythm steady."
            )),
        Lesson(4, "Smooth chord changes", "The skill that separates beginners from players",
            listOf(
                "Pick two chords, for example G and C, and use the Chord-change trainer in the Learn tab.",
                "Look for fingers that can stay put or slide, and move all fingers together as one shape.",
                "Practise slowly at first. Speed comes from accuracy, not from rushing.",
                "Raise your changes-per-minute score a little every day."
            )),
        Lesson(5, "A minor arpeggio (tab)", "Picking the notes of a chord one by one",
            listOf(
                "Follow the tab: play each note with a steady pick, one per beat. Numbers are frets.",
                "Slow the tempo down to 0.5× first, then speed up when every note rings clearly.",
                "The notes A, E, A and C are the notes of an A minor chord (A, C, E)."
            ),
            listOf(TabNote(1, 0), TabNote(2, 2), TabNote(3, 2), TabNote(4, 1), TabNote(3, 2), TabNote(2, 2), TabNote(1, 0), TabNote(2, 2))),
        Lesson(6, "A minor pentatonic, box 1 (tab)", "The most used scale shape for riffs and solos",
            listOf(
                "Place your index finger on the 5th fret. The ring finger covers the 7th fret and the pinky covers the 8th.",
                "Play from the low E string up to the high e string, two notes per string, then back down.",
                "The five notes are A, C, D, E and G. A is the root note."
            ),
            listOf(TabNote(0, 5), TabNote(0, 8), TabNote(1, 5), TabNote(1, 7), TabNote(2, 5), TabNote(2, 7),
                TabNote(3, 5), TabNote(3, 7), TabNote(4, 5), TabNote(4, 8), TabNote(5, 5), TabNote(5, 8))),
        Lesson(7, "Barre chords: F major", "Using your index finger as a bar",
            listOf(
                "Lay your index finger flat across all six strings at the 1st fret.",
                "Place your middle finger on the G string, 2nd fret. Ring finger on the A string, 3rd fret. Pinky on the D string, 3rd fret.",
                "Press close to the fret and keep your thumb behind the neck. Buzzing is normal at first, so build strength in short sessions.",
                "The same shape moved up the neck gives other major chords. The root is on the low E string."
            ))
    )
}

data class Song(val title: String, val difficulty: String, val key: String, val bpm: Int, val strumming: String, val lines: List<String>) {
    /** All chord names used in the song, in order of first appearance. */
    fun chords(): List<String> = lines.flatMap { l -> Regex("\\[([^\\]]+)]").findAll(l).map { it.groupValues[1] }.toList() }.distinct()
}

/** Original songs written for this app (no copyrighted material). Chords are inline in [brackets]. */
object Songs {
    val ALL = listOf(
        Song("Horizon Road", "Easy", "G", 90, "D DU UDU",
            listOf("[G]Walking down the [D]horizon road", "[Em]Every step feels [C]like home", "[G]Take me where the [D]sunlight goes", "[Em]I will never [C]walk alone")),
        Song("Morning Porch", "Easy", "C", 80, "D D D D",
            listOf("[C]Coffee on the [Am]porch at dawn", "[F]Birds are singing [G]on", "[C]Nothing left to [Am]hurry for", "[F]Let the day be [G]long")),
        Song("Open Highway", "Easy", "E", 100, "D DU UDU",
            listOf("[E]Open highway [A]and the sun", "[E]Nothing left to [B7]prove to anyone", "[E]Windows down and [A]radio on", "[E]Carry me [B7]home [E]")),
        Song("Quiet River", "Medium", "D", 76, "D DU UDU",
            listOf("[D]Quiet river [Bm]carry me", "[G]Down to where the [A]ocean is free", "[D]Slow and golden [Bm]evening light", "[G]Hold me [A]through the [D]night")),
        Song("Rainy Blues", "Medium", "A", 70, "12-bar blues shuffle",
            listOf("[A7]Grey clouds over my window, coffee gone cold by the door", "[D7]Grey clouds over my window, [A7]coffee gone cold by the door",
                "[E7]Play me one more slow one, [D7]then I will [A7]let it [E7]go")),
        Song("Midnight Fire", "Hard", "Am", 110, "D DU UDU",
            listOf("[Am]Sparks fly under the [F]city lights", "[C]We run until the [G]dawn", "[Am]Hold the fire, [F]hold it tight", "[C]Until the night is [G]gone"))
    )
}

data class PracticeTask(val id: String, val title: String, val minutes: Int, val route: String)

object Practice {
    /** Daily plan: puts the chord-change trainer first when the player's best score is still low. */
    fun plan(bestChangesPerMinute: Int): List<PracticeTask> {
        val first = if (bestChangesPerMinute < 30)
            PracticeTask("changes", "Chord changes (your slowest skill)", 3, "train")
        else PracticeTask("changes", "Chord changes: beat your best of $bestChangesPerMinute", 3, "train")
        return listOf(
            first,
            PracticeTask("strum", "Strumming with the metronome", 4, "metro"),
            PracticeTask("scale", "A minor pentatonic, box 1", 3, "lessons")
        )
    }
}
