package com.appforge.guitarstudio.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class Pitch(val hz: Double, val clarity: Double)

/** YIN fundamental-frequency estimator. Works on a float buffer of at least [requiredSamples] samples. */
class Yin(
    private val sampleRate: Int,
    minHz: Double = 60.0,
    maxHz: Double = 1000.0,
    private val threshold: Double = 0.15,
    private val windowSize: Int = 2048,
    private val gate: Double = 0.01
) {
    private val maxTau = (sampleRate / minHz).toInt()
    private val minTau = maxOf(2, (sampleRate / maxHz).toInt())
    private val cmnd = DoubleArray(maxTau + 2)
    val requiredSamples: Int get() = windowSize + maxTau + 2

    fun detect(x: FloatArray): Pitch? {
        if (x.size < requiredSamples) return null
        var e = 0.0
        for (i in 0 until windowSize) e += x[i] * x[i]
        if (sqrt(e / windowSize) < gate) return null
        var running = 0.0
        cmnd[0] = 1.0
        for (tau in 1..maxTau + 1) {
            var s = 0.0
            for (j in 0 until windowSize) {
                val d = x[j] - x[j + tau]
                s += d * d
            }
            running += s
            cmnd[tau] = if (running > 0.0) s * tau / running else 1.0
        }
        var tau = minTau
        var found = -1
        while (tau <= maxTau) {
            if (cmnd[tau] < threshold) {
                while (tau + 1 <= maxTau && cmnd[tau + 1] < cmnd[tau]) tau++
                found = tau
                break
            }
            tau++
        }
        if (found < 0) return null
        val a = cmnd[found - 1]
        val b = cmnd[found]
        val c = cmnd[found + 1]
        val denom = a - 2 * b + c
        val shift = if (abs(denom) > 1e-12) 0.5 * (a - c) / denom else 0.0
        val better = found + shift
        return Pitch(sampleRate / better, 1.0 - b)
    }
}

object Fft {
    /** In-place radix-2 FFT. Size must be a power of two. */
    fun transform(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang)
            val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0
                var ci = 0.0
                for (k in 0 until len / 2) {
                    val ur = re[i + k]; val ui = im[i + k]
                    val vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci
                    val vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr
                    re[i + k] = ur + vr; im[i + k] = ui + vi
                    re[i + k + len / 2] = ur - vr; im[i + k + len / 2] = ui - vi
                    val nr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = nr
                }
                i += len
            }
            len = len shl 1
        }
    }
}

data class Detection(val root: Int, val quality: Quality, val score: Double, val margin: Double) {
    val name: String get() = ChordLibrary.nameOf(root, quality)
}

/** missingStrings: string indices 0 (low E) .. 5 whose note is not ringing. extra: pitch classes that should not be there. */
data class TargetResult(val ok: Boolean, val missingStrings: List<Int>, val extra: List<Int>, val similarity: Double)

/** Chromagram + template matching chord recogniser. */
class ChordDetector(private val sampleRate: Int, private val size: Int = 16384) {
    private val window = DoubleArray(size) { 0.5 - 0.5 * cos(2.0 * PI * it / (size - 1)) }
    private val re = DoubleArray(size)
    private val im = DoubleArray(size)

    val minSamples: Int get() = size

    /** Magnitude spectrum (size/2 bins), or null when the input is too quiet. Values are scaled so the band maximum is 1. */
    private fun magnitudes(samples: FloatArray, quietRms: Double = 0.005): DoubleArray? {
        val n = minOf(size, samples.size)
        val start = samples.size - n
        var e = 0.0
        for (i in 0 until n) e += samples[start + i] * samples[start + i]
        if (n == 0 || sqrt(e / n) < quietRms) return null
        for (i in 0 until size) {
            re[i] = if (i < n) samples[start + i] * window[i] else 0.0
            im[i] = 0.0
        }
        Fft.transform(re, im)
        val half = size / 2
        val mag = DoubleArray(half) { sqrt(re[it] * re[it] + im[it] * im[it]) }
        var maxMag = 0.0
        val lo = binOf(70.0)
        val hi = minOf(half - 2, binOf(2000.0))
        for (k in lo..hi) if (mag[k] > maxMag) maxMag = mag[k]
        if (maxMag <= 0.0) return null
        for (k in mag.indices) mag[k] /= maxMag
        return mag
    }

    private fun binOf(hz: Double): Int = (hz * size / sampleRate).toInt().coerceAtLeast(2)

    /** 12 pitch-class energies (C..B), normalised so the maximum is 1. Returns null when the input is too quiet. */
    fun chroma(samples: FloatArray, quietRms: Double = 0.005): DoubleArray? {
        val mag = magnitudes(samples, quietRms) ?: return null
        return chromaFrom(mag)
    }

    private fun chromaFrom(mag: DoubleArray): DoubleArray? {
        val half = size / 2
        val lo = binOf(70.0)
        val hi = minOf(half - 2, binOf(2000.0))
        val chroma = DoubleArray(12)
        for (k in lo..hi) {
            val m = mag[k]
            if (m < 0.04 || m < mag[k - 1] || m <= mag[k + 1]) continue
            val a = ln(mag[k - 1] + 1e-12); val b = ln(m + 1e-12); val c = ln(mag[k + 1] + 1e-12)
            val d = a - 2 * b + c
            val shift = if (abs(d) > 1e-12) 0.5 * (a - c) / d else 0.0
            val hz = (k + shift) * sampleRate / size
            val midi = Notes.midiOf(hz)
            val nearest = Math.round(midi).toInt()
            val dev = abs(midi - nearest)
            if (dev > 0.35) continue
            chroma[Notes.pc(nearest)] += m.pow(0.7) * (1.0 - dev)
        }
        val mx = chroma.max()
        if (mx <= 0.0) return null
        for (i in 0 until 12) chroma[i] /= mx
        return chroma
    }

    fun detect(chroma: DoubleArray, qualities: List<Quality> = listOf(Quality.MAJ, Quality.MIN, Quality.DOM7)): Detection? {
        var best: Detection? = null
        var second = 0.0
        for (root in 0 until 12) for (q in qualities) {
            val s = cosine(chroma, template(root, q))
            if (best == null || s > best.score) {
                if (best != null) second = maxOf(second, best.score)
                best = Detection(root, q, s, 0.0)
            } else second = maxOf(second, s)
        }
        val b = best ?: return null
        return Detection(b.root, b.quality, b.score, b.score - second)
    }

    /** Chord template that also models the upper harmonics (3rd, 5th, 7th) every plucked string produces. */
    private fun template(root: Int, q: Quality): DoubleArray {
        val t = DoubleArray(12)
        for ((i, iv) in q.intervals.withIndex()) {
            val w = if (i == 0) 1.2 else 1.0
            val pc = (root + iv) % 12
            t[pc] += w
            t[(pc + 7) % 12] += 0.45 * w
            t[(pc + 4) % 12] += 0.22 * w
            t[(pc + 10) % 12] += 0.10 * w
        }
        return t
    }

    private fun cosine(a: DoubleArray, b: DoubleArray): Double {
        var dot = 0.0; var na = 0.0; var nb = 0.0
        for (i in 0 until 12) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        return if (na == 0.0 || nb == 0.0) 0.0 else dot / (sqrt(na) * sqrt(nb))
    }

    private class Reference(val mag: DoubleArray, val chroma: DoubleArray)
    private val expectedCache = HashMap<String, Reference>()

    private fun reference(target: Chord, tuning: Tuning, ref: Double): Reference =
        expectedCache.getOrPut(target.name + target.frets.joinToString("") + tuning.name + ref) {
            val len = size + sampleRate / 2
            val sig = FloatArray(len)
            for ((i, m) in target.midis(tuning).sorted().withIndex()) {
                Synth.mixInto(sig, Synth.pluck(Notes.freq(m.toDouble(), ref), len / sampleRate.toDouble() + 0.1, sampleRate, 0.22, 11L + m), (i * 0.035 * sampleRate).toInt())
            }
            val mag = magnitudes(sig.copyOfRange(sampleRate / 4, sampleRate / 4 + size))!!
            Reference(mag, chromaFrom(mag) ?: DoubleArray(12))
        }

    private fun peakNear(mag: DoubleArray, hz: Double): Double {
        val lo = ((hz * 0.988) * size / sampleRate).toInt().coerceAtLeast(1)
        val hi = ((hz * 1.012) * size / sampleRate).toInt() + 1
        var p = 0.0
        for (k in lo..minOf(hi, mag.size - 1)) if (mag[k] > p) p = mag[k]
        return p
    }

    /**
     * "Check my chord". Compares the heard sound with a clean strum of [target]: each string's own fundamental is
     * looked up in the spectrum, so a string that is muted or not pressed down can be named. Thresholds are lenient
     * because a real guitar sounds different from the reference.
     */
    fun analyze(samples: FloatArray, target: Chord, tuning: Tuning = Tunings.STANDARD, ref: Double = 440.0,
                minRatio: Double = 0.25, extraMargin: Double = 0.45): TargetResult? {
        val mag = magnitudes(samples) ?: return null
        val heard = chromaFrom(mag) ?: return null
        val r = reference(target, tuning, ref)
        val missing = ArrayList<Int>()
        for (i in target.frets.indices) {
            if (target.frets[i] < 0) continue
            val hz = Notes.freq((tuning.strings[i] + target.frets[i]).toDouble(), ref)
            val expected = peakNear(r.mag, hz)
            if (expected > 0.05 && peakNear(mag, hz) < expected * minRatio) missing.add(i)
        }
        val extra = (0 until 12).filter { it !in target.pitchClasses() && heard[it] - r.chroma[it] > extraMargin }
        val sim = cosine(heard, r.chroma)
        return TargetResult(missing.isEmpty() && extra.isEmpty() && sim > 0.85, missing, extra, sim)
    }
}

/** Generates metronome clicks sample-accurately; bpm can change at any time. */
class MetronomeGenerator(private val sampleRate: Int) {
    @Volatile var bpm: Double = 100.0
    @Volatile var beatsPerBar: Int = 4
    private var posInBeat = 0L
    private var beatIndex = 0
    private val clickLen = (sampleRate * 0.03).toInt()

    fun reset() { posInBeat = 0; beatIndex = 0 }

    /** Fills [out] with audio. [onBeat] is called with the beat number (0 = accent) when a beat starts. */
    fun fill(out: FloatArray, onBeat: (Int) -> Unit) {
        val samplesPerBeat = (60.0 / bpm * sampleRate).toLong()
        for (i in out.indices) {
            if (posInBeat == 0L) onBeat(beatIndex)
            out[i] = if (posInBeat < clickLen) {
                val f = if (beatIndex == 0) 1500.0 else 1000.0
                val env = 1.0 - posInBeat.toDouble() / clickLen
                (sin(2.0 * PI * f * posInBeat / sampleRate) * env * 0.8).toFloat()
            } else 0f
            posInBeat++
            if (posInBeat >= samplesPerBeat) {
                posInBeat = 0
                beatIndex = (beatIndex + 1) % beatsPerBar
            }
        }
    }
}

object Wav {
    fun toFloat(pcm: ShortArray): FloatArray = FloatArray(pcm.size) { pcm[it] / 32768f }
    fun toShort(x: FloatArray): ShortArray = ShortArray(x.size) {
        (x[it].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
    }
    fun floorMod(a: Int, b: Int): Int = ((a % b) + b) % b
    fun fractional(x: Double): Double = x - floor(x)
}
