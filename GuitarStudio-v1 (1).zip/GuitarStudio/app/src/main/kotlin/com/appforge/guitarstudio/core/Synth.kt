package com.appforge.guitarstudio.core

import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

object Synth {
    const val SR = 44100

    /** Karplus-Strong plucked string with fractional-delay tuning (accurate pitch). */
    fun pluck(hz: Double, seconds: Double, sr: Int = SR, amp: Double = 0.3, seed: Long = 1L): FloatArray {
        val out = FloatArray((seconds * sr).toInt())
        val total = sr / hz - 0.5
        val n = floor(total - 0.5).toInt().coerceAtLeast(2)
        val dFrac = total - n
        val a = ((1.0 - dFrac) / (1.0 + dFrac)).toFloat()
        val rnd = Random(seed)
        val buf = FloatArray(n)
        var prevNoise = 0f
        var peak = 1e-6f
        for (i in 0 until n) {
            val v = (rnd.nextFloat() * 2f - 1f)
            buf[i] = 0.5f * v + 0.5f * prevNoise
            prevNoise = v
            peak = maxOf(peak, abs(buf[i]))
        }
        for (i in 0 until n) buf[i] = buf[i] / peak * amp.toFloat()
        val rho = 0.5.pow(1.0 / (hz * 1.6)).toFloat()
        var pos = 0
        var prevCur = 0f
        var apX = 0f
        var apY = 0f
        for (i in out.indices) {
            val cur = buf[pos]
            val avg = rho * 0.5f * (cur + prevCur)
            val y = a * avg + apX - a * apY
            apX = avg; apY = y
            buf[pos] = y
            out[i] = cur
            prevCur = cur
            pos = (pos + 1) % n
        }
        return out
    }

    fun mixInto(dst: FloatArray, src: FloatArray, offset: Int, gain: Float = 1f) {
        for (i in src.indices) {
            val j = offset + i
            if (j >= dst.size) break
            if (j >= 0) dst[j] += src[i] * gain
        }
    }

    fun strum(midis: List<Int>, ref: Double = 440.0, seconds: Double = 2.0, spacingMs: Double = 35.0, down: Boolean = true, amp: Double = 0.22): FloatArray {
        val out = FloatArray((seconds * SR).toInt())
        val order = if (down) midis.sorted() else midis.sortedDescending()
        for ((i, m) in order.withIndex()) {
            val p = pluck(Notes.freq(m.toDouble(), ref), seconds, SR, amp, 11L + m)
            mixInto(out, p, (i * spacingMs * SR / 1000.0).toInt())
        }
        return out
    }

    fun chordAudio(c: Chord, tuning: Tuning = Tunings.STANDARD, ref: Double = 440.0, seconds: Double = 2.0) =
        strum(c.midis(tuning), ref, seconds)

    /** Plain triad / seventh voicing for any root (used by backing tracks), notes between E3 and D#4. */
    fun voicing(root: Int, q: Quality): List<Int> = q.intervals.map { iv ->
        52 + Wav.floorMod(root + iv - 52, 12)
    }

    fun bassNote(root: Int): Int = 36 + Wav.floorMod(root - 36, 12)

    fun tone(hz: Double, seconds: Double, amp: Double = 0.3): FloatArray {
        val n = (seconds * SR).toInt()
        return FloatArray(n) {
            val env = exp(-3.0 * it / n)
            (sin(2.0 * PI * hz * it / SR) * env * amp).toFloat()
        }
    }

    // ---- drums ----
    fun kick(): FloatArray {
        val n = (0.25 * SR).toInt()
        var phase = 0.0
        return FloatArray(n) {
            val t = it.toDouble() / SR
            val f = 45.0 + 110.0 * exp(-t * 28.0)
            phase += 2.0 * PI * f / SR
            (sin(phase) * exp(-t * 14.0) * 0.9).toFloat()
        }
    }

    private fun noise(n: Int, seed: Long): FloatArray {
        val r = Random(seed)
        var prev = 0f
        return FloatArray(n) { val v = r.nextFloat() * 2f - 1f; val o = v - prev; prev = v; o * 0.5f }
    }

    fun snare(): FloatArray {
        val n = (0.2 * SR).toInt()
        val nz = noise(n, 5L)
        return FloatArray(n) {
            val t = it.toDouble() / SR
            (nz[it] * exp(-t * 22.0) * 0.8 + sin(2.0 * PI * 190.0 * t) * exp(-t * 30.0) * 0.4).toFloat() * 0.8f
        }
    }

    fun hat(): FloatArray {
        val n = (0.06 * SR).toInt()
        val nz = noise(n, 9L)
        return FloatArray(n) { (nz[it] * exp(-it.toDouble() / SR * 70.0) * 0.5).toFloat() }
    }
}

object Fx {
    /**
     * Distortion -> delay -> reverb. drive/delayMix/reverbMix in 0..1. Output is longer than the input by a tail.
     */
    fun apply(input: FloatArray, sr: Int = Synth.SR, drive: Double, delayMix: Double, reverbMix: Double, delayMs: Double = 320.0): FloatArray {
        val tail = (2.0 * sr).toInt()
        val n = input.size + tail
        val x = FloatArray(n)
        val g = 1.0 + drive * 40.0
        val norm = tanh(g)
        for (i in input.indices) x[i] = (tanh(g * input[i]) / norm * (if (drive > 0.01) 0.6 else 1.0)).toFloat()
        val out = FloatArray(n)
        for (i in 0 until n) out[i] = x[i]
        // feedback delay
        val dl = (delayMs * sr / 1000.0).toInt()
        val d = FloatArray(n)
        for (i in 0 until n) {
            val fb = if (i >= dl) d[i - dl] * 0.4f else 0f
            d[i] = x[i] + fb
            if (i >= dl) out[i] += (d[i - dl]) * delayMix.toFloat()
        }
        // Schroeder reverb
        if (reverbMix > 0.001) {
            val scale = sr / 44100.0
            val combs = intArrayOf(1116, 1188, 1277, 1356).map { (it * scale).toInt() }
            val wet = FloatArray(n)
            for (cd in combs) {
                val buf = FloatArray(n)
                for (i in 0 until n) {
                    val fb = if (i >= cd) buf[i - cd] * 0.84f else 0f
                    buf[i] = x[i] + fb
                    wet[i] += buf[i] * 0.25f
                }
            }
            var w = wet
            for (ap in intArrayOf(556, 441).map { (it * scale).toInt() }) {
                val y = FloatArray(n)
                for (i in 0 until n) {
                    val xd = if (i >= ap) w[i - ap] else 0f
                    val yd = if (i >= ap) y[i - ap] else 0f
                    y[i] = -0.5f * w[i] + xd + 0.5f * yd
                }
                w = y
            }
            for (i in 0 until n) out[i] += w[i] * reverbMix.toFloat() * 0.25f
        }
        var peak = 1e-6f
        for (v in out) peak = maxOf(peak, abs(v))
        val gain = if (peak > 0.95f) 0.95f / peak else 1f
        for (i in 0 until n) out[i] *= gain
        return out
    }
}

enum class Genre(val label: String, val steps: Int, val kick: IntArray, val snare: IntArray, val hat: IntArray, val degrees: IntArray, val quality: Quality, val bars: Int) {
    ROCK("Rock", 8, intArrayOf(0, 4), intArrayOf(2, 6), intArrayOf(0, 1, 2, 3, 4, 5, 6, 7), intArrayOf(0, 5, 7, 5), Quality.MAJ, 4),
    POP("Pop", 8, intArrayOf(0, 2, 4, 6), intArrayOf(2, 6), intArrayOf(1, 3, 5, 7), intArrayOf(0, 7, 9, 5), Quality.MAJ, 4),
    BLUES("Blues", 12, intArrayOf(0, 6), intArrayOf(3, 9), intArrayOf(0, 2, 3, 5, 6, 8, 9, 11), intArrayOf(0, 0, 0, 0, 5, 5, 0, 0, 7, 5, 0, 7), Quality.DOM7, 12),
    FOLK("Folk", 8, intArrayOf(0, 4), intArrayOf(2, 6), intArrayOf(), intArrayOf(0, 5, 0, 7), Quality.MAJ, 4);

    /** Quality of the chord for a given degree (minor vi in pop). */
    fun qualityAt(bar: Int): Quality = if (this == POP && degrees[bar] == 9) Quality.MIN else quality
}

object Jam {
    /** One seamless loop of the whole progression, 4/4 (12/8 feel for blues). */
    fun render(genre: Genre, keyPc: Int, bpm: Int, sr: Int = Synth.SR, ref: Double = 440.0): FloatArray {
        val barSamples = (4.0 * 60.0 / bpm * sr).toInt()
        val loop = barSamples * genre.bars
        val tail = 2 * sr
        val buf = FloatArray(loop + tail)
        val kick = Synth.kick(); val snare = Synth.snare(); val hat = Synth.hat()
        val stepLen = barSamples / genre.steps
        for (bar in 0 until genre.bars) {
            val barStart = bar * barSamples
            for (s in genre.kick) Synth.mixInto(buf, kick, barStart + s * stepLen)
            for (s in genre.snare) Synth.mixInto(buf, snare, barStart + s * stepLen)
            for (s in genre.hat) Synth.mixInto(buf, hat, barStart + s * stepLen, 0.7f)
            val root = (keyPc + genre.degrees[bar]) % 12
            val q = genre.qualityAt(bar)
            val bassHz = Notes.freq(Synth.bassNote(root).toDouble(), ref)
            for (s in genre.kick) {
                val b = Synth.pluck(bassHz, 0.5, sr, 0.5, 3L)
                Synth.mixInto(buf, b, barStart + s * stepLen)
            }
            val chord = Synth.strum(Synth.voicing(root, q), ref, 1.8, 28.0, true, 0.16)
            Synth.mixInto(buf, chord, barStart)
            if (genre != Genre.BLUES) Synth.mixInto(buf, Synth.strum(Synth.voicing(root, q), ref, 1.2, 28.0, true, 0.12), barStart + barSamples / 2, 0.8f)
        }
        val out = FloatArray(loop)
        for (i in 0 until loop) out[i] = buf[i] + (if (i < tail) buf[loop + i] else 0f)
        var peak = 1e-6f
        for (v in out) peak = maxOf(peak, abs(v))
        if (peak > 0.9f) for (i in out.indices) out[i] *= 0.9f / peak
        return out
    }
}
