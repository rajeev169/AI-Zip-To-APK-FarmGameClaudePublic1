package com.appforge.guitarstudio.core

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow

/** Note maths. MIDI 69 = A4. Strings are always listed low (6th) to high (1st). */
object Notes {
    val NAMES = arrayOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
    private val SHAPE_NAMES = arrayOf("C", "C♯", "D", "E♭", "E", "F", "F♯", "G", "A♭", "A", "B♭", "B")

    fun pc(midi: Int): Int = ((midi % 12) + 12) % 12
    fun name(midi: Int): String = NAMES[pc(midi)]
    fun nameOct(midi: Int): String = name(midi) + (Math.floorDiv(midi, 12) - 1)
    fun shapeName(pc: Int): String = SHAPE_NAMES[((pc % 12) + 12) % 12]

    fun freq(midi: Double, ref: Double = 440.0): Double = ref * 2.0.pow((midi - 69.0) / 12.0)
    fun midiOf(hz: Double, ref: Double = 440.0): Double = 69.0 + 12.0 * ln(hz / ref) / ln(2.0)
    fun cents(hz: Double, targetMidi: Int, ref: Double = 440.0): Double =
        1200.0 * ln(hz / freq(targetMidi.toDouble(), ref)) / ln(2.0)
}

data class Tuning(val name: String, val strings: List<Int>) {
    fun label(): String = strings.joinToString(" ") { Notes.name(it) }
}

object Tunings {
    val STANDARD = Tuning("Standard", listOf(40, 45, 50, 55, 59, 64))
    val ALL = listOf(
        STANDARD,
        Tuning("Drop D", listOf(38, 45, 50, 55, 59, 64)),
        Tuning("Half step down", listOf(39, 44, 49, 54, 58, 63)),
        Tuning("DADGAD", listOf(38, 45, 50, 55, 57, 62)),
        Tuning("Open G", listOf(38, 43, 50, 55, 59, 62)),
        Tuning("Open D", listOf(38, 45, 50, 54, 57, 62))
    )

    /** Index of the string whose open pitch is closest (in cents) to the heard frequency. */
    fun nearestString(hz: Double, t: Tuning, ref: Double = 440.0): Int {
        var best = 0
        var bestAbs = Double.MAX_VALUE
        for (i in t.strings.indices) {
            val c = abs(Notes.cents(hz, t.strings[i], ref))
            if (c < bestAbs) { bestAbs = c; best = i }
        }
        return best
    }

    fun noteAt(tuning: Tuning, stringIdx: Int, fret: Int): Int = tuning.strings[stringIdx] + fret
}

enum class Quality(val suffix: String, val intervals: IntArray) {
    MAJ("", intArrayOf(0, 4, 7)),
    MIN("m", intArrayOf(0, 3, 7)),
    DOM7("7", intArrayOf(0, 4, 7, 10)),
    MAJ7("maj7", intArrayOf(0, 4, 7, 11)),
    MIN7("m7", intArrayOf(0, 3, 7, 10)),
    SUS2("sus2", intArrayOf(0, 2, 7)),
    SUS4("sus4", intArrayOf(0, 5, 7))
}

/** frets: 6 entries low E to high e; -1 = muted string, 0 = open. */
class Chord(val label: String, val root: Int, val quality: Quality, val frets: IntArray) {
    val name: String get() = label + quality.suffix
    fun pitchClasses(): Set<Int> = quality.intervals.map { (root + it) % 12 }.toSet()

    fun midis(tuning: Tuning = Tunings.STANDARD): List<Int> =
        frets.indices.filter { frets[it] >= 0 }.map { tuning.strings[it] + frets[it] }

    /** First fret shown in a diagram (1 unless the shape sits higher than fret 4). */
    fun baseFret(): Int {
        val fretted = frets.filter { it > 0 }
        if (fretted.isEmpty() || fretted.max() <= 4) return 1
        return fretted.min()
    }
}

object ChordLibrary {
    private fun c(label: String, root: Int, q: Quality, shape: String): Chord {
        val frets = IntArray(6) { i -> if (shape[i] == 'x') -1 else shape[i] - '0' }
        return Chord(label, root, q, frets)
    }

    val ALL: List<Chord> = listOf(
        c("C", 0, Quality.MAJ, "x32010"), c("D", 2, Quality.MAJ, "xx0232"), c("E", 4, Quality.MAJ, "022100"),
        c("F", 5, Quality.MAJ, "133211"), c("G", 7, Quality.MAJ, "320003"), c("A", 9, Quality.MAJ, "x02220"),
        c("B", 11, Quality.MAJ, "x24442"), c("B♭", 10, Quality.MAJ, "x13331"),
        c("C", 0, Quality.MIN, "x35543"), c("C♯", 1, Quality.MIN, "x46654"), c("D", 2, Quality.MIN, "xx0231"),
        c("E", 4, Quality.MIN, "022000"), c("F", 5, Quality.MIN, "133111"), c("F♯", 6, Quality.MIN, "244222"),
        c("G", 7, Quality.MIN, "355333"), c("A", 9, Quality.MIN, "x02210"), c("B", 11, Quality.MIN, "x24432"),
        c("C", 0, Quality.DOM7, "x32310"), c("D", 2, Quality.DOM7, "xx0212"), c("E", 4, Quality.DOM7, "020100"),
        c("G", 7, Quality.DOM7, "320001"), c("A", 9, Quality.DOM7, "x02020"), c("B", 11, Quality.DOM7, "x21202"),
        c("C", 0, Quality.MAJ7, "x32000"), c("D", 2, Quality.MAJ7, "xx0222"), c("E", 4, Quality.MAJ7, "021100"),
        c("F", 5, Quality.MAJ7, "xx3210"), c("G", 7, Quality.MAJ7, "320002"), c("A", 9, Quality.MAJ7, "x02120"),
        c("D", 2, Quality.MIN7, "xx0211"), c("E", 4, Quality.MIN7, "022030"), c("A", 9, Quality.MIN7, "x02010"),
        c("B", 11, Quality.MIN7, "x20202"),
        c("D", 2, Quality.SUS2, "xx0230"), c("D", 2, Quality.SUS4, "xx0233"), c("A", 9, Quality.SUS2, "x02200"),
        c("A", 9, Quality.SUS4, "x02230"), c("E", 4, Quality.SUS4, "022200")
    )

    fun find(root: Int, q: Quality): Chord? = ALL.firstOrNull { it.root == root && it.quality == q }

    fun byName(name: String): Chord? = ALL.firstOrNull { it.name == name }

    /** Parses names like "G", "F♯m", "B♭", "Am7", "Cmaj7" (also # and b). Returns root pc + quality or null. */
    fun parse(name: String): Pair<Int, Quality>? {
        if (name.isEmpty()) return null
        val base = when (name[0]) { 'C' -> 0; 'D' -> 2; 'E' -> 4; 'F' -> 5; 'G' -> 7; 'A' -> 9; 'B' -> 11; else -> return null }
        var root = base
        var i = 1
        while (i < name.length && (name[i] == '♯' || name[i] == '#' || name[i] == '♭' || name[i] == 'b')) {
            root += if (name[i] == '♯' || name[i] == '#') 1 else -1
            i++
        }
        val suffix = name.substring(i)
        val q = Quality.values().firstOrNull { it.suffix == suffix } ?: return null
        return Pair(((root % 12) + 12) % 12, q)
    }

    fun nameOf(root: Int, q: Quality): String = Notes.shapeName(root) + q.suffix

    /** Moves a chord name by a number of semitones (negative = down). */
    fun transpose(name: String, semitones: Int): String {
        val (r, q) = parse(name) ?: return name
        return nameOf(r + semitones, q)
    }

    /**
     * Capo helper: for each capo fret 0..7 returns how many of the song's chords become shapes that exist in
     * the library as open-position shapes (contain an open string). Best capo = highest count, lowest fret.
     */
    fun bestCapo(chords: List<String>): Int {
        var best = 0
        var bestScore = -1.0
        for (capo in 0..7) {
            var score = 0.0
            for (n in chords.distinct()) {
                val (r, q) = parse(n) ?: continue
                val shape = find(((r - capo) % 12 + 12) % 12, q) ?: continue
                score += if (shape.frets.any { it == 0 }) 1.0 else 0.3   // open shapes are easier than barre shapes
            }
            score -= 0.12 * capo                                           // prefer a lower capo position
            if (score > bestScore + 1e-9) { bestScore = score; best = capo }
        }
        return best
    }
}

object Scales {
    val ALL: Map<String, IntArray> = linkedMapOf(
        "Major" to intArrayOf(0, 2, 4, 5, 7, 9, 11),
        "Natural minor" to intArrayOf(0, 2, 3, 5, 7, 8, 10),
        "Major pentatonic" to intArrayOf(0, 2, 4, 7, 9),
        "Minor pentatonic" to intArrayOf(0, 3, 5, 7, 10),
        "Blues" to intArrayOf(0, 3, 5, 6, 7, 10),
        "Dorian" to intArrayOf(0, 2, 3, 5, 7, 9, 10),
        "Mixolydian" to intArrayOf(0, 2, 4, 5, 7, 9, 10)
    )

    fun contains(scale: IntArray, rootPc: Int, midi: Int): Boolean = scale.contains(((midi - rootPc) % 12 + 12) % 12)
}
