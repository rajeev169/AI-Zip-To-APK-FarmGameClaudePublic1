import com.appforge.guitarstudio.core.*
import kotlin.math.abs

var failures = 0
var checks = 0
fun check(name: String, ok: Boolean, detail: String = "") {
    checks++
    if (!ok) { failures++; println("FAIL: $name $detail") }
}

fun main() {
    val sr = 44100
    // 1. Chord library accuracy
    for (c in ChordLibrary.ALL) {
        val formula = c.pitchClasses()
        val sounding = c.midis().map { Notes.pc(it) }.toSet()
        check("${c.name} subset", formula.containsAll(sounding), "sounding=$sounding formula=$formula")
        check("${c.name} root", sounding.contains(c.root))
        val charTone = (c.root + c.quality.intervals[1]) % 12
        check("${c.name} third/sus", sounding.contains(charTone))
        if (c.quality.intervals.size == 4) check("${c.name} seventh", sounding.contains((c.root + c.quality.intervals[3]) % 12))
        check("${c.name} lowest note root-ish", true)
        check("${c.name} six fret entries", c.frets.size == 6)
    }
    println("chord library checked: ${ChordLibrary.ALL.size} chords")
    // bass note is root for every library chord (no slash chords in library)
    for (c in ChordLibrary.ALL) check("${c.name} bass", Notes.pc(c.midis().min()) == c.root, "bass=${Notes.name(c.midis().min())}")

    // 2. Names, parse, transpose
    check("parse Am7", ChordLibrary.parse("Am7") == Pair(9, Quality.MIN7))
    check("parse F♯m", ChordLibrary.parse("F♯m") == Pair(6, Quality.MIN))
    check("parse Bb", ChordLibrary.parse("Bb") == Pair(10, Quality.MAJ))
    check("transpose G down 3", ChordLibrary.transpose("G", -3) == "E")
    check("transpose Em up 2", ChordLibrary.transpose("Em", 2) == "F♯m")
    check("transpose C down 1", ChordLibrary.transpose("C", -1) == "B")
    check("transpose D up 8", ChordLibrary.transpose("D", 8) == "B♭")
    check("capo for Bm D G A", ChordLibrary.bestCapo(listOf("Bm", "D", "G", "A")) == 0)
    val capoF = ChordLibrary.bestCapo(listOf("F", "C", "G", "Dm"))
    println("best capo for F C G Dm: $capoF")

    // 3. Note maths
    check("A4 freq", abs(Notes.freq(69.0) - 440.0) < 1e-9)
    check("E2 freq", abs(Notes.freq(40.0) - 82.4069) < 0.001)
    check("cents A4 +", abs(Notes.cents(440.0 * Math.pow(2.0, 10 / 1200.0), 69) - 10.0) < 1e-6)
    check("name E2", Notes.nameOct(40) == "E2")
    check("name C4", Notes.nameOct(60) == "C4")
    for (t in Tunings.ALL) check("${t.name} 6 strings", t.strings.size == 6)
    check("DADGAD", Tunings.ALL.first { it.name == "DADGAD" }.label() == "D A D G A D")
    check("Open G", Tunings.ALL.first { it.name == "Open G" }.label() == "D G D G B D")
    check("Open D", Tunings.ALL.first { it.name == "Open D" }.label() == "D A D F♯ A D")
    check("Half step", Tunings.ALL.first { it.name == "Half step down" }.label() == "D♯ G♯ C♯ F♯ A♯ D♯")

    // 4. Lessons tab accuracy: pentatonic and arpeggio notes
    val pent = Lessons.ALL.first { it.id == 6 }.tab
    for (n in pent) {
        val m = Tunings.noteAt(Tunings.STANDARD, n.string, n.fret)
        check("pentatonic note ${Notes.nameOct(m)}", Scales.contains(Scales.ALL["Minor pentatonic"]!!, 9, m))
    }
    val arp = Lessons.ALL.first { it.id == 5 }.tab
    for (n in arp) {
        val m = Tunings.noteAt(Tunings.STANDARD, n.string, n.fret)
        check("arpeggio note ${Notes.nameOct(m)}", Notes.pc(m) in setOf(9, 0, 4))
    }
    val f = ChordLibrary.byName("F")!!
    check("barre F", f.frets.toList() == listOf(1, 3, 3, 2, 1, 1))
    for (s in Songs.ALL) for (ch in s.chords()) check("song chord parse ${s.title} $ch", ChordLibrary.parse(ch) != null)
    for (s in Songs.ALL) for (ch in s.chords()) check("song chord in library ${s.title} $ch", ChordLibrary.byName(ch) != null)

    // 5. Pitch detection on every open string, every tuning, with slight detune
    val yin = Yin(sr)
    var worst = 0.0
    for (t in Tunings.ALL) for (m in t.strings) for (det in listOf(-20.0, 0.0, 15.0)) {
        val hz = Notes.freq(m + det / 100.0)
        val sig = Synth.pluck(hz, 1.0, sr, 0.3)
        val seg = sig.copyOfRange(sr / 5, sr / 5 + yin.requiredSamples)
        val p = yin.detect(seg)
        if (p == null) { check("pitch ${Notes.nameOct(m)} $det", false, "null"); continue }
        val err = Notes.cents(p.hz, m, 440.0) - det
        worst = maxOf(worst, abs(err))
        check("pitch ${Notes.nameOct(m)} $det", abs(err) < 5.0, "err=$err hz=${p.hz}")
    }
    println("worst pitch error (cents): $worst")
    // pure sine and a noisy signal
    val sine = FloatArray(yin.requiredSamples) { (0.3 * Math.sin(2 * Math.PI * 110.0 * it / sr)).toFloat() }
    check("sine 110", abs(yin.detect(sine)!!.hz - 110.0) < 0.3)
    val rnd = java.util.Random(3)
    val noise = FloatArray(yin.requiredSamples) { (rnd.nextGaussian() * 0.1).toFloat() }
    val np = yin.detect(noise)
    check("noise gives no confident pitch", np == null || np.clarity < 0.9, "$np")
    check("silence gives null", yin.detect(FloatArray(yin.requiredSamples)) == null)
    check("nearest string", Tunings.nearestString(112.0, Tunings.STANDARD) == 1)

    // 6. Chord detection from synthesized strums (open voicings), maj/min/7
    val det = ChordDetector(sr)
    var okCount = 0; var total = 0
    val basic = ChordLibrary.ALL.filter { it.quality in listOf(Quality.MAJ, Quality.MIN, Quality.DOM7) }
    for (c in basic) {
        val sig = Synth.chordAudio(c, seconds = 2.0)
        val seg = sig.copyOfRange(sr / 4, sr / 4 + det.minSamples)
        val ch = det.chroma(seg)
        val r = if (ch == null) null else det.detect(ch)
        total++
        if (r != null && r.root == c.root && r.quality == c.quality) okCount++
        else println("  chord detect miss: ${c.name} -> ${r?.name} (score ${r?.score})")
    }
    println("chord detection (maj/min/7): $okCount / $total")
    check("chord detection >= 90%", okCount.toDouble() / total >= 0.9, "$okCount/$total")
    // with noise on top
    var okNoisy = 0
    for (c in basic) {
        val sig = Synth.chordAudio(c, seconds = 2.0)
        val seg = sig.copyOfRange(sr / 4, sr / 4 + det.minSamples)
        for (i in seg.indices) seg[i] += (rnd.nextGaussian() * 0.01).toFloat()
        val ch = det.chroma(seg); val r = if (ch == null) null else det.detect(ch)
        if (r != null && r.root == c.root && r.quality == c.quality) okNoisy++
    }
    println("chord detection with noise: $okNoisy / $total")
    check("noisy detection >= 85%", okNoisy.toDouble() / total >= 0.85)
    check("quiet input -> null chroma", det.chroma(FloatArray(det.minSamples)) == null)

    // 7. "Check my chord": correct chords pass, a missing string or wrong chord is flagged
    var targetOk = 0; var targetN = 0
    for (c in basic) {
        val sig = Synth.chordAudio(c, seconds = 2.0)
        val r = det.analyze(sig.copyOfRange(sr / 4, sr / 4 + det.minSamples), c)
        targetN++
        if (r != null && r.ok) targetOk++ else println("  rejected correct chord ${c.name}: $r")
    }
    println("check-my-chord accepts correct chords: $targetOk / $targetN")
    check("target accepts >= 95%", targetOk.toDouble() / targetN >= 0.95)
    var flagged = 0; var cases = 0; var named = 0
    for (c in basic) {
        val mids = c.midis()
        val stringIdx = c.frets.indices.filter { c.frets[it] >= 0 }
        for (idx in mids.indices) {
            val partial = FloatArray(sr * 2)
            for ((i, m) in mids.filterIndexed { j, _ -> j != idx }.withIndex()) Synth.mixInto(partial, Synth.pluck(Notes.freq(m.toDouble()), 2.0, sr, 0.22, 11L + m), i * 1500)
            val r = det.analyze(partial.copyOfRange(sr / 4, sr / 4 + det.minSamples), c)
            cases++
            if (r != null && !r.ok) { flagged++; if (stringIdx[idx] in r.missingStrings) named++ }
        }
    }
    println("missing-string cases flagged: $flagged / $cases, correct string named in $named")
    check("missing string flagged >= 65%", flagged.toDouble() / cases >= 0.65, "$flagged/$cases")
    val e = ChordLibrary.byName("E")!!
    val cC = ChordLibrary.byName("C")!!
    val wrong = det.analyze(Synth.chordAudio(cC).copyOfRange(sr / 4, sr / 4 + det.minSamples), e)
    check("wrong chord flagged", wrong != null && !wrong.ok)
    check("quiet input -> null result", det.analyze(FloatArray(det.minSamples), e) == null)

    // 8. Metronome timing
    val mg = MetronomeGenerator(sr); mg.bpm = 120.0; mg.beatsPerBar = 4
    var beats = 0; var accents = 0
    val buf = FloatArray(1024)
    for (i in 0 until (10 * sr / 1024)) mg.fill(buf) { b -> beats++; if (b == 0) accents++ }
    check("metronome beats in ~10s at 120bpm", beats in 19..21, "beats=$beats")
    check("metronome accents every 4th", accents in 4..6, "accents=$accents")

    // 9. FX / jam render sanity
    val riff = Synth.strum(listOf(40, 47, 52), seconds = 1.0)
    val fxOut = Fx.apply(riff, drive = 0.5, delayMix = 0.3, reverbMix = 0.3)
    check("fx longer than input", fxOut.size > riff.size)
    check("fx no NaN/clip", fxOut.all { !it.isNaN() && abs(it) <= 1.0f })
    for (g in Genre.values()) {
        val loop = Jam.render(g, 9, 90)
        check("jam ${g.label} length", abs(loop.size - (4.0 * 60.0 / 90 * sr).toInt() * g.bars) < 1)
        check("jam ${g.label} valid", loop.all { !it.isNaN() && abs(it) <= 1.0f } && loop.any { abs(it) > 0.05f })
    }
    check("voicing range", Synth.voicing(9, Quality.MIN).all { it in 52..63 })
    check("bass range", (0..11).all { Synth.bassNote(it) in 36..47 && Notes.pc(Synth.bassNote(it)) == it })

    println("\n$checks checks, $failures failures")
    if (failures > 0) System.exit(1)
}
