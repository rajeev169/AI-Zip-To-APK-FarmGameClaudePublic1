#!/bin/sh
# Compiles the pure-Kotlin core (tuner, chord detection, synth, theory) and runs 465 automated checks on a PC with kotlinc + Java.
kotlinc ../app/src/main/kotlin/com/appforge/guitarstudio/core/*.kt CoreTests.kt -include-runtime -d core-tests.jar && java -cp core-tests.jar CoreTestsKt
