@file:OptIn(ExperimentalMaterial3Api::class)

package com.appforge.guitarstudio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.guitarstudio.core.MetronomeGenerator
import com.appforge.guitarstudio.core.Notes
import com.appforge.guitarstudio.core.Synth
import com.appforge.guitarstudio.core.Tunings
import com.appforge.guitarstudio.core.Yin
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun TuneScreen(s: Settings) {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    ScreenColumn("Tune & Time") {
        ChipRow(listOf("Tuner", "Metronome"), sub) { sub = it }
        Spacer(Modifier.height(8.dp))
        if (sub == 0) MicGate { TunerView(s) } else MetronomeView()
    }
}

@Composable
fun TunerView(s: Settings) {
    val tuning = Tunings.ALL[s.tuningIdx.coerceIn(0, Tunings.ALL.size - 1)]
    val mic = remember { Mic() }
    val yin = remember { Yin(SR) }
    var manual by remember { mutableStateOf<Int?>(null) }
    var cents by remember { mutableStateOf<Double?>(null) }
    var hz by remember { mutableStateOf<Double?>(null) }
    var stringIdx by remember { mutableIntStateOf(0) }
    var micOk by remember { mutableStateOf(true) }

    DisposableEffect(Unit) {
        micOk = mic.start()
        onDispose { mic.stop() }
    }

    LaunchedEffect(tuning, manual, s.refHz) {
        val history = ArrayList<Double>()
        var misses = 0
        while (true) {
            delay(90)
            val buf = mic.snapshot(yin.requiredSamples)
            val p = if (buf == null) null else withContext(Dispatchers.Default) { yin.detect(buf) }
            if (p != null && p.clarity > 0.85) {
                misses = 0
                val ref = s.refHz.toDouble()
                val idx = manual ?: Tunings.nearestString(p.hz, tuning, ref)
                if (idx != stringIdx) history.clear()
                stringIdx = idx
                history.add(Notes.cents(p.hz, tuning.strings[idx], ref))
                if (history.size > 5) history.removeAt(0)
                cents = history.sorted()[history.size / 2]
                hz = p.hz
            } else {
                misses++
                if (misses > 8) {
                    cents = null
                    hz = null
                    history.clear()
                }
            }
        }
    }

    ChipRow(Tunings.ALL.map { it.name }, s.tuningIdx) { s.tuningIdx = it; manual = null }
    SectionCard(hero = true) {
        val c = cents
        val inTune = c != null && abs(c) <= 5.0
        Text(
            Notes.nameOct(tuning.strings[stringIdx]),
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            fontSize = 72.sp,
            fontWeight = FontWeight.Bold,
            color = if (inTune) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onPrimaryContainer
        )
        CentsGauge(c, inTune)
        Text(
            when {
                !micOk -> "Could not open the microphone"
                c == null -> "Pluck a string"
                inTune -> "In tune"
                c > 0 -> "${c.roundToInt()} cents sharp, loosen the string"
                else -> "${abs(c).roundToInt()} cents flat, tighten the string"
            },
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleMedium
        )
        Text(
            hz?.let { "%.1f Hz".format(it) } ?: "A = ${s.refHz} Hz",
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
    }
    Text("Tap a string to hear it and tune to it. Tap again for automatic mode.", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (i in tuning.strings.indices) {
            val sel = manual == i
            val b = Modifier.weight(1f)
            if (sel) {
                Button(onClick = { manual = null }, modifier = b, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) {
                    Text(Notes.name(tuning.strings[i]))
                }
            } else {
                FilledTonalButton(
                    onClick = {
                        manual = i
                        Player.play(Synth.pluck(Notes.freq(tuning.strings[i].toDouble(), s.refHz.toDouble()), 2.0))
                    },
                    modifier = b,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) { Text(Notes.name(tuning.strings[i])) }
            }
        }
    }
}

@Composable
fun CentsGauge(cents: Double?, inTune: Boolean) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val mark = MaterialTheme.colorScheme.onSurface
    val needle = if (inTune) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
    Canvas(Modifier.fillMaxWidth().height(56.dp)) {
        val y = size.height / 2
        drawRoundRect(track, Offset(0f, y - 8f), Size(size.width, 16f), CornerRadius(8f, 8f))
        drawLine(mark, Offset(size.width / 2, y - 24f), Offset(size.width / 2, y + 24f), strokeWidth = 4f)
        if (cents != null) {
            val c = cents.coerceIn(-50.0, 50.0).toFloat()
            drawCircle(needle, radius = 20f, center = Offset(size.width / 2 + c / 50f * (size.width / 2 - 24f), y))
        }
    }
}

@Composable
fun MetronomeView() {
    var bpm by rememberSaveable { mutableIntStateOf(100) }
    var beats by rememberSaveable { mutableIntStateOf(4) }
    var running by remember { mutableStateOf(false) }
    var current by remember { mutableIntStateOf(-1) }
    val gen = remember { MetronomeGenerator(SR) }
    val player = remember { ClickPlayer() }
    val taps = remember { ArrayList<Long>() }
    gen.bpm = bpm.toDouble()
    gen.beatsPerBar = beats
    DisposableEffect(Unit) { onDispose { player.stop() } }

    fun tap() {
        val now = System.nanoTime()
        if (taps.isNotEmpty() && now - taps[taps.size - 1] > 2_000_000_000L) taps.clear()
        taps.add(now)
        while (taps.size > 5) taps.removeAt(0)
        if (taps.size >= 2) {
            val avg = (taps[taps.size - 1] - taps[0]).toDouble() / (taps.size - 1) / 1e9
            bpm = (60.0 / avg).roundToInt().coerceIn(30, 240)
        }
    }

    SectionCard(hero = true) {
        Text("$bpm", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 80.sp, fontWeight = FontWeight.Bold)
        Text("beats per minute", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            for (i in 0 until beats) {
                Box(
                    Modifier
                        .padding(horizontal = 6.dp)
                        .size(if (running && current == i) 26.dp else 20.dp)
                        .clip(CircleShape)
                        .background(if (running && current == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(onClick = { bpm = (bpm - 1).coerceAtLeast(30) }) { Text("−") }
            Button(onClick = {
                if (running) { player.stop(); running = false; current = -1 }
                else { player.start(gen) { b -> current = b }; running = true }
            }) { Text(if (running) "Stop" else "Start") }
            FilledTonalButton(onClick = { bpm = (bpm + 1).coerceAtMost(240) }) { Text("+") }
        }
    }
    androidx.compose.material3.Slider(value = bpm.toFloat(), onValueChange = { bpm = it.roundToInt() }, valueRange = 30f..240f)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { tap() }) { Text("Tap tempo") }
        Text("Beats per bar:")
    }
    ChipRow(listOf("2", "3", "4", "5", "6"), beats - 2) { beats = it + 2 }
}
