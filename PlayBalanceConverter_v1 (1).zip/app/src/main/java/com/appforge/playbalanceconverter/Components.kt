package com.appforge.playbalanceconverter

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Chunky(
    onClick: () -> Unit,
    color: Color,
    edge: Color,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    outline: Color = Color.Black,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(12.dp)
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val dy by animateDpAsState(if (pressed) 2.dp else 0.dp, label = "press")
    Box(modifier.padding(bottom = 3.dp)) {
        Box(
            Modifier
                .matchParentSize()
                .offset(y = 3.dp)
                .background(edge, shape),
        )
        Box(
            Modifier
                .offset(y = dy)
                .fillMaxWidth()
                .clip(shape)
                .background(color)
                .then(if (selected) Modifier.border(2.dp, outline, shape) else Modifier)
                .clickable(interactionSource = source, indication = null, onClick = onClick),
            content = content,
        )
    }
}

@Composable
fun NoticeBox(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .padding(12.dp),
    ) {
        Text(text, color = fg, fontSize = 13.sp, lineHeight = 19.sp)
    }
}

@Composable
fun StatusPill(label: String) {
    val (bg, fg) = when (label) {
        "Pending" -> Pal.Amber100 to Pal.Amber900
        "Rejected" -> Pal.Red100 to Pal.Red900
        else -> Pal.Green100 to Pal.Teal900
    }
    Text(
        label,
        color = fg,
        fontSize = 12.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 3.dp),
    )
}
