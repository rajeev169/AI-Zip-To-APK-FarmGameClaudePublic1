# Play Balance Converter: setup (package com.appforge.playbalanceconverter)

IMPORTANT: this project was written and statically checked, but NOT compiled
(the build sandbox could not reach Google Maven / Gradle). Build it through your
GitHub pipeline first and send any errors back.

## 1. Firebase
1. Create a new Firebase project, add an Android app with package `com.appforge.playbalanceconverter`.
2. Add the SHA-1 of your AppForge upload key (and the Play app-signing SHA-1 later).
3. Authentication > Sign-in method > enable Google.
4. Download `google-services.json` and REPLACE `app/google-services.json`
   (the file in the zip is a placeholder; sign-in will not work until replaced).
5. Create a Firestore database, then paste `firestore.rules` into Rules and publish.

## 2. Firestore documents
- `config/app`: purchasesEnabled=false (boolean), packs=[50,100,200,500] (array of numbers),
  customMin=10, customMax=1000, holdDays=7, coinPercent=60 (numbers).
- `admins/<your Firebase uid>`: any field (e.g. a=1). Find your uid in Authentication > Users.

## 3. Google Play Console
- Billing only works for an app installed from Play (internal testing track) by a
  license tester. A sideloaded APK cannot buy.
- Create one in-app product per price: `coins_10`, `coins_20` ... `coins_1000`
  (100 products, listed in `play-products.csv`), each priced at that many INR.
  Custom amounts in the app only allow multiples of 10 for this reason.
- Coins = amount x coinPercent / 100 (rounded down). Coins are consumed after crediting.

## 4. Keep it switched off
`purchasesEnabled` is false, so normal users see "Not available yet". Admins can still
open everything to test. Turn it on from the Admin screen only after Google Play Support
confirms in writing that cash-out of purchased coins is allowed.

## 5. Known limits (v1)
- No server-side purchase verification. The app credits coins itself and users could tamper
  with their own balance. Control: payouts are manual. Use "Show purchase orders" on each
  payout request and check the order IDs in Play Console before you pay.
- If Google refunds an order, you must handle the clawback yourself.
- Add a privacy policy and fill in the Data safety form before publishing.
