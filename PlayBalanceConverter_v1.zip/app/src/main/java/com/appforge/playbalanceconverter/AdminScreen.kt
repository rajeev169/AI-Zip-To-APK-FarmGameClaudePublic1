package com.appforge.playbalanceconverter

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun day(ts: Long): String =
    SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(ts))

@Composable
fun AdminScreen(ui: UiState, vm: AppViewModel) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Pal.Amber100)
                    .padding(12.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Buying and redeeming open for users",
                        modifier = Modifier.weight(1f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = Pal.Amber900,
                    )
                    Switch(checked = ui.config.purchasesEnabled, onCheckedChange = { vm.setEnabled(it) })
                }
                Text(
                    "Keep this off until Google Play Support confirms in writing that cashing out purchased coins is allowed. Admins can always use the app.",
                    fontSize = 12.sp,
                    color = Pal.Amber900,
                )
            }
        }
        item {
            Text("Payout requests", fontSize = 13.sp, color = Pal.Purple600)
        }
        if (ui.adminPayouts.isEmpty()) {
            item { Text("No requests yet", color = Pal.Purple600) }
        }
        items(ui.adminPayouts, key = { it.id }) { p -> PayoutCard(p, vm) }
    }
}

@Composable
private fun PayoutCard(p: PayoutItem, vm: AppViewModel) {
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    var orders by remember(p.id) { mutableStateOf<List<PurchaseItem>?>(null) }
    val now = System.currentTimeMillis()
    val holdOver = now >= p.holdUntil
    val pending = p.status == "pending"

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Pal.Purple50)
            .border(0.5.dp, Pal.Purple200, RoundedCornerShape(10.dp))
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.email, fontSize = 14.sp, color = Pal.Purple900)
                Text("₹${p.coins} (${p.coins} coins)", fontSize = 13.sp, color = Pal.Purple600)
            }
            StatusPill(statusLabel(p.status))
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("UPI: ${p.upi}", fontSize = 13.sp, color = Pal.Purple900, modifier = Modifier.weight(1f))
            IconButton(onClick = { clipboard.setText(AnnotatedString(p.upi)) }) {
                Icon(Icons.Filled.ContentCopy, contentDescription = "Copy UPI ID", tint = Pal.Purple600)
            }
        }
        Text("Requested ${day(p.createdAt)} · hold ends ${day(p.holdUntil)}", fontSize = 12.sp, color = Pal.Purple600)
        if (pending) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.markPaid(p.id) }, enabled = holdOver) {
                    Text(if (holdOver) "Mark paid" else "Hold until ${day(p.holdUntil)}")
                }
                OutlinedButton(onClick = { vm.reject(p.id) }) { Text("Reject and refund") }
            }
        }
        TextButton(onClick = {
            scope.launch {
                orders = try {
                    Repo.userPurchasesOnce(p.uid)
                } catch (e: Exception) {
                    emptyList()
                }
            }
        }) { Text("Show purchase orders") }
        orders?.let { list ->
            if (list.isEmpty()) {
                Text("No purchases found", fontSize = 12.sp, color = Pal.Purple600)
            }
            list.forEach { o ->
                Text(
                    "${o.orderId} · ₹${o.amount} · ${day(o.ts)}",
                    fontSize = 12.sp,
                    color = Pal.Purple900,
                )
            }
        }
    }
}
