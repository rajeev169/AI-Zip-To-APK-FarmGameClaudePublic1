package com.appforge.playbalanceconverter

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

@Composable
fun AppRoot(vm: AppViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    if (!ui.ready) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }
    if (!ui.signedIn) {
        SignInScreen(ui, vm)
        return
    }
    MainScaffold(ui, vm)
}

@Composable
fun SignInScreen(ui: UiState, vm: AppViewModel) {
    val activity = LocalContext.current as Activity
    Column(
        Modifier
            .fillMaxSize()
            .background(Pal.Purple400)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(Pal.Amber200),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.MonetizationOn, contentDescription = null, tint = Pal.Amber900, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("Play Balance Converter", color = Color.White, fontSize = 26.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        Text(
            "Buy coins with your Google Play balance and cash them out to UPI.",
            color = Pal.Purple50,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(28.dp))
        Chunky(
            onClick = { vm.signIn(activity) },
            color = Color.White,
            edge = Pal.Purple200,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(
                if (ui.busy) "Signing in…" else "Continue with Google",
                color = Pal.Purple900,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(16.dp),
            )
        }
        ui.message?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "Not affiliated with Google. Google Play is a trademark of Google LLC.",
            color = Pal.Purple50,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun WalletHeader(coins: Long, onMenu: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Pal.Purple400)
            .statusBarsPadding()
            .padding(start = 8.dp, end = 16.dp, top = 6.dp, bottom = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMenu) {
                Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text("Purchased coins", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("Separate from any other coins", color = Pal.Purple50, fontSize = 12.sp)
            }
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Pal.Amber200),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.MonetizationOn, contentDescription = null, tint = Pal.Amber900)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 8.dp)
                .shadow(3.dp, RoundedCornerShape(12.dp))
                .background(Color.White, RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("Your balance", color = Pal.Purple600, fontSize = 12.sp)
                Text("$coins coins", color = Pal.Purple900, fontSize = 24.sp, fontWeight = FontWeight.Medium)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Cash value", color = Pal.Purple600, fontSize = 12.sp)
                Text("₹$coins", color = Pal.Teal600, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun MainScaffold(ui: UiState, vm: AppViewModel) {
    val activity = LocalContext.current as Activity
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var screen by rememberSaveable { mutableStateOf("buy") }
    val snack = remember { SnackbarHostState() }

    LaunchedEffect(ui.message) {
        ui.message?.let {
            snack.showSnackbar(it)
            vm.clearMessage()
        }
    }

    val open = ui.config.purchasesEnabled || ui.isAdmin

    fun go(s: String) {
        screen = s
        scope.launch { drawer.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 24.dp)) {
                    Text("Play Balance Converter", fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Pal.Purple900)
                    Text(ui.email, fontSize = 13.sp, color = Pal.Purple600)
                }
                NavigationDrawerItem(
                    label = { Text("Buy coins") },
                    icon = { Icon(Icons.Filled.ShoppingCart, null) },
                    selected = screen == "buy",
                    onClick = { go("buy") },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                NavigationDrawerItem(
                    label = { Text("Redeem") },
                    icon = { Icon(Icons.Filled.Payments, null) },
                    selected = screen == "redeem",
                    onClick = { go("redeem") },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                NavigationDrawerItem(
                    label = { Text("History") },
                    icon = { Icon(Icons.Filled.History, null) },
                    selected = screen == "history",
                    onClick = { go("history") },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                NavigationDrawerItem(
                    label = { Text("Settings") },
                    icon = { Icon(Icons.Filled.Settings, null) },
                    selected = screen == "settings",
                    onClick = { go("settings") },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                if (ui.isAdmin) {
                    NavigationDrawerItem(
                        label = { Text("Admin") },
                        icon = { Icon(Icons.Filled.AdminPanelSettings, null) },
                        selected = screen == "admin",
                        onClick = { go("admin") },
                        modifier = Modifier.padding(horizontal = 12.dp),
                    )
                }
                NavigationDrawerItem(
                    label = { Text("Sign out") },
                    icon = { Icon(Icons.AutoMirrored.Filled.ExitToApp, null) },
                    selected = false,
                    onClick = { vm.signOut(activity) },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
            }
        },
    ) {
        Scaffold(
            topBar = { WalletHeader(ui.coins) { scope.launch { drawer.open() } } },
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = screen == "buy",
                        onClick = { screen = "buy" },
                        icon = { Icon(Icons.Filled.ShoppingCart, null) },
                        label = { Text("Buy") },
                    )
                    NavigationBarItem(
                        selected = screen == "redeem",
                        onClick = { screen = "redeem" },
                        icon = { Icon(Icons.Filled.Payments, null) },
                        label = { Text("Redeem") },
                    )
                    NavigationBarItem(
                        selected = screen == "history",
                        onClick = { screen = "history" },
                        icon = { Icon(Icons.Filled.History, null) },
                        label = { Text("History") },
                    )
                }
            },
        ) { pad ->
            Box(
                Modifier
                    .padding(pad)
                    .fillMaxSize(),
            ) {
                when (screen) {
                    "buy" -> if (open) BuyScreen(ui) { amount -> vm.buy(activity, amount) } else ComingSoon()
                    "redeem" -> if (open) RedeemScreen(ui) { coins, upi -> vm.requestPayout(coins, upi) } else ComingSoon()
                    "history" -> HistoryScreen(ui)
                    "settings" -> SettingsScreen(ui) { vm.signOut(activity) }
                    "admin" -> if (ui.isAdmin) AdminScreen(ui, vm) else ComingSoon()
                    else -> ComingSoon()
                }
            }
        }
    }
}

@Composable
fun ComingSoon() {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Not available yet", fontSize = 18.sp, fontWeight = FontWeight.Medium, color = Pal.Purple900)
            Spacer(Modifier.height(6.dp))
            Text(
                "Buying and redeeming coins will open soon.",
                fontSize = 14.sp,
                color = Pal.Purple600,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
fun SettingsScreen(ui: UiState, onSignOut: () -> Unit) {
    val context = LocalContext.current
    val version = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }
    val p = ui.config.coinPercent
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        Text("Account", fontSize = 13.sp, color = Pal.Purple600)
        Spacer(Modifier.height(6.dp))
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Pal.Purple50)
                .padding(12.dp),
        ) {
            if (ui.name.isNotEmpty()) Text(ui.name, fontSize = 15.sp, color = Pal.Purple900)
            Text(ui.email, fontSize = 13.sp, color = Pal.Purple600)
        }
        Spacer(Modifier.height(16.dp))
        Text("How it works", fontSize = 13.sp, color = Pal.Purple600)
        Spacer(Modifier.height(6.dp))
        NoticeBox(
            text = "You pay through Google Play and get $p% of the amount as coins. " +
                "Coins can be redeemed to UPI cash at 1 coin = ₹1. " +
                "Payouts are held ${ui.config.holdDays} days and approved by the admin. " +
                "Coins bought here can only be cashed out.",
            bg = Pal.Purple50,
            fg = Pal.Purple900,
        )
        Spacer(Modifier.height(16.dp))
        Text("About", fontSize = 13.sp, color = Pal.Purple600)
        Spacer(Modifier.height(6.dp))
        Text("Version $version", fontSize = 14.sp, color = Pal.Purple900)
        Text(
            "Not affiliated with Google. Google Play is a trademark of Google LLC.",
            fontSize = 12.sp,
            color = Pal.Purple600,
        )
        Spacer(Modifier.height(20.dp))
        Chunky(
            onClick = onSignOut,
            color = Pal.Purple400,
            edge = Pal.Purple600,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(
                "Sign out",
                color = Color.White,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(14.dp),
            )
        }
    }
}
