package com.appforge.playbalanceconverter

import android.app.Activity
import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.android.billingclient.api.Purchase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var dataJob: Job? = null

    private val billing = BillingManager(
        context = app,
        scope = viewModelScope,
        onPurchased = { p -> credit(p) },
        onMessage = { m -> say(m) },
    )

    private val authListener = FirebaseAuth.AuthStateListener { a -> onUser(a.currentUser) }

    init {
        FirebaseAuth.getInstance().addAuthStateListener(authListener)
    }

    override fun onCleared() {
        FirebaseAuth.getInstance().removeAuthStateListener(authListener)
        super.onCleared()
    }

    private fun say(m: String?) {
        _ui.update { it.copy(message = m) }
    }

    fun clearMessage() = say(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun onUser(user: FirebaseUser?) {
        dataJob?.cancel()
        if (user == null) {
            _ui.value = UiState(ready = true)
            return
        }
        _ui.update {
            it.copy(
                ready = true,
                signedIn = true,
                uid = user.uid,
                email = user.email ?: "",
                name = user.displayName ?: "",
            )
        }
        dataJob = viewModelScope.launch {
            try {
                Repo.ensureUser(user)
            } catch (e: Exception) {
                say("Couldn't set up your account. Check your connection.")
            }
            billing.restore()
            launch {
                Repo.userCoins(user.uid).catch { }.collect { c -> _ui.update { it.copy(coins = c) } }
            }
            launch {
                Repo.config().collect { c -> _ui.update { it.copy(config = c) } }
            }
            launch {
                Repo.isAdmin(user.uid).collect { a -> _ui.update { it.copy(isAdmin = a) } }
            }
            launch {
                combine(Repo.purchases(user.uid), Repo.userPayouts(user.uid)) { a, b -> rows(a, b) }
                    .catch { }
                    .collect { r -> _ui.update { it.copy(history = r) } }
            }
            launch {
                Repo.isAdmin(user.uid)
                    .flatMapLatest { admin ->
                        if (admin) Repo.allPayouts() else flowOf(emptyList<PayoutItem>())
                    }
                    .catch { }
                    .collect { l -> _ui.update { it.copy(adminPayouts = l) } }
            }
        }
    }

    private fun rows(a: List<PurchaseItem>, b: List<PayoutItem>): List<HistoryRow> {
        val bought = a.map { HistoryRow("Bought ₹${it.amount}", "+${it.coins} coins", "Done", it.ts) }
        val payouts = b.map {
            HistoryRow("Payout to ${it.upi}", "−${it.coins} coins · ₹${it.coins}", statusLabel(it.status), it.createdAt)
        }
        return (bought + payouts).sortedByDescending { it.ts }
    }

    private suspend fun credit(p: Purchase) {
        val s = _ui.value
        val pid = p.products.firstOrNull() ?: throw IllegalStateException("Unknown product")
        val amount = pid.removePrefix("coins_").toIntOrNull() ?: throw IllegalStateException("Unknown product")
        val percent = s.config.coinPercent
        val coins = coinsFor(amount, percent)
        val orderId = p.orderId ?: ("T" + p.purchaseToken.hashCode().toString().replace("-", "n"))
        val created = Repo.creditPurchase(s.uid, orderId, pid, amount, coins, percent, p.purchaseToken)
        if (created) say("$coins coins added to your balance")
    }

    fun signIn(activity: Activity) {
        if (_ui.value.busy) return
        viewModelScope.launch {
            _ui.update { it.copy(busy = true, message = null) }
            try {
                Auth.signIn(activity)
            } catch (e: Exception) {
                say("Sign-in didn't finish. Please try again.")
            }
            _ui.update { it.copy(busy = false) }
        }
    }

    fun signOut(context: Context) {
        viewModelScope.launch { Auth.signOut(context) }
    }

    fun buy(activity: Activity, amount: Int) {
        val s = _ui.value
        val c = s.config
        val ok = (amount in c.customMin..c.customMax && amount % 10 == 0) || amount in c.packs
        if (!ok) {
            say("That amount isn't available")
            return
        }
        billing.buy(activity, productIdFor(amount), s.uid)
    }

    fun requestPayout(coins: Long, upi: String) {
        val s = _ui.value
        viewModelScope.launch {
            try {
                Repo.requestPayout(s.uid, s.email, upi, coins, s.config.holdDays)
                say("Request sent. It shows as Pending in History.")
            } catch (e: Exception) {
                say(e.message ?: "Couldn't send the request")
            }
        }
    }

    fun markPaid(id: String) {
        viewModelScope.launch {
            try {
                Repo.markPaid(id)
            } catch (e: Exception) {
                say(e.message ?: "Couldn't update")
            }
        }
    }

    fun reject(id: String) {
        viewModelScope.launch {
            try {
                Repo.rejectPayout(id)
            } catch (e: Exception) {
                say(e.message ?: "Couldn't update")
            }
        }
    }

    fun setEnabled(enabled: Boolean) {
        viewModelScope.launch {
            try {
                Repo.setPurchasesEnabled(enabled)
            } catch (e: Exception) {
                say(e.message ?: "Couldn't update")
            }
        }
    }
}
