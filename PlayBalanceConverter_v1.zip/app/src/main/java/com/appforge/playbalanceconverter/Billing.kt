package com.appforge.playbalanceconverter

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class BillingManager(
    context: Context,
    private val scope: CoroutineScope,
    private val onPurchased: suspend (Purchase) -> Unit,
    private val onMessage: (String) -> Unit,
) {
    private val client: BillingClient = BillingClient.newBuilder(context.applicationContext)
        .setListener(PurchasesUpdatedListener { result, purchases -> onUpdated(result, purchases) })
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    private fun onUpdated(result: BillingResult, purchases: List<Purchase>?) {
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> if (purchases != null) handle(purchases)
            BillingClient.BillingResponseCode.USER_CANCELED -> onMessage("Payment cancelled")
            else -> onMessage("Payment failed (code ${result.responseCode})")
        }
    }

    private suspend fun ensureReady(): Boolean {
        if (client.isReady) return true
        return suspendCancellableCoroutine { cont ->
            client.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(result: BillingResult) {
                    if (cont.isActive) cont.resume(result.responseCode == BillingClient.BillingResponseCode.OK)
                }

                override fun onBillingServiceDisconnected() {}
            })
        }
    }

    private suspend fun details(productId: String): ProductDetails? {
        if (!ensureReady()) return null
        val product = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(productId)
            .setProductType(BillingClient.ProductType.INAPP)
            .build()
        val params = QueryProductDetailsParams.newBuilder().setProductList(listOf(product)).build()
        return client.queryProductDetails(params).productDetailsList?.firstOrNull()
    }

    fun buy(activity: Activity, productId: String, uid: String) {
        scope.launch {
            val d = details(productId)
            if (d == null) {
                onMessage("This amount isn't available yet. Try another one.")
                return@launch
            }
            val pdp = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).build()
            val flow = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(listOf(pdp))
                .setObfuscatedAccountId(uid)
                .build()
            val r = client.launchBillingFlow(activity, flow)
            if (r.responseCode != BillingClient.BillingResponseCode.OK) {
                onMessage("Couldn't start payment (code ${r.responseCode})")
            }
        }
    }

    fun restore() {
        scope.launch {
            if (!ensureReady()) return@launch
            val res = client.queryPurchasesAsync(
                QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build(),
            )
            if (res.billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                handle(res.purchasesList)
            }
        }
    }

    private fun handle(list: List<Purchase>) {
        scope.launch {
            for (p in list) {
                when (p.purchaseState) {
                    Purchase.PurchaseState.PURCHASED -> {
                        try {
                            onPurchased(p)
                            client.consumePurchase(ConsumeParams.newBuilder().setPurchaseToken(p.purchaseToken).build())
                        } catch (e: Exception) {
                            onMessage("Couldn't add coins yet. They will be added when you reopen the app.")
                        }
                    }
                    Purchase.PurchaseState.PENDING ->
                        onMessage("Payment is pending. Coins are added when it completes.")
                    else -> {}
                }
            }
        }
    }
}
