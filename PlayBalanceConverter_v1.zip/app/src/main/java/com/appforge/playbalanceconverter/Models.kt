package com.appforge.playbalanceconverter

const val DAY_MS = 24L * 60L * 60L * 1000L

data class AppConfig(
    val purchasesEnabled: Boolean = false,
    val packs: List<Int> = listOf(50, 100, 200, 500),
    val customMin: Int = 10,
    val customMax: Int = 1000,
    val holdDays: Int = 7,
    val coinPercent: Int = 60,
)

data class PurchaseItem(
    val orderId: String,
    val productId: String,
    val amount: Int,
    val coins: Long,
    val ts: Long,
)

data class PayoutItem(
    val id: String,
    val uid: String,
    val email: String,
    val upi: String,
    val coins: Long,
    val status: String,
    val createdAt: Long,
    val holdUntil: Long,
)

data class HistoryRow(
    val title: String,
    val detail: String,
    val status: String,
    val ts: Long,
)

data class UiState(
    val ready: Boolean = false,
    val signedIn: Boolean = false,
    val uid: String = "",
    val email: String = "",
    val name: String = "",
    val coins: Long = 0L,
    val config: AppConfig = AppConfig(),
    val isAdmin: Boolean = false,
    val history: List<HistoryRow> = emptyList(),
    val adminPayouts: List<PayoutItem> = emptyList(),
    val busy: Boolean = false,
    val message: String? = null,
)

fun coinsFor(amount: Int, percent: Int): Long = (amount.toLong() * percent.toLong()) / 100L

fun productIdFor(amount: Int): String = "coins_$amount"

fun statusLabel(status: String): String = when (status) {
    "pending" -> "Pending"
    "paid" -> "Paid"
    "rejected" -> "Rejected"
    else -> status
}
