package com.appforge.playbalanceconverter

import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Transaction
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

object Repo {
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    private fun userRef(uid: String) = db.collection("users").document(uid)

    suspend fun ensureUser(user: FirebaseUser) {
        val ref = userRef(user.uid)
        db.runTransaction(Transaction.Function<Any?> { tr ->
            val snap = tr.get(ref)
            if (!snap.exists()) {
                tr.set(
                    ref,
                    hashMapOf<String, Any>(
                        "email" to (user.email ?: ""),
                        "name" to (user.displayName ?: ""),
                        "coins" to 0L,
                        "createdAt" to System.currentTimeMillis(),
                    ),
                )
            }
            null
        }).await()
    }

    fun userCoins(uid: String): Flow<Long> = callbackFlow {
        val reg = userRef(uid).addSnapshotListener { s, e ->
            if (e != null) {
                close(e)
                return@addSnapshotListener
            }
            trySend(s?.getLong("coins") ?: 0L)
        }
        awaitClose { reg.remove() }
    }

    fun config(): Flow<AppConfig> = callbackFlow {
        val reg = db.collection("config").document("app").addSnapshotListener { s, e ->
            val d = AppConfig()
            if (e != null || s == null || !s.exists()) {
                trySend(d)
                return@addSnapshotListener
            }
            val packs = (s.get("packs") as? List<*>)?.mapNotNull { (it as? Number)?.toInt() } ?: d.packs
            trySend(
                AppConfig(
                    purchasesEnabled = s.getBoolean("purchasesEnabled") ?: false,
                    packs = if (packs.isEmpty()) d.packs else packs,
                    customMin = s.getLong("customMin")?.toInt() ?: d.customMin,
                    customMax = s.getLong("customMax")?.toInt() ?: d.customMax,
                    holdDays = s.getLong("holdDays")?.toInt() ?: d.holdDays,
                    coinPercent = s.getLong("coinPercent")?.toInt() ?: d.coinPercent,
                ),
            )
        }
        awaitClose { reg.remove() }
    }

    fun isAdmin(uid: String): Flow<Boolean> = callbackFlow {
        val reg = db.collection("admins").document(uid).addSnapshotListener { s, e ->
            if (e != null) {
                trySend(false)
                return@addSnapshotListener
            }
            trySend(s?.exists() == true)
        }
        awaitClose { reg.remove() }
    }

    private fun toPurchase(d: DocumentSnapshot) = PurchaseItem(
        orderId = d.id,
        productId = d.getString("productId") ?: "",
        amount = (d.getLong("amount") ?: 0L).toInt(),
        coins = d.getLong("coins") ?: 0L,
        ts = d.getLong("ts") ?: 0L,
    )

    private fun toPayout(d: DocumentSnapshot) = PayoutItem(
        id = d.id,
        uid = d.getString("uid") ?: "",
        email = d.getString("email") ?: "",
        upi = d.getString("upi") ?: "",
        coins = d.getLong("coins") ?: 0L,
        status = d.getString("status") ?: "pending",
        createdAt = d.getLong("createdAt") ?: 0L,
        holdUntil = d.getLong("holdUntil") ?: 0L,
    )

    fun purchases(uid: String): Flow<List<PurchaseItem>> = callbackFlow {
        val reg = userRef(uid).collection("purchases")
            .orderBy("ts", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { s, e ->
                if (e != null) {
                    close(e)
                    return@addSnapshotListener
                }
                trySend(s?.documents?.map { toPurchase(it) } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun userPayouts(uid: String): Flow<List<PayoutItem>> = callbackFlow {
        val reg = db.collection("payouts").whereEqualTo("uid", uid)
            .addSnapshotListener { s, e ->
                if (e != null) {
                    close(e)
                    return@addSnapshotListener
                }
                trySend(s?.documents?.map { toPayout(it) } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun allPayouts(): Flow<List<PayoutItem>> = callbackFlow {
        val reg = db.collection("payouts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(200)
            .addSnapshotListener { s, e ->
                if (e != null) {
                    close(e)
                    return@addSnapshotListener
                }
                trySend(s?.documents?.map { toPayout(it) } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    suspend fun userPurchasesOnce(uid: String): List<PurchaseItem> =
        userRef(uid).collection("purchases")
            .orderBy("ts", Query.Direction.DESCENDING)
            .get().await().documents.map { toPurchase(it) }

    suspend fun creditPurchase(
        uid: String,
        orderId: String,
        productId: String,
        amount: Int,
        coins: Long,
        percent: Int,
        token: String,
    ): Boolean {
        val user = userRef(uid)
        val pRef = user.collection("purchases").document(orderId)
        var created = false
        db.runTransaction(Transaction.Function<Any?> { tr ->
            val snap = tr.get(pRef)
            if (!snap.exists()) {
                tr.set(
                    pRef,
                    hashMapOf<String, Any>(
                        "productId" to productId,
                        "amount" to amount,
                        "coins" to coins,
                        "percent" to percent,
                        "token" to token,
                        "ts" to System.currentTimeMillis(),
                    ),
                )
                tr.update(user, "coins", FieldValue.increment(coins))
                created = true
            }
            null
        }).await()
        return created
    }

    suspend fun requestPayout(uid: String, email: String, upi: String, coins: Long, holdDays: Int) {
        val user = userRef(uid)
        val pRef = db.collection("payouts").document()
        val now = System.currentTimeMillis()
        db.runTransaction(Transaction.Function<Any?> { tr ->
            val snap = tr.get(user)
            val have = snap.getLong("coins") ?: 0L
            if (coins <= 0L || have < coins) {
                throw FirebaseFirestoreException("Not enough coins", FirebaseFirestoreException.Code.ABORTED)
            }
            tr.update(user, "coins", FieldValue.increment(-coins))
            tr.set(
                pRef,
                hashMapOf<String, Any>(
                    "uid" to uid,
                    "email" to email,
                    "upi" to upi,
                    "coins" to coins,
                    "status" to "pending",
                    "createdAt" to now,
                    "holdUntil" to now + holdDays.toLong() * DAY_MS,
                ),
            )
            null
        }).await()
    }

    suspend fun markPaid(id: String) {
        db.collection("payouts").document(id)
            .update(mapOf<String, Any>("status" to "paid", "paidAt" to System.currentTimeMillis()))
            .await()
    }

    suspend fun rejectPayout(id: String) {
        val ref = db.collection("payouts").document(id)
        db.runTransaction(Transaction.Function<Any?> { tr ->
            val snap = tr.get(ref)
            if (snap.getString("status") == "pending") {
                val uid = snap.getString("uid") ?: ""
                val coins = snap.getLong("coins") ?: 0L
                tr.update(ref, mapOf<String, Any>("status" to "rejected", "closedAt" to System.currentTimeMillis()))
                tr.update(userRef(uid), "coins", FieldValue.increment(coins))
            }
            null
        }).await()
    }

    suspend fun setPurchasesEnabled(enabled: Boolean) {
        db.collection("config").document("app")
            .set(mapOf<String, Any>("purchasesEnabled" to enabled), SetOptions.merge())
            .await()
    }
}
