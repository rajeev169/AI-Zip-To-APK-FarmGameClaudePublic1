package com.appforge.playbalanceconverter

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color

private val UPI_REGEX = Regex("^[\\w.\\-]{2,}@[\\w]{2,}$")

@Composable
fun BuyScreen(ui: UiState, onBuy: (Int) -> Unit) {
    val c = ui.config
    val p = c.coinPercent
    var selected by rememberSaveable { mutableIntStateOf(c.packs.getOrNull(1) ?: c.packs.firstOrNull() ?: 0) }
    var custom by rememberSaveable { mutableStateOf("") }
    var agreed by rememberSaveable { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    val customAmount = custom.toIntOrNull()?.takeIf { it in c.customMin..c.customMax && it % 10 == 0 }
    val customBad = custom.isNotEmpty() && customAmount == null
    val amount = if (custom.isNotEmpty()) (customAmount ?: 0) else selected
    val coins = coinsFor(amount, p)
    val colors = listOf(
        Triple(Pal.Teal200, Pal.Teal400, Pal.Teal900),
        Triple(Pal.Purple200, Pal.Purple400, Pal.Purple900),
        Triple(Pal.Coral200, Pal.Coral400, Pal.Coral900),
        Triple(Pal.Amber200, Pal.Amber400, Pal.Amber900),
    )

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        NoticeBox(
            text = "You get $p% of what you pay. Pay ₹100 and you get ${coinsFor(100, p)} coins, " +
                "worth ₹${coinsFor(100, p)} cash. The other ${100 - p}% is the service fee.",
            bg = Pal.Amber100,
            fg = Pal.Amber900,
        )
        Spacer(Modifier.height(14.dp))
        Text("Choose a pack", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        c.packs.chunked(2).forEachIndexed { rowIndex, row ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                row.forEachIndexed { i, a ->
                    val col = colors[(rowIndex * 2 + i) % colors.size]
                    Chunky(
                        onClick = {
                            selected = a
                            custom = ""
                            error = ""
                        },
                        color = col.first,
                        edge = col.second,
                        modifier = Modifier.weight(1f),
                        selected = custom.isEmpty() && selected == a,
                        outline = col.third,
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text("₹$a", color = col.third, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            Text("${coinsFor(a, p)} coins", color = col.third, fontSize = 13.sp)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Or enter your own amount (₹${c.customMin} to ₹${c.customMax}, in steps of ₹10)",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = custom,
            onValueChange = {
                custom = it.filter { ch -> ch.isDigit() }.take(5)
                error = ""
            },
            prefix = { Text("₹") },
            placeholder = { Text("250") },
            singleLine = true,
            isError = customBad,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
        )
        if (customBad) {
            Text(
                "Enter an amount in steps of ₹10, from ₹${c.customMin} to ₹${c.customMax}",
                color = Pal.Danger,
                fontSize = 13.sp,
            )
        }
        Spacer(Modifier.height(12.dp))
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Pal.Purple50)
                .border(0.5.dp, Pal.Purple200, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            SummaryRow("You pay", "₹$amount")
            SummaryRow("You get", "$coins coins")
            SummaryRow("Cash you can redeem", "₹$coins", Pal.Teal600)
        }
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clickable {
                    agreed = !agreed
                    error = ""
                },
            verticalAlignment = Alignment.Top,
        ) {
            Checkbox(checked = agreed, onCheckedChange = {
                agreed = it
                error = ""
            })
            Text(
                "I understand I get $p% of what I pay, and these coins can only be cashed out.",
                fontSize = 13.sp,
                lineHeight = 19.sp,
                modifier = Modifier.padding(top = 12.dp),
            )
        }
        if (error.isNotEmpty()) Text(error, color = Pal.Danger, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Chunky(
            onClick = {
                if (amount <= 0) {
                    error = "Enter a valid amount or choose a pack"
                } else if (!agreed) {
                    error = "Tick the box to continue"
                } else {
                    error = ""
                    agreed = false
                    onBuy(amount)
                }
            },
            color = Pal.Teal400,
            edge = Pal.Teal600,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(
                "Buy with Google Play",
                color = Pal.Teal900,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(14.dp),
            )
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String, valueColor: Color = Pal.Purple900) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 13.sp, color = Pal.Purple600)
        Text(value, fontSize = 13.sp, color = valueColor, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun RedeemScreen(ui: UiState, onRequest: (Long, String) -> Unit) {
    val c = ui.config
    var coinsText by rememberSaveable { mutableStateOf("") }
    var upi by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val coins = coinsText.toLongOrNull() ?: 0L

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        Text("Coins to redeem", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = coinsText,
            onValueChange = {
                coinsText = it.filter { ch -> ch.isDigit() }.take(7)
                error = ""
            },
            placeholder = { Text("60") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))
        Text("UPI ID", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = upi,
            onValueChange = {
                upi = it
                error = ""
            },
            placeholder = { Text("name@bank") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Pal.Purple50)
                .border(0.5.dp, Pal.Purple200, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            SummaryRow("Rate", "1 coin = ₹1")
            SummaryRow("You get", "₹$coins", Pal.Teal600)
        }
        Spacer(Modifier.height(12.dp))
        NoticeBox(
            text = "Payouts are held ${c.holdDays} days, then paid to your UPI ID after approval.",
            bg = Pal.Blue100,
            fg = Pal.Blue900,
        )
        if (error.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(error, color = Pal.Danger, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
        Chunky(
            onClick = {
                val id = upi.trim()
                if (coins <= 0L) {
                    error = "Enter how many coins to redeem"
                } else if (coins > ui.coins) {
                    error = "You only have ${ui.coins} coins"
                } else if (!UPI_REGEX.matches(id)) {
                    error = "Enter a valid UPI ID, like name@bank"
                } else {
                    error = ""
                    onRequest(coins, id)
                    coinsText = ""
                }
            },
            color = Pal.Purple400,
            edge = Pal.Purple600,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(
                "Request payout",
                color = Color.White,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(14.dp),
            )
        }
    }
}

@Composable
fun HistoryScreen(ui: UiState) {
    if (ui.history.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No activity yet", color = Pal.Purple600)
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        itemsIndexed(ui.history) { _, row ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Pal.Purple50)
                    .border(0.5.dp, Pal.Purple200, RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(row.title, fontSize = 14.sp, color = Pal.Purple900)
                    Text(row.detail, fontSize = 13.sp, color = Pal.Purple600)
                }
                StatusPill(row.status)
            }
        }
    }
}
