package com.appforge.playbalanceconverter

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Pal {
    val Purple50 = Color(0xFFEEEDFE)
    val Purple200 = Color(0xFFAFA9EC)
    val Purple400 = Color(0xFF7F77DD)
    val Purple600 = Color(0xFF534AB7)
    val Purple800 = Color(0xFF3C3489)
    val Purple900 = Color(0xFF26215C)
    val Teal200 = Color(0xFF5DCAA5)
    val Teal400 = Color(0xFF1D9E75)
    val Teal600 = Color(0xFF0F6E56)
    val Teal900 = Color(0xFF04342C)
    val Coral200 = Color(0xFFF0997B)
    val Coral400 = Color(0xFFD85A30)
    val Coral900 = Color(0xFF4A1B0C)
    val Amber100 = Color(0xFFFAC775)
    val Amber200 = Color(0xFFEF9F27)
    val Amber400 = Color(0xFFBA7517)
    val Amber900 = Color(0xFF412402)
    val Blue100 = Color(0xFFB5D4F4)
    val Blue900 = Color(0xFF042C53)
    val Green100 = Color(0xFF9FE1CB)
    val Red100 = Color(0xFFF7C1C1)
    val Red900 = Color(0xFF501313)
    val Danger = Color(0xFFB3261E)
}

@Composable
fun CoinCashTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Pal.Purple600,
            onPrimary = Color.White,
            secondary = Pal.Teal400,
            onSecondary = Color.White,
            background = Color.White,
            onBackground = Pal.Purple900,
            surface = Color.White,
            onSurface = Pal.Purple900,
            surfaceVariant = Pal.Purple50,
            onSurfaceVariant = Pal.Purple800,
            secondaryContainer = Pal.Purple50,
            onSecondaryContainer = Pal.Purple900,
        ),
        content = content,
    )
}
