package com.rajeev.samuhkhata.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rajeev.samuhkhata.core.Alerts
import com.rajeev.samuhkhata.core.Calc
import com.rajeev.samuhkhata.core.Exporter
import com.rajeev.samuhkhata.core.Kind
import com.rajeev.samuhkhata.core.Member
import com.rajeev.samuhkhata.core.MemberStatus
import com.rajeev.samuhkhata.core.Prefs
import com.rajeev.samuhkhata.core.Repo
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.tx

private val colourNames = listOf("plum" to ("Plum Rose" to "प्लम रोज़"), "green" to ("Green Harvest" to "ग्रीन हार्वेस्ट"), "blue" to ("Royal Blue" to "रॉयल ब्लू"))

@Composable
fun ColourPicker(selected: String, enabled: Boolean, onPick: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
        colourNames.forEach { (key, names) ->
            val on = key == selected
            Column(
                Modifier.alpha(if (!enabled && !on) 0.4f else 1f).clip(MaterialTheme.shapes.medium)
                    .then(if (enabled) Modifier.clickable { onPick(key) } else Modifier).padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Box(
                    Modifier.size(48.dp).then(if (on) Modifier.border(3.dp, swatch(key), CircleShape).padding(5.dp) else Modifier)
                        .clip(CircleShape).background(swatch(key)),
                    contentAlignment = Alignment.Center,
                ) { if (on) Icon(Icons.Outlined.Check, null, tint = Color.White) }
                Text(tx(names.first, names.second), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ModePicker() {
    Text(tx("Mode", "मोड"), style = MaterialTheme.typography.bodyLarge)
    Segmented(listOf("light" to tx("Light", "लाइट"), "dark" to tx("Dark", "डार्क"), "system" to tx("System", "सिस्टम")), Prefs.mode) { Prefs.changeMode(it) }
}

@Composable
private fun LanguageRow() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(tx("Language", "भाषा"), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Box(Modifier.weight(1f)) { Segmented(listOf("hi" to "हिंदी", "en" to "English"), if (Prefs.hindi) "hi" else "en") { Prefs.setLanguage(it == "hi") } }
    }
}

@Composable
private fun ProfileCard(title: String) {
    val me = Session.me ?: return
    var edit by remember { mutableStateOf(false) }
    SectionCard(title) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(me.initials, MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary, 52.dp)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(me.name, style = MaterialTheme.typography.titleMedium)
                Text(me.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("+91 " + me.phone.ifBlank { tx("[add phone]", "[फ़ोन जोड़ें]") }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { edit = true }) { Text(tx("Edit", "बदलें")) }
        }
        LanguageRow()
    }
    if (edit) {
        var name by remember { mutableStateOf(me.name) }
        var phone by remember { mutableStateOf(me.phone) }
        AlertDialog(
            onDismissRequest = { edit = false },
            title = { Text(tx("Edit profile", "प्रोफ़ाइल बदलें")) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(tx("Name", "नाम"), name, { name = it })
                Field(tx("Phone number", "फ़ोन नंबर"), phone, { phone = it.filter { c -> c.isDigit() }.take(10) }, number = true)
            } },
            confirmButton = { TextButton(onClick = { if (name.isNotBlank()) Repo.updateMyProfile(name.trim(), phone.trim()); edit = false }) { Text(tx("Save", "सेव करें")) } },
            dismissButton = { TextButton(onClick = { edit = false }) { Text(tx("Cancel", "रद्द करें")) } },
        )
    }
}

// ---------------------------------------------------------------- admin & co-admin settings

@Composable
fun AdminSettingsScreen(onSignOut: () -> Unit) {
    val g = Session.group ?: return
    val ctx = LocalContext.current
    val isAdmin = Session.isAdmin
    var signOut by remember { mutableStateOf(false) }
    Page(tx("Settings", "सेटिंग"), "${roleName(Session.me?.role ?: "")} · ${g.name}") {
        item { ProfileCard(tx("Profile", "प्रोफ़ाइल")) }
        item {
            SectionCard(tx("Appearance", "रूप-रंग")) {
                ModePicker()
                Text(tx("Group colour", "समूह का रंग"), style = MaterialTheme.typography.bodyLarge)
                ColourPicker(g.colour, isAdmin) { Repo.setGroupColour(it) }
                Divider()
                ToggleRow(tx("Let members choose their own colour", "सदस्यों को अपना रंग चुनने दें"),
                    if (g.colourLocked) tx("🔒 Locked · everyone uses ${colourLabel(g.colour)}", "🔒 लॉक · सभी ${colourLabel(g.colour)} इस्तेमाल करेंगे") else tx("🔓 Unlocked · members can pick", "🔓 अनलॉक · सदस्य चुन सकते हैं"),
                    checked = !g.colourLocked, enabled = isAdmin) { Repo.setColourLocked(!it) }
                Text(tx("Light, Dark and System mode are always each member's own choice. The app icon follows the colour.", "लाइट, डार्क और सिस्टम मोड हमेशा हर सदस्य की अपनी पसंद है। ऐप आइकन रंग के साथ बदलता है।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            SectionCard(tx("Group settings", "समूह सेटिंग"), padding = 12.dp) {
                ListRow(tx("Group rules", "समूह के नियम"), tx("${Calc.rupees(g.monthlySaving)} by ${g.dueDay} · ${Calc.num(g.interestRate)}% ${g.interestMethod} · fine ${Calc.rupees(g.lateFine)}", "${Calc.rupees(g.monthlySaving)} · ${g.dueDay} तारीख · ${Calc.num(g.interestRate)}% · जुर्माना ${Calc.rupees(g.lateFine)}"), onClick = { Nav.go(Screen.GroupRules) })
                Divider()
                ListRow(tx("Manage members", "सदस्य प्रबंधन"), tx("${Session.activeMembers.size} members · co-admin: ${g.coAdminName.ifBlank { "none" }}", "${Session.activeMembers.size} सदस्य · सह-एडमिन: ${g.coAdminName.ifBlank { "कोई नहीं" }}"), onClick = { Nav.go(Screen.Members) })
                Divider()
                ListRow(tx("Invite code", "इनवाइट कोड"), g.inviteCode.chunked(3).joinToString(" "), onClick = { Nav.go(Screen.Members) })
                Divider()
                ListRow(tx("Permissions", "अनुमतियाँ"), tx("Back-date & edit switches", "पिछली तारीख और बदलाव के स्विच"), onClick = { Nav.go(Screen.Permissions) })
            }
        }
        item {
            SectionCard(tx("Group maintenance alerts", "समूह रखरखाव अलर्ट"), padding = 12.dp) {
                val a = g.alerts
                val on = listOf(a.savingDue, a.emi, a.meeting, a.lowCash, a.joinRequest).count { it }
                ListRow(tx("Alert settings", "अलर्ट सेटिंग"), tx("$on of 5 alerts on", "5 में से $on अलर्ट चालू"), onClick = { Nav.go(Screen.Alerts) })
            }
        }
        item {
            SectionCard(tx("Data & backup", "डेटा और बैकअप"), padding = 12.dp) {
                ListRow(tx("Export records", "रिकॉर्ड एक्सपोर्ट"), tx("Excel (CSV) · PDF reports", "Excel (CSV) · PDF रिपोर्ट"), onClick = { Nav.go(Screen.Reports) })
                Divider()
                ListRow(tx("Back up now (share Excel file)", "अभी बैकअप लें (Excel फ़ाइल शेयर)"), null, onClick = { Exporter.share(ctx, Exporter.recordsCsv(ctx, g, Session.txns), "text/csv") })
                Divider()
                ListRow(tx("Edit history log", "बदलाव इतिहास"), null, onClick = { Nav.go(Screen.ActivityLog(Kind.EDIT)) })
                Divider()
                ListRow(tx("Old Records Setup", "पुराने रिकॉर्ड सेटअप"), if (g.setupOpen()) tx("Open till ${Calc.date(g.setupUntil)}", "${Calc.date(g.setupUntil)} तक खुला") else tx("Closed", "बंद"), onClick = { Nav.go(Screen.OldRecords) })
                Divider()
                ListRow(tx("Year-end close & profit share", "साल बंद और मुनाफ़ा बँटवारा"), null, onClick = { Nav.go(Screen.ProfitShare) })
            }
        }
        item {
            Text(tx("Your records are saved online (Firebase) and on this phone. Sign in with the same Gmail on a new phone to get everything back.",
                "आपका हिसाब ऑनलाइन (Firebase) और इस फ़ोन में सुरक्षित है। नए फ़ोन पर वही Gmail से साइन इन करें, सब वापस आ जाएगा।"),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { SecondaryButton(tx("Sign out", "साइन आउट"), color = LocalExtra.current.badFg) { signOut = true } }
    }
    if (signOut) ConfirmDialog(tx("Sign out?", "साइन आउट करें?"), tx("Your records stay safe online.", "आपका हिसाब ऑनलाइन सुरक्षित रहेगा।"), tx("Sign out", "साइन आउट"), { signOut = false }) { onSignOut() }
}

private fun colourLabel(c: String): String = colourNames.firstOrNull { it.first == c }?.second?.let { tx(it.first, it.second) } ?: c

@Composable
fun GroupRulesEditScreen() {
    val g = Session.group ?: return
    if (!Session.isAdmin) { GroupRulesViewScreen(); return }
    var name by remember { mutableStateOf(g.name) }
    var monthly by remember { mutableStateOf(Calc.num(g.monthlySaving)) }
    var due by remember { mutableStateOf(g.dueDay.toString()) }
    var rate by remember { mutableStateOf(Calc.num(g.interestRate)) }
    var method by remember { mutableStateOf(g.interestMethod) }
    var fine by remember { mutableStateOf(Calc.num(g.lateFine)) }
    var max by remember { mutableStateOf(if (g.maxSize == 0) "" else g.maxSize.toString()) }
    var err by remember { mutableStateOf("") }
    Page(tx("Group rules", "समूह के नियम"), bottom = {
        PrimaryButton(tx("Save rules", "नियम सेव करें")) {
            val m = monthly.money(); val d = due.toIntOrNull(); val r = rate.money(); val f = fine.money(); val mx = if (max.isBlank()) 0 else max.toIntOrNull()
            err = when {
                name.isBlank() -> tx("Enter group name", "समूह का नाम लिखें")
                m == null || m <= 0 -> tx("Enter monthly saving", "मासिक बचत लिखें")
                d == null || d !in 1..28 -> tx("Due day must be 1 to 28", "तारीख 1 से 28 हो")
                r == null || r < 0 -> tx("Enter interest rate", "ब्याज दर लिखें")
                f == null || f < 0 -> tx("Enter late fine", "जुर्माना लिखें")
                mx == null || mx < 0 -> tx("Max size must be a number (empty = no limit)", "अधिकतम संख्या लिखें (खाली = कोई सीमा नहीं)")
                (mx ?: 0) in 1 until Session.activeMembers.size -> tx("Max size is less than current members", "अधिकतम संख्या अभी के सदस्यों से कम है")
                else -> ""
            }
            if (err.isBlank()) { Repo.updateRules(name.trim(), m!!, d!!, r!!, method, f!!, mx!!); Nav.back() }
        }
    }) {
        item {
            SectionCard {
                Field(tx("Group name", "समूह का नाम"), name, { name = it })
                Field(tx("Monthly saving (₹)", "मासिक बचत (₹)"), monthly, { monthly = it }, number = true)
                Field(tx("Due day of month (1–28)", "हर महीने जमा की तारीख (1–28)"), due, { due = it }, number = true)
                Field(tx("Loan interest % per month", "लोन ब्याज % प्रति माह"), rate, { rate = it }, number = true)
                Segmented(listOf("flat" to tx("Flat", "फ्लैट"), "reducing" to tx("Reducing", "घटता हुआ")), method) { method = it }
                Field(tx("Late fine (₹)", "देर का जुर्माना (₹)"), fine, { fine = it }, number = true)
                Field(tx("Max group size (empty = no limit)", "अधिकतम सदस्य (खाली = कोई सीमा नहीं)"), max, { max = it.filter { c -> c.isDigit() } }, number = true)
            }
        }
        item { Banner(tx("All members are notified of any rule change. New interest rates apply to new loans only.", "नियम बदलने पर सभी को सूचना जाएगी। नई ब्याज दर केवल नए लोन पर लगेगी।"), warn = false) }
        if (err.isNotBlank()) item { Banner(err) }
    }
}

@Composable
fun GroupRulesViewScreen() {
    Page(tx("Group rules", "समूह के नियम")) {
        item { SectionCard { RulesText() } }
        item { Text(tx("Only the admin can change rules. Everyone is notified when they change.", "केवल एडमिन नियम बदल सकते हैं। बदलने पर सभी को सूचना जाती है।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
fun AlertsScreen() {
    val g = Session.group ?: return
    val a = g.alerts
    val editable = Session.isAdmin
    var saving by remember { mutableStateOf(a.savingDue) }
    var emi by remember { mutableStateOf(a.emi) }
    var meeting by remember { mutableStateOf(a.meeting) }
    var low by remember { mutableStateOf(a.lowCash) }
    var limit by remember { mutableStateOf(Calc.num(a.lowCashLimit)) }
    var join by remember { mutableStateOf(a.joinRequest) }
    Page(tx("Group maintenance alerts", "समूह रखरखाव अलर्ट"), bottom = if (editable) ({
        PrimaryButton(tx("Save", "सेव करें")) {
            Repo.setAlerts(Alerts(saving, emi, meeting, low, limit.money() ?: 5000.0, join)); Nav.back()
        }
    }) else null) {
        item {
            SectionCard {
                ToggleRow(tx("Saving due reminder", "बचत जमा याद"), tx("2 days before the due date · all members", "जमा तारीख से 2 दिन पहले · सभी सदस्य"), saving, editable) { saving = it }
                Divider()
                ToggleRow(tx("Loan EMI due & overdue", "लोन किस्त देय और बकाया"), tx("Borrower + admin", "लोन लेने वाले + एडमिन"), emi, editable) { emi = it }
                Divider()
                ToggleRow(tx("Meeting reminder", "बैठक याद"), tx("1 day before · all members", "1 दिन पहले · सभी सदस्य"), meeting, editable) { meeting = it }
                Divider()
                ToggleRow(tx("Low cash warning", "कम नकद चेतावनी"), tx("Admin only", "केवल एडमिन"), low, editable) { low = it }
                if (low) Field(tx("Warn when cash is below (₹)", "जब नकद इससे कम हो (₹)"), limit, { limit = it }, number = true, enabled = editable)
                Divider()
                ToggleRow(tx("New join request", "नया जुड़ने का अनुरोध"), tx("Admin + co-admin", "एडमिन + सह-एडमिन"), join, editable) { join = it }
            }
        }
        item {
            Banner(tx("Edit, permission and role alerts always go to members and cannot be turned off.", "बदलाव, अनुमति और भूमिका के अलर्ट हमेशा सदस्यों को जाते हैं और बंद नहीं हो सकते।"), Icons.Outlined.Lock, warn = false)
        }
    }
}

// ---------------------------------------------------------------- permissions (two-key)

@Composable
fun PermissionsScreen() {
    val g = Session.group ?: return
    val me = Session.me ?: return
    val now = System.currentTimeMillis()
    // Only the co-admin holds the switches, and they unlock the admin.
    val other: Member? = if (me.role == com.rajeev.samuhkhata.core.Role.CO) Session.memberById(g.adminUid) else null
    var turnOn by remember { mutableStateOf("") }

    Page(tx("Permissions", "अनुमतियाँ"), tx("Two-key safety: admin enters, co-admin unlocks", "दो-चाबी सुरक्षा: एडमिन एंट्री करें, सह-एडमिन अनुमति दें")) {
        if (g.coAdminUid.isBlank()) {
            item {
                Banner(tx("No co-admin yet. Back-date and edit stay OFF until the admin chooses a co-admin.", "अभी कोई सह-एडमिन नहीं। सह-एडमिन चुनने तक पिछली तारीख और बदलाव बंद रहेंगे।"))
            }
            if (Session.isAdmin) item { PrimaryButton(tx("Choose co-admin", "सह-एडमिन चुनें")) { Nav.go(Screen.Members) } }
        }
        if (g.setupOpen()) item {
            Banner(tx("Old Records Setup is open till ${Calc.date(g.setupUntil)}: back-dating is allowed for old notebook records during this time.",
                "पुराने रिकॉर्ड सेटअप ${Calc.date(g.setupUntil)} तक खुला: इस दौरान पुराने रिकॉर्ड पिछली तारीख से डाल सकते हैं।"), warn = false)
        }
        if (other != null) {
            item { SectionLabel(tx("You control these for ${other.name}", "${other.name} के लिए आपके हाथ में")) }
            listOf("backdate" to (g.backdateUntil[other.uid] ?: 0L), "edit" to (g.editUntil[other.uid] ?: 0L)).forEach { (kind, until) ->
                item {
                    val active = until > now
                    SectionCard {
                        ToggleRow(
                            if (kind == "backdate") tx("📅 Back-date entries", "📅 पिछली तारीख की एंट्री") else tx("✏️ Edit entries", "✏️ एंट्री बदलना"),
                            if (active) tx("ON until ${Calc.dateTime(until)}", "${Calc.dateTime(until)} तक चालू")
                            else if (kind == "backdate") tx("OFF: ${other.name}'s entries get today's date and time automatically", "बंद: ${other.name} की एंट्री में आज की तारीख और समय अपने आप लगेगा")
                            else tx("OFF: ${other.name} cannot edit or delete saved entries", "बंद: ${other.name} सेव एंट्री बदल या हटा नहीं सकते"),
                            checked = active,
                        ) { on -> if (on) turnOn = kind else Repo.setPermission(kind, other, 0) }
                    }
                }
            }
            item { Text(tx("Every time a switch is turned ON or OFF, all members get a notification and it is saved in Group Activity.", "हर बार स्विच चालू या बंद करने पर सभी सदस्यों को सूचना जाती है और समूह गतिविधि में सेव होता है।"),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        if (Session.isAdmin) item { SectionLabel(tx("What you are allowed now", "आपको अभी क्या अनुमति है")) }
        if (Session.isAdmin) item {
            val b = g.backdateUntil[me.uid] ?: 0L
            val e = g.editUntil[me.uid] ?: 0L
            SectionCard {
                Text(tx("📅 Back-date: ", "📅 पिछली तारीख: ") + if (b > now) tx("ON till ${Calc.dateTime(b)}", "${Calc.dateTime(b)} तक चालू") else if (g.setupOpen()) tx("only for setup period", "केवल सेटअप अवधि में") else tx("OFF", "बंद"))
                Text(tx("✏️ Edit: ", "✏️ बदलाव: ") + if (e > now) tx("ON till ${Calc.dateTime(e)}", "${Calc.dateTime(e)} तक चालू") else tx("OFF", "बंद"))
                Text(tx("Only the co-admin (${g.coAdminName.ifBlank { "not chosen" }}) can turn these on for you.", "केवल सह-एडमिन (${g.coAdminName.ifBlank { "नहीं चुने" }}) इन्हें आपके लिए चालू कर सकते हैं।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item { SecondaryButton(tx("See permission & role history", "अनुमति और भूमिका का इतिहास देखें")) { Nav.go(Screen.ActivityLog("permrole")) } }
    }

    if (turnOn.isNotBlank() && other != null) {
        var days by remember { mutableStateOf(1) }
        AlertDialog(
            onDismissRequest = { turnOn = "" },
            title = { Text(if (turnOn == "backdate") tx("Allow back-dating for how long?", "पिछली तारीख की अनुमति कितने समय?") else tx("Allow editing for how long?", "बदलाव की अनुमति कितने समय?")) },
            text = {
                Column {
                    listOf(1, 7, 30).forEach { d ->
                        Row(Modifier.fillMaxWidth().clickable { days = d }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = days == d, onClick = { days = d })
                            Text(if (d == 1) tx("1 day", "1 दिन") else tx("$d days", "$d दिन"))
                        }
                    }
                    Text(tx("It turns OFF by itself after this time. All members will be notified.", "इतने समय बाद यह अपने आप बंद हो जाएगा। सभी को सूचना जाएगी।"), style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { Repo.setPermission(turnOn, other, days); turnOn = "" }) { Text(tx("Turn ON", "चालू करें"), fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { turnOn = "" }) { Text(tx("Cancel", "रद्द करें")) } },
        )
    }
}

// ---------------------------------------------------------------- member settings

@Composable
fun MemberSettingsScreen(onSignOut: () -> Unit) {
    val g = Session.group ?: return
    val me = Session.me ?: return
    val ctx = LocalContext.current
    var leave by remember { mutableStateOf(false) }
    var signOut by remember { mutableStateOf(false) }
    var refresh by remember { mutableStateOf(0) }
    Page(tx("Settings", "सेटिंग"), "${roleName(me.role)} · ${g.name}") {
        item { ProfileCard(tx("My profile", "मेरी प्रोफ़ाइल")) }
        item {
            SectionCard(tx("Appearance", "रूप-रंग")) {
                ModePicker()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tx("Colour", "रंग"), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    if (g.colourLocked) Tag(tx("🔒 Set by admin", "🔒 एडमिन ने तय किया"), MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary)
                }
                val current = if (g.colourLocked || Prefs.personalColour.isBlank()) g.colour else Prefs.personalColour
                ColourPicker(current, !g.colourLocked) { Prefs.setColour(it) }
            }
        }
        item {
            SectionCard(tx("My alerts", "मेरे अलर्ट")) {
                key(refresh) {
                    listOf(
                        "saving" to (tx("My saving due", "मेरी बचत जमा") to tx("2 days before the ${g.dueDay}th", "${g.dueDay} तारीख से 2 दिन पहले")),
                        "emi" to (tx("My loan EMI", "मेरी लोन किस्त") to tx("Due and overdue", "देय और बकाया")),
                        "meeting" to (tx("Meeting reminder", "बैठक याद") to tx("1 day before", "1 दिन पहले")),
                        "announce" to (tx("Group announcements", "समूह सूचनाएं") to tx("Messages from admin", "एडमिन के संदेश")),
                    ).forEach { (k, t) ->
                        ToggleRow(t.first, t.second, Prefs.alertOn(k)) { Prefs.setAlert(k, it); refresh++ }
                    }
                }
                Text(tx("Edits to your entries, permission and role changes always notify you and can't be turned off.", "आपकी एंट्री में बदलाव, अनुमति और भूमिका के अलर्ट हमेशा आते हैं, बंद नहीं होते।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            SectionCard(tx("My group", "मेरा समूह"), padding = 12.dp) {
                val admin = Session.memberById(g.adminUid)
                val co = Session.memberById(g.coAdminUid)
                if (admin != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { ListRow(admin.name, tx("Admin", "एडमिन"), chevron = false) }
                    CallButton(admin.phone)
                }
                if (co != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { ListRow(co.name, tx("Co-admin", "सह-एडमिन"), chevron = false) }
                    CallButton(co.phone)
                }
                Divider()
                ListRow(tx("Group rules", "समूह के नियम"), "${Calc.rupees(g.monthlySaving)} · ${Calc.num(g.interestRate)}% · ${tx("fine", "जुर्माना")} ${Calc.rupees(g.lateFine)}", onClick = { Nav.go(Screen.GroupRules) })
                Divider()
                ListRow(tx("Member list", "सदस्य सूची"), tx("${Session.activeMembers.size} names", "${Session.activeMembers.size} नाम"), onClick = { Nav.go(Screen.MemberList) })
            }
        }
        item {
            SectionCard(tx("My records", "मेरा हिसाब"), padding = 12.dp) {
                ListRow(tx("Download my passbook", "मेरी पासबुक डाउनलोड"), "PDF", onClick = { Exporter.share(ctx, Exporter.passbook(ctx, g, me, Session.txns, Session.loans), "application/pdf") })
                Divider()
                ListRow(tx("Savings & loan history", "बचत और लोन इतिहास"), null, onClick = { Nav.go(Screen.Passbook(me.uid)) })
            }
        }
        item {
            if (me.status == MemberStatus.LEAVE_REQUESTED) SecondaryButton(tx("Cancel leave request", "छोड़ने का अनुरोध रद्द करें")) { Repo.cancelLeave() }
            else SecondaryButton(tx("Request to leave group", "समूह छोड़ने का अनुरोध"), color = LocalExtra.current.warnFg) { leave = true }
            Text(tx("Admin settles your savings and any loan first.", "पहले एडमिन आपकी बचत और लोन का हिसाब करेंगे।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
        }
        item { SecondaryButton(tx("Sign out", "साइन आउट"), color = LocalExtra.current.badFg) { signOut = true } }
    }
    if (leave) ConfirmDialog(tx("Request to leave?", "छोड़ने का अनुरोध करें?"), tx("The admin and co-admin will be notified.", "एडमिन और सह-एडमिन को सूचना जाएगी।"), tx("Send request", "अनुरोध भेजें"), { leave = false }) { Repo.requestLeave() }
    if (signOut) ConfirmDialog(tx("Sign out?", "साइन आउट करें?"), tx("Your records stay safe online.", "आपका हिसाब ऑनलाइन सुरक्षित रहेगा।"), tx("Sign out", "साइन आउट"), { signOut = false }) { onSignOut() }
}

@Composable
private fun key(k: Int, content: @Composable () -> Unit) = androidx.compose.runtime.key(k) { content() }
