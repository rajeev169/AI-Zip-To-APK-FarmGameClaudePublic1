# Samuh Khata v1 — Setup (one time, ~10 minutes)

Package name: `com.rajeev.samuhkhata`

## 1. Firebase project
1. Open https://console.firebase.google.com → **Add project** → name it **Samuh Khata** (a new project, like Fleet Track and Family Shield).
2. **Build → Authentication → Get started → Sign-in method → Google → Enable → Save.**
3. **Build → Firestore Database → Create database** → choose a location near India (e.g. `asia-south1` Mumbai) → start in production mode.
4. **Firestore → Rules** → delete everything, paste the full `firestore.rules` file from this zip → **Publish**.

## 2. Add the Android app
1. Project settings (⚙️) → **Add app → Android**.
2. Android package name: `com.rajeev.samuhkhata`
3. Add the **SHA-1** of your signing key — the same shared test key your GitHub workflow uses (the one you already added for Tractor Khata / Fleet Track). Google sign-in will not work without it.
4. Download **google-services.json** and put it here inside the project:
   `SamuhKhata/app/google-services.json`
   (next to `app/build.gradle.kts`). The build fails without this file.

## 3. Build the APK
Zip the `SamuhKhata` folder (with `google-services.json` inside `app/`) and push it to your GitHub repo — the **Universal ZIP to APK** workflow builds and signs it as usual. Keep only one zip in the repo, or run the workflow with `zip_path`.

## 4. First use
- **Admin:** sign in with Google → *Create a new group* → fill rules.
- **Members:** admin adds their Gmail (they join automatically on sign-in) **or** shares the 6-digit invite code (admin approves).
- Old group with a notebook? ☰ → **Old Records Setup** (open 30 days).
- Choose a **co-admin** (☰ → Members) so the back-date and edit permission switches can be used.

## Costs
For one group of 10–20 members everything stays on Firebase's **free (Spark) plan**: Google sign-in, invite codes, Firestore, and notifications (they are shown by the app itself, no paid server).

---

# सेटअप (हिंदी)
1. Firebase में नया प्रोजेक्ट **Samuh Khata** बनाएं।
2. Authentication → Google चालू करें।
3. Firestore Database बनाएं (Mumbai), फिर Rules में `firestore.rules` पूरा पेस्ट करके Publish करें।
4. Android ऐप जोड़ें: पैकेज `com.rajeev.samuhkhata`, अपनी साइनिंग key का SHA-1 डालें।
5. `google-services.json` डाउनलोड करके `SamuhKhata/app/` में रखें।
6. फ़ोल्डर zip करके GitHub पर डालें — APK बन जाएगी।
