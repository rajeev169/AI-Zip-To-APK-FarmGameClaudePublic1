package com.rajeev.samuhkhata

import android.app.Application
import com.rajeev.samuhkhata.core.Notifier
import com.rajeev.samuhkhata.core.Prefs
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.SyncWorker

class SamuhApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Notifier.createChannels(this)
        Session.init(this)
        SyncWorker.schedule(this)
    }
}
