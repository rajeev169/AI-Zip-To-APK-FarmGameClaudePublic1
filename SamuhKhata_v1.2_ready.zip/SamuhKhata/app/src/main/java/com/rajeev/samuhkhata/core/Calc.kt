package com.rajeev.samuhkhata.core

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/** All money maths lives here so every screen shows the same numbers. */
object Calc {

    fun live(txns: List<Txn>) = txns.filter { !it.deleted }

    // ---------- savings ----------
    fun memberSavings(uid: String, txns: List<Txn>): Double = live(txns).filter { it.memberUid == uid }.sumOf {
        when (it.type) {
            TxType.SAVING, TxType.OPEN_SAVING, TxType.PROFIT_SHARE -> it.amount
            TxType.WITHDRAW -> -it.amount
            else -> 0.0
        }
    }

    fun memberFines(uid: String, txns: List<Txn>) =
        live(txns).filter { it.memberUid == uid && it.type == TxType.FINE }.sumOf { it.amount }

    fun memberInterestPaid(uid: String, txns: List<Txn>) = live(txns).filter { it.memberUid == uid }.sumOf {
        when (it.type) {
            TxType.REPAY -> it.interest
            TxType.OPEN_INTEREST -> it.amount
            else -> 0.0
        }
    }

    fun paidSaving(uid: String, month: String, txns: List<Txn>) =
        live(txns).any { it.memberUid == uid && it.type == TxType.SAVING && it.month == month }

    fun savingTxnFor(uid: String, month: String, txns: List<Txn>) =
        live(txns).firstOrNull { it.memberUid == uid && it.type == TxType.SAVING && it.month == month }

    // ---------- loans ----------
    fun repaidPrincipal(loan: Loan, txns: List<Txn>) =
        live(txns).filter { it.type == TxType.REPAY && it.loanId == loan.id }.sumOf { it.principal }

    fun repaidInterest(loan: Loan, txns: List<Txn>) =
        live(txns).filter { it.type == TxType.REPAY && it.loanId == loan.id }.sumOf { it.interest }

    fun outstanding(loan: Loan, txns: List<Txn>) = max(0.0, loan.principal - repaidPrincipal(loan, txns))

    fun principalPart(loan: Loan) = loan.principal / loan.months

    /** Interest for the next instalment. Flat = on the full loan; reducing = on what is still due. */
    fun interestDue(loan: Loan, outstanding: Double): Double {
        val base = if (loan.method == "reducing") outstanding else loan.principal
        return round2(base * loan.rate / 100.0)
    }

    fun nextEmi(loan: Loan, outstanding: Double): Double {
        if (outstanding <= 0.5) return 0.0
        return round2(min(principalPart(loan), outstanding) + interestDue(loan, outstanding))
    }

    /** Splits an amount paid into interest first, then principal. */
    fun split(loan: Loan, outstanding: Double, amount: Double): Pair<Double, Double> {
        val interest = min(amount, interestDue(loan, outstanding))
        val principal = min(max(0.0, amount - interest), outstanding)
        return round2(principal) to round2(interest)
    }

    fun instalmentsPaid(loan: Loan, outstanding: Double): Int {
        val part = principalPart(loan)
        if (part <= 0) return 0
        return floor((loan.principal - outstanding) / part + 0.001).toInt().coerceIn(0, loan.months)
    }

    fun nextDueDate(loan: Loan, outstanding: Double): Long {
        val paid = instalmentsPaid(loan, outstanding)
        return addMonths(loan.startDate, paid + 1)
    }

    fun isOverdue(loan: Loan, outstanding: Double, now: Long = System.currentTimeMillis()): Boolean {
        if (loan.status != "active" || outstanding <= 0.5) return false
        return now > nextDueDate(loan, outstanding) + DAY
    }

    fun schedule(loan: Loan): List<Triple<Long, Double, Double>> {
        val list = mutableListOf<Triple<Long, Double, Double>>()
        var left = loan.principal
        val part = principalPart(loan)
        for (i in 1..loan.months) {
            val interest = interestDue(loan, left)
            val p = min(part, left)
            list += Triple(addMonths(loan.startDate, i), round2(p), interest)
            left -= p
        }
        return list
    }

    // ---------- group summary ----------
    fun profitEarned(txns: List<Txn>) = live(txns).sumOf {
        when (it.type) {
            TxType.REPAY -> it.interest
            TxType.OPEN_INTEREST, TxType.FINE, TxType.INCOME -> it.amount
            TxType.EXPENSE -> -it.amount
            else -> 0.0
        }
    }

    fun profitDistributed(txns: List<Txn>) = live(txns)
        .filter { it.type == TxType.PROFIT_SHARE || it.type == TxType.PROFIT_PAYOUT }.sumOf { it.amount }

    fun summary(txns: List<Txn>, loans: List<Loan>): Summary {
        val savings = live(txns).sumOf {
            when (it.type) {
                TxType.SAVING, TxType.OPEN_SAVING, TxType.PROFIT_SHARE -> it.amount
                TxType.WITHDRAW -> -it.amount
                else -> 0.0
            }
        }
        val profit = profitEarned(txns) - profitDistributed(txns)
        val active = loans.filter { it.status == "active" }
        val lent = active.sumOf { outstanding(it, txns) }
        val fund = savings + profit
        return Summary(
            fund = round2(fund), cash = round2(fund - lent), lent = round2(lent),
            profit = round2(profit), savings = round2(savings),
            activeLoans = active.count { outstanding(it, txns) > 0.5 },
            updatedAt = System.currentTimeMillis(),
        )
    }

    /** Each member's share of undistributed profit, by how much they have saved. */
    fun profitShares(members: List<Member>, txns: List<Txn>): List<Pair<Member, Double>> {
        val profit = profitEarned(txns) - profitDistributed(txns)
        val active = members.filter { it.status != MemberStatus.LEFT }
        val weights = active.map { it to max(0.0, memberSavings(it.uid, txns)) }
        val total = weights.sumOf { it.second }
        if (total <= 0 || profit <= 0) return active.map { it to 0.0 }
        return weights.map { (m, w) -> m to floor(profit * w / total) }
    }

    // ---------- dates & money ----------
    const val DAY = 24L * 60 * 60 * 1000

    fun monthKey(t: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyy-MM", Locale.US).format(Date(t))

    fun monthStart(key: String): Long {
        val p = key.split("-")
        val c = Calendar.getInstance()
        c.clear()
        c.set(p[0].toInt(), p[1].toInt() - 1, 1)
        return c.timeInMillis
    }

    fun shiftMonth(key: String, by: Int): String = monthKey(addMonths(monthStart(key), by))

    fun monthLabel(key: String, hindi: Boolean = false): String =
        SimpleDateFormat("MMMM yyyy", if (hindi) Locale("hi", "IN") else Locale.ENGLISH).format(Date(monthStart(key)))

    fun shortMonth(key: String, hindi: Boolean = false): String =
        SimpleDateFormat("MMMM", if (hindi) Locale("hi", "IN") else Locale.ENGLISH).format(Date(monthStart(key)))

    fun addMonths(t: Long, n: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.add(Calendar.MONTH, n)
        return c.timeInMillis
    }

    fun dueDateOf(key: String, dueDay: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = monthStart(key)
        c.set(Calendar.DAY_OF_MONTH, dueDay)
        c.set(Calendar.HOUR_OF_DAY, 23)
        c.set(Calendar.MINUTE, 59)
        return c.timeInMillis
    }

    fun dayOfMonth(t: Long = System.currentTimeMillis()): Int {
        val c = Calendar.getInstance(); c.timeInMillis = t; return c.get(Calendar.DAY_OF_MONTH)
    }

    fun round2(v: Double) = (v * 100).roundToLong() / 100.0

    fun date(t: Long): String = SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(Date(t))
    fun shortDate(t: Long): String = SimpleDateFormat("d MMM", Locale.ENGLISH).format(Date(t))
    fun dateTime(t: Long): String = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.ENGLISH).format(Date(t))
    fun shortDateTime(t: Long): String = SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH).format(Date(t))
    fun isoDate(t: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(t))

    fun parseIsoDate(s: String): Long? = try {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(s.trim())?.time
    } catch (e: Exception) { null }

    /** ₹1,24,500 style (Indian grouping). Shows paise only when present. */
    fun rupees(v: Double): String {
        val neg = v < 0
        val a = abs(v)
        val whole = floor(a + 0.0000001).toLong()
        val paise = ((a - whole) * 100).roundToLong()
        val s = whole.toString()
        val grouped = if (s.length <= 3) s else {
            val last3 = s.takeLast(3)
            var rest = s.dropLast(3)
            val parts = mutableListOf<String>()
            while (rest.length > 2) { parts.add(0, rest.takeLast(2)); rest = rest.dropLast(2) }
            if (rest.isNotEmpty()) parts.add(0, rest)
            parts.joinToString(",") + "," + last3
        }
        val p = if (paise in 1..99) "." + paise.toString().padStart(2, '0') else ""
        return (if (neg) "−" else "") + "₹" + grouped + p
    }

    fun num(v: Double): String = if (v == floor(v)) v.toLong().toString() else round2(v).toString()

    fun newCode(): String = (100000..999999).random().toString()
}
