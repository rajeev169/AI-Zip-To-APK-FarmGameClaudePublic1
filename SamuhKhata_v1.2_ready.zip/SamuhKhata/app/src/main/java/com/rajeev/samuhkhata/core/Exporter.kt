package com.rajeev.samuhkhata.core

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File

/** Monthly report & passbook PDFs (to share on WhatsApp), and Excel-friendly CSV files. */
object Exporter {

    private class Pdf(val title: String) {
        val doc = PdfDocument()
        private var pageNo = 0
        private var page: PdfDocument.Page? = null
        lateinit var c: Canvas
        var y = 0f
        val W = 595f
        val H = 842f
        val left = 40f
        val text = Paint().apply { color = Color.rgb(34, 26, 44); textSize = 11f; isAntiAlias = true }
        val bold = Paint(text).apply { typeface = Typeface.DEFAULT_BOLD }
        val big = Paint(bold).apply { textSize = 18f }
        val grey = Paint(text).apply { color = Color.rgb(92, 84, 106); textSize = 9.5f }
        val line = Paint().apply { color = Color.rgb(220, 214, 230); strokeWidth = 1f }
        val band = Paint().apply { color = Color.rgb(91, 58, 140) }
        val white = Paint(big).apply { color = Color.WHITE }

        init { newPage() }

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(W.toInt(), H.toInt(), pageNo).create())
            page = p
            c = p.canvas
            c.drawRect(0f, 0f, W, 56f, band)
            c.drawText(title, left, 36f, white)
            c.drawText("${tx("Page", "पेज")} $pageNo", W - 90f, 36f, Paint(grey).apply { color = Color.WHITE })
            y = 84f
        }

        fun need(h: Float) { if (y + h > H - 40f) newPage() }

        fun heading(s: String) { need(30f); y += 8f; c.drawText(s, left, y, bold.apply { textSize = 13f }); bold.textSize = 11f; y += 18f }
        fun row(cols: List<String>, widths: List<Float>, header: Boolean = false) {
            need(18f)
            var x = left
            cols.forEachIndexed { i, s ->
                val p = if (header) bold else text
                val w = widths[i]
                var t = s
                while (t.isNotEmpty() && p.measureText(t) > w - 6) t = t.dropLast(1)
                c.drawText(t, x, y, p)
                x += w
            }
            y += 6f
            c.drawLine(left, y, W - left, y, line)
            y += 12f
        }
        fun para(s: String, p: Paint = text) { need(16f); c.drawText(s, left, y, p); y += 16f }

        fun save(ctx: Context, name: String): File {
            page?.let { doc.finishPage(it) }
            page = null
            val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
            val f = File(dir, name)
            f.outputStream().use { doc.writeTo(it) }
            doc.close()
            return f
        }
    }

    fun monthlyReport(ctx: Context, g: Group, month: String, members: List<Member>, txns: List<Txn>, loans: List<Loan>): File {
        val hi = Prefs.hindi
        val pdf = Pdf("${g.name} · ${Calc.monthLabel(month, hi)}")
        val live = Calc.live(txns)
        val s = Calc.summary(txns, loans)
        pdf.heading(tx("Group summary", "समूह सारांश"))
        pdf.para("${tx("Total group fund", "कुल समूह फंड")}: ${Calc.rupees(s.fund)}")
        pdf.para("${tx("Cash in hand", "हाथ में नकद")}: ${Calc.rupees(s.cash)}    ${tx("Lent out", "लोन में दिया")}: ${Calc.rupees(s.lent)}    ${tx("Profit", "मुनाफ़ा")}: ${Calc.rupees(s.profit)}")
        pdf.para("${tx("Generated", "बनाया गया")}: ${Calc.dateTime(System.currentTimeMillis())}", pdf.grey)

        pdf.heading(tx("Members", "सदस्य"))
        val w = listOf(150f, 80f, 90f, 90f, 105f)
        pdf.row(listOf(tx("Name", "नाम"), tx("This month", "इस माह"), tx("Total saved", "कुल बचत"), tx("Loan due", "बाकी लोन"), tx("Status", "स्थिति")), w, true)
        members.filter { it.status != MemberStatus.LEFT }.forEach { m ->
            val paid = Calc.savingTxnFor(m.uid, month, txns)
            val loanDue = loans.filter { it.memberUid == m.uid && it.status == "active" }.sumOf { Calc.outstanding(it, txns) }
            pdf.row(listOf(m.name, if (paid != null) Calc.rupees(paid.amount) else "—", Calc.rupees(Calc.memberSavings(m.uid, txns)),
                Calc.rupees(loanDue), if (paid != null) tx("Paid", "जमा") else tx("Pending", "बाकी")), w)
        }

        pdf.heading(tx("Entries this month", "इस माह की एंट्री"))
        val start = Calc.monthStart(month); val end = Calc.monthStart(Calc.shiftMonth(month, 1))
        val w2 = listOf(70f, 150f, 110f, 80f, 105f)
        pdf.row(listOf(tx("Date", "तारीख"), tx("Member", "सदस्य"), tx("Type", "प्रकार"), tx("Amount", "राशि"), tx("Added by", "किसने")), w2, true)
        live.filter { it.date in start until end }.sortedBy { it.date }.forEach { t ->
            pdf.row(listOf(Calc.shortDate(t.date), t.memberName.ifBlank { tx("Group", "समूह") }, Repo.typeLabel(t.type), Calc.rupees(t.amount), t.createdByName), w2)
        }
        return pdf.save(ctx, "Report_${month}.pdf")
    }

    fun passbook(ctx: Context, g: Group, m: Member, txns: List<Txn>, loans: List<Loan>): File {
        val pdf = Pdf("${tx("Passbook", "पासबुक")} · ${m.name}")
        pdf.para("${g.name}", pdf.bold)
        pdf.para("${tx("Total saved", "कुल बचत")}: ${Calc.rupees(Calc.memberSavings(m.uid, txns))}    ${tx("Interest paid", "ब्याज भरा")}: ${Calc.rupees(Calc.memberInterestPaid(m.uid, txns))}    ${tx("Fines", "जुर्माना")}: ${Calc.rupees(Calc.memberFines(m.uid, txns))}")
        loans.filter { it.memberUid == m.uid && it.status == "active" }.forEach { l ->
            val out = Calc.outstanding(l, txns)
            pdf.para("${tx("Loan", "लोन")} ${Calc.rupees(l.principal)} · ${tx("left", "बाकी")} ${Calc.rupees(out)} · ${tx("next EMI", "अगली किस्त")} ${Calc.rupees(Calc.nextEmi(l, out))} ${tx("on", "को")} ${Calc.shortDate(Calc.nextDueDate(l, out))}")
        }
        pdf.para("${tx("Generated", "बनाया गया")}: ${Calc.dateTime(System.currentTimeMillis())}", pdf.grey)
        pdf.heading(tx("All entries", "सभी एंट्री"))
        val w = listOf(80f, 120f, 90f, 90f, 135f)
        pdf.row(listOf(tx("Date", "तारीख"), tx("Type", "प्रकार"), tx("Amount", "राशि"), tx("Saved total", "कुल बचत"), tx("Added by", "किसने")), w, true)
        var running = 0.0
        txns.filter { it.memberUid == m.uid }.sortedBy { it.date }.forEach { t ->
            if (!t.deleted) {
                running += when (t.type) {
                    TxType.SAVING, TxType.OPEN_SAVING, TxType.PROFIT_SHARE -> t.amount
                    TxType.WITHDRAW -> -t.amount
                    else -> 0.0
                }
            }
            val type = Repo.typeLabel(t.type) + (if (t.deleted) " (${tx("deleted", "हटाई")})" else if (t.edited) " (${tx("edited", "बदली")})" else "")
            pdf.row(listOf(Calc.shortDate(t.date), type, Calc.rupees(t.amount), Calc.rupees(running), t.createdByName), w)
        }
        return pdf.save(ctx, "Passbook_${m.name.replace(" ", "_")}.pdf")
    }

    private fun csvCell(s: String): String = if (s.contains(',') || s.contains('"') || s.contains('\n')) "\"" + s.replace("\"", "\"\"") + "\"" else s

    fun recordsCsv(ctx: Context, g: Group, txns: List<Txn>): File {
        val sb = StringBuilder()
        sb.append("date,member,type,amount,principal,interest,month,note,added_by,added_on,back_dated,edited,deleted\n")
        txns.sortedBy { it.date }.forEach { t ->
            sb.append(listOf(Calc.isoDate(t.date), t.memberName, t.type, Calc.num(t.amount), Calc.num(t.principal), Calc.num(t.interest),
                t.month, t.note, t.createdByName, Calc.dateTime(t.createdAt), t.backdated.toString(), t.edited.toString(), t.deleted.toString())
                .joinToString(",") { csvCell(it) }).append("\n")
        }
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, "${g.name.replace(" ", "_")}_records.csv")
        f.writeText("﻿" + sb.toString())
        return f
    }

    fun templateCsv(ctx: Context, members: List<Member>): File {
        val sb = StringBuilder()
        sb.append("date,member,type,amount,note\n")
        val example = members.firstOrNull()?.name ?: "Rajeev Kant"
        sb.append("2024-03-03,$example,saving,500,March saving\n")
        sb.append("2024-03-10,$example,fine,50,Late fine\n")
        sb.append("2024-04-01,,income,1200,Business profit\n")
        sb.append("2024-04-05,,expense,300,Register and pens\n")
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, "Old_records_template.csv")
        f.writeText("﻿" + sb.toString())
        return f
    }

    /** Parses an uploaded CSV. Returns rows and a list of problems (line numbers). */
    fun parseImport(text: String, members: List<Member>): Pair<List<Repo.ImportRow>, List<String>> {
        val rows = mutableListOf<Repo.ImportRow>()
        val errors = mutableListOf<String>()
        val allowed = setOf(TxType.SAVING, TxType.FINE, TxType.INCOME, TxType.EXPENSE)
        text.removePrefix("﻿").lines().forEachIndexed { i, raw ->
            val line = raw.trim()
            if (line.isEmpty() || (i == 0 && line.lowercase().startsWith("date"))) return@forEachIndexed
            val c = splitCsv(line)
            if (c.size < 4) { errors += "${tx("Line", "लाइन")} ${i + 1}: ${tx("needs date, member, type, amount", "तारीख, सदस्य, प्रकार, राशि चाहिए")}"; return@forEachIndexed }
            val date = Calc.parseIsoDate(c[0])
            val type = c[2].trim().lowercase()
            val amount = c[3].trim().replace("₹", "").replace(",", "").toDoubleOrNull()
            val who = c[1].trim()
            val member = members.firstOrNull { it.email.equals(who, true) || it.name.equals(who, true) }
            when {
                date == null -> errors += "${tx("Line", "लाइन")} ${i + 1}: ${tx("date must be YYYY-MM-DD", "तारीख YYYY-MM-DD में हो")}"
                type !in allowed -> errors += "${tx("Line", "लाइन")} ${i + 1}: ${tx("type must be saving, fine, income or expense", "प्रकार saving, fine, income या expense हो")}"
                amount == null || amount <= 0 -> errors += "${tx("Line", "लाइन")} ${i + 1}: ${tx("wrong amount", "गलत राशि")}"
                (type == TxType.SAVING || type == TxType.FINE) && member == null -> errors += "${tx("Line", "लाइन")} ${i + 1}: ${tx("member not found", "सदस्य नहीं मिला")} ($who)"
                else -> rows += Repo.ImportRow(date, if (type == TxType.INCOME || type == TxType.EXPENSE) null else member, type, amount, c.getOrElse(4) { "" })
            }
        }
        return rows to errors
    }

    private fun splitCsv(line: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var q = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' && q && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                ch == '"' -> q = !q
                ch == ',' && !q -> { out += sb.toString(); sb.clear() }
                else -> sb.append(ch)
            }
            i++
        }
        out += sb.toString()
        return out
    }

    fun share(ctx: Context, f: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, tx("Share", "शेयर करें")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun shareText(ctx: Context, text: String) {
        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
        ctx.startActivity(Intent.createChooser(send, tx("Share", "शेयर करें")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
