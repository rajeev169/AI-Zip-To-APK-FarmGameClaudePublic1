package com.rajeev.samuhkhata.core

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/** Switches the home-screen icon to match the app colour (Plum / Green / Blue). */
object IconSwitcher {
    private val aliases = mapOf(
        "plum" to "com.rajeev.samuhkhata.LauncherPlum",
        "green" to "com.rajeev.samuhkhata.LauncherGreen",
        "blue" to "com.rajeev.samuhkhata.LauncherBlue",
    )

    fun apply(ctx: Context, colour: String) {
        val c = if (colour in aliases) colour else "plum"
        if (Prefs.appliedIcon == c) return
        val pm = ctx.packageManager
        try {
            // Enable the new one first so there is always one launcher icon.
            aliases.forEach { (k, name) ->
                if (k == c) pm.setComponentEnabledSetting(ComponentName(ctx.packageName, name),
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            }
            aliases.forEach { (k, name) ->
                if (k != c) pm.setComponentEnabledSetting(ComponentName(ctx.packageName, name),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
            Prefs.appliedIcon = c
        } catch (e: Exception) {
            // Some launchers don't allow it; the app colour still changes.
        }
    }
}
