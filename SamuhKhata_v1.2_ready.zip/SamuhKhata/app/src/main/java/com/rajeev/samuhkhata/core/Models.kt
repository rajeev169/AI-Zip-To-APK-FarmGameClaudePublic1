package com.rajeev.samuhkhata.core

import com.google.firebase.firestore.DocumentSnapshot

object Role {
    const val ADMIN = "admin"
    const val CO = "coadmin"
    const val MEMBER = "member"
}

object MemberStatus {
    const val ACTIVE = "active"
    const val LEAVE_REQUESTED = "leaveRequested"
    const val LEFT = "left"
}

/** Every kind of money entry kept in the group's records. */
object TxType {
    const val SAVING = "saving"
    const val FINE = "fine"
    const val LOAN = "loan"
    const val REPAY = "repayment"
    const val INCOME = "income"
    const val EXPENSE = "expense"
    const val OPEN_SAVING = "openingSaving"
    const val OPEN_INTEREST = "openingInterest"
    const val PROFIT_SHARE = "profitShare"
    const val PROFIT_PAYOUT = "profitPayout"
    const val WITHDRAW = "withdrawal"
}

/** Activity categories; PERM and ROLE are the "Permissions & roles" filter. */
object Kind {
    const val MONEY = "money"
    const val EDIT = "edit"
    const val PERM = "perm"
    const val ROLE = "role"
    const val RULE = "rule"
    const val MEMBER = "member"
    const val SETUP = "setup"
    const val MEETING = "meeting"
    const val ANNOUNCE = "announce"
    const val ALERT = "alert"
}

data class Alerts(
    val savingDue: Boolean = true,
    val emi: Boolean = true,
    val meeting: Boolean = true,
    val lowCash: Boolean = false,
    val lowCashLimit: Double = 5000.0,
    val joinRequest: Boolean = true,
) {
    fun toMap(): Map<String, Any> = mapOf(
        "savingDue" to savingDue, "emi" to emi, "meeting" to meeting,
        "lowCash" to lowCash, "lowCashLimit" to lowCashLimit, "joinRequest" to joinRequest,
    )
}

data class Summary(
    val fund: Double = 0.0,
    val cash: Double = 0.0,
    val lent: Double = 0.0,
    val profit: Double = 0.0,
    val savings: Double = 0.0,
    val activeLoans: Int = 0,
    val updatedAt: Long = 0,
) {
    fun toMap(): Map<String, Any> = mapOf(
        "fund" to fund, "cash" to cash, "lent" to lent, "profit" to profit,
        "savings" to savings, "activeLoans" to activeLoans, "updatedAt" to updatedAt,
    )
}

data class Group(
    val id: String,
    val name: String,
    val adminUid: String,
    val adminName: String,
    val coAdminUid: String,
    val coAdminName: String,
    val monthlySaving: Double,
    val dueDay: Int,
    val interestRate: Double,
    val interestMethod: String,
    val lateFine: Double,
    val maxSize: Int,
    val inviteCode: String,
    val colour: String,
    val colourLocked: Boolean,
    val createdAt: Long,
    val setupUntil: Long,
    val setupClosed: Boolean,
    val alerts: Alerts,
    val backdateUntil: Map<String, Long>,
    val editUntil: Map<String, Long>,
    val summary: Summary,
    val lastCloseAt: Long,
    val lowCashFlag: Boolean,
    val activeProposalId: String,
    val adminAccepted: Boolean,
) {
    fun setupOpen(now: Long = System.currentTimeMillis()) = !setupClosed && now < setupUntil
    fun canBackdate(uid: String, now: Long = System.currentTimeMillis()) =
        setupOpen(now) || (backdateUntil[uid] ?: 0L) > now
    fun canEdit(uid: String, now: Long = System.currentTimeMillis()) = (editUntil[uid] ?: 0L) > now
}

data class Member(
    val uid: String,
    val name: String,
    val email: String,
    val phone: String,
    val role: String,
    val status: String,
    val joinedAt: Long,
    /** "", "pending", "confirmed" or "disputed" */
    val opening: String,
    val openingNote: String,
) {
    val isStaff get() = role == Role.ADMIN || role == Role.CO
    val initials: String
        get() = name.trim().split(" ").filter { it.isNotBlank() }.take(2)
            .joinToString("") { it.first().uppercase() }.ifBlank { "?" }
}

data class HistoryItem(
    val action: String, // added, edited, deleted
    val by: String,
    val at: Long,
    val reason: String,
    val detail: String,
)

data class Txn(
    val id: String,
    val type: String,
    val memberUid: String,
    val memberName: String,
    val amount: Double,
    val principal: Double,
    val interest: Double,
    val loanId: String,
    val month: String,
    val note: String,
    /** The date the money actually changed hands (can be back-dated only with permission). */
    val date: Long,
    /** When it was typed into the app. */
    val createdAt: Long,
    val createdBy: String,
    val createdByName: String,
    val backdated: Boolean,
    val deleted: Boolean,
    val edited: Boolean,
    val history: List<HistoryItem>,
)

data class Loan(
    val id: String,
    val memberUid: String,
    val memberName: String,
    val principal: Double,
    val rate: Double,
    val months: Int,
    val method: String, // flat / reducing
    val startDate: Long,
    val status: String, // active / closed
    val opening: Boolean,
    val createdByName: String,
    val note: String,
)

data class Meeting(
    val id: String,
    val date: Long,
    val title: String,
    val notes: String,
    val attendees: List<String>,
    val createdByName: String,
)

data class Activity(
    val id: String,
    val at: Long,
    val kind: String,
    val text: String,
    val textHi: String,
    val actorName: String,
    val affectedUid: String,
)

data class InboxMsg(
    val id: String,
    val toUid: String,
    val title: String,
    val body: String,
    val titleHi: String,
    val bodyHi: String,
    val at: Long,
    val kind: String,
    val fromUid: String,
)

/** A vote to choose a new admin. Votes are secret: only the counts are stored here. */
data class Proposal(
    val id: String,
    val candidateUid: String,
    val candidateName: String,
    val proposedByName: String,
    val reason: String,
    val at: Long,
    val status: String, // open, passed, failed
    val yes: Int,
    val no: Int,
    val total: Int,
    val eligible: List<String>,
    val closedAt: Long,
) {
    val needed: Int get() = total / 2 + 1
    val waiting: Int get() = (total - yes - no).coerceAtLeast(0)
}

data class JoinRequest(val uid: String, val name: String, val email: String, val at: Long)

data class Invite(val email: String, val addedByName: String, val at: Long)

/** A message in both languages. */
data class Msg(val en: String, val hi: String)

// ---------- Firestore parsing helpers ----------

private fun DocumentSnapshot.s(k: String) = getString(k) ?: ""
private fun DocumentSnapshot.d(k: String) = (get(k) as? Number)?.toDouble() ?: 0.0
private fun DocumentSnapshot.l(k: String): Long {
    val v = get(k)
    return when (v) {
        is Number -> v.toLong()
        is com.google.firebase.Timestamp -> v.toDate().time
        else -> 0L
    }
}
private fun DocumentSnapshot.b(k: String) = getBoolean(k) ?: false

private fun anyToLong(v: Any?): Long = when (v) {
    is Number -> v.toLong()
    is com.google.firebase.Timestamp -> v.toDate().time
    else -> 0L
}
private fun anyToDouble(v: Any?): Double = (v as? Number)?.toDouble() ?: 0.0

@Suppress("UNCHECKED_CAST")
private fun DocumentSnapshot.longMap(k: String): Map<String, Long> {
    val m = get(k) as? Map<String, Any?> ?: return emptyMap()
    return m.mapValues { anyToLong(it.value) }
}

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toGroup(): Group {
    val a = get("alerts") as? Map<String, Any?> ?: emptyMap()
    val sm = get("summary") as? Map<String, Any?> ?: emptyMap()
    return Group(
        id = id,
        name = s("name"),
        adminUid = s("adminUid"),
        adminName = s("adminName"),
        coAdminUid = s("coAdminUid"),
        coAdminName = s("coAdminName"),
        monthlySaving = d("monthlySaving"),
        dueDay = l("dueDay").toInt().coerceIn(1, 28),
        interestRate = d("interestRate"),
        interestMethod = s("interestMethod").ifBlank { "flat" },
        lateFine = d("lateFine"),
        maxSize = l("maxSize").toInt(),
        inviteCode = s("inviteCode"),
        colour = s("colour").ifBlank { "plum" },
        colourLocked = getBoolean("colourLocked") ?: true,
        createdAt = l("createdAt"),
        setupUntil = l("setupUntil"),
        setupClosed = b("setupClosed"),
        alerts = Alerts(
            savingDue = a["savingDue"] as? Boolean ?: true,
            emi = a["emi"] as? Boolean ?: true,
            meeting = a["meeting"] as? Boolean ?: true,
            lowCash = a["lowCash"] as? Boolean ?: false,
            lowCashLimit = (a["lowCashLimit"] as? Number)?.toDouble() ?: 5000.0,
            joinRequest = a["joinRequest"] as? Boolean ?: true,
        ),
        backdateUntil = longMap("backdateUntil"),
        editUntil = longMap("editUntil"),
        summary = Summary(
            fund = anyToDouble(sm["fund"]), cash = anyToDouble(sm["cash"]),
            lent = anyToDouble(sm["lent"]), profit = anyToDouble(sm["profit"]),
            savings = anyToDouble(sm["savings"]),
            activeLoans = anyToLong(sm["activeLoans"]).toInt(),
            updatedAt = anyToLong(sm["updatedAt"]),
        ),
        lastCloseAt = l("lastCloseAt"),
        lowCashFlag = b("lowCashFlag"),
        activeProposalId = s("activeProposalId"),
        adminAccepted = getBoolean("adminAccepted") ?: true,
    )
}

fun DocumentSnapshot.toMember() = Member(
    uid = id,
    name = s("name"),
    email = s("email"),
    phone = s("phone"),
    role = s("role").ifBlank { Role.MEMBER },
    status = s("status").ifBlank { MemberStatus.ACTIVE },
    joinedAt = l("joinedAt"),
    opening = s("opening"),
    openingNote = s("openingNote"),
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toTxn(): Txn {
    val h = (get("history") as? List<Map<String, Any?>>) ?: emptyList()
    return Txn(
        id = id,
        type = s("type"),
        memberUid = s("memberUid"),
        memberName = s("memberName"),
        amount = d("amount"),
        principal = d("principal"),
        interest = d("interest"),
        loanId = s("loanId"),
        month = s("month"),
        note = s("note"),
        date = l("date"),
        createdAt = l("createdAt").takeIf { it > 0 } ?: l("date"),
        createdBy = s("createdBy"),
        createdByName = s("createdByName"),
        backdated = b("backdated"),
        deleted = b("deleted"),
        edited = b("edited"),
        history = h.map {
            HistoryItem(
                action = it["action"] as? String ?: "",
                by = it["by"] as? String ?: "",
                at = anyToLong(it["at"]),
                reason = it["reason"] as? String ?: "",
                detail = it["detail"] as? String ?: "",
            )
        },
    )
}

fun DocumentSnapshot.toLoan() = Loan(
    id = id,
    memberUid = s("memberUid"),
    memberName = s("memberName"),
    principal = d("principal"),
    rate = d("rate"),
    months = l("months").toInt().coerceAtLeast(1),
    method = s("method").ifBlank { "flat" },
    startDate = l("startDate"),
    status = s("status").ifBlank { "active" },
    opening = b("opening"),
    createdByName = s("createdByName"),
    note = s("note"),
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toMeeting() = Meeting(
    id = id,
    date = l("date"),
    title = s("title"),
    notes = s("notes"),
    attendees = (get("attendees") as? List<String>) ?: emptyList(),
    createdByName = s("createdByName"),
)

fun DocumentSnapshot.toActivity() = Activity(
    id = id,
    at = l("at"),
    kind = s("kind"),
    text = s("text"),
    textHi = s("textHi"),
    actorName = s("actorName"),
    affectedUid = s("affectedUid"),
)

fun DocumentSnapshot.toInbox() = InboxMsg(
    id = id,
    toUid = s("toUid"),
    title = s("title"),
    body = s("body"),
    titleHi = s("titleHi"),
    bodyHi = s("bodyHi"),
    at = l("at"),
    kind = s("kind"),
    fromUid = s("fromUid"),
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toProposal() = Proposal(
    id = id,
    candidateUid = s("candidateUid"),
    candidateName = s("candidateName"),
    proposedByName = s("proposedByName"),
    reason = s("reason"),
    at = l("at"),
    status = s("status").ifBlank { "open" },
    yes = l("yes").toInt(),
    no = l("no").toInt(),
    total = l("total").toInt().coerceAtLeast(1),
    eligible = (get("eligible") as? List<String>) ?: emptyList(),
    closedAt = l("closedAt"),
)

fun DocumentSnapshot.toJoinRequest() = JoinRequest(id, s("name"), s("email"), l("at"))
fun DocumentSnapshot.toInvite() = Invite(id, s("addedByName"), l("at"))
