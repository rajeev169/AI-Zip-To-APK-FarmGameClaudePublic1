package com.rajeev.samuhkhata.core

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.rajeev.samuhkhata.MainActivity
import com.rajeev.samuhkhata.R

object Notifier {
    const val CH_UPDATES = "updates"
    const val CH_REMINDERS = "reminders"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_UPDATES, "Group updates", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Entries, edits, permissions and role changes"
        })
        nm.createNotificationChannel(NotificationChannel(CH_REMINDERS, "Reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Saving due, EMI due and meeting reminders"
        })
    }

    private fun allowed(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun show(ctx: Context, tag: String, title: String, body: String, channel: String = CH_UPDATES) {
        if (!allowed(ctx)) return
        val intent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openInbox", true)
        }
        val pi = PendingIntent.getActivity(ctx, tag.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setPriority(if (channel == CH_UPDATES) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(tag.hashCode(), n)
        } catch (e: SecurityException) {
            // Permission was removed while running; ignore.
        }
    }

    fun showInbox(ctx: Context, m: InboxMsg) {
        val title = if (Prefs.hindi && m.titleHi.isNotBlank()) m.titleHi else m.title
        val body = if (Prefs.hindi && m.bodyHi.isNotBlank()) m.bodyHi else m.body
        show(ctx, "inbox_${m.id}", title, body)
    }
}
