package com.rajeev.samuhkhata.core

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Settings that belong to this phone only (language, light/dark, personal colour, own alerts). */
object Prefs {
    private lateinit var sp: SharedPreferences

    var hindi by mutableStateOf(false)
        private set
    var mode by mutableStateOf("system")
        private set
    var personalColour by mutableStateOf("")
        private set

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("samuh_prefs", Context.MODE_PRIVATE)
        hindi = sp.getString("lang", "en") == "hi"
        mode = sp.getString("mode", "system") ?: "system"
        personalColour = sp.getString("colour", "") ?: ""
    }

    fun setLanguage(hi: Boolean) { hindi = hi; sp.edit().putString("lang", if (hi) "hi" else "en").apply() }
    fun setMode(m: String) { mode = m; sp.edit().putString("mode", m).apply() }
    fun setColour(c: String) { personalColour = c; sp.edit().putString("colour", c).apply() }

    fun alertOn(key: String): Boolean = sp.getBoolean("alert_$key", true)
    fun setAlert(key: String, on: Boolean) { sp.edit().putBoolean("alert_$key", on).apply() }

    var lastNotifiedAt: Long
        get() = sp.getLong("lastNotifiedAt", 0L)
        set(v) { sp.edit().putLong("lastNotifiedAt", v).apply() }

    var lastSeenInbox: Long
        get() = sp.getLong("lastSeenInbox", 0L)
        set(v) { sp.edit().putLong("lastSeenInbox", v).apply() }

    fun reminderDone(key: String) = sp.getBoolean("rem_$key", false)
    fun markReminder(key: String) { sp.edit().putBoolean("rem_$key", true).apply() }

    var appliedIcon: String
        get() = sp.getString("appliedIcon", "plum") ?: "plum"
        set(v) { sp.edit().putString("appliedIcon", v).apply() }

    var lastGroupId: String
        get() = sp.getString("lastGroupId", "") ?: ""
        set(v) { sp.edit().putString("lastGroupId", v).apply() }
}

/** Pick the text for the current language. */
fun tx(en: String, hi: String) = if (Prefs.hindi) hi else en
fun Msg.text() = if (Prefs.hindi) hi else en
