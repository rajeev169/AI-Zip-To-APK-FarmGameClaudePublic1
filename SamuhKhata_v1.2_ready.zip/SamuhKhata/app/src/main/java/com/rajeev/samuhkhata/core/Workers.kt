package com.rajeev.samuhkhata.core

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

/**
 * Runs every ~15 minutes in the background (free, no server needed):
 * shows new group notifications and saving / EMI / meeting reminders.
 */
class SyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val user = FirebaseAuth.getInstance().currentUser ?: return Result.success()
        val gid = Prefs.lastGroupId
        if (gid.isBlank()) return Result.success()
        return try {
            val db = FirebaseFirestore.getInstance()
            val gref = db.collection("groups").document(gid)
            val gs = gref.get().await()
            if (!gs.exists()) return Result.success()
            val group = gs.toGroup()
            val ms = gref.collection("members").document(user.uid).get().await()
            if (!ms.exists()) return Result.success()
            val me = ms.toMember()

            // New notifications
            val last = Prefs.lastNotifiedAt
            val mine = gref.collection("inbox").whereEqualTo("toUid", user.uid).get().await().documents.map { it.toInbox() }
            val all = gref.collection("inbox").whereEqualTo("toUid", "all").get().await().documents.map { it.toInbox() }
            val fresh = (mine + all).distinctBy { it.id }.filter { it.at > last }.sortedBy { it.at }
            fresh.forEach { if (it.fromUid != user.uid && Session.shouldShow(it)) Notifier.showInbox(applicationContext, it) }
            if (fresh.isNotEmpty()) Prefs.lastNotifiedAt = fresh.maxOf { it.at }

            // Reminders for this member
            val txns = gref.collection("txns").whereEqualTo("memberUid", user.uid).get().await().documents.map { it.toTxn() }
            val loans = gref.collection("loans").whereEqualTo("memberUid", user.uid).get().await().documents.map { it.toLoan() }
            val meetings = gref.collection("meetings").get().await().documents.map { it.toMeeting() }
            Reminders.check(applicationContext, group, me, txns, loans, meetings)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("samuh_sync", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}

object Reminders {
    fun check(ctx: Context, g: Group, me: Member, myTxns: List<Txn>, myLoans: List<Loan>, meetings: List<Meeting>) {
        if (me.status == MemberStatus.LEFT) return
        val now = System.currentTimeMillis()
        val month = Calc.monthKey(now)
        val due = Calc.dueDateOf(month, g.dueDay)

        // Saving due (2 days before) and overdue (fine applies)
        if (g.alerts.savingDue && Prefs.alertOn("saving") && !Calc.paidSaving(me.uid, month, myTxns)) {
            if (now in (due - 3 * Calc.DAY)..due && !Prefs.reminderDone("save_$month")) {
                Notifier.show(ctx, "save_$month", tx("Saving due", "बचत जमा करें"),
                    tx("${Calc.rupees(g.monthlySaving)} saving is due by ${Calc.shortDate(due)}",
                        "${Calc.rupees(g.monthlySaving)} बचत ${Calc.shortDate(due)} तक जमा करें"), Notifier.CH_REMINDERS)
                Prefs.markReminder("save_$month")
            } else if (now > due && !Prefs.reminderDone("saveLate_$month")) {
                Notifier.show(ctx, "saveLate_$month", tx("Saving overdue", "बचत बाकी"),
                    tx("Your ${Calc.shortMonth(month)} saving is pending. Late fine ${Calc.rupees(g.lateFine)} applies.",
                        "आपकी ${Calc.shortMonth(month, true)} की बचत बाकी है। देर का जुर्माना ${Calc.rupees(g.lateFine)} लगेगा।"), Notifier.CH_REMINDERS)
                Prefs.markReminder("saveLate_$month")
            }
        }

        // EMI due / overdue
        if (g.alerts.emi && Prefs.alertOn("emi")) {
            myLoans.filter { it.status == "active" }.forEach { loan ->
                val out = Calc.outstanding(loan, myTxns)
                if (out <= 0.5) return@forEach
                val next = Calc.nextDueDate(loan, out)
                val emi = Calc.nextEmi(loan, out)
                val k = Calc.instalmentsPaid(loan, out)
                if (now in (next - 2 * Calc.DAY)..next && !Prefs.reminderDone("emi_${loan.id}_$k")) {
                    Notifier.show(ctx, "emi_${loan.id}_$k", tx("EMI due", "किस्त जमा करें"),
                        tx("Loan EMI ${Calc.rupees(emi)} is due on ${Calc.shortDate(next)}", "लोन किस्त ${Calc.rupees(emi)} ${Calc.shortDate(next)} को जमा करें"), Notifier.CH_REMINDERS)
                    Prefs.markReminder("emi_${loan.id}_$k")
                } else if (now > next + Calc.DAY && !Prefs.reminderDone("emiLate_${loan.id}_$k")) {
                    Notifier.show(ctx, "emiLate_${loan.id}_$k", tx("EMI overdue", "किस्त बकाया"),
                        tx("Your loan EMI ${Calc.rupees(emi)} was due on ${Calc.shortDate(next)}", "आपकी लोन किस्त ${Calc.rupees(emi)} ${Calc.shortDate(next)} को देनी थी"), Notifier.CH_REMINDERS)
                    Prefs.markReminder("emiLate_${loan.id}_$k")
                }
            }
        }

        // Meeting tomorrow
        if (g.alerts.meeting && Prefs.alertOn("meeting")) {
            meetings.filter { it.date in now..(now + Calc.DAY) }.forEach { m ->
                if (!Prefs.reminderDone("meet_${m.id}")) {
                    Notifier.show(ctx, "meet_${m.id}", tx("Meeting reminder", "बैठक की याद"),
                        "${m.title} · ${Calc.dateTime(m.date)}", Notifier.CH_REMINDERS)
                    Prefs.markReminder("meet_${m.id}")
                }
            }
        }
    }
}
