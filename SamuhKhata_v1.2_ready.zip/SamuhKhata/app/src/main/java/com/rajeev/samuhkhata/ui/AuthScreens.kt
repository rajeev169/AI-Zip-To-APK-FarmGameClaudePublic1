package com.rajeev.samuhkhata.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rajeev.samuhkhata.R
import com.rajeev.samuhkhata.core.Prefs
import com.rajeev.samuhkhata.core.Repo
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.tx
import kotlinx.coroutines.launch

@Composable
private fun LangSwitch() {
    Segmented(listOf("en" to "English", "hi" to "हिंदी"), if (Prefs.hindi) "hi" else "en") { Prefs.setLanguage(it == "hi") }
}

@Composable
private fun Logo() {
    Box(Modifier.size(112.dp).clip(RoundedCornerShape(28.dp)).background(LocalExtra.current.header), contentAlignment = Alignment.Center) {
        Image(painterResource(R.drawable.ic_fg_plum), null, Modifier.size(150.dp))
    }
}

@Composable
fun LoginScreen(onGoogle: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        LangSwitch()
        Gap(24.dp)
        Logo()
        Text(tx("Samuh Khata", "समूह खाता"), style = MaterialTheme.typography.headlineSmall)
        Text(
            tx("Savings, loans and records for your village savings group — honest and easy for everyone.",
                "आपके गाँव के बचत समूह की बचत, लोन और हिसाब — सबके लिए आसान और ईमानदार।"),
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Gap(16.dp)
        PrimaryButton(tx("Sign in with Google", "Google से साइन इन करें"), onClick = onGoogle)
        Text(tx("Use the same Gmail on any phone and all your records come back.",
            "किसी भी फ़ोन पर वही Gmail इस्तेमाल करें, आपका पूरा हिसाब वापस आ जाएगा।"),
            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun NoGroupScreen(onSignOut: () -> Unit) {
    var mode by remember { mutableStateOf("") }
    when (mode) {
        "create" -> CreateGroupScreen(onBack = { mode = "" })
        "join" -> JoinCodeScreen(onBack = { mode = "" })
        else -> Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            LangSwitch()
            Gap(16.dp)
            Logo()
            Text(tx("Namaste, ${Session.user?.displayName ?: ""}", "नमस्ते, ${Session.user?.displayName ?: ""}"), style = MaterialTheme.typography.titleLarge)
            Text(Session.user?.email ?: "", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (Session.rejected) Banner(tx("Your join request was not approved by the admin.", "एडमिन ने आपका अनुरोध मंज़ूर नहीं किया।"))
            Text(tx("If your admin added your Gmail, you would join automatically. Otherwise:",
                "अगर एडमिन ने आपका Gmail जोड़ा होता तो आप अपने आप जुड़ जाते। नहीं तो:"),
                textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            PrimaryButton(tx("Join a group with invite code", "इनवाइट कोड से समूह से जुड़ें")) { mode = "join" }
            SecondaryButton(tx("Create a new group (I am the admin)", "नया समूह बनाएं (मैं एडमिन हूँ)")) { mode = "create" }
            SecondaryButton(tx("Check again", "फिर से जाँचें")) { Session.restart() }
            TextButton(onClick = onSignOut) { Text(tx("Use another Google account", "दूसरा Google खाता इस्तेमाल करें")) }
        }
    }
}

@Composable
private fun CreateGroupScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var admin by remember { mutableStateOf(Session.user?.displayName ?: "") }
    var phone by remember { mutableStateOf("") }
    var monthly by remember { mutableStateOf("500") }
    var due by remember { mutableStateOf("5") }
    var rate by remember { mutableStateOf("2") }
    var method by remember { mutableStateOf("flat") }
    var fine by remember { mutableStateOf("50") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    Page(tx("Create group", "समूह बनाएं"), onBack = onBack, bottom = {
        PrimaryButton(if (busy) tx("Creating…", "बन रहा है…") else tx("Create group", "समूह बनाएं"), enabled = !busy) {
            val m = monthly.money(); val d = due.toIntOrNull(); val r = rate.money(); val f = fine.money()
            err = when {
                name.isBlank() || admin.isBlank() -> tx("Enter group name and your name", "समूह का नाम और अपना नाम लिखें")
                m == null || m <= 0 -> tx("Enter monthly saving amount", "मासिक बचत राशि लिखें")
                d == null || d !in 1..28 -> tx("Due day must be 1 to 28", "जमा तारीख 1 से 28 हो")
                r == null || r < 0 -> tx("Enter interest rate", "ब्याज दर लिखें")
                f == null || f < 0 -> tx("Enter late fine (0 for none)", "देर का जुर्माना लिखें (नहीं तो 0)")
                else -> ""
            }
            if (err.isBlank()) {
                busy = true
                scope.launch {
                    try {
                        val u = Session.user ?: return@launch
                        val gid = Repo.createGroup(u, name.trim(), admin.trim(), phone.trim(), m!!, d!!, r!!, method, f!!)
                        Session.restart()
                        if (gid.isBlank()) busy = false
                    } catch (e: Exception) {
                        busy = false
                        err = tx("Could not create. Check internet. ", "नहीं बना। इंटरनेट जाँचें। ") + (e.message ?: "")
                    }
                }
            }
        }
    }) {
        item {
            SectionCard(tx("Group", "समूह")) {
                Field(tx("Group name", "समूह का नाम"), name, { name = it })
                Field(tx("Your name (admin)", "आपका नाम (एडमिन)"), admin, { admin = it })
                Field(tx("Your phone number", "आपका फ़ोन नंबर"), phone, { phone = it }, number = true)
            }
        }
        item {
            SectionCard(tx("Rules", "नियम")) {
                Field(tx("Monthly saving (₹)", "मासिक बचत (₹)"), monthly, { monthly = it }, number = true)
                Field(tx("Saving due by day of month (1–28)", "हर महीने जमा की तारीख (1–28)"), due, { due = it }, number = true)
                Field(tx("Loan interest % per month", "लोन ब्याज % प्रति माह"), rate, { rate = it }, number = true)
                Text(tx("Interest method", "ब्याज का तरीका"), style = MaterialTheme.typography.bodyMedium)
                Segmented(listOf("flat" to tx("Flat", "फ्लैट"), "reducing" to tx("Reducing", "घटता हुआ")), method) { method = it }
                Text(if (method == "flat") tx("Flat: interest every month on the full loan amount.", "फ्लैट: हर महीने पूरे लोन पर ब्याज।")
                else tx("Reducing: interest only on the loan still due.", "घटता हुआ: सिर्फ़ बाकी लोन पर ब्याज।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Field(tx("Late fine (₹)", "देर का जुर्माना (₹)"), fine, { fine = it }, number = true)
            }
        }
        item {
            Banner(tx("Old group with notebook records? After creating, use ☰ → Old Records Setup (open for 30 days).",
                "पुराना समूह है? बनाने के बाद ☰ → पुराने रिकॉर्ड सेटअप से पुराना हिसाब डालें (30 दिन तक खुला)।"), warn = false)
        }
        if (err.isNotBlank()) item { Banner(err) }
    }
}

@Composable
private fun JoinCodeScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    Page(tx("Join with code", "कोड से जुड़ें"), onBack = onBack, bottom = {
        PrimaryButton(if (busy) tx("Sending…", "भेज रहे हैं…") else tx("Send join request", "जुड़ने का अनुरोध भेजें"), enabled = !busy && code.trim().length == 6) {
            busy = true; err = ""
            scope.launch {
                try {
                    val u = Session.user ?: return@launch
                    val name = Repo.requestJoin(u, code.trim())
                    if (name == null) { err = tx("Wrong code. Ask your admin for the 6-digit code.", "गलत कोड। एडमिन से 6 अंकों का कोड पूछें।"); busy = false }
                    else Session.restart()
                } catch (e: Exception) {
                    busy = false
                    err = tx("Could not send. Check internet. ", "नहीं भेजा गया। इंटरनेट जाँचें। ") + (e.message ?: "")
                }
            }
        }
    }) {
        item {
            SectionCard {
                Text(tx("Enter the 6-digit invite code your admin shared on WhatsApp.", "एडमिन ने WhatsApp पर जो 6 अंकों का कोड भेजा, वह लिखें।"))
                Field(tx("Invite code", "इनवाइट कोड"), code, { code = it.filter { c -> c.isDigit() }.take(6) }, number = true)
                Text(tx("The admin will approve your request.", "एडमिन आपके अनुरोध को मंज़ूरी देंगे।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (err.isNotBlank()) item { Banner(err) }
    }
}

@Composable
fun WaitingScreen(onSignOut: () -> Unit) {
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
    ) {
        CircularProgressIndicator()
        Text(tx("Waiting for admin approval", "एडमिन की मंज़ूरी का इंतज़ार"), style = MaterialTheme.typography.titleLarge)
        Text(tx("Your request to join ${Session.pendingGroupName} was sent. This screen opens your group as soon as the admin approves.",
            "${Session.pendingGroupName} से जुड़ने का अनुरोध भेजा गया। एडमिन के मंज़ूर करते ही आपका समूह खुल जाएगा।"),
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        SecondaryButton(tx("Cancel request", "अनुरोध रद्द करें")) {
            scope.launch {
                try { Repo.cancelRequest(Session.pendingGroupId) } catch (e: Exception) { Session.error = e.message }
                Session.restart()
            }
        }
        TextButton(onClick = onSignOut) { Text(tx("Sign out", "साइन आउट")) }
    }
}

@Composable
fun RemovedScreen(onSignOut: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
    ) {
        Text(tx("You are no longer in this group", "आप अब इस समूह में नहीं हैं"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(tx("The admin removed you or your leave was completed. You can join or create another group.",
            "एडमिन ने आपको हटाया या आपका समूह छोड़ना पूरा हुआ। आप दूसरे समूह से जुड़ या बना सकते हैं।"),
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        val scope = rememberCoroutineScope()
        PrimaryButton(tx("Continue", "आगे बढ़ें")) {
            scope.launch {
                try { Repo.clearRemoved() } catch (e: Exception) { Session.error = e.message }
                Session.restart()
            }
        }
        TextButton(onClick = onSignOut) { Text(tx("Sign out", "साइन आउट")) }
    }
}
