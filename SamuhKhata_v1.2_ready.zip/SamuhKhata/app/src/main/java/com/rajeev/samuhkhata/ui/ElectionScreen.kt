package com.rajeev.samuhkhata.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rajeev.samuhkhata.core.Calc
import com.rajeev.samuhkhata.core.Member
import com.rajeev.samuhkhata.core.Repo
import com.rajeev.samuhkhata.core.Role
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.tx

@Composable
fun ElectionScreen() {
    val g = Session.group ?: return
    val me = Session.me ?: return
    val open = Session.openProposal
    val past = Session.proposals.filter { it.status != "open" }
    var pick by remember { mutableStateOf(false) }
    var candidate by remember { mutableStateOf<Member?>(null) }
    var confirmVote by remember { mutableStateOf<Boolean?>(null) }
    var busy by remember { mutableStateOf(false) }

    Page(tx("Admin Election", "एडमिन चुनाव"), tx("Current admin: ${g.adminName}", "अभी के एडमिन: ${g.adminName}"),
        bottom = if (open == null && me.role == Role.CO) ({ PrimaryButton(tx("Propose new admin", "नया एडमिन प्रस्तावित करें")) { pick = true } }) else null) {

        item {
            SectionCard(tx("How it works", "यह कैसे काम करता है")) {
                Text(tx("1. The co-admin proposes a member as the new admin.", "1. सह-एडमिन किसी सदस्य को नया एडमिन प्रस्तावित करते हैं।"))
                Text(tx("2. Every member votes Yes or No. Votes are secret — only counts are shown.", "2. हर सदस्य हाँ या ना वोट करता है। वोट गुप्त हैं — केवल गिनती दिखती है।"))
                Text(tx("3. As soon as Yes is more than half of all members, admin power moves to the elected member instantly.", "3. जैसे ही हाँ कुल सदस्यों के आधे से ज़्यादा हो, एडमिन शक्ति तुरंत चुने गए सदस्य को मिल जाती है।"))
                Text(tx("4. If Yes can no longer reach a majority, the vote fails immediately.", "4. अगर हाँ बहुमत तक नहीं पहुँच सकता, वोट तुरंत असफल हो जाता है।"))
            }
        }

        if (open != null) {
            item {
                SectionCard(tx("Vote running", "वोट चल रहा है")) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val cm = Session.memberById(open.candidateUid)
                        Avatar(cm?.initials ?: open.candidateName.take(1), size = 48.dp)
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(open.candidateName, style = MaterialTheme.typography.titleMedium)
                            Text(tx("Proposed by ${open.proposedByName} · ${Calc.shortDateTime(open.at)}", "${open.proposedByName} ने प्रस्तावित किया · ${Calc.shortDateTime(open.at)}"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Text(tx("Reason: ${open.reason}", "कारण: ${open.reason}"))
                    LinearProgressIndicator(progress = { (open.yes.toFloat() / open.needed).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(99.dp)))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Stat(tx("Yes", "हाँ"), open.yes.toString(), Modifier.weight(1f), MaterialTheme.colorScheme.primary)
                        Stat(tx("No", "ना"), open.no.toString(), Modifier.weight(1f), LocalExtra.current.warnFg)
                        Stat(tx("Waiting", "बाकी"), open.waiting.toString(), Modifier.weight(1f))
                    }
                    Text(tx("Needs ${open.needed} Yes out of ${open.total} members.", "${open.total} में से ${open.needed} हाँ चाहिए।"), fontWeight = FontWeight.SemiBold)

                    when {
                        Session.uid !in open.eligible -> Text(tx("You joined after this vote started, so you can't vote in it.", "आप इस वोट के शुरू होने के बाद जुड़े, इसलिए वोट नहीं कर सकते।"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Session.myVote.isNotBlank() -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Lock, null, tint = MaterialTheme.colorScheme.primary)
                            Text(tx("  You have voted. Your vote is secret and cannot be changed.", "  आपने वोट कर दिया। आपका वोट गुप्त है और बदला नहीं जा सकता।"))
                        }
                        else -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PrimaryButton(tx("Yes", "हाँ"), enabled = !busy, modifier = Modifier.weight(1f)) { confirmVote = true }
                            SecondaryButton(tx("No", "ना"), modifier = Modifier.weight(1f), color = LocalExtra.current.warnFg) { if (!busy) confirmVote = false }
                        }
                    }
                }
            }
        } else {
            item {
                Banner(if (me.role == Role.CO) tx("No vote is running. As co-admin you can propose a new admin.", "कोई वोट नहीं चल रहा। सह-एडमिन होने के नाते आप नया एडमिन प्रस्तावित कर सकते हैं।")
                else if (g.coAdminUid.isBlank()) tx("No vote is running. A co-admin is needed to start a vote.", "कोई वोट नहीं चल रहा। वोट शुरू करने के लिए सह-एडमिन चाहिए।")
                else tx("No vote is running. Only the co-admin (${g.coAdminName}) can start one.", "कोई वोट नहीं चल रहा। केवल सह-एडमिन (${g.coAdminName}) शुरू कर सकते हैं।"), warn = false)
            }
        }

        item { SectionLabel(tx("Past votes", "पिछले वोट")) }
        if (past.isEmpty()) item { Empty(tx("No past votes", "कोई पिछला वोट नहीं")) }
        items(past, key = { it.id }) { p ->
            SectionCard(padding = 12.dp) {
                ListRow(p.candidateName,
                    tx("${if (p.status == "passed") "✅ Elected" else "❌ Not elected"} · Yes ${p.yes}, No ${p.no} of ${p.total} · ${Calc.date(p.closedAt)}",
                        "${if (p.status == "passed") "✅ चुने गए" else "❌ नहीं चुने गए"} · हाँ ${p.yes}, ना ${p.no} / ${p.total} · ${Calc.date(p.closedAt)}"),
                    chevron = false)
                Text(tx("Reason: ${p.reason}", "कारण: ${p.reason}"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    if (pick) MemberPickerDialog(tx("Who should be the new admin?", "नया एडमिन कौन हो?"),
        Session.activeMembers.filter { it.uid != g.adminUid }, { pick = false }) { candidate = it }

    candidate?.let { c ->
        var reason by remember(c.uid) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { candidate = null },
            title = { Text(tx("Propose ${c.name} as admin?", "${c.name} को एडमिन प्रस्तावित करें?")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tx("All ${Session.activeMembers.size} members will be asked to vote. Needs ${Session.activeMembers.size / 2 + 1} Yes.",
                        "सभी ${Session.activeMembers.size} सदस्यों से वोट माँगा जाएगा। ${Session.activeMembers.size / 2 + 1} हाँ चाहिए।"))
                    Field(tx("Reason (shown to everyone)", "कारण (सबको दिखेगा)"), reason, { reason = it }, singleLine = false, minLines = 2)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val err = Repo.proposeAdmin(c, reason.trim())
                    if (err != null) Session.error = err else candidate = null
                }) { Text(tx("Start vote", "वोट शुरू करें")) }
            },
            dismissButton = { TextButton(onClick = { candidate = null }) { Text(tx("Cancel", "रद्द करें")) } },
        )
    }

    val cv = confirmVote
    if (cv != null && open != null) ConfirmDialog(
        if (cv) tx("Vote Yes for ${open.candidateName}?", "${open.candidateName} के लिए हाँ?") else tx("Vote No?", "ना वोट करें?"),
        tx("Your vote is secret and cannot be changed.", "आपका वोट गुप्त है और बदला नहीं जा सकता।"),
        tx("Vote", "वोट करें"), { confirmVote = null }) {
        busy = true
        Repo.vote(open, cv) { err -> busy = false; if (err != null) Session.error = err else Session.toast = tx("Vote saved", "वोट सेव हुआ") }
    }
}
