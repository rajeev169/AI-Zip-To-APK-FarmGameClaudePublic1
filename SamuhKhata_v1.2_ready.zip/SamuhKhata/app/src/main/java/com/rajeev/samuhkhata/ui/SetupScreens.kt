package com.rajeev.samuhkhata.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rajeev.samuhkhata.core.Calc
import com.rajeev.samuhkhata.core.Exporter
import com.rajeev.samuhkhata.core.Repo
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.TxType
import com.rajeev.samuhkhata.core.tx

@Composable
fun OldRecordsScreen() {
    val g = Session.group ?: return
    val ctx = LocalContext.current
    val open = g.setupOpen()
    val admin = Session.isAdmin
    var close by remember { mutableStateOf(false) }
    var oldCash by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<Pair<List<Repo.ImportRow>, List<String>>?>(null) }
    val upload = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                preview = Exporter.parseImport(text, Session.members)
            } catch (e: Exception) { Session.error = e.message }
        }
    }

    Page(tx("Old Records Setup", "पुराने रिकॉर्ड सेटअप"),
        if (open) tx("Open till ${Calc.date(g.setupUntil)}", "${Calc.date(g.setupUntil)} तक खुला") else tx("Closed · back-dating locked", "बंद · पिछली तारीख लॉक"),
        bottom = if (open && admin) ({ SecondaryButton(tx("Close setup now (lock back-dating)", "सेटअप अभी बंद करें (पिछली तारीख लॉक)"), color = LocalExtra.current.badFg) { close = true } }) else null) {
        if (!open) item {
            Banner(tx("Setup is closed. Old records can no longer be added, so no one can add hidden old entries later.", "सेटअप बंद है। अब पुराने रिकॉर्ड नहीं जुड़ सकते, ताकि कोई बाद में छिपी पुरानी एंट्री न डाल सके।"), Icons.Outlined.Lock, warn = false)
        } else item {
            Banner(tx("For groups that already ran on a notebook. Choose any way below. Every old entry shows two dates: the date in the register and the date it was added to the app.",
                "जो समूह पहले नोटबुक पर चलते थे। नीचे कोई भी तरीका चुनें। हर पुरानी एंट्री में दो तारीख दिखती हैं: रजिस्टर की तारीख और ऐप में जोड़ने की तारीख।"), Icons.Outlined.History, warn = false)
        }

        item {
            SectionCard(tx("1 · Opening balance (fastest)", "1 · शुरुआती बैलेंस (सबसे तेज़)")) {
                Text(tx("For each member enter: total saved so far, loan still due (rate, months left), interest paid so far. Each member is asked to Confirm or Report a mistake.",
                    "हर सदस्य के लिए डालें: अब तक की कुल बचत, बाकी लोन (ब्याज, बचे महीने), अब तक भरा ब्याज। हर सदस्य से पुष्टि या गलती बताने को कहा जाएगा।"), style = MaterialTheme.typography.bodySmall)
                Session.activeMembers.forEach { m ->
                    Divider()
                    ListRow(m.name, when (m.opening) {
                        "pending" -> tx("Waiting for confirmation", "पुष्टि का इंतज़ार")
                        "confirmed" -> tx("Confirmed ✅", "पुष्टि हुई ✅")
                        "disputed" -> tx("Mistake reported: ${m.openingNote}", "गलती बताई: ${m.openingNote}")
                        else -> tx("Not entered", "नहीं डाला")
                    }, badge = if (m.opening == "disputed") tx("Check", "जाँचें") else null, onClick = { Nav.go(Screen.Opening(m.uid)) })
                }
            }
        }

        if (open && admin) item {
            SectionCard(tx("Group money before the app", "ऐप से पहले का समूह पैसा")) {
                Text(tx("Other profit the group made before (e.g. from a small business). Interest and fines are entered per member above.",
                    "समूह का पहले का दूसरा मुनाफ़ा (जैसे छोटे व्यापार से)। ब्याज और जुर्माना ऊपर हर सदस्य में डालें।"), style = MaterialTheme.typography.bodySmall)
                Field(tx("Old group income (₹)", "पुरानी समूह आय (₹)"), oldCash, { oldCash = it }, number = true)
                PrimaryButton(tx("Add as old income", "पुरानी आय के रूप में जोड़ें"), enabled = (oldCash.money() ?: 0.0) > 0) {
                    Repo.addCashEntry(TxType.INCOME, oldCash.money() ?: 0.0, tx("Group income before using the app", "ऐप से पहले की समूह आय"), System.currentTimeMillis() - Calc.DAY)
                    oldCash = ""
                }
            }
        }

        item {
            SectionCard(tx("2 · Full old history (back-dated entries)", "2 · पूरा पुराना इतिहास (पिछली तारीख की एंट्री)")) {
                Text(if (open) tx("While setup is open, the date box in Add Saving, New Loan, Repayment and Cash Book can be set to the real date from the notebook.",
                    "सेटअप खुला रहने तक बचत, लोन, किस्त और कैश बुक में तारीख नोटबुक की असली तारीख रख सकते हैं।")
                else tx("After setup, back-dating needs a timed permission from the co-admin (☰ → Permissions).", "सेटअप के बाद पिछली तारीख के लिए सह-एडमिन की अनुमति चाहिए (☰ → अनुमतियाँ)।"), style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton(tx("Savings", "बचत"), modifier = Modifier.weight(1f)) { Nav.go(Screen.Savings) }
                    SecondaryButton(tx("Loans", "लोन"), modifier = Modifier.weight(1f)) { Nav.go(Screen.NewLoan()) }
                    SecondaryButton(tx("Cash", "नकद"), modifier = Modifier.weight(1f)) { Nav.go(Screen.CashBook) }
                }
            }
        }

        item {
            SectionCard(tx("3 · Upload from Excel", "3 · Excel से अपलोड")) {
                Text(tx("Fill the template (date, member, type, amount, note) in Excel or Google Sheets, save as CSV and upload. Types: saving, fine, income, expense. Dates as YYYY-MM-DD.",
                    "टेम्पलेट (तारीख, सदस्य, प्रकार, राशि, नोट) Excel या Google Sheets में भरें, CSV में सेव करके अपलोड करें। प्रकार: saving, fine, income, expense। तारीख YYYY-MM-DD में।"), style = MaterialTheme.typography.bodySmall)
                SecondaryButton(tx("Get the template", "टेम्पलेट लें")) { Exporter.share(ctx, Exporter.templateCsv(ctx, Session.activeMembers), "text/csv") }
                PrimaryButton(tx("Upload CSV file", "CSV फ़ाइल अपलोड करें"), enabled = open && admin) { upload.launch("*/*") }
            }
        }
    }

    preview?.let { (rows, errors) ->
        AlertDialog(
            onDismissRequest = { preview = null },
            title = { Text(tx("Upload old records", "पुराने रिकॉर्ड अपलोड")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(tx("${rows.size} entries ready · total ${Calc.rupees(rows.sumOf { it.amount })}", "${rows.size} एंट्री तैयार · कुल ${Calc.rupees(rows.sumOf { it.amount })}"), fontWeight = FontWeight.SemiBold)
                    if (errors.isNotEmpty()) {
                        Text(tx("${errors.size} lines skipped:", "${errors.size} लाइन छोड़ी गईं:"), color = LocalExtra.current.warnFg)
                        errors.take(8).forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                    }
                    Text(tx("All members will be notified.", "सभी सदस्यों को सूचना जाएगी।"), style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(enabled = rows.isNotEmpty(), onClick = { Repo.importRows(rows)?.let { Session.error = it }; preview = null }) { Text(tx("Import", "इम्पोर्ट करें")) } },
            dismissButton = { TextButton(onClick = { preview = null }) { Text(tx("Cancel", "रद्द करें")) } },
        )
    }
    if (close) ConfirmDialog(tx("Close Old Records Setup?", "पुराने रिकॉर्ड सेटअप बंद करें?"),
        tx("Back-dating will lock for everyone. After this it needs the co-admin's timed permission. All members are notified.", "सबके लिए पिछली तारीख लॉक हो जाएगी। इसके बाद सह-एडमिन की अनुमति चाहिए। सभी को सूचना जाएगी।"),
        tx("Close setup", "सेटअप बंद करें"), { close = false }) { Repo.closeSetup() }
}

@Composable
fun OpeningScreen(uid: String) {
    val g = Session.group ?: return
    val m = Session.memberById(uid) ?: return
    val txns = Session.txns
    val existing = Calc.live(txns).filter { it.memberUid == uid && (it.type == TxType.OPEN_SAVING || it.type == TxType.OPEN_INTEREST) }
    val existingLoans = Session.loans.filter { it.memberUid == uid && it.opening && it.status != "cancelled" }
    val entered = existing.isNotEmpty() || existingLoans.isNotEmpty()
    var saved by remember { mutableStateOf("") }
    var interest by remember { mutableStateOf("") }
    var loan by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf(Calc.num(g.interestRate)) }
    var months by remember { mutableStateOf("10") }
    var method by remember { mutableStateOf(g.interestMethod) }
    var asOf by remember { mutableStateOf(System.currentTimeMillis()) }
    val open = g.setupOpen()

    Page(tx("Opening balance", "शुरुआती बैलेंस"), m.name, bottom = if (open && !entered && Session.isAdmin) ({
        PrimaryButton(tx("Save & ask ${m.name} to confirm", "सेव करें और ${m.name} से पुष्टि लें")) {
            val s = saved.money() ?: 0.0; val i = interest.money() ?: 0.0; val l = loan.money() ?: 0.0
            if (s + i + l <= 0) { Session.error = tx("Enter at least one amount", "कम से कम एक राशि लिखें"); return@PrimaryButton }
            Repo.saveOpening(m, s, i, l, rate.money() ?: g.interestRate, months.toIntOrNull() ?: 1, method, asOf)
            Nav.back()
        }
    }) else null) {
        if (m.opening == "disputed") item { Banner(tx("${m.name} says: ${m.openingNote}", "${m.name} कहते हैं: ${m.openingNote}"), Icons.Outlined.Warning) }
        if (entered) {
            item {
                SectionCard(tx("Already entered", "पहले से डाला गया")) {
                    Text(tx("To correct a mistake, open the entry and edit it (needs edit permission from the co-admin).", "गलती ठीक करने के लिए एंट्री खोलकर बदलें (सह-एडमिन की अनुमति चाहिए)।"), style = MaterialTheme.typography.bodySmall)
                }
            }
            items(existing, key = { it.id }) { SectionCard(padding = 8.dp) { TxnRow(it, showMember = false) } }
            items(existingLoans, key = { "l" + it.id }) { LoanCard(it) }
        } else if (!open) {
            item { Banner(tx("Setup is closed.", "सेटअप बंद है।"), Icons.Outlined.Lock) }
        } else {
            item {
                SectionCard(tx("From the notebook", "नोटबुक से")) {
                    DateRow(tx("As of date", "किस तारीख तक"), asOf, true, "") { asOf = it }
                    Field(tx("Total saved so far (₹)", "अब तक कुल बचत (₹)"), saved, { saved = it }, number = true)
                    Field(tx("Interest paid so far (₹)", "अब तक भरा ब्याज (₹)"), interest, { interest = it }, number = true)
                }
            }
            item {
                SectionCard(tx("Loan still due (if any)", "बाकी लोन (अगर है)")) {
                    Field(tx("Loan amount still due (₹)", "बाकी लोन राशि (₹)"), loan, { loan = it }, number = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(tx("Interest %", "ब्याज %"), rate, { rate = it }, number = true, modifier = Modifier.weight(1f))
                        Field(tx("Months left", "बचे महीने"), months, { months = it.filter { c -> c.isDigit() } }, number = true, modifier = Modifier.weight(1f))
                    }
                    Segmented(listOf("flat" to tx("Flat", "फ्लैट"), "reducing" to tx("Reducing", "घटता हुआ")), method) { method = it }
                }
            }
            item { Text(tx("${m.name} gets: \"Your opening balance: Saved …, Loan … — Confirm or Report a mistake.\"", "${m.name} को सूचना जाएगी: \"आपका शुरुआती बैलेंस: बचत …, लोन … — पुष्टि करें या गलती बताएं।\""), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
