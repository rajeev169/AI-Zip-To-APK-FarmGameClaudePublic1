package com.rajeev.samuhkhata.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Extra colours for warnings (orange) and info (blue) that stay the same idea in every theme. */
data class Extra(
    val warnBg: Color, val warnFg: Color,
    val infoBg: Color, val infoFg: Color,
    val goodFg: Color, val badFg: Color,
    val header: Color, val onHeader: Color,
    val dark: Boolean,
)

val LocalExtra = staticCompositionLocalOf {
    Extra(Color(0xFFFDF1E4), Color(0xFF8A4205), Color(0xFFE8F0FB), Color(0xFF1D3F73), Color(0xFF1F6F4A), Color(0xFFB3261E), Color(0xFF5B3A8C), Color.White, false)
}

private fun plumLight() = lightColorScheme(
    primary = Color(0xFF5B3A8C), onPrimary = Color.White,
    primaryContainer = Color(0xFFF1EAF8), onPrimaryContainer = Color(0xFF2B1550),
    secondary = Color(0xFF8A6100), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFF0C8), onSecondaryContainer = Color(0xFF2B1F00),
    tertiary = Color(0xFF0F6F68), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFCFF5F1), onTertiaryContainer = Color(0xFF00201E),
    background = Color(0xFFF7F5FA), onBackground = Color(0xFF221A2C),
    surface = Color.White, onSurface = Color(0xFF221A2C),
    surfaceVariant = Color(0xFFEEEAF2), onSurfaceVariant = Color(0xFF5C546A),
    outline = Color(0xFFCBC3D6), outlineVariant = Color(0xFFE3DDEA),
)

private fun plumDark() = darkColorScheme(
    primary = Color(0xFFD3B8FF), onPrimary = Color(0xFF3A1C66),
    primaryContainer = Color(0xFF4A2B78), onPrimaryContainer = Color(0xFFEEDCFF),
    secondary = Color(0xFFF2C55C), onSecondary = Color(0xFF402D00),
    secondaryContainer = Color(0xFF5C4300), onSecondaryContainer = Color(0xFFFFE08F),
    tertiary = Color(0xFF6FE0D5), onTertiary = Color(0xFF003733),
    tertiaryContainer = Color(0xFF00504A), onTertiaryContainer = Color(0xFF8FF5EA),
    background = Color(0xFF141118), onBackground = Color(0xFFEAE1F0),
    surface = Color(0xFF1E1A23), onSurface = Color(0xFFEAE1F0),
    surfaceVariant = Color(0xFF2C2633), onSurfaceVariant = Color(0xFFCBC2D4),
    outline = Color(0xFF4A4352), outlineVariant = Color(0xFF39323F),
)

private fun greenLight() = lightColorScheme(
    primary = Color(0xFF1F6F4A), onPrimary = Color.White,
    primaryContainer = Color(0xFFE3F3EA), onPrimaryContainer = Color(0xFF0B3A24),
    secondary = Color(0xFF8A6100), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFF0C8), onSecondaryContainer = Color(0xFF2B1F00),
    tertiary = Color(0xFFA6431C), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFDBCF), onTertiaryContainer = Color(0xFF390C00),
    background = Color(0xFFF5F6F2), onBackground = Color(0xFF1B2A22),
    surface = Color.White, onSurface = Color(0xFF1B2A22),
    surfaceVariant = Color(0xFFEEF0EC), onSurfaceVariant = Color(0xFF55645B),
    outline = Color(0xFFC9D0CA), outlineVariant = Color(0xFFDFE4E0),
)

private fun greenDark() = darkColorScheme(
    primary = Color(0xFF8AD8AE), onPrimary = Color(0xFF003822),
    primaryContainer = Color(0xFF165338), onPrimaryContainer = Color(0xFFA6F4C8),
    secondary = Color(0xFFF2C55C), onSecondary = Color(0xFF402D00),
    secondaryContainer = Color(0xFF5C4300), onSecondaryContainer = Color(0xFFFFE08F),
    tertiary = Color(0xFFFFB59B), onTertiary = Color(0xFF5B1A00),
    tertiaryContainer = Color(0xFF7F2D0A), onTertiaryContainer = Color(0xFFFFDBCF),
    background = Color(0xFF101512), onBackground = Color(0xFFDFE8E1),
    surface = Color(0xFF19201B), onSurface = Color(0xFFDFE8E1),
    surfaceVariant = Color(0xFF253029), onSurfaceVariant = Color(0xFFBDC9C0),
    outline = Color(0xFF3F4A43), outlineVariant = Color(0xFF323B35),
)

private fun blueLight() = lightColorScheme(
    primary = Color(0xFF1D4F8A), onPrimary = Color.White,
    primaryContainer = Color(0xFFE3EDFA), onPrimaryContainer = Color(0xFF0A2547),
    secondary = Color(0xFF8A6100), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFF0C8), onSecondaryContainer = Color(0xFF2B1F00),
    tertiary = Color(0xFF0E6B50), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFC9F5E3), onTertiaryContainer = Color(0xFF002116),
    background = Color(0xFFF4F6FA), onBackground = Color(0xFF182230),
    surface = Color.White, onSurface = Color(0xFF182230),
    surfaceVariant = Color(0xFFE9EDF4), onSurfaceVariant = Color(0xFF556070),
    outline = Color(0xFFC5CDD9), outlineVariant = Color(0xFFDCE2EA),
)

private fun blueDark() = darkColorScheme(
    primary = Color(0xFFA8C8FF), onPrimary = Color(0xFF00315F),
    primaryContainer = Color(0xFF1A4577), onPrimaryContainer = Color(0xFFD5E3FF),
    secondary = Color(0xFFF2C55C), onSecondary = Color(0xFF402D00),
    secondaryContainer = Color(0xFF5C4300), onSecondaryContainer = Color(0xFFFFE08F),
    tertiary = Color(0xFF6FE0B8), onTertiary = Color(0xFF00382A),
    tertiaryContainer = Color(0xFF00513D), onTertiaryContainer = Color(0xFF8FFDD3),
    background = Color(0xFF10131A), onBackground = Color(0xFFE0E4EC),
    surface = Color(0xFF191D25), onSurface = Color(0xFFE0E4EC),
    surfaceVariant = Color(0xFF262C36), onSurfaceVariant = Color(0xFFC0C7D3),
    outline = Color(0xFF414955), outlineVariant = Color(0xFF333A45),
)

fun schemeFor(colour: String, dark: Boolean): ColorScheme = when (colour) {
    "green" -> if (dark) greenDark() else greenLight()
    "blue" -> if (dark) blueDark() else blueLight()
    else -> if (dark) plumDark() else plumLight()
}

/** Swatch shown in the colour picker. */
fun swatch(colour: String): Color = when (colour) {
    "green" -> Color(0xFF1F6F4A)
    "blue" -> Color(0xFF1D4F8A)
    else -> Color(0xFF5B3A8C)
}

private val AppType = Typography(
    headlineSmall = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    bodySmall = TextStyle(fontSize = 12.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
)

@Composable
fun SamuhTheme(colour: String, mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val scheme = schemeFor(colour, dark)
    val extra = if (dark) Extra(
        warnBg = Color(0xFF3D2A12), warnFg = Color(0xFFF6C38A),
        infoBg = Color(0xFF1B2A40), infoFg = Color(0xFFB8D0F5),
        goodFg = scheme.primary, badFg = Color(0xFFFFB4AB),
        header = scheme.primaryContainer, onHeader = scheme.onPrimaryContainer, dark = true,
    ) else Extra(
        warnBg = Color(0xFFFDF1E4), warnFg = Color(0xFF8A4205),
        infoBg = Color(0xFFE8F0FB), infoFg = Color(0xFF1D3F73),
        goodFg = scheme.primary, badFg = Color(0xFFB3261E),
        header = scheme.primary, onHeader = scheme.onPrimary, dark = false,
    )
    CompositionLocalProvider(LocalExtra provides extra) {
        MaterialTheme(colorScheme = scheme, typography = AppType, content = content)
    }
}
