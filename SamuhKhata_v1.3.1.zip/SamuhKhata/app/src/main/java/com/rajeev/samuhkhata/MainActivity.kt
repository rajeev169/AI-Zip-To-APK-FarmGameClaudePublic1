package com.rajeev.samuhkhata

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.rajeev.samuhkhata.core.AppState
import com.rajeev.samuhkhata.core.IconSwitcher
import com.rajeev.samuhkhata.core.Prefs
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.tx
import com.rajeev.samuhkhata.ui.*

class MainActivity : ComponentActivity() {
    lateinit var googleClient: GoogleSignInClient
    private var openInbox by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleClient = GoogleSignIn.getClient(this, gso)
        openInbox = intent?.getBooleanExtra("openInbox", false) == true
        setContent { AppRoot(this) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("openInbox", false)) openInbox = true
    }

    fun consumeOpenInbox(): Boolean { val v = openInbox; openInbox = false; return v }
    val wantsInbox: Boolean get() = openInbox

    fun signOut() {
        googleClient.signOut()
        Session.signOut()
        Nav.home()
    }
}

@Composable
fun AppRoot(act: MainActivity) {
    val ctx = LocalContext.current
    val g = Session.group
    val colour = when {
        g == null -> "plum"
        g.colourLocked || Prefs.personalColour.isBlank() -> g.colour
        else -> Prefs.personalColour
    }
    LaunchedEffect(colour, g?.id) { if (g != null) IconSwitcher.apply(ctx, colour) }

    val toast = Session.toast
    LaunchedEffect(toast) { if (toast != null) { Toast.makeText(ctx, toast, Toast.LENGTH_SHORT).show(); Session.toast = null } }
    val err = Session.error
    LaunchedEffect(err) { if (err != null) { Toast.makeText(ctx, err, Toast.LENGTH_LONG).show(); Session.error = null } }

    val signInLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        try {
            val acc = GoogleSignIn.getSignedInAccountFromIntent(res.data).getResult(ApiException::class.java)
            val cred = GoogleAuthProvider.getCredential(acc.idToken, null)
            FirebaseAuth.getInstance().signInWithCredential(cred)
                .addOnFailureListener { Session.error = it.message }
        } catch (e: ApiException) {
            Session.error = when (e.statusCode) {
                // 10 = this APK's signing key (SHA-1) is not added in Firebase — not an internet problem.
                10 -> tx("Google sign-in failed (code 10): app setup problem. The SHA-1 of this APK's signing key must be added in Firebase.",
                    "Google साइन-इन नहीं हुआ (कोड 10): ऐप सेटअप की समस्या। इस APK की साइनिंग key का SHA-1 Firebase में जोड़ना होगा।")
                12501 -> tx("Sign-in cancelled", "साइन-इन रद्द किया")
                else -> tx("Google sign-in failed (code ${e.statusCode}). Check internet and try again.",
                    "Google साइन-इन नहीं हुआ (कोड ${e.statusCode})। इंटरनेट जाँचें और फिर कोशिश करें।")
            }
        }
    }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    SamuhTheme(colour, Prefs.mode) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            when (Session.state) {
                AppState.SIGNED_OUT -> LoginScreen { signInLauncher.launch(act.googleClient.signInIntent) }
                AppState.LOADING -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                AppState.NO_GROUP -> NoGroupScreen(onSignOut = { act.signOut() })
                AppState.WAITING -> WaitingScreen(onSignOut = { act.signOut() })
                AppState.REMOVED -> RemovedScreen(onSignOut = { act.signOut() })
                AppState.READY -> {
                    LaunchedEffect(Unit) {
                        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    LaunchedEffect(act.wantsInbox) { if (act.consumeOpenInbox()) Nav.go(Screen.Inbox) }
                    BackHandler(enabled = Nav.stack.size > 1) { Nav.back() }
                    if (Session.me == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    } else {
                        ScreenHost(onSignOut = { act.signOut() })
                    }
                }
            }
        }
    }
}

@Composable
fun ScreenHost(onSignOut: () -> Unit) {
    val staff = Session.isStaff
    when (val s = Nav.top) {
        Screen.Home -> if (staff) AdminHome() else MemberHome()
        Screen.Members -> if (staff) MembersScreen() else MemberListScreen()
        is Screen.MemberDetail -> MemberDetailScreen(s.uid)
        Screen.Savings -> SavingsScreen()
        Screen.Loans -> LoansScreen()
        is Screen.NewLoan -> NewLoanScreen(s.memberUid)
        is Screen.LoanDetail -> LoanDetailScreen(s.id)
        Screen.Repayments -> RepaymentsScreen()
        Screen.CashBook -> CashBookScreen()
        is Screen.TxnDetail -> TxnDetailScreen(s.id)
        Screen.Meetings -> MeetingsScreen()
        is Screen.MeetingEdit -> MeetingEditScreen(s.id)
        Screen.Reports -> ReportsScreen()
        Screen.ProfitShare -> ProfitShareScreen()
        is Screen.ActivityLog -> ActivityScreen(s.filter)
        Screen.Inbox -> InboxScreen()
        is Screen.Passbook -> PassbookScreen(s.uid)
        Screen.MyLoans -> MyLoansScreen()
        Screen.GroupSummary -> GroupSummaryScreen()
        Screen.Settings -> if (staff) AdminSettingsScreen(onSignOut) else MemberSettingsScreen(onSignOut)
        Screen.GroupRules -> if (staff) FinanceSettingsScreen() else GroupRulesViewScreen()
        Screen.Alerts -> AlertsScreen()
        Screen.Permissions -> PermissionsScreen()
        Screen.OldRecords -> OldRecordsScreen()
        is Screen.Opening -> OpeningScreen(s.uid)
        Screen.MemberList -> MemberListScreen()
        Screen.Election -> ElectionScreen()
        Screen.GroupProfile -> GroupProfileScreen()
        Screen.FinanceSettings -> FinanceSettingsScreen()
        Screen.PendingFines -> PendingFinesScreen()
    }
}
