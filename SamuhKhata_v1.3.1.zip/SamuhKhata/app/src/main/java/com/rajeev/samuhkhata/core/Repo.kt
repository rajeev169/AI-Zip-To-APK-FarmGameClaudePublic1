package com.rajeev.samuhkhata.core

import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.WriteBatch
import kotlinx.coroutines.tasks.await

/**
 * Every change to the group's records goes through here.
 * Writes are saved on the phone straight away and synced when the internet is available.
 * Each change also writes a Group Activity line and, where needed, notifications.
 */
object Repo {
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    private fun now() = System.currentTimeMillis()
    private fun uid() = Session.uid
    private fun meName() = Session.me?.name ?: Session.user?.displayName ?: ""
    private fun gref(gid: String) = db.collection("groups").document(gid)
    private fun g(): Group = Session.group ?: error("No group")

    private fun commit(b: WriteBatch, done: (() -> Unit)? = null) {
        b.commit()
            .addOnSuccessListener { done?.invoke() }
            .addOnFailureListener { Session.error = it.message }
        // Saved on the phone already; tell the user straight away.
        Session.toast = tx("Saved", "सेव हो गया")
    }

    private fun WriteBatch.act(gid: String, kind: String, m: Msg, affected: String = "") {
        set(gref(gid).collection("activity").document(), mapOf(
            "at" to now(), "kind" to kind, "text" to m.en, "textHi" to m.hi,
            "actorName" to meName(), "actorUid" to uid(), "affectedUid" to affected,
        ))
    }

    private fun WriteBatch.note(gid: String, to: String, title: Msg, body: Msg, kind: String) {
        set(gref(gid).collection("inbox").document(), mapOf(
            "toUid" to to, "fromUid" to uid(), "at" to now(), "kind" to kind,
            "title" to title.en, "titleHi" to title.hi, "body" to body.en, "bodyHi" to body.hi,
        ))
    }

    private fun r(v: Double) = Calc.rupees(v)
    private fun monthEn(key: String) = if (key.isBlank()) "" else Calc.shortMonth(key, false)
    private fun monthHi(key: String) = if (key.isBlank()) "" else Calc.shortMonth(key, true)

    /** Date used for an entry: the chosen date only when back-dating is allowed, else now. */
    fun effectiveDate(chosen: Long?): Pair<Long, Boolean> {
        val n = now()
        val g = Session.group ?: return n to false
        if (chosen == null) return n to false
        if (!g.canBackdate(uid())) return n to false
        val back = chosen < n - 60 * 60 * 1000
        return (if (chosen > n) n else chosen) to back
    }

    private fun txnMap(
        type: String, member: Member?, amount: Double, date: Long, backdated: Boolean,
        month: String = "", note: String = "", principal: Double = 0.0, interest: Double = 0.0, loanId: String = "",
    ): Map<String, Any> = mapOf(
        "type" to type,
        "memberUid" to (member?.uid ?: ""),
        "memberName" to (member?.name ?: ""),
        "amount" to Calc.round2(amount),
        "principal" to Calc.round2(principal),
        "interest" to Calc.round2(interest),
        "loanId" to loanId,
        "month" to month,
        "note" to note,
        "date" to date,
        "createdAt" to FieldValue.serverTimestamp(),
        "createdBy" to uid(),
        "createdByName" to meName(),
        "backdated" to backdated,
        "deleted" to false,
        "edited" to false,
        "history" to listOf(mapOf(
            "action" to "added", "by" to meName(), "at" to now(), "reason" to "",
            "detail" to if (backdated) "Back-dated to ${Calc.date(date)}" else "",
        )),
    )

    // =====================================================================
    // Group creation & joining
    // =====================================================================

    /**
     * Only the group name is typed here. Every other setting starts empty and locked:
     * the admin adds members, chooses a co-admin, and the co-admin unlocks the settings.
     */
    suspend fun createGroup(user: FirebaseUser, name: String, adminName: String, phone: String): String {
        var code = Calc.newCode()
        repeat(5) {
            if (!db.collection("codes").document(code).get().await().exists()) return@repeat
            code = Calc.newCode()
        }
        val ref = db.collection("groups").document()
        val t = now()
        ref.set(mapOf(
            "name" to name, "adminUid" to user.uid, "adminName" to adminName,
            "coAdminUid" to "", "coAdminName" to "",
            "monthlySaving" to 0.0, "dueDay" to 0, "interestRate" to 0.0,
            "interestMethod" to LoanType.FLEXIBLE, "lateFine" to 0.0, "maxSize" to 0,
            "yearlyFine" to 0.0, "interestFine" to 0.0, "cutoffDay" to 0, "oneLoan" to true, "stampLimit" to 0.0,
            "financeSet" to false, "financeFromAt" to 0L,
            "village" to "", "startedOn" to t, "groupLanguage" to "",
            "profileUnlocked" to false, "financeUnlocked" to false,
            "inviteCode" to code, "colour" to "plum", "colourLocked" to true,
            "createdAt" to t, "setupUntil" to t + 30 * Calc.DAY, "setupClosed" to false,
            "alerts" to Alerts().toMap(), "backdateUntil" to emptyMap<String, Long>(),
            "editUntil" to emptyMap<String, Long>(), "summary" to Summary().toMap(),
            "lastCloseAt" to t, "lowCashFlag" to false,
            "activeProposalId" to "", "adminAccepted" to true,
        )).await()
        ref.collection("members").document(user.uid).set(mapOf(
            "name" to adminName, "email" to (user.email ?: "").lowercase(), "phone" to phone,
            "role" to Role.ADMIN, "status" to MemberStatus.ACTIVE, "joinedAt" to t,
            "opening" to "", "openingNote" to "",
        )).await()
        db.collection("codes").document(code).set(mapOf("gid" to ref.id, "groupName" to name)).await()
        db.collection("users").document(user.uid).set(mapOf("groupId" to ref.id, "pendingGroupId" to "", "pendingGroupName" to "")).await()
        val b = db.batch()
        b.act(ref.id, Kind.SETUP, Msg("$adminName created the group $name", "$adminName ने समूह $name बनाया"))
        b.commit().await()
        return ref.id
    }

    /** Member was added by Gmail: joining happens automatically on sign-in. */
    suspend fun joinFromInvite(gid: String, user: FirebaseUser) {
        val email = (user.email ?: "").lowercase()
        val name = user.displayName ?: email.substringBefore("@")
        gref(gid).collection("members").document(user.uid).set(mapOf(
            "name" to name, "email" to email, "phone" to "",
            "role" to Role.MEMBER, "status" to MemberStatus.ACTIVE, "joinedAt" to now(),
            "opening" to "", "openingNote" to "",
        )).await()
        db.collection("users").document(user.uid).set(mapOf("groupId" to gid, "pendingGroupId" to "", "pendingGroupName" to "")).await()
        val b = db.batch()
        b.delete(db.collection("invitesByEmail").document(email))
        b.delete(gref(gid).collection("invites").document(email))
        b.set(gref(gid).collection("activity").document(), mapOf(
            "at" to now(), "kind" to Kind.MEMBER, "text" to "$name joined the group (added by Gmail)",
            "textHi" to "$name समूह से जुड़े (Gmail से जोड़ा गया)", "actorName" to name, "actorUid" to user.uid, "affectedUid" to user.uid,
        ))
        b.set(gref(gid).collection("inbox").document(), mapOf(
            "toUid" to "all", "fromUid" to user.uid, "at" to now(), "kind" to Kind.MEMBER,
            "title" to "New member", "titleHi" to "नया सदस्य",
            "body" to "$name joined the group", "bodyHi" to "$name समूह से जुड़े",
        ))
        b.commit().await()
    }

    /** Returns the group name, or null if the code is wrong. */
    suspend fun requestJoin(user: FirebaseUser, code: String): String? {
        val c = db.collection("codes").document(code.trim()).get().await()
        if (!c.exists()) return null
        val gid = c.getString("gid") ?: return null
        val gname = c.getString("groupName") ?: ""
        val email = (user.email ?: "").lowercase()
        gref(gid).collection("joinRequests").document(user.uid).set(mapOf(
            "name" to (user.displayName ?: email.substringBefore("@")), "email" to email, "at" to now(),
        )).await()
        db.collection("users").document(user.uid).set(mapOf(
            "groupId" to "", "pendingGroupId" to gid, "pendingGroupName" to gname,
        )).await()
        Session.pendingGroupName = gname
        return gname
    }

    suspend fun cancelRequest(gid: String) {
        db.collection("users").document(uid()).set(mapOf("groupId" to "", "pendingGroupId" to "", "pendingGroupName" to "")).await()
        if (gid.isNotBlank()) gref(gid).collection("joinRequests").document(uid()).delete().await()
    }

    suspend fun clearRemoved() {
        Prefs.lastGroupId = ""
        db.collection("users").document(uid()).set(mapOf("groupId" to "", "pendingGroupId" to "", "pendingGroupName" to "")).await()
    }

    private fun roomLeft(g: Group): Boolean {
        if (g.maxSize <= 0) return true
        return Session.activeMembers.size + Session.invites.size < g.maxSize
    }

    /** Returns an error message, or null when done. */
    fun addInvite(emailRaw: String): String? {
        val g = g()
        val email = emailRaw.trim().lowercase()
        if (!email.contains("@") || !email.contains(".")) return tx("Enter a valid Gmail address", "सही Gmail पता लिखें")
        if (Session.members.any { it.email == email && it.status != MemberStatus.LEFT }) return tx("Already a member", "पहले से सदस्य हैं")
        if (!roomLeft(g)) return tx("Group is full (max ${g.maxSize})", "समूह भरा हुआ है (अधिकतम ${g.maxSize})")
        val b = db.batch()
        val inv = mapOf("gid" to g.id, "groupName" to g.name, "addedByName" to meName(), "at" to now())
        b.set(db.collection("invitesByEmail").document(email), inv)
        b.set(gref(g.id).collection("invites").document(email), inv)
        b.act(g.id, Kind.MEMBER, Msg("${meName()} added $email by Gmail (waiting to join)", "${meName()} ने $email को Gmail से जोड़ा (जुड़ने का इंतज़ार)"))
        commit(b)
        return null
    }

    fun removeInvite(email: String) {
        val g = g()
        val b = db.batch()
        b.delete(db.collection("invitesByEmail").document(email))
        b.delete(gref(g.id).collection("invites").document(email))
        b.act(g.id, Kind.MEMBER, Msg("${meName()} removed the pending Gmail $email", "${meName()} ने लंबित Gmail $email हटाया"))
        commit(b)
    }

    fun approve(r: JoinRequest): String? {
        val g = g()
        if (!roomLeft(g)) return tx("Group is full (max ${g.maxSize})", "समूह भरा हुआ है (अधिकतम ${g.maxSize})")
        val b = db.batch()
        b.set(gref(g.id).collection("members").document(r.uid), mapOf(
            "name" to r.name, "email" to r.email, "phone" to "", "role" to Role.MEMBER,
            "status" to MemberStatus.ACTIVE, "joinedAt" to now(), "opening" to "", "openingNote" to "",
        ))
        b.delete(gref(g.id).collection("joinRequests").document(r.uid))
        b.act(g.id, Kind.MEMBER, Msg("${meName()} approved ${r.name} (joined with invite code)", "${meName()} ने ${r.name} को मंज़ूरी दी (इनवाइट कोड से जुड़े)"), r.uid)
        b.note(g.id, "all", Msg("New member", "नया सदस्य"), Msg("${r.name} joined the group", "${r.name} समूह से जुड़े"), Kind.MEMBER)
        commit(b)
        return null
    }

    fun reject(r: JoinRequest) {
        val g = g()
        val b = db.batch()
        b.delete(gref(g.id).collection("joinRequests").document(r.uid))
        b.act(g.id, Kind.MEMBER, Msg("${meName()} declined the join request from ${r.name}", "${meName()} ने ${r.name} का अनुरोध अस्वीकार किया"))
        commit(b)
    }

    fun regenerateCode() {
        val g = g()
        val code = Calc.newCode()
        val b = db.batch()
        if (g.inviteCode.isNotBlank()) b.delete(db.collection("codes").document(g.inviteCode))
        b.set(db.collection("codes").document(code), mapOf("gid" to g.id, "groupName" to g.name))
        b.update(gref(g.id), "inviteCode", code)
        b.act(g.id, Kind.RULE, Msg("${meName()} made a new invite code (old code no longer works)", "${meName()} ने नया इनवाइट कोड बनाया (पुराना कोड बंद)"))
        b.note(g.id, "all", Msg("Invite code changed", "इनवाइट कोड बदला"),
            Msg("${meName()} made a new invite code. The old code no longer works.", "${meName()} ने नया इनवाइट कोड बनाया। पुराना कोड अब काम नहीं करेगा।"), Kind.RULE)
        commit(b)
    }

    // =====================================================================
    // Roles & permissions (two-key system)
    // =====================================================================

    fun setCoAdmin(newCo: Member?) {
        val g = g()
        val old = Session.memberById(g.coAdminUid)
        val b = db.batch()
        b.update(gref(g.id), mapOf(
            "coAdminUid" to (newCo?.uid ?: ""), "coAdminName" to (newCo?.name ?: ""),
            "backdateUntil" to emptyMap<String, Long>(), "editUntil" to emptyMap<String, Long>(),
            "profileUnlocked" to false, "financeUnlocked" to false,
        ))
        if (old != null && old.uid != newCo?.uid) {
            b.update(gref(g.id).collection("members").document(old.uid), "role", Role.MEMBER)
            b.note(g.id, old.uid, Msg("Co-admin role ended", "सह-एडमिन भूमिका समाप्त"),
                Msg("${meName()} changed the co-admin. You are now a member.", "${meName()} ने सह-एडमिन बदला। अब आप सदस्य हैं।"), Kind.ROLE)
        }
        if (newCo != null) b.update(gref(g.id).collection("members").document(newCo.uid), "role", Role.CO)

        val (en, hi) = when {
            newCo != null && old == null -> "${meName()} made ${newCo.name} co-admin" to "${meName()} ने ${newCo.name} को सह-एडमिन बनाया"
            newCo != null && old != null -> "${meName()} changed co-admin from ${old.name} to ${newCo.name}" to "${meName()} ने सह-एडमिन ${old.name} से बदलकर ${newCo.name} किया"
            old != null -> "${meName()} removed ${old.name} as co-admin" to "${meName()} ने ${old.name} को सह-एडमिन से हटाया"
            else -> return
        }
        b.act(g.id, Kind.ROLE, Msg(en, hi), newCo?.uid ?: old?.uid ?: "")
        b.note(g.id, "all", Msg(if (old == null) "New co-admin" else "Co-admin changed", if (old == null) "नए सह-एडमिन" else "सह-एडमिन बदला"), Msg(en, hi), Kind.ROLE)
        val hadPerms = g.backdateUntil.values.any { it > now() } || g.editUntil.values.any { it > now() } ||
            g.profileUnlocked || g.financeUnlocked
        if (hadPerms) {
            val m = Msg("All permissions turned OFF automatically because the co-admin changed",
                "सह-एडमिन बदलने से सभी अनुमतियाँ अपने आप बंद हो गईं")
            b.act(g.id, Kind.PERM, m)
            b.note(g.id, "all", Msg("Permissions reset", "अनुमतियाँ रीसेट"), m, Kind.PERM)
        }
        commit(b)
    }

    /** kind = "backdate" or "edit". days = 0 turns it off. */
    fun setPermission(kind: String, grantee: Member, days: Int) {
        val g = g()
        val field = if (kind == "backdate") "backdateUntil" else "editUntil"
        val labelEn = if (kind == "backdate") "back-date entries" else "edit entries"
        val labelHi = if (kind == "backdate") "पिछली तारीख की एंट्री" else "एंट्री बदलने"
        val b = db.batch()
        val m: Msg
        if (days > 0) {
            val until = now() + days * Calc.DAY
            b.update(gref(g.id), "$field.${grantee.uid}", until)
            m = Msg("🔓 ${meName()} allowed ${grantee.name} to $labelEn for $days day(s), until ${Calc.dateTime(until)}",
                "🔓 ${meName()} ने ${grantee.name} को $days दिन के लिए $labelHi की अनुमति दी, ${Calc.dateTime(until)} तक")
        } else {
            b.update(gref(g.id), "$field.${grantee.uid}", FieldValue.delete())
            m = Msg("🔒 ${meName()} turned OFF permission for ${grantee.name} to $labelEn",
                "🔒 ${meName()} ने ${grantee.name} की $labelHi की अनुमति बंद की")
        }
        b.act(g.id, Kind.PERM, m, grantee.uid)
        b.note(g.id, "all", Msg("Permission changed", "अनुमति बदली"), m, Kind.PERM)
        commit(b)
    }

    /**
     * Co-admin's switches for the two settings sections. section = "profile" or "finance".
     * While a switch is ON the admin can change that section; turning it OFF locks it at once.
     */
    fun setUnlock(section: String, on: Boolean) {
        val g = g()
        if (Session.me?.role != Role.CO) { Session.error = tx("Only the co-admin can do this", "यह केवल सह-एडमिन कर सकते हैं"); return }
        val field = if (section == "profile") "profileUnlocked" else "financeUnlocked"
        val (en, hi) = if (section == "profile") "group profile" to "समूह प्रोफ़ाइल" else "financial settings" to "वित्तीय सेटिंग"
        val b = db.batch()
        b.update(gref(g.id), field, on)
        val m = if (on) Msg("🔓 ${meName()} (co-admin) allowed ${g.adminName} to edit $en", "🔓 ${meName()} (सह-एडमिन) ने ${g.adminName} को $hi बदलने की अनुमति दी")
        else Msg("🔒 ${meName()} (co-admin) locked $en", "🔒 ${meName()} (सह-एडमिन) ने $hi लॉक की")
        b.act(g.id, Kind.PERM, m, g.adminUid)
        b.note(g.id, "all", Msg(if (on) "Settings unlocked" else "Settings locked", if (on) "सेटिंग अनलॉक" else "सेटिंग लॉक"), m, Kind.PERM)
        commit(b)
    }

    /** Timed permissions switch themselves off; everyone is told. Run on the admin's phone. */
    fun expirePermissions(g: Group) {
        val n = now()
        val expired = g.backdateUntil.filter { it.value in 1..n }.map { "backdateUntil" to it.key } +
            g.editUntil.filter { it.value in 1..n }.map { "editUntil" to it.key }
        if (expired.isEmpty()) return
        val b = db.batch()
        expired.forEach { (field, who) ->
            b.update(gref(g.id), "$field.$who", FieldValue.delete())
            val name = Session.memberById(who)?.name ?: ""
            val m = if (field == "backdateUntil")
                Msg("⏱ Back-date permission for $name ended automatically (timer finished)", "⏱ $name की पिछली तारीख की अनुमति अपने आप बंद (समय पूरा)")
            else Msg("⏱ Edit permission for $name ended automatically (timer finished)", "⏱ $name की एंट्री बदलने की अनुमति अपने आप बंद (समय पूरा)")
            b.act(g.id, Kind.PERM, m, who)
            b.note(g.id, "all", Msg("Permission ended", "अनुमति समाप्त"), m, Kind.PERM)
        }
        b.commit().addOnFailureListener { Session.error = it.message }
    }

    // =====================================================================
    // Admin election (secret vote, instant transfer at majority)
    // =====================================================================

    /** Co-admin proposes a new admin. Returns an error message or null. */
    fun proposeAdmin(candidate: Member, reason: String): String? {
        val g = g()
        val me = Session.me ?: return null
        if (me.role != Role.CO) return tx("Only the co-admin can propose a new admin", "केवल सह-एडमिन नया एडमिन प्रस्तावित कर सकते हैं")
        if (g.activeProposalId.isNotBlank()) return tx("A vote is already running", "एक वोट पहले से चल रहा है")
        if (candidate.uid == g.adminUid) return tx("This member is already the admin", "यह सदस्य पहले से एडमिन हैं")
        if (reason.isBlank()) return tx("Please write a reason", "कारण लिखें")
        val recentFail = Session.proposals.firstOrNull {
            it.candidateUid == candidate.uid && it.status == "failed" && now() - it.closedAt < 7 * Calc.DAY
        }
        if (recentFail != null) return tx("${candidate.name} lost a vote recently. Try again after ${Calc.date(recentFail.closedAt + 7 * Calc.DAY)}.",
            "${candidate.name} हाल ही में वोट हारे हैं। ${Calc.date(recentFail.closedAt + 7 * Calc.DAY)} के बाद फिर कोशिश करें।")
        val eligible = Session.activeMembers.map { it.uid }
        val pref = gref(g.id).collection("proposals").document()
        val b = db.batch()
        b.set(pref, mapOf(
            "candidateUid" to candidate.uid, "candidateName" to candidate.name,
            "proposedBy" to uid(), "proposedByName" to meName(), "reason" to reason,
            "at" to now(), "status" to "open", "yes" to 0, "no" to 0,
            "total" to eligible.size, "eligible" to eligible, "closedAt" to 0L,
        ))
        b.update(gref(g.id), "activeProposalId", pref.id)
        val m = Msg("🗳 ${meName()} (co-admin) proposed ${candidate.name} as the new admin. Reason: $reason. Vote now — your vote is secret.",
            "🗳 ${meName()} (सह-एडमिन) ने ${candidate.name} को नया एडमिन प्रस्तावित किया। कारण: $reason। अभी वोट करें — आपका वोट गुप्त है।")
        b.act(g.id, Kind.ROLE, Msg("🗳 ${meName()} (co-admin) proposed ${candidate.name} as the new admin. Reason: $reason",
            "🗳 ${meName()} (सह-एडमिन) ने ${candidate.name} को नया एडमिन प्रस्तावित किया। कारण: $reason"), candidate.uid)
        b.note(g.id, "all", Msg("Vote for new admin", "नए एडमिन के लिए वोट"), m, Kind.ROLE)
        commit(b)
        return null
    }

    /** Cast a secret vote. If it decides the result, the transfer happens in the same step. */
    fun vote(p: Proposal, yes: Boolean, done: (String?) -> Unit) {
        val g = g()
        if (uid() !in p.eligible) { done(tx("You cannot vote in this proposal", "आप इस वोट में भाग नहीं ले सकते")); return }
        val newYes = p.yes + if (yes) 1 else 0
        val newNo = p.no + if (yes) 0 else 1
        val status = when {
            newYes * 2 > p.total -> "passed"
            (p.total - newNo) * 2 <= p.total -> "failed"
            else -> "open"
        }
        val pref = gref(g.id).collection("proposals").document(p.id)
        val b = db.batch()
        b.set(pref.collection("votes").document(uid()), mapOf("vote" to if (yes) "yes" else "no", "at" to now()))
        val upd = mutableMapOf<String, Any>("yes" to newYes, "no" to newNo, "status" to status)
        if (status != "open") upd["closedAt"] = now()
        b.update(pref, upd)
        when (status) {
            "passed" -> {
                val oldAdminUid = g.adminUid
                val oldAdminName = g.adminName
                val candidateWasCo = g.coAdminUid == p.candidateUid
                b.update(gref(g.id), mapOf(
                    "activeProposalId" to "", "adminUid" to p.candidateUid, "adminName" to p.candidateName,
                    "coAdminUid" to if (candidateWasCo) "" else g.coAdminUid,
                    "coAdminName" to if (candidateWasCo) "" else g.coAdminName,
                    "backdateUntil" to emptyMap<String, Long>(), "editUntil" to emptyMap<String, Long>(),
                    "profileUnlocked" to false, "financeUnlocked" to false,
                    "adminAccepted" to false,
                ))
                if (oldAdminUid.isNotBlank() && oldAdminUid != p.candidateUid) {
                    b.update(gref(g.id).collection("members").document(oldAdminUid), "role", Role.MEMBER)
                }
                b.update(gref(g.id).collection("members").document(p.candidateUid), "role", Role.ADMIN)
                val res = Msg("✅ Vote passed ($newYes of ${p.total} said Yes). ${p.candidateName} is now the admin. $oldAdminName is now a member.",
                    "✅ वोट पास ($newYes / ${p.total} ने हाँ कहा)। ${p.candidateName} अब एडमिन हैं। $oldAdminName अब सदस्य हैं।")
                b.set(gref(g.id).collection("activity").document(), mapOf(
                    "at" to now(), "kind" to Kind.ROLE, "text" to res.en, "textHi" to res.hi,
                    "actorName" to tx("Group vote", "समूह वोट"), "actorUid" to uid(), "affectedUid" to p.candidateUid,
                ))
                b.note(g.id, "all", Msg("New admin elected", "नए एडमिन चुने गए"), res, Kind.ROLE)
                if (oldAdminUid.isNotBlank() && oldAdminUid != p.candidateUid) {
                    b.note(g.id, oldAdminUid, Msg("You are no longer admin", "आप अब एडमिन नहीं हैं"),
                        Msg("The group voted. ${p.candidateName} is now the admin. You are now a member.",
                            "समूह ने वोट किया। ${p.candidateName} अब एडमिन हैं। अब आप सदस्य हैं।"), Kind.ROLE)
                }
                b.note(g.id, p.candidateUid, Msg("🎉 You are elected as the new admin", "🎉 आप नए एडमिन चुने गए"),
                    Msg("The group voted for you. Open the app and tap Accept.", "समूह ने आपको चुना। ऐप खोलें और स्वीकार करें दबाएं।"), Kind.ROLE)
                if (g.backdateUntil.values.any { it > now() } || g.editUntil.values.any { it > now() } || g.profileUnlocked || g.financeUnlocked) {
                    val pm = Msg("All permissions turned OFF automatically because the admin changed", "एडमिन बदलने से सभी अनुमतियाँ अपने आप बंद हो गईं")
                    b.set(gref(g.id).collection("activity").document(), mapOf(
                        "at" to now() + 1, "kind" to Kind.PERM, "text" to pm.en, "textHi" to pm.hi,
                        "actorName" to "", "actorUid" to uid(), "affectedUid" to "",
                    ))
                }
            }
            "failed" -> {
                b.update(gref(g.id), "activeProposalId", "")
                val res = Msg("❌ Vote failed: not enough Yes votes for ${p.candidateName} (Yes $newYes, No $newNo of ${p.total}). ${g.adminName} stays admin.",
                    "❌ वोट असफल: ${p.candidateName} के लिए पर्याप्त हाँ नहीं (हाँ $newYes, ना $newNo / ${p.total})। ${g.adminName} एडमिन रहेंगे।")
                b.set(gref(g.id).collection("activity").document(), mapOf(
                    "at" to now(), "kind" to Kind.ROLE, "text" to res.en, "textHi" to res.hi,
                    "actorName" to tx("Group vote", "समूह वोट"), "actorUid" to uid(), "affectedUid" to p.candidateUid,
                ))
                b.note(g.id, "all", Msg("Admin vote failed", "एडमिन वोट असफल"), res, Kind.ROLE)
            }
        }
        b.commit()
            .addOnSuccessListener { done(null) }
            .addOnFailureListener { done(tx("Vote not saved (someone voted at the same moment). Please tap again.", "वोट सेव नहीं हुआ (किसी और ने उसी समय वोट किया)। फिर से दबाएं।")) }
    }

    /** The elected admin confirms. They cannot decline. */
    fun acceptAdmin() {
        val g = g()
        val b = db.batch()
        b.update(gref(g.id), "adminAccepted", true)
        val m = Msg("🤝 ${meName()} accepted the admin role", "🤝 ${meName()} ने एडमिन की ज़िम्मेदारी स्वीकार की")
        b.act(g.id, Kind.ROLE, m, uid())
        b.note(g.id, "all", Msg("New admin accepted", "नए एडमिन ने स्वीकार किया"), m, Kind.ROLE)
        commit(b)
    }

    // =====================================================================
    // Group rules, appearance, alerts
    // =====================================================================

    private fun lockedMsg(section: String) = if (section == "profile")
        tx("Group profile is locked. Ask the co-admin to turn on \"Edit group profile\".", "समूह प्रोफ़ाइल लॉक है। सह-एडमिन से \"समूह प्रोफ़ाइल बदलें\" चालू करने को कहें।")
    else tx("Financial settings are locked. Ask the co-admin to turn on \"Edit financial settings\".", "वित्तीय सेटिंग लॉक है। सह-एडमिन से \"वित्तीय सेटिंग बदलें\" चालू करने को कहें।")

    private fun langName(l: String) = when (l) { "hi" -> "हिंदी"; "en" -> "English"; else -> "—" }

    /** Group profile. Needs the co-admin's "Edit group profile" switch. Returns an error or null. */
    fun updateProfile(name: String, village: String, startedOn: Long, language: String, maxSize: Int): String? {
        val g = g()
        if (!g.profileUnlocked) return lockedMsg("profile")
        val changes = mutableListOf<Pair<String, String>>()
        fun ch(en: String, hi: String, old: String, new: String) { if (old != new) changes += "$en: $old → $new" to "$hi: $old → $new" }
        ch("Group name", "समूह का नाम", g.name, name)
        ch("Village / area", "गाँव / क्षेत्र", g.village.ifBlank { "—" }, village.ifBlank { "—" })
        ch("Started on", "शुरू होने की तारीख", Calc.date(g.startedOn), Calc.date(startedOn))
        ch("Group language", "समूह की भाषा", langName(g.groupLanguage), langName(language))
        ch("Max group size", "अधिकतम सदस्य", if (g.maxSize == 0) "No limit" else g.maxSize.toString(), if (maxSize == 0) "No limit" else maxSize.toString())
        if (changes.isEmpty()) return tx("Nothing changed", "कुछ नहीं बदला")
        val b = db.batch()
        b.update(gref(g.id), mapOf(
            "name" to name, "village" to village, "startedOn" to startedOn, "groupLanguage" to language, "maxSize" to maxSize,
        ))
        if (name != g.name && g.inviteCode.isNotBlank()) b.set(db.collection("codes").document(g.inviteCode), mapOf("gid" to g.id, "groupName" to name))
        val m = Msg("${meName()} changed the group profile — " + changes.joinToString("; ") { it.first },
            "${meName()} ने समूह प्रोफ़ाइल बदली — " + changes.joinToString("; ") { it.second })
        b.act(g.id, Kind.RULE, m)
        b.note(g.id, "all", Msg("Group profile changed", "समूह प्रोफ़ाइल बदली"), m, Kind.RULE)
        commit(b)
        return null
    }

    data class FinanceValues(
        val dueDay: Int, val monthly: Double, val lateFine: Double, val yearlyFine: Double,
        val loanType: String, val rate: Double, val cutoffDay: Int, val oneLoan: Boolean,
        val stampLimit: Double, val interestFine: Double,
    )

    private fun loanTypeName(t: String) = when (t) {
        LoanType.FLAT -> "Flat EMI" to "फ्लैट EMI"
        LoanType.REDUCING -> "Reducing EMI" to "घटती EMI"
        else -> "Flexible" to "लचीला"
    }

    /** Group financial settings. Needs the co-admin's "Edit financial settings" switch. Returns an error or null. */
    fun updateFinance(v: FinanceValues): String? {
        val g = g()
        if (!g.financeUnlocked) return lockedMsg("finance")
        val first = !g.financeSet
        val changes = mutableListOf<Pair<String, String>>()
        fun ch(en: String, hi: String, old: String, new: String) { if (first || old != new) changes += (if (first) "$en: $new" else "$en: $old → $new") to (if (first) "$hi: $new" else "$hi: $old → $new") }
        fun day(d: Int) = if (d <= 0) "—" else d.toString()
        ch("Meeting day", "बैठक की तारीख", day(g.dueDay), day(v.dueDay))
        ch("Monthly saving", "मासिक बचत", r(g.monthlySaving), r(v.monthly))
        ch("Monthly saving late fine", "मासिक बचत देर का जुर्माना", r(g.lateFine), r(v.lateFine))
        ch("Yearly meeting absence fine", "वार्षिक बैठक अनुपस्थिति जुर्माना", r(g.yearlyFine), r(v.yearlyFine))
        val ot = loanTypeName(g.interestMethod); val nt = loanTypeName(v.loanType)
        if (first || g.interestMethod != v.loanType) changes += (if (first) "Loan type: ${nt.first}" else "Loan type: ${ot.first} → ${nt.first}") to (if (first) "लोन का प्रकार: ${nt.second}" else "लोन का प्रकार: ${ot.second} → ${nt.second}")
        ch("Interest per month", "प्रति माह ब्याज", "${Calc.num(g.interestRate)}%", "${Calc.num(v.rate)}%")
        ch("Mid-month cut-off day", "महीने की कट-ऑफ तारीख", day(g.cutoffDay), day(v.cutoffDay))
        val yn = { x: Boolean -> if (x) "Yes" else "No" }
        val ynHi = { x: Boolean -> if (x) "हाँ" else "नहीं" }
        if (first || g.oneLoan != v.oneLoan) changes += (if (first) "One loan at a time: ${yn(v.oneLoan)}" else "One loan at a time: ${yn(g.oneLoan)} → ${yn(v.oneLoan)}") to
            (if (first) "एक समय में एक लोन: ${ynHi(v.oneLoan)}" else "एक समय में एक लोन: ${ynHi(g.oneLoan)} → ${ynHi(v.oneLoan)}")
        ch("Stamp paper limit", "स्टाम्प पेपर सीमा", r(g.stampLimit), r(v.stampLimit))
        ch("Missed interest fine", "ब्याज न भरने का जुर्माना", r(g.interestFine), r(v.interestFine))
        if (changes.isEmpty()) return tx("Nothing changed", "कुछ नहीं बदला")
        val upd = mutableMapOf<String, Any>(
            "dueDay" to v.dueDay, "monthlySaving" to v.monthly, "lateFine" to v.lateFine, "yearlyFine" to v.yearlyFine,
            "interestMethod" to v.loanType, "interestRate" to v.rate, "cutoffDay" to v.cutoffDay, "oneLoan" to v.oneLoan,
            "stampLimit" to v.stampLimit, "interestFine" to v.interestFine, "financeSet" to true,
        )
        if (g.financeFromAt <= 0) upd["financeFromAt"] = now()
        val b = db.batch()
        b.update(gref(g.id), upd)
        val m = if (first) Msg("✅ ${meName()} filled the group financial settings — " + changes.joinToString("; ") { it.first },
            "✅ ${meName()} ने समूह की वित्तीय सेटिंग भरी — " + changes.joinToString("; ") { it.second })
        else Msg("${meName()} changed financial settings — " + changes.joinToString("; ") { it.first },
            "${meName()} ने वित्तीय सेटिंग बदली — " + changes.joinToString("; ") { it.second })
        b.act(g.id, Kind.RULE, m)
        b.note(g.id, "all", Msg(if (first) "Group setup complete" else "Financial settings changed", if (first) "समूह सेटअप पूरा" else "वित्तीय सेटिंग बदली"), m, Kind.RULE)
        commit(b)
        return null
    }

    /** Groups made before v1.3: automatic fines start from the day this version first runs (no surprise old fines). */
    fun stampFinanceStart(g: Group) {
        if (!g.financeSet || g.financeFromAt > 0) return
        gref(g.id).update("financeFromAt", now()).addOnFailureListener { }
    }

    fun setGroupColour(colour: String) {
        val g = g()
        if (!g.profileUnlocked) { Session.error = lockedMsg("profile"); return }
        if (g.colour == colour) return
        val names = mapOf("plum" to ("Plum Rose" to "प्लम रोज़"), "green" to ("Green Harvest" to "ग्रीन हार्वेस्ट"), "blue" to ("Royal Blue" to "रॉयल ब्लू"))
        val n = names[colour] ?: ("" to "")
        val b = db.batch()
        b.update(gref(g.id), "colour", colour)
        val m = Msg("${meName()} changed the group colour to ${n.first}", "${meName()} ने समूह का रंग ${n.second} किया")
        b.act(g.id, Kind.RULE, m)
        b.note(g.id, "all", Msg("Group colour changed", "समूह का रंग बदला"), m, Kind.RULE)
        commit(b)
    }

    fun setColourLocked(locked: Boolean) {
        val g = g()
        if (!g.profileUnlocked) { Session.error = lockedMsg("profile"); return }
        val b = db.batch()
        b.update(gref(g.id), "colourLocked", locked)
        val m = if (locked) Msg("🔒 ${meName()} locked the app colour — everyone uses the group colour", "🔒 ${meName()} ने रंग लॉक किया — सभी समूह का रंग इस्तेमाल करेंगे")
        else Msg("🔓 ${meName()} unlocked the app colour — members can choose their own", "🔓 ${meName()} ने रंग अनलॉक किया — सदस्य अपना रंग चुन सकते हैं")
        b.act(g.id, Kind.PERM, m)
        b.note(g.id, "all", Msg("Appearance lock changed", "रंग लॉक बदला"), m, Kind.PERM)
        commit(b)
    }

    fun setAlerts(a: Alerts) {
        val g = g()
        val b = db.batch()
        b.update(gref(g.id), "alerts", a.toMap())
        b.act(g.id, Kind.RULE, Msg("${meName()} updated group alert settings", "${meName()} ने समूह अलर्ट सेटिंग बदली"))
        commit(b)
    }

    fun announce(text: String) {
        val g = g()
        val b = db.batch()
        b.note(g.id, "all", Msg("Announcement from ${meName()}", "${meName()} की सूचना"), Msg(text, text), Kind.ANNOUNCE)
        b.act(g.id, Kind.ANNOUNCE, Msg("📢 ${meName()}: $text", "📢 ${meName()}: $text"))
        commit(b)
    }

    fun lowCashAlert(g: Group, cash: Double) {
        val b = db.batch()
        b.note(g.id, g.adminUid, Msg("Low cash warning", "कम नकद चेतावनी"),
            Msg("Cash in hand is ${r(cash)}, below your limit of ${r(g.alerts.lowCashLimit)}", "हाथ में नकद ${r(cash)} है, आपकी सीमा ${r(g.alerts.lowCashLimit)} से कम"), Kind.ALERT)
        b.commit()
    }

    // =====================================================================
    // Members
    // =====================================================================

    fun updateMyProfile(name: String, phone: String) {
        val g = g()
        val me = Session.me ?: return
        val b = db.batch()
        b.update(gref(g.id).collection("members").document(me.uid), mapOf("name" to name, "phone" to phone))
        if (me.role == Role.ADMIN) b.update(gref(g.id), "adminName", name)
        if (me.role == Role.CO) b.update(gref(g.id), "coAdminName", name)
        if (name != me.name) b.act(g.id, Kind.MEMBER, Msg("${me.name} changed their name to $name", "${me.name} ने अपना नाम $name किया"), me.uid)
        commit(b)
    }

    fun requestLeave() {
        val g = g()
        val me = Session.me ?: return
        val b = db.batch()
        b.update(gref(g.id).collection("members").document(me.uid), "status", MemberStatus.LEAVE_REQUESTED)
        val m = Msg("${me.name} asked to leave the group", "${me.name} ने समूह छोड़ने का अनुरोध किया")
        b.act(g.id, Kind.MEMBER, m, me.uid)
        b.note(g.id, g.adminUid, Msg("Leave request", "समूह छोड़ने का अनुरोध"), m, Kind.MEMBER)
        if (g.coAdminUid.isNotBlank()) b.note(g.id, g.coAdminUid, Msg("Leave request", "समूह छोड़ने का अनुरोध"), m, Kind.MEMBER)
        commit(b)
    }

    fun cancelLeave() {
        val g = g()
        val me = Session.me ?: return
        val b = db.batch()
        b.update(gref(g.id).collection("members").document(me.uid), "status", MemberStatus.ACTIVE)
        b.act(g.id, Kind.MEMBER, Msg("${me.name} cancelled their leave request", "${me.name} ने छोड़ने का अनुरोध वापस लिया"), me.uid)
        commit(b)
    }

    /** Pays back the member's savings (minus any loan they still owe) and removes them. */
    fun settleAndRemove(m: Member, payout: Double, note: String) {
        val g = g()
        val b = db.batch()
        if (payout > 0) {
            b.set(gref(g.id).collection("txns").document(),
                txnMap(TxType.WITHDRAW, m, payout, now(), false, note = note.ifBlank { "Settlement on leaving" }))
        }
        b.update(gref(g.id).collection("members").document(m.uid), mapOf("status" to MemberStatus.LEFT, "role" to Role.MEMBER))
        if (g.coAdminUid == m.uid) b.update(gref(g.id), mapOf(
            "coAdminUid" to "", "coAdminName" to "",
            "backdateUntil" to emptyMap<String, Long>(), "editUntil" to emptyMap<String, Long>(),
        ))
        val msg = Msg("${meName()} removed ${m.name} from the group" + (if (payout > 0) " (paid back ${r(payout)})" else ""),
            "${meName()} ने ${m.name} को समूह से हटाया" + (if (payout > 0) " (${r(payout)} वापस दिए)" else ""))
        b.act(g.id, Kind.MEMBER, msg, m.uid)
        b.note(g.id, "all", Msg("Member removed", "सदस्य हटाए गए"), msg, Kind.MEMBER)
        commit(b)
    }

    // =====================================================================
    // Money entries
    // =====================================================================

    /** Savings and loans need the financial settings to be filled first. */
    private fun ready(): Boolean {
        val g = Session.group
        if (g == null || !g.financeSet) {
            Session.error = tx("Group setup is not complete. Fill the financial settings first.", "समूह सेटअप पूरा नहीं है। पहले वित्तीय सेटिंग भरें।")
            return false
        }
        return true
    }

    fun addSaving(m: Member, month: String, amount: Double, chosenDate: Long?, addFine: Boolean, fineAmount: Double) {
        if (!ready()) return
        val g = g()
        val (date, back) = effectiveDate(chosenDate)
        val b = db.batch()
        b.set(gref(g.id).collection("txns").document(), txnMap(TxType.SAVING, m, amount, date, back, month = month))
        var fineTextEn = ""; var fineTextHi = ""
        if (addFine && fineAmount > 0 && !Calc.fineSettled(m.uid, FineKind.LATE_SAVING, month, Session.txns)) {
            b.set(gref(g.id).collection("txns").document(),
                txnMap(TxType.FINE, m, fineAmount, date, back, month = month, note = "Monthly saving late fine · ${monthEn(month)}") +
                    mapOf("fineKind" to FineKind.LATE_SAVING, "ref" to month))
            fineTextEn = " + late fine ${r(fineAmount)}"; fineTextHi = " + देर का जुर्माना ${r(fineAmount)}"
        }
        b.note(g.id, m.uid, Msg("Saving received ✅", "बचत प्राप्त ✅"),
            Msg("${r(amount)} saving received for ${monthEn(month)}$fineTextEn · by ${meName()}", "${monthHi(month)} की ${r(amount)} बचत प्राप्त$fineTextHi · ${meName()} द्वारा"), Kind.MONEY)
        b.act(g.id, Kind.MONEY, Msg("${meName()} added a saving entry for ${m.name} (${monthEn(month)})", "${meName()} ने ${m.name} की बचत एंट्री जोड़ी (${monthHi(month)})"), m.uid)
        commit(b)
    }

    fun addFine(m: Member, amount: Double, note: String, chosenDate: Long?) {
        if (!ready()) return
        val g = g()
        val (date, back) = effectiveDate(chosenDate)
        val b = db.batch()
        b.set(gref(g.id).collection("txns").document(), txnMap(TxType.FINE, m, amount, date, back, note = note))
        b.note(g.id, m.uid, Msg("Fine added", "जुर्माना जोड़ा"), Msg("${r(amount)} fine: $note", "${r(amount)} जुर्माना: $note"), Kind.MONEY)
        b.act(g.id, Kind.MONEY, Msg("${meName()} added a fine entry for ${m.name}", "${meName()} ने ${m.name} की जुर्माना एंट्री जोड़ी"), m.uid)
        commit(b)
    }

    /** The member paid an automatic (pending) fine. */
    fun collectFine(f: Calc.PendingFine, chosenDate: Long?) {
        if (!ready()) return
        val g = g()
        val m = Session.memberById(f.memberUid) ?: return
        if (Calc.fineSettled(f.memberUid, f.kind, f.ref, Session.txns)) return
        val (date, back) = effectiveDate(chosenDate)
        val month = if (f.kind == FineKind.LATE_SAVING) f.ref else ""
        val b = db.batch()
        b.set(gref(g.id).collection("txns").document(),
            txnMap(TxType.FINE, m, f.amount, date, back, month = month, note = f.en) + mapOf("fineKind" to f.kind, "ref" to f.ref))
        b.note(g.id, m.uid, Msg("Fine paid ✅", "जुर्माना जमा ✅"), Msg("${r(f.amount)} received · ${f.en}", "${r(f.amount)} प्राप्त · ${f.hi}"), Kind.MONEY)
        b.act(g.id, Kind.MONEY, Msg("${meName()} collected ${r(f.amount)} fine from ${m.name} (${f.en})", "${meName()} ने ${m.name} से ${r(f.amount)} जुर्माना लिया (${f.hi})"), m.uid)
        commit(b)
    }

    /** The admin lets a member off a pending fine. Everyone sees it in Group Activity. */
    fun waiveFine(f: Calc.PendingFine, reason: String): String? {
        if (!ready()) return null
        if (reason.isBlank()) return tx("Please write a reason", "कारण लिखें")
        val g = g()
        val m = Session.memberById(f.memberUid) ?: return null
        val month = if (f.kind == FineKind.LATE_SAVING) f.ref else ""
        val b = db.batch()
        b.set(gref(g.id).collection("txns").document(),
            txnMap(TxType.WAIVE, m, f.amount, now(), false, month = month, note = "${f.en} · $reason") + mapOf("fineKind" to f.kind, "ref" to f.ref))
        b.note(g.id, m.uid, Msg("Fine waived", "जुर्माना माफ़"), Msg("${r(f.amount)} fine waived by ${meName()} · ${f.en}. Reason: $reason", "${meName()} ने ${r(f.amount)} जुर्माना माफ़ किया · ${f.hi}। कारण: $reason"), Kind.MONEY)
        b.act(g.id, Kind.MONEY, Msg("${meName()} waived ${r(f.amount)} fine for ${m.name} (${f.en}). Reason: $reason", "${meName()} ने ${m.name} का ${r(f.amount)} जुर्माना माफ़ किया (${f.hi})। कारण: $reason"), m.uid)
        commit(b)
        return null
    }

    /**
     * Gives a loan using the group's current loan rules. The loan keeps its rate, meeting day and
     * cut-off day even if the group settings change later. Returns an error message or null.
     */
    fun newLoan(m: Member, amount: Double, method: String, months: Int, chosenDate: Long?, note: String, stampPaper: Boolean): String? {
        if (!ready()) return null
        val g = g()
        if (amount <= 0) return tx("Enter loan amount", "लोन राशि लिखें")
        if (method != LoanType.FLEXIBLE && months <= 0) return tx("Enter number of months", "महीनों की संख्या लिखें")
        if (g.oneLoan && Calc.hasOpenLoan(m.uid, Session.loans, Session.txns))
            return tx("${m.name} already has a loan. A new loan is given only after the old one is fully repaid.", "${m.name} का एक लोन पहले से चल रहा है। पुराना लोन पूरा चुकाने के बाद ही नया लोन मिलेगा।")
        if (g.stampLimit > 0 && amount >= g.stampLimit && !stampPaper)
            return tx("Loans of ${r(g.stampLimit)} or more need stamp paper. Tick \"Stamp paper received\".", "${r(g.stampLimit)} या उससे ज़्यादा के लोन पर स्टाम्प पेपर चाहिए। \"स्टाम्प पेपर मिला\" पर टिक करें।")
        val rate = g.interestRate
        val (date, back) = effectiveDate(chosenDate)
        val loanRef = gref(g.id).collection("loans").document()
        val n = if (method == LoanType.FLEXIBLE) 1 else months
        val loan = Loan(loanRef.id, m.uid, m.name, amount, rate, n, method, date, "active", false, meName(), note, g.dueDay, g.cutoffDay, stampPaper)
        val b = db.batch()
        b.set(loanRef, mapOf(
            "memberUid" to m.uid, "memberName" to m.name, "principal" to amount, "rate" to rate,
            "months" to n, "method" to method, "startDate" to date, "status" to "active",
            "opening" to false, "createdByName" to meName(), "note" to note, "createdAt" to now(),
            "dueDay" to g.dueDay, "cutoffDay" to g.cutoffDay, "stampPaper" to stampPaper,
        ))
        b.set(gref(g.id).collection("txns").document(), txnMap(TxType.LOAN, m, amount, date, back, loanId = loanRef.id, note = note))
        val body = if (loan.flexible) {
            val st = Calc.loanState(loan, emptyList(), date)
            Msg("Loan ${r(amount)} at ${Calc.num(rate)}% a month on the amount still due. Repay any amount any time. First interest ${r(st.nextAmount)} due ${Calc.date(st.nextDate)}." + if (stampPaper) " Stamp paper received." else "",
                "${r(amount)} का लोन, बाकी राशि पर ${Calc.num(rate)}% मासिक ब्याज। कभी भी कितना भी लौटा सकते हैं। पहला ब्याज ${r(st.nextAmount)}, ${Calc.date(st.nextDate)} को।" + if (stampPaper) " स्टाम्प पेपर मिला।" else "")
        } else {
            val emi = Calc.nextEmi(loan, amount)
            Msg("Loan ${r(amount)} at ${Calc.num(rate)}% monthly for $months months. First EMI ${r(emi)} due ${Calc.date(Calc.addMonths(date, 1))}.",
                "${r(amount)} का लोन, ${Calc.num(rate)}% मासिक ब्याज, $months महीने। पहली किस्त ${r(emi)}, ${Calc.date(Calc.addMonths(date, 1))} तक।")
        }
        b.note(g.id, m.uid, Msg("Loan given", "लोन दिया गया"), body, Kind.MONEY)
        b.act(g.id, Kind.MONEY, Msg("${meName()} gave a loan to ${m.name}", "${meName()} ने ${m.name} को लोन दिया"), m.uid)
        commit(b)
        return null
    }

    fun addRepayment(loan: Loan, principal: Double, interest: Double, chosenDate: Long?) {
        if (!ready()) return
        val g = g()
        val m = Session.memberById(loan.memberUid)
        val (date, back) = effectiveDate(chosenDate)
        val amount = principal + interest
        val left = Calc.outstanding(loan, Session.txns) - principal
        val b = db.batch()
        b.set(gref(g.id).collection("txns").document(), txnMap(
            TxType.REPAY, m, amount, date, back, principal = principal, interest = interest, loanId = loan.id,
            note = if (loan.flexible) "Loan ${r(principal)} + ${r(interest)} interest" else "EMI ${r(principal)} + ${r(interest)} interest",
        ))
        b.note(g.id, loan.memberUid, if (loan.flexible) Msg("Loan payment received ✅", "लोन भुगतान प्राप्त ✅") else Msg("EMI received ✅", "किस्त प्राप्त ✅"),
            Msg("${r(amount)} received (${r(principal)} + ${r(interest)} interest). Loan left: ${r(maxOf(0.0, left))}",
                "${r(amount)} प्राप्त (${r(principal)} + ${r(interest)} ब्याज)। बाकी लोन: ${r(maxOf(0.0, left))}"), Kind.MONEY)
        b.act(g.id, Kind.MONEY, Msg("${meName()} added a loan repayment for ${loan.memberName}", "${meName()} ने ${loan.memberName} की लोन किस्त जोड़ी"), loan.memberUid)
        commit(b)
    }

    fun addCashEntry(type: String, amount: Double, note: String, chosenDate: Long?) {
        val g = g()
        val (date, back) = effectiveDate(chosenDate)
        val b = db.batch()
        b.set(gref(g.id).collection("txns").document(), txnMap(type, null, amount, date, back, note = note))
        val m = if (type == TxType.INCOME) Msg("${meName()} added group income ${r(amount)}: $note", "${meName()} ने समूह आय ${r(amount)} जोड़ी: $note")
        else Msg("${meName()} added group expense ${r(amount)}: $note", "${meName()} ने समूह खर्च ${r(amount)} जोड़ा: $note")
        b.act(g.id, Kind.MONEY, m)
        commit(b)
    }

    private fun typeName(t: String): Msg = when (t) {
        TxType.SAVING -> Msg("saving", "बचत")
        TxType.FINE -> Msg("fine", "जुर्माना")
        TxType.LOAN -> Msg("loan", "लोन")
        TxType.REPAY -> Msg("repayment", "किस्त")
        TxType.INCOME -> Msg("income", "आय")
        TxType.EXPENSE -> Msg("expense", "खर्च")
        TxType.OPEN_SAVING -> Msg("opening saving", "शुरुआती बचत")
        TxType.OPEN_INTEREST -> Msg("opening interest", "शुरुआती ब्याज")
        TxType.PROFIT_SHARE -> Msg("profit share", "मुनाफ़ा हिस्सा")
        TxType.PROFIT_PAYOUT -> Msg("profit payout", "मुनाफ़ा भुगतान")
        TxType.WITHDRAW -> Msg("withdrawal", "निकासी")
        TxType.WAIVE -> Msg("fine waived", "जुर्माना माफ़")
        else -> Msg(t, t)
    }
    fun typeLabel(t: String): String = typeName(t).text()

    /** Edit needs the edit permission and a reason. Old values stay in the history. */
    fun editTxn(t: Txn, amount: Double, principal: Double, interest: Double, note: String, chosenDate: Long?, reason: String): String? {
        val g = g()
        if (!g.canEdit(uid())) return tx("Editing is OFF. Ask the ${if (Session.isAdmin) "co-admin" else "admin"} to allow it.", "एंट्री बदलना बंद है। ${if (Session.isAdmin) "सह-एडमिन" else "एडमिन"} से अनुमति लें।")
        if (reason.isBlank()) return tx("Please write a reason", "कारण लिखें")
        val parts = mutableListOf<String>()
        val upd = mutableMapOf<String, Any>()
        if (Calc.round2(amount) != t.amount) { parts += "${r(t.amount)} → ${r(amount)}"; upd["amount"] = Calc.round2(amount) }
        if (t.type == TxType.REPAY) {
            if (Calc.round2(principal) != t.principal) { parts += "principal ${r(t.principal)} → ${r(principal)}"; upd["principal"] = Calc.round2(principal) }
            if (Calc.round2(interest) != t.interest) { parts += "interest ${r(t.interest)} → ${r(interest)}"; upd["interest"] = Calc.round2(interest) }
        }
        if (note != t.note) { parts += "note changed"; upd["note"] = note }
        if (chosenDate != null && Calc.isoDate(chosenDate) != Calc.isoDate(t.date)) {
            if (!g.canBackdate(uid())) return tx("Changing the date needs back-date permission", "तारीख बदलने के लिए पिछली तारीख की अनुमति चाहिए")
            parts += "date ${Calc.date(t.date)} → ${Calc.date(chosenDate)}"; upd["date"] = chosenDate; upd["backdated"] = true
        }
        if (parts.isEmpty()) return tx("Nothing changed", "कुछ नहीं बदला")
        val detail = parts.joinToString(", ")
        upd["edited"] = true
        upd["history"] = FieldValue.arrayUnion(mapOf("action" to "edited", "by" to meName(), "at" to now(), "reason" to reason, "detail" to detail))
        val tn = typeName(t.type)
        val b = db.batch()
        b.update(gref(g.id).collection("txns").document(t.id), upd)
        if (t.type == TxType.LOAN && upd.containsKey("amount")) {
            b.update(gref(g.id).collection("loans").document(t.loanId), "principal", Calc.round2(amount))
        }
        val when_ = Calc.dateTime(now())
        if (t.memberUid.isNotBlank()) {
            val mon = if (t.month.isNotBlank()) " ${monthEn(t.month)}" else ""
            val monHi = if (t.month.isNotBlank()) " ${monthHi(t.month)}" else ""
            b.note(g.id, t.memberUid, Msg("✏️ Your entry was edited", "✏️ आपकी एंट्री बदली गई"),
                Msg("${meName()} edited your$mon ${tn.en}: $detail ($when_). Reason: $reason",
                    "${meName()} ने आपकी$monHi ${tn.hi} बदली: $detail ($when_)। कारण: $reason"), Kind.EDIT)
        }
        b.act(g.id, Kind.EDIT, Msg("✏️ ${meName()} edited a ${tn.en} entry", "✏️ ${meName()} ने एक ${tn.hi} एंट्री बदली"), t.memberUid)
        commit(b)
        return null
    }

    fun deleteTxn(t: Txn, reason: String): String? {
        val g = g()
        if (!g.canEdit(uid())) return tx("Editing is OFF. Ask the ${if (Session.isAdmin) "co-admin" else "admin"} to allow it.", "एंट्री बदलना बंद है। ${if (Session.isAdmin) "सह-एडमिन" else "एडमिन"} से अनुमति लें।")
        if (reason.isBlank()) return tx("Please write a reason", "कारण लिखें")
        val tn = typeName(t.type)
        val b = db.batch()
        b.update(gref(g.id).collection("txns").document(t.id), mapOf(
            "deleted" to true,
            "history" to FieldValue.arrayUnion(mapOf("action" to "deleted", "by" to meName(), "at" to now(), "reason" to reason, "detail" to "${r(t.amount)} removed")),
        ))
        if (t.type == TxType.LOAN && t.loanId.isNotBlank()) b.update(gref(g.id).collection("loans").document(t.loanId), "status", "cancelled")
        if (t.memberUid.isNotBlank()) {
            b.note(g.id, t.memberUid, Msg("🗑 Your entry was deleted", "🗑 आपकी एंट्री हटाई गई"),
                Msg("${meName()} deleted your ${tn.en} of ${r(t.amount)} (${Calc.dateTime(now())}). Reason: $reason",
                    "${meName()} ने आपकी ${r(t.amount)} की ${tn.hi} हटाई (${Calc.dateTime(now())})। कारण: $reason"), Kind.EDIT)
        }
        b.act(g.id, Kind.EDIT, Msg("🗑 ${meName()} deleted a ${tn.en} entry", "🗑 ${meName()} ने एक ${tn.hi} एंट्री हटाई"), t.memberUid)
        commit(b)
        return null
    }

    // =====================================================================
    // Meetings
    // =====================================================================

    /**
     * [attendanceDone] = the admin has marked who came (only for a meeting that has happened).
     * [moveDue] = this monthly meeting is later than the usual meeting day, so that month's saving and
     * interest fall due on the meeting date instead (only ever later — members get more time, never less).
     */
    fun saveMeeting(existing: Meeting?, date: Long, title: String, notes: String, attendees: List<String>, type: String, attendanceDone: Boolean, moveDue: Boolean = false) {
        val g = g()
        val ref = if (existing != null) gref(g.id).collection("meetings").document(existing.id) else gref(g.id).collection("meetings").document()
        val b = db.batch()
        // ---- one-month move of the due date ----
        val month = Calc.monthKey(date)
        val wantMove = moveDue && type == MeetingType.MONTHLY && g.financeSet && Calc.canMoveDue(date, g.dueDay)
        val newDay = Calc.startOfDay(date)
        val oldMonth = if (existing != null && existing.type == MeetingType.MONTHLY) Calc.monthKey(existing.date) else ""
        if (oldMonth.isNotBlank() && g.dueShift.containsKey(oldMonth) && (!wantMove || oldMonth != month)) {
            b.update(gref(g.id), "dueShift.$oldMonth", FieldValue.delete())
            val m = Msg("📅 ${Calc.shortMonth(oldMonth)} meeting is back on the usual day: saving and interest due by ${Calc.date(Calc.dueDateOf(oldMonth, g.dueDay))}",
                "📅 ${Calc.shortMonth(oldMonth, true)} की बैठक फिर सामान्य तारीख पर: बचत और ब्याज ${Calc.date(Calc.dueDateOf(oldMonth, g.dueDay))} तक")
            b.act(g.id, Kind.MEETING, m)
            b.note(g.id, "all", Msg("Meeting date changed", "बैठक की तारीख बदली"), m, Kind.MEETING)
        }
        if (wantMove && g.dueShift[month] != newDay) {
            b.update(gref(g.id), "dueShift.$month", newDay)
            val m = Msg("📅 ${Calc.shortMonth(month)} meeting moved to ${Calc.date(newDay)} — saving and loan interest for ${Calc.shortMonth(month)} are due by ${Calc.date(newDay)}. No late fine before that.",
                "📅 ${Calc.shortMonth(month, true)} की बैठक ${Calc.date(newDay)} को — ${Calc.shortMonth(month, true)} की बचत और लोन ब्याज ${Calc.date(newDay)} तक। उससे पहले कोई जुर्माना नहीं।")
            b.act(g.id, Kind.MEETING, m)
            b.note(g.id, "all", Msg("Meeting moved", "बैठक की तारीख बदली"), m, Kind.MEETING)
        }
        b.set(ref, mapOf(
            "date" to date, "title" to title, "notes" to notes, "attendees" to if (attendanceDone) attendees else emptyList(),
            "createdByName" to (existing?.createdByName ?: meName()),
            "type" to type, "attendanceDone" to attendanceDone,
        ), SetOptions.merge())
        if (existing == null) {
            val m = Msg("Meeting \"$title\" on ${Calc.dateTime(date)}", "बैठक \"$title\" — ${Calc.dateTime(date)}")
            b.note(g.id, "all", Msg("📅 Meeting", "📅 बैठक"), m, Kind.MEETING)
            b.act(g.id, Kind.MEETING, Msg("${meName()} added meeting: $title (${Calc.dateTime(date)})", "${meName()} ने बैठक जोड़ी: $title (${Calc.dateTime(date)})"))
        }
        if (attendanceDone) {
            val absent = Session.activeMembers.filter { it.uid !in attendees }
            val absentEn = if (absent.isEmpty()) "everyone present" else "absent: " + absent.joinToString(", ") { it.name }
            val absentHi = if (absent.isEmpty()) "सभी उपस्थित" else "अनुपस्थित: " + absent.joinToString(", ") { it.name }
            b.act(g.id, Kind.MEETING, Msg("${meName()} marked attendance for $title (${Calc.date(date)}): ${attendees.size} present, $absentEn",
                "${meName()} ने $title (${Calc.date(date)}) की उपस्थिति दर्ज की: ${attendees.size} उपस्थित, $absentHi"))
            if (type == MeetingType.YEARLY && g.yearlyFine > 0) absent.forEach { m ->
                b.note(g.id, m.uid, Msg("Yearly meeting absence fine", "वार्षिक बैठक अनुपस्थिति जुर्माना"),
                    Msg("You were marked absent from $title (${Calc.date(date)}). Fine ${r(g.yearlyFine)} is pending.",
                        "आप $title (${Calc.date(date)}) में अनुपस्थित दर्ज हुए। ${r(g.yearlyFine)} जुर्माना बाकी है।"), Kind.MONEY)
            }
        } else if (existing != null) {
            b.act(g.id, Kind.MEETING, Msg("${meName()} updated meeting: $title", "${meName()} ने बैठक अपडेट की: $title"))
        }
        commit(b)
    }

    // =====================================================================
    // Old records setup
    // =====================================================================

    /** Opening balances are part of the financial settings, so they need the co-admin's switch. Returns an error or null. */
    fun saveOpening(m: Member, saved: Double, interestPaid: Double, loanLeft: Double, rate: Double, monthsLeft: Int, method: String, asOf: Long): String? {
        val g = g()
        if (!g.financeSet) return tx("Fill the financial settings first.", "पहले वित्तीय सेटिंग भरें।")
        if (!g.financeUnlocked) return lockedMsg("finance")
        val b = db.batch()
        if (saved > 0) b.set(gref(g.id).collection("txns").document(), txnMap(TxType.OPEN_SAVING, m, saved, asOf, true, note = "Opening balance"))
        if (interestPaid > 0) b.set(gref(g.id).collection("txns").document(), txnMap(TxType.OPEN_INTEREST, m, interestPaid, asOf, true, note = "Interest paid before using the app"))
        if (loanLeft > 0) {
            val lref = gref(g.id).collection("loans").document()
            b.set(lref, mapOf(
                "memberUid" to m.uid, "memberName" to m.name, "principal" to loanLeft, "rate" to rate,
                "months" to if (method == LoanType.FLEXIBLE) 1 else monthsLeft.coerceAtLeast(1), "method" to method, "startDate" to asOf, "status" to "active",
                "opening" to true, "createdByName" to meName(), "note" to "Loan still due when the group started using the app", "createdAt" to now(),
                "dueDay" to g.dueDay, "cutoffDay" to g.cutoffDay, "stampPaper" to false,
            ))
        }
        b.update(gref(g.id).collection("members").document(m.uid), mapOf("opening" to "pending", "openingNote" to ""))
        b.note(g.id, m.uid, Msg("Please check your opening balance", "अपना शुरुआती बैलेंस जाँचें"),
            Msg("Saved ${r(saved)}, Loan ${r(loanLeft)}, Interest paid ${r(interestPaid)} (as of ${Calc.date(asOf)}). Open the app to Confirm or Report a mistake.",
                "बचत ${r(saved)}, लोन ${r(loanLeft)}, ब्याज भरा ${r(interestPaid)} (${Calc.date(asOf)} तक)। ऐप खोलकर पुष्टि करें या गलती बताएं।"), Kind.SETUP)
        b.act(g.id, Kind.SETUP, Msg("${meName()} entered the opening balance for ${m.name}", "${meName()} ने ${m.name} का शुरुआती बैलेंस डाला"), m.uid)
        commit(b)
        return null
    }

    fun confirmOpening(ok: Boolean, note: String) {
        val g = g()
        val me = Session.me ?: return
        val b = db.batch()
        b.update(gref(g.id).collection("members").document(me.uid), mapOf("opening" to if (ok) "confirmed" else "disputed", "openingNote" to note))
        val m = if (ok) Msg("${me.name} confirmed their opening balance ✅", "${me.name} ने अपने शुरुआती बैलेंस की पुष्टि की ✅")
        else Msg("${me.name} reported a mistake in their opening balance: $note", "${me.name} ने शुरुआती बैलेंस में गलती बताई: $note")
        b.act(g.id, Kind.SETUP, m, me.uid)
        b.note(g.id, g.adminUid, Msg(if (ok) "Opening balance confirmed" else "Opening balance mistake", if (ok) "शुरुआती बैलेंस पुष्टि" else "शुरुआती बैलेंस में गलती"), m, Kind.SETUP)
        commit(b)
    }

    fun closeSetup() {
        val g = g()
        val b = db.batch()
        b.update(gref(g.id), "setupClosed", true)
        val m = Msg("${meName()} closed Old Records Setup. Back-dating is now locked.", "${meName()} ने पुराने रिकॉर्ड सेटअप बंद किया। अब पिछली तारीख लॉक है।")
        b.act(g.id, Kind.SETUP, m)
        b.note(g.id, "all", Msg("Old records setup closed", "पुराने रिकॉर्ड सेटअप बंद"), m, Kind.SETUP)
        commit(b)
    }

    /** Rows from an Excel/CSV upload, entered with their real dates (setup period only). */
    data class ImportRow(val date: Long, val member: Member?, val type: String, val amount: Double, val note: String)

    fun importRows(rows: List<ImportRow>): String? {
        val g = g()
        if (!g.setupOpen()) return tx("Old records upload works only during the setup period", "पुराने रिकॉर्ड अपलोड केवल सेटअप के समय होता है")
        rows.chunked(400).forEachIndexed { i, chunk ->
            val b = db.batch()
            chunk.forEach { row ->
                val month = if (row.type == TxType.SAVING) Calc.monthKey(row.date) else ""
                b.set(gref(g.id).collection("txns").document(), txnMap(row.type, row.member, row.amount, row.date, true, month = month, note = row.note.ifBlank { "Imported old record" }))
            }
            if (i == 0) {
                val m = Msg("${meName()} uploaded ${rows.size} old records from Excel", "${meName()} ने Excel से ${rows.size} पुराने रिकॉर्ड अपलोड किए")
                b.act(g.id, Kind.SETUP, m)
                b.note(g.id, "all", Msg("Old records uploaded", "पुराने रिकॉर्ड अपलोड"), m, Kind.SETUP)
            }
            commit(b)
        }
        return null
    }

    // =====================================================================
    // Year-end profit share
    // =====================================================================

    fun shareProfit(shares: List<Pair<Member, Double>>, addToSavings: Boolean) {
        val g = g()
        val type = if (addToSavings) TxType.PROFIT_SHARE else TxType.PROFIT_PAYOUT
        val total = shares.sumOf { it.second }
        val b = db.batch()
        shares.filter { it.second > 0 }.forEach { (m, amt) ->
            b.set(gref(g.id).collection("txns").document(), txnMap(type, m, amt, now(), false, note = "Year-end profit share"))
            b.note(g.id, m.uid, Msg("🎯 Your profit share", "🎯 आपका मुनाफ़ा हिस्सा"),
                Msg("${r(amt)} " + if (addToSavings) "added to your savings" else "paid to you in cash",
                    "${r(amt)} " + if (addToSavings) "आपकी बचत में जोड़ा गया" else "आपको नकद दिया गया"), Kind.MONEY)
        }
        b.update(gref(g.id), "lastCloseAt", now())
        val m = Msg("${meName()} closed the year and shared profit ${r(total)} among members " + if (addToSavings) "(added to savings)" else "(paid in cash)",
            "${meName()} ने साल बंद किया और ${r(total)} मुनाफ़ा सदस्यों में बाँटा " + if (addToSavings) "(बचत में जोड़ा)" else "(नकद दिया)")
        b.act(g.id, Kind.MONEY, m)
        b.note(g.id, "all", Msg("Year-end profit shared", "साल का मुनाफ़ा बँटा"), m, Kind.MONEY)
        commit(b)
    }
}
