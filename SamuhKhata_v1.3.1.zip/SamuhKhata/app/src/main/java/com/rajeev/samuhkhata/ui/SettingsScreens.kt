package com.rajeev.samuhkhata.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rajeev.samuhkhata.core.Alerts
import com.rajeev.samuhkhata.core.Calc
import com.rajeev.samuhkhata.core.Exporter
import com.rajeev.samuhkhata.core.Kind
import com.rajeev.samuhkhata.core.LoanType
import com.rajeev.samuhkhata.core.Member
import com.rajeev.samuhkhata.core.Role
import com.rajeev.samuhkhata.core.MemberStatus
import com.rajeev.samuhkhata.core.Prefs
import com.rajeev.samuhkhata.core.Repo
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.tx

private val colourNames = listOf("plum" to ("Plum Rose" to "प्लम रोज़"), "green" to ("Green Harvest" to "ग्रीन हार्वेस्ट"), "blue" to ("Royal Blue" to "रॉयल ब्लू"))

@Composable
fun ColourPicker(selected: String, enabled: Boolean, onPick: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
        colourNames.forEach { (key, names) ->
            val on = key == selected
            Column(
                Modifier.alpha(if (!enabled && !on) 0.4f else 1f).clip(MaterialTheme.shapes.medium)
                    .then(if (enabled) Modifier.clickable { onPick(key) } else Modifier).padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Box(
                    Modifier.size(48.dp).then(if (on) Modifier.border(3.dp, swatch(key), CircleShape).padding(5.dp) else Modifier)
                        .clip(CircleShape).background(swatch(key)),
                    contentAlignment = Alignment.Center,
                ) { if (on) Icon(Icons.Outlined.Check, null, tint = Color.White) }
                Text(tx(names.first, names.second), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ModePicker() {
    Text(tx("Mode", "मोड"), style = MaterialTheme.typography.bodyLarge)
    Segmented(listOf("light" to tx("Light", "लाइट"), "dark" to tx("Dark", "डार्क"), "system" to tx("System", "सिस्टम")), Prefs.mode) { Prefs.changeMode(it) }
}

@Composable
private fun LanguageRow() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(tx("Language", "भाषा"), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Box(Modifier.weight(1f)) { Segmented(listOf("hi" to "हिंदी", "en" to "English"), if (Prefs.hindi) "hi" else "en") { Prefs.setLanguage(it == "hi") } }
    }
}

@Composable
private fun ProfileCard(title: String) {
    val me = Session.me ?: return
    var edit by remember { mutableStateOf(false) }
    SectionCard(title) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(me.initials, MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary, 52.dp)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(me.name, style = MaterialTheme.typography.titleMedium)
                Text(me.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("+91 " + me.phone.ifBlank { tx("[add phone]", "[फ़ोन जोड़ें]") }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { edit = true }) { Text(tx("Edit", "बदलें")) }
        }
        LanguageRow()
    }
    if (edit) {
        var name by remember { mutableStateOf(me.name) }
        var phone by remember { mutableStateOf(me.phone) }
        AlertDialog(
            onDismissRequest = { edit = false },
            title = { Text(tx("Edit profile", "प्रोफ़ाइल बदलें")) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(tx("Name", "नाम"), name, { name = it })
                Field(tx("Phone number", "फ़ोन नंबर"), phone, { phone = it.filter { c -> c.isDigit() }.take(10) }, number = true)
            } },
            confirmButton = { TextButton(onClick = { if (name.isNotBlank()) Repo.updateMyProfile(name.trim(), phone.trim()); edit = false }) { Text(tx("Save", "सेव करें")) } },
            dismissButton = { TextButton(onClick = { edit = false }) { Text(tx("Cancel", "रद्द करें")) } },
        )
    }
}

// ---------------------------------------------------------------- admin & co-admin settings

@Composable
fun AdminSettingsScreen(onSignOut: () -> Unit) {
    val g = Session.group ?: return
    val ctx = LocalContext.current
    val isAdmin = Session.isAdmin
    var signOut by remember { mutableStateOf(false) }
    Page(tx("Settings", "सेटिंग"), "${roleName(Session.me?.role ?: "")} · ${g.name}") {
        item { ProfileCard(tx("Profile", "प्रोफ़ाइल")) }
        item {
            SectionCard(tx("Appearance", "रूप-रंग")) {
                ModePicker()
                val canColour = isAdmin && g.profileUnlocked
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tx("Group colour", "समूह का रंग"), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    if (!g.profileUnlocked) Tag(tx("🔒 Locked", "🔒 लॉक"), MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary)
                }
                ColourPicker(g.colour, canColour) { Repo.setGroupColour(it) }
                Divider()
                ToggleRow(tx("Let members choose their own colour", "सदस्यों को अपना रंग चुनने दें"),
                    if (g.colourLocked) tx("🔒 Locked · everyone uses ${colourLabel(g.colour)}", "🔒 लॉक · सभी ${colourLabel(g.colour)} इस्तेमाल करेंगे") else tx("🔓 Unlocked · members can pick", "🔓 अनलॉक · सदस्य चुन सकते हैं"),
                    checked = !g.colourLocked, enabled = canColour) { Repo.setColourLocked(!it) }
                Text(tx("Group colour is part of the group profile: it changes only when the co-admin turns on \"Edit group profile\". Light, Dark and System mode are always each member's own choice.",
                    "समूह का रंग समूह प्रोफ़ाइल का हिस्सा है: सह-एडमिन के \"समूह प्रोफ़ाइल बदलें\" चालू करने पर ही बदलता है। लाइट, डार्क और सिस्टम मोड हमेशा हर सदस्य की अपनी पसंद है।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            SectionCard(tx("Group settings", "समूह सेटिंग"), padding = 12.dp) {
                ListRow(tx("Group profile", "समूह प्रोफ़ाइल"), tx("Name, village, start date, language", "नाम, गाँव, शुरू की तारीख, भाषा"),
                    badge = if (g.profileUnlocked) tx("🔓 Unlocked", "🔓 अनलॉक") else tx("🔒 Locked", "🔒 लॉक"), onClick = { Nav.go(Screen.GroupProfile) })
                Divider()
                ListRow(tx("Group financial settings", "समूह की वित्तीय सेटिंग"),
                    if (g.financeSet) tx("${Calc.rupees(g.monthlySaving)} · meeting ${g.dueDay} · ${Calc.num(g.interestRate)}% interest", "${Calc.rupees(g.monthlySaving)} · बैठक ${g.dueDay} तारीख · ${Calc.num(g.interestRate)}% ब्याज")
                    else tx("Not filled yet", "अभी नहीं भरी"),
                    badge = when { g.financeUnlocked -> tx("🔓 Unlocked", "🔓 अनलॉक"); !g.financeSet -> tx("To fill", "भरना है"); else -> tx("🔒 Locked", "🔒 लॉक") },
                    onClick = { Nav.go(Screen.FinanceSettings) })
                Divider()
                ListRow(tx("Manage members", "सदस्य प्रबंधन"), tx("${Session.activeMembers.size} members · co-admin: ${g.coAdminName.ifBlank { "none" }}", "${Session.activeMembers.size} सदस्य · सह-एडमिन: ${g.coAdminName.ifBlank { "कोई नहीं" }}"), onClick = { Nav.go(Screen.Members) })
                Divider()
                ListRow(tx("Invite code", "इनवाइट कोड"), g.inviteCode.chunked(3).joinToString(" "), onClick = { Nav.go(Screen.Members) })
                Divider()
                ListRow(tx("Permissions", "अनुमतियाँ"), tx("Settings, back-date & edit switches", "सेटिंग, पिछली तारीख और बदलाव के स्विच"), onClick = { Nav.go(Screen.Permissions) })
            }
        }
        item {
            SectionCard(tx("Group maintenance alerts", "समूह रखरखाव अलर्ट"), padding = 12.dp) {
                val a = g.alerts
                val on = listOf(a.savingDue, a.emi, a.meeting, a.lowCash, a.joinRequest).count { it }
                ListRow(tx("Alert settings", "अलर्ट सेटिंग"), tx("$on of 5 alerts on", "5 में से $on अलर्ट चालू"), onClick = { Nav.go(Screen.Alerts) })
            }
        }
        item {
            SectionCard(tx("Data & backup", "डेटा और बैकअप"), padding = 12.dp) {
                ListRow(tx("Export records", "रिकॉर्ड एक्सपोर्ट"), tx("Excel (CSV) · PDF reports", "Excel (CSV) · PDF रिपोर्ट"), onClick = { Nav.go(Screen.Reports) })
                Divider()
                ListRow(tx("Back up now (share Excel file)", "अभी बैकअप लें (Excel फ़ाइल शेयर)"), null, onClick = { Exporter.share(ctx, Exporter.recordsCsv(ctx, g, Session.txns), "text/csv") })
                Divider()
                ListRow(tx("Edit history log", "बदलाव इतिहास"), null, onClick = { Nav.go(Screen.ActivityLog(Kind.EDIT)) })
                Divider()
                ListRow(tx("Old Records Setup", "पुराने रिकॉर्ड सेटअप"), if (g.setupOpen()) tx("Open till ${Calc.date(g.setupUntil)}", "${Calc.date(g.setupUntil)} तक खुला") else tx("Closed", "बंद"), onClick = { Nav.go(Screen.OldRecords) })
                Divider()
                ListRow(tx("Year-end close & profit share", "साल बंद और मुनाफ़ा बँटवारा"), null, onClick = { Nav.go(Screen.ProfitShare) })
            }
        }
        item {
            Text(tx("Your records are saved online (Firebase) and on this phone. Sign in with the same Gmail on a new phone to get everything back.",
                "आपका हिसाब ऑनलाइन (Firebase) और इस फ़ोन में सुरक्षित है। नए फ़ोन पर वही Gmail से साइन इन करें, सब वापस आ जाएगा।"),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { SecondaryButton(tx("Sign out", "साइन आउट"), color = LocalExtra.current.badFg) { signOut = true } }
    }
    if (signOut) ConfirmDialog(tx("Sign out?", "साइन आउट करें?"), tx("Your records stay safe online.", "आपका हिसाब ऑनलाइन सुरक्षित रहेगा।"), tx("Sign out", "साइन आउट"), { signOut = false }) { onSignOut() }
}

private fun colourLabel(c: String): String = colourNames.firstOrNull { it.first == c }?.second?.let { tx(it.first, it.second) } ?: c

/** Lock status banner + (for the co-admin) the switch, shown at the top of both settings screens. */
@Composable
private fun LockCard(section: String) {
    val g = Session.group ?: return
    val me = Session.me ?: return
    val unlocked = if (section == "profile") g.profileUnlocked else g.financeUnlocked
    val (nameEn, nameHi) = if (section == "profile") "Edit group profile" to "समूह प्रोफ़ाइल बदलें" else "Edit financial settings" to "वित्तीय सेटिंग बदलें"
    when {
        g.coAdminUid.isBlank() -> {
            Banner(tx("🔒 Locked. Settings can only be changed when the co-admin allows it, so first add members and choose a co-admin.",
                "🔒 लॉक। सेटिंग केवल सह-एडमिन की अनुमति से बदलती है, इसलिए पहले सदस्य जोड़ें और सह-एडमिन चुनें।"), Icons.Outlined.Lock)
            if (Session.isAdmin) PrimaryButton(tx("Add members & choose co-admin", "सदस्य जोड़ें और सह-एडमिन चुनें")) { Nav.go(Screen.Members) }
        }
        me.role == Role.CO -> SectionCard {
            ToggleRow(if (unlocked) tx("🔓 $nameEn: ON", "🔓 $nameHi: चालू") else tx("🔒 $nameEn: OFF", "🔒 $nameHi: बंद"),
                if (unlocked) tx("${g.adminName} can change these now. Turn OFF to lock them again at once.", "${g.adminName} अभी इन्हें बदल सकते हैं। बंद करते ही फिर से लॉक हो जाएगा।")
                else tx("Turn ON to let ${g.adminName} change these. All members are notified.", "${g.adminName} को बदलने देने के लिए चालू करें। सभी सदस्यों को सूचना जाएगी।"),
                checked = unlocked) { Repo.setUnlock(section, it) }
        }
        unlocked -> Banner(tx("🔓 Unlocked by co-admin ${g.coAdminName}. Make your changes and save; the co-admin will lock it again.",
            "🔓 सह-एडमिन ${g.coAdminName} ने अनलॉक किया। बदलाव करके सेव करें; सह-एडमिन फिर लॉक कर देंगे।"), Icons.Outlined.LockOpen, warn = false)
        else -> Banner(tx("🔒 Locked. Only co-admin ${g.coAdminName} can unlock this (\"$nameEn\").",
            "🔒 लॉक। केवल सह-एडमिन ${g.coAdminName} इसे अनलॉक कर सकते हैं (\"$nameHi\")।"), Icons.Outlined.Lock)
    }
}

@Composable
fun GroupProfileScreen() {
    val g = Session.group ?: return
    val editable = Session.isAdmin && g.profileUnlocked
    var name by remember(g.id) { mutableStateOf(g.name) }
    var village by remember(g.id) { mutableStateOf(g.village) }
    var started by remember(g.id) { mutableStateOf(g.startedOn) }
    var lang by remember(g.id) { mutableStateOf(g.groupLanguage) }
    var max by remember(g.id) { mutableStateOf(if (g.maxSize == 0) "" else g.maxSize.toString()) }
    var err by remember { mutableStateOf("") }
    Page(tx("Group profile", "समूह प्रोफ़ाइल"), g.name, bottom = if (editable) ({
        PrimaryButton(tx("Save group profile", "समूह प्रोफ़ाइल सेव करें")) {
            val mx = if (max.isBlank()) 0 else max.toIntOrNull()
            err = when {
                name.isBlank() -> tx("Enter group name", "समूह का नाम लिखें")
                mx == null || mx < 0 -> tx("Max size must be a number (empty = no limit)", "अधिकतम संख्या लिखें (खाली = कोई सीमा नहीं)")
                (mx ?: 0) in 1 until Session.activeMembers.size -> tx("Max size is less than current members", "अधिकतम संख्या अभी के सदस्यों से कम है")
                else -> ""
            }
            if (err.isBlank()) {
                val e = Repo.updateProfile(name.trim(), village.trim(), started, lang, mx ?: 0)
                if (e != null) err = e else Nav.back()
            }
        }
    }) else null) {
        item { LockCard("profile") }
        item {
            SectionCard {
                Field(tx("Group name", "समूह का नाम"), name, { name = it }, enabled = editable)
                Field(tx("Village / area", "गाँव / क्षेत्र"), village, { village = it }, enabled = editable, placeholder = tx("e.g. Biharsharif, Nalanda", "जैसे बिहारशरीफ, नालंदा"))
                DateRow(tx("Group started on", "समूह शुरू होने की तारीख"), started, editable, tx("Locked", "लॉक")) { started = it }
                Text(tx("Group language", "समूह की भाषा"), style = MaterialTheme.typography.bodyMedium)
                Segmented(listOf("hi" to "हिंदी", "en" to "English"), lang) { if (editable) lang = it }
                Text(tx("New members see the app in this language first. Everyone can still change their own language.",
                    "नए सदस्यों को ऐप पहले इसी भाषा में दिखेगा। हर कोई अपनी भाषा खुद बदल सकता है।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Field(tx("Max group size (empty = no limit)", "अधिकतम सदस्य (खाली = कोई सीमा नहीं)"), max, { max = it.filter { c -> c.isDigit() } }, number = true, enabled = editable, placeholder = tx("e.g. 20", "जैसे 20"))
            }
        }
        item {
            Text(tx("Group colour is also part of the profile (Settings → Appearance). Every change goes to all members and Group Activity.",
                "समूह का रंग भी प्रोफ़ाइल का हिस्सा है (सेटिंग → रूप-रंग)। हर बदलाव सभी सदस्यों और समूह गतिविधि में जाता है।"),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (err.isNotBlank()) item { Banner(err) }
    }
}

private fun numOrBlank(set: Boolean, v: Double) = if (set) Calc.num(v) else ""
private fun dayOrBlank(set: Boolean, v: Int) = if (set && v > 0) v.toString() else ""

@Composable
fun FinanceSettingsScreen() {
    val g = Session.group ?: return
    val editable = Session.isAdmin && g.financeUnlocked
    val set = g.financeSet
    var day by remember(g.id) { mutableStateOf(dayOrBlank(set, g.dueDay)) }
    var monthly by remember(g.id) { mutableStateOf(numOrBlank(set, g.monthlySaving)) }
    var lateFine by remember(g.id) { mutableStateOf(numOrBlank(set, g.lateFine)) }
    var yearlyFine by remember(g.id) { mutableStateOf(numOrBlank(set, g.yearlyFine)) }
    var loanType by remember(g.id) { mutableStateOf(if (set) g.interestMethod else LoanType.FLEXIBLE) }
    var rate by remember(g.id) { mutableStateOf(numOrBlank(set, g.interestRate)) }
    var cutoff by remember(g.id) { mutableStateOf(dayOrBlank(set, g.cutoffDay)) }
    var oneLoan by remember(g.id) { mutableStateOf(if (set) (if (g.oneLoan) "yes" else "no") else "") }
    var stamp by remember(g.id) { mutableStateOf(numOrBlank(set, g.stampLimit)) }
    var interestFine by remember(g.id) { mutableStateOf(numOrBlank(set, g.interestFine)) }
    var err by remember { mutableStateOf("") }

    Page(tx("Group financial settings", "समूह की वित्तीय सेटिंग"), g.name, bottom = if (editable) ({
        PrimaryButton(if (set) tx("Save changes", "बदलाव सेव करें") else tx("Save & complete setup", "सेव करें और सेटअप पूरा करें")) {
            val d = day.toIntOrNull(); val m = monthly.money(); val lf = lateFine.money(); val yf = yearlyFine.money()
            val r = rate.money(); val c = cutoff.toIntOrNull(); val st = stamp.money(); val inf = interestFine.money()
            err = when {
                d == null || d !in 1..28 -> tx("1 · Meeting day must be 1 to 28", "1 · बैठक की तारीख 1 से 28 हो")
                m == null || m <= 0 -> tx("2 · Enter monthly saving amount", "2 · मासिक बचत राशि लिखें")
                lf == null || lf < 0 -> tx("3 · Enter monthly saving late fine (0 for none)", "3 · मासिक बचत देर का जुर्माना लिखें (नहीं तो 0)")
                yf == null || yf < 0 -> tx("4 · Enter yearly meeting absence fine (0 for none)", "4 · वार्षिक बैठक अनुपस्थिति जुर्माना लिखें (नहीं तो 0)")
                r == null || r < 0 -> tx("6 · Enter interest per month", "6 · प्रति माह ब्याज लिखें")
                c == null || c !in 1..28 -> tx("7 · Mid-month cut-off day must be 1 to 28", "7 · कट-ऑफ तारीख 1 से 28 हो")
                oneLoan.isBlank() -> tx("8 · Choose Yes or No for one loan at a time", "8 · एक समय में एक लोन — हाँ या नहीं चुनें")
                st == null || st < 0 -> tx("9 · Enter stamp paper limit (0 for none)", "9 · स्टाम्प पेपर सीमा लिखें (नहीं तो 0)")
                inf == null || inf < 0 -> tx("10 · Enter missed interest fine (0 for none)", "10 · ब्याज न भरने का जुर्माना लिखें (नहीं तो 0)")
                else -> ""
            }
            if (err.isBlank()) {
                val e = Repo.updateFinance(Repo.FinanceValues(d!!, m!!, lf!!, yf!!, loanType, r!!, c!!, oneLoan == "yes", st!!, inf!!))
                if (e != null) err = e else Nav.back()
            }
        }
    }) else null) {
        item { LockCard("finance") }
        if (!set) item {
            Banner(tx("Group setup is not complete. Savings and loans can be entered only after these settings are filled.",
                "समूह सेटअप पूरा नहीं है। ये सेटिंग भरने के बाद ही बचत और लोन की एंट्री होगी।"), Icons.Outlined.Info)
        }
        item {
            SectionCard(tx("Savings & meetings", "बचत और बैठक")) {
                Field(tx("1 · Meeting day of the month (1–28)", "1 · हर महीने बैठक की तारीख (1–28)"), day, { day = it.filter { c -> c.isDigit() }.take(2) }, number = true, enabled = editable, placeholder = tx("e.g. 20", "जैसे 20"))
                Field(tx("2 · Monthly saving amount (₹)", "2 · मासिक बचत राशि (₹)"), monthly, { monthly = it }, number = true, enabled = editable, placeholder = tx("e.g. ₹200", "जैसे ₹200"))
                Field(tx("3 · Monthly saving late fine (₹)", "3 · मासिक बचत देर का जुर्माना (₹)"), lateFine, { lateFine = it }, number = true, enabled = editable, placeholder = tx("e.g. ₹10", "जैसे ₹10"))
                Text(tx("If a member's saving is not recorded by the meeting day, this fine is added as pending automatically.",
                    "अगर बैठक की तारीख तक सदस्य की बचत दर्ज नहीं हुई तो यह जुर्माना अपने आप बाकी में जुड़ जाएगा।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Field(tx("4 · Yearly meeting absence fine (₹)", "4 · वार्षिक बैठक अनुपस्थिति जुर्माना (₹)"), yearlyFine, { yearlyFine = it }, number = true, enabled = editable, placeholder = tx("e.g. ₹50", "जैसे ₹50"))
            }
        }
        item {
            SectionCard(tx("Loans", "लोन")) {
                Text(tx("5 · Loan type", "5 · लोन का प्रकार"), style = MaterialTheme.typography.bodyMedium)
                Segmented(listOf(LoanType.FLEXIBLE to tx("Flexible", "लचीला"), LoanType.FLAT to tx("Flat EMI", "फ्लैट EMI"), LoanType.REDUCING to tx("Reducing EMI", "घटती EMI")), loanType) { if (editable) loanType = it }
                Text(when (loanType) {
                    LoanType.FLAT -> tx("Flat EMI: fixed months, interest every month on the full loan amount.", "फ्लैट EMI: तय महीने, हर महीने पूरे लोन पर ब्याज।")
                    LoanType.REDUCING -> tx("Reducing EMI: fixed months, interest only on the loan still due.", "घटती EMI: तय महीने, सिर्फ़ बाकी लोन पर ब्याज।")
                    else -> tx("Flexible: no fixed time or EMI. Interest every month on the loan still due; repay any amount any time.", "लचीला: कोई तय समय या EMI नहीं। हर महीने बाकी लोन पर ब्याज; कभी भी कितना भी लौटाएं।")
                }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Field(tx("6 · Interest per month (%)", "6 · प्रति माह ब्याज (%)"), rate, { rate = it }, number = true, enabled = editable, placeholder = tx("e.g. 1%", "जैसे 1%"))
                Field(tx("7 · Mid-month cut-off day", "7 · महीने की कट-ऑफ तारीख"), cutoff, { cutoff = it.filter { c -> c.isDigit() }.take(2) }, number = true, enabled = editable, placeholder = tx("e.g. 15", "जैसे 15"))
                Text(tx("Loan given on or before this day pays a full month's interest at that month's meeting. Loan given after it starts interest from the meeting day.",
                    "इस तारीख तक लिया गया लोन उसी महीने की बैठक पर पूरे महीने का ब्याज देगा। इसके बाद लिए लोन का ब्याज बैठक की तारीख से शुरू होगा।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(tx("8 · One loan at a time", "8 · एक समय में एक लोन"), style = MaterialTheme.typography.bodyMedium)
                Segmented(listOf("yes" to tx("Yes", "हाँ"), "no" to tx("No", "नहीं")), oneLoan) { if (editable) oneLoan = it }
                if (oneLoan.isBlank()) Text(tx("e.g. Yes", "जैसे हाँ"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Field(tx("9 · Stamp paper needed for loans from (₹)", "9 · इतने या ज़्यादा के लोन पर स्टाम्प पेपर (₹)"), stamp, { stamp = it }, number = true, enabled = editable, placeholder = tx("e.g. ₹20,000 (0 = not needed)", "जैसे ₹20,000 (0 = ज़रूरी नहीं)"))
                Field(tx("10 · Missed interest fine (₹)", "10 · ब्याज न भरने का जुर्माना (₹)"), interestFine, { interestFine = it }, number = true, enabled = editable, placeholder = tx("e.g. ₹10", "जैसे ₹10"))
            }
        }
        item {
            SectionCard(tx("11 · Opening balances", "11 · शुरुआती बैलेंस"), padding = 12.dp) {
                val done = Session.activeMembers.count { it.opening.isNotBlank() }
                ListRow(tx("Old records of each member", "हर सदस्य का पुराना हिसाब"),
                    if (g.setupOpen()) tx("$done of ${Session.activeMembers.size} entered · open till ${Calc.date(g.setupUntil)}", "${Session.activeMembers.size} में से $done डाले · ${Calc.date(g.setupUntil)} तक खुला")
                    else tx("Setup closed", "सेटअप बंद"),
                    onClick = { Nav.go(Screen.OldRecords) })
                Text(tx("For a group that was running before the app. Needs \"Edit financial settings\" ON.", "ऐप से पहले से चल रहे समूह के लिए। \"वित्तीय सेटिंग बदलें\" चालू होना चाहिए।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Text(tx("Every change goes to all members with the old and new value. Running loans keep the interest and dates they started with.",
                "हर बदलाव पुराने और नए मान के साथ सभी सदस्यों को जाता है। चल रहे लोन अपने शुरू के ब्याज और तारीख पर ही चलते हैं।"),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (err.isNotBlank()) item { Banner(err) }
    }
}

@Composable
fun GroupRulesViewScreen() {
    Page(tx("Group rules", "समूह के नियम")) {
        item { SectionCard { RulesText() } }
        item { Text(tx("Rules are locked. The admin can change them only when the co-admin allows it, and everyone is notified of every change.", "नियम लॉक हैं। सह-एडमिन की अनुमति से ही एडमिन इन्हें बदल सकते हैं, और हर बदलाव की सूचना सभी को जाती है।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
fun AlertsScreen() {
    val g = Session.group ?: return
    val a = g.alerts
    val editable = Session.isAdmin
    var saving by remember { mutableStateOf(a.savingDue) }
    var emi by remember { mutableStateOf(a.emi) }
    var meeting by remember { mutableStateOf(a.meeting) }
    var low by remember { mutableStateOf(a.lowCash) }
    var limit by remember { mutableStateOf(Calc.num(a.lowCashLimit)) }
    var join by remember { mutableStateOf(a.joinRequest) }
    Page(tx("Group maintenance alerts", "समूह रखरखाव अलर्ट"), bottom = if (editable) ({
        PrimaryButton(tx("Save", "सेव करें")) {
            Repo.setAlerts(Alerts(saving, emi, meeting, low, limit.money() ?: 5000.0, join)); Nav.back()
        }
    }) else null) {
        item {
            SectionCard {
                ToggleRow(tx("Saving due reminder", "बचत जमा याद"), tx("2 days before the due date · all members", "जमा तारीख से 2 दिन पहले · सभी सदस्य"), saving, editable) { saving = it }
                Divider()
                ToggleRow(tx("Loan EMI due & overdue", "लोन किस्त देय और बकाया"), tx("Borrower + admin", "लोन लेने वाले + एडमिन"), emi, editable) { emi = it }
                Divider()
                ToggleRow(tx("Meeting reminder", "बैठक याद"), tx("1 day before · all members", "1 दिन पहले · सभी सदस्य"), meeting, editable) { meeting = it }
                Divider()
                ToggleRow(tx("Low cash warning", "कम नकद चेतावनी"), tx("Admin only", "केवल एडमिन"), low, editable) { low = it }
                if (low) Field(tx("Warn when cash is below (₹)", "जब नकद इससे कम हो (₹)"), limit, { limit = it }, number = true, enabled = editable)
                Divider()
                ToggleRow(tx("New join request", "नया जुड़ने का अनुरोध"), tx("Admin + co-admin", "एडमिन + सह-एडमिन"), join, editable) { join = it }
            }
        }
        item {
            Banner(tx("Edit, permission and role alerts always go to members and cannot be turned off.", "बदलाव, अनुमति और भूमिका के अलर्ट हमेशा सदस्यों को जाते हैं और बंद नहीं हो सकते।"), Icons.Outlined.Lock, warn = false)
        }
    }
}

// ---------------------------------------------------------------- permissions (two-key)

@Composable
fun PermissionsScreen() {
    val g = Session.group ?: return
    val me = Session.me ?: return
    val now = System.currentTimeMillis()
    // Only the co-admin holds the switches, and they unlock the admin.
    val other: Member? = if (me.role == com.rajeev.samuhkhata.core.Role.CO) Session.memberById(g.adminUid) else null
    var turnOn by remember { mutableStateOf("") }

    Page(tx("Permissions", "अनुमतियाँ"), tx("Two-key safety: admin enters, co-admin unlocks", "दो-चाबी सुरक्षा: एडमिन एंट्री करें, सह-एडमिन अनुमति दें")) {
        if (g.coAdminUid.isBlank()) {
            item {
                Banner(tx("No co-admin yet. Settings, back-date and edit stay locked until the admin chooses a co-admin.", "अभी कोई सह-एडमिन नहीं। सह-एडमिन चुनने तक सेटिंग, पिछली तारीख और बदलाव लॉक रहेंगे।"))
            }
            if (Session.isAdmin) item { PrimaryButton(tx("Choose co-admin", "सह-एडमिन चुनें")) { Nav.go(Screen.Members) } }
        }
        if (g.setupOpen()) item {
            Banner(tx("Old Records Setup is open till ${Calc.date(g.setupUntil)}: back-dating is allowed for old notebook records during this time.",
                "पुराने रिकॉर्ड सेटअप ${Calc.date(g.setupUntil)} तक खुला: इस दौरान पुराने रिकॉर्ड पिछली तारीख से डाल सकते हैं।"), warn = false)
        }
        if (other != null) {
            item { SectionLabel(tx("You control these for ${other.name}", "${other.name} के लिए आपके हाथ में")) }
            item {
                SectionCard {
                    ToggleRow(tx("🏷 Edit group profile", "🏷 समूह प्रोफ़ाइल बदलें"),
                        if (g.profileUnlocked) tx("ON: ${other.name} can change name, village, start date, language and colour", "चालू: ${other.name} नाम, गाँव, तारीख, भाषा और रंग बदल सकते हैं")
                        else tx("OFF: group profile is locked", "बंद: समूह प्रोफ़ाइल लॉक है"),
                        checked = g.profileUnlocked) { Repo.setUnlock("profile", it) }
                    Divider()
                    ToggleRow(tx("💰 Edit financial settings", "💰 वित्तीय सेटिंग बदलें"),
                        if (g.financeUnlocked) tx("ON: ${other.name} can change saving, meeting day, interest, fines and opening balances", "चालू: ${other.name} बचत, बैठक तारीख, ब्याज, जुर्माना और शुरुआती बैलेंस बदल सकते हैं")
                        else if (!g.financeSet) tx("OFF: turn ON so ${other.name} can fill the group's money rules", "बंद: चालू करें ताकि ${other.name} समूह के पैसे के नियम भर सकें")
                        else tx("OFF: financial settings are locked", "बंद: वित्तीय सेटिंग लॉक है"),
                        checked = g.financeUnlocked) { Repo.setUnlock("finance", it) }
                    Text(tx("These stay ON until you turn them OFF. Turning OFF locks the settings at once.", "ये तब तक चालू रहते हैं जब तक आप बंद न करें। बंद करते ही सेटिंग लॉक हो जाती है।"),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            listOf("backdate" to (g.backdateUntil[other.uid] ?: 0L), "edit" to (g.editUntil[other.uid] ?: 0L)).forEach { (kind, until) ->
                item {
                    val active = until > now
                    SectionCard {
                        ToggleRow(
                            if (kind == "backdate") tx("📅 Back-date entries", "📅 पिछली तारीख की एंट्री") else tx("✏️ Edit entries", "✏️ एंट्री बदलना"),
                            if (active) tx("ON until ${Calc.dateTime(until)}", "${Calc.dateTime(until)} तक चालू")
                            else if (kind == "backdate") tx("OFF: ${other.name}'s entries get today's date and time automatically", "बंद: ${other.name} की एंट्री में आज की तारीख और समय अपने आप लगेगा")
                            else tx("OFF: ${other.name} cannot edit or delete saved entries", "बंद: ${other.name} सेव एंट्री बदल या हटा नहीं सकते"),
                            checked = active,
                        ) { on -> if (on) turnOn = kind else Repo.setPermission(kind, other, 0) }
                    }
                }
            }
            item { Text(tx("Every time a switch is turned ON or OFF, all members get a notification and it is saved in Group Activity.", "हर बार स्विच चालू या बंद करने पर सभी सदस्यों को सूचना जाती है और समूह गतिविधि में सेव होता है।"),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        if (Session.isAdmin) item { SectionLabel(tx("What you are allowed now", "आपको अभी क्या अनुमति है")) }
        if (Session.isAdmin) item {
            val b = g.backdateUntil[me.uid] ?: 0L
            val e = g.editUntil[me.uid] ?: 0L
            SectionCard {
                Text(tx("🏷 Group profile: ", "🏷 समूह प्रोफ़ाइल: ") + if (g.profileUnlocked) tx("unlocked", "अनलॉक") else tx("locked", "लॉक"))
                Text(tx("💰 Financial settings: ", "💰 वित्तीय सेटिंग: ") + if (g.financeUnlocked) tx("unlocked", "अनलॉक") else tx("locked", "लॉक"))
                Text(tx("📅 Back-date: ", "📅 पिछली तारीख: ") + if (b > now) tx("ON till ${Calc.dateTime(b)}", "${Calc.dateTime(b)} तक चालू") else if (g.setupOpen()) tx("only for setup period", "केवल सेटअप अवधि में") else tx("OFF", "बंद"))
                Text(tx("✏️ Edit: ", "✏️ बदलाव: ") + if (e > now) tx("ON till ${Calc.dateTime(e)}", "${Calc.dateTime(e)} तक चालू") else tx("OFF", "बंद"))
                Text(tx("Only the co-admin (${g.coAdminName.ifBlank { "not chosen" }}) can turn these on for you.", "केवल सह-एडमिन (${g.coAdminName.ifBlank { "नहीं चुने" }}) इन्हें आपके लिए चालू कर सकते हैं।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item { SecondaryButton(tx("See permission & role history", "अनुमति और भूमिका का इतिहास देखें")) { Nav.go(Screen.ActivityLog("permrole")) } }
    }

    if (turnOn.isNotBlank() && other != null) {
        var days by remember { mutableStateOf(1) }
        AlertDialog(
            onDismissRequest = { turnOn = "" },
            title = { Text(if (turnOn == "backdate") tx("Allow back-dating for how long?", "पिछली तारीख की अनुमति कितने समय?") else tx("Allow editing for how long?", "बदलाव की अनुमति कितने समय?")) },
            text = {
                Column {
                    listOf(1, 7, 30).forEach { d ->
                        Row(Modifier.fillMaxWidth().clickable { days = d }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = days == d, onClick = { days = d })
                            Text(if (d == 1) tx("1 day", "1 दिन") else tx("$d days", "$d दिन"))
                        }
                    }
                    Text(tx("It turns OFF by itself after this time. All members will be notified.", "इतने समय बाद यह अपने आप बंद हो जाएगा। सभी को सूचना जाएगी।"), style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { Repo.setPermission(turnOn, other, days); turnOn = "" }) { Text(tx("Turn ON", "चालू करें"), fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { turnOn = "" }) { Text(tx("Cancel", "रद्द करें")) } },
        )
    }
}

// ---------------------------------------------------------------- member settings

@Composable
fun MemberSettingsScreen(onSignOut: () -> Unit) {
    val g = Session.group ?: return
    val me = Session.me ?: return
    val ctx = LocalContext.current
    var leave by remember { mutableStateOf(false) }
    var signOut by remember { mutableStateOf(false) }
    var refresh by remember { mutableStateOf(0) }
    Page(tx("Settings", "सेटिंग"), "${roleName(me.role)} · ${g.name}") {
        item { ProfileCard(tx("My profile", "मेरी प्रोफ़ाइल")) }
        item {
            SectionCard(tx("Appearance", "रूप-रंग")) {
                ModePicker()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tx("Colour", "रंग"), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    if (g.colourLocked) Tag(tx("🔒 Set by admin", "🔒 एडमिन ने तय किया"), MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary)
                }
                val current = if (g.colourLocked || Prefs.personalColour.isBlank()) g.colour else Prefs.personalColour
                ColourPicker(current, !g.colourLocked) { Prefs.setColour(it) }
            }
        }
        item {
            SectionCard(tx("My alerts", "मेरे अलर्ट")) {
                key(refresh) {
                    listOf(
                        "saving" to (tx("My saving due", "मेरी बचत जमा") to (if (g.dueDay > 0) tx("2 days before the ${g.dueDay}th", "${g.dueDay} तारीख से 2 दिन पहले") else tx("2 days before the meeting day", "बैठक की तारीख से 2 दिन पहले"))),
                        "emi" to (tx("My loan interest / EMI", "मेरा लोन ब्याज / किस्त") to tx("Due and overdue", "देय और बकाया")),
                        "meeting" to (tx("Meeting reminder", "बैठक याद") to tx("1 day before", "1 दिन पहले")),
                        "announce" to (tx("Group announcements", "समूह सूचनाएं") to tx("Messages from admin", "एडमिन के संदेश")),
                    ).forEach { (k, t) ->
                        ToggleRow(t.first, t.second, Prefs.alertOn(k)) { Prefs.setAlert(k, it); refresh++ }
                    }
                }
                Text(tx("Edits to your entries, permission and role changes always notify you and can't be turned off.", "आपकी एंट्री में बदलाव, अनुमति और भूमिका के अलर्ट हमेशा आते हैं, बंद नहीं होते।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            SectionCard(tx("My group", "मेरा समूह"), padding = 12.dp) {
                val admin = Session.memberById(g.adminUid)
                val co = Session.memberById(g.coAdminUid)
                if (admin != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { ListRow(admin.name, tx("Admin", "एडमिन"), chevron = false) }
                    CallButton(admin.phone)
                }
                if (co != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { ListRow(co.name, tx("Co-admin", "सह-एडमिन"), chevron = false) }
                    CallButton(co.phone)
                }
                Divider()
                ListRow(tx("Group rules", "समूह के नियम"),
                    if (g.financeSet) "${Calc.rupees(g.monthlySaving)} · ${Calc.num(g.interestRate)}% · ${tx("fine", "जुर्माना")} ${Calc.rupees(g.lateFine)}" else tx("Being set up", "सेटअप चल रहा है"),
                    onClick = { Nav.go(Screen.GroupRules) })
                Divider()
                ListRow(tx("Member list", "सदस्य सूची"), tx("${Session.activeMembers.size} names", "${Session.activeMembers.size} नाम"), onClick = { Nav.go(Screen.MemberList) })
            }
        }
        item {
            SectionCard(tx("My records", "मेरा हिसाब"), padding = 12.dp) {
                ListRow(tx("Download my passbook", "मेरी पासबुक डाउनलोड"), "PDF", onClick = { Exporter.share(ctx, Exporter.passbook(ctx, g, me, Session.txns, Session.loans), "application/pdf") })
                Divider()
                ListRow(tx("Savings & loan history", "बचत और लोन इतिहास"), null, onClick = { Nav.go(Screen.Passbook(me.uid)) })
            }
        }
        item {
            if (me.status == MemberStatus.LEAVE_REQUESTED) SecondaryButton(tx("Cancel leave request", "छोड़ने का अनुरोध रद्द करें")) { Repo.cancelLeave() }
            else SecondaryButton(tx("Request to leave group", "समूह छोड़ने का अनुरोध"), color = LocalExtra.current.warnFg) { leave = true }
            Text(tx("Admin settles your savings and any loan first.", "पहले एडमिन आपकी बचत और लोन का हिसाब करेंगे।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
        }
        item { SecondaryButton(tx("Sign out", "साइन आउट"), color = LocalExtra.current.badFg) { signOut = true } }
    }
    if (leave) ConfirmDialog(tx("Request to leave?", "छोड़ने का अनुरोध करें?"), tx("The admin and co-admin will be notified.", "एडमिन और सह-एडमिन को सूचना जाएगी।"), tx("Send request", "अनुरोध भेजें"), { leave = false }) { Repo.requestLeave() }
    if (signOut) ConfirmDialog(tx("Sign out?", "साइन आउट करें?"), tx("Your records stay safe online.", "आपका हिसाब ऑनलाइन सुरक्षित रहेगा।"), tx("Sign out", "साइन आउट"), { signOut = false }) { onSignOut() }
}

@Composable
private fun key(k: Int, content: @Composable () -> Unit) = androidx.compose.runtime.key(k) { content() }
