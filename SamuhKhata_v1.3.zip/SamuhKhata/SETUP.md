# Samuh Khata v1.3 — Update steps (do this first)

1. **Publish the new security rules (required).** Firebase Console → Samuh Khata → Firestore Database → **Rules** →
   delete everything → paste the whole new `firestore.rules` from this zip → **Publish**.
   Without this, the co-admin's new settings switches will not save.
2. Build the APK as usual (same signing key — the Little Village Farm key, SHA-1 `EA:D8:EF:0D:…:61:CF`).
3. Install the new APK on the admin's and co-admin's phones first, then on members' phones.

## What's new in v1.3
- **Create group** asks only for the group name. Everything else starts empty and locked.
- Settings are split into **Group profile** (name, village, start date, language, colour, max size) and
  **Group financial settings** (meeting day, monthly saving, late fine, yearly meeting absence fine, loan type,
  interest per month, mid-month cut-off day, one loan at a time, stamp paper limit, missed interest fine, opening balances).
- Two new co-admin switches in ☰ → Permissions: **Edit group profile** and **Edit financial settings**.
  The admin can change a section only while its switch is ON; turning it OFF locks it at once. Every change is sent to all members
  with the old and new value.
- Until the financial settings are filled, a **"Group setup not complete"** banner shows and savings/loans cannot be entered.
- **Flexible loan** (default): interest every month on the loan still due, repay any amount any time.
  Loan taken on or before the cut-off day → full month's interest at that month's meeting; after it → interest starts from the meeting day.
- **Automatic pending fines**: monthly saving late fine, missed interest fine, yearly meeting absence fine.
  Members see their own; admin and co-admin see the **Pending fines** list. Admin can Collect or Waive (with a reason).
- **Meetings** are Monthly / Yearly / Other. Attendance: everyone ticked present by default; untick who was absent.
- **One loan at a time** and **stamp paper** checks when giving a loan.
- Google sign-in error code 10 now says it is a signing-key (SHA-1) problem, not internet.

### Existing groups (made with v1.2)
- Their money rules are kept and count as filled. The new fields (yearly fine, missed interest fine, cut-off day, stamp limit)
  start at 0 — the co-admin turns on "Edit financial settings" and the admin fills them in.
- Automatic fines start from the day the admin first opens v1.3 — no surprise fines for older months.
- Running loans keep their type (flat / reducing). New loans use the group's loan type.

---

# Samuh Khata — First-time setup (one time, ~10 minutes)

Package name: `com.rajeev.samuhkhata`

## 1. Firebase project
1. Open https://console.firebase.google.com → **Add project** → name it **Samuh Khata** (a new project, like Fleet Track and Family Shield).
2. **Build → Authentication → Get started → Sign-in method → Google → Enable → Save.**
3. **Build → Firestore Database → Create database** → choose a location near India (e.g. `asia-south1` Mumbai) → start in production mode.
4. **Firestore → Rules** → delete everything, paste the full `firestore.rules` file from this zip → **Publish**.

## 2. Add the Android app
1. Project settings (⚙️) → **Add app → Android**.
2. Android package name: `com.rajeev.samuhkhata`
3. Add the **SHA-1** of your signing key — the same shared test key your GitHub workflow uses (the one you already added for Tractor Khata / Fleet Track). Google sign-in will not work without it.
4. Download **google-services.json** and put it here inside the project:
   `SamuhKhata/app/google-services.json`
   (next to `app/build.gradle.kts`). The build fails without this file.

## 3. Build the APK
Zip the `SamuhKhata` folder (with `google-services.json` inside `app/`) and push it to your GitHub repo — the **Universal ZIP to APK** workflow builds and signs it as usual. Keep only one zip in the repo, or run the workflow with `zip_path`.

## 4. First use
1. **Admin:** sign in with Google → *Create a new group* → type the group name only.
2. **Members:** admin adds their Gmail (they join automatically on sign-in) **or** shares the 6-digit invite code (admin approves).
3. Admin chooses a **co-admin** (☰ → Members).
4. **Co-admin:** ☰ → Permissions → turn ON **Edit financial settings** (and **Edit group profile** if needed).
5. **Admin:** Settings → Group financial settings → fill all 10 values → *Save & complete setup*.
6. Old group with a notebook? Settings → Group financial settings → **11 · Opening balances** (open 30 days).
7. **Co-admin:** turn the switches OFF again. Everything is locked until the co-admin turns them ON next time.

## Costs
For one group of 10–20 members everything stays on Firebase's **free (Spark) plan**: Google sign-in, invite codes, Firestore, and notifications (they are shown by the app itself, no paid server).

---

# सेटअप (हिंदी)

**v1.3 अपडेट:** Firebase → Firestore Database → Rules में नई `firestore.rules` पूरी पेस्ट करके **Publish** करें (ज़रूरी)। फिर नई APK पहले एडमिन और सह-एडमिन के फ़ोन में डालें।
नया समूह: एडमिन सिर्फ़ नाम डालें → सदस्य जोड़ें → सह-एडमिन चुनें → सह-एडमिन "वित्तीय सेटिंग बदलें" चालू करें → एडमिन सेटिंग भरें → सह-एडमिन बंद करें।

1. Firebase में नया प्रोजेक्ट **Samuh Khata** बनाएं।
2. Authentication → Google चालू करें।
3. Firestore Database बनाएं (Mumbai), फिर Rules में `firestore.rules` पूरा पेस्ट करके Publish करें।
4. Android ऐप जोड़ें: पैकेज `com.rajeev.samuhkhata`, अपनी साइनिंग key का SHA-1 डालें।
5. `google-services.json` डाउनलोड करके `SamuhKhata/app/` में रखें।
6. फ़ोल्डर zip करके GitHub पर डालें — APK बन जाएगी।
