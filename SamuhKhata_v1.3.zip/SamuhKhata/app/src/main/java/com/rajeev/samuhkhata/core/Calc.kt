package com.rajeev.samuhkhata.core

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/** All money maths lives here so every screen shows the same numbers. */
object Calc {

    fun live(txns: List<Txn>) = txns.filter { !it.deleted }

    // ---------- savings ----------
    fun memberSavings(uid: String, txns: List<Txn>): Double = live(txns).filter { it.memberUid == uid }.sumOf {
        when (it.type) {
            TxType.SAVING, TxType.OPEN_SAVING, TxType.PROFIT_SHARE -> it.amount
            TxType.WITHDRAW -> -it.amount
            else -> 0.0
        }
    }

    fun memberFines(uid: String, txns: List<Txn>) =
        live(txns).filter { it.memberUid == uid && it.type == TxType.FINE }.sumOf { it.amount }

    fun memberInterestPaid(uid: String, txns: List<Txn>) = live(txns).filter { it.memberUid == uid }.sumOf {
        when (it.type) {
            TxType.REPAY -> it.interest
            TxType.OPEN_INTEREST -> it.amount
            else -> 0.0
        }
    }

    fun paidSaving(uid: String, month: String, txns: List<Txn>) =
        live(txns).any { it.memberUid == uid && it.type == TxType.SAVING && it.month == month }

    fun savingTxnFor(uid: String, month: String, txns: List<Txn>) =
        live(txns).firstOrNull { it.memberUid == uid && it.type == TxType.SAVING && it.month == month }

    // ---------- loans ----------
    fun repaidPrincipal(loan: Loan, txns: List<Txn>) =
        live(txns).filter { it.type == TxType.REPAY && it.loanId == loan.id }.sumOf { it.principal }

    fun repaidInterest(loan: Loan, txns: List<Txn>) =
        live(txns).filter { it.type == TxType.REPAY && it.loanId == loan.id }.sumOf { it.interest }

    fun outstanding(loan: Loan, txns: List<Txn>) = max(0.0, loan.principal - repaidPrincipal(loan, txns))

    fun principalPart(loan: Loan) = loan.principal / loan.months

    /** Interest for the next instalment. Flat = on the full loan; reducing = on what is still due. */
    fun interestDue(loan: Loan, outstanding: Double): Double {
        val base = if (loan.method == "reducing") outstanding else loan.principal
        return round2(base * loan.rate / 100.0)
    }

    fun nextEmi(loan: Loan, outstanding: Double): Double {
        if (outstanding <= 0.5) return 0.0
        return round2(min(principalPart(loan), outstanding) + interestDue(loan, outstanding))
    }

    /** Splits an amount paid into interest first, then principal. */
    fun split(loan: Loan, outstanding: Double, amount: Double): Pair<Double, Double> {
        val interest = min(amount, interestDue(loan, outstanding))
        val principal = min(max(0.0, amount - interest), outstanding)
        return round2(principal) to round2(interest)
    }

    fun instalmentsPaid(loan: Loan, outstanding: Double): Int {
        val part = principalPart(loan)
        if (part <= 0) return 0
        return floor((loan.principal - outstanding) / part + 0.001).toInt().coerceIn(0, loan.months)
    }

    fun nextDueDate(loan: Loan, outstanding: Double): Long {
        val paid = instalmentsPaid(loan, outstanding)
        return addMonths(loan.startDate, paid + 1)
    }

    fun isOverdue(loan: Loan, outstanding: Double, now: Long = System.currentTimeMillis()): Boolean {
        if (loan.status != "active" || outstanding <= 0.5) return false
        return now > nextDueDate(loan, outstanding) + DAY
    }

    fun schedule(loan: Loan): List<Triple<Long, Double, Double>> {
        val list = mutableListOf<Triple<Long, Double, Double>>()
        var left = loan.principal
        val part = principalPart(loan)
        for (i in 1..loan.months) {
            val interest = interestDue(loan, left)
            val p = min(part, left)
            list += Triple(addMonths(loan.startDate, i), round2(p), interest)
            left -= p
        }
        return list
    }

    // ---------- flexible loans ----------
    // Interest is charged month by month on the loan still due, and falls due on the meeting day.
    // Loan given on or before the cut-off day: a full month's interest at that month's meeting.
    // Loan given after the cut-off day (up to the meeting day): interest starts from the meeting day,
    // so the first interest falls due at the next month's meeting.

    /** One month of interest on a flexible loan. [start] and [due] are at 00:00 of their day. */
    data class Period(val start: Long, val due: Long, val balance: Double, val interest: Double)

    fun startOfDay(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** 00:00 on [day] of the month that contains [t]. */
    fun dayInMonth(t: Long, day: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = startOfDay(t)
        c.set(Calendar.DAY_OF_MONTH, day.coerceIn(1, 28))
        return c.timeInMillis
    }

    fun flexPeriods(loan: Loan, txns: List<Txn>, until: Long): List<Period> {
        val day = loan.dueDay.coerceIn(1, 28)
        val repays = live(txns).filter { it.type == TxType.REPAY && it.loanId == loan.id }
        fun repaidBefore(t: Long) = repays.filter { it.date < t }.sumOf { it.principal }
        val loanDay = dayOfMonth(loan.startDate)
        var meeting = dayInMonth(loan.startDate, day)
        if (loanDay > day) meeting = addMonths(meeting, 1)
        val skipFirst = loanDay > loan.cutoffDay && loanDay <= day
        var start: Long
        var due: Long
        if (skipFirst) { start = meeting + DAY; due = addMonths(meeting, 1) }
        else { start = startOfDay(loan.startDate); due = meeting }
        val list = mutableListOf<Period>()
        var guard = 0
        while (guard < 600 && start <= until) {
            val bal = max(0.0, loan.principal - repaidBefore(start))
            if (bal <= 0.5) break
            list += Period(start, due, round2(bal), round2(bal * loan.rate / 100.0))
            start = due + DAY
            due = addMonths(due, 1)
            guard++
        }
        return list
    }

    /** Everything a screen needs to know about one loan, for every loan type. */
    data class LoanState(
        val outstanding: Double,
        val interestPaid: Double,
        /** Interest whose meeting day has come and is not paid yet. */
        val interestDueNow: Double,
        /** Same, plus the running month's interest (a payment pays this first). */
        val interestAccrued: Double,
        /** Next payment date (00:00), or 0 when nothing more is due. */
        val nextDate: Long,
        val nextAmount: Double,
        val overdue: Boolean,
        /** Loan and all its interest are fully paid. */
        val finished: Boolean,
    )

    fun loanState(loan: Loan, txns: List<Txn>, now: Long = System.currentTimeMillis()): LoanState {
        val out = outstanding(loan, txns)
        val paidI = repaidInterest(loan, txns)
        if (!loan.flexible) {
            val done = out <= 0.5
            val i = if (done) 0.0 else interestDue(loan, out)
            return LoanState(out, paidI, i, i, if (done) 0L else nextDueDate(loan, out),
                if (done) 0.0 else nextEmi(loan, out), isOverdue(loan, out, now), done)
        }
        val periods = flexPeriods(loan, txns, now + 45 * DAY)
        val accrued = periods.filter { it.start <= now }.sumOf { it.interest }
        val dueSum = periods.filter { it.due <= now }.sumOf { it.interest }
        var cum = 0.0
        var found: Period? = null
        for (p in periods) {
            cum += p.interest
            if (cum > paidI + 0.5) { found = p; break }
        }
        val next: Period? = found
        val nextAmount = if (next == null) 0.0
            else max(0.0, round2(periods.filter { it.due <= next.due }.sumOf { it.interest } - paidI))
        val accNow = max(0.0, round2(accrued - paidI))
        return LoanState(
            outstanding = out,
            interestPaid = paidI,
            interestDueNow = max(0.0, round2(dueSum - paidI)),
            interestAccrued = accNow,
            nextDate = next?.due ?: 0L,
            nextAmount = nextAmount,
            overdue = next != null && next.due + DAY <= now,
            finished = out <= 0.5 && accNow <= 0.5,
        )
    }

    /** Splits an amount paid into (loan part, interest): interest first, then the loan. */
    fun splitPayment(loan: Loan, txns: List<Txn>, amount: Double, now: Long = System.currentTimeMillis()): Pair<Double, Double> {
        val out = outstanding(loan, txns)
        if (!loan.flexible) return split(loan, out, amount)
        val st = loanState(loan, txns, now)
        val interest = min(amount, st.interestAccrued)
        val principal = min(max(0.0, amount - interest), out)
        return round2(principal) to round2(interest)
    }

    /** True if the member still has a loan that is not fully paid (loan + interest). */
    fun hasOpenLoan(uid: String, loans: List<Loan>, txns: List<Txn>): Boolean =
        loans.any { it.memberUid == uid && it.status != "cancelled" && !loanState(it, txns).finished }

    // ---------- automatic fines ----------

    data class PendingFine(
        val memberUid: String,
        val memberName: String,
        val kind: String,
        val ref: String,
        val amount: Double,
        /** The day the fine became due. */
        val date: Long,
        val en: String,
        val hi: String,
    ) {
        val key: String get() = "$memberUid|$kind|$ref"
    }

    fun fineSettled(uid: String, kind: String, ref: String, txns: List<Txn>): Boolean = live(txns).any {
        it.memberUid == uid && (it.type == TxType.FINE || it.type == TxType.WAIVE) && it.fineKind == kind && it.ref == ref
    }

    /**
     * Fines that are owed but not yet paid. Nothing is written to the records until the admin
     * collects (or waives) a fine, so cash and profit stay correct.
     */
    fun pendingFines(
        g: Group, members: List<Member>, txns: List<Txn>, loans: List<Loan>, meetings: List<Meeting>,
        now: Long = System.currentTimeMillis(),
    ): List<PendingFine> {
        if (!g.financeSet || g.financeFromAt <= 0) return emptyList()
        val from = g.financeFromAt
        val people = members.filter { it.status != MemberStatus.LEFT }
        val byUid = people.associateBy { it.uid }
        val alive = live(txns)
        val settled = alive.filter { it.type == TxType.FINE || it.type == TxType.WAIVE }
            .map { "${it.memberUid}|${it.fineKind}|${it.ref}" }.toHashSet()
        // Late fines entered by hand before v1.3 (tagged only with the month).
        val oldLateFines = alive.filter { it.type == TxType.FINE && it.fineKind.isBlank() && it.month.isNotBlank() }
            .map { "${it.memberUid}|${it.month}" }.toHashSet()
        val savingDate = HashMap<String, Long>()
        alive.filter { it.type == TxType.SAVING }.forEach {
            val k = "${it.memberUid}|${it.month}"
            savingDate[k] = min(savingDate[k] ?: Long.MAX_VALUE, it.date)
        }
        val out = mutableListOf<PendingFine>()
        fun add(m: Member, kind: String, ref: String, amount: Double, date: Long, en: String, hi: String) {
            if (amount <= 0) return
            if ("${m.uid}|$kind|$ref" in settled) return
            out += PendingFine(m.uid, m.name, kind, ref, amount, date, en, hi)
        }

        // 1. Monthly saving not paid by the meeting day
        if (g.lateFine > 0 && g.dueDay in 1..28) {
            var month = monthKey(from)
            val last = monthKey(now)
            var guard = 0
            while (month <= last && guard < 240) {
                val due = dueDateOf(month, g.dueDay)
                if (due > from && due < now) {
                    people.forEach { m ->
                        if (m.joinedAt < due) {
                            val paidAt = savingDate["${m.uid}|$month"]
                            val late = paidAt == null || paidAt > due
                            if (late && "${m.uid}|$month" !in oldLateFines) {
                                add(m, FineKind.LATE_SAVING, month, g.lateFine, startOfDay(due),
                                    "Monthly saving late fine · ${shortMonth(month)} ${month.take(4)}",
                                    "मासिक बचत देर का जुर्माना · ${shortMonth(month, true)} ${month.take(4)}")
                            }
                        }
                    }
                }
                month = shiftMonth(month, 1)
                guard++
            }
        }

        // 2. Loan interest (or EMI) not paid by its due day
        if (g.interestFine > 0) {
            loans.filter { it.status != "cancelled" }.forEach { loan ->
                val m = byUid[loan.memberUid] ?: return@forEach
                val repays = alive.filter { it.type == TxType.REPAY && it.loanId == loan.id }
                if (loan.flexible) {
                    var cumDue = 0.0
                    flexPeriods(loan, txns, now).forEachIndexed { i, p ->
                        cumDue += p.interest
                        val end = p.due + DAY
                        if (end > now || p.due <= from) return@forEachIndexed
                        val paidBy = repays.filter { it.date < end }.sumOf { it.interest }
                        if (paidBy < cumDue - 0.5) {
                            add(m, FineKind.MISSED_INTEREST, "${loan.id}_${i + 1}", g.interestFine, p.due,
                                "Missed interest fine · due ${date(p.due)}", "ब्याज न भरने का जुर्माना · ${date(p.due)} को देय")
                        }
                    }
                } else {
                    val part = principalPart(loan)
                    for (k in 1..loan.months) {
                        val dueK = startOfDay(addMonths(loan.startDate, k))
                        val end = dueK + DAY
                        if (end > now) break
                        if (dueK <= from) continue
                        val expected = min(loan.principal, k * part)
                        val paidBy = repays.filter { it.date < end }.sumOf { it.principal }
                        if (paidBy < expected - 0.5) {
                            add(m, FineKind.MISSED_INTEREST, "${loan.id}_$k", g.interestFine, dueK,
                                "Missed EMI fine · due ${date(dueK)}", "किस्त न भरने का जुर्माना · ${date(dueK)} को देय")
                        }
                    }
                }
            }
        }

        // 3. Absent from the yearly meeting
        if (g.yearlyFine > 0) {
            meetings.filter { it.type == MeetingType.YEARLY && it.attendanceDone && it.date < now && it.date > from }.forEach { mt ->
                people.forEach { m ->
                    if (m.joinedAt < mt.date && m.uid !in mt.attendees) {
                        add(m, FineKind.YEARLY_ABSENCE, mt.id, g.yearlyFine, startOfDay(mt.date),
                            "Yearly meeting absence fine · ${date(mt.date)}", "वार्षिक बैठक अनुपस्थिति जुर्माना · ${date(mt.date)}")
                    }
                }
            }
        }
        return out.sortedWith(compareBy<PendingFine> { it.memberName.lowercase() }.thenBy { it.date })
    }

    // ---------- group summary ----------
    fun profitEarned(txns: List<Txn>) = live(txns).sumOf {
        when (it.type) {
            TxType.REPAY -> it.interest
            TxType.OPEN_INTEREST, TxType.FINE, TxType.INCOME -> it.amount
            TxType.EXPENSE -> -it.amount
            else -> 0.0
        }
    }

    fun profitDistributed(txns: List<Txn>) = live(txns)
        .filter { it.type == TxType.PROFIT_SHARE || it.type == TxType.PROFIT_PAYOUT }.sumOf { it.amount }

    fun summary(txns: List<Txn>, loans: List<Loan>): Summary {
        val savings = live(txns).sumOf {
            when (it.type) {
                TxType.SAVING, TxType.OPEN_SAVING, TxType.PROFIT_SHARE -> it.amount
                TxType.WITHDRAW -> -it.amount
                else -> 0.0
            }
        }
        val profit = profitEarned(txns) - profitDistributed(txns)
        val active = loans.filter { it.status == "active" }
        val lent = active.sumOf { outstanding(it, txns) }
        val fund = savings + profit
        return Summary(
            fund = round2(fund), cash = round2(fund - lent), lent = round2(lent),
            profit = round2(profit), savings = round2(savings),
            activeLoans = active.count { outstanding(it, txns) > 0.5 },
            updatedAt = System.currentTimeMillis(),
        )
    }

    /** Each member's share of undistributed profit, by how much they have saved. */
    fun profitShares(members: List<Member>, txns: List<Txn>): List<Pair<Member, Double>> {
        val profit = profitEarned(txns) - profitDistributed(txns)
        val active = members.filter { it.status != MemberStatus.LEFT }
        val weights = active.map { it to max(0.0, memberSavings(it.uid, txns)) }
        val total = weights.sumOf { it.second }
        if (total <= 0 || profit <= 0) return active.map { it to 0.0 }
        return weights.map { (m, w) -> m to floor(profit * w / total) }
    }

    // ---------- dates & money ----------
    const val DAY = 24L * 60 * 60 * 1000

    fun monthKey(t: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyy-MM", Locale.US).format(Date(t))

    fun monthStart(key: String): Long {
        val p = key.split("-")
        val c = Calendar.getInstance()
        c.clear()
        c.set(p[0].toInt(), p[1].toInt() - 1, 1)
        return c.timeInMillis
    }

    fun shiftMonth(key: String, by: Int): String = monthKey(addMonths(monthStart(key), by))

    fun monthLabel(key: String, hindi: Boolean = false): String =
        SimpleDateFormat("MMMM yyyy", if (hindi) Locale("hi", "IN") else Locale.ENGLISH).format(Date(monthStart(key)))

    fun shortMonth(key: String, hindi: Boolean = false): String =
        SimpleDateFormat("MMMM", if (hindi) Locale("hi", "IN") else Locale.ENGLISH).format(Date(monthStart(key)))

    fun addMonths(t: Long, n: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.add(Calendar.MONTH, n)
        return c.timeInMillis
    }

    fun dueDateOf(key: String, dueDay: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = monthStart(key)
        c.set(Calendar.DAY_OF_MONTH, dueDay)
        c.set(Calendar.HOUR_OF_DAY, 23)
        c.set(Calendar.MINUTE, 59)
        return c.timeInMillis
    }

    fun dayOfMonth(t: Long = System.currentTimeMillis()): Int {
        val c = Calendar.getInstance(); c.timeInMillis = t; return c.get(Calendar.DAY_OF_MONTH)
    }

    fun round2(v: Double) = (v * 100).roundToLong() / 100.0

    fun date(t: Long): String = SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(Date(t))
    fun shortDate(t: Long): String = SimpleDateFormat("d MMM", Locale.ENGLISH).format(Date(t))
    fun dateTime(t: Long): String = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.ENGLISH).format(Date(t))
    fun shortDateTime(t: Long): String = SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH).format(Date(t))
    fun isoDate(t: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(t))

    fun parseIsoDate(s: String): Long? = try {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(s.trim())?.time
    } catch (e: Exception) { null }

    /** ₹1,24,500 style (Indian grouping). Shows paise only when present. */
    fun rupees(v: Double): String {
        val neg = v < 0
        val a = abs(v)
        val whole = floor(a + 0.0000001).toLong()
        val paise = ((a - whole) * 100).roundToLong()
        val s = whole.toString()
        val grouped = if (s.length <= 3) s else {
            val last3 = s.takeLast(3)
            var rest = s.dropLast(3)
            val parts = mutableListOf<String>()
            while (rest.length > 2) { parts.add(0, rest.takeLast(2)); rest = rest.dropLast(2) }
            if (rest.isNotEmpty()) parts.add(0, rest)
            parts.joinToString(",") + "," + last3
        }
        val p = if (paise in 1..99) "." + paise.toString().padStart(2, '0') else ""
        return (if (neg) "−" else "") + "₹" + grouped + p
    }

    fun num(v: Double): String = if (v == floor(v)) v.toLong().toString() else round2(v).toString()

    fun newCode(): String = (100000..999999).random().toString()
}
