package com.rajeev.samuhkhata.core

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.math.abs

enum class AppState { SIGNED_OUT, LOADING, NO_GROUP, WAITING, READY, REMOVED }

/** Live copy of the signed-in user's group, kept in sync with Firestore (also offline). */
object Session {
    private val scope = MainScope()
    val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    lateinit var app: Context

    var user by mutableStateOf<FirebaseUser?>(null)
    var state by mutableStateOf(AppState.LOADING)
    var error by mutableStateOf<String?>(null)
    var toast by mutableStateOf<String?>(null)

    var pendingGroupName by mutableStateOf("")
    var pendingGroupId = ""
    var rejected by mutableStateOf(false)

    var group by mutableStateOf<Group?>(null)
    var me by mutableStateOf<Member?>(null)
    var members by mutableStateOf<List<Member>>(emptyList())
    var txns by mutableStateOf<List<Txn>>(emptyList())
    var loans by mutableStateOf<List<Loan>>(emptyList())
    var meetings by mutableStateOf<List<Meeting>>(emptyList())
    var activity by mutableStateOf<List<Activity>>(emptyList())
    var inbox by mutableStateOf<List<InboxMsg>>(emptyList())
    var joinRequests by mutableStateOf<List<JoinRequest>>(emptyList())
    var invites by mutableStateOf<List<Invite>>(emptyList())
    var proposals by mutableStateOf<List<Proposal>>(emptyList())
    /** "yes" / "no" if I already voted in the open proposal, else "". Only I can read my vote. */
    var myVote by mutableStateOf("")
    private var voteReg: ListenerRegistration? = null
    private var voteFor = ""

    private val regs = mutableListOf<ListenerRegistration>()
    private val roleRegs = mutableListOf<ListenerRegistration>()
    private var listeningAsStaff: Boolean? = null
    private var inboxMine: List<InboxMsg> = emptyList()
    private var inboxAll: List<InboxMsg> = emptyList()
    private var seenJoinRequests = mutableSetOf<String>()
    private var firstJoinSnapshot = true

    val uid: String get() = user?.uid ?: ""
    val isStaff: Boolean get() = me?.isStaff == true
    val isAdmin: Boolean get() = me?.role == Role.ADMIN
    val activeMembers: List<Member> get() = members.filter { it.status != MemberStatus.LEFT }

    fun init(ctx: Context) {
        app = ctx.applicationContext
        auth.addAuthStateListener {
            val u = it.currentUser
            if (u?.uid != user?.uid || state == AppState.LOADING || state == AppState.SIGNED_OUT) {
                user = u
                restart()
            }
        }
    }

    fun restart() {
        stopAll()
        if (user == null) { state = AppState.SIGNED_OUT; return }
        scope.launch { resolve() }
    }

    fun signOut() {
        stopAll()
        auth.signOut()
        Prefs.lastGroupId = ""
        user = null
        state = AppState.SIGNED_OUT
    }

    private fun stopAll() {
        regs.forEach { it.remove() }; regs.clear()
        roleRegs.forEach { it.remove() }; roleRegs.clear()
        listeningAsStaff = null
        group = null; me = null; members = emptyList(); txns = emptyList(); loans = emptyList()
        meetings = emptyList(); activity = emptyList(); inbox = emptyList()
        joinRequests = emptyList(); invites = emptyList()
        proposals = emptyList(); myVote = ""; voteReg?.remove(); voteReg = null; voteFor = ""
        inboxMine = emptyList(); inboxAll = emptyList()
        seenJoinRequests.clear(); firstJoinSnapshot = true
    }

    private suspend fun resolve() {
        state = AppState.LOADING
        rejected = false
        val u = user ?: return
        val email = (u.email ?: "").lowercase()
        try {
            val userDoc = db.collection("users").document(u.uid).get().await()
            val gid = userDoc.getString("groupId") ?: ""
            if (gid.isNotBlank()) {
                val m = db.collection("groups").document(gid).collection("members").document(u.uid).get().await()
                if (m.exists() && m.getString("status") != MemberStatus.LEFT) { attach(gid); return }
                if (m.exists()) { state = AppState.REMOVED; return }
            }
            if (email.isNotBlank()) {
                val inv = db.collection("invitesByEmail").document(email).get().await()
                val ig = inv.getString("gid") ?: ""
                if (inv.exists() && ig.isNotBlank()) {
                    Repo.joinFromInvite(ig, u)
                    attach(ig)
                    return
                }
            }
            val pending = userDoc.getString("pendingGroupId") ?: ""
            if (pending.isNotBlank()) {
                pendingGroupName = userDoc.getString("pendingGroupName") ?: ""
                waitFor(pending)
                return
            }
            state = AppState.NO_GROUP
        } catch (e: Exception) {
            // Offline: open the last group from the phone's saved copy.
            val last = Prefs.lastGroupId
            if (last.isNotBlank()) attach(last) else {
                error = tx("No internet. Connect once to open your group.", "इंटरनेट नहीं है। अपना समूह खोलने के लिए एक बार इंटरनेट चालू करें।")
                state = AppState.NO_GROUP
            }
        }
    }

    fun waitFor(gid: String) {
        pendingGroupId = gid
        state = AppState.WAITING
        val memberRef = db.collection("groups").document(gid).collection("members").document(uid)
        var memberExists = false
        regs += memberRef.addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists()) {
                memberExists = true
                db.collection("users").document(uid)
                    .set(mapOf("groupId" to gid, "pendingGroupId" to "", "pendingGroupName" to ""))
                regs.forEach { it.remove() }; regs.clear()
                attach(gid)
            }
        }
        regs += db.collection("groups").document(gid).collection("joinRequests").document(uid)
            .addSnapshotListener { snap, _ ->
                if (snap != null && !snap.exists() && !snap.metadata.isFromCache && !memberExists) {
                    // Request removed without a member record = rejected by admin.
                    scope.launch {
                        kotlinx.coroutines.delay(1500)
                        if (state == AppState.WAITING && !memberExists) {
                            db.collection("users").document(uid)
                                .set(mapOf("groupId" to "", "pendingGroupId" to "", "pendingGroupName" to ""))
                            regs.forEach { it.remove() }; regs.clear()
                            rejected = true
                            state = AppState.NO_GROUP
                        }
                    }
                }
            }
    }

    fun attach(gid: String) {
        Prefs.lastGroupId = gid
        if (Prefs.lastNotifiedAt == 0L) Prefs.lastNotifiedAt = System.currentTimeMillis()
        val gref = db.collection("groups").document(gid)

        regs += gref.addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists()) {
                val g = snap.toGroup()
                group = g
                // The group's language is the default until this person picks their own.
                if (g.groupLanguage.isNotBlank() && !Prefs.languageChosen) Prefs.applyGroupLanguage(g.groupLanguage == "hi")
                watchMyVote(gid, g.activeProposalId)
                afterChange()
            }
        }
        regs += gref.collection("proposals").orderBy("at", Query.Direction.DESCENDING).limit(30)
            .addSnapshotListener { snap, _ ->
                if (snap != null) proposals = snap.documents.map { it.toProposal() }
            }
        regs += gref.collection("members").addSnapshotListener { snap, err ->
            if (err != null && err.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) { state = AppState.REMOVED; return@addSnapshotListener }
            if (snap == null) return@addSnapshotListener
            members = snap.documents.map { it.toMember() }.sortedBy { it.name.lowercase() }
            val mine = members.firstOrNull { it.uid == uid }
            me = mine
            when {
                mine == null && !snap.metadata.isFromCache -> state = AppState.REMOVED
                mine != null && mine.status == MemberStatus.LEFT -> state = AppState.REMOVED
                mine != null -> {
                    if (state != AppState.READY) state = AppState.READY
                    if (listeningAsStaff != mine.isStaff) listenByRole(gid, mine.isStaff)
                }
            }
        }
        regs += gref.collection("meetings").addSnapshotListener { snap, _ ->
            if (snap != null) meetings = snap.documents.map { it.toMeeting() }.sortedByDescending { it.date }
        }
        regs += gref.collection("activity").orderBy("at", Query.Direction.DESCENDING).limit(400)
            .addSnapshotListener { snap, _ ->
                if (snap != null) activity = snap.documents.map { it.toActivity() }
            }
        regs += gref.collection("inbox").whereEqualTo("toUid", uid).addSnapshotListener { snap, _ ->
            if (snap != null) { inboxMine = snap.documents.map { it.toInbox() }; mergeInbox() }
        }
        regs += gref.collection("inbox").whereEqualTo("toUid", "all").addSnapshotListener { snap, _ ->
            if (snap != null) { inboxAll = snap.documents.map { it.toInbox() }; mergeInbox() }
        }
    }

    private fun watchMyVote(gid: String, pid: String) {
        if (pid == voteFor) return
        voteReg?.remove(); voteReg = null; voteFor = pid; myVote = ""
        if (pid.isBlank()) return
        voteReg = db.collection("groups").document(gid).collection("proposals").document(pid)
            .collection("votes").document(uid).addSnapshotListener { snap, _ ->
                myVote = if (snap != null && snap.exists()) snap.getString("vote") ?: "" else ""
            }
    }

    val openProposal: Proposal? get() {
        val g = group ?: return null
        if (g.activeProposalId.isBlank()) return null
        return proposals.firstOrNull { it.id == g.activeProposalId && it.status == "open" }
    }

    private fun listenByRole(gid: String, staff: Boolean) {
        roleRegs.forEach { it.remove() }; roleRegs.clear()
        listeningAsStaff = staff
        val gref = db.collection("groups").document(gid)
        val txQ: Query = if (staff) gref.collection("txns") else gref.collection("txns").whereEqualTo("memberUid", uid)
        val loanQ: Query = if (staff) gref.collection("loans") else gref.collection("loans").whereEqualTo("memberUid", uid)
        roleRegs += txQ.addSnapshotListener { snap, _ ->
            if (snap != null) { txns = snap.documents.map { it.toTxn() }.sortedByDescending { it.date }; afterChange() }
        }
        roleRegs += loanQ.addSnapshotListener { snap, _ ->
            if (snap != null) { loans = snap.documents.map { it.toLoan() }.sortedByDescending { it.startDate }; afterChange() }
        }
        if (staff) {
            roleRegs += gref.collection("joinRequests").addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                joinRequests = snap.documents.map { it.toJoinRequest() }.sortedBy { it.at }
                val g = group
                if (!firstJoinSnapshot && g != null && g.alerts.joinRequest) {
                    joinRequests.filter { it.uid !in seenJoinRequests }.forEach {
                        Notifier.show(app, "join_${it.uid}",
                            tx("New join request", "नया जुड़ने का अनुरोध"),
                            tx("${it.name} wants to join ${g.name}", "${it.name} ${g.name} से जुड़ना चाहते हैं"))
                    }
                }
                firstJoinSnapshot = false
                seenJoinRequests.addAll(joinRequests.map { it.uid })
            }
            roleRegs += gref.collection("invites").addSnapshotListener { snap, _ ->
                if (snap != null) invites = snap.documents.map { it.toInvite() }.sortedBy { it.email }
            }
        } else {
            joinRequests = emptyList(); invites = emptyList()
        }
    }

    private fun mergeInbox() {
        val all = (inboxMine + inboxAll).distinctBy { it.id }.sortedByDescending { it.at }
        inbox = all
        val last = Prefs.lastNotifiedAt
        val fresh = all.filter { it.at > last }
        if (fresh.isNotEmpty()) {
            fresh.sortedBy { it.at }.forEach { m -> if (m.fromUid != uid && shouldShow(m)) Notifier.showInbox(app, m) }
            Prefs.lastNotifiedAt = fresh.maxOf { it.at }
        }
    }

    /** Members can switch off announcements; edit, permission and role alerts can never be switched off. */
    fun shouldShow(m: InboxMsg): Boolean = when (m.kind) {
        Kind.ANNOUNCE -> Prefs.alertOn("announce")
        Kind.MEETING -> Prefs.alertOn("meeting")
        else -> true
    }

    /** Staff phones keep the group totals, loan status and timed permissions up to date. */
    private fun afterChange() {
        val g = group ?: return
        val m = me ?: return
        if (!m.isStaff || listeningAsStaff != true) return
        val gref = db.collection("groups").document(g.id)

        // Loans close themselves when fully repaid — loan and interest (and reopen if an entry is edited). Admin phone only.
        if (m.role == Role.ADMIN) loans.forEach { loan ->
            if (loan.status == "active" || loan.status == "closed") {
                val want = if (Calc.loanState(loan, txns).finished) "closed" else "active"
                if (want != loan.status) gref.collection("loans").document(loan.id).update("status", want)
            }
        }
        if (m.role == Role.ADMIN) Repo.stampFinanceStart(g)

        val s = Calc.summary(txns, loans)
        val old = g.summary
        if (abs(s.fund - old.fund) > 0.009 || abs(s.cash - old.cash) > 0.009 || abs(s.lent - old.lent) > 0.009 ||
            abs(s.profit - old.profit) > 0.009 || abs(s.savings - old.savings) > 0.009 || s.activeLoans != old.activeLoans
        ) {
            gref.update("summary", s.toMap())
        }

        // Low cash warning (admin only), sent once each time cash drops below the limit.
        if (m.role == Role.ADMIN) {
            val low = g.alerts.lowCash && s.cash < g.alerts.lowCashLimit
            if (low && !g.lowCashFlag) {
                gref.update("lowCashFlag", true)
                Repo.lowCashAlert(g, s.cash)
            } else if (!low && g.lowCashFlag) {
                gref.update("lowCashFlag", false)
            }
            Repo.expirePermissions(g)
        }
    }

    fun memberById(id: String) = members.firstOrNull { it.uid == id }

    // ---------- pending (automatic) fines, worked out again only when the records change ----------
    private var fineInputs: List<Any?> = emptyList()
    private var fineCache: List<Calc.PendingFine> = emptyList()

    /** Staff see everyone's pending fines; a member sees only their own. */
    val pendingFines: List<Calc.PendingFine>
        get() {
            val g = group ?: return emptyList()
            val m = me ?: return emptyList()
            val day = Calc.isoDate(System.currentTimeMillis())
            val inputs = listOf(g, txns, loans, meetings, members, m, day)
            val same = fineInputs.size == inputs.size && fineInputs.indices.all { i ->
                if (i == inputs.lastIndex) fineInputs[i] == inputs[i] else fineInputs[i] === inputs[i]
            }
            if (!same) {
                val who = if (m.isStaff) members else members.filter { it.uid == m.uid }
                fineCache = Calc.pendingFines(g, who, txns, loans, meetings)
                fineInputs = inputs
            }
            return fineCache
        }
}
