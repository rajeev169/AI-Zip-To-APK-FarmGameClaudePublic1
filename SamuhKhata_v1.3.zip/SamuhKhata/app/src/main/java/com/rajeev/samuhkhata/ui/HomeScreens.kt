package com.rajeev.samuhkhata.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.HowToVote
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.Savings
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.samuhkhata.core.Calc
import com.rajeev.samuhkhata.core.Kind
import com.rajeev.samuhkhata.core.MemberStatus
import com.rajeev.samuhkhata.core.Prefs
import com.rajeev.samuhkhata.core.Repo
import com.rajeev.samuhkhata.core.Role
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.TxType
import com.rajeev.samuhkhata.core.tx

// ---------------------------------------------------------------- shared top

@Composable
private fun HomeTop(greetingName: String, chips: List<String>, onMenu: () -> Unit) {
    val ex = LocalExtra.current
    val g = Session.group
    Column(Modifier.fillMaxWidth().background(ex.header).statusBarsPadding().padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 64.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(g?.name ?: "", color = ex.onHeader.copy(alpha = 0.9f), style = MaterialTheme.typography.bodyMedium)
                Text(tx("Namaste, $greetingName", "नमस्ते, $greetingName"), color = ex.onHeader, style = MaterialTheme.typography.headlineSmall)
            }
            HeaderIcon(Icons.Outlined.Menu, tx("Menu", "मेन्यू"), onMenu)
            HeaderIcon(Icons.Outlined.Settings, tx("Settings", "सेटिंग")) { Nav.go(Screen.Settings) }
        }
        Gap(10.dp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            chips.forEachIndexed { i, c ->
                Text(c, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    color = if (i == 0) ex.header else ex.onHeader,
                    modifier = Modifier.clip(RoundedCornerShape(99.dp))
                        .background(if (i == 0) ex.onHeader else ex.onHeader.copy(alpha = 0.16f))
                        .padding(horizontal = 10.dp, vertical = 3.dp))
            }
        }
    }
}

@Composable
private fun HeaderIcon(icon: ImageVector, desc: String, onClick: () -> Unit) {
    val ex = LocalExtra.current
    Box(Modifier.padding(start = 4.dp).size(44.dp).clip(RoundedCornerShape(12.dp)).background(ex.onHeader.copy(alpha = 0.14f)).clickable { onClick() },
        contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = ex.onHeader)
    }
}

@Composable
private fun HomeFrame(greetingName: String, chips: List<String>, menu: List<MenuEntry>, body: @Composable () -> Unit) {
    var open by remember { mutableStateOf(false) }
    BackHandler(enabled = open) { open = false }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            HomeTop(greetingName, chips) { open = true }
            Column(Modifier.offset(y = (-48).dp).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                body()
            }
            Box(Modifier.navigationBarsPadding())
        }
        RightMenu(open, menu) { open = false }
    }
}

// ---------------------------------------------------------------- ☰ menu

data class MenuEntry(val icon: ImageVector, val title: String, val sub: String, val badge: Int = 0, val warn: Boolean = false, val divider: Boolean = false, val accent: Boolean = false, val go: () -> Unit)

@Composable
private fun RightMenu(open: Boolean, entries: List<MenuEntry>, onClose: () -> Unit) {
    val ex = LocalExtra.current
    val g = Session.group
    val me = Session.me
    AnimatedVisibility(open, enter = fadeIn(), exit = fadeOut()) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)).clickable { onClose() })
    }
    AnimatedVisibility(open, enter = slideInHorizontally { it }, exit = slideOutHorizontally { it }, modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterEnd) {
            Surface(Modifier.fillMaxHeight().width(320.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 12.dp) {
                Column {
                    Row(Modifier.fillMaxWidth().background(ex.header).statusBarsPadding().padding(start = 20.dp, end = 12.dp, top = 16.dp, bottom = 16.dp),
                        verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(g?.name ?: "", color = ex.onHeader, style = MaterialTheme.typography.titleLarge)
                            Text("${me?.name ?: ""} · ${roleName(me?.role ?: "")}", color = ex.onHeader.copy(alpha = 0.9f), style = MaterialTheme.typography.bodySmall)
                        }
                        HeaderIcon(Icons.Outlined.Close, tx("Close menu", "मेन्यू बंद करें"), onClose)
                    }
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(8.dp)) {
                        entries.forEach { e ->
                            if (e.divider) item { Box(Modifier.padding(horizontal = 12.dp, vertical = 6.dp).fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant)) }
                            item {
                                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onClose(); e.go() }.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                    if (e.accent) IconBox(e.icon, ex.infoBg, ex.infoFg) else IconBox(e.icon)
                                    Column(Modifier.weight(1f)) {
                                        Text(e.title, style = MaterialTheme.typography.titleMedium)
                                        Text(e.sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (e.badge > 0) Text(e.badge.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                        color = if (e.warn) ex.warnFg else Color.White,
                                        modifier = Modifier.clip(RoundedCornerShape(99.dp)).background(if (e.warn) ex.warnBg else ex.infoFg).padding(horizontal = 8.dp, vertical = 2.dp))
                                }
                            }
                        }
                    }
                    if (me?.isStaff != true) {
                        Row(Modifier.navigationBarsPadding().padding(20.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Outlined.Lock, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                            Text(tx("View only · entries are added by the admin", "केवल देखने के लिए · एंट्री एडमिन जोड़ते हैं"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

fun roleName(r: String) = when (r) {
    Role.ADMIN -> tx("Admin", "एडमिन")
    Role.CO -> tx("Co-admin", "सह-एडमिन")
    else -> tx("Member", "सदस्य")
}

private fun unreadCount(): Int = Session.inbox.count { it.at > Prefs.lastSeenInbox && it.fromUid != Session.uid }

// ---------------------------------------------------------------- admin / co-admin

@Composable
fun AdminHome() {
    val g = Session.group ?: return
    val me = Session.me ?: return
    val txns = Session.txns
    val s = g.summary
    val month = Calc.monthKey()
    val active = Session.activeMembers
    val paid = active.count { Calc.paidSaving(it.uid, month, txns) }
    val paidAmount = Calc.live(txns).filter { it.type == TxType.SAVING && it.month == month }.sumOf { it.amount }
    val overdue = Session.loans.filter { it.status == "active" }.mapNotNull { l ->
        val st = Calc.loanState(l, txns)
        if (st.overdue) l to st.nextAmount else null
    }
    val leaveReq = active.filter { it.status == MemberStatus.LEAVE_REQUESTED }
    val disputed = active.filter { it.opening == "disputed" }
    val due = if (g.financeSet && g.dueDay in 1..28) Calc.dueDateOf(month, g.dueDay) else 0L
    val fines = Session.pendingFines

    val menu = buildList {
        add(MenuEntry(Icons.Outlined.Groups, tx("Members", "सदस्य"), tx("${active.size} members", "${active.size} सदस्य"), Session.joinRequests.size + leaveReq.size) { Nav.go(Screen.Members) })
        add(MenuEntry(Icons.Outlined.Savings, tx("Monthly Savings", "मासिक बचत"), tx("$paid of ${active.size} paid", "${active.size} में से $paid जमा"), active.size - paid, warn = true) { Nav.go(Screen.Savings) })
        add(MenuEntry(Icons.Outlined.AccountBalanceWallet, tx("Loans", "लोन"), tx("${s.activeLoans} active · ${Calc.rupees(s.lent)} out", "${s.activeLoans} चालू · ${Calc.rupees(s.lent)} बाहर")) { Nav.go(Screen.Loans) })
        add(MenuEntry(Icons.Outlined.Payments, tx("Repayments", "किस्त वापसी"), if (overdue.isEmpty()) tx("No overdue", "कोई बकाया नहीं") else tx("${overdue.size} overdue", "${overdue.size} बकाया"), overdue.size, warn = true) { Nav.go(Screen.Repayments) })
        add(MenuEntry(Icons.Outlined.Gavel, tx("Pending fines", "बाकी जुर्माना"), if (fines.isEmpty()) tx("None pending", "कोई बाकी नहीं") else tx("${fines.size} · ${Calc.rupees(fines.sumOf { it.amount })}", "${fines.size} · ${Calc.rupees(fines.sumOf { it.amount })}"), fines.size, warn = true) { Nav.go(Screen.PendingFines) })
        add(MenuEntry(Icons.Outlined.MenuBook, tx("Cash Book", "कैश बुक"), tx("All money in & out", "सारा पैसा आना-जाना")) { Nav.go(Screen.CashBook) })
        add(MenuEntry(Icons.Outlined.CalendarMonth, tx("Meetings", "बैठकें"), nextMeetingText()) { Nav.go(Screen.Meetings) })
        add(MenuEntry(Icons.Outlined.BarChart, tx("Reports", "रिपोर्ट"), tx("Monthly PDF for WhatsApp", "WhatsApp के लिए मासिक PDF")) { Nav.go(Screen.Reports) })
        add(MenuEntry(Icons.Outlined.CardGiftcard, tx("Year-end Profit Share", "साल का मुनाफ़ा बँटवारा"), tx("${Calc.rupees(s.profit)} to share", "${Calc.rupees(s.profit)} बाँटना है")) { Nav.go(Screen.ProfitShare) })
        add(MenuEntry(Icons.Outlined.Key, tx("Permissions", "अनुमतियाँ"), permissionSub(), divider = true, accent = true) { Nav.go(Screen.Permissions) })
        add(MenuEntry(Icons.Outlined.HowToVote, tx("Admin Election", "एडमिन चुनाव"), electionSub(), if (Session.openProposal != null && Session.myVote.isBlank()) 1 else 0, accent = true) { Nav.go(Screen.Election) })
        add(MenuEntry(Icons.Outlined.History, tx("Old Records Setup", "पुराने रिकॉर्ड सेटअप"),
            if (g.setupOpen()) tx("Open till ${Calc.shortDate(g.setupUntil)}", "${Calc.shortDate(g.setupUntil)} तक खुला") else tx("Closed", "बंद"), accent = true) { Nav.go(Screen.OldRecords) })
        add(MenuEntry(Icons.Outlined.ShowChart, tx("Group Activity", "समूह गतिविधि"), tx("Every entry & edit", "हर एंट्री और बदलाव"), divider = true, accent = true) { Nav.go(Screen.ActivityLog()) })
        add(MenuEntry(Icons.Outlined.Notifications, tx("Notifications", "सूचनाएं"), tx("Alerts sent to you", "आपको भेजे गए अलर्ट"), unreadCount(), accent = true) { Nav.go(Screen.Inbox) })
    }

    if (me.role == Role.ADMIN && !g.adminAccepted) {
        HomeFrame(me.name.substringBefore(" "), listOf(roleName(me.role).uppercase(), tx("${active.size} members", "${active.size} सदस्य")), emptyList()) { AcceptAdminCard() }
        return
    }
    HomeFrame(me.name.substringBefore(" "), listOf(roleName(me.role).uppercase(), tx("${active.size} members", "${active.size} सदस्य")), menu) {
        VoteBanner()
        SetupNotDoneBanner()
        // Group fund
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(3.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(tx("Total group fund", "कुल समूह फंड"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(Calc.rupees(s.fund), fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Cash in hand", "हाथ में नकद"), Calc.rupees(s.cash), Modifier.weight(1f))
                    Stat(tx("Lent out", "लोन में"), Calc.rupees(s.lent), Modifier.weight(1f))
                    Stat(tx("Profit", "मुनाफ़ा"), Calc.rupees(s.profit), Modifier.weight(1f), MaterialTheme.colorScheme.primary)
                }
            }
        }
        // This month
        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tx("${Calc.shortMonth(month)} savings", "${Calc.shortMonth(month, true)} की बचत"), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                if (due > 0) Text(tx("Due by ${Calc.shortDate(due)}", "${Calc.shortDate(due)} तक"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            LinearProgressIndicator(progress = { if (active.isEmpty()) 0f else paid.toFloat() / active.size }, modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(99.dp)))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tx("$paid of ${active.size} paid · ${Calc.rupees(paidAmount)}", "${active.size} में से $paid जमा · ${Calc.rupees(paidAmount)}"), modifier = Modifier.weight(1f))
                if (active.size - paid > 0) Tag(tx("${active.size - paid} pending", "${active.size - paid} बाकी"), LocalExtra.current.warnBg, LocalExtra.current.warnFg)
            }
            TextButton(onClick = { Nav.go(Screen.Savings) }) { Text(tx("Open monthly savings", "मासिक बचत खोलें")) }
        }
        if (overdue.isNotEmpty()) Banner(tx("${overdue.size} loan payments overdue · ${Calc.rupees(overdue.sumOf { it.second })}", "${overdue.size} लोन भुगतान बकाया · ${Calc.rupees(overdue.sumOf { it.second })}"), Icons.Outlined.Warning) { Nav.go(Screen.Repayments) }
        if (fines.isNotEmpty()) Banner(tx("${fines.size} pending fines · ${Calc.rupees(fines.sumOf { it.amount })}", "${fines.size} जुर्माना बाकी · ${Calc.rupees(fines.sumOf { it.amount })}"), Icons.Outlined.Gavel) { Nav.go(Screen.PendingFines) }
        if (Session.joinRequests.isNotEmpty() && me.role == Role.ADMIN) Banner(tx("${Session.joinRequests.size} join request · ${Session.joinRequests.first().name}", "${Session.joinRequests.size} जुड़ने का अनुरोध · ${Session.joinRequests.first().name}"), Icons.Outlined.PersonAdd, warn = false) { Nav.go(Screen.Members) }
        if (leaveReq.isNotEmpty()) Banner(tx("${leaveReq.first().name} asked to leave the group", "${leaveReq.first().name} समूह छोड़ना चाहते हैं"), Icons.Outlined.Info) { Nav.go(Screen.MemberDetail(leaveReq.first().uid)) }
        if (disputed.isNotEmpty()) Banner(tx("${disputed.first().name} reported a mistake in opening balance", "${disputed.first().name} ने शुरुआती बैलेंस में गलती बताई"), Icons.Outlined.Warning) { Nav.go(Screen.Opening(disputed.first().uid)) }
        if (g.setupOpen() && me.role == Role.ADMIN) Banner(tx("Old Records Setup is open till ${Calc.date(g.setupUntil)} — add notebook records with their real dates", "पुराने रिकॉर्ड सेटअप ${Calc.date(g.setupUntil)} तक खुला — नोटबुक का हिसाब असली तारीख के साथ डालें"), Icons.Outlined.History, warn = false) { Nav.go(Screen.OldRecords) }
        PermissionBanner()
        CoAdminViewOnly()

        // Quick actions (admin only)
        if (me.role == Role.ADMIN) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quick(Icons.Outlined.Savings, tx("Add Saving", "बचत जोड़ें"), Modifier.weight(1f)) { Nav.go(Screen.Savings) }
            Quick(Icons.Outlined.AccountBalanceWallet, tx("New Loan", "नया लोन"), Modifier.weight(1f)) { Nav.go(Screen.NewLoan()) }
            Quick(Icons.Outlined.Check, tx("Repayment", "किस्त"), Modifier.weight(1f)) { Nav.go(Screen.Repayments) }
            Quick(Icons.Outlined.PersonAdd, tx("Add Member", "सदस्य जोड़ें"), Modifier.weight(1f)) { Nav.go(Screen.Members) }
        }

        // Recent entries
        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tx("Recent entries", "हाल की एंट्री"), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = { Nav.go(Screen.CashBook) }) { Text(tx("See all", "सभी देखें")) }
            }
            val recent = txns.sortedByDescending { it.createdAt }.take(6)
            if (recent.isEmpty()) Empty(if (me.role == Role.ADMIN) tx("No entries yet. Start with Add Saving.", "अभी कोई एंट्री नहीं। बचत जोड़ें से शुरू करें।") else tx("No entries yet", "अभी कोई एंट्री नहीं"))
            recent.forEach { TxnRow(it) }
        }
        Gap(8.dp)
    }
}

@Composable
private fun Quick(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface).clickable { onClick() }.padding(vertical = 12.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        IconBox(icon)
        Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1)
    }
}

@Composable
fun PermissionBanner() {
    val g = Session.group ?: return
    val now = System.currentTimeMillis()
    val lines = mutableListOf<String>()
    g.backdateUntil.filter { it.value > now }.forEach { (who, until) ->
        lines += tx("🔓 Back-dating ON for ${Session.memberById(who)?.name ?: ""} till ${Calc.shortDateTime(until)}", "🔓 ${Session.memberById(who)?.name ?: ""} के लिए पिछली तारीख चालू, ${Calc.shortDateTime(until)} तक")
    }
    g.editUntil.filter { it.value > now }.forEach { (who, until) ->
        lines += tx("🔓 Editing ON for ${Session.memberById(who)?.name ?: ""} till ${Calc.shortDateTime(until)}", "🔓 ${Session.memberById(who)?.name ?: ""} के लिए एंट्री बदलना चालू, ${Calc.shortDateTime(until)} तक")
    }
    if (g.profileUnlocked) lines += tx("🔓 Group profile is unlocked for the admin", "🔓 एडमिन के लिए समूह प्रोफ़ाइल अनलॉक है")
    if (g.financeUnlocked) lines += tx("🔓 Financial settings are unlocked for the admin", "🔓 एडमिन के लिए वित्तीय सेटिंग अनलॉक है")
    if (lines.isNotEmpty()) Banner(lines.joinToString("\n"), Icons.Outlined.Key, warn = false) { Nav.go(Screen.Permissions) }
}

private fun permissionSub(): String {
    val g = Session.group ?: return ""
    val now = System.currentTimeMillis()
    val on = g.backdateUntil.values.count { it > now } + g.editUntil.values.count { it > now } +
        (if (g.profileUnlocked) 1 else 0) + (if (g.financeUnlocked) 1 else 0)
    return when {
        g.coAdminUid.isBlank() -> tx("Choose a co-admin first", "पहले सह-एडमिन चुनें")
        on > 0 -> tx("$on permission ON", "$on अनुमति चालू")
        else -> tx("All locked", "सब लॉक")
    }
}

private fun electionSub(): String {
    val p = Session.openProposal
    return when {
        p == null -> tx("Change admin by secret vote", "गुप्त वोट से एडमिन बदलें")
        Session.myVote.isBlank() -> tx("Vote now: ${p.candidateName}", "अभी वोट करें: ${p.candidateName}")
        else -> tx("Yes ${p.yes} · No ${p.no} · Waiting ${p.waiting}", "हाँ ${p.yes} · ना ${p.no} · बाकी ${p.waiting}")
    }
}

@Composable
private fun VoteBanner() {
    val p = Session.openProposal ?: return
    if (Session.myVote.isBlank() && Session.uid in p.eligible) {
        Banner(tx("🗳 Vote now: ${p.candidateName} proposed as new admin", "🗳 अभी वोट करें: ${p.candidateName} नए एडमिन के लिए प्रस्तावित"), Icons.Outlined.HowToVote, warn = false) { Nav.go(Screen.Election) }
    } else {
        Banner(tx("🗳 Admin vote running · Yes ${p.yes} · No ${p.no} · Waiting ${p.waiting}", "🗳 एडमिन वोट चल रहा है · हाँ ${p.yes} · ना ${p.no} · बाकी ${p.waiting}"), Icons.Outlined.HowToVote, warn = false) { Nav.go(Screen.Election) }
    }
}

@Composable
private fun AcceptAdminCard() {
    val g = Session.group ?: return
    val last = Session.proposals.firstOrNull { it.status == "passed" && it.candidateUid == Session.uid }
    SectionCard {
        Text(tx("🎉 You are elected as the new admin", "🎉 आप नए एडमिन चुने गए"), style = MaterialTheme.typography.titleLarge)
        if (last != null) Text(tx("${last.yes} of ${last.total} members voted Yes (secret vote).", "${last.total} में से ${last.yes} सदस्यों ने हाँ कहा (गुप्त वोट)।"))
        Text(tx("Admin power is already yours for ${g.name}. Tap Accept to start. All members will be told that you accepted.",
            "${g.name} की एडमिन शक्ति अब आपके पास है। शुरू करने के लिए स्वीकार करें दबाएं। सभी सदस्यों को बताया जाएगा।"),
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        PrimaryButton(tx("Accept as new admin", "नए एडमिन के रूप में स्वीकार करें")) { Repo.acceptAdmin() }
    }
}

private fun nextMeetingText(): String {
    val next = Session.meetings.filter { it.date >= System.currentTimeMillis() }.minByOrNull { it.date }
    return if (next == null) tx("No meeting planned", "कोई बैठक तय नहीं") else tx("Next: ${Calc.shortDate(next.date)}", "अगली: ${Calc.shortDate(next.date)}")
}

// ---------------------------------------------------------------- member

@Composable
fun MemberHome() {
    val g = Session.group ?: return
    val me = Session.me ?: return
    val txns = Session.txns
    val month = Calc.monthKey()
    val saved = Calc.memberSavings(me.uid, txns)
    val myLoans = Session.loans.filter { it.status == "active" }
    val loanDue = myLoans.sumOf { Calc.outstanding(it, txns) }
    val interestPaid = Calc.memberInterestPaid(me.uid, txns)
    val thisMonth = Calc.savingTxnFor(me.uid, month, txns)
    val loanStates = myLoans.map { it to Calc.loanState(it, txns) }.filter { it.second.nextDate > 0 }
    val nextPair = loanStates.minByOrNull { it.second.nextDate }
    val nextLoan = nextPair?.first
    val nextSt = nextPair?.second
    val myFines = Session.pendingFines.filter { it.memberUid == me.uid }
    val lastEdit = Session.inbox.firstOrNull { it.kind == Kind.EDIT && it.toUid == me.uid }
    var dispute by remember { mutableStateOf(false) }

    val menu = listOf(
        MenuEntry(Icons.Outlined.MenuBook, tx("My Passbook", "मेरी पासबुक"), tx("${Calc.rupees(saved)} saved", "${Calc.rupees(saved)} बचत")) { Nav.go(Screen.Passbook(me.uid)) },
        MenuEntry(Icons.Outlined.AccountBalanceWallet, tx("My Loans", "मेरे लोन"),
            if (nextSt == null) (if (myLoans.isEmpty()) tx("No active loan", "कोई चालू लोन नहीं") else tx("${Calc.rupees(loanDue)} due", "${Calc.rupees(loanDue)} बाकी"))
            else tx("${Calc.rupees(loanDue)} due · next payment ${Calc.shortDate(nextSt.nextDate)}", "${Calc.rupees(loanDue)} बाकी · अगला भुगतान ${Calc.shortDate(nextSt.nextDate)}")) { Nav.go(Screen.MyLoans) },
        MenuEntry(Icons.Outlined.Gavel, tx("My pending fines", "मेरा बाकी जुर्माना"), if (myFines.isEmpty()) tx("None", "कोई नहीं") else Calc.rupees(myFines.sumOf { it.amount }), myFines.size, warn = true) { Nav.go(Screen.PendingFines) },
        MenuEntry(Icons.Outlined.BarChart, tx("Group Summary", "समूह सारांश"), tx("Fund, lent out, profit", "फंड, लोन, मुनाफ़ा")) { Nav.go(Screen.GroupSummary) },
        MenuEntry(Icons.Outlined.CalendarMonth, tx("Meetings", "बैठकें"), nextMeetingText()) { Nav.go(Screen.Meetings) },
        MenuEntry(Icons.Outlined.Groups, tx("Members", "सदस्य"), tx("Names and roles", "नाम और भूमिका")) { Nav.go(Screen.MemberList) },
        MenuEntry(Icons.Outlined.HowToVote, tx("Admin Election", "एडमिन चुनाव"), electionSub(), if (Session.openProposal != null && Session.myVote.isBlank()) 1 else 0, divider = true, accent = true) { Nav.go(Screen.Election) },
        MenuEntry(Icons.Outlined.ShowChart, tx("Group Activity", "समूह गतिविधि"), tx("See every entry & edit", "हर एंट्री और बदलाव देखें"), accent = true) { Nav.go(Screen.ActivityLog()) },
        MenuEntry(Icons.Outlined.Notifications, tx("Notifications", "सूचनाएं"), tx("Alerts sent to you", "आपको भेजे गए अलर्ट"), unreadCount(), accent = true) { Nav.go(Screen.Inbox) },
    )

    val chips = listOf(roleName(me.role).uppercase(), tx("Admin: ${g.adminName}", "एडमिन: ${g.adminName}"))
    HomeFrame(me.name.substringBefore(" "), chips, menu) {
        VoteBanner()
        if (!g.financeSet) Banner(tx("Your group is being set up. Savings and loans will show here once the admin fills the group's rules.",
            "आपका समूह सेटअप हो रहा है। एडमिन के नियम भरने के बाद बचत और लोन यहाँ दिखेंगे।"), Icons.Outlined.Info, warn = false)
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(3.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(tx("My total savings", "मेरी कुल बचत"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(Calc.rupees(saved), fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = { Nav.go(Screen.Passbook(me.uid)) }) { Text(tx("Passbook", "पासबुक")) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Loan balance", "बाकी लोन"), Calc.rupees(loanDue), Modifier.weight(1f))
                    Stat(tx("Interest paid", "ब्याज भरा"), Calc.rupees(interestPaid), Modifier.weight(1f))
                }
            }
        }

        if (me.opening == "pending") {
            SectionCard(tx("Check your opening balance", "अपना शुरुआती बैलेंस जाँचें")) {
                Text(tx("The admin entered your old records from the notebook:", "एडमिन ने नोटबुक से आपका पुराना हिसाब डाला:"))
                val os = Calc.live(txns).filter { it.type == TxType.OPEN_SAVING }.sumOf { it.amount }
                val oi = Calc.live(txns).filter { it.type == TxType.OPEN_INTEREST }.sumOf { it.amount }
                val ol = Session.loans.filter { it.opening }.sumOf { it.principal }
                Text(tx("Saved ${Calc.rupees(os)} · Loan ${Calc.rupees(ol)} · Interest paid ${Calc.rupees(oi)}", "बचत ${Calc.rupees(os)} · लोन ${Calc.rupees(ol)} · ब्याज भरा ${Calc.rupees(oi)}"), fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(tx("Confirm", "पुष्टि करें"), modifier = Modifier.weight(1f)) { Repo.confirmOpening(true, "") }
                    SecondaryButton(tx("Report a mistake", "गलती बताएं"), modifier = Modifier.weight(1f), color = LocalExtra.current.warnFg) { dispute = true }
                }
            }
        }
        if (me.opening == "disputed") Banner(tx("You reported a mistake in your opening balance. The admin will correct it.", "आपने शुरुआती बैलेंस में गलती बताई है। एडमिन ठीक करेंगे।"), Icons.Outlined.Info, warn = false)
        if (me.status == MemberStatus.LEAVE_REQUESTED) {
            Banner(tx("You asked to leave. The admin will settle your savings. Tap to cancel the request.", "आपने समूह छोड़ने को कहा है। एडमिन हिसाब करेंगे। अनुरोध रद्द करने के लिए दबाएं।"), Icons.Outlined.Info) { Repo.cancelLeave() }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val ex = LocalExtra.current
            Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (thisMonth != null) MaterialTheme.colorScheme.surface else ex.warnBg).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(tx("${Calc.shortMonth(month)} saving", "${Calc.shortMonth(month, true)} की बचत"), style = MaterialTheme.typography.bodySmall, color = if (thisMonth != null) MaterialTheme.colorScheme.onSurfaceVariant else ex.warnFg)
                if (thisMonth != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Check, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text(tx(" Paid ${Calc.rupees(thisMonth.amount)}", " जमा ${Calc.rupees(thisMonth.amount)}"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    Text(Calc.shortDate(thisMonth.date), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else if (g.financeSet && g.dueDay in 1..28) {
                    Text(tx("Pending ${Calc.rupees(g.monthlySaving)}", "बाकी ${Calc.rupees(g.monthlySaving)}"), color = ex.warnFg, fontWeight = FontWeight.Bold)
                    Text(tx("Due by ${Calc.shortDate(Calc.dueDateOf(month, g.dueDay))}", "${Calc.shortDate(Calc.dueDateOf(month, g.dueDay))} तक"), style = MaterialTheme.typography.bodySmall, color = ex.warnFg)
                } else Text(tx("Not started", "अभी शुरू नहीं"), color = ex.warnFg, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (nextLoan != null) ex.warnBg else MaterialTheme.colorScheme.surface).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                val fg = if (nextLoan != null) ex.warnFg else MaterialTheme.colorScheme.onSurfaceVariant
                Text(if (nextLoan?.flexible == true) tx("Next interest", "अगला ब्याज") else tx("Next EMI", "अगली किस्त"), style = MaterialTheme.typography.bodySmall, color = fg)
                if (nextLoan != null && nextSt != null) {
                    Text(Calc.rupees(nextSt.nextAmount), color = fg, fontWeight = FontWeight.Bold)
                    if (nextLoan.flexible) Text(tx("Due ${Calc.shortDate(nextSt.nextDate)} · loan ${Calc.rupees(nextSt.outstanding)}", "${Calc.shortDate(nextSt.nextDate)} तक · लोन ${Calc.rupees(nextSt.outstanding)}"), style = MaterialTheme.typography.bodySmall, color = fg)
                    else Text(tx("Due ${Calc.shortDate(nextSt.nextDate)} · ${nextLoan.months - Calc.instalmentsPaid(nextLoan, nextSt.outstanding)} left",
                        "${Calc.shortDate(nextSt.nextDate)} तक · ${nextLoan.months - Calc.instalmentsPaid(nextLoan, nextSt.outstanding)} बाकी"), style = MaterialTheme.typography.bodySmall, color = fg)
                } else Text(if (myLoans.isEmpty()) tx("No loan", "कोई लोन नहीं") else tx("Nothing due", "कुछ देय नहीं"), fontWeight = FontWeight.Bold)
            }
        }

        if (myFines.isNotEmpty()) Banner(tx("Pending fine ${Calc.rupees(myFines.sumOf { it.amount })} · ${myFines.first().en}" + if (myFines.size > 1) " (+${myFines.size - 1} more)" else "",
            "बाकी जुर्माना ${Calc.rupees(myFines.sumOf { it.amount })} · ${myFines.first().hi}" + if (myFines.size > 1) " (+${myFines.size - 1} और)" else ""), Icons.Outlined.Gavel) { Nav.go(Screen.PendingFines) }

        if (lastEdit != null) {
            val ex = LocalExtra.current
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(ex.infoBg).clickable { Nav.go(Screen.Inbox) }.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Outlined.Edit, null, tint = ex.infoFg)
                Column {
                    Text(if (Prefs.hindi) lastEdit.titleHi else lastEdit.title, color = ex.infoFg, fontWeight = FontWeight.SemiBold)
                    Text(if (Prefs.hindi) lastEdit.bodyHi else lastEdit.body, color = ex.infoFg, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        SectionCard {
            Text(tx("Group summary", "समूह सारांश"), style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Stat(tx("Group fund", "समूह फंड"), Calc.rupees(g.summary.fund), Modifier.weight(1f))
                Stat(tx("Lent out", "लोन में"), Calc.rupees(g.summary.lent), Modifier.weight(1f))
                Stat(tx("Profit", "मुनाफ़ा"), Calc.rupees(g.summary.profit), Modifier.weight(1f), MaterialTheme.colorScheme.primary)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Lock, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(tx("  Other members' amounts stay private", "  दूसरे सदस्यों की राशि निजी रहती है"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tx("My recent entries", "मेरी हाल की एंट्री"), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = { Nav.go(Screen.Passbook(me.uid)) }) { Text(tx("See all", "सभी देखें")) }
            }
            val recent = txns.sortedByDescending { it.date }.take(5)
            if (recent.isEmpty()) Empty(tx("No entries yet", "अभी कोई एंट्री नहीं"))
            recent.forEach { TxnRow(it, showMember = false) }
        }
        Gap(8.dp)
    }

    if (dispute) InputDialog(tx("Report a mistake", "गलती बताएं"), tx("What is wrong? (e.g. I saved ₹6,500)", "क्या गलत है? (जैसे मेरी बचत ₹6,500 है)"),
        confirm = tx("Send to admin", "एडमिन को भेजें"), multiLine = true, onDismiss = { dispute = false }) { Repo.confirmOpening(false, it) }
}

/** One money entry in a list. */
@Composable
fun TxnRow(t: com.rajeev.samuhkhata.core.Txn, showMember: Boolean = true) {
    val ex = LocalExtra.current
    val out = t.type in listOf(TxType.LOAN, TxType.EXPENSE, TxType.WITHDRAW, TxType.PROFIT_PAYOUT)
    val title = buildString {
        if (showMember) append(t.memberName.ifBlank { tx("Group", "समूह") }).append(" · ")
        append(Repo.typeLabel(t.type).replaceFirstChar { it.uppercase() })
        if (t.month.isNotBlank()) append(" · ").append(Calc.shortMonth(t.month, Prefs.hindi))
    }
    val sub = buildString {
        append(Calc.shortDateTime(t.date))
        append(" · ").append(tx("by ", "")).append(t.createdByName)
        if (t.type == TxType.REPAY) append(" · ${Calc.rupees(t.principal)} + ${Calc.rupees(t.interest)} ${tx("interest", "ब्याज")}")
    }
    val badge = when {
        t.deleted -> tx("Deleted", "हटाई")
        t.edited -> tx("Edited", "बदली")
        t.backdated -> tx("Old record", "पुराना रिकॉर्ड")
        else -> null
    }
    val waived = t.type == TxType.WAIVE
    ListRow(
        title, sub,
        // A waived fine moves no money, so it has no + or −.
        value = if (waived) Calc.rupees(t.amount) else (if (out) "−" else "+") + Calc.rupees(t.amount).removePrefix("−"),
        valueColor = if (t.deleted || waived) MaterialTheme.colorScheme.onSurfaceVariant else if (out) ex.warnFg else MaterialTheme.colorScheme.primary,
        leading = { Avatar(if (t.memberName.isBlank()) "₹" else t.memberName.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }, size = 36.dp) },
        badge = badge,
        onClick = { Nav.go(Screen.TxnDetail(t.id)) },
        chevron = false,
    )
}
