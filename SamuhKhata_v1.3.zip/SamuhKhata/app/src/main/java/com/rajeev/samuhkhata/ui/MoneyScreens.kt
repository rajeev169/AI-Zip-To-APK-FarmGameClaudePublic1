package com.rajeev.samuhkhata.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rajeev.samuhkhata.core.Calc
import com.rajeev.samuhkhata.core.FineKind
import com.rajeev.samuhkhata.core.Loan
import com.rajeev.samuhkhata.core.LoanType
import com.rajeev.samuhkhata.core.Member
import com.rajeev.samuhkhata.core.Prefs
import com.rajeev.samuhkhata.core.Repo
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.Txn
import com.rajeev.samuhkhata.core.TxType
import com.rajeev.samuhkhata.core.tx

private fun backdateNote(): String = tx("Today's date is used. Back-dating needs the co-admin's permission.", "आज की तारीख लगेगी। पिछली तारीख के लिए सह-एडमिन की अनुमति चाहिए।")

/** Only the admin enters records. The co-admin can see everything but only holds the permission switches. */
@Composable
fun CoAdminViewOnly() {
    if (Session.me?.role == com.rajeev.samuhkhata.core.Role.CO) Banner(
        tx("You are co-admin: you can see all records but only the admin adds or edits them. You control the admin's back-date and edit switches in ☰ → Permissions.",
            "आप सह-एडमिन हैं: आप सारा हिसाब देख सकते हैं, पर एंट्री केवल एडमिन जोड़ते/बदलते हैं। एडमिन की पिछली तारीख और बदलाव के स्विच ☰ → अनुमतियाँ में आपके पास हैं।"),
        Icons.Outlined.Lock, warn = false)
}

private fun canBack(): Boolean = Session.group?.canBackdate(Session.uid) == true

/** Shown until the admin has filled the group's financial settings. Returns true when setup is complete. */
@Composable
fun SetupNotDoneBanner(): Boolean {
    val g = Session.group ?: return false
    if (g.financeSet) return true
    val text = when {
        g.coAdminUid.isBlank() -> tx("Group setup not complete — add members and choose a co-admin. Then the co-admin unlocks the financial settings.",
            "समूह सेटअप पूरा नहीं — सदस्य जोड़ें और सह-एडमिन चुनें। फिर सह-एडमिन वित्तीय सेटिंग अनलॉक करेंगे।")
        !g.financeUnlocked -> tx("Group setup not complete — waiting for co-admin ${g.coAdminName} to turn on \"Edit financial settings\".",
            "समूह सेटअप पूरा नहीं — सह-एडमिन ${g.coAdminName} के \"वित्तीय सेटिंग बदलें\" चालू करने का इंतज़ार।")
        else -> tx("Group setup not complete — financial settings are unlocked. Admin: fill them now.",
            "समूह सेटअप पूरा नहीं — वित्तीय सेटिंग अनलॉक है। एडमिन: अभी भरें।")
    }
    Banner(text, Icons.Outlined.Lock, onClick = if (Session.isStaff) ({ Nav.go(if (g.coAdminUid.isBlank() && Session.isAdmin) Screen.Members else Screen.FinanceSettings) }) else null)
    return false
}

// ---------------------------------------------------------------- savings

@Composable
fun SavingsScreen() {
    val g = Session.group ?: return
    var month by remember { mutableStateOf(Calc.monthKey()) }
    var adding by remember { mutableStateOf<Member?>(null) }
    var fineFor by remember { mutableStateOf<Member?>(null) }
    val active = Session.activeMembers
    val txns = Session.txns
    val paid = active.filter { Calc.paidSaving(it.uid, month, txns) }
    val pending = active - paid.toSet()
    val ready = g.financeSet && g.dueDay in 1..28
    val due = if (ready) Calc.dueDateOf(month, g.dueDay) else Long.MAX_VALUE
    val late = System.currentTimeMillis() > due
    val canAdd = Session.isAdmin && ready

    Page(tx("Monthly Savings", "मासिक बचत"), if (ready) tx("${Calc.rupees(g.monthlySaving)} each · meeting day ${g.dueDay}", "हर सदस्य ${Calc.rupees(g.monthlySaving)} · बैठक ${g.dueDay} तारीख") else tx("Setup not complete", "सेटअप पूरा नहीं")) {
        if (!ready) item { SetupNotDoneBanner() }
        item {
            SectionCard(padding = 8.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { month = Calc.shiftMonth(month, -1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, tx("Previous month", "पिछला महीना")) }
                    Text(Calc.monthLabel(month, Prefs.hindi), style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    IconButton(onClick = { if (month < Calc.monthKey()) month = Calc.shiftMonth(month, 1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, tx("Next month", "अगला महीना")) }
                }
                Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Paid", "जमा"), "${paid.size} / ${active.size}", Modifier.weight(1f))
                    Stat(tx("Collected", "जमा राशि"), Calc.rupees(Calc.live(txns).filter { it.type == TxType.SAVING && it.month == month }.sumOf { it.amount }), Modifier.weight(1f))
                    Stat(tx("Pending", "बाकी"), pending.size.toString(), Modifier.weight(1f), LocalExtra.current.warnFg)
                }
            }
        }
        if (!Session.isAdmin) item { CoAdminViewOnly() }
        if (late && pending.isNotEmpty() && g.lateFine > 0) item {
            Banner(tx("Meeting day passed. A ${Calc.rupees(g.lateFine)} monthly saving late fine is now pending for each member below.",
                "बैठक की तारीख निकल गई। नीचे हर सदस्य पर ${Calc.rupees(g.lateFine)} मासिक बचत देर का जुर्माना बाकी है।"), Icons.Outlined.Warning) { Nav.go(Screen.PendingFines) }
        }
        if (pending.isNotEmpty()) {
            item { SectionLabel(if (canAdd) tx("Pending — tap to add", "बाकी — जोड़ने के लिए दबाएं") else tx("Pending", "बाकी")) }
            items(pending, key = { "p" + it.uid }) { m ->
                SectionCard(padding = 10.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            ListRow(m.name, if (late) tx("Late · fine pending", "देर · जुर्माना बाकी") else tx("Not paid yet", "अभी जमा नहीं"),
                                leading = { Avatar(m.initials, LocalExtra.current.warnBg, LocalExtra.current.warnFg) }, onClick = if (canAdd) ({ adding = m }) else null, chevron = false)
                        }
                        if (canAdd) {
                            TextButton(onClick = { fineFor = m }) { Text(tx("Fine", "जुर्माना")) }
                            PrimaryButton(tx("Add", "जोड़ें"), modifier = Modifier) { adding = m }
                        }
                    }
                }
            }
        }
        if (paid.isNotEmpty()) {
            item { SectionLabel(tx("Paid", "जमा")) }
            items(paid, key = { "d" + it.uid }) { m ->
                val t = Calc.savingTxnFor(m.uid, month, txns)
                SectionCard(padding = 10.dp) {
                    ListRow(m.name, if (t != null) "${Calc.shortDateTime(t.date)} · ${tx("by", "")} ${t.createdByName}" else null,
                        value = t?.let { Calc.rupees(it.amount) }, valueColor = MaterialTheme.colorScheme.primary,
                        leading = { Avatar(m.initials) }, badge = if (t?.edited == true) tx("Edited", "बदली") else null,
                        onClick = { if (t != null) Nav.go(Screen.TxnDetail(t.id)) })
                }
            }
        }
    }

    adding?.let { m -> AddSavingDialog(m, month) { adding = null } }
    fineFor?.let { m ->
        var amt by remember(m.uid) { mutableStateOf(Calc.num(g.lateFine)) }
        var note by remember(m.uid) { mutableStateOf(tx("Late fine", "देर का जुर्माना")) }
        AlertDialog(
            onDismissRequest = { fineFor = null },
            title = { Text(tx("Add fine for ${m.name}", "${m.name} पर जुर्माना")) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(tx("Fine amount (₹)", "जुर्माना राशि (₹)"), amt, { amt = it }, number = true)
                Field(tx("Reason", "कारण"), note, { note = it })
            } },
            confirmButton = { TextButton(onClick = { amt.money()?.let { if (it > 0) Repo.addFine(m, it, note, null) }; fineFor = null }) { Text(tx("Add fine", "जुर्माना जोड़ें")) } },
            dismissButton = { TextButton(onClick = { fineFor = null }) { Text(tx("Cancel", "रद्द करें")) } },
        )
    }
}

@Composable
private fun AddSavingDialog(m: Member, month: String, onDismiss: () -> Unit) {
    val g = Session.group ?: return
    var amount by remember { mutableStateOf(Calc.num(g.monthlySaving)) }
    var date by remember { mutableStateOf(System.currentTimeMillis()) }
    val due = Calc.dueDateOf(month, g.dueDay)
    val alreadySettled = Calc.fineSettled(m.uid, FineKind.LATE_SAVING, month, Session.txns)
    var fine by remember { mutableStateOf(System.currentTimeMillis() > due && g.lateFine > 0 && !alreadySettled) }
    var fineAmt by remember { mutableStateOf(Calc.num(g.lateFine)) }
    val back = canBack()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Saving: ${m.name}", "बचत: ${m.name}")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(Calc.monthLabel(month, Prefs.hindi), fontWeight = FontWeight.SemiBold)
                Field(tx("Amount (₹)", "राशि (₹)"), amount, { amount = it }, number = true)
                DateRow(tx("Date received", "जमा की तारीख"), date, back, backdateNote()) {
                    date = it; fine = it > due && g.lateFine > 0 && !alreadySettled
                }
                if (alreadySettled) Text(tx("Late fine for this month is already paid or waived.", "इस महीने का देर का जुर्माना पहले ही जमा या माफ़ है।"), style = MaterialTheme.typography.bodySmall)
                else Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = fine, onCheckedChange = { fine = it })
                    Text(tx("Collect monthly saving late fine now", "मासिक बचत देर का जुर्माना अभी लें"), modifier = Modifier.weight(1f))
                }
                if (!alreadySettled && !fine && System.currentTimeMillis() > due && g.lateFine > 0)
                    Text(tx("Not collected now: the fine stays pending.", "अभी नहीं लिया: जुर्माना बाकी रहेगा।"), style = MaterialTheme.typography.bodySmall, color = LocalExtra.current.warnFg)
                if (fine) Field(tx("Fine (₹)", "जुर्माना (₹)"), fineAmt, { fineAmt = it }, number = true)
                Text(tx("${m.name} gets a notification.", "${m.name} को सूचना जाएगी।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.money()
                if (a == null || a <= 0) { Session.error = tx("Enter amount", "राशि लिखें"); return@TextButton }
                Repo.addSaving(m, month, a, if (back) date else null, fine, fineAmt.money() ?: 0.0)
                onDismiss()
            }) { Text(tx("Mark paid", "जमा करें")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx("Cancel", "रद्द करें")) } },
    )
}

// ---------------------------------------------------------------- loans

private fun loanTypeLabel(l: Loan): String = when (l.method) {
    LoanType.FLEXIBLE -> tx("flexible", "लचीला")
    LoanType.REDUCING -> tx("reducing EMI", "घटती EMI")
    else -> tx("flat EMI", "फ्लैट EMI")
}

@Composable
fun LoansScreen() {
    val txns = Session.txns
    val active = Session.loans.filter { it.status == "active" }
    val closed = Session.loans.filter { it.status == "closed" }
    val ready = Session.group?.financeSet == true
    Page(tx("Loans", "लोन"), tx("${active.size} active · ${Calc.rupees(active.sumOf { Calc.outstanding(it, txns) })} out", "${active.size} चालू · ${Calc.rupees(active.sumOf { Calc.outstanding(it, txns) })} बाहर"),
        bottom = if (Session.isAdmin && ready) ({ PrimaryButton(tx("Give new loan", "नया लोन दें")) { Nav.go(Screen.NewLoan()) } }) else null) {
        if (!ready) item { SetupNotDoneBanner() }
        if (!Session.isAdmin) item { CoAdminViewOnly() }
        if (active.isEmpty()) item { Empty(tx("No active loans", "कोई चालू लोन नहीं")) }
        items(active, key = { it.id }) { LoanCard(it) }
        if (closed.isNotEmpty()) {
            item { SectionLabel(tx("Fully repaid", "पूरा चुकाया")) }
            items(closed, key = { "c" + it.id }) { LoanCard(it) }
        }
    }
}

@Composable
fun LoanCard(l: Loan) {
    val st = Calc.loanState(l, Session.txns)
    val sub = when {
        l.status == "closed" -> tx("Fully repaid", "पूरा चुकाया")
        st.nextDate <= 0L -> tx("${Calc.num(l.rate)}% ${loanTypeLabel(l)} · nothing due now", "${Calc.num(l.rate)}% ${loanTypeLabel(l)} · अभी कुछ देय नहीं")
        l.flexible -> tx("${Calc.num(l.rate)}% flexible · interest ${Calc.rupees(st.nextAmount)} on ${Calc.shortDate(st.nextDate)}",
            "${Calc.num(l.rate)}% लचीला · ब्याज ${Calc.rupees(st.nextAmount)} ${Calc.shortDate(st.nextDate)} को")
        else -> tx("${Calc.num(l.rate)}% ${loanTypeLabel(l)} · next EMI ${Calc.rupees(st.nextAmount)} on ${Calc.shortDate(st.nextDate)}",
            "${Calc.num(l.rate)}% ${loanTypeLabel(l)} · अगली किस्त ${Calc.rupees(st.nextAmount)} ${Calc.shortDate(st.nextDate)} को")
    }
    SectionCard(padding = 12.dp) {
        ListRow(
            "${l.memberName} · ${Calc.rupees(l.principal)}",
            sub,
            value = Calc.rupees(st.outstanding),
            badge = when { st.overdue && l.status == "active" -> tx("Overdue", "बकाया"); l.opening -> tx("Old loan", "पुराना लोन"); else -> null },
            onClick = { Nav.go(Screen.LoanDetail(l.id)) },
        )
    }
}

@Composable
fun NewLoanScreen(memberUid: String) {
    val g = Session.group ?: return
    var member by remember { mutableStateOf(Session.memberById(memberUid)) }
    var pick by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    var months by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(System.currentTimeMillis()) }
    var note by remember { mutableStateOf("") }
    var stamp by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    val back = canBack()
    val method = g.interestMethod
    val flexible = method == LoanType.FLEXIBLE
    val a = amount.money() ?: 0.0
    val n = months.toIntOrNull() ?: 0
    val cash = g.summary.cash
    val needStamp = g.stampLimit > 0 && a >= g.stampLimit
    val m0 = member
    val blocked = m0 != null && g.oneLoan && Calc.hasOpenLoan(m0.uid, Session.loans, Session.txns)
    val preview = if (a > 0 && (flexible || n > 0))
        Loan("", "", "", a, g.interestRate, if (flexible) 1 else n, method, date, "active", false, "", "", g.dueDay, g.cutoffDay) else null

    if (!g.financeSet) {
        Page(tx("New loan", "नया लोन")) { item { SetupNotDoneBanner() } }
        return
    }
    Page(tx("New loan", "नया लोन"), tx("${Calc.num(g.interestRate)}% a month · ${loanTypeLabelOf(method)}", "${Calc.num(g.interestRate)}% प्रति माह · ${loanTypeLabelOf(method)}"), bottom = {
        PrimaryButton(tx("Give loan", "लोन दें"), enabled = member != null && a > 0 && (flexible || n > 0) && !blocked && (!needStamp || stamp)) {
            val m = member ?: return@PrimaryButton
            val e = Repo.newLoan(m, a, method, n, if (back) date else null, note.trim(), stamp)
            if (e != null) err = e else Nav.back()
        }
    }) {
        item {
            SectionCard {
                PickerField(tx("Member", "सदस्य"), member?.name ?: "") { pick = true }
                if (blocked) Banner(tx("${m0?.name} already has a loan. Group rule: a new loan only after the old one is fully repaid.",
                    "${m0?.name} का एक लोन पहले से चल रहा है। समूह का नियम: पुराना लोन पूरा चुकाने के बाद ही नया लोन।"), Icons.Outlined.Warning)
                Field(tx("Loan amount (₹)", "लोन राशि (₹)"), amount, { amount = it }, number = true)
                if (a > cash) Text(tx("Cash in hand is only ${Calc.rupees(cash)}", "हाथ में केवल ${Calc.rupees(cash)} नकद है"), color = LocalExtra.current.warnFg, style = MaterialTheme.typography.bodySmall)
                if (!flexible) Field(tx("Months", "महीने"), months, { months = it.filter { c -> c.isDigit() }.take(3) }, number = true, placeholder = tx("e.g. 12", "जैसे 12"))
                if (needStamp) Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = stamp, onCheckedChange = { stamp = it })
                    Text(tx("Stamp paper received (needed for ${Calc.rupees(g.stampLimit)} or more)", "स्टाम्प पेपर मिला (${Calc.rupees(g.stampLimit)} या ज़्यादा पर ज़रूरी)"), modifier = Modifier.weight(1f))
                }
                DateRow(tx("Loan date", "लोन की तारीख"), date, back, backdateNote()) { date = it }
                Field(tx("Purpose / note", "उद्देश्य / नोट"), note, { note = it })
                Text(tx("Interest and loan type come from the group's financial settings.", "ब्याज और लोन का प्रकार समूह की वित्तीय सेटिंग से आते हैं।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (preview != null) item {
            if (flexible) {
                val st = Calc.loanState(preview, emptyList(), date)
                SectionCard(tx("How this loan works", "यह लोन कैसे चलेगा")) {
                    Text(tx("Interest ${Calc.rupees(Calc.round2(a * g.interestRate / 100))} a month while the full amount is due. Pay back any amount any time; interest falls on what is still due.",
                        "जब तक पूरा लोन बाकी है, हर महीने ${Calc.rupees(Calc.round2(a * g.interestRate / 100))} ब्याज। कभी भी कितना भी लौटाएं; ब्याज बाकी राशि पर लगेगा।"))
                    Text(tx("First interest ${Calc.rupees(st.nextAmount)} due on ${Calc.date(st.nextDate)}", "पहला ब्याज ${Calc.rupees(st.nextAmount)}, ${Calc.date(st.nextDate)} को"), fontWeight = FontWeight.SemiBold)
                    if (Calc.dayOfMonth(date) > g.cutoffDay && Calc.dayOfMonth(date) <= g.dueDay)
                        Text(tx("Given after the ${g.cutoffDay}th: no interest until the ${g.dueDay}th.", "${g.cutoffDay} तारीख के बाद लिया: ${g.dueDay} तारीख तक कोई ब्याज नहीं।"), style = MaterialTheme.typography.bodySmall)
                    else if (Calc.dayOfMonth(date) <= g.cutoffDay)
                        Text(tx("Given on or before the ${g.cutoffDay}th: full month's interest at this month's meeting.", "${g.cutoffDay} तारीख तक लिया: इस महीने की बैठक पर पूरे महीने का ब्याज।"), style = MaterialTheme.typography.bodySmall)
                }
            } else {
                val sched = Calc.schedule(preview)
                SectionCard(tx("Repayment plan", "किस्त योजना")) {
                    Text(tx("First EMI ${Calc.rupees(sched.first().second + sched.first().third)} on ${Calc.date(sched.first().first)}",
                        "पहली किस्त ${Calc.rupees(sched.first().second + sched.first().third)} — ${Calc.date(sched.first().first)}"), fontWeight = FontWeight.SemiBold)
                    Text(tx("Total interest ${Calc.rupees(sched.sumOf { it.third })} · Total to repay ${Calc.rupees(a + sched.sumOf { it.third })}",
                        "कुल ब्याज ${Calc.rupees(sched.sumOf { it.third })} · कुल वापसी ${Calc.rupees(a + sched.sumOf { it.third })}"))
                    sched.take(12).forEachIndexed { i, (d, p, intr) ->
                        Row { Text("${i + 1}. ${Calc.shortDate(d)}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            Text("${Calc.rupees(p)} + ${Calc.rupees(intr)} = ${Calc.rupees(p + intr)}", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
        if (err.isNotBlank()) item { Banner(err) }
    }
    if (pick) MemberPickerDialog(tx("Choose member", "सदस्य चुनें"), Session.activeMembers, { pick = false }) { member = it; err = "" }
}

private fun loanTypeLabelOf(method: String): String = when (method) {
    LoanType.FLEXIBLE -> tx("flexible", "लचीला")
    LoanType.REDUCING -> tx("reducing EMI", "घटती EMI")
    else -> tx("flat EMI", "फ्लैट EMI")
}

@Composable
fun LoanDetailScreen(id: String) {
    val l = Session.loans.firstOrNull { it.id == id } ?: run { Page(tx("Loan", "लोन")) { item { Empty(tx("Not found", "नहीं मिला")) } }; return }
    val txns = Session.txns
    val st = Calc.loanState(l, txns)
    val repayments = Calc.live(txns).filter { it.type == TxType.REPAY && it.loanId == l.id }.sortedBy { it.date }
    var pay by remember { mutableStateOf(false) }
    Page(tx("Loan · ${l.memberName}", "लोन · ${l.memberName}"), "${Calc.rupees(l.principal)} · ${Calc.date(l.startDate)}",
        bottom = if (Session.isAdmin && l.status == "active") ({ PrimaryButton(if (l.flexible) tx("Add payment", "भुगतान जोड़ें") else tx("Add repayment", "किस्त जोड़ें")) { pay = true } }) else null) {
        item {
            SectionCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Still due", "बाकी"), Calc.rupees(st.outstanding), Modifier.weight(1f))
                    Stat(tx("Paid back", "लौटाया"), Calc.rupees(Calc.repaidPrincipal(l, txns)), Modifier.weight(1f))
                    Stat(tx("Interest paid", "ब्याज भरा"), Calc.rupees(st.interestPaid), Modifier.weight(1f))
                }
                if (l.flexible) {
                    Text(tx("${Calc.num(l.rate)}% per month on the amount still due · flexible (no fixed time)", "बाकी राशि पर ${Calc.num(l.rate)}% प्रति माह · लचीला (कोई तय समय नहीं)"))
                    if (st.interestDueNow > 0.5) Text(tx("Interest due now: ${Calc.rupees(st.interestDueNow)}", "अभी देय ब्याज: ${Calc.rupees(st.interestDueNow)}"), fontWeight = FontWeight.SemiBold, color = LocalExtra.current.warnFg)
                    if (st.nextDate > 0) Text(tx("Next interest ${Calc.rupees(st.nextAmount)} by ${Calc.date(st.nextDate)}", "अगला ब्याज ${Calc.rupees(st.nextAmount)}, ${Calc.date(st.nextDate)} तक"), fontWeight = FontWeight.SemiBold)
                    if (st.interestAccrued > st.interestDueNow + 0.5) Text(tx("To close the loan today: ${Calc.rupees(st.outstanding + st.interestAccrued)} (loan + this month's interest)", "आज लोन बंद करने के लिए: ${Calc.rupees(st.outstanding + st.interestAccrued)} (लोन + इस महीने का ब्याज)"), style = MaterialTheme.typography.bodySmall)
                } else {
                    Text(tx("${Calc.num(l.rate)}% per month · ${loanTypeLabel(l)} · ${l.months} months", "${Calc.num(l.rate)}% प्रति माह · ${loanTypeLabel(l)} · ${l.months} महीने"))
                    if (l.status == "active" && st.nextDate > 0) Text(tx("Next EMI ${Calc.rupees(st.nextAmount)} on ${Calc.date(st.nextDate)}", "अगली किस्त ${Calc.rupees(st.nextAmount)} — ${Calc.date(st.nextDate)}"), fontWeight = FontWeight.SemiBold)
                }
                if (st.overdue && l.status == "active") Banner(if (l.flexible) tx("Interest is overdue", "ब्याज बकाया है") else tx("This EMI is overdue", "यह किस्त बकाया है"), Icons.Outlined.Warning)
                if (l.stampPaper) Tag(tx("Stamp paper received", "स्टाम्प पेपर मिला"))
                if (l.note.isNotBlank()) Text(l.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (l.opening) Tag(tx("Loan from old records", "पुराने रिकॉर्ड का लोन"))
            }
        }
        if (l.flexible) item {
            val periods = Calc.flexPeriods(l, txns, System.currentTimeMillis() + 45 * Calc.DAY)
            var cum = 0.0
            SectionCard(tx("Monthly interest", "मासिक ब्याज")) {
                if (periods.isEmpty()) Text(tx("No interest charged yet", "अभी कोई ब्याज नहीं"), style = MaterialTheme.typography.bodySmall)
                periods.takeLast(18).let { shown ->
                    // running total must include periods not shown
                    cum = periods.dropLast(shown.size).sumOf { it.interest }
                    shown.forEach { p ->
                        cum += p.interest
                        val paid = st.interestPaid >= cum - 0.5
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (paid) "✅" else if (p.due + Calc.DAY <= System.currentTimeMillis()) "⚠️" else "•", Modifier.padding(end = 8.dp))
                            Text(tx("Due ${Calc.shortDate(p.due)} · on ${Calc.rupees(p.balance)}", "${Calc.shortDate(p.due)} · ${Calc.rupees(p.balance)} पर"), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            Text(Calc.rupees(p.interest), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        } else item {
            val paidCount = Calc.instalmentsPaid(l, st.outstanding)
            SectionCard(tx("EMI schedule", "किस्त सूची")) {
                Calc.schedule(l).forEachIndexed { i, (d, p, intr) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (i < paidCount) "✅" else "${i + 1}.", Modifier.padding(end = 8.dp))
                        Text(Calc.shortDate(d), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        Text("${Calc.rupees(p)} + ${Calc.rupees(intr)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item { SectionLabel(tx("Payments", "भुगतान")) }
        if (repayments.isEmpty()) item { Empty(tx("No payments yet", "अभी कोई भुगतान नहीं")) }
        items(repayments, key = { it.id }) { SectionCard(padding = 8.dp) { TxnRow(it, showMember = false) } }
    }
    if (pay) RepaymentDialog(l) { pay = false }
}

@Composable
fun RepaymentsScreen() {
    val txns = Session.txns
    val states = Session.loans.filter { it.status == "active" }.map { it to Calc.loanState(it, txns) }
    val active = states.sortedWith(compareByDescending<Pair<Loan, Calc.LoanState>> { it.second.overdue }.thenBy { if (it.second.nextDate > 0) it.second.nextDate else Long.MAX_VALUE })
    var pay by remember { mutableStateOf<Loan?>(null) }
    Page(tx("Repayments", "किस्त वापसी"), if (Session.isAdmin) tx("Tap a loan to record a payment", "भुगतान जोड़ने के लिए लोन दबाएं") else tx("Loans and payments due", "लोन और देय भुगतान")) {
        if (!Session.isAdmin) item { CoAdminViewOnly() }
        if (active.isEmpty()) item { Empty(tx("No active loans", "कोई चालू लोन नहीं")) }
        items(active, key = { it.first.id }) { (l, st) ->
            val what = if (l.flexible) tx("Interest", "ब्याज") else tx("EMI", "किस्त")
            SectionCard(padding = 12.dp) {
                ListRow(l.memberName,
                    if (st.nextDate > 0) tx("$what ${Calc.rupees(st.nextAmount)} · due ${Calc.shortDate(st.nextDate)} · ${Calc.rupees(st.outstanding)} left", "$what ${Calc.rupees(st.nextAmount)} · ${Calc.shortDate(st.nextDate)} तक · ${Calc.rupees(st.outstanding)} बाकी")
                    else tx("${Calc.rupees(st.outstanding)} left · nothing due now", "${Calc.rupees(st.outstanding)} बाकी · अभी कुछ देय नहीं"),
                    badge = if (st.overdue) tx("Overdue", "बकाया") else null, leading = { Avatar(l.memberName.take(1).uppercase()) },
                    onClick = { if (Session.isAdmin) pay = l else Nav.go(Screen.LoanDetail(l.id)) })
            }
        }
        item { SectionLabel(tx("Recent payments", "हाल के भुगतान")) }
        val recent = Calc.live(txns).filter { it.type == TxType.REPAY }.take(20)
        if (recent.isEmpty()) item { Empty(tx("No payments yet", "अभी कोई भुगतान नहीं")) }
        items(recent, key = { "r" + it.id }) { SectionCard(padding = 8.dp) { TxnRow(it) } }
    }
    pay?.let { RepaymentDialog(it) { pay = null } }
}

@Composable
private fun RepaymentDialog(l: Loan, onDismiss: () -> Unit) {
    val st = Calc.loanState(l, Session.txns)
    val out = st.outstanding
    var amount by remember { mutableStateOf(Calc.num(if (l.flexible) st.interestAccrued else st.nextAmount)) }
    val split = Calc.splitPayment(l, Session.txns, amount.money() ?: 0.0)
    var principal by remember { mutableStateOf("") }
    var interest by remember { mutableStateOf("") }
    var manual by remember { mutableStateOf(false) }
    var date by remember { mutableStateOf(System.currentTimeMillis()) }
    val back = canBack()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (l.flexible) tx("Payment from ${l.memberName}", "${l.memberName} का भुगतान") else tx("EMI from ${l.memberName}", "${l.memberName} की किस्त")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (l.flexible) {
                    Text(tx("Loan left ${Calc.rupees(out)} · interest to pay ${Calc.rupees(st.interestAccrued)}", "बाकी लोन ${Calc.rupees(out)} · देय ब्याज ${Calc.rupees(st.interestAccrued)}"))
                    Text(tx("Interest is taken first; anything more reduces the loan. To close the loan: ${Calc.rupees(out + st.interestAccrued)}.",
                        "पहले ब्याज कटेगा; बाकी से लोन घटेगा। लोन बंद करने के लिए: ${Calc.rupees(out + st.interestAccrued)}।"), style = MaterialTheme.typography.bodySmall)
                } else {
                    Text(tx("Loan left ${Calc.rupees(out)} · interest due ${Calc.rupees(st.interestDueNow)}", "बाकी लोन ${Calc.rupees(out)} · देय ब्याज ${Calc.rupees(st.interestDueNow)}"))
                }
                Field(tx("Amount received (₹)", "प्राप्त राशि (₹)"), amount, { amount = it; manual = false }, number = true)
                if (!manual) {
                    Text(tx("Split: ${Calc.rupees(split.first)} loan + ${Calc.rupees(split.second)} interest", "बँटवारा: ${Calc.rupees(split.first)} लोन + ${Calc.rupees(split.second)} ब्याज"), fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { manual = true; principal = Calc.num(split.first); interest = Calc.num(split.second) }) { Text(tx("Change split", "बँटवारा बदलें")) }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(tx("Loan part", "लोन भाग"), principal, { principal = it }, number = true, modifier = Modifier.weight(1f))
                        Field(tx("Interest", "ब्याज"), interest, { interest = it }, number = true, modifier = Modifier.weight(1f))
                    }
                }
                DateRow(tx("Date received", "प्राप्त तारीख"), date, back, backdateNote()) { date = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = if (manual) principal.money() ?: 0.0 else split.first
                val i = if (manual) interest.money() ?: 0.0 else split.second
                if (p + i <= 0) { Session.error = tx("Enter amount", "राशि लिखें"); return@TextButton }
                if (p > out + 0.5) { Session.error = tx("Loan part is more than the loan left", "लोन भाग बाकी लोन से ज़्यादा है"); return@TextButton }
                Repo.addRepayment(l, p, i, if (back) date else null)
                onDismiss()
            }) { Text(tx("Save", "सेव करें")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx("Cancel", "रद्द करें")) } },
    )
}

// ---------------------------------------------------------------- pending fines

@Composable
fun PendingFinesScreen() {
    val g = Session.group ?: return
    val list = Session.pendingFines
    val admin = Session.isAdmin
    var collect by remember { mutableStateOf<Calc.PendingFine?>(null) }
    var waive by remember { mutableStateOf<Calc.PendingFine?>(null) }
    Page(tx("Pending fines", "बाकी जुर्माना"), tx("${list.size} pending · ${Calc.rupees(list.sumOf { it.amount })}", "${list.size} बाकी · ${Calc.rupees(list.sumOf { it.amount })}")) {
        if (!g.financeSet) item { SetupNotDoneBanner() }
        if (Session.me?.role == com.rajeev.samuhkhata.core.Role.CO) item {
            Banner(tx("View only: you can check that fines are collected honestly. Only the admin records them.", "केवल देखने के लिए: आप जाँच सकते हैं कि जुर्माना ईमानदारी से लिया जा रहा है। दर्ज केवल एडमिन करते हैं।"), Icons.Outlined.Lock, warn = false)
        }
        item {
            Text(tx("Added automatically: monthly saving not paid by the meeting day, loan interest not paid by its due day, and absence from the yearly meeting.",
                "अपने आप जुड़ता है: बैठक की तारीख तक बचत न देना, देय तारीख तक लोन ब्याज न देना, और वार्षिक बैठक में अनुपस्थिति।"),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (list.isEmpty()) item { Empty(tx("No pending fines 🎉", "कोई जुर्माना बाकी नहीं 🎉")) }
        items(list, key = { it.key }) { f ->
            SectionCard(padding = 12.dp) {
                ListRow(if (Session.isStaff) f.memberName else tx(f.en.substringBefore(" ·"), f.hi.substringBefore(" ·")),
                    tx(f.en, f.hi), value = Calc.rupees(f.amount), valueColor = LocalExtra.current.warnFg,
                    leading = { Avatar(f.memberName.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }, LocalExtra.current.warnBg, LocalExtra.current.warnFg) }, chevron = false)
                if (admin) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(tx("Collect ${Calc.rupees(f.amount)}", "${Calc.rupees(f.amount)} लें"), modifier = Modifier.weight(1f)) { collect = f }
                    SecondaryButton(tx("Waive", "माफ़ करें"), modifier = Modifier.weight(1f), color = LocalExtra.current.warnFg) { waive = f }
                }
            }
        }
    }
    collect?.let { f ->
        ConfirmDialog(tx("Collect fine from ${f.memberName}?", "${f.memberName} से जुर्माना लें?"), tx("${Calc.rupees(f.amount)} · ${f.en}", "${Calc.rupees(f.amount)} · ${f.hi}"),
            tx("Mark paid", "जमा करें"), { collect = null }) { Repo.collectFine(f, null) }
    }
    waive?.let { f ->
        InputDialog(tx("Waive this fine?", "यह जुर्माना माफ़ करें?"), tx("Reason (required) — all members will see it", "कारण (ज़रूरी) — सभी सदस्य देखेंगे"), confirm = tx("Waive", "माफ़ करें"),
            multiLine = true, onDismiss = { waive = null }) { reason -> Repo.waiveFine(f, reason)?.let { Session.error = it } }
    }
}

// ---------------------------------------------------------------- cash book

@Composable
fun CashBookScreen() {
    val g = Session.group ?: return
    var filter by remember { mutableStateOf("all") }
    var add by remember { mutableStateOf("") }
    val txns = Session.txns
    val outTypes = listOf(TxType.LOAN, TxType.EXPENSE, TxType.WITHDRAW, TxType.PROFIT_PAYOUT)
    val noCash = listOf(TxType.OPEN_SAVING, TxType.OPEN_INTEREST, TxType.PROFIT_SHARE, TxType.WAIVE)
    val list = txns.filter {
        when (filter) {
            "in" -> it.type !in outTypes && it.type !in noCash
            "out" -> it.type in outTypes
            "deleted" -> it.deleted
            else -> true
        }
    }
    Page(tx("Cash Book", "कैश बुक"), tx("Cash in hand ${Calc.rupees(g.summary.cash)}", "हाथ में नकद ${Calc.rupees(g.summary.cash)}"), bottom = if (Session.isAdmin) ({
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PrimaryButton(tx("+ Income", "+ आय"), modifier = Modifier.weight(1f)) { add = TxType.INCOME }
            SecondaryButton(tx("− Expense", "− खर्च"), modifier = Modifier.weight(1f)) { add = TxType.EXPENSE }
        }
    }) else null) {
        item {
            SectionCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Money in", "आया"), Calc.rupees(Calc.live(txns).filter { it.type !in outTypes && it.type !in noCash }.sumOf { it.amount }), Modifier.weight(1f), MaterialTheme.colorScheme.primary)
                    Stat(tx("Money out", "गया"), Calc.rupees(Calc.live(txns).filter { it.type in outTypes }.sumOf { it.amount }), Modifier.weight(1f), LocalExtra.current.warnFg)
                }
                Segmented(listOf("all" to tx("All", "सभी"), "in" to tx("In", "आया"), "out" to tx("Out", "गया"), "deleted" to tx("Deleted", "हटाई")), filter) { filter = it }
            }
        }
        if (list.isEmpty()) item { Empty(tx("No entries", "कोई एंट्री नहीं")) }
        items(list.take(300), key = { it.id }) { SectionCard(padding = 8.dp) { TxnRow(it) } }
    }
    if (add.isNotBlank()) CashEntryDialog(add) { add = "" }
}

@Composable
private fun CashEntryDialog(type: String, onDismiss: () -> Unit) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(System.currentTimeMillis()) }
    val back = canBack()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (type == TxType.INCOME) tx("Group income", "समूह आय") else tx("Group expense", "समूह खर्च")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (type == TxType.INCOME) tx("e.g. small business profit, donation", "जैसे छोटे व्यापार का मुनाफ़ा, दान") else tx("e.g. register, travel, meeting tea", "जैसे रजिस्टर, यात्रा, बैठक की चाय"), style = MaterialTheme.typography.bodySmall)
                Field(tx("Amount (₹)", "राशि (₹)"), amount, { amount = it }, number = true)
                Field(tx("Details", "विवरण"), note, { note = it })
                DateRow(tx("Date", "तारीख"), date, back, backdateNote()) { date = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.money()
                if (a == null || a <= 0 || note.isBlank()) { Session.error = tx("Enter amount and details", "राशि और विवरण लिखें"); return@TextButton }
                Repo.addCashEntry(type, a, note.trim(), if (back) date else null)
                onDismiss()
            }) { Text(tx("Save", "सेव करें")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx("Cancel", "रद्द करें")) } },
    )
}

// ---------------------------------------------------------------- entry detail, edit & history

@Composable
fun TxnDetailScreen(id: String) {
    val t = Session.txns.firstOrNull { it.id == id } ?: run { Page(tx("Entry", "एंट्री")) { item { Empty(tx("Not found", "नहीं मिला")) } }; return }
    val g = Session.group ?: return
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    val canEdit = g.canEdit(Session.uid)
    val staff = Session.isAdmin
    Page(Repo.typeLabel(t.type).replaceFirstChar { it.uppercase() }, t.memberName.ifBlank { tx("Group entry", "समूह एंट्री") }) {
        item {
            SectionCard {
                Text(Calc.rupees(t.amount), style = MaterialTheme.typography.headlineSmall, color = if (t.deleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                if (t.deleted) Tag(tx("Deleted", "हटाई गई"), LocalExtra.current.warnBg, LocalExtra.current.warnFg)
                if (t.type == TxType.REPAY) Text(tx("${Calc.rupees(t.principal)} loan + ${Calc.rupees(t.interest)} interest", "${Calc.rupees(t.principal)} लोन + ${Calc.rupees(t.interest)} ब्याज"))
                if (t.month.isNotBlank()) Text(tx("For ", "") + Calc.monthLabel(t.month, Prefs.hindi) + tx("", " के लिए"))
                if (t.note.isNotBlank()) Text(t.note, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Divider()
                Text(tx("Date in register: ${Calc.date(t.date)}", "रजिस्टर की तारीख: ${Calc.date(t.date)}"))
                Text(tx("Added to app: ${Calc.dateTime(t.createdAt)} by ${t.createdByName}", "ऐप में जोड़ी: ${Calc.dateTime(t.createdAt)} — ${t.createdByName}"))
                if (t.backdated) Tag(tx("Old / back-dated record", "पुराना / पिछली तारीख का रिकॉर्ड"))
            }
        }
        item {
            SectionCard(tx("History", "इतिहास")) {
                Text(tx("Old values are never erased.", "पुराने मान कभी नहीं मिटते।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                t.history.sortedBy { it.at }.forEach { h ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        val action = when (h.action) { "added" -> tx("Added", "जोड़ी"); "edited" -> tx("Edited", "बदली"); "deleted" -> tx("Deleted", "हटाई"); else -> h.action }
                        Text("$action · ${h.by} · ${Calc.dateTime(h.at)}", fontWeight = FontWeight.SemiBold)
                        if (h.detail.isNotBlank()) Text(h.detail, style = MaterialTheme.typography.bodySmall)
                        if (h.reason.isNotBlank()) Text(tx("Reason: ${h.reason}", "कारण: ${h.reason}"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        if (staff && !t.deleted) item {
            SectionCard {
                if (!canEdit) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Lock, null, tint = LocalExtra.current.warnFg)
                        Text(tx("  Editing is OFF. The co-admin can allow it in ☰ → Permissions.", "  बदलाव बंद है। सह-एडमिन ☰ → अनुमतियाँ में चालू कर सकते हैं।"),
                            color = LocalExtra.current.warnFg, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(tx("Edit", "बदलें"), enabled = canEdit, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { edit = true }
                    SecondaryButton(tx("Delete", "हटाएं"), modifier = Modifier.weight(1f), color = LocalExtra.current.badFg) { if (canEdit) del = true else Session.error = tx("Editing is OFF", "बदलाव बंद है") }
                }
                Text(tx("The member gets full details of any change. Everyone else sees that an edit happened.", "सदस्य को बदलाव की पूरी जानकारी मिलती है। बाकी सब को बस पता चलता है कि बदलाव हुआ।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (edit) EditTxnDialog(t) { edit = false }
    if (del) {
        InputDialog(tx("Delete this entry?", "यह एंट्री हटाएं?"), tx("Reason (required)", "कारण (ज़रूरी)"), confirm = tx("Delete", "हटाएं"), multiLine = true, onDismiss = { del = false }) { reason ->
            Repo.deleteTxn(t, reason)?.let { Session.error = it }
        }
    }
}

@Composable
private fun EditTxnDialog(t: Txn, onDismiss: () -> Unit) {
    var amount by remember { mutableStateOf(Calc.num(t.amount)) }
    var principal by remember { mutableStateOf(Calc.num(t.principal)) }
    var interest by remember { mutableStateOf(Calc.num(t.interest)) }
    var note by remember { mutableStateOf(t.note) }
    var date by remember { mutableStateOf(t.date) }
    var reason by remember { mutableStateOf("") }
    val back = canBack()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Edit entry", "एंट्री बदलें")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (t.type == TxType.REPAY) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(tx("Loan part", "लोन भाग"), principal, { principal = it }, number = true, modifier = Modifier.weight(1f))
                        Field(tx("Interest", "ब्याज"), interest, { interest = it }, number = true, modifier = Modifier.weight(1f))
                    }
                } else Field(tx("Amount (₹)", "राशि (₹)"), amount, { amount = it }, number = true)
                Field(tx("Note", "नोट"), note, { note = it })
                DateRow(tx("Date", "तारीख"), date, back, tx("Changing the date needs back-date permission.", "तारीख बदलने के लिए पिछली तारीख की अनुमति चाहिए।")) { date = it }
                Field(tx("Reason for change (required)", "बदलाव का कारण (ज़रूरी)"), reason, { reason = it }, singleLine = false, minLines = 2)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = principal.money() ?: t.principal
                val i = interest.money() ?: t.interest
                val a = if (t.type == TxType.REPAY) p + i else amount.money() ?: t.amount
                val err = Repo.editTxn(t, a, p, i, note.trim(), if (back) date else null, reason.trim())
                if (err != null) Session.error = err else onDismiss()
            }) { Text(tx("Save change", "बदलाव सेव करें")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx("Cancel", "रद्द करें")) } },
    )
}
