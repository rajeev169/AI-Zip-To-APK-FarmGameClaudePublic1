package com.rajeev.samuhkhata.core

import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.WriteBatch
import kotlinx.coroutines.tasks.await

/**
 * Every change to the group's records goes through here.
 * Writes are saved on the phone straight away and synced when the internet is available.
 * Each change also writes a Group Activity line and, where needed, notifications.
 */
object Repo {
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    private fun now() = System.currentTimeMillis()
    private fun uid() = Session.uid
    private fun meName() = Session.me?.name ?: Session.user?.displayName ?: ""
    private fun gref(gid: String) = db.collection("groups").document(gid)
    private fun g(): Group = Session.group ?: error("No group")

    private fun commit(b: WriteBatch, done: (() -> Unit)? = null) {
        b.commit()
            .addOnSuccessListener { done?.invoke() }
            .addOnFailureListener { Session.error = it.message }
        // Saved on the phone already; tell the user straight away.
        Session.toast = tx("Saved", "सेव हो गया")
    }

    private fun WriteBatch.act(gid: String, kind: String, m: Msg, affected: String = "") {
        set(gref(gid).collection("activity").document(), mapOf(
            "at" to now(), "kind" to kind, "text" to m.en, "textHi" to m.hi,
            "actorName" to meName(), "actorUid" to uid(), "affectedUid" to affected,
        ))
    }

    private fun WriteBatch.note(gid: String, to: String, title: Msg, body: Msg, kind: String) {
        set(gref(gid).collection("inbox").document(), mapOf(
            "toUid" to to, "fromUid" to uid(), "at" to now(), "kind" to kind,
            "title" to title.en, "titleHi" to title.hi, "body" to body.en, "bodyHi" to body.hi,
        ))
    }

    private fun r(v: Double) = Calc.rupees(v)
    private fun monthEn(key: String) = if (key.isBlank()) "" else Calc.shortMonth(key, false)
    private fun monthHi(key: String) = if (key.isBlank()) "" else Calc.shortMonth(key, true)

    /** Date used for an entry: the chosen date only when back-dating is allowed, else now. */
    fun effectiveDate(chosen: Long?): Pair<Long, Boolean> {
        val n = now()
        val g = Session.group ?: return n to false
        if (chosen == null) return n to false
        if (!g.canBackdate(uid())) return n to false
        val back = chosen < n - 60 * 60 * 1000
        return (if (chosen > n) n else chosen) to back
    }

    private fun txnMap(
        type: String, member: Member?, amount: Double, date: Long, backdated: Boolean,
        month: String = "", note: String = "", principal: Double = 0.0, interest: Double = 0.0, loanId: String = "",
    ): Map<String, Any> = mapOf(
        "type" to type,
        "memberUid" to (member?.uid ?: ""),
        "memberName" to (member?.name ?: ""),
        "amount" to Calc.round2(amount),
        "principal" to Calc.round2(principal),
        "interest" to Calc.round2(interest),
        "loanId" to loanId,
        "month" to month,
        "note" to note,
        "date" to date,
        "createdAt" to FieldValue.serverTimestamp(),
        "createdBy" to uid(),
        "createdByName" to meName(),
        "backdated" to backdated,
        "deleted" to false,
        "edited" to false,
        "history" to listOf(mapOf(
            "action" to "added", "by" to meName(), "at" to now(), "reason" to "",
            "detail" to if (backdated) "Back-dated to ${Calc.date(date)}" else "",
        )),
    )

    // =====================================================================
    // Group creation & joining
    // =====================================================================

    suspend fun createGroup(
        user: FirebaseUser, name: String, adminName: String, phone: String,
        monthly: Double, dueDay: Int, rate: Double, method: String, fine: Double,
    ): String {
        var code = Calc.newCode()
        repeat(5) {
            if (!db.collection("codes").document(code).get().await().exists()) return@repeat
            code = Calc.newCode()
        }
        val ref = db.collection("groups").document()
        val t = now()
        ref.set(mapOf(
            "name" to name, "adminUid" to user.uid, "adminName" to adminName,
            "coAdminUid" to "", "coAdminName" to "",
            "monthlySaving" to monthly, "dueDay" to dueDay, "interestRate" to rate,
            "interestMethod" to method, "lateFine" to fine, "maxSize" to 0,
            "inviteCode" to code, "colour" to "plum", "colourLocked" to true,
            "createdAt" to t, "setupUntil" to t + 30 * Calc.DAY, "setupClosed" to false,
            "alerts" to Alerts().toMap(), "backdateUntil" to emptyMap<String, Long>(),
            "editUntil" to emptyMap<String, Long>(), "summary" to Summary().toMap(),
            "lastCloseAt" to t, "lowCashFlag" to false,
        )).await()
        ref.collection("members").document(user.uid).set(mapOf(
            "name" to adminName, "email" to (user.email ?: "").lowercase(), "phone" to phone,
            "role" to Role.ADMIN, "status" to MemberStatus.ACTIVE, "joinedAt" to t,
            "opening" to "", "openingNote" to "",
        )).await()
        db.collection("codes").document(code).set(mapOf("gid" to ref.id, "groupName" to name)).await()
        db.collection("users").document(user.uid).set(mapOf("groupId" to ref.id, "pendingGroupId" to "", "pendingGroupName" to "")).await()
        val b = db.batch()
        b.act(ref.id, Kind.SETUP, Msg("$adminName created the group $name", "$adminName ने समूह $name बनाया"))
        b.commit().await()
        return ref.id
    }

    /** Member was added by Gmail: joining happens automatically on sign-in. */
    suspend fun joinFromInvite(gid: String, user: FirebaseUser) {
        val email = (user.email ?: "").lowercase()
        val name = user.displayName ?: email.substringBefore("@")
        gref(gid).collection("members").document(user.uid).set(mapOf(
            "name" to name, "email" to email, "phone" to "",
            "role" to Role.MEMBER, "status" to MemberStatus.ACTIVE, "joinedAt" to now(),
            "opening" to "", "openingNote" to "",
        )).await()
        db.collection("users").document(user.uid).set(mapOf("groupId" to gid, "pendingGroupId" to "", "pendingGroupName" to "")).await()
        val b = db.batch()
        b.delete(db.collection("invitesByEmail").document(email))
        b.delete(gref(gid).collection("invites").document(email))
        b.set(gref(gid).collection("activity").document(), mapOf(
            "at" to now(), "kind" to Kind.MEMBER, "text" to "$name joined the group (added by Gmail)",
            "textHi" to "$name समूह से जुड़े (Gmail से जोड़ा गया)", "actorName" to name, "actorUid" to user.uid, "affectedUid" to user.uid,
        ))
        b.set(gref(gid).collection("inbox").document(), mapOf(
            "toUid" to "all", "fromUid" to user.uid, "at" to now(), "kind" to Kind.MEMBER,
            "title" to "New member", "titleHi" to "नया सदस्य",
            "body" to "$name joined the group", "bodyHi" to "$name समूह से जुड़े",
        ))
        b.commit().await()
    }

    /** Returns the group name, or null if the code is wrong. */
    suspend fun requestJoin(user: FirebaseUser, code: String): String? {
        val c = db.collection("codes").document(code.trim()).get().await()
        if (!c.exists()) return null
        val gid = c.getString("gid") ?: return null
        val gname = c.getString("groupName") ?: ""
        val email = (user.email ?: "").lowercase()
        gref(gid).collection("joinRequests").document(user.uid).set(mapOf(
            "name" to (user.displayName ?: email.substringBefore("@")), "email" to email, "at" to now(),
        )).await()
        db.collection("users").document(user.uid).set(mapOf(
            "groupId" to "", "pendingGroupId" to gid, "pendingGroupName" to gname,
        )).await()
        Session.pendingGroupName = gname
        return gname
    }

    suspend fun cancelRequest(gid: String) {
        db.collection("users").document(uid()).set(mapOf("groupId" to "", "pendingGroupId" to "", "pendingGroupName" to "")).await()
        if (gid.isNotBlank()) gref(gid).collection("joinRequests").document(uid()).delete().await()
    }

    suspend fun clearRemoved() {
        Prefs.lastGroupId = ""
        db.collection("users").document(uid()).set(mapOf("groupId" to "", "pendingGroupId" to "", "pendingGroupName" to "")).await()
    }

    private fun roomLeft(g: Group): Boolean {
        if (g.maxSize <= 0) return true
        return Session.activeMembers.size + Session.invites.size < g.maxSize
    }

    /** Returns an error message, or null when done. */
    fun addInvite(emailRaw: String): String? {
        val g = g()
        val email = emailRaw.trim().lowercase()
        if (!email.contains("@") || !email.contains(".")) return tx("Enter a valid Gmail address", "सही Gmail पता लिखें")
        if (Session.members.any { it.email == email && it.status != MemberStatus.LEFT }) return tx("Already a member", "पहले से सदस्य हैं")
        if (!roomLeft(g)) return tx("Group is full (max ${g.maxSize})", "समूह भरा हुआ है (अधिकतम ${g.maxSize})")
        val b = db.batch()
        val inv = mapOf("gid" to g.id, "groupName" to g.name, "addedByName" to meName(), "at" to now())
        b.set(db.collection("invitesByEmail").document(email), inv)
        b.set(gref(g.id).collection("invites").document(email), inv)
        b.act(g.id, Kind.MEMBER, Msg("${meName()} added $email by Gmail (waiting to join)", "${meName()} ने $email को Gmail से जोड़ा (जुड़ने का इंतज़ार)"))
        commit(b)
        return null
    }

    fun removeInvite(email: String) {
        val g = g()
        val b = db.batch()
        b.delete(db.collection("invitesByEmail").document(email))
        b.delete(gref(g.id).collection("invites").document(email))
        b.act(g.id, Kind.MEMBER, Msg("${meName()} removed the pending Gmail $email", "${meName()} ने लंबित Gmail $email हटाया"))
        commit(b)
    }

    fun approve(r: JoinRequest): String? {
        val g = g()
        if (!roomLeft(g)) return tx("Group is full (max ${g.maxSize})", "समूह भरा हुआ है (अधिकतम ${g.maxSize})")
        val b = db.batch()
        b.set(gref(g.id).collection("members").document(r.uid), mapOf(
            "name" to r.name, "email" to r.email, "phone" to "", "role" to Role.MEMBER,
            "status" to MemberStatus.ACTIVE, "joinedAt" to now(), "opening" to "", "openingNote" to "",
        ))
        b.delete(gref(g.id).collection("joinRequests").document(r.uid))
        b.act(g.id, Kind.MEMBER, Msg("${meName()} approved ${r.name} (joined with invite code)", "${meName()} ने ${r.name} को मंज़ूरी दी (इनवाइट कोड से जुड़े)"), r.uid)
        b.note(g.id, "all", Msg("New member", "नया सदस्य"), Msg("${r.name} joined the group", "${r.name} समूह से जुड़े"), Kind.MEMBER)
        commit(b)
        return null
    }

    fun reject(r: JoinRequest) {
        val g = g()
        val b = db.batch()
        b.delete(gref(g.id).collection("joinRequests").document(r.uid))
        b.act(g.id, Kind.MEMBER, Msg("${meName()} declined the join request from ${r.name}", "${meName()} ने ${r.name} का अनुरोध अस्वीकार किया"))
        commit(b)
    }

    fun regenerateCode() {
        val g = g()
        val code = Calc.newCode()
        val b = db.batch()
        if (g.inviteCode.isNotBlank()) b.delete(db.collection("codes").document(g.inviteCode))
        b.set(db.collection("codes").document(code), mapOf("gid" to g.id, "groupName" to g.name))
        b.update(gref(g.id), "inviteCode", code)
        b.act(g.id, Kind.RULE, Msg("${meName()} made a new invite code (old code no longer works)", "${meName()} ने नया इनवाइट कोड बनाया (पुराना कोड बंद)"))
        b.note(g.id, "all", Msg("Invite code changed", "इनवाइट कोड बदला"),
            Msg("${meName()} made a new invite code. The old code no longer works.", "${meName()} ने नया इनवाइट कोड बनाया। पुराना कोड अब काम नहीं करेगा।"), Kind.RULE)
        commit(b)
    }

    // =====================================================================
    // Roles & permissions (two-key system)
    // =====================================================================

    fun setCoAdmin(newCo: Member?) {
        val g = g()
        val old = Session.memberById(g.coAdminUid)
        val b = db.batch()
        b.update(gref(g.id), mapOf(
            "coAdminUid" to (newCo?.uid ?: ""), "coAdminName" to (newCo?.name ?: ""),
            "backdateUntil" to emptyMap<String, Long>(), "editUntil" to emptyMap<String, Long>(),
        ))
        if (old != null && old.uid != newCo?.uid) {
            b.update(gref(g.id).collection("members").document(old.uid), "role", Role.MEMBER)
            b.note(g.id, old.uid, Msg("Co-admin role ended", "सह-एडमिन भूमिका समाप्त"),
                Msg("${meName()} changed the co-admin. You are now a member.", "${meName()} ने सह-एडमिन बदला। अब आप सदस्य हैं।"), Kind.ROLE)
        }
        if (newCo != null) b.update(gref(g.id).collection("members").document(newCo.uid), "role", Role.CO)

        val (en, hi) = when {
            newCo != null && old == null -> "${meName()} made ${newCo.name} co-admin" to "${meName()} ने ${newCo.name} को सह-एडमिन बनाया"
            newCo != null && old != null -> "${meName()} changed co-admin from ${old.name} to ${newCo.name}" to "${meName()} ने सह-एडमिन ${old.name} से बदलकर ${newCo.name} किया"
            old != null -> "${meName()} removed ${old.name} as co-admin" to "${meName()} ने ${old.name} को सह-एडमिन से हटाया"
            else -> return
        }
        b.act(g.id, Kind.ROLE, Msg(en, hi), newCo?.uid ?: old?.uid ?: "")
        b.note(g.id, "all", Msg(if (old == null) "New co-admin" else "Co-admin changed", if (old == null) "नए सह-एडमिन" else "सह-एडमिन बदला"), Msg(en, hi), Kind.ROLE)
        val hadPerms = g.backdateUntil.values.any { it > now() } || g.editUntil.values.any { it > now() }
        if (hadPerms) {
            val m = Msg("All permissions turned OFF automatically because the co-admin changed",
                "सह-एडमिन बदलने से सभी अनुमतियाँ अपने आप बंद हो गईं")
            b.act(g.id, Kind.PERM, m)
            b.note(g.id, "all", Msg("Permissions reset", "अनुमतियाँ रीसेट"), m, Kind.PERM)
        }
        commit(b)
    }

    /** kind = "backdate" or "edit". days = 0 turns it off. */
    fun setPermission(kind: String, grantee: Member, days: Int) {
        val g = g()
        val field = if (kind == "backdate") "backdateUntil" else "editUntil"
        val labelEn = if (kind == "backdate") "back-date entries" else "edit entries"
        val labelHi = if (kind == "backdate") "पिछली तारीख की एंट्री" else "एंट्री बदलने"
        val b = db.batch()
        val m: Msg
        if (days > 0) {
            val until = now() + days * Calc.DAY
            b.update(gref(g.id), "$field.${grantee.uid}", until)
            m = Msg("🔓 ${meName()} allowed ${grantee.name} to $labelEn for $days day(s), until ${Calc.dateTime(until)}",
                "🔓 ${meName()} ने ${grantee.name} को $days दिन के लिए $labelHi की अनुमति दी, ${Calc.dateTime(until)} तक")
        } else {
            b.update(gref(g.id), "$field.${grantee.uid}", FieldValue.delete())
            m = Msg("🔒 ${meName()} turned OFF permission for ${grantee.name} to $labelEn",
                "🔒 ${meName()} ने ${grantee.name} की $labelHi की अनुमति बंद की")
        }
        b.act(g.id, Kind.PERM, m, grantee.uid)
        b.note(g.id, "all", Msg("Permission changed", "अनुमति बदली"), m, Kind.PERM)
        commit(b)
    }

    /** Timed permissions switch themselves off; everyone is told. Run on the admin's phone. */
    fun expirePermissions(g: Group) {
        val n = now()
        val expired = g.backdateUntil.filter { it.value in 1..n }.map { "backdateUntil" to it.key } +
            g.editUntil.filter { it.value in 1..n }.map { "editUntil" to it.key }
        if (expired.isEmpty()) return
        val b = db.batch()
        expired.forEach { (field, who) ->
            b.update(gref(g.id), "$field.$who", FieldValue.delete())
            val name = Session.memberById(who)?.name ?: ""
            val m = if (field == "backdateUntil")
                Msg("⏱ Back-date permission for $name ended automatically (timer finished)", "⏱ $name की पिछली तारीख की अनुमति अपने आप बंद (समय पूरा)")
            else Msg("⏱ Edit permission for $name ended automatically (timer finished)", "⏱ $name की एंट्री बदलने की अनुमति अपने आप बंद (समय पूरा)")
            b.act(g.id, Kind.PERM, m, who)
            b.note(g.id, "all", Msg("Permission ended", "अनुमति समाप्त"), m, Kind.PERM)
        }
        b.commit().addOnFailureListener { Session.error = it.message }
    }

    // =====================================================================
    // Group rules, appearance, alerts
    // =====================================================================

    fun updateRules(name: String, monthly: Double, dueDay: Int, rate: Double, method: String, fine: Double, maxSize: Int) {
        val g = g()
        val changes = mutableListOf<Pair<String, String>>()
        fun ch(en: String, hi: String, old: String, new: String) { if (old != new) changes += "$en: $old → $new" to "$hi: $old → $new" }
        ch("Group name", "समूह का नाम", g.name, name)
        ch("Monthly saving", "मासिक बचत", r(g.monthlySaving), r(monthly))
        ch("Due day", "जमा करने की तारीख", g.dueDay.toString(), dueDay.toString())
        ch("Interest", "ब्याज", "${Calc.num(g.interestRate)}%", "${Calc.num(rate)}%")
        ch("Interest method", "ब्याज का तरीका", g.interestMethod, method)
        ch("Late fine", "देर का जुर्माना", r(g.lateFine), r(fine))
        ch("Max group size", "अधिकतम सदस्य", if (g.maxSize == 0) "No limit" else g.maxSize.toString(), if (maxSize == 0) "No limit" else maxSize.toString())
        if (changes.isEmpty()) return
        val b = db.batch()
        b.update(gref(g.id), mapOf(
            "name" to name, "monthlySaving" to monthly, "dueDay" to dueDay, "interestRate" to rate,
            "interestMethod" to method, "lateFine" to fine, "maxSize" to maxSize,
        ))
        if (name != g.name && g.inviteCode.isNotBlank()) b.set(db.collection("codes").document(g.inviteCode), mapOf("gid" to g.id, "groupName" to name))
        val m = Msg("${meName()} changed group rules — " + changes.joinToString("; ") { it.first },
            "${meName()} ने समूह के नियम बदले — " + changes.joinToString("; ") { it.second })
        b.act(g.id, Kind.RULE, m)
        b.note(g.id, "all", Msg("Group rules changed", "समूह के नियम बदले"), m, Kind.RULE)
        commit(b)
    }

    fun setGroupColour(colour: String) {
        val g = g()
        if (g.colour == colour) return
        val names = mapOf("plum" to ("Plum Rose" to "प्लम रोज़"), "green" to ("Green Harvest" to "ग्रीन हार्वेस्ट"), "blue" to ("Royal Blue" to "रॉयल ब्लू"))
        val n = names[colour] ?: ("" to "")
        val b = db.batch()
        b.update(gref(g.id), "colour", colour)
        val m = Msg("${meName()} changed the group colour to ${n.first}", "${meName()} ने समूह का रंग ${n.second} किया")
        b.act(g.id, Kind.RULE, m)
        b.note(g.id, "all", Msg("Group colour changed", "समूह का रंग बदला"), m, Kind.RULE)
        commit(b)
    }

    fun setColourLocked(locked: Boolean) {
        val g = g()
        val b = db.batch()
        b.update(gref(g.id), "colourLocked", locked)
        val m = if (locked) Msg("🔒 ${meName()} locked the app colour — everyone uses the group colour", "🔒 ${meName()} ने रंग लॉक किया — सभी समूह का रंग इस्तेमाल करेंगे")
        else Msg("🔓 ${meName()} unlocked the app colour — members can choose their own", "🔓 ${meName()} ने रंग अनलॉक किया — सदस्य अपना रंग चुन सकते हैं")
        b.act(g.id, Kind.PERM, m)
        b.note(g.id, "all", Msg("Appearance lock changed", "रंग लॉक बदला"), m, Kind.PERM)
        commit(b)
    }

    fun setAlerts(a: Alerts) {
        val g = g()
        val b = db.batch()
        b.update(gref(g.id), "alerts", a.toMap())
        b.act(g.id, Kind.RULE, Msg("${meName()} updated group alert settings", "${meName()} ने समूह अलर्ट सेटिंग बदली"))
        commit(b)
    }

    fun announce(text: String) {
        val g = g()
        val b = db.batch()
        b.note(g.id, "all", Msg("Announcement from ${meName()}", "${meName()} की सूचना"), Msg(text, text), Kind.ANNOUNCE)
        b.act(g.id, Kind.ANNOUNCE, Msg("📢 ${meName()}: $text", "📢 ${meName()}: $text"))
        commit(b)
    }

    fun lowCashAlert(g: Group, cash: Double) {
        val b = db.batch()
        b.note(g.id, g.adminUid, Msg("Low cash warning", "कम नकद चेतावनी"),
            Msg("Cash in hand is ${r(cash)}, below your limit of ${r(g.alerts.lowCashLimit)}", "हाथ में नकद ${r(cash)} है, आपकी सीमा ${r(g.alerts.lowCashLimit)} से कम"), Kind.ALERT)
        b.commit()
    }

    // =====================================================================
    // Members
    // =====================================================================

    fun updateMyProfile(name: String, phone: String) {
        val g = g()
        val me = Session.me ?: return
        val b = db.batch()
        b.update(gref(g.id).collection("members").document(me.uid), mapOf("name" to name, "phone" to phone))
        if (me.role == Role.ADMIN) b.update(gref(g.id), "adminName", name)
        if (me.role == Role.CO) b.update(gref(g.id), "coAdminName", name)
        if (name != me.name) b.act(g.id, Kind.MEMBER, Msg("${me.name} changed their name to $name", "${me.name} ने अपना नाम $name किया"), me.uid)
        commit(b)
    }

    fun requestLeave() {
        val g = g()
        val me = Session.me ?: return
        val b = db.batch()
        b.update(gref(g.id).collection("members").document(me.uid), "status", MemberStatus.LEAVE_REQUESTED)
        val m = Msg("${me.name} asked to leave the group", "${me.name} ने समूह छोड़ने का अनुरोध किया")
        b.act(g.id, Kind.MEMBER, m, me.uid)
        b.note(g.id, g.adminUid, Msg("Leave request", "समूह छोड़ने का अनुरोध"), m, Kind.MEMBER)
        if (g.coAdminUid.isNotBlank()) b.note(g.id, g.coAdminUid, Msg("Leave request", "समूह छोड़ने का अनुरोध"), m, Kind.MEMBER)
        commit(b)
    }

    fun cancelLeave() {
        val g = g()
        val me = Session.me ?: return
        val b = db.batch()
        b.update(gref(g.id).collection("members").document(me.uid), "status", MemberStatus.ACTIVE)
        b.act(g.id, Kind.MEMBER, Msg("${me.name} cancelled their leave request", "${me.name} ने छोड़ने का अनुरोध वापस लिया"), me.uid)
        commit(b)
    }

    /** Pays back the member's savings (minus any loan they still owe) and removes them. */
    fun settleAndRemove(m: Member, payout: Double, note: String) {
        val g = g()
        val b = db.batch()
        if (payout > 0) {
            b.set(gref(g.id).collection("txns").document(),
                txnMap(TxType.WITHDRAW, m, payout, now(), false, note = note.ifBlank { "Settlement on leaving" }))
        }
        b.update(gref(g.id).collection("members").document(m.uid), mapOf("status" to MemberStatus.LEFT, "role" to Role.MEMBER))
        if (g.coAdminUid == m.uid) b.update(gref(g.id), mapOf(
            "coAdminUid" to "", "coAdminName" to "",
            "backdateUntil" to emptyMap<String, Long>(), "editUntil" to emptyMap<String, Long>(),
        ))
        val msg = Msg("${meName()} removed ${m.name} from the group" + (if (payout > 0) " (paid back ${r(payout)})" else ""),
            "${meName()} ने ${m.name} को समूह से हटाया" + (if (payout > 0) " (${r(payout)} वापस दिए)" else ""))
        b.act(g.id, Kind.MEMBER, msg, m.uid)
        b.note(g.id, "all", Msg("Member removed", "सदस्य हटाए गए"), msg, Kind.MEMBER)
        commit(b)
    }

    // =====================================================================
    // Money entries
    // =====================================================================

    fun addSaving(m: Member, month: String, amount: Double, chosenDate: Long?, addFine: Boolean, fineAmount: Double) {
        val g = g()
        val (date, back) = effectiveDate(chosenDate)
        val b = db.batch()
        b.set(gref(g.id).collection("txns").document(), txnMap(TxType.SAVING, m, amount, date, back, month = month))
        var fineTextEn = ""; var fineTextHi = ""
        if (addFine && fineAmount > 0) {
            b.set(gref(g.id).collection("txns").document(),
                txnMap(TxType.FINE, m, fineAmount, date, back, month = month, note = "Late saving for ${monthEn(month)}"))
            fineTextEn = " + late fine ${r(fineAmount)}"; fineTextHi = " + देर का जुर्माना ${r(fineAmount)}"
        }
        b.note(g.id, m.uid, Msg("Saving received ✅", "बचत प्राप्त ✅"),
            Msg("${r(amount)} saving received for ${monthEn(month)}$fineTextEn · by ${meName()}", "${monthHi(month)} की ${r(amount)} बचत प्राप्त$fineTextHi · ${meName()} द्वारा"), Kind.MONEY)
        b.act(g.id, Kind.MONEY, Msg("${meName()} added a saving entry for ${m.name} (${monthEn(month)})", "${meName()} ने ${m.name} की बचत एंट्री जोड़ी (${monthHi(month)})"), m.uid)
        commit(b)
    }

    fun addFine(m: Member, amount: Double, note: String, chosenDate: Long?) {
        val g = g()
        val (date, back) = effectiveDate(chosenDate)
        val b = db.batch()
        b.set(gref(g.id).collection("txns").document(), txnMap(TxType.FINE, m, amount, date, back, note = note))
        b.note(g.id, m.uid, Msg("Fine added", "जुर्माना जोड़ा"), Msg("${r(amount)} fine: $note", "${r(amount)} जुर्माना: $note"), Kind.MONEY)
        b.act(g.id, Kind.MONEY, Msg("${meName()} added a fine entry for ${m.name}", "${meName()} ने ${m.name} की जुर्माना एंट्री जोड़ी"), m.uid)
        commit(b)
    }

    fun newLoan(m: Member, amount: Double, rate: Double, months: Int, method: String, chosenDate: Long?, note: String) {
        val g = g()
        val (date, back) = effectiveDate(chosenDate)
        val loanRef = gref(g.id).collection("loans").document()
        val loan = Loan(loanRef.id, m.uid, m.name, amount, rate, months, method, date, "active", false, meName(), note)
        val emi = Calc.nextEmi(loan, amount)
        val b = db.batch()
        b.set(loanRef, mapOf(
            "memberUid" to m.uid, "memberName" to m.name, "principal" to amount, "rate" to rate,
            "months" to months, "method" to method, "startDate" to date, "status" to "active",
            "opening" to false, "createdByName" to meName(), "note" to note, "createdAt" to now(),
        ))
        b.set(gref(g.id).collection("txns").document(), txnMap(TxType.LOAN, m, amount, date, back, loanId = loanRef.id, note = note))
        b.note(g.id, m.uid, Msg("Loan given", "लोन दिया गया"),
            Msg("Loan ${r(amount)} at ${Calc.num(rate)}% monthly for $months months. First EMI ${r(emi)} due ${Calc.date(Calc.addMonths(date, 1))}.",
                "${r(amount)} का लोन, ${Calc.num(rate)}% मासिक ब्याज, $months महीने। पहली किस्त ${r(emi)}, ${Calc.date(Calc.addMonths(date, 1))} तक।"), Kind.MONEY)
        b.act(g.id, Kind.MONEY, Msg("${meName()} gave a loan to ${m.name}", "${meName()} ने ${m.name} को लोन दिया"), m.uid)
        commit(b)
    }

    fun addRepayment(loan: Loan, principal: Double, interest: Double, chosenDate: Long?) {
        val g = g()
        val m = Session.memberById(loan.memberUid)
        val (date, back) = effectiveDate(chosenDate)
        val amount = principal + interest
        val left = Calc.outstanding(loan, Session.txns) - principal
        val b = db.batch()
        b.set(gref(g.id).collection("txns").document(), txnMap(
            TxType.REPAY, m, amount, date, back, principal = principal, interest = interest, loanId = loan.id,
            note = "EMI ${r(principal)} + ${r(interest)} interest",
        ))
        b.note(g.id, loan.memberUid, Msg("EMI received ✅", "किस्त प्राप्त ✅"),
            Msg("${r(amount)} received (${r(principal)} + ${r(interest)} interest). Loan left: ${r(maxOf(0.0, left))}",
                "${r(amount)} प्राप्त (${r(principal)} + ${r(interest)} ब्याज)। बाकी लोन: ${r(maxOf(0.0, left))}"), Kind.MONEY)
        b.act(g.id, Kind.MONEY, Msg("${meName()} added a loan repayment for ${loan.memberName}", "${meName()} ने ${loan.memberName} की लोन किस्त जोड़ी"), loan.memberUid)
        commit(b)
    }

    fun addCashEntry(type: String, amount: Double, note: String, chosenDate: Long?) {
        val g = g()
        val (date, back) = effectiveDate(chosenDate)
        val b = db.batch()
        b.set(gref(g.id).collection("txns").document(), txnMap(type, null, amount, date, back, note = note))
        val m = if (type == TxType.INCOME) Msg("${meName()} added group income ${r(amount)}: $note", "${meName()} ने समूह आय ${r(amount)} जोड़ी: $note")
        else Msg("${meName()} added group expense ${r(amount)}: $note", "${meName()} ने समूह खर्च ${r(amount)} जोड़ा: $note")
        b.act(g.id, Kind.MONEY, m)
        commit(b)
    }

    private fun typeName(t: String): Msg = when (t) {
        TxType.SAVING -> Msg("saving", "बचत")
        TxType.FINE -> Msg("fine", "जुर्माना")
        TxType.LOAN -> Msg("loan", "लोन")
        TxType.REPAY -> Msg("repayment", "किस्त")
        TxType.INCOME -> Msg("income", "आय")
        TxType.EXPENSE -> Msg("expense", "खर्च")
        TxType.OPEN_SAVING -> Msg("opening saving", "शुरुआती बचत")
        TxType.OPEN_INTEREST -> Msg("opening interest", "शुरुआती ब्याज")
        TxType.PROFIT_SHARE -> Msg("profit share", "मुनाफ़ा हिस्सा")
        TxType.PROFIT_PAYOUT -> Msg("profit payout", "मुनाफ़ा भुगतान")
        TxType.WITHDRAW -> Msg("withdrawal", "निकासी")
        else -> Msg(t, t)
    }
    fun typeLabel(t: String): String = typeName(t).text()

    /** Edit needs the edit permission and a reason. Old values stay in the history. */
    fun editTxn(t: Txn, amount: Double, principal: Double, interest: Double, note: String, chosenDate: Long?, reason: String): String? {
        val g = g()
        if (!g.canEdit(uid())) return tx("Editing is OFF. Ask the ${if (Session.isAdmin) "co-admin" else "admin"} to allow it.", "एंट्री बदलना बंद है। ${if (Session.isAdmin) "सह-एडमिन" else "एडमिन"} से अनुमति लें।")
        if (reason.isBlank()) return tx("Please write a reason", "कारण लिखें")
        val parts = mutableListOf<String>()
        val upd = mutableMapOf<String, Any>()
        if (Calc.round2(amount) != t.amount) { parts += "${r(t.amount)} → ${r(amount)}"; upd["amount"] = Calc.round2(amount) }
        if (t.type == TxType.REPAY) {
            if (Calc.round2(principal) != t.principal) { parts += "principal ${r(t.principal)} → ${r(principal)}"; upd["principal"] = Calc.round2(principal) }
            if (Calc.round2(interest) != t.interest) { parts += "interest ${r(t.interest)} → ${r(interest)}"; upd["interest"] = Calc.round2(interest) }
        }
        if (note != t.note) { parts += "note changed"; upd["note"] = note }
        if (chosenDate != null && Calc.isoDate(chosenDate) != Calc.isoDate(t.date)) {
            if (!g.canBackdate(uid())) return tx("Changing the date needs back-date permission", "तारीख बदलने के लिए पिछली तारीख की अनुमति चाहिए")
            parts += "date ${Calc.date(t.date)} → ${Calc.date(chosenDate)}"; upd["date"] = chosenDate; upd["backdated"] = true
        }
        if (parts.isEmpty()) return tx("Nothing changed", "कुछ नहीं बदला")
        val detail = parts.joinToString(", ")
        upd["edited"] = true
        upd["history"] = FieldValue.arrayUnion(mapOf("action" to "edited", "by" to meName(), "at" to now(), "reason" to reason, "detail" to detail))
        val tn = typeName(t.type)
        val b = db.batch()
        b.update(gref(g.id).collection("txns").document(t.id), upd)
        if (t.type == TxType.LOAN && upd.containsKey("amount")) {
            b.update(gref(g.id).collection("loans").document(t.loanId), "principal", Calc.round2(amount))
        }
        val when_ = Calc.dateTime(now())
        if (t.memberUid.isNotBlank()) {
            val mon = if (t.month.isNotBlank()) " ${monthEn(t.month)}" else ""
            val monHi = if (t.month.isNotBlank()) " ${monthHi(t.month)}" else ""
            b.note(g.id, t.memberUid, Msg("✏️ Your entry was edited", "✏️ आपकी एंट्री बदली गई"),
                Msg("${meName()} edited your$mon ${tn.en}: $detail ($when_). Reason: $reason",
                    "${meName()} ने आपकी$monHi ${tn.hi} बदली: $detail ($when_)। कारण: $reason"), Kind.EDIT)
        }
        b.act(g.id, Kind.EDIT, Msg("✏️ ${meName()} edited a ${tn.en} entry", "✏️ ${meName()} ने एक ${tn.hi} एंट्री बदली"), t.memberUid)
        commit(b)
        return null
    }

    fun deleteTxn(t: Txn, reason: String): String? {
        val g = g()
        if (!g.canEdit(uid())) return tx("Editing is OFF. Ask the ${if (Session.isAdmin) "co-admin" else "admin"} to allow it.", "एंट्री बदलना बंद है। ${if (Session.isAdmin) "सह-एडमिन" else "एडमिन"} से अनुमति लें।")
        if (reason.isBlank()) return tx("Please write a reason", "कारण लिखें")
        val tn = typeName(t.type)
        val b = db.batch()
        b.update(gref(g.id).collection("txns").document(t.id), mapOf(
            "deleted" to true,
            "history" to FieldValue.arrayUnion(mapOf("action" to "deleted", "by" to meName(), "at" to now(), "reason" to reason, "detail" to "${r(t.amount)} removed")),
        ))
        if (t.type == TxType.LOAN && t.loanId.isNotBlank()) b.update(gref(g.id).collection("loans").document(t.loanId), "status", "cancelled")
        if (t.memberUid.isNotBlank()) {
            b.note(g.id, t.memberUid, Msg("🗑 Your entry was deleted", "🗑 आपकी एंट्री हटाई गई"),
                Msg("${meName()} deleted your ${tn.en} of ${r(t.amount)} (${Calc.dateTime(now())}). Reason: $reason",
                    "${meName()} ने आपकी ${r(t.amount)} की ${tn.hi} हटाई (${Calc.dateTime(now())})। कारण: $reason"), Kind.EDIT)
        }
        b.act(g.id, Kind.EDIT, Msg("🗑 ${meName()} deleted a ${tn.en} entry", "🗑 ${meName()} ने एक ${tn.hi} एंट्री हटाई"), t.memberUid)
        commit(b)
        return null
    }

    // =====================================================================
    // Meetings
    // =====================================================================

    fun saveMeeting(existing: Meeting?, date: Long, title: String, notes: String, attendees: List<String>) {
        val g = g()
        val ref = if (existing != null) gref(g.id).collection("meetings").document(existing.id) else gref(g.id).collection("meetings").document()
        val b = db.batch()
        b.set(ref, mapOf(
            "date" to date, "title" to title, "notes" to notes, "attendees" to attendees,
            "createdByName" to (existing?.createdByName ?: meName()),
        ), SetOptions.merge())
        if (existing == null) {
            val m = Msg("Meeting \"$title\" on ${Calc.dateTime(date)}", "बैठक \"$title\" — ${Calc.dateTime(date)}")
            b.note(g.id, "all", Msg("📅 Meeting", "📅 बैठक"), m, Kind.MEETING)
            b.act(g.id, Kind.MEETING, Msg("${meName()} added meeting: $title (${Calc.dateTime(date)})", "${meName()} ने बैठक जोड़ी: $title (${Calc.dateTime(date)})"))
        } else {
            b.act(g.id, Kind.MEETING, Msg("${meName()} updated meeting: $title (${attendees.size} present)", "${meName()} ने बैठक अपडेट की: $title (${attendees.size} उपस्थित)"))
        }
        commit(b)
    }

    // =====================================================================
    // Old records setup
    // =====================================================================

    fun saveOpening(m: Member, saved: Double, interestPaid: Double, loanLeft: Double, rate: Double, monthsLeft: Int, method: String, asOf: Long) {
        val g = g()
        val b = db.batch()
        if (saved > 0) b.set(gref(g.id).collection("txns").document(), txnMap(TxType.OPEN_SAVING, m, saved, asOf, true, note = "Opening balance"))
        if (interestPaid > 0) b.set(gref(g.id).collection("txns").document(), txnMap(TxType.OPEN_INTEREST, m, interestPaid, asOf, true, note = "Interest paid before using the app"))
        if (loanLeft > 0) {
            val lref = gref(g.id).collection("loans").document()
            b.set(lref, mapOf(
                "memberUid" to m.uid, "memberName" to m.name, "principal" to loanLeft, "rate" to rate,
                "months" to monthsLeft.coerceAtLeast(1), "method" to method, "startDate" to asOf, "status" to "active",
                "opening" to true, "createdByName" to meName(), "note" to "Loan still due when the group started using the app", "createdAt" to now(),
            ))
        }
        b.update(gref(g.id).collection("members").document(m.uid), mapOf("opening" to "pending", "openingNote" to ""))
        b.note(g.id, m.uid, Msg("Please check your opening balance", "अपना शुरुआती बैलेंस जाँचें"),
            Msg("Saved ${r(saved)}, Loan ${r(loanLeft)}, Interest paid ${r(interestPaid)} (as of ${Calc.date(asOf)}). Open the app to Confirm or Report a mistake.",
                "बचत ${r(saved)}, लोन ${r(loanLeft)}, ब्याज भरा ${r(interestPaid)} (${Calc.date(asOf)} तक)। ऐप खोलकर पुष्टि करें या गलती बताएं।"), Kind.SETUP)
        b.act(g.id, Kind.SETUP, Msg("${meName()} entered the opening balance for ${m.name}", "${meName()} ने ${m.name} का शुरुआती बैलेंस डाला"), m.uid)
        commit(b)
    }

    fun confirmOpening(ok: Boolean, note: String) {
        val g = g()
        val me = Session.me ?: return
        val b = db.batch()
        b.update(gref(g.id).collection("members").document(me.uid), mapOf("opening" to if (ok) "confirmed" else "disputed", "openingNote" to note))
        val m = if (ok) Msg("${me.name} confirmed their opening balance ✅", "${me.name} ने अपने शुरुआती बैलेंस की पुष्टि की ✅")
        else Msg("${me.name} reported a mistake in their opening balance: $note", "${me.name} ने शुरुआती बैलेंस में गलती बताई: $note")
        b.act(g.id, Kind.SETUP, m, me.uid)
        b.note(g.id, g.adminUid, Msg(if (ok) "Opening balance confirmed" else "Opening balance mistake", if (ok) "शुरुआती बैलेंस पुष्टि" else "शुरुआती बैलेंस में गलती"), m, Kind.SETUP)
        commit(b)
    }

    fun closeSetup() {
        val g = g()
        val b = db.batch()
        b.update(gref(g.id), "setupClosed", true)
        val m = Msg("${meName()} closed Old Records Setup. Back-dating is now locked.", "${meName()} ने पुराने रिकॉर्ड सेटअप बंद किया। अब पिछली तारीख लॉक है।")
        b.act(g.id, Kind.SETUP, m)
        b.note(g.id, "all", Msg("Old records setup closed", "पुराने रिकॉर्ड सेटअप बंद"), m, Kind.SETUP)
        commit(b)
    }

    /** Rows from an Excel/CSV upload, entered with their real dates (setup period only). */
    data class ImportRow(val date: Long, val member: Member?, val type: String, val amount: Double, val note: String)

    fun importRows(rows: List<ImportRow>): String? {
        val g = g()
        if (!g.setupOpen()) return tx("Old records upload works only during the setup period", "पुराने रिकॉर्ड अपलोड केवल सेटअप के समय होता है")
        rows.chunked(400).forEachIndexed { i, chunk ->
            val b = db.batch()
            chunk.forEach { row ->
                val month = if (row.type == TxType.SAVING) Calc.monthKey(row.date) else ""
                b.set(gref(g.id).collection("txns").document(), txnMap(row.type, row.member, row.amount, row.date, true, month = month, note = row.note.ifBlank { "Imported old record" }))
            }
            if (i == 0) {
                val m = Msg("${meName()} uploaded ${rows.size} old records from Excel", "${meName()} ने Excel से ${rows.size} पुराने रिकॉर्ड अपलोड किए")
                b.act(g.id, Kind.SETUP, m)
                b.note(g.id, "all", Msg("Old records uploaded", "पुराने रिकॉर्ड अपलोड"), m, Kind.SETUP)
            }
            commit(b)
        }
        return null
    }

    // =====================================================================
    // Year-end profit share
    // =====================================================================

    fun shareProfit(shares: List<Pair<Member, Double>>, addToSavings: Boolean) {
        val g = g()
        val type = if (addToSavings) TxType.PROFIT_SHARE else TxType.PROFIT_PAYOUT
        val total = shares.sumOf { it.second }
        val b = db.batch()
        shares.filter { it.second > 0 }.forEach { (m, amt) ->
            b.set(gref(g.id).collection("txns").document(), txnMap(type, m, amt, now(), false, note = "Year-end profit share"))
            b.note(g.id, m.uid, Msg("🎯 Your profit share", "🎯 आपका मुनाफ़ा हिस्सा"),
                Msg("${r(amt)} " + if (addToSavings) "added to your savings" else "paid to you in cash",
                    "${r(amt)} " + if (addToSavings) "आपकी बचत में जोड़ा गया" else "आपको नकद दिया गया"), Kind.MONEY)
        }
        b.update(gref(g.id), "lastCloseAt", now())
        val m = Msg("${meName()} closed the year and shared profit ${r(total)} among members " + if (addToSavings) "(added to savings)" else "(paid in cash)",
            "${meName()} ने साल बंद किया और ${r(total)} मुनाफ़ा सदस्यों में बाँटा " + if (addToSavings) "(बचत में जोड़ा)" else "(नकद दिया)")
        b.act(g.id, Kind.MONEY, m)
        b.note(g.id, "all", Msg("Year-end profit shared", "साल का मुनाफ़ा बँटा"), m, Kind.MONEY)
        commit(b)
    }
}
