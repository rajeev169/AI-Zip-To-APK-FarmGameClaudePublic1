package com.rajeev.samuhkhata.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.samuhkhata.core.Calc
import com.rajeev.samuhkhata.core.Exporter
import com.rajeev.samuhkhata.core.Member
import com.rajeev.samuhkhata.core.MemberStatus
import com.rajeev.samuhkhata.core.Repo
import com.rajeev.samuhkhata.core.Role
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.tx

@Composable
fun CallButton(phone: String) {
    val ctx = LocalContext.current
    if (phone.isBlank()) return
    IconButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
        Icon(Icons.Outlined.Phone, tx("Call", "कॉल करें"), tint = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun RoleTag(m: Member) {
    when {
        m.role == Role.ADMIN -> Tag(tx("Admin", "एडमिन"), MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary)
        m.role == Role.CO -> Tag(tx("Co-admin", "सह-एडमिन"))
        m.status == MemberStatus.LEAVE_REQUESTED -> Tag(tx("Wants to leave", "छोड़ना चाहते हैं"), LocalExtra.current.warnBg, LocalExtra.current.warnFg)
    }
}

@Composable
fun MembersScreen() {
    val g = Session.group ?: return
    val ctx = LocalContext.current
    val isAdmin = Session.isAdmin
    var addGmail by remember { mutableStateOf(false) }
    var newCode by remember { mutableStateOf(false) }
    var pickCo by remember { mutableStateOf(false) }
    var removeCo by remember { mutableStateOf(false) }
    val active = Session.activeMembers
    val co = Session.memberById(g.coAdminUid)

    Page(tx("Members", "सदस्य"), "${active.size} ${tx("members", "सदस्य")}" + if (g.maxSize > 0) " · ${tx("max", "अधिकतम")} ${g.maxSize}" else "") {
        item {
            SectionCard(tx("Add members", "सदस्य जोड़ें")) {
                Text(tx("Two ways — use either, as many times as you like.", "दो तरीके — जितनी बार चाहें, किसी से भी।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                PrimaryButton(tx("Add by Gmail (joins automatically)", "Gmail से जोड़ें (अपने आप जुड़ेंगे)")) { addGmail = true }
                Divider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tx("Invite code", "इनवाइट कोड"), style = MaterialTheme.typography.bodyMedium)
                        Text(g.inviteCode.chunked(3).joinToString(" "), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = 2.sp)
                    }
                    IconButton(onClick = {
                        Exporter.shareText(ctx, tx("Join our savings group \"${g.name}\" on the Samuh Khata app. Sign in with Google, tap \"Join with invite code\" and enter: ${g.inviteCode}",
                            "Samuh Khata ऐप पर हमारे बचत समूह \"${g.name}\" से जुड़ें। Google से साइन इन करें, \"इनवाइट कोड से जुड़ें\" दबाएं और यह कोड डालें: ${g.inviteCode}"))
                    }) { Icon(Icons.Outlined.Share, tx("Share", "शेयर")) }
                    if (isAdmin) IconButton(onClick = { newCode = true }) { Icon(Icons.Outlined.Refresh, tx("New code", "नया कोड")) }
                }
            }
        }

        if (Session.joinRequests.isNotEmpty()) {
            item { SectionLabel(tx("Join requests", "जुड़ने के अनुरोध")) }
            items(Session.joinRequests, key = { "r" + it.uid }) { r ->
                SectionCard(padding = 12.dp) {
                    ListRow(r.name, "${r.email} · ${Calc.shortDateTime(r.at)}", leading = { Avatar(r.name.take(1).uppercase()) }, chevron = false)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PrimaryButton(tx("Approve", "मंज़ूर करें"), modifier = Modifier.weight(1f)) { Repo.approve(r)?.let { Session.error = it } }
                        SecondaryButton(tx("Decline", "अस्वीकार"), modifier = Modifier.weight(1f), color = LocalExtra.current.badFg) { Repo.reject(r) }
                    }
                }
            }
        }

        if (Session.invites.isNotEmpty()) {
            item { SectionLabel(tx("Added by Gmail — not joined yet", "Gmail से जोड़े — अभी नहीं जुड़े")) }
            items(Session.invites, key = { "i" + it.email }) { inv ->
                SectionCard(padding = 12.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(inv.email, style = MaterialTheme.typography.titleMedium)
                            Text(tx("Pending: not joined yet · added by ${inv.addedByName}", "लंबित: अभी नहीं जुड़े · ${inv.addedByName} ने जोड़ा"), style = MaterialTheme.typography.bodySmall, color = LocalExtra.current.warnFg)
                        }
                        IconButton(onClick = { Repo.removeInvite(inv.email) }) { Icon(Icons.Outlined.Delete, tx("Remove", "हटाएं")) }
                    }
                    Text(tx("Wrong spelling? Remove it and add again.", "स्पेलिंग गलत है? हटाकर फिर से जोड़ें।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        item {
            SectionCard(tx("Co-admin", "सह-एडमिन")) {
                if (co == null) Text(tx("No co-admin yet. The co-admin holds the back-date and edit permission switches.", "अभी कोई सह-एडमिन नहीं। सह-एडमिन पिछली तारीख और बदलाव की अनुमति रखते हैं।"))
                else ListRow(co.name, co.email, leading = { Avatar(co.initials) }, chevron = false)
                if (isAdmin) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(if (co == null) tx("Choose co-admin", "सह-एडमिन चुनें") else tx("Change co-admin", "सह-एडमिन बदलें"), modifier = Modifier.weight(1f)) { pickCo = true }
                    if (co != null) SecondaryButton(tx("Remove", "हटाएं"), modifier = Modifier.weight(1f), color = LocalExtra.current.badFg) { removeCo = true }
                }
                Text(tx("All members are notified when the co-admin is chosen or changed.", "सह-एडमिन चुनने या बदलने पर सभी सदस्यों को सूचना जाती है।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        item { SectionLabel(tx("All members", "सभी सदस्य")) }
        items(active, key = { it.uid }) { m ->
            SectionCard(padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        ListRow(m.name, tx("Saved ${Calc.rupees(Calc.memberSavings(m.uid, Session.txns))}", "बचत ${Calc.rupees(Calc.memberSavings(m.uid, Session.txns))}"),
                            leading = { Avatar(m.initials) }, onClick = { Nav.go(Screen.MemberDetail(m.uid)) }, chevron = false)
                    }
                    RoleTag(m)
                }
            }
        }
        val left = Session.members.filter { it.status == MemberStatus.LEFT }
        if (left.isNotEmpty()) {
            item { SectionLabel(tx("Left the group", "समूह छोड़ चुके")) }
            items(left, key = { "l" + it.uid }) { m -> ListRow(m.name, m.email, leading = { Avatar(m.initials) }, onClick = { Nav.go(Screen.Passbook(m.uid)) }) }
        }
    }

    if (addGmail) InputDialog(tx("Add member by Gmail", "Gmail से सदस्य जोड़ें"), tx("Member's Gmail address", "सदस्य का Gmail पता"), confirm = tx("Add", "जोड़ें"),
        onDismiss = { addGmail = false }) { email -> Repo.addInvite(email)?.let { Session.error = it } }
    if (newCode) ConfirmDialog(tx("Make a new invite code?", "नया इनवाइट कोड बनाएं?"), tx("The old code will stop working. All members are notified.", "पुराना कोड बंद हो जाएगा। सभी सदस्यों को सूचना जाएगी।"),
        tx("Make new code", "नया कोड बनाएं"), { newCode = false }) { Repo.regenerateCode() }
    if (pickCo) MemberPickerDialog(tx("Choose co-admin", "सह-एडमिन चुनें"), active.filter { it.role != Role.ADMIN && it.uid != g.coAdminUid }, { pickCo = false }) { m ->
        pendingCo = m
    }
    val pc = pendingCo
    if (pc != null) ConfirmDialog(tx("Make ${pc.name} co-admin?", "${pc.name} को सह-एडमिन बनाएं?"),
        tx("All members will be notified. Any permission that is ON will turn OFF.", "सभी सदस्यों को सूचना जाएगी। जो भी अनुमति चालू है वह बंद हो जाएगी।"),
        tx("Confirm", "पुष्टि करें"), { pendingCo = null }) { Repo.setCoAdmin(pc) }
    if (removeCo) ConfirmDialog(tx("Remove co-admin?", "सह-एडमिन हटाएं?"), tx("Permissions will turn OFF until a new co-admin is chosen.", "नया सह-एडमिन चुनने तक अनुमतियाँ बंद रहेंगी।"),
        tx("Remove", "हटाएं"), { removeCo = false }) { Repo.setCoAdmin(null) }
}

private var pendingCo by mutableStateOf<Member?>(null)

@Composable
fun MemberDetailScreen(uid: String) {
    val g = Session.group ?: return
    val m = Session.memberById(uid) ?: run { Page(tx("Member", "सदस्य")) { item { Empty(tx("Not found", "नहीं मिला")) } }; return }
    val txns = Session.txns
    val saved = Calc.memberSavings(uid, txns)
    val loans = Session.loans.filter { it.memberUid == uid && it.status == "active" }
    val loanDue = loans.sumOf { Calc.outstanding(it, txns) }
    var remove by remember { mutableStateOf(false) }
    var makeCo by remember { mutableStateOf(false) }

    Page(m.name, roleName(m.role)) {
        item {
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(m.initials, size = 52.dp)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(m.name, style = MaterialTheme.typography.titleMedium)
                        Text(m.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(m.phone.ifBlank { tx("No phone added", "फ़ोन नंबर नहीं") }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    CallButton(m.phone)
                }
                Text(tx("Joined ${Calc.date(m.joinedAt)}", "${Calc.date(m.joinedAt)} को जुड़े"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Saved", "बचत"), Calc.rupees(saved), Modifier.weight(1f))
                    Stat(tx("Loan due", "बाकी लोन"), Calc.rupees(loanDue), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Interest paid", "ब्याज भरा"), Calc.rupees(Calc.memberInterestPaid(uid, txns)), Modifier.weight(1f))
                    Stat(tx("Fines", "जुर्माना"), Calc.rupees(Calc.memberFines(uid, txns)), Modifier.weight(1f))
                }
            }
        }
        if (m.status == MemberStatus.LEAVE_REQUESTED) item {
            Banner(tx("${m.name} asked to leave. Settle their money and remove them below.", "${m.name} समूह छोड़ना चाहते हैं। नीचे हिसाब करके हटाएं।"))
        }
        if (m.opening == "disputed") item {
            Banner(tx("Reported mistake in opening balance: ${m.openingNote}", "शुरुआती बैलेंस में गलती बताई: ${m.openingNote}")) { Nav.go(Screen.Opening(uid)) }
        }
        item {
            SectionCard(tx("Actions", "काम")) {
                ListRow(tx("Passbook", "पासबुक"), tx("All entries, download PDF", "सभी एंट्री, PDF डाउनलोड"), onClick = { Nav.go(Screen.Passbook(uid)) })
                Divider()
                ListRow(tx("Give new loan", "नया लोन दें"), null, onClick = { Nav.go(Screen.NewLoan(uid)) })
                loans.forEach { l ->
                    Divider()
                    ListRow(tx("Loan ${Calc.rupees(l.principal)}", "लोन ${Calc.rupees(l.principal)}"), tx("${Calc.rupees(Calc.outstanding(l, txns))} left", "${Calc.rupees(Calc.outstanding(l, txns))} बाकी"), onClick = { Nav.go(Screen.LoanDetail(l.id)) })
                }
                if (g.setupOpen()) {
                    Divider()
                    ListRow(tx("Opening balance (old records)", "शुरुआती बैलेंस (पुराना हिसाब)"), when (m.opening) {
                        "pending" -> tx("Waiting for member to confirm", "सदस्य की पुष्टि का इंतज़ार")
                        "confirmed" -> tx("Confirmed by member ✅", "सदस्य ने पुष्टि की ✅")
                        "disputed" -> tx("Member reported a mistake", "सदस्य ने गलती बताई")
                        else -> tx("Not entered yet", "अभी नहीं डाला")
                    }, onClick = { Nav.go(Screen.Opening(uid)) })
                }
                if (Session.isAdmin && m.role == Role.MEMBER && m.status != MemberStatus.LEFT) {
                    Divider()
                    ListRow(tx("Make co-admin", "सह-एडमिन बनाएं"), tx("All members will be notified", "सभी को सूचना जाएगी"), onClick = { makeCo = true })
                }
                if (m.role != Role.ADMIN && m.status != MemberStatus.LEFT) {
                    Divider()
                    ListRow(tx("Settle & remove from group", "हिसाब करके समूह से हटाएं"), null, valueColor = LocalExtra.current.badFg, onClick = { remove = true })
                }
            }
        }
        item { SectionLabel(tx("Recent entries", "हाल की एंट्री")) }
        val list = txns.filter { it.memberUid == uid }.take(15)
        if (list.isEmpty()) item { Empty(tx("No entries yet", "अभी कोई एंट्री नहीं")) }
        items(list, key = { it.id }) { SectionCard(padding = 8.dp) { TxnRow(it, showMember = false) } }
    }

    if (makeCo) ConfirmDialog(tx("Make ${m.name} co-admin?", "${m.name} को सह-एडमिन बनाएं?"),
        tx("All members will be notified. Any permission that is ON will turn OFF.", "सभी सदस्यों को सूचना जाएगी। जो भी अनुमति चालू है वह बंद हो जाएगी।"),
        tx("Confirm", "पुष्टि करें"), { makeCo = false }) { Repo.setCoAdmin(m) }
    if (remove) SettleDialog(m, saved, loanDue) { remove = false }
}

@Composable
private fun SettleDialog(m: Member, saved: Double, loanDue: Double, onDismiss: () -> Unit) {
    val suggested = maxOf(0.0, saved - loanDue)
    var amount by remember { mutableStateOf(Calc.num(suggested)) }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Settle & remove ${m.name}", "${m.name} का हिसाब करके हटाएं")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tx("Saved: ${Calc.rupees(saved)}  ·  Loan still due: ${Calc.rupees(loanDue)}", "बचत: ${Calc.rupees(saved)}  ·  बाकी लोन: ${Calc.rupees(loanDue)}"))
                if (loanDue > saved) Text(tx("Loan due is more than savings. Collect the rest before removing.", "बाकी लोन बचत से ज़्यादा है। हटाने से पहले बाकी पैसा लें।"), color = LocalExtra.current.badFg)
                Field(tx("Money paid back to member (₹)", "सदस्य को लौटाई राशि (₹)"), amount, { amount = it }, number = true)
                Field(tx("Note", "नोट"), note, { note = it })
                Text(tx("All members will be notified.", "सभी सदस्यों को सूचना जाएगी।"), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.money() ?: 0.0
                Repo.settleAndRemove(m, a, note)
                onDismiss(); Nav.back()
            }) { Text(tx("Remove", "हटाएं"), color = LocalExtra.current.badFg) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx("Cancel", "रद्द करें")) } },
    )
}

/** Members' view: names and roles only, with call buttons for admin and co-admin. */
@Composable
fun MemberListScreen() {
    val g = Session.group ?: return
    val active = Session.activeMembers
    Page(tx("Members", "सदस्य"), "${active.size} ${tx("members", "सदस्य")}") {
        item {
            SectionCard {
                val admin = Session.memberById(g.adminUid)
                val co = Session.memberById(g.coAdminUid)
                if (admin != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { ListRow(admin.name, tx("Admin", "एडमिन"), leading = { Avatar(admin.initials) }, chevron = false) }
                    CallButton(admin.phone)
                }
                if (co != null) {
                    Divider()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { ListRow(co.name, tx("Co-admin", "सह-एडमिन"), leading = { Avatar(co.initials) }, chevron = false) }
                        CallButton(co.phone)
                    }
                }
            }
        }
        item { SectionLabel(tx("All members", "सभी सदस्य")) }
        items(active, key = { it.uid }) { m ->
            SectionCard(padding = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(m.initials, size = 36.dp)
                    Text(m.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f).padding(start = 12.dp))
                    RoleTag(m)
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.PersonAdd, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(tx("  Only names are shown. Everyone's money stays private.", "  केवल नाम दिखते हैं। सबका पैसा निजी रहता है।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
