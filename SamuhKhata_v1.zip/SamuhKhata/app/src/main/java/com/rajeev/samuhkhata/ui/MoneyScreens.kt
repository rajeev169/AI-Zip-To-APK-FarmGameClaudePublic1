package com.rajeev.samuhkhata.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rajeev.samuhkhata.core.Calc
import com.rajeev.samuhkhata.core.Loan
import com.rajeev.samuhkhata.core.Member
import com.rajeev.samuhkhata.core.Prefs
import com.rajeev.samuhkhata.core.Repo
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.Txn
import com.rajeev.samuhkhata.core.TxType
import com.rajeev.samuhkhata.core.tx

private fun backdateNote(): String = if (Session.isAdmin) tx("Today's date is used. Back-dating needs the co-admin's permission.", "आज की तारीख लगेगी। पिछली तारीख के लिए सह-एडमिन की अनुमति चाहिए।")
else tx("Today's date is used. Back-dating needs the admin's permission.", "आज की तारीख लगेगी। पिछली तारीख के लिए एडमिन की अनुमति चाहिए।")

private fun canBack(): Boolean = Session.group?.canBackdate(Session.uid) == true

// ---------------------------------------------------------------- savings

@Composable
fun SavingsScreen() {
    val g = Session.group ?: return
    var month by remember { mutableStateOf(Calc.monthKey()) }
    var adding by remember { mutableStateOf<Member?>(null) }
    var fineFor by remember { mutableStateOf<Member?>(null) }
    val active = Session.activeMembers
    val txns = Session.txns
    val paid = active.filter { Calc.paidSaving(it.uid, month, txns) }
    val pending = active - paid.toSet()
    val due = Calc.dueDateOf(month, g.dueDay)
    val late = System.currentTimeMillis() > due

    Page(tx("Monthly Savings", "मासिक बचत"), tx("${Calc.rupees(g.monthlySaving)} each · due by ${g.dueDay}", "हर सदस्य ${Calc.rupees(g.monthlySaving)} · ${g.dueDay} तारीख तक")) {
        item {
            SectionCard(padding = 8.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { month = Calc.shiftMonth(month, -1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, tx("Previous month", "पिछला महीना")) }
                    Text(Calc.monthLabel(month, Prefs.hindi), style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    IconButton(onClick = { if (month < Calc.monthKey()) month = Calc.shiftMonth(month, 1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, tx("Next month", "अगला महीना")) }
                }
                Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Paid", "जमा"), "${paid.size} / ${active.size}", Modifier.weight(1f))
                    Stat(tx("Collected", "जमा राशि"), Calc.rupees(Calc.live(txns).filter { it.type == TxType.SAVING && it.month == month }.sumOf { it.amount }), Modifier.weight(1f))
                    Stat(tx("Pending", "बाकी"), pending.size.toString(), Modifier.weight(1f), LocalExtra.current.warnFg)
                }
            }
        }
        if (late && pending.isNotEmpty()) item {
            Banner(tx("Due date passed. Late fine ${Calc.rupees(g.lateFine)} will be added when pending savings are recorded.", "तारीख निकल गई। बाकी बचत जमा करते समय ${Calc.rupees(g.lateFine)} जुर्माना जुड़ेगा।"), Icons.Outlined.Warning)
        }
        if (pending.isNotEmpty()) {
            item { SectionLabel(tx("Pending — tap to add", "बाकी — जोड़ने के लिए दबाएं")) }
            items(pending, key = { "p" + it.uid }) { m ->
                SectionCard(padding = 10.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            ListRow(m.name, if (late) tx("Late · fine applies", "देर · जुर्माना लगेगा") else tx("Not paid yet", "अभी जमा नहीं"),
                                leading = { Avatar(m.initials, LocalExtra.current.warnBg, LocalExtra.current.warnFg) }, onClick = { adding = m }, chevron = false)
                        }
                        TextButton(onClick = { fineFor = m }) { Text(tx("Fine", "जुर्माना")) }
                        PrimaryButton(tx("Add", "जोड़ें"), modifier = Modifier) { adding = m }
                    }
                }
            }
        }
        if (paid.isNotEmpty()) {
            item { SectionLabel(tx("Paid", "जमा")) }
            items(paid, key = { "d" + it.uid }) { m ->
                val t = Calc.savingTxnFor(m.uid, month, txns)
                SectionCard(padding = 10.dp) {
                    ListRow(m.name, if (t != null) "${Calc.shortDateTime(t.date)} · ${tx("by", "")} ${t.createdByName}" else null,
                        value = t?.let { Calc.rupees(it.amount) }, valueColor = MaterialTheme.colorScheme.primary,
                        leading = { Avatar(m.initials) }, badge = if (t?.edited == true) tx("Edited", "बदली") else null,
                        onClick = { if (t != null) Nav.go(Screen.TxnDetail(t.id)) })
                }
            }
        }
    }

    adding?.let { m -> AddSavingDialog(m, month) { adding = null } }
    fineFor?.let { m ->
        var amt by remember(m.uid) { mutableStateOf(Calc.num(g.lateFine)) }
        var note by remember(m.uid) { mutableStateOf(tx("Late fine", "देर का जुर्माना")) }
        AlertDialog(
            onDismissRequest = { fineFor = null },
            title = { Text(tx("Add fine for ${m.name}", "${m.name} पर जुर्माना")) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(tx("Fine amount (₹)", "जुर्माना राशि (₹)"), amt, { amt = it }, number = true)
                Field(tx("Reason", "कारण"), note, { note = it })
            } },
            confirmButton = { TextButton(onClick = { amt.money()?.let { if (it > 0) Repo.addFine(m, it, note, null) }; fineFor = null }) { Text(tx("Add fine", "जुर्माना जोड़ें")) } },
            dismissButton = { TextButton(onClick = { fineFor = null }) { Text(tx("Cancel", "रद्द करें")) } },
        )
    }
}

@Composable
private fun AddSavingDialog(m: Member, month: String, onDismiss: () -> Unit) {
    val g = Session.group ?: return
    var amount by remember { mutableStateOf(Calc.num(g.monthlySaving)) }
    var date by remember { mutableStateOf(System.currentTimeMillis()) }
    val due = Calc.dueDateOf(month, g.dueDay)
    var fine by remember { mutableStateOf(System.currentTimeMillis() > due && g.lateFine > 0) }
    var fineAmt by remember { mutableStateOf(Calc.num(g.lateFine)) }
    val back = canBack()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Saving: ${m.name}", "बचत: ${m.name}")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(Calc.monthLabel(month, Prefs.hindi), fontWeight = FontWeight.SemiBold)
                Field(tx("Amount (₹)", "राशि (₹)"), amount, { amount = it }, number = true)
                DateRow(tx("Date received", "जमा की तारीख"), date, back, backdateNote()) {
                    date = it; fine = it > due && g.lateFine > 0
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = fine, onCheckedChange = { fine = it })
                    Text(tx("Add late fine", "देर का जुर्माना जोड़ें"), modifier = Modifier.weight(1f))
                }
                if (fine) Field(tx("Fine (₹)", "जुर्माना (₹)"), fineAmt, { fineAmt = it }, number = true)
                Text(tx("${m.name} gets a notification.", "${m.name} को सूचना जाएगी।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.money()
                if (a == null || a <= 0) { Session.error = tx("Enter amount", "राशि लिखें"); return@TextButton }
                Repo.addSaving(m, month, a, if (back) date else null, fine, fineAmt.money() ?: 0.0)
                onDismiss()
            }) { Text(tx("Mark paid", "जमा करें")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx("Cancel", "रद्द करें")) } },
    )
}

// ---------------------------------------------------------------- loans

@Composable
fun LoansScreen() {
    val txns = Session.txns
    val active = Session.loans.filter { it.status == "active" }
    val closed = Session.loans.filter { it.status == "closed" }
    Page(tx("Loans", "लोन"), tx("${active.size} active · ${Calc.rupees(active.sumOf { Calc.outstanding(it, txns) })} out", "${active.size} चालू · ${Calc.rupees(active.sumOf { Calc.outstanding(it, txns) })} बाहर"),
        bottom = { PrimaryButton(tx("Give new loan", "नया लोन दें")) { Nav.go(Screen.NewLoan()) } }) {
        if (active.isEmpty()) item { Empty(tx("No active loans", "कोई चालू लोन नहीं")) }
        items(active, key = { it.id }) { LoanCard(it) }
        if (closed.isNotEmpty()) {
            item { SectionLabel(tx("Fully repaid", "पूरा चुकाया")) }
            items(closed, key = { "c" + it.id }) { LoanCard(it) }
        }
    }
}

@Composable
fun LoanCard(l: Loan) {
    val txns = Session.txns
    val out = Calc.outstanding(l, txns)
    val overdue = Calc.isOverdue(l, out)
    SectionCard(padding = 12.dp) {
        ListRow(
            "${l.memberName} · ${Calc.rupees(l.principal)}",
            if (l.status == "closed") tx("Fully repaid", "पूरा चुकाया")
            else tx("${Calc.num(l.rate)}% ${l.method} · next EMI ${Calc.rupees(Calc.nextEmi(l, out))} on ${Calc.shortDate(Calc.nextDueDate(l, out))}",
                "${Calc.num(l.rate)}% ${if (l.method == "flat") "फ्लैट" else "घटता"} · अगली किस्त ${Calc.rupees(Calc.nextEmi(l, out))} ${Calc.shortDate(Calc.nextDueDate(l, out))} को"),
            value = Calc.rupees(out),
            badge = when { overdue -> tx("Overdue", "बकाया"); l.opening -> tx("Old loan", "पुराना लोन"); else -> null },
            onClick = { Nav.go(Screen.LoanDetail(l.id)) },
        )
    }
}

@Composable
fun NewLoanScreen(memberUid: String) {
    val g = Session.group ?: return
    var member by remember { mutableStateOf(Session.memberById(memberUid)) }
    var pick by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf(Calc.num(g.interestRate)) }
    var months by remember { mutableStateOf("10") }
    var method by remember { mutableStateOf(g.interestMethod) }
    var date by remember { mutableStateOf(System.currentTimeMillis()) }
    var note by remember { mutableStateOf("") }
    val back = canBack()
    val a = amount.money() ?: 0.0
    val r = rate.money() ?: 0.0
    val n = months.toIntOrNull() ?: 0
    val preview = if (a > 0 && n > 0) Loan("", "", "", a, r, n, method, date, "active", false, "", "") else null
    val cash = g.summary.cash

    Page(tx("New loan", "नया लोन"), bottom = {
        PrimaryButton(tx("Give loan", "लोन दें"), enabled = member != null && a > 0 && n > 0) {
            val m = member ?: return@PrimaryButton
            Repo.newLoan(m, a, r, n, method, if (back) date else null, note)
            Nav.back()
        }
    }) {
        item {
            SectionCard {
                PickerField(tx("Member", "सदस्य"), member?.name ?: "") { pick = true }
                Field(tx("Loan amount (₹)", "लोन राशि (₹)"), amount, { amount = it }, number = true)
                if (a > cash) Text(tx("Cash in hand is only ${Calc.rupees(cash)}", "हाथ में केवल ${Calc.rupees(cash)} नकद है"), color = LocalExtra.current.warnFg, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field(tx("Interest % / month", "ब्याज % / माह"), rate, { rate = it }, number = true, modifier = Modifier.weight(1f))
                    Field(tx("Months", "महीने"), months, { months = it.filter { c -> c.isDigit() } }, number = true, modifier = Modifier.weight(1f))
                }
                Segmented(listOf("flat" to tx("Flat", "फ्लैट"), "reducing" to tx("Reducing", "घटता हुआ")), method) { method = it }
                DateRow(tx("Loan date", "लोन की तारीख"), date, back, backdateNote()) { date = it }
                Field(tx("Purpose / note", "उद्देश्य / नोट"), note, { note = it })
            }
        }
        if (preview != null) item {
            val sched = Calc.schedule(preview)
            SectionCard(tx("Repayment plan", "किस्त योजना")) {
                Text(tx("First EMI ${Calc.rupees(sched.first().second + sched.first().third)} on ${Calc.date(sched.first().first)}",
                    "पहली किस्त ${Calc.rupees(sched.first().second + sched.first().third)} — ${Calc.date(sched.first().first)}"), fontWeight = FontWeight.SemiBold)
                Text(tx("Total interest ${Calc.rupees(sched.sumOf { it.third })} · Total to repay ${Calc.rupees(a + sched.sumOf { it.third })}",
                    "कुल ब्याज ${Calc.rupees(sched.sumOf { it.third })} · कुल वापसी ${Calc.rupees(a + sched.sumOf { it.third })}"))
                sched.take(12).forEachIndexed { i, (d, p, intr) ->
                    Row { Text("${i + 1}. ${Calc.shortDate(d)}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        Text("${Calc.rupees(p)} + ${Calc.rupees(intr)} = ${Calc.rupees(p + intr)}", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
    if (pick) MemberPickerDialog(tx("Choose member", "सदस्य चुनें"), Session.activeMembers, { pick = false }) { member = it }
}

@Composable
fun LoanDetailScreen(id: String) {
    val l = Session.loans.firstOrNull { it.id == id } ?: run { Page(tx("Loan", "लोन")) { item { Empty(tx("Not found", "नहीं मिला")) } }; return }
    val txns = Session.txns
    val out = Calc.outstanding(l, txns)
    val repayments = Calc.live(txns).filter { it.type == TxType.REPAY && it.loanId == l.id }.sortedBy { it.date }
    var pay by remember { mutableStateOf(false) }
    val paidCount = Calc.instalmentsPaid(l, out)
    Page(tx("Loan · ${l.memberName}", "लोन · ${l.memberName}"), "${Calc.rupees(l.principal)} · ${Calc.date(l.startDate)}",
        bottom = if (Session.isStaff && l.status == "active") ({ PrimaryButton(tx("Add repayment", "किस्त जोड़ें")) { pay = true } }) else null) {
        item {
            SectionCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Still due", "बाकी"), Calc.rupees(out), Modifier.weight(1f))
                    Stat(tx("Paid back", "लौटाया"), Calc.rupees(Calc.repaidPrincipal(l, txns)), Modifier.weight(1f))
                    Stat(tx("Interest paid", "ब्याज भरा"), Calc.rupees(Calc.repaidInterest(l, txns)), Modifier.weight(1f))
                }
                Text(tx("${Calc.num(l.rate)}% per month · ${if (l.method == "flat") "flat" else "reducing"} · ${l.months} months", "${Calc.num(l.rate)}% प्रति माह · ${if (l.method == "flat") "फ्लैट" else "घटता"} · ${l.months} महीने"))
                if (l.status == "active") Text(tx("Next EMI ${Calc.rupees(Calc.nextEmi(l, out))} on ${Calc.date(Calc.nextDueDate(l, out))}", "अगली किस्त ${Calc.rupees(Calc.nextEmi(l, out))} — ${Calc.date(Calc.nextDueDate(l, out))}"), fontWeight = FontWeight.SemiBold)
                if (Calc.isOverdue(l, out)) Banner(tx("This EMI is overdue", "यह किस्त बकाया है"), Icons.Outlined.Warning)
                if (l.note.isNotBlank()) Text(l.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (l.opening) Tag(tx("Loan from old records", "पुराने रिकॉर्ड का लोन"))
            }
        }
        item {
            SectionCard(tx("EMI schedule", "किस्त सूची")) {
                Calc.schedule(l).forEachIndexed { i, (d, p, intr) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (i < paidCount) "✅" else "${i + 1}.", Modifier.padding(end = 8.dp))
                        Text(Calc.shortDate(d), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        Text("${Calc.rupees(p)} + ${Calc.rupees(intr)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item { SectionLabel(tx("Repayments", "किस्तें")) }
        if (repayments.isEmpty()) item { Empty(tx("No repayments yet", "अभी कोई किस्त नहीं")) }
        items(repayments, key = { it.id }) { SectionCard(padding = 8.dp) { TxnRow(it, showMember = false) } }
    }
    if (pay) RepaymentDialog(l) { pay = false }
}

@Composable
fun RepaymentsScreen() {
    val txns = Session.txns
    val active = Session.loans.filter { it.status == "active" }
        .sortedWith(compareByDescending<Loan> { Calc.isOverdue(it, Calc.outstanding(it, txns)) }.thenBy { Calc.nextDueDate(it, Calc.outstanding(it, txns)) })
    var pay by remember { mutableStateOf<Loan?>(null) }
    Page(tx("Repayments", "किस्त वापसी"), tx("Tap a loan to record an EMI", "किस्त जोड़ने के लिए लोन दबाएं")) {
        if (active.isEmpty()) item { Empty(tx("No active loans", "कोई चालू लोन नहीं")) }
        items(active, key = { it.id }) { l ->
            val out = Calc.outstanding(l, txns)
            val overdue = Calc.isOverdue(l, out)
            SectionCard(padding = 12.dp) {
                ListRow(l.memberName,
                    tx("EMI ${Calc.rupees(Calc.nextEmi(l, out))} · due ${Calc.shortDate(Calc.nextDueDate(l, out))} · ${Calc.rupees(out)} left", "किस्त ${Calc.rupees(Calc.nextEmi(l, out))} · ${Calc.shortDate(Calc.nextDueDate(l, out))} तक · ${Calc.rupees(out)} बाकी"),
                    badge = if (overdue) tx("Overdue", "बकाया") else null, leading = { Avatar(l.memberName.take(1).uppercase()) }, onClick = { pay = l })
            }
        }
        item { SectionLabel(tx("Recent repayments", "हाल की किस्तें")) }
        val recent = Calc.live(txns).filter { it.type == TxType.REPAY }.take(20)
        if (recent.isEmpty()) item { Empty(tx("No repayments yet", "अभी कोई किस्त नहीं")) }
        items(recent, key = { "r" + it.id }) { SectionCard(padding = 8.dp) { TxnRow(it) } }
    }
    pay?.let { RepaymentDialog(it) { pay = null } }
}

@Composable
private fun RepaymentDialog(l: Loan, onDismiss: () -> Unit) {
    val out = Calc.outstanding(l, Session.txns)
    var amount by remember { mutableStateOf(Calc.num(Calc.nextEmi(l, out))) }
    val split = Calc.split(l, out, amount.money() ?: 0.0)
    var principal by remember { mutableStateOf("") }
    var interest by remember { mutableStateOf("") }
    var manual by remember { mutableStateOf(false) }
    var date by remember { mutableStateOf(System.currentTimeMillis()) }
    val back = canBack()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("EMI from ${l.memberName}", "${l.memberName} की किस्त")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(tx("Loan left ${Calc.rupees(out)} · interest due ${Calc.rupees(Calc.interestDue(l, out))}", "बाकी लोन ${Calc.rupees(out)} · देय ब्याज ${Calc.rupees(Calc.interestDue(l, out))}"))
                Field(tx("Amount received (₹)", "प्राप्त राशि (₹)"), amount, { amount = it; manual = false }, number = true)
                if (!manual) {
                    Text(tx("Split: ${Calc.rupees(split.first)} loan + ${Calc.rupees(split.second)} interest", "बँटवारा: ${Calc.rupees(split.first)} लोन + ${Calc.rupees(split.second)} ब्याज"), fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { manual = true; principal = Calc.num(split.first); interest = Calc.num(split.second) }) { Text(tx("Change split", "बँटवारा बदलें")) }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(tx("Loan part", "लोन भाग"), principal, { principal = it }, number = true, modifier = Modifier.weight(1f))
                        Field(tx("Interest", "ब्याज"), interest, { interest = it }, number = true, modifier = Modifier.weight(1f))
                    }
                }
                DateRow(tx("Date received", "प्राप्त तारीख"), date, back, backdateNote()) { date = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = if (manual) principal.money() ?: 0.0 else split.first
                val i = if (manual) interest.money() ?: 0.0 else split.second
                if (p + i <= 0) { Session.error = tx("Enter amount", "राशि लिखें"); return@TextButton }
                if (p > out + 0.5) { Session.error = tx("Loan part is more than the loan left", "लोन भाग बाकी लोन से ज़्यादा है"); return@TextButton }
                Repo.addRepayment(l, p, i, if (back) date else null)
                onDismiss()
            }) { Text(tx("Save", "सेव करें")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx("Cancel", "रद्द करें")) } },
    )
}

// ---------------------------------------------------------------- cash book

@Composable
fun CashBookScreen() {
    val g = Session.group ?: return
    var filter by remember { mutableStateOf("all") }
    var add by remember { mutableStateOf("") }
    val txns = Session.txns
    val outTypes = listOf(TxType.LOAN, TxType.EXPENSE, TxType.WITHDRAW, TxType.PROFIT_PAYOUT)
    val noCash = listOf(TxType.OPEN_SAVING, TxType.OPEN_INTEREST, TxType.PROFIT_SHARE)
    val list = txns.filter {
        when (filter) {
            "in" -> it.type !in outTypes && it.type !in noCash
            "out" -> it.type in outTypes
            "deleted" -> it.deleted
            else -> true
        }
    }
    Page(tx("Cash Book", "कैश बुक"), tx("Cash in hand ${Calc.rupees(g.summary.cash)}", "हाथ में नकद ${Calc.rupees(g.summary.cash)}"), bottom = {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PrimaryButton(tx("+ Income", "+ आय"), modifier = Modifier.weight(1f)) { add = TxType.INCOME }
            SecondaryButton(tx("− Expense", "− खर्च"), modifier = Modifier.weight(1f)) { add = TxType.EXPENSE }
        }
    }) {
        item {
            SectionCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Money in", "आया"), Calc.rupees(Calc.live(txns).filter { it.type !in outTypes && it.type !in noCash }.sumOf { it.amount }), Modifier.weight(1f), MaterialTheme.colorScheme.primary)
                    Stat(tx("Money out", "गया"), Calc.rupees(Calc.live(txns).filter { it.type in outTypes }.sumOf { it.amount }), Modifier.weight(1f), LocalExtra.current.warnFg)
                }
                Segmented(listOf("all" to tx("All", "सभी"), "in" to tx("In", "आया"), "out" to tx("Out", "गया"), "deleted" to tx("Deleted", "हटाई")), filter) { filter = it }
            }
        }
        if (list.isEmpty()) item { Empty(tx("No entries", "कोई एंट्री नहीं")) }
        items(list.take(300), key = { it.id }) { SectionCard(padding = 8.dp) { TxnRow(it) } }
    }
    if (add.isNotBlank()) CashEntryDialog(add) { add = "" }
}

@Composable
private fun CashEntryDialog(type: String, onDismiss: () -> Unit) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(System.currentTimeMillis()) }
    val back = canBack()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (type == TxType.INCOME) tx("Group income", "समूह आय") else tx("Group expense", "समूह खर्च")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (type == TxType.INCOME) tx("e.g. small business profit, donation", "जैसे छोटे व्यापार का मुनाफ़ा, दान") else tx("e.g. register, travel, meeting tea", "जैसे रजिस्टर, यात्रा, बैठक की चाय"), style = MaterialTheme.typography.bodySmall)
                Field(tx("Amount (₹)", "राशि (₹)"), amount, { amount = it }, number = true)
                Field(tx("Details", "विवरण"), note, { note = it })
                DateRow(tx("Date", "तारीख"), date, back, backdateNote()) { date = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.money()
                if (a == null || a <= 0 || note.isBlank()) { Session.error = tx("Enter amount and details", "राशि और विवरण लिखें"); return@TextButton }
                Repo.addCashEntry(type, a, note.trim(), if (back) date else null)
                onDismiss()
            }) { Text(tx("Save", "सेव करें")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx("Cancel", "रद्द करें")) } },
    )
}

// ---------------------------------------------------------------- entry detail, edit & history

@Composable
fun TxnDetailScreen(id: String) {
    val t = Session.txns.firstOrNull { it.id == id } ?: run { Page(tx("Entry", "एंट्री")) { item { Empty(tx("Not found", "नहीं मिला")) } }; return }
    val g = Session.group ?: return
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    val canEdit = g.canEdit(Session.uid)
    val staff = Session.isStaff
    Page(Repo.typeLabel(t.type).replaceFirstChar { it.uppercase() }, t.memberName.ifBlank { tx("Group entry", "समूह एंट्री") }) {
        item {
            SectionCard {
                Text(Calc.rupees(t.amount), style = MaterialTheme.typography.headlineSmall, color = if (t.deleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                if (t.deleted) Tag(tx("Deleted", "हटाई गई"), LocalExtra.current.warnBg, LocalExtra.current.warnFg)
                if (t.type == TxType.REPAY) Text(tx("${Calc.rupees(t.principal)} loan + ${Calc.rupees(t.interest)} interest", "${Calc.rupees(t.principal)} लोन + ${Calc.rupees(t.interest)} ब्याज"))
                if (t.month.isNotBlank()) Text(tx("For ", "") + Calc.monthLabel(t.month, Prefs.hindi) + tx("", " के लिए"))
                if (t.note.isNotBlank()) Text(t.note, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Divider()
                Text(tx("Date in register: ${Calc.date(t.date)}", "रजिस्टर की तारीख: ${Calc.date(t.date)}"))
                Text(tx("Added to app: ${Calc.dateTime(t.createdAt)} by ${t.createdByName}", "ऐप में जोड़ी: ${Calc.dateTime(t.createdAt)} — ${t.createdByName}"))
                if (t.backdated) Tag(tx("Old / back-dated record", "पुराना / पिछली तारीख का रिकॉर्ड"))
            }
        }
        item {
            SectionCard(tx("History", "इतिहास")) {
                Text(tx("Old values are never erased.", "पुराने मान कभी नहीं मिटते।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                t.history.sortedBy { it.at }.forEach { h ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        val action = when (h.action) { "added" -> tx("Added", "जोड़ी"); "edited" -> tx("Edited", "बदली"); "deleted" -> tx("Deleted", "हटाई"); else -> h.action }
                        Text("$action · ${h.by} · ${Calc.dateTime(h.at)}", fontWeight = FontWeight.SemiBold)
                        if (h.detail.isNotBlank()) Text(h.detail, style = MaterialTheme.typography.bodySmall)
                        if (h.reason.isNotBlank()) Text(tx("Reason: ${h.reason}", "कारण: ${h.reason}"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        if (staff && !t.deleted) item {
            SectionCard {
                if (!canEdit) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Lock, null, tint = LocalExtra.current.warnFg)
                        Text(if (Session.isAdmin) tx("  Editing is OFF. The co-admin can allow it in ☰ → Permissions.", "  बदलाव बंद है। सह-एडमिन ☰ → अनुमतियाँ में चालू कर सकते हैं।")
                        else tx("  Editing is OFF. The admin can allow it in ☰ → Permissions.", "  बदलाव बंद है। एडमिन ☰ → अनुमतियाँ में चालू कर सकते हैं।"),
                            color = LocalExtra.current.warnFg, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(tx("Edit", "बदलें"), enabled = canEdit, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { edit = true }
                    SecondaryButton(tx("Delete", "हटाएं"), modifier = Modifier.weight(1f), color = LocalExtra.current.badFg) { if (canEdit) del = true else Session.error = tx("Editing is OFF", "बदलाव बंद है") }
                }
                Text(tx("The member gets full details of any change. Everyone else sees that an edit happened.", "सदस्य को बदलाव की पूरी जानकारी मिलती है। बाकी सब को बस पता चलता है कि बदलाव हुआ।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (edit) EditTxnDialog(t) { edit = false }
    if (del) {
        InputDialog(tx("Delete this entry?", "यह एंट्री हटाएं?"), tx("Reason (required)", "कारण (ज़रूरी)"), confirm = tx("Delete", "हटाएं"), multiLine = true, onDismiss = { del = false }) { reason ->
            Repo.deleteTxn(t, reason)?.let { Session.error = it }
        }
    }
}

@Composable
private fun EditTxnDialog(t: Txn, onDismiss: () -> Unit) {
    var amount by remember { mutableStateOf(Calc.num(t.amount)) }
    var principal by remember { mutableStateOf(Calc.num(t.principal)) }
    var interest by remember { mutableStateOf(Calc.num(t.interest)) }
    var note by remember { mutableStateOf(t.note) }
    var date by remember { mutableStateOf(t.date) }
    var reason by remember { mutableStateOf("") }
    val back = canBack()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Edit entry", "एंट्री बदलें")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (t.type == TxType.REPAY) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(tx("Loan part", "लोन भाग"), principal, { principal = it }, number = true, modifier = Modifier.weight(1f))
                        Field(tx("Interest", "ब्याज"), interest, { interest = it }, number = true, modifier = Modifier.weight(1f))
                    }
                } else Field(tx("Amount (₹)", "राशि (₹)"), amount, { amount = it }, number = true)
                Field(tx("Note", "नोट"), note, { note = it })
                DateRow(tx("Date", "तारीख"), date, back, tx("Changing the date needs back-date permission.", "तारीख बदलने के लिए पिछली तारीख की अनुमति चाहिए।")) { date = it }
                Field(tx("Reason for change (required)", "बदलाव का कारण (ज़रूरी)"), reason, { reason = it }, singleLine = false, minLines = 2)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = principal.money() ?: t.principal
                val i = interest.money() ?: t.interest
                val a = if (t.type == TxType.REPAY) p + i else amount.money() ?: t.amount
                val err = Repo.editTxn(t, a, p, i, note.trim(), if (back) date else null, reason.trim())
                if (err != null) Session.error = err else onDismiss()
            }) { Text(tx("Save change", "बदलाव सेव करें")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx("Cancel", "रद्द करें")) } },
    )
}
