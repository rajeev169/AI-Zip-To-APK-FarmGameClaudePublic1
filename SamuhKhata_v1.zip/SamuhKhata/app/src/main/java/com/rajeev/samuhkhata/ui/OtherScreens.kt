package com.rajeev.samuhkhata.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rajeev.samuhkhata.core.Calc
import com.rajeev.samuhkhata.core.Exporter
import com.rajeev.samuhkhata.core.Kind
import com.rajeev.samuhkhata.core.Prefs
import com.rajeev.samuhkhata.core.Repo
import com.rajeev.samuhkhata.core.Session
import com.rajeev.samuhkhata.core.tx

// ---------------------------------------------------------------- meetings

@Composable
fun MeetingsScreen() {
    val now = System.currentTimeMillis()
    val upcoming = Session.meetings.filter { it.date >= now }.sortedBy { it.date }
    val past = Session.meetings.filter { it.date < now }
    Page(tx("Meetings", "बैठकें"), bottom = if (Session.isStaff) ({ PrimaryButton(tx("New meeting", "नई बैठक")) { Nav.go(Screen.MeetingEdit()) } }) else null) {
        item { SectionLabel(tx("Upcoming", "आने वाली")) }
        if (upcoming.isEmpty()) item { Empty(tx("No meeting planned", "कोई बैठक तय नहीं")) }
        items(upcoming, key = { it.id }) { m ->
            SectionCard(padding = 12.dp) { ListRow(m.title, Calc.dateTime(m.date), onClick = { Nav.go(Screen.MeetingEdit(m.id)) }) }
        }
        item { SectionLabel(tx("Past meetings", "पिछली बैठकें")) }
        if (past.isEmpty()) item { Empty(tx("No past meetings", "कोई पिछली बैठक नहीं")) }
        items(past, key = { "p" + it.id }) { m ->
            SectionCard(padding = 12.dp) {
                ListRow(m.title, tx("${Calc.date(m.date)} · ${m.attendees.size} present", "${Calc.date(m.date)} · ${m.attendees.size} उपस्थित"), onClick = { Nav.go(Screen.MeetingEdit(m.id)) })
            }
        }
    }
}

@Composable
fun MeetingEditScreen(id: String) {
    val existing = Session.meetings.firstOrNull { it.id == id }
    val staff = Session.isStaff
    var title by remember { mutableStateOf(existing?.title ?: tx("Monthly meeting", "मासिक बैठक")) }
    var date by remember { mutableStateOf(existing?.date ?: (System.currentTimeMillis() + Calc.DAY)) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    val present = remember { mutableStateListOf<String>().apply { addAll(existing?.attendees ?: emptyList()) } }
    Page(if (existing == null) tx("New meeting", "नई बैठक") else existing.title, bottom = if (staff) ({
        PrimaryButton(tx("Save meeting", "बैठक सेव करें"), enabled = title.isNotBlank()) {
            Repo.saveMeeting(existing, date, title.trim(), notes.trim(), present.toList()); Nav.back()
        }
    }) else null) {
        item {
            SectionCard {
                if (staff) {
                    Field(tx("Title", "शीर्षक"), title, { title = it })
                    DateRow(tx("Date & time", "तारीख और समय"), date, true, "", withTime = true, allowFuture = true) { date = it }
                    Field(tx("Decisions / notes", "फ़ैसले / नोट"), notes, { notes = it }, singleLine = false, minLines = 4)
                } else {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    Text(Calc.dateTime(date))
                    Text(notes.ifBlank { tx("No notes yet", "अभी कोई नोट नहीं") }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { SectionLabel(tx("Attendance · ${present.size} present", "उपस्थिति · ${present.size} उपस्थित")) }
        items(Session.activeMembers, key = { it.uid }) { m ->
            SectionCard(padding = 4.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = m.uid in present, enabled = staff, onCheckedChange = { on -> if (on) present.add(m.uid) else present.remove(m.uid) })
                    Text(m.name, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

// ---------------------------------------------------------------- reports

@Composable
fun ReportsScreen() {
    val g = Session.group ?: return
    val ctx = LocalContext.current
    var month by remember { mutableStateOf(Calc.monthKey()) }
    var pick by remember { mutableStateOf(false) }
    Page(tx("Reports", "रिपोर्ट")) {
        item {
            SectionCard(tx("Monthly report (PDF)", "मासिक रिपोर्ट (PDF)")) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { month = Calc.shiftMonth(month, -1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null) }
                    Text(Calc.monthLabel(month, Prefs.hindi), Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = { if (month < Calc.monthKey()) month = Calc.shiftMonth(month, 1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null) }
                }
                Text(tx("Group totals, each member's saving status and all entries of the month. Share on WhatsApp.", "समूह का हिसाब, हर सदस्य की बचत स्थिति और महीने की सभी एंट्री। WhatsApp पर शेयर करें।"), style = MaterialTheme.typography.bodySmall)
                PrimaryButton(tx("Make & share PDF", "PDF बनाकर शेयर करें")) {
                    val f = Exporter.monthlyReport(ctx, g, month, Session.members, Session.txns, Session.loans)
                    Exporter.share(ctx, f, "application/pdf")
                }
            }
        }
        item {
            SectionCard(tx("Member passbook (PDF)", "सदस्य पासबुक (PDF)")) {
                PrimaryButton(tx("Choose member", "सदस्य चुनें")) { pick = true }
            }
        }
        item {
            SectionCard(tx("Export all records", "सारा हिसाब एक्सपोर्ट")) {
                Text(tx("A CSV file that opens in Excel or Google Sheets, with every entry, who added it and when.", "CSV फ़ाइल जो Excel या Google Sheets में खुलती है — हर एंट्री, किसने और कब जोड़ी।"), style = MaterialTheme.typography.bodySmall)
                SecondaryButton(tx("Export to Excel (CSV)", "Excel (CSV) में एक्सपोर्ट")) {
                    Exporter.share(ctx, Exporter.recordsCsv(ctx, g, Session.txns), "text/csv")
                }
            }
        }
        item {
            SectionCard(tx("Edit history", "बदलाव का इतिहास")) {
                SecondaryButton(tx("See all edits & deletions", "सभी बदलाव और हटाई गई एंट्री देखें")) { Nav.go(Screen.ActivityLog(Kind.EDIT)) }
            }
        }
    }
    if (pick) MemberPickerDialog(tx("Passbook of", "किसकी पासबुक"), Session.members, { pick = false }) { m ->
        Exporter.share(ctx, Exporter.passbook(ctx, g, m, Session.txns, Session.loans), "application/pdf")
    }
}

// ---------------------------------------------------------------- profit share

@Composable
fun ProfitShareScreen() {
    val g = Session.group ?: return
    val shares = Calc.profitShares(Session.activeMembers, Session.txns)
    val total = shares.sumOf { it.second }
    var addToSavings by remember { mutableStateOf(true) }
    var confirm by remember { mutableStateOf(false) }
    Page(tx("Year-end Profit Share", "साल का मुनाफ़ा बँटवारा"), tx("Since ${Calc.date(g.lastCloseAt)}", "${Calc.date(g.lastCloseAt)} से"),
        bottom = if (Session.isAdmin) ({ PrimaryButton(tx("Close year & share ${Calc.rupees(total)}", "साल बंद करें और ${Calc.rupees(total)} बाँटें"), enabled = total > 0) { confirm = true } }) else null) {
        item {
            SectionCard {
                Text(tx("Profit to share", "बाँटने का मुनाफ़ा"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(Calc.rupees(g.summary.profit), style = MaterialTheme.typography.headlineSmall)
                Text(tx("Interest + fines + group income − expenses, not yet shared. Each member gets a part by how much they have saved.",
                    "ब्याज + जुर्माना + समूह आय − खर्च, जो अभी बाँटा नहीं गया। हर सदस्य को उसकी बचत के हिसाब से हिस्सा मिलता है।"), style = MaterialTheme.typography.bodySmall)
                if (Session.isAdmin) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = addToSavings, onClick = { addToSavings = true }); Text(tx("Add to each member's savings", "हर सदस्य की बचत में जोड़ें"))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = !addToSavings, onClick = { addToSavings = false }); Text(tx("Pay out in cash", "नकद दें"))
                    }
                }
            }
        }
        item { SectionLabel(tx("Each member's share", "हर सदस्य का हिस्सा")) }
        items(shares, key = { it.first.uid }) { (m, amt) ->
            SectionCard(padding = 10.dp) {
                ListRow(m.name, tx("Saved ${Calc.rupees(Calc.memberSavings(m.uid, Session.txns))}", "बचत ${Calc.rupees(Calc.memberSavings(m.uid, Session.txns))}"),
                    value = Calc.rupees(amt), valueColor = MaterialTheme.colorScheme.primary, leading = { Avatar(m.initials) })
            }
        }
        item { Text(tx("Rounded down to whole rupees; the small remainder stays in the group.", "पूरे रुपये में; बचा हुआ थोड़ा पैसा समूह में रहता है।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
    if (confirm) ConfirmDialog(tx("Close the year?", "साल बंद करें?"),
        tx("${Calc.rupees(total)} will be ${if (addToSavings) "added to savings" else "paid in cash"}. Every member is notified.", "${Calc.rupees(total)} ${if (addToSavings) "बचत में जोड़ा जाएगा" else "नकद दिया जाएगा"}। हर सदस्य को सूचना जाएगी।"),
        tx("Close year", "साल बंद करें"), { confirm = false }) { Repo.shareProfit(shares, addToSavings); Nav.back() }
}

// ---------------------------------------------------------------- activity & notifications

@Composable
fun ActivityScreen(initial: String) {
    var filter by remember { mutableStateOf(initial) }
    var announce by remember { mutableStateOf(false) }
    val filters = listOf(
        "" to tx("All", "सभी"),
        "permrole" to tx("Permissions & roles", "अनुमतियाँ और भूमिकाएं"),
        Kind.EDIT to tx("Edits", "बदलाव"),
        Kind.MONEY to tx("Money", "पैसा"),
        Kind.MEMBER to tx("Members", "सदस्य"),
        Kind.RULE to tx("Rules", "नियम"),
        Kind.SETUP to tx("Old records", "पुराना हिसाब"),
        Kind.MEETING to tx("Meetings", "बैठकें"),
        Kind.ANNOUNCE to tx("Announcements", "सूचनाएं"),
    )
    val list = Session.activity.filter {
        when (filter) {
            "" -> true
            "permrole" -> it.kind == Kind.PERM || it.kind == Kind.ROLE
            else -> it.kind == filter
        }
    }
    Page(tx("Group Activity", "समूह गतिविधि"), tx("Saved forever · cannot be edited or deleted", "हमेशा के लिए सुरक्षित · बदला या हटाया नहीं जा सकता"),
        bottom = if (Session.isStaff) ({ SecondaryButton(tx("📢 Send announcement to all", "📢 सबको सूचना भेजें")) { announce = true } }) else null) {
        item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                filters.forEach { (k, label) ->
                    Chip(label, k == filter) { filter = k }
                }
            }
        }
        if (list.isEmpty()) item { Empty(tx("Nothing here yet", "अभी यहाँ कुछ नहीं")) }
        items(list, key = { it.id }) { a ->
            SectionCard(padding = 12.dp) {
                Text(if (Prefs.hindi && a.textHi.isNotBlank()) a.textHi else a.text, style = MaterialTheme.typography.bodyMedium)
                Text(Calc.dateTime(a.at), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (announce) InputDialog(tx("Announcement", "सूचना"), tx("Message to all members", "सभी सदस्यों के लिए संदेश"), confirm = tx("Send", "भेजें"), multiLine = true, onDismiss = { announce = false }) { Repo.announce(it) }
}

@Composable
fun InboxScreen() {
    LaunchedEffect(Unit) { Prefs.lastSeenInbox = System.currentTimeMillis() }
    val list = Session.inbox.filter { it.fromUid != Session.uid || it.toUid == Session.uid }
    Page(tx("Notifications", "सूचनाएं")) {
        if (list.isEmpty()) item { Empty(tx("No notifications yet", "अभी कोई सूचना नहीं")) }
        items(list, key = { it.id }) { m ->
            SectionCard(padding = 12.dp) {
                Row(verticalAlignment = Alignment.Top) {
                    if (m.kind == Kind.ANNOUNCE) Icon(Icons.Outlined.Campaign, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 8.dp))
                    Column {
                        Text(if (Prefs.hindi && m.titleHi.isNotBlank()) m.titleHi else m.title, fontWeight = FontWeight.SemiBold)
                        Text(if (Prefs.hindi && m.bodyHi.isNotBlank()) m.bodyHi else m.body, style = MaterialTheme.typography.bodyMedium)
                        Text(Calc.dateTime(m.at), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- passbook, loans, summary (member views)

@Composable
fun PassbookScreen(uid: String) {
    val g = Session.group ?: return
    val ctx = LocalContext.current
    if (!Session.isStaff && uid != Session.uid) return
    val m = Session.memberById(uid) ?: return
    val txns = Session.txns
    val mine = txns.filter { it.memberUid == uid }
    Page(tx("Passbook", "पासबुक"), m.name, bottom = {
        PrimaryButton(tx("Download / share PDF", "PDF डाउनलोड / शेयर")) {
            Exporter.share(ctx, Exporter.passbook(ctx, g, m, txns, Session.loans), "application/pdf")
        }
    }) {
        item {
            SectionCard {
                Text(tx("Total saved", "कुल बचत"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(Calc.rupees(Calc.memberSavings(uid, txns)), style = MaterialTheme.typography.headlineSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Loan due", "बाकी लोन"), Calc.rupees(Session.loans.filter { it.memberUid == uid && it.status == "active" }.sumOf { Calc.outstanding(it, txns) }), Modifier.weight(1f))
                    Stat(tx("Interest paid", "ब्याज भरा"), Calc.rupees(Calc.memberInterestPaid(uid, txns)), Modifier.weight(1f))
                    Stat(tx("Fines", "जुर्माना"), Calc.rupees(Calc.memberFines(uid, txns)), Modifier.weight(1f))
                }
            }
        }
        item { SectionLabel(tx("All entries · tap to see history", "सभी एंट्री · इतिहास देखने के लिए दबाएं")) }
        if (mine.isEmpty()) item { Empty(tx("No entries yet", "अभी कोई एंट्री नहीं")) }
        items(mine, key = { it.id }) { SectionCard(padding = 8.dp) { TxnRow(it, showMember = false) } }
    }
}

@Composable
fun MyLoansScreen() {
    val mine = Session.loans.filter { it.memberUid == Session.uid && it.status != "cancelled" }
    Page(tx("My Loans", "मेरे लोन")) {
        if (mine.isEmpty()) item { Empty(tx("You have no loans", "आपका कोई लोन नहीं")) }
        items(mine, key = { it.id }) { LoanCard(it) }
        item { Text(tx("To take a loan, talk to the admin. Repayments are recorded by the admin.", "लोन के लिए एडमिन से बात करें। किस्त एडमिन दर्ज करते हैं।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
fun GroupSummaryScreen() {
    val g = Session.group ?: return
    val s = g.summary
    Page(tx("Group Summary", "समूह सारांश"), g.name) {
        item {
            SectionCard {
                Text(tx("Total group fund", "कुल समूह फंड"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(Calc.rupees(s.fund), style = MaterialTheme.typography.headlineSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("Cash in hand", "हाथ में नकद"), Calc.rupees(s.cash), Modifier.weight(1f))
                    Stat(tx("Lent out", "लोन में"), Calc.rupees(s.lent), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(tx("All savings", "सभी की बचत"), Calc.rupees(s.savings), Modifier.weight(1f))
                    Stat(tx("Profit", "मुनाफ़ा"), Calc.rupees(s.profit), Modifier.weight(1f), MaterialTheme.colorScheme.primary)
                }
                Text(tx("${s.activeLoans} active loans · ${Session.activeMembers.size} members", "${s.activeLoans} चालू लोन · ${Session.activeMembers.size} सदस्य"))
                if (s.updatedAt > 0) Text(tx("Updated ${Calc.dateTime(s.updatedAt)}", "अपडेट ${Calc.dateTime(s.updatedAt)}"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            SectionCard(tx("Group rules", "समूह के नियम")) { RulesText() }
        }
    }
}

@Composable
fun RulesText() {
    val g = Session.group ?: return
    Text(tx("Monthly saving: ${Calc.rupees(g.monthlySaving)} by day ${g.dueDay}", "मासिक बचत: ${Calc.rupees(g.monthlySaving)}, ${g.dueDay} तारीख तक"))
    Text(tx("Loan interest: ${Calc.num(g.interestRate)}% per month (${if (g.interestMethod == "flat") "flat" else "reducing"})", "लोन ब्याज: ${Calc.num(g.interestRate)}% प्रति माह (${if (g.interestMethod == "flat") "फ्लैट" else "घटता हुआ"})"))
    Text(tx("Late fine: ${Calc.rupees(g.lateFine)}", "देर का जुर्माना: ${Calc.rupees(g.lateFine)}"))
    Text(tx("Admin: ${g.adminName}" + if (g.coAdminName.isNotBlank()) " · Co-admin: ${g.coAdminName}" else "", "एडमिन: ${g.adminName}" + if (g.coAdminName.isNotBlank()) " · सह-एडमिन: ${g.coAdminName}" else ""))
}
