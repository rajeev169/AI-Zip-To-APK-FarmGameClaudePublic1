package com.appforge.recorderlive.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.facebook.AccessToken
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.appforge.recorderlive.data.Prefs
import com.appforge.recorderlive.data.FacebookPageOption
import com.appforge.recorderlive.CrashReporter

@Composable
fun FacebookSetupScreen(
    onBack: () -> Unit,
    onLogin: (Boolean, (List<FacebookPageOption>, String?) -> Unit) -> Unit,
    onSelectPage: (FacebookPageOption) -> Boolean,
    onStartLive: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember(context) { Prefs(context) }
    var server by remember { mutableStateOf(prefs.facebookRtmpServer) }
    var key by remember { mutableStateOf(prefs.facebookRtmpKey) }
    var saved by remember { mutableStateOf(false) }
    var showGoLivePreview by remember { mutableStateOf(false) }
    var statusRefresh by remember { mutableIntStateOf(0) }
    var pages by remember { mutableStateOf<List<FacebookPageOption>>(emptyList()) }
    var selectedPageId by remember { mutableStateOf(prefs.facebookSelectedPageId) }
    var selectedPageName by remember { mutableStateOf(prefs.facebookSelectedPageName) }
    var pageSaveMessage by remember { mutableStateOf<String?>(null) }
    var pagesLoading by remember { mutableStateOf(false) }
    var pageError by remember { mutableStateOf<String?>(null) }
    var pageListLoaded by remember { mutableStateOf(false) }
    val lifecycleOwner = LocalLifecycleOwner.current
    fun refreshFacebookStatus() {
        val token = AccessToken.getCurrentAccessToken()
        if (token != null && !token.isExpired) {
            prefs.facebookAccountConnected = true
            prefs.facebookPageAccessGranted = token.permissions.contains("pages_show_list")
        }
        statusRefresh++
    }
    LaunchedEffect(Unit) { refreshFacebookStatus() }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refreshFacebookStatus()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val accountConnected = remember(statusRefresh) { prefs.facebookAccountConnected }
    val pagePermissionGranted = remember(statusRefresh) { prefs.facebookPageAccessGranted }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
        Text("Facebook connection", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Choose how you want to connect Facebook for streaming.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("1. Facebook account", fontWeight = FontWeight.SemiBold)
            if (accountConnected) Text("✓ Connected — this status is saved on this device.", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            Text("Sign in with Facebook. The basic profile permission authenticates your account; it does not itself enable Live publishing.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = { onLogin(false) { _, _ -> } }, modifier = Modifier.fillMaxWidth()) { Text(if (accountConnected) "Reconnect Facebook account" else "Continue with Facebook") }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("2. Go Live", fontWeight = FontWeight.SemiBold)
                AssistChip(onClick = { showGoLivePreview = true }, label = { Text("Preview") })
            }
            Text("Start a broadcast to the Facebook Page you choose below.", style = MaterialTheme.typography.bodySmall)
            val facebookReady = !prefs.facebookSelectedPageId.isNullOrBlank() &&
                prefs.facebookRtmpServer.trim().startsWith("rtmps://", ignoreCase = true) &&
                prefs.facebookRtmpKey.isNotBlank()
            Button(
                onClick = onStartLive,
                enabled = facebookReady,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Go Live on Facebook") }
            Text(
                "This sends your screen to the RTMPS stream key saved below. Create the broadcast in Facebook Live Producer first, then press Go Live there after the preview appears.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("3. Facebook Page", fontWeight = FontWeight.SemiBold)
            if (pagePermissionGranted) Text("✓ Page-list permission granted.", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            selectedPageName?.let { name ->
                Text("Selected Page: $name", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
            pageSaveMessage?.let { message ->
                Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
            Text("Connect to retrieve the Pages you manage, then select the Page ScreenRecorderLive should use.", style = MaterialTheme.typography.bodySmall)
            Button(
                onClick = {
                    pagesLoading = true
                    pageError = null
                    pageListLoaded = false
                    onLogin(true) { result, error ->
                        pages = result
                        pageError = error
                        pageListLoaded = true
                        pagesLoading = false
                        if (result.isNotEmpty()) selectedPageId = result.firstOrNull { it.id == prefs.facebookSelectedPageId }?.id ?: result.first().id
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !pagesLoading
            ) { Text(if (pagesLoading) "Loading Facebook Pages…" else if (pagePermissionGranted) "Refresh Facebook Pages" else "Connect and load Facebook Pages") }
            if (pageError != null) Text(pageError ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            if (pageListLoaded && pages.isEmpty() && pageError == null) Text("No Facebook Pages were returned for this account.", style = MaterialTheme.typography.bodySmall)
            pages.forEach { page ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    RadioButton(selected = selectedPageId == page.id, onClick = { selectedPageId = page.id })
                    Column(Modifier.weight(1f)) {
                        Text(page.name, fontWeight = FontWeight.Medium)
                        Text("Page ID: ${page.id}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (pages.isNotEmpty()) {
                Button(
                    onClick = {
                        val page = pages.firstOrNull { it.id == selectedPageId }
                        if (page != null) {
                            pageSaveMessage = null
                            if (onSelectPage(page)) {
                                selectedPageName = page.name
                                pageSaveMessage = "✓ ${page.name} saved successfully. You can continue to RTMPS setup."
                            } else {
                                pageSaveMessage = "Page could not be saved. Check the error message and try again."
                            }
                        }
                    },
                    enabled = pages.any { it.id == selectedPageId },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Save selected Page") }
            }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("4. RTMPS stream key", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(server, { server = it; saved = false }, label = { Text("RTMPS Server URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(key, { key = it; saved = false }, label = { Text("Stream Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = {
                runCatching {
                    prefs.facebookRtmpServer = server.trim()
                    prefs.facebookRtmpKey = key.trim()
                    saved = true
                }.onFailure { error ->
                    saved = false
                    CrashReporter.recordException(context, "Saving Facebook RTMPS settings failed", error)
                }
            }, modifier = Modifier.fillMaxWidth(), enabled = server.startsWith("rtmps://") && key.isNotBlank()) { Text("Save RTMPS details") }
            if (saved) Text("RTMPS details saved on this device. Keep the stream key private.", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        } }
        Text("The selected Page ID is saved on this device and its Page access token is encrypted with Android Keystore. Facebook Live publishing and multi-platform encoder output are separate features and are not active yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (showGoLivePreview) {
        AlertDialog(
            onDismissRequest = { showGoLivePreview = false },
            title = { Text("Facebook Live preview") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("The finished workflow will let you enter a stream title, review your broadcast settings, preview your screen, and then start the broadcast.")
                    Text("For now, this is a preview only. A Facebook Page has not yet been retrieved and selected inside the app, and the encoder is not connected to Facebook Live.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = { showGoLivePreview = false }) { Text("Got it") }
            }
        )
    }
}
