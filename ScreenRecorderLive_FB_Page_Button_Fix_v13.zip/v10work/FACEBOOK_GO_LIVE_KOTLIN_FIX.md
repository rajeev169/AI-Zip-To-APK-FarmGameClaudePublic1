# Facebook SDK compatibility review and Kotlin fix

Project dependency: `com.facebook.android:facebook-login:18.2.3`.

## AccessToken Kotlin API usage

The SDK exposes Java-style getters. Kotlin accesses these as properties:
- `AccessToken.getCurrentAccessToken()`
- `token.isExpired` (Boolean property; do not call it as a function)
- `token.permissions` (Set property; do not call `getPermissions()` as a function)

## Login callback flow

Updated `MainActivity` to use the AndroidX Activity Result overload:
`logInWithReadPermissions(this, facebookCallbackManager, permissions)`.
The legacy `onActivityResult` override and manual `CallbackManager.onActivityResult` forwarding were removed.

The Page permission flag is reset when a new Page-permission login starts, and refreshed from the active token's permission set when the Facebook setup screen resumes. This records permission only; it does not retrieve or select a Facebook Page and does not enable Facebook Live publishing.

## Verification status

Source-level review and ZIP integrity checks are performed for this update. A successful Gradle compile/APK build is only claimed if the build command completes successfully in an environment with the required Gradle distribution and dependencies.


## Diagnostic log update

- Uncaught app crashes are saved to the app's private files directory.
- Facebook Login SDK callback exceptions and exceptions while starting Facebook login are also recorded, even when the app handles the error instead of crashing.
- On the next app launch, the diagnostic report dialog appears with a Copy action. Close clears the saved report.
- The log includes timestamp, app version, device/Android version, event name, and exception stack trace. It does not intentionally record Facebook access tokens or stream keys.
- The report is stored locally on the device and is only shared when the user copies it.
