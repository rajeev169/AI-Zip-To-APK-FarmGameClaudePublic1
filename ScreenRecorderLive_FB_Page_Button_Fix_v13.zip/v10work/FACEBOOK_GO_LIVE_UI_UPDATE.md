# Facebook Go Live UI update

- Added a Facebook Go Live card between Facebook account and Facebook Page sections.
- Added a Preview action that explains the intended title/settings/preview/start flow.
- Kept the Go Live action disabled until in-app Page retrieval/selection and Facebook Live publishing/encoder integration exist.
- This is a UI preview only; it does not create or start a Facebook broadcast.

Build verification: not completed in this environment because Gradle 8.14.3 could not be downloaded from services.gradle.org (DNS/network unavailable).
