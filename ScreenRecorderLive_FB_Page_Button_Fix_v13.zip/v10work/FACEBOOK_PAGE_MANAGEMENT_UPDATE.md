# Facebook Page management update

This update adds a remove-and-replace workflow for the saved Facebook Page.

- The Facebook Page section displays **Remove saved Page** when a Page is selected.
- Removing requires confirmation.
- Confirming removal clears the selected Page ID/name and deletes the encrypted Page access token from Android Keystore-backed token storage.
- The Facebook account connection, Page-list permission, and RTMPS server/key are retained.
- The user can then load the Pages they manage, choose a different Page, and save it.
- The Go Live readiness check becomes false while no Page is selected and becomes eligible again after a replacement Page is saved.

The change does not alter the YouTube streaming implementation.

## Build verification

ZIP integrity and source-level checks were performed. Gradle compilation could not be run in this environment because the Gradle distribution download failed with `UnknownHostException: services.gradle.org`. Run the repository's GitHub Actions build before installing.
