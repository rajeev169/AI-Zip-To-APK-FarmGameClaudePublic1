# Facebook Page Picker Callback Fix

This update fixes the Facebook native-login result handoff used by the Add or change Facebook Page button.

Changes:
- Forwards Activity `onActivityResult` to the Facebook SDK `CallbackManager`, allowing LoginManager results to reach the registered callback.
- Wraps Page-list GraphRequest startup so synchronous failures are returned to the screen instead of leaving the button stuck.
- Shows a loading indicator and a clear error message while Pages are retrieved.
- Preserves existing selected Page, token vault, RTMPS settings, and YouTube code.

Build verification: Gradle compilation was attempted, but the environment could not resolve `services.gradle.org` (DNS/network failure). Compilation is therefore not verified. Run the GitHub Actions build before installing.
