# ScreenRecorderLive v10 — Facebook integration progress

Base: original ScreenRecorderLive v9 source. Existing YouTube classes and capture service were retained.

## Added in this archive
- Meta Facebook Android Login SDK dependency (`facebook-login:18.2.3`).
- Meta App ID and Client Token resources using values supplied by the project owner.
- Facebook SDK manifest metadata, FacebookActivity, CustomTabActivity and app-targeted callback package.
- Facebook entry point from the existing connect screen.
- Facebook setup screen with distinct account-login, Page-login, and manual RTMPS configuration sections.
- Facebook LoginManager flow requesting `public_profile`; Page path additionally requests `pages_show_list`.
- Local persistence fields for RTMPS server and key.
- App version code/name advanced to 10 / 1.5.0.

## Not yet complete — do not mistake the setup UI for a finished broadcaster
- Facebook Page discovery/selection via Graph API is not yet implemented.
- `pages_show_list` and any publishing permissions may require Meta App Review / Advanced Access and business verification depending on the use case.
- Facebook Live publishing to a personal profile is not generally available through the standard Live API. Do not promise this destination unless Meta explicitly grants the relevant capability.
- Saved Facebook RTMPS URL/key are not yet connected to a second encoder output. Existing capture service starts one `GenericStream` for the current YouTube route. Multi-destination output and simultaneous YouTube/Facebook streaming remain to be implemented.
- Facebook login success now saves local account-login and `pages_show_list` permission status in app preferences; the setup screen restores and displays those statuses after reopening. The Facebook SDK retains its own access token.
- The app still does not retrieve a Page list, select/store a Page ID, or show a real Page name. The saved Page status means only that the Page-list permission was granted; it is not proof of a selected Page or Live publishing access.

## Meta dashboard configuration
- Android package: `com.appforge.recorderlive`
- Default Activity: `com.appforge.recorderlive.MainActivity`
- Add the development and release key hashes matching the actual APK signing keys.
- Keep App Secret off-device and out of the APK. Client Token is not the App Secret.
- Test in Development mode with app roles before App Review / public release.

## Build status
The build was attempted with `./gradlew :app:assembleDebug`, but the environment could not resolve `services.gradle.org` (network DNS unavailable), so no APK build verification was possible. Build and test in your GitHub Actions environment before installing.

## Facebook Page retrieval implementation update

The Android app now requests `pages_show_list` and `pages_read_engagement` during the Page connection flow, then calls Graph API `GET /me/accounts?fields=id,name,access_token` using the Facebook SDK user access token. It displays the returned Page names and IDs for selection. The selected Page ID/name are saved in app preferences; the Page access token is encrypted with an AES-GCM key held by Android Keystore. Tokens are not written to logs or shown in the UI.

This completes Page retrieval and local Page selection only. It does not yet create a Facebook Live Video, publish a broadcast, or add a second RTMPS encoder output. The Go Live button remains intentionally disabled until that separate streaming work is implemented and tested.

Build verification note for this archive: local Gradle compilation could not run in the editing environment because the Gradle 8.14.3 distribution download failed with `UnknownHostException: services.gradle.org`. Run the project's GitHub Actions build before installing this archive; do not treat it as a verified APK build.
