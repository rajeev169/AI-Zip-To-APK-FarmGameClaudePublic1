# Screen Recorder + YouTube Live (v1)

Android app (Kotlin, Jetpack Compose, Material 3) built from the approved mockups:

- **Home** – big record button, Go live card, Bubble / Face-cam / Mic quick toggles, recent items, settings gear
- **Recordings** – All / Recordings / Live replays / Screenshots, with Edit, Rename, Share, Delete
- **3 ways to connect YouTube:** Continue with Google (Gmail's own channel) · Choose a brand channel (Google sign-in page, any channel) · Use a stream key (no sign-in)
- **Live flow** – Connect YouTube → Google account picker → (help screen if the channel can't stream yet) → Go live setup → 3-2-1 countdown → Live
- **Always show bubble** (Settings): bubble waits on screen; tap it → Record, or Go live (uses the last Go live settings) from inside a game; Home's Start recording still works
- **Bubble colour** (8 colours) and **Auto-hide bubble** in Settings
- **Floating bubble** (light red, video camera) over games: pause, stop, mic, face-cam, screenshot + LIVE/REC timer and viewer count
- **Face-cam** round camera bubble (shows in the recording / stream)
- Recordings save to `Movies/ScreenRecorder`, screenshots to `Pictures/ScreenRecorder` (visible in Gallery)
- Live replays stay on the YouTube channel and are listed in the app

Package name: `com.appforge.recorderlive` · minSdk 29 (Android 10, needed for game sound) · targetSdk 36

**App name:** change the one line in `app/src/main/res/values/strings.xml` (`app_name`).
If you rename the folder name `ScreenRecorder`, edit `MediaRepository.FOLDER`.

---

## 1. Build

Same as your other projects: zip this folder and push it to your ZIP-to-APK GitHub repo.
Libraries come from Google Maven, Maven Central and **JitPack** (already set in `settings.gradle.kts`).

> **Important for Google sign-in:** build a **release APK signed with your own keystore**.
> A debug APK built on GitHub Actions gets a new random debug key each run, so its SHA-1
> never matches Google Cloud and sign-in fails with error 10.

Get the SHA-1 of the keystore your pipeline signs with:

```
keytool -list -v -keystore your.keystore -alias YOUR_ALIAS
```

---

## 2. One-time Google Cloud setup (for the Live feature)

Recording works without any of this. Only "Go live" needs it.

1. Open https://console.cloud.google.com → create a project (or reuse one).
2. **APIs & Services → Library →** enable **YouTube Data API v3**.
3. **OAuth consent screen** (Google Auth Platform):
   - User type **External**, app name, support email, developer email.
   - **Data access → Add scope:** `https://www.googleapis.com/auth/youtube`
   - **Audience → Test users:** add your Gmail and your testers' Gmails (up to 100) while in Testing.
4. **Credentials → Create credentials → OAuth client ID → Android**
   - Package name: `com.appforge.recorderlive`
   - SHA-1: from step 1 above.
   - After you upload to Play Console, also add a second Android client with the
     **App signing key SHA-1** from Play Console → Setup → App signing.

No `google-services.json` or Firebase is needed for this app.

**For "Choose a brand channel" (web sign-in):** open Clients → your Android client →
**Advanced settings** → tick **Enable custom URI scheme** → Save.
The app's web sign-in uses this client ID (in `youtube/YouTubeAuth.kt`, `WEB_CLIENT_ID`)
and the redirect `com.appforge.recorderlive:/oauth2redirect`.
While the consent screen is in **Testing**, Google expires web sign-ins after 7 days
(users just tap Switch → Choose a brand channel again). After verification this goes away.

5. On each YouTube channel that will stream: open https://studio.youtube.com once and turn on
   live streaming (phone verification, can take up to 24 hours). If it isn't on, the app shows
   the "Live streaming isn't on yet" screen.

### Before public release
The YouTube permission is a "sensitive scope", so Google must **verify** the OAuth app before
anyone outside your test users can sign in. You need: a privacy policy URL, an app home page,
your app's domain, and a short YouTube video showing the sign-in and Go live flow.

---

## 3. Play Console declarations

- **Foreground service types:** media projection (screen capture), microphone, camera, special use
  — explain: "records / live streams the screen while the user plays, with optional mic and face-cam".
  — special use: "optional floating bubble the user turns on in Settings; it stays over other apps so the
  user can start a screen recording from inside a game".
- **Display over other apps** is used only for the floating bubble and face-cam.
- Data safety: Google account (sign-in) used only to create live streams on the user's channel.

---

## 4. Defaults (from the mockups — change in `data/Prefs.kt`)

| Setting | Default |
|---|---|
| Recording | 1080p, 60 fps (dropdown 30/60/90/120 — unsupported greyed out), mic on, game sound on, bubble on, face-cam off |
| Live | Public, 720p, 30 fps (or 60), Low latency, landscape, game sound on, mic on, face-cam on, bubble on |
| Live title | "Playing live from my phone" |
| Settings → Always show bubble | Off |
| Settings → Bubble colour | Light red (8 colours to choose) |
| Settings → Menu colour | Light (or Dark) |
| Settings → Auto-hide bubble | Off |

## 5. Good to know

- Android asks "Start recording or casting?" every time — this is a system rule.
- Netflix, Hotstar, banking apps and some games block capture (black screen) or block their sound.
- Game sound needs microphone permission (Android rule for playback capture).
- During live, **Pause** shows a "Be right back" card to viewers and mutes sound.
- Viewer count refreshes every 30 seconds (uses very little of the free daily API quota).
- Main libraries: RootEncoder 2.7.0 (screen capture, encoding, RTMP), CameraX, Google Play services auth.
