# Minify is off by default. If you turn it on, keep the streaming library:
-keep class com.pedro.** { *; }
-dontwarn com.pedro.**
-dontwarn io.ktor.**
