package com.appforge.recorderlive

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Saves the error of any crash to a file, so the next time the app opens it can show
 * "The app closed unexpectedly" with the technical details and a Copy button.
 */
object CrashReporter {
    private const val FILE = "last_crash.txt"

    fun install(context: Context) {
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching { append(appContext, report(appContext, "UNCAUGHT CRASH", thread.name, error)) }
            previous?.uncaughtException(thread, error)
        }
    }

    /** Records an error handled by the app (for example, a Facebook SDK callback failure). */
    fun recordException(context: Context, event: String, error: Throwable) {
        runCatching {
            val thread = Thread.currentThread()
            append(context.applicationContext, report(context.applicationContext, event, thread.name, error))
        }
    }

    /** Records a diagnostic event even when the SDK provides no Throwable. */
    fun recordMessage(context: Context, event: String, message: String) {
        runCatching {
            val appContext = context.applicationContext
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val version = runCatching {
                val pi = appContext.packageManager.getPackageInfo(appContext.packageName, 0)
                "${pi.versionName} (${pi.longVersionCode})"
            }.getOrDefault("?")
            val entry = buildString {
                appendLine("Time: $time")
                appendLine("App: $version")
                appendLine("Phone: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                appendLine("Event: $event")
                appendLine(message.take(4000))
                appendLine()
            }
            append(appContext, entry)
        }
    }

    @Synchronized
    private fun append(context: Context, entry: String) {
        val file = File(context.filesDir, FILE)
        val existing = runCatching { file.readText() }.getOrDefault("")
        // Keep the most recent diagnostic history bounded so it cannot grow indefinitely.
        file.writeText((existing + entry + "\n").takeLast(24000))
    }

    private fun report(context: Context, event: String, threadName: String, error: Throwable): String {
        val sw = StringWriter()
        error.printStackTrace(PrintWriter(sw))
        val version = runCatching {
            val pi = context.packageManager.getPackageInfo(context.packageName, 0)
            "${pi.versionName} (${pi.longVersionCode})"
        }.getOrDefault("?")
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        return buildString {
            appendLine("Time: $time")
            appendLine("App: $version")
            appendLine("Phone: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("Event: $event")
            appendLine("Thread: $threadName")
            appendLine()
            append(sw.toString().take(12000))
        }
    }

    /** The saved crash report, or null if the app didn't crash last time. */
    fun lastCrash(context: Context): String? =
        File(context.filesDir, FILE).takeIf { it.exists() }?.readText()?.takeIf { it.isNotBlank() }

    fun clear(context: Context) {
        File(context.filesDir, FILE).delete()
    }
}
