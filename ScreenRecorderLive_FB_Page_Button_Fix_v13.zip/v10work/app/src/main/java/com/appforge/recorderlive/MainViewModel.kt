package com.appforge.recorderlive

import android.app.Application
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.appforge.recorderlive.data.MediaItem
import com.appforge.recorderlive.data.MediaRepository
import com.appforge.recorderlive.data.Prefs
import com.appforge.recorderlive.service.SessionStore
import com.appforge.recorderlive.youtube.AuthMode
import com.appforge.recorderlive.youtube.SignInAgainException
import com.appforge.recorderlive.youtube.YouTubeAccount
import com.appforge.recorderlive.youtube.YouTubeAuth
import com.appforge.recorderlive.youtube.YouTubeApi
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.common.api.ApiException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

data class ChannelUi(val title: String, val email: String, val avatar: ImageBitmap?)

sealed interface ChannelResult {
    data object Ok : ChannelResult
    /** Signed in, but this Google account has no channel of its own (channels are brand channels). */
    data object NoChannel : ChannelResult
    data class NeedsConsent(val intent: Intent) : ChannelResult
    data class Failed(val message: String) : ChannelResult
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val repo = MediaRepository(app)

    private val _media = MutableStateFlow<List<MediaItem>>(emptyList())
    val media: StateFlow<List<MediaItem>> = _media

    private val _channel = MutableStateFlow<ChannelUi?>(null)
    val channel: StateFlow<ChannelUi?> = _channel

    /** How the app is connected to YouTube (none / Google / brand channel / stream key). */
    private val _authMode = MutableStateFlow(YouTubeAuth.mode(app))
    val authMode: StateFlow<AuthMode> = _authMode
    private val _signedIn = MutableStateFlow(_authMode.value != AuthMode.NONE)
    /** True when any YouTube connection is set up. */
    val signedIn: StateFlow<Boolean> = _signedIn

    /** Error shown on the channel card (with a Retry button), null when fine. */
    private val _channelError = MutableStateFlow<String?>(null)
    val channelError: StateFlow<String?> = _channelError

    fun refreshAuth() {
        _authMode.value = YouTubeAuth.mode(getApplication())
        _signedIn.value = _authMode.value != AuthMode.NONE
        if (_authMode.value == AuthMode.NONE || _authMode.value == AuthMode.KEY) _channel.value = null
    }

    private val thumbs = LruCache<String, ImageBitmap>(60)

    init {
        viewModelScope.launch { SessionStore.mediaVersion.collect { refreshMedia() } }
        if (_authMode.value == AuthMode.NATIVE || _authMode.value == AuthMode.WEB) viewModelScope.launch { loadChannel() }
    }

    fun refreshMedia() {
        viewModelScope.launch { _media.value = repo.loadAll(prefs) }
    }

    suspend fun thumbnail(uri: Uri): ImageBitmap? {
        thumbs.get(uri.toString())?.let { return it }
        val bmp = repo.thumbnail(uri)?.asImageBitmap() ?: return null
        thumbs.put(uri.toString(), bmp)
        return bmp
    }

    /** Handles the Android Google account picker result. */
    fun accountFromSignIn(data: Intent?): Result<Unit> = try {
        YouTubeAccount.accountFromResult(data)
        if (YouTubeAccount.isSignedIn(getApplication())) {
            modeBeforeNative = prefs.authMode
            prefs.authMode = AuthMode.NATIVE.key
            refreshAuth()
            Result.success(Unit)
        } else Result.failure(IllegalStateException("YouTube permission was not allowed"))
    } catch (e: ApiException) {
        Result.failure(e)
    }

    fun saveStreamKey(key: String) {
        viewModelScope.launch {
            if (YouTubeAuth.mode(getApplication()) == AuthMode.NATIVE) YouTubeAccount.signOut(getApplication())
            prefs.webAuthState = null
            prefs.streamKey = key.trim()
            prefs.authMode = AuthMode.KEY.key
            _channelError.value = null
            refreshAuth()
        }
    }

    suspend fun loadChannel(): ChannelResult {
        val ctx = getApplication<Application>()
        if (YouTubeAuth.mode(ctx) == AuthMode.KEY || YouTubeAuth.mode(ctx) == AuthMode.NONE) return ChannelResult.Ok
        _channelError.value = null
        val result = try {
            val token = YouTubeAuth.token(ctx)
            val ch = YouTubeApi.myChannel(token)
            val avatar = ch.avatarUrl?.let { url ->
                withContext(Dispatchers.IO) {
                    runCatching { URL(url).openStream().use { BitmapFactory.decodeStream(it) }?.asImageBitmap() }.getOrNull()
                }
            }
            val sub = if (YouTubeAuth.mode(ctx) == AuthMode.WEB) "Connected with Google sign-in page"
                      else YouTubeAccount.account(ctx)?.email.orEmpty()
            _channel.value = ChannelUi(ch.title, sub, avatar)
            ChannelResult.Ok
        } catch (e: UserRecoverableAuthException) {
            val i = e.intent
            if (i != null) ChannelResult.NeedsConsent(i) else ChannelResult.Failed("Please allow YouTube access")
        } catch (e: YouTubeApi.NoChannelException) {
            ChannelResult.NoChannel
        } catch (e: SignInAgainException) {
            ChannelResult.Failed("Please connect your YouTube channel again (tap Switch)")
        } catch (e: java.io.IOException) {
            ChannelResult.Failed("No internet connection")
        } catch (e: Exception) {
            ChannelResult.Failed(e.message ?: "Could not reach YouTube")
        }
        _channelError.value = when (result) {
            is ChannelResult.Failed -> result.message
            ChannelResult.NoChannel -> "This account has no channel of its own. Tap Switch → Choose a brand channel."
            is ChannelResult.NeedsConsent -> "YouTube permission needed. Tap Retry."
            ChannelResult.Ok -> null
        }
        return result
    }

    /** Makes sure a token can be fetched before starting a live (asks for consent if needed). */
    suspend fun checkToken(): ChannelResult = try {
        if (YouTubeAuth.mode(getApplication()) != AuthMode.KEY) YouTubeAuth.token(getApplication())
        ChannelResult.Ok
    } catch (e: UserRecoverableAuthException) {
        e.intent?.let { ChannelResult.NeedsConsent(it) } ?: ChannelResult.Failed("Please allow YouTube access")
    } catch (e: Exception) {
        ChannelResult.Failed(e.message ?: "Not signed in")
    }

    /** Sign out / remove stream key. */
    fun signOut() {
        viewModelScope.launch {
            YouTubeAuth.disconnect(getApplication())
            _channel.value = null
            _channelError.value = null
            refreshAuth()
        }
    }

    private var modeBeforeNative = AuthMode.NONE.key

    /** Native sign-in found no channel: undo it and keep any earlier connection (brand channel / key). */
    suspend fun undoNativeSignIn() {
        YouTubeAccount.signOut(getApplication())
        prefs.authMode = if (modeBeforeNative == AuthMode.NATIVE.key) AuthMode.NONE.key else modeBeforeNative
        _channel.value = null
        refreshAuth()
        if (_authMode.value == AuthMode.WEB) loadChannel()
    }

    fun rename(item: MediaItem, name: String, done: (Boolean) -> Unit) {
        viewModelScope.launch { val ok = repo.rename(item, name); refreshMedia(); done(ok) }
    }

    fun delete(item: MediaItem, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = if (item.replay != null) { prefs.removeReplay(item.replay.id); true } else repo.delete(item)
            refreshMedia(); done(ok)
        }
    }
}
