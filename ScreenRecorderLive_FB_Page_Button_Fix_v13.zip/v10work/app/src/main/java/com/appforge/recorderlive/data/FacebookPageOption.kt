package com.appforge.recorderlive.data

/** A Page returned by Meta's /me/accounts endpoint. The token is kept only in memory until saved encrypted. */
data class FacebookPageOption(
    val id: String,
    val name: String,
    val accessToken: String
)
