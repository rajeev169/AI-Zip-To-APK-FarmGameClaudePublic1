package com.appforge.recorderlive.data

import android.content.Context
import android.hardware.display.DisplayManager
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import android.view.Display
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** One frame-rate choice and whether this phone can do it. */
data class FpsOption(val fps: Int, val supported: Boolean, val reason: String?)

/**
 * Checks which frame rates this phone can really record / stream:
 * the screen must refresh at least that fast, and the H.264 encoder must handle it at that size.
 */
object FpsSupport {

    /** Highest refresh rate the screen supports, e.g. 60, 90, 120. */
    fun screenMaxHz(context: Context): Int {
        val display: Display? = context.getSystemService(DisplayManager::class.java)
            ?.getDisplay(Display.DEFAULT_DISPLAY)
        val modes = display?.supportedModes
        val hz = modes?.maxOfOrNull { it.refreshRate } ?: display?.refreshRate ?: 60f
        return hz.roundToInt()
    }

    /** Output size used for recordings (keeps the phone's shape, short side = chosen height). */
    fun recordingSize(context: Context, height: Int): Pair<Int, Int> {
        val (w, h) = screenSize(context)
        val screenLong = max(w, h)
        val screenShort = min(w, h)
        val short = even(min(height, screenShort))
        val long = even((short.toFloat() * screenLong / screenShort).roundToInt())
        return long to short
    }

    /** Output size used for live (16:9). */
    fun liveSize(height: Int): Pair<Int, Int> = even((height * 16f / 9f).roundToInt()) to height

    /** Does any H.264 encoder on this phone handle this size at this fps? */
    fun encoderSupports(width: Int, height: Int, fps: Int): Boolean = runCatching {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
            info.isEncoder && info.supportedTypes.any { it.equals(MediaFormat.MIMETYPE_VIDEO_AVC, true) } &&
                runCatching {
                    val caps: MediaCodecInfo.VideoCapabilities =
                        info.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC).videoCapabilities
                    caps.areSizeAndRateSupported(width, height, fps.toDouble()) ||
                        caps.areSizeAndRateSupported(height, width, fps.toDouble())
                }.getOrDefault(false)
        }
    }.getOrDefault(fps <= 30)

    /** Frame-rate options with supported / greyed-out reason. 30 fps is always allowed. */
    fun options(context: Context, choices: List<Int>, size: Pair<Int, Int>, label: String): List<FpsOption> {
        val maxHz = screenMaxHz(context)
        return choices.map { fps ->
            when {
                fps <= 30 -> FpsOption(fps, true, null)
                fps > maxHz + 1 -> FpsOption(fps, false, "Not supported on this phone (screen max $maxHz Hz)")
                !encoderSupports(size.first, size.second, fps) ->
                    FpsOption(fps, false, "Not supported by this phone's video encoder at $label")
                else -> FpsOption(fps, true, null)
            }
        }
    }

    fun recordingOptions(context: Context, height: Int): List<FpsOption> =
        options(context, listOf(30, 60, 90, 120), recordingSize(context, height), "${height}p")

    fun liveOptions(context: Context, height: Int): List<FpsOption> =
        options(context, listOf(30, 60), liveSize(height), "${height}p")

    /** The wanted fps if supported, otherwise the highest supported one below it. */
    fun bestOf(options: List<FpsOption>, wanted: Int): Int =
        options.filter { it.supported && it.fps <= wanted }.maxOfOrNull { it.fps } ?: 30

    @Suppress("DEPRECATION")
    private fun screenSize(context: Context): Pair<Int, Int> {
        val wm = context.getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = android.util.DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun even(v: Int) = if (v % 2 == 0) v else v + 1
}
