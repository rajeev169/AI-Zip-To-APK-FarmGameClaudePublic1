package com.appforge.recorderlive.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

enum class MediaKind { VIDEO, SCREENSHOT, REPLAY }

data class MediaItem(
    val key: String,
    val kind: MediaKind,
    val uri: Uri?,
    val name: String,
    val dateMs: Long,
    val durationMs: Long,
    val sizeBytes: Long,
    val height: Int,
    val replay: Replay? = null,
)

/** Saves recordings to Movies/<folder> and screenshots to Pictures/<folder> so they show in Gallery. */
class MediaRepository(private val context: Context) {

    companion object {
        const val FOLDER = "ScreenRecorder"
        private val VIDEO_PATH = "Movies/$FOLDER/"
        private val IMAGE_PATH = "Pictures/$FOLDER/"
    }

    private val resolver get() = context.contentResolver

    suspend fun saveVideo(file: File, displayName: String): Uri? = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "$displayName.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, VIDEO_PATH)
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext null
        try {
            resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            file.delete()
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    suspend fun saveScreenshot(bitmap: Bitmap, displayName: String): Uri? = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$displayName.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, IMAGE_PATH)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext null
        try {
            resolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    suspend fun loadAll(prefs: Prefs): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()
        runCatching { items += queryVideos() }
        runCatching { items += queryImages() }
        items += prefs.replays().map {
            MediaItem("replay_${it.id}", MediaKind.REPLAY, null, it.title, it.dateMs, it.durationSec * 1000, 0, 0, it)
        }
        items.sortedByDescending { it.dateMs }
    }

    private fun queryVideos(): List<MediaItem> {
        val out = mutableListOf<MediaItem>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.WIDTH
        )
        resolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj,
            "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?", arrayOf("$VIDEO_PATH%"),
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val w = c.getInt(6)
                val h = c.getInt(5)
                out += MediaItem(
                    "v_$id", MediaKind.VIDEO,
                    ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                    c.getString(1).substringBeforeLast('.'), c.getLong(2) * 1000, c.getLong(3), c.getLong(4),
                    minOf(w, h)
                )
            }
        }
        return out
    }

    private fun queryImages(): List<MediaItem> {
        val out = mutableListOf<MediaItem>()
        val proj = arrayOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.SIZE
        )
        resolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj,
            "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?", arrayOf("$IMAGE_PATH%"),
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out += MediaItem(
                    "i_$id", MediaKind.SCREENSHOT,
                    ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                    c.getString(1).substringBeforeLast('.'), c.getLong(2) * 1000, 0, c.getLong(3), 0
                )
            }
        }
        return out
    }

    suspend fun thumbnail(uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        runCatching { resolver.loadThumbnail(uri, Size(320, 180), null) }.getOrNull()
    }

    /** Returns false if Android did not allow it (e.g. file made before a reinstall). */
    suspend fun rename(item: MediaItem, newName: String): Boolean = withContext(Dispatchers.IO) {
        val uri = item.uri ?: return@withContext false
        val ext = if (item.kind == MediaKind.VIDEO) ".mp4" else ".png"
        runCatching {
            resolver.update(uri, ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, newName.trim() + ext)
            }, null, null) > 0
        }.getOrDefault(false)
    }

    suspend fun delete(item: MediaItem): Boolean = withContext(Dispatchers.IO) {
        val uri = item.uri ?: return@withContext false
        runCatching { resolver.delete(uri, null, null) > 0 }.getOrDefault(false)
    }
}
