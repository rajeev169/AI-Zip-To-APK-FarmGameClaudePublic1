package com.appforge.recorderlive.service

import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CenterFocusWeak
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.delay
import com.appforge.recorderlive.data.Prefs
import com.appforge.recorderlive.ui.components.BubbleIcon
import com.appforge.recorderlive.ui.components.formatDuration
import com.appforge.recorderlive.ui.theme.AppTheme
import com.appforge.recorderlive.ui.theme.Brand

/** The light red floating bubble that stays on top of games while recording or live. */
class BubbleOverlay(private val service: CaptureService) {
    private val wm = service.getSystemService(WindowManager::class.java)
    private var view: ComposeView? = null
    private val density = service.resources.displayMetrics.density
    private val autoHide = Prefs(service).bubbleAutoHide

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = (service.resources.displayMetrics.widthPixels - 84 * density).toInt()
        y = (220 * density).toInt()
    }

    fun show() {
        if (view != null) return
        val v = ComposeView(service).apply {
            setViewTreeLifecycleOwner(service)
            setViewTreeSavedStateRegistryOwner(service)
            setContent { AppTheme { BubbleContent(onDrag = ::moveBy) } }
        }
        runCatching { wm.addView(v, params) }.onSuccess { view = v }
    }

    fun hide() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }

    private fun moveBy(dx: Float, dy: Float) {
        val v = view ?: return
        val dm = service.resources.displayMetrics
        params.x = (params.x + dx).toInt().coerceIn(0, dm.widthPixels - v.width.coerceAtLeast(1))
        params.y = (params.y + dy).toInt().coerceIn(0, dm.heightPixels - v.height.coerceAtLeast(1))
        runCatching { wm.updateViewLayout(v, params) }
    }

    @Composable
    private fun BubbleContent(onDrag: (Float, Float) -> Unit) {
        val s by SessionStore.state.collectAsState()
        val colorArgb by SessionStore.bubbleColor.collectAsState()
        val bubbleColor = Color(colorArgb)
        // Menu panel colour chosen in Settings (Light / Dark)
        val menuDark by SessionStore.bubbleMenuDark.collectAsState()
        val menuBg = if (menuDark) Color(0xFF2A2A33) else Color(0xFFFBF8FF)
        val menuIcon = if (menuDark) Color.White else Color(0xFF46464F)
        val chipBg = if (menuDark) Color(0xFF45464F) else Color(0xFFDEE0FF)
        val chipFg = if (menuDark) Color.White else Color(0xFF00105C)
        var expanded by remember { mutableStateOf(false) }
        val ctx = service
        val waiting = s.mode == Mode.NONE // "Always show bubble" is on and nothing is recording

        // Auto-hide: every touch bumps `tick`; 3 s later the menu closes and the bubble shrinks.
        var tick by remember { mutableIntStateOf(0) }
        var idle by remember { mutableStateOf(false) }
        val touch = { tick++; idle = false }
        LaunchedEffect(tick, expanded) {
            if (!autoHide) return@LaunchedEffect
            delay(3000)
            expanded = false
            idle = true
        }
        val bubbleSize by animateDpAsState(if (idle) 40.dp else 64.dp, label = "bubbleSize")
        val bubbleAlpha by animateFloatAsState(if (idle) 0.5f else 1f, label = "bubbleAlpha")

        Column(
            Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                Modifier
                    .size(bubbleSize)
                    .alpha(bubbleAlpha)
                    .clip(CircleShape)
                    .border(if (idle) 2.dp else 3.dp, Color.White, CircleShape)
                    .pointerInput(Unit) {
                        detectDragGestures(onDragStart = { touch() }) { change, drag ->
                            change.consume(); onDrag(drag.x, drag.y)
                        }
                    }
                    .clickable {
                        // First tap on the faded dot only wakes it up
                        if (idle) touch() else { expanded = !expanded; touch() }
                    },
                contentAlignment = Alignment.Center
            ) { BubbleIcon(bubbleSize, color = bubbleColor) }

            if (!idle && !waiting) StatusPill(s)

            if (expanded && waiting) {
                // Waiting bubble: start a recording from any app, or close the bubble
                Column(
                    Modifier
                        .width(60.dp)
                        .clip(RoundedCornerShape(30.dp))
                        .background(menuBg)
                        .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(
                        onClick = { expanded = false; touch(); service.recordFromBubble() },
                        modifier = Modifier.size(44.dp),
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFFFFDAD6))
                    ) {
                        Box(Modifier.size(18.dp).clip(CircleShape).background(Brand.Record))
                    }
                    Text("Record", fontSize = 11.sp, color = menuIcon)
                    IconButton(
                        onClick = { expanded = false; touch(); service.liveFromBubble() },
                        modifier = Modifier.size(44.dp),
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Brand.GoLive, contentColor = Color.White)
                    ) { Icon(Icons.Outlined.Sensors, contentDescription = "Go live") }
                    Text("Go live", fontSize = 11.sp, color = menuIcon)
                    MenuButton(
                        Icons.Outlined.Close, "Close bubble",
                        Color.Transparent, menuIcon
                    ) { expanded = false; service.closeBubble() }
                }
            }

            if (expanded && !waiting) {
                Column(
                    Modifier
                        .width(60.dp)
                        .clip(RoundedCornerShape(30.dp))
                        .background(menuBg)
                        .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MenuButton(
                        if (s.paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause,
                        if (s.paused) "Resume" else "Pause",
                        chipBg, chipFg
                    ) { touch(); CaptureService.command(ctx, CaptureService.ACTION_TOGGLE_PAUSE) }
                    IconButton(
                        onClick = { expanded = false; CaptureService.command(ctx, CaptureService.ACTION_STOP) },
                        modifier = Modifier.size(44.dp),
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFFFFDAD6))
                    ) {
                        Box(Modifier.size(16.dp).clip(RoundedCornerShape(3.dp)).background(Brand.GoLive))
                    }
                    if (s.micAvailable) MenuButton(
                        if (s.micOn) Icons.Outlined.Mic else Icons.Outlined.MicOff,
                        if (s.micOn) "Mute microphone" else "Turn microphone on",
                        Color.Transparent, if (s.micOn) menuIcon else Brand.GoLive
                    ) { touch(); CaptureService.command(ctx, CaptureService.ACTION_TOGGLE_MIC) }
                    MenuButton(
                        Icons.Outlined.Face, "Face-cam",
                        if (s.faceCamOn) chipBg else Color.Transparent,
                        if (s.faceCamOn) chipFg else menuIcon
                    ) { touch(); CaptureService.command(ctx, CaptureService.ACTION_TOGGLE_FACECAM) }
                    MenuButton(
                        Icons.Outlined.CenterFocusWeak, "Screenshot",
                        Color.Transparent, menuIcon
                    ) { touch(); CaptureService.command(ctx, CaptureService.ACTION_SCREENSHOT) }
                }
            }
        }
    }

    @Composable
    private fun StatusPill(s: Session) {
        val live = s.mode == Mode.LIVE
        val bg = if (live && !s.paused) Brand.LiveRed else Color(0xA6000000)
        Row(
            Modifier.clip(RoundedCornerShape(8.dp)).background(bg).padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val label = when {
                s.paused -> "PAUSED"
                live && s.reconnecting -> "RECONNECTING"
                live && s.phase != Phase.RUNNING -> "STARTING"
                live -> "LIVE"
                else -> "REC"
            }
            Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(formatDuration(s.elapsedSec), color = Color.White, fontSize = 11.sp)
            if (live && s.viewers != null) {
                Icon(Icons.Outlined.Visibility, null, tint = Color.White, modifier = Modifier.size(12.dp))
                Text("${s.viewers}", color = Color.White, fontSize = 11.sp)
            }
        }
    }

    @Composable
    private fun MenuButton(icon: ImageVector, label: String, bg: Color, tint: Color, onClick: () -> Unit) {
        IconButton(
            onClick = onClick,
            modifier = Modifier.size(44.dp),
            colors = IconButtonDefaults.iconButtonColors(containerColor = bg, contentColor = tint)
        ) { Icon(icon, contentDescription = label) }
    }
}
