package com.appforge.recorderlive.service

import android.Manifest
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.appforge.recorderlive.data.Prefs

/**
 * Invisible screen opened by the floating bubble's Record button.
 * It only asks Android for the needed permissions + "Start recording?", then starts recording
 * and closes, so the user stays in their game.
 */
class CaptureRequestActivity : ComponentActivity() {

    companion object {
        /** true = go live (with the last saved Go live settings), false = record */
        const val EXTRA_LIVE = "live"
    }

    private val live by lazy { intent.getBooleanExtra(EXTRA_LIVE, false) }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            if (live) SessionStore.reset()
            CaptureService.start(this, live = live, resultCode = r.resultCode, data = data)
        }
        finish()
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        askCapture()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return // result launchers resume after rotation
        val p = Prefs(this)
        val needed = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            val mic = if (live) p.liveMic || p.liveGameSound else p.recMic || p.recGameSound
            val cam = if (live) p.liveFaceCam else p.recFaceCam
            if (mic) add(Manifest.permission.RECORD_AUDIO)
            if (cam) add(Manifest.permission.CAMERA)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isEmpty()) askCapture() else permissionLauncher.launch(needed.toTypedArray())
    }

    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
