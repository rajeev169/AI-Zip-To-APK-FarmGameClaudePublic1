package com.appforge.recorderlive.service

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import com.appforge.recorderlive.App
import com.appforge.recorderlive.MainActivity
import com.appforge.recorderlive.R
import com.appforge.recorderlive.data.FpsSupport
import com.appforge.recorderlive.data.MediaRepository
import com.appforge.recorderlive.data.Prefs
import com.appforge.recorderlive.data.Replay
import com.appforge.recorderlive.youtube.AuthMode
import com.appforge.recorderlive.youtube.SignInAgainException
import com.appforge.recorderlive.youtube.YouTubeAuth
import com.appforge.recorderlive.youtube.YouTubeApi
import com.appforge.recorderlive.youtube.YouTubeException
import com.google.android.gms.auth.UserRecoverableAuthException
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.encoder.input.sources.audio.AudioSource
import com.pedro.encoder.input.sources.audio.InternalAudioSource
import com.pedro.encoder.input.sources.audio.MicrophoneSource
import com.pedro.encoder.input.sources.audio.MixAudioSource
import com.pedro.encoder.input.sources.audio.NoAudioSource
import com.pedro.encoder.input.sources.audio.SilenceAudioSource
import com.pedro.encoder.input.sources.video.NoVideoSource
import com.pedro.encoder.input.sources.video.ScreenSource
import com.pedro.library.base.recording.RecordController
import com.pedro.library.generic.GenericStream
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Foreground service that captures the screen (+ game sound / mic) and either
 * records it to an MP4 or streams it to YouTube Live over RTMP.
 * It also hosts the floating bubble and the face-cam overlay.
 */
class CaptureService : LifecycleService(), SavedStateRegistryOwner, ConnectChecker {

    companion object {
        const val ACTION_START_RECORD = "start_record"
        const val ACTION_START_LIVE = "start_live"
        const val ACTION_STOP = "stop"
        const val ACTION_TOGGLE_PAUSE = "toggle_pause"
        const val ACTION_TOGGLE_MIC = "toggle_mic"
        const val ACTION_TOGGLE_FACECAM = "toggle_facecam"
        const val ACTION_SCREENSHOT = "screenshot"
        const val ACTION_SHOW_BUBBLE = "show_bubble"
        const val ACTION_HIDE_BUBBLE = "hide_bubble"

        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_DATA = "data"
        private const val EXTRA_FACEBOOK_LIVE = "facebook_live"
        private const val NOTIFICATION_ID = 42

        /** Call from the Activity right after the user accepted screen capture. */
        fun start(context: Context, live: Boolean, resultCode: Int, data: Intent, facebookLive: Boolean = false) {
            val i = Intent(context, CaptureService::class.java)
                .setAction(if (live) ACTION_START_LIVE else ACTION_START_RECORD)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
                .putExtra(EXTRA_FACEBOOK_LIVE, facebookLive)
            ContextCompat.startForegroundService(context, i)
        }

        /** "Always show bubble" turned on (call from the app while it is open). */
        fun showBubble(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            ContextCompat.startForegroundService(
                context, Intent(context, CaptureService::class.java).setAction(ACTION_SHOW_BUBBLE)
            )
        }

        /** "Always show bubble" turned off. */
        fun hideBubble(context: Context) {
            runCatching { context.startService(Intent(context, CaptureService::class.java).setAction(ACTION_HIDE_BUBBLE)) }
        }

        fun command(context: Context, action: String) {
            if (SessionStore.state.value.mode == Mode.NONE) return
            context.startService(Intent(context, CaptureService::class.java).setAction(action))
        }
    }

    // ----- SavedStateRegistryOwner (needed by Compose inside the overlay window) -----
    private val savedStateController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: Prefs
    private lateinit var repo: MediaRepository

    private var mode = Mode.NONE
    private var projection: MediaProjection? = null
    private var stream: GenericStream? = null
    private var bubble: BubbleOverlay? = null
    private var faceCam: FaceCamOverlay? = null
    private var pauseFilter: ImageObjectFilterRender? = null

    private var recordFile: File? = null
    private var gameSound = false
    private var micOn = false
    private var broadcastId: String? = null
    private var facebookLive = false
    private var liveTitle = ""
    private var startedAt = 0L
    private var ending = false
    private var timerJob: Job? = null
    private var viewersJob: Job? = null
    /** True while the "Always show bubble" setting keeps the bubble waiting on screen. */
    private var idleBubble = false

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            // User tapped "Stop sharing" in the system UI
            main.post { stopSession() }
        }
    }

    override fun onCreate() {
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        super.onCreate()
        prefs = Prefs(this)
        repo = MediaRepository(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START_RECORD, ACTION_START_LIVE -> {
                val live = intent.action == ACTION_START_LIVE
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
                facebookLive = intent.getBooleanExtra(EXTRA_FACEBOOK_LIVE, false)
                if (mode != Mode.NONE || data == null) return START_NOT_STICKY
                startSession(live, code, data)
            }
            ACTION_STOP -> stopSession()
            ACTION_TOGGLE_PAUSE -> togglePause()
            ACTION_TOGGLE_MIC -> toggleMic()
            ACTION_TOGGLE_FACECAM -> toggleFaceCam()
            ACTION_SCREENSHOT -> takeScreenshot()
            ACTION_SHOW_BUBBLE -> enterIdleBubble()
            ACTION_HIDE_BUBBLE -> exitIdleBubble()
            else -> if (mode == Mode.NONE && !idleBubble) stopSelf()
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ start

    private fun has(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun startSession(live: Boolean, resultCode: Int, data: Intent) {
        mode = if (live) Mode.LIVE else Mode.RECORD
        ending = false
        val audioAllowed = has(Manifest.permission.RECORD_AUDIO)
        gameSound = (if (live) prefs.liveGameSound else prefs.recGameSound) && audioAllowed
        micOn = (if (live) prefs.liveMic else prefs.recMic) && audioAllowed
        val wantBubble = if (live) prefs.liveBubble else prefs.recBubble
        val wantFaceCam = if (live) prefs.liveFaceCam else prefs.recFaceCam

        // 1. Foreground notification (must happen before getMediaProjection on Android 14+)
        var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (audioAllowed) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (has(Manifest.permission.CAMERA)) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        }
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), types)
        } catch (e: Exception) {
            fail(ErrorKind.OTHER, "Could not start: ${e.message}")
            return
        }

        // 2. Screen capture permission token -> MediaProjection
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = runCatching { mpm.getMediaProjection(resultCode, data) }.getOrNull()
        if (mp == null) {
            fail(ErrorKind.OTHER, "Screen capture was not allowed")
            return
        }
        projection = mp

        // 3. Encoder + sources
        val height = if (live) prefs.liveHeight else prefs.recHeight
        // Use the chosen fps if this phone supports it, otherwise the best it can do
        val wantedFps = if (live) prefs.liveFps else prefs.recFps
        val fpsOptions = if (live) FpsSupport.liveOptions(this, height) else FpsSupport.recordingOptions(this, height)
        val fps = FpsSupport.bestOf(fpsOptions, wantedFps)
        if (fps < wantedFps) showMessage("This phone supports up to $fps fps here — using $fps fps")
        val size = computeSize(live, height)
        val bitrate = videoBitrate(live, size.short, fps)
        val s = GenericStream(applicationContext, this, NoVideoSource(), NoAudioSource())
        try {
            s.getGlInterface().setForceRender(true, fps)
            val okVideo = s.prepareVideo(size.long, size.short, bitrate, fps, 2, size.rotation)
            val okAudio = s.prepareAudio(44100, true, 128_000)
            if (!okVideo || !okAudio) throw IllegalArgumentException("Encoder not supported on this phone")
            s.changeVideoSource(ScreenSource(applicationContext, mp, projectionCallback))
            s.changeAudioSource(buildAudioSource())
            if (live) s.getStreamClient().setReTries(10)
        } catch (e: Exception) {
            stream = s
            fail(ErrorKind.OTHER, e.message ?: "Could not prepare the encoder")
            return
        }
        stream = s

        SessionStore.update {
            Session(
                mode = mode,
                phase = if (live) Phase.PREPARING else Phase.RUNNING,
                micOn = micOn,
                micAvailable = audioAllowed,
                qualityLabel = "${size.short}p",
            )
        }

        // 4. Overlays
        val canOverlay = Settings.canDrawOverlays(this)
        if ((wantBubble || idleBubble) && canOverlay && bubble == null) bubble = BubbleOverlay(this).also { it.show() }
        if (wantFaceCam) showFaceCam(quiet = true)

        // 5. Go
        if (live) startLive(s) else startRecording(s)
    }

    @Suppress("DEPRECATION")
    private fun screenBounds(): android.graphics.Rect {
        val wm = getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            wm.maximumWindowMetrics.bounds
        } else {
            val dm = android.util.DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            android.graphics.Rect(0, 0, dm.widthPixels, dm.heightPixels)
        }
    }

    private data class OutSize(val long: Int, val short: Int, val rotation: Int)

    private fun even(v: Int) = if (v % 2 == 0) v else v + 1

    private fun computeSize(live: Boolean, height: Int): OutSize {
        val b = screenBounds()
        val screenLong = max(b.width(), b.height())
        val screenShort = min(b.width(), b.height())
        return if (live) {
            // YouTube likes 16:9
            val short = height
            val long = even((short * 16f / 9f).roundToInt())
            OutSize(long, short, if (prefs.liveLandscape) 0 else 90)
        } else {
            // Recording keeps the phone's own shape, in the orientation the phone is held now
            val short = even(min(height, screenShort))
            val long = even((short.toFloat() * screenLong / screenShort).roundToInt())
            val landscapeNow = b.width() > b.height()
            OutSize(long, short, if (landscapeNow) 0 else 90)
        }
    }

    private fun videoBitrate(live: Boolean, short: Int, fps: Int): Int = if (live) {
        // Close to YouTube's recommendations, kept moderate for mobile data
        val base = when {
            short >= 1080 -> 6_000_000
            short >= 720 -> 3_500_000
            else -> 1_500_000
        }
        if (fps >= 60) (base * 1.5f).toInt().coerceAtMost(9_000_000) else base
    } else {
        val base = if (short >= 1080) 8_000_000 else 5_000_000
        val factor = when {
            fps >= 120 -> 1.7f
            fps >= 90 -> 1.35f
            fps >= 60 -> 1.0f
            else -> 0.75f
        }
        (base * factor).toInt()
    }

    /** Picks the audio source from the current game-sound and mic switches. */
    private fun buildAudioSource(): AudioSource {
        val mp = projection
        return when {
            gameSound && micOn && mp != null -> MixAudioSource(mp)
            gameSound && mp != null -> InternalAudioSource(mp)
            micOn -> MicrophoneSource()
            else -> SilenceAudioSource()
        }
    }

    // ------------------------------------------------------------------ record

    private fun startRecording(s: GenericStream) {
        val dir = getExternalFilesDir(null) ?: filesDir
        val file = File(dir, "rec_${System.currentTimeMillis()}.mp4")
        recordFile = file
        try {
            s.startRecord(file.absolutePath, RecordController.RecordTracks.ALL) { }
        } catch (e: Exception) {
            fail(ErrorKind.OTHER, e.message ?: "Could not start recording")
            return
        }
        startedAt = System.currentTimeMillis()
        startTimer()
    }

    // ------------------------------------------------------------------ live

    private fun startLive(s: GenericStream) {
        liveTitle = prefs.liveTitle
        if (facebookLive) {
            val pageId = prefs.facebookSelectedPageId
            val server = prefs.facebookRtmpServer.trim().trimEnd('/')
            val key = prefs.facebookRtmpKey.trim().trimStart('/')
            if (pageId.isNullOrBlank()) { fail(ErrorKind.SIGN_IN, "Select and save a Facebook Page first"); return }
            if (!server.startsWith("rtmps://", ignoreCase = true) || key.isBlank()) {
                fail(ErrorKind.SIGN_IN, "Save the Facebook RTMPS server URL and stream key first")
                return
            }
            val targetUrl = "$server/$key"
            SessionStore.update { it.copy(liveCreated = true, keyMode = true) }
            try {
                s.startStream(targetUrl)
            } catch (e: Exception) {
                fail(ErrorKind.OTHER, e.message ?: "Could not start the Facebook RTMPS stream")
            }
            return
        }
        // Stream-key mode: no sign-in, stream straight to the channel's key
        if (YouTubeAuth.mode(this) == AuthMode.KEY) {
            val url = YouTubeAuth.streamKeyUrl(this)
            if (url == null) { fail(ErrorKind.SIGN_IN, "Add your stream key first"); return }
            SessionStore.update { it.copy(liveCreated = true, keyMode = true) }
            try { s.startStream(url) } catch (e: Exception) { fail(ErrorKind.OTHER, e.message) }
            return
        }
        lifecycleScope.launch {
            try {
                val token = YouTubeAuth.token(this@CaptureService)
                val setup = YouTubeApi.createLive(token, liveTitle, prefs.livePrivacy, prefs.liveLatency)
                if (ending || mode != Mode.LIVE) {
                    // User cancelled while we were creating it: remove it again
                    App.scope.launch { runCatching { YouTubeApi.endLive(token, setup.broadcastId) } }
                    return@launch
                }
                broadcastId = setup.broadcastId
                SessionStore.update { it.copy(liveCreated = true, broadcastId = setup.broadcastId) }
                s.startStream(setup.rtmpUrl)
            } catch (e: YouTubeException) {
                if (e.isLiveNotEnabled) fail(ErrorKind.LIVE_NOT_ENABLED, e.message)
                else fail(ErrorKind.OTHER, e.message)
            } catch (e: UserRecoverableAuthException) {
                fail(ErrorKind.SIGN_IN, "Please allow YouTube access again")
            } catch (e: SignInAgainException) {
                fail(ErrorKind.SIGN_IN, "Please connect your YouTube channel again")
            } catch (e: IOException) {
                fail(ErrorKind.NETWORK, "No internet connection")
            } catch (e: Exception) {
                fail(ErrorKind.OTHER, e.message)
            }
        }
    }

    override fun onConnectionStarted(url: String) {}

    override fun onConnectionSuccess() {
        main.post { onConnected() }
    }

    private fun onConnected() {
        if (mode != Mode.LIVE) return
        val first = startedAt == 0L
        SessionStore.update {
            it.copy(liveConnected = true, screenReady = true, reconnecting = false, phase = Phase.RUNNING)
        }
        if (first) {
            startedAt = System.currentTimeMillis()
            startTimer()
            startViewerPolling()
        }
    }

    override fun onConnectionFailed(reason: String) {
        main.post { onFailed(reason) }
    }

    private fun onFailed(reason: String) {
        val s = stream ?: return
        if (mode != Mode.LIVE || ending) return
        if (s.getStreamClient().reTry(5000, reason, null)) {
            SessionStore.update { it.copy(reconnecting = true) }
        } else {
            fail(ErrorKind.NETWORK, if (facebookLive) "Connection to Facebook lost" else "Connection to YouTube lost")
        }
    }

    override fun onDisconnect() {}
    override fun onAuthError() {}
    override fun onAuthSuccess() {}

    private fun startViewerPolling() {
        viewersJob?.cancel()
        viewersJob = lifecycleScope.launch {
            while (isActive) {
                delay(30_000)
                val id = broadcastId ?: continue
                runCatching {
                    val token = YouTubeAuth.token(this@CaptureService)
                    YouTubeApi.viewers(token, id)
                }.getOrNull()?.let { v -> SessionStore.update { it.copy(viewers = v) } }
            }
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = lifecycleScope.launch {
            while (isActive) {
                delay(1000)
                val st = SessionStore.state.value
                if (!st.paused && !st.reconnecting) SessionStore.update { it.copy(elapsedSec = it.elapsedSec + 1) }
            }
        }
    }

    // ------------------------------------------------------------------ controls

    private fun togglePause() {
        val s = stream ?: return
        val paused = !SessionStore.state.value.paused
        if (mode == Mode.RECORD) {
            if (paused) s.pauseRecord() else s.resumeRecord()
        } else if (mode == Mode.LIVE) {
            // Viewers see a "be right back" card and hear nothing while paused
            try {
                if (paused) {
                    val f = ImageObjectFilterRender()
                    s.getGlInterface().addFilter(f)
                    f.setImage(pausedCard())
                    f.setScale(100f, 100f)
                    f.setPosition(0f, 0f)
                    pauseFilter = f
                    s.changeAudioSource(SilenceAudioSource())
                } else {
                    pauseFilter?.let { s.getGlInterface().removeFilter(it) }
                    pauseFilter = null
                    s.changeAudioSource(buildAudioSource())
                }
            } catch (_: Exception) { }
        }
        SessionStore.update { it.copy(paused = paused) }
        updateNotification()
    }

    private fun pausedCard(): Bitmap {
        val w = 1280
        val h = 720
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.parseColor("#1B1B21"))
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 64f; textAlign = Paint.Align.CENTER; isFakeBoldText = true
        }
        c.drawText("Be right back", w / 2f, h / 2f, p)
        p.textSize = 32f; p.isFakeBoldText = false; p.color = Color.parseColor("#C6C5D0")
        c.drawText("The stream is paused", w / 2f, h / 2f + 60f, p)
        return bmp
    }

    private fun toggleMic() {
        val s = stream ?: return
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            SessionStore.toast("Allow microphone in the app first")
            return
        }
        micOn = !micOn
        if (!SessionStore.state.value.paused) {
            runCatching { s.changeAudioSource(buildAudioSource()) }
        }
        SessionStore.update { it.copy(micOn = micOn) }
    }

    private fun toggleFaceCam() {
        if (faceCam != null) {
            faceCam?.hide(); faceCam = null
            SessionStore.update { it.copy(faceCamOn = false) }
        } else showFaceCam(quiet = false)
    }

    private fun showFaceCam(quiet: Boolean) {
        if (!has(Manifest.permission.CAMERA) || !Settings.canDrawOverlays(this)) {
            if (!quiet) SessionStore.toast("Allow camera and \"Display over other apps\" for face-cam")
            return
        }
        faceCam = FaceCamOverlay(this).also {
            if (it.show()) SessionStore.update { st -> st.copy(faceCamOn = true) }
            else { faceCam = null; SessionStore.toast("Front camera not available") }
        }
    }

    private fun takeScreenshot() {
        val s = stream ?: return
        s.getGlInterface().takePhoto { bmp ->
            App.scope.launch {
                val name = "Screenshot_" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
                val uri = repo.saveScreenshot(bmp, name)
                SessionStore.toast(if (uri != null) "Screenshot saved" else "Could not save screenshot")
                SessionStore.mediaChanged()
            }
        }
    }

    // ------------------------------------------------------------------ stop

    /** Normal end: saves the recording / ends the YouTube broadcast. */
    fun stopSession() {
        if (mode == Mode.NONE || ending) return
        ending = true
        val s = stream
        val endedMode = mode
        val elapsed = SessionStore.state.value.elapsedSec
        when (endedMode) {
            Mode.RECORD -> {
                runCatching { s?.stopRecord() }
                val file = recordFile
                val name = "Recording_" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(startedAt))
                App.scope.launch {
                    val uri = if (file != null && file.exists() && file.length() > 0) repo.saveVideo(file, name) else null
                    SessionStore.toast(if (uri != null) "Recording saved" else "Recording could not be saved")
                    SessionStore.mediaChanged()
                }
            }
            Mode.LIVE -> {
                runCatching { if (s?.isStreaming == true) s.stopStream() }
                val id = broadcastId
                if (id != null) {
                    val wentLive = startedAt != 0L
                    if (wentLive) prefs.addReplay(Replay(id, liveTitle, startedAt, elapsed))
                    val ctx = applicationContext
                    App.scope.launch {
                        runCatching { YouTubeApi.endLive(YouTubeAuth.token(ctx), id) }
                        SessionStore.mediaChanged()
                    }
                    if (wentLive) SessionStore.toast("Live ended. Replay saved on your channel")
                }
            }
            Mode.NONE -> {}
        }
        cleanup()
        SessionStore.reset()
    }

    /** Something went wrong: keep the error in [SessionStore] so the screen can explain it. */
    private fun fail(kind: ErrorKind, message: String?) {
        if (ending) return
        ending = true
        if (mode == Mode.RECORD) showMessage(message ?: "Recording stopped")
        if (mode == Mode.LIVE && !App.inForeground) showMessage(
            when (kind) {
                ErrorKind.LIVE_NOT_ENABLED -> if (facebookLive) "Facebook Live is not available for this Page or account" else "Live streaming isn't turned on for this channel yet"
                ErrorKind.SIGN_IN -> if (facebookLive) "Open Facebook setup and check the selected Page and RTMPS details" else "Open the app and connect YouTube again"
                else -> "Couldn't go live: ${message ?: "unknown error"}"
            }
        )
        runCatching { if (stream?.isStreaming == true) stream?.stopStream() }
        runCatching { if (stream?.isRecording == true) stream?.stopRecord() }
        recordFile?.delete()
        val id = broadcastId
        if (id != null) {
            val ctx = applicationContext
            App.scope.launch { runCatching { YouTubeApi.endLive(YouTubeAuth.token(ctx), id) } }
        }
        cleanup()
        SessionStore.update { Session(mode = Mode.NONE, phase = Phase.ERROR, errorKind = kind, errorMessage = message) }
    }

    private fun cleanup() {
        timerJob?.cancel()
        viewersJob?.cancel()
        faceCam?.hide(); faceCam = null
        pauseFilter = null
        runCatching { stream?.release() }
        stream = null
        runCatching { projection?.unregisterCallback(projectionCallback) }
        runCatching { projection?.stop() }
        projection = null
        mode = Mode.NONE
        broadcastId = null
        facebookLive = false
        startedAt = 0L
        recordFile = null
        if (idleBubble && Settings.canDrawOverlays(this)) {
            // Go back to the waiting bubble so the next recording can start from any app
            startIdleForeground()
            if (bubble == null) bubble = BubbleOverlay(this).also { it.show() }
        } else {
            bubble?.hide(); bubble = null
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    // ------------------------------------------------------------------ waiting bubble

    private fun enterIdleBubble() {
        idleBubble = true
        if (mode != Mode.NONE) return // already recording / live; bubble returns to waiting after
        if (!startIdleForeground() || !Settings.canDrawOverlays(this)) {
            idleBubble = false
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        if (bubble == null) bubble = BubbleOverlay(this).also { it.show() }
    }

    private fun exitIdleBubble() {
        idleBubble = false
        prefs.floatingBubble = false
        if (mode == Mode.NONE) {
            bubble?.hide(); bubble = null
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun startIdleForeground(): Boolean = try {
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, idleNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, idleNotification())
        }
        true
    } catch (e: Exception) {
        false
    }

    /** Called by the waiting bubble's Record button: opens the small screen that asks Android for capture. */
    fun recordFromBubble() {
        if (mode != Mode.NONE) return
        val i = Intent(this, CaptureRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(i) }.onFailure { showMessage("Open the app to start recording") }
    }

    /** Called by the waiting bubble's Go live button: starts live with the last saved Go live settings. */
    fun liveFromBubble() {
        if (mode != Mode.NONE) return
        if (!YouTubeAuth.isConnected(this)) {
            // Not connected to YouTube yet: open the app on the Connect screen
            SessionStore.openRoute("connect")
            val i = Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            runCatching { startActivity(i) }.onFailure { showMessage("Open the app and connect YouTube first") }
            return
        }
        val i = Intent(this, CaptureRequestActivity::class.java)
            .putExtra(CaptureRequestActivity.EXTRA_LIVE, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(i) }.onFailure { showMessage("Open the app to go live") }
    }

    /** Closes the waiting bubble from its ✕ button (same as turning the setting off). */
    fun closeBubble() {
        exitIdleBubble()
        showMessage("Bubble turned off. Turn it on again in Settings.")
    }

    /** Message the user can see even outside the app. */
    fun showMessage(msg: String) {
        if (App.inForeground) SessionStore.toast(msg)
        else main.post { android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_SHORT).show() }
    }

    private fun idleNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val hide = PendingIntent.getService(
            this, 2, Intent(this, CaptureService::class.java).setAction(ACTION_HIDE_BUBBLE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, App.CHANNEL_CAPTURE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Bubble is ready")
            .setContentText("Tap the bubble in any app to start recording")
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .addAction(0, "Hide bubble", hide)
            .build()
    }

    override fun onDestroy() {
        idleBubble = false
        if (mode != Mode.NONE) stopSession()
        bubble?.hide(); bubble = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notification

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val paused = SessionStore.state.value.paused
        val title = when {
            mode == Mode.LIVE && paused -> "Live paused"
            mode == Mode.LIVE -> "Live on YouTube"
            paused -> "Recording paused"
            else -> "Recording your screen"
        }
        return NotificationCompat.Builder(this, App.CHANNEL_CAPTURE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(if (mode == Mode.LIVE) "Tap Stop to end the live stream" else "Tap Stop to save the video")
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .addAction(0, "Stop", stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun updateNotification() {
        if (mode == Mode.NONE) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            androidx.core.app.NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, buildNotification())
        }
    }
}
