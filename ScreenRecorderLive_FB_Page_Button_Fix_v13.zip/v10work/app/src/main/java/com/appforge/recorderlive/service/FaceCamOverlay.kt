package com.appforge.recorderlive.service

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat

/** Round, draggable front-camera bubble. It is drawn on screen, so it shows in the recording/live. */
class FaceCamOverlay(private val service: CaptureService) {
    private val wm = service.getSystemService(WindowManager::class.java)
    private val density = service.resources.displayMetrics.density
    private var frame: FrameLayout? = null
    private var provider: ProcessCameraProvider? = null

    private fun dp(v: Int) = (v * density).toInt()

    /** Returns false if the phone has no front camera. */
    @SuppressLint("ClickableViewAccessibility")
    fun show(): Boolean {
        if (frame != null) return true
        val size = dp(110)
        val preview = PreviewView(service).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        val f = FrameLayout(service).apply {
            addView(preview, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) = outline.setOval(0, 0, view.width, view.height)
            }
            clipToOutline = true
            foreground = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(3), Color.WHITE)
            }
            contentDescription = "Face-cam"
        }
        val dm = service.resources.displayMetrics
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dm.heightPixels - size - dp(140)
        }

        var lastX = 0f
        var lastY = 0f
        f.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lastX = e.rawX; lastY = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (params.x + (e.rawX - lastX)).toInt().coerceIn(0, dm.widthPixels - size)
                    params.y = (params.y + (e.rawY - lastY)).toInt().coerceIn(0, dm.heightPixels - size)
                    lastX = e.rawX; lastY = e.rawY
                    runCatching { wm.updateViewLayout(v, params) }
                }
            }
            true
        }

        if (runCatching { wm.addView(f, params) }.isFailure) return false
        frame = f

        val future = ProcessCameraProvider.getInstance(service)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                if (!p.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)) {
                    hide()
                    SessionStore.toast("Front camera not available")
                    SessionStore.update { it.copy(faceCamOn = false) }
                    return@addListener
                }
                val camPreview = Preview.Builder().build()
                camPreview.setSurfaceProvider(preview.surfaceProvider)
                p.unbindAll()
                p.bindToLifecycle(service, CameraSelector.DEFAULT_FRONT_CAMERA, camPreview)
            } catch (e: Exception) {
                hide()
                SessionStore.toast("Could not open the camera")
                SessionStore.update { it.copy(faceCamOn = false) }
            }
        }, ContextCompat.getMainExecutor(service))
        return true
    }

    fun hide() {
        runCatching { provider?.unbindAll() }
        provider = null
        frame?.let { runCatching { wm.removeView(it) } }
        frame = null
    }
}
