package com.appforge.recorderlive.ui.screens

import android.Manifest
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.AppActions
import com.appforge.recorderlive.MainViewModel
import com.appforge.recorderlive.service.Mode
import com.appforge.recorderlive.service.SessionStore
import com.appforge.recorderlive.data.FpsSupport
import com.appforge.recorderlive.ui.components.FpsDropdown
import com.appforge.recorderlive.ui.components.LabeledSection
import com.appforge.recorderlive.ui.components.Segmented
import com.appforge.recorderlive.ui.theme.Brand
import com.appforge.recorderlive.youtube.AuthMode
import kotlinx.coroutines.launch

@Composable
fun GoLiveSetupScreen(
    vm: MainViewModel,
    actions: AppActions,
    onBack: () -> Unit,
    onSwitch: () -> Unit,
    onStarted: () -> Unit,
) {
    val p = vm.prefs
    val cs = MaterialTheme.colorScheme
    val channel by vm.channel.collectAsState()
    val channelError by vm.channelError.collectAsState()
    val authMode by vm.authMode.collectAsState()
    val keyMode = authMode == AuthMode.KEY
    val session by SessionStore.state.collectAsState()
    val scope = rememberCoroutineScope()

    var title by remember { mutableStateOf(p.liveTitle) }
    val privacies = listOf("public", "unlisted", "private")
    var privacy by remember { mutableStateOf(privacies.indexOf(p.livePrivacy).coerceAtLeast(0)) }
    val qualities = listOf(480, 720, 1080)
    var quality by remember { mutableStateOf(qualities.indexOf(p.liveHeight).coerceAtLeast(1)) }
    var landscape by remember { mutableStateOf(p.liveLandscape) }
    val ctx = LocalContext.current
    var liveFps by remember { mutableStateOf(p.liveFps) }
    val liveHeight = qualities[quality]
    // 30 / 60 fps for live (YouTube allows up to 60); 60 greyed out if this phone can't do it
    val fpsOptions = remember(liveHeight) { FpsSupport.liveOptions(ctx, liveHeight) }
    LaunchedEffect(fpsOptions) {
        val best = FpsSupport.bestOf(fpsOptions, liveFps)
        if (best != liveFps) { liveFps = best; p.liveFps = best }
    }
    val latencies = listOf("normal", "low", "ultraLow")
    var latency by remember { mutableStateOf(latencies.indexOf(p.liveLatency).coerceAtLeast(0)) }
    var gameSound by remember { mutableStateOf(p.liveGameSound) }
    var mic by remember { mutableStateOf(p.liveMic) }
    var faceCam by remember { mutableStateOf(p.liveFaceCam) }
    var bubble by remember { mutableStateOf(p.liveBubble) }
    var starting by remember { mutableStateOf(false) }

    LaunchedEffect(authMode) { if (!keyMode && channel == null) vm.loadChannel() }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.height(64.dp).padding(start = 4.dp, end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back") }
            Text("Go live", fontSize = 22.sp, fontWeight = FontWeight.Medium)
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Connection card: channel (Google / brand channel) or stream key
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainer)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                    val avatar = channel?.avatar
                    when {
                        keyMode -> Icon(Icons.Outlined.Key, null, tint = cs.onPrimary)
                        avatar != null -> Image(avatar, null, Modifier.size(44.dp), contentScale = ContentScale.Crop)
                        else -> Text((channel?.title ?: "Y").take(1).uppercase(), color = cs.onPrimary, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    when {
                        keyMode -> {
                            Text("Stream key", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text("••••" + (p.streamKey?.takeLast(4) ?: ""), fontSize = 13.sp, color = cs.onSurfaceVariant)
                        }
                        channelError != null -> {
                            Text("Couldn't load channel", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = cs.error)
                            Text(channelError ?: "", fontSize = 12.sp, color = cs.onSurfaceVariant, lineHeight = 16.sp)
                        }
                        else -> {
                            Text(channel?.title ?: "Loading channel…", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text(
                                channel?.email?.takeIf { it.isNotBlank() }
                                    ?: if (authMode == AuthMode.WEB) "Brand channel via Google" else "Signed in with Google",
                                fontSize = 13.sp, color = cs.onSurfaceVariant
                            )
                        }
                    }
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = onSwitch) { Text(if (keyMode) "Change" else "Switch") }
                    if (!keyMode && channelError != null) {
                        TextButton(onClick = { actions.retryChannel() }) { Text("Retry") }
                    }
                }
            }

            if (keyMode) {
                Text(
                    "Title and who can watch are set in YouTube Studio when you use a stream key.",
                    fontSize = 13.sp, color = cs.onSurfaceVariant, lineHeight = 19.sp
                )
            } else {
                OutlinedTextField(
                    value = title, onValueChange = { title = it; p.liveTitle = it },
                    label = { Text("Stream title") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )

                LabeledSection("Who can watch") {
                    Segmented(listOf("Public", "Unlisted", "Private"), privacy, { privacy = it; p.livePrivacy = privacies[it] })
                }
            }
            LabeledSection("Quality") {
                Segmented(listOf("480p", "720p", "1080p"), quality, { quality = it; p.liveHeight = qualities[it] })
            }
            FpsDropdown("Frame rate", fpsOptions, liveFps, { liveFps = it; p.liveFps = it })
            if (keyMode) {
                Text(
                    "Latency (delay for viewers) is set in YouTube Studio → Stream settings when you use a stream key.",
                    fontSize = 13.sp, color = cs.onSurfaceVariant, lineHeight = 19.sp
                )
            } else {
                LabeledSection("Latency (delay for viewers)") {
                    Segmented(listOf("Normal", "Low", "Ultra low"), latency, { latency = it; p.liveLatency = latencies[it] })
                    Text(
                        when (latency) {
                            0 -> "About 15–30 s behind. Smoothest for viewers with weak internet."
                            1 -> "About 5–10 s behind. Good balance (recommended)."
                            else -> "About 2–5 s behind. Best for chatting live; viewers may buffer more."
                        },
                        fontSize = 12.sp, color = cs.onSurfaceVariant, lineHeight = 17.sp
                    )
                }
            }
            LabeledSection("Orientation") {
                Segmented(listOf("Landscape", "Portrait"), if (landscape) 0 else 1, { landscape = it == 0; p.liveLandscape = landscape })
            }

            Surface(
                shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerLowest,
                border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    SwitchRow("Game sound", gameSound) {
                        gameSound = it; p.liveGameSound = it
                        if (it) actions.ensurePermissions(listOf(Manifest.permission.RECORD_AUDIO)) {}
                    }
                    HorizontalDivider(color = cs.surfaceContainer)
                    SwitchRow("Microphone", mic) {
                        mic = it; p.liveMic = it
                        if (it) actions.ensurePermissions(listOf(Manifest.permission.RECORD_AUDIO)) {}
                    }
                    HorizontalDivider(color = cs.surfaceContainer)
                    SwitchRow("Face-cam", faceCam) {
                        faceCam = it; p.liveFaceCam = it
                        if (it) actions.ensurePermissions(listOf(Manifest.permission.CAMERA)) { actions.ensureOverlay() }
                    }
                    HorizontalDivider(color = cs.surfaceContainer)
                    SwitchRow("Floating bubble", bubble) {
                        bubble = it; p.liveBubble = it
                        if (it) actions.ensureOverlay()
                    }
                }
            }
        }

        Box(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 24.dp)) {
            Button(
                onClick = {
                    if (session.mode != Mode.NONE) {
                        SessionStore.toast("Stop the current recording first"); return@Button
                    }
                    starting = true
                    p.liveTitle = title
                    SessionStore.reset()
                    actions.startLive { scope.launch { onStarted() } }
                    scope.launch { kotlinx.coroutines.delay(1500); starting = false }
                },
                enabled = !starting,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Brand.GoLive, contentColor = Color.White)
            ) {
                if (starting) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                else {
                    Icon(Icons.Outlined.Sensors, null)
                    Text("  Go live now", fontSize = 17.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
