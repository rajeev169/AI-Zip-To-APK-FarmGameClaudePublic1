package com.appforge.recorderlive.ui.screens

import android.text.format.DateUtils
import android.text.format.Formatter
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.MainViewModel
import com.appforge.recorderlive.data.MediaItem
import com.appforge.recorderlive.data.MediaKind
import com.appforge.recorderlive.ui.components.formatDuration

@Composable
fun MediaThumb(vm: MainViewModel, item: MediaItem, width: Dp, height: Dp, modifier: Modifier = Modifier) {
    var bmp by remember(item.key) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(item.key) { item.uri?.let { bmp = vm.thumbnail(it) } }
    val placeholder = when (item.kind) {
        MediaKind.REPLAY -> Color(0xFF2B2E45)
        MediaKind.VIDEO -> Color(0xFF3A4C3F)
        MediaKind.SCREENSHOT -> Color(0xFF4B3A52)
    }
    Box(modifier.size(width, height).clip(RoundedCornerShape(12.dp)).background(placeholder)) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        if (item.kind == MediaKind.REPLAY) {
            Icon(Icons.Outlined.Sensors, null, tint = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.align(Alignment.Center).size(26.dp))
        }
        if (item.durationMs > 0) {
            Text(
                formatDuration(item.durationMs / 1000), color = Color.White, fontSize = 11.sp,
                modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
                    .clip(RoundedCornerShape(4.dp)).background(Color(0xA6000000)).padding(horizontal = 5.dp, vertical = 1.dp)
            )
        }
    }
}

@Composable
fun mediaSubtitle(item: MediaItem): String {
    val ctx = LocalContext.current
    val day = DateUtils.getRelativeTimeSpanString(
        item.dateMs, System.currentTimeMillis(), DateUtils.DAY_IN_MILLIS
    ).toString()
    return when (item.kind) {
        MediaKind.REPLAY -> "$day · Saved on YouTube"
        MediaKind.VIDEO -> buildString {
            append(day)
            if (item.height > 0) append(" · ${item.height}p")
            if (item.sizeBytes > 0) append(" · " + Formatter.formatShortFileSize(ctx, item.sizeBytes))
        }
        MediaKind.SCREENSHOT -> "$day · Screenshot"
    }
}
