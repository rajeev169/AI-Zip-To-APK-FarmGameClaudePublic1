package com.appforge.recorderlive.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.AppActions
import com.appforge.recorderlive.MainViewModel
import com.appforge.recorderlive.data.MediaItem
import com.appforge.recorderlive.data.MediaKind
import com.appforge.recorderlive.service.SessionStore
import com.appforge.recorderlive.ui.theme.Brand

@Composable
fun RecordingsScreen(vm: MainViewModel, actions: AppActions) {
    val all by vm.media.collectAsState()
    var filter by remember { mutableStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var renaming by remember { mutableStateOf<MediaItem?>(null) }
    var deleting by remember { mutableStateOf<MediaItem?>(null) }
    val cs = MaterialTheme.colorScheme

    val filters = listOf("All", "Recordings", "Live replays", "Screenshots")
    val shown = all.filter {
        when (filter) {
            1 -> it.kind == MediaKind.VIDEO
            2 -> it.kind == MediaKind.REPLAY
            3 -> it.kind == MediaKind.SCREENSHOT
            else -> true
        } && (query.isBlank() || it.name.contains(query, ignoreCase = true))
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().height(64.dp).padding(start = if (searching) 4.dp else 16.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (searching) {
                IconButton(onClick = { searching = false; query = "" }) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Close search") }
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text("Search by name") }, modifier = Modifier.weight(1f)
                )
            } else {
                Text("Recordings", fontSize = 22.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                IconButton(onClick = { searching = true }) { Icon(Icons.Outlined.Search, "Search", tint = cs.onSurfaceVariant) }
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            items(filters.size) { i ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(filters[i]) })
            }
        }

        if (shown.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Outlined.VideoLibrary, null, tint = cs.outline, modifier = Modifier.size(48.dp))
                Text("Nothing here yet", fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 12.dp))
                Text("Record your screen or go live to see it here.", fontSize = 14.sp, color = cs.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(shown, key = { it.key }) { item ->
                    if (item.kind == MediaKind.REPLAY) ReplayCard(vm, item, actions, onRemove = { deleting = item })
                    else FileCard(vm, item, actions, onRename = { renaming = item }, onDelete = { deleting = item })
                }
            }
        }
    }

    renaming?.let { item ->
        var name by remember(item.key) { mutableStateOf(item.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = {
                    vm.rename(item, name) { ok -> if (!ok) SessionStore.toast("Could not rename this file") }
                    renaming = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } }
        )
    }

    deleting?.let { item ->
        val replay = item.kind == MediaKind.REPLAY
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(if (replay) "Remove from list?" else "Delete?") },
            text = {
                Text(if (replay) "The replay stays on your YouTube channel. It is only removed from this list."
                     else "\"${item.name}\" will be deleted from your phone.")
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.delete(item) { ok -> if (!ok) SessionStore.toast("Could not delete. Try from your Gallery app.") }
                    deleting = null
                }) { Text(if (replay) "Remove" else "Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ReplayCard(vm: MainViewModel, item: MediaItem, actions: AppActions, onRemove: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    Surface(
        shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerLowest,
        border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(170.dp).background(Color(0xFF2B2E45)).clickable { actions.open(item) }) {
                Text(
                    "LIVE REPLAY", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(10.dp).clip(RoundedCornerShape(6.dp)).background(Brand.LiveRed)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
                Box(
                    Modifier.align(Alignment.Center).size(56.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.9f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.PlayArrow, "Watch on YouTube", tint = Color(0xFF1B1B21)) }
                if (item.durationMs > 0) {
                    Text(
                        com.appforge.recorderlive.ui.components.formatDuration(item.durationMs / 1000),
                        color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp).clip(RoundedCornerShape(4.dp))
                            .background(Color(0xA6000000)).padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Row(Modifier.padding(start = 16.dp, top = 12.dp, end = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(item.name, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(mediaSubtitle(item), fontSize = 13.sp, color = cs.onSurfaceVariant)
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Outlined.MoreVert, "More options", tint = cs.onSurfaceVariant) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Watch on YouTube") }, onClick = { menu = false; actions.open(item) })
                        DropdownMenuItem(text = { Text("Share link") }, onClick = { menu = false; actions.share(item) })
                        DropdownMenuItem(text = { Text("Remove from list") }, onClick = { menu = false; onRemove() })
                    }
                }
            }
        }
    }
}

@Composable
private fun FileCard(vm: MainViewModel, item: MediaItem, actions: AppActions, onRename: () -> Unit, onDelete: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerLowest,
        border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { actions.open(item) },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MediaThumb(vm, item, 110.dp, 64.dp)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(item.name, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(mediaSubtitle(item), fontSize = 13.sp, color = cs.onSurfaceVariant)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ActionTile(Icons.Outlined.ContentCut, "Edit", cs.primary, Modifier.weight(1f)) { actions.edit(item) }
                ActionTile(Icons.Outlined.DriveFileRenameOutline, "Rename", cs.primary, Modifier.weight(1f), onRename)
                ActionTile(Icons.Outlined.Share, "Share", cs.primary, Modifier.weight(1f)) { actions.share(item) }
                ActionTile(Icons.Outlined.Delete, "Delete", cs.error, Modifier.weight(1f), onDelete)
            }
        }
    }
}

@Composable
private fun ActionTile(icon: ImageVector, label: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(56.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceContainer)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = color)
    }
}
