@file:Suppress("DEPRECATION")

package com.appforge.recorderlive.youtube

import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Google sign-in with permission to manage the user's YouTube live streams.
 * No Firebase and no google-services.json needed: only an "Android" OAuth client
 * (package name + SHA-1) in the Google Cloud project where YouTube Data API v3 is enabled.
 */
object YouTubeAccount {
    const val SCOPE = "https://www.googleapis.com/auth/youtube"

    private fun options() = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestEmail()
        .requestProfile()
        .requestScopes(Scope(SCOPE))
        .build()

    fun client(context: Context): GoogleSignInClient = GoogleSignIn.getClient(context, options())

    fun signInIntent(context: Context): Intent = client(context).signInIntent

    /** Signed-in account that has already allowed the YouTube permission, or null. */
    fun account(context: Context): GoogleSignInAccount? =
        GoogleSignIn.getLastSignedInAccount(context)?.takeIf { GoogleSignIn.hasPermissions(it, Scope(SCOPE)) }

    fun isSignedIn(context: Context) = account(context) != null

    /** Handles the result of [signInIntent]. Throws ApiException if the user cancelled or setup is wrong. */
    fun accountFromResult(data: Intent?): GoogleSignInAccount =
        GoogleSignIn.getSignedInAccountFromIntent(data).getResult(com.google.android.gms.common.api.ApiException::class.java)

    /**
     * Fresh access token for YouTube API calls (Google caches and refreshes it).
     * May throw UserRecoverableAuthException -> launch its intent so the user can tap Allow.
     */
    suspend fun token(context: Context): String = withContext(Dispatchers.IO) {
        val acc = account(context)?.account ?: throw IllegalStateException("Not signed in")
        GoogleAuthUtil.getToken(context.applicationContext, acc, "oauth2:$SCOPE")
    }

    suspend fun signOut(context: Context) {
        runCatching { client(context).signOut().await() }
    }
}
