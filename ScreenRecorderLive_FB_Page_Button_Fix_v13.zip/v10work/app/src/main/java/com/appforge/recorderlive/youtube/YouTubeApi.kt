package com.appforge.recorderlive.youtube

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class YouTubeException(val code: Int, val reason: String, message: String) : Exception(message) {
    /** Channel has not turned on live streaming in YouTube Studio (or is blocked from it). */
    val isLiveNotEnabled get() = reason == "liveStreamingNotEnabled" || reason == "insufficientLivePermissions"
}

data class Channel(val title: String, val avatarUrl: String?)
data class LiveSetup(val broadcastId: String, val streamId: String, val rtmpUrl: String)

/** Small YouTube Data API v3 client for live streaming. */
object YouTubeApi {
    private const val BASE = "https://www.googleapis.com/youtube/v3"

    class NoChannelException : Exception("This Google account has no YouTube channel yet")

    suspend fun myChannel(token: String): Channel {
        val json = call("GET", "$BASE/channels?part=snippet&mine=true", token)
        val items = json.optJSONArray("items")
        if (items == null || items.length() == 0) throw NoChannelException()
        val sn = items.getJSONObject(0).getJSONObject("snippet")
        val thumbs = sn.optJSONObject("thumbnails")
        val url = thumbs?.optJSONObject("medium")?.optString("url")
            ?: thumbs?.optJSONObject("default")?.optString("url")
        return Channel(sn.optString("title"), url)
    }

    /** Creates the broadcast + stream on the user's channel and links them. */
    suspend fun createLive(token: String, title: String, privacy: String, latency: String = "low"): LiveSetup {
        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date())

        val broadcastBody = JSONObject()
            .put("snippet", JSONObject().put("title", title.ifBlank { "Live from my phone" }).put("scheduledStartTime", now))
            .put("status", JSONObject().put("privacyStatus", privacy).put("selfDeclaredMadeForKids", false))
            .put("contentDetails", JSONObject()
                .put("enableAutoStart", true)
                .put("enableAutoStop", true)
                .put("latencyPreference", latency))
        val broadcast = call("POST", "$BASE/liveBroadcasts?part=snippet,status,contentDetails", token, broadcastBody)
        val broadcastId = broadcast.getString("id")

        val streamBody = JSONObject()
            .put("snippet", JSONObject().put("title", "Phone stream"))
            .put("cdn", JSONObject().put("ingestionType", "rtmp").put("resolution", "variable").put("frameRate", "variable"))
            .put("contentDetails", JSONObject().put("isReusable", false))
        val stream = call("POST", "$BASE/liveStreams?part=snippet,cdn,contentDetails", token, streamBody)
        val streamId = stream.getString("id")
        val ingestion = stream.getJSONObject("cdn").getJSONObject("ingestionInfo")
        val rtmp = ingestion.getString("ingestionAddress").trimEnd('/') + "/" + ingestion.getString("streamName")

        call("POST", "$BASE/liveBroadcasts/bind?id=$broadcastId&part=id,contentDetails&streamId=$streamId", token)
        return LiveSetup(broadcastId, streamId, rtmp)
    }

    /** Ends the broadcast (or deletes it if it never went live). Replay stays on the channel. */
    suspend fun endLive(token: String, broadcastId: String) {
        try {
            call("POST", "$BASE/liveBroadcasts/transition?broadcastStatus=complete&id=$broadcastId&part=status", token)
        } catch (e: YouTubeException) {
            runCatching { call("DELETE", "$BASE/liveBroadcasts?id=$broadcastId", token) }
        }
    }

    /** Current viewers, or null when YouTube doesn't report it yet. */
    suspend fun viewers(token: String, broadcastId: String): Int? {
        val json = call("GET", "$BASE/videos?part=liveStreamingDetails&id=$broadcastId", token)
        val items = json.optJSONArray("items") ?: return null
        if (items.length() == 0) return null
        val d = items.getJSONObject(0).optJSONObject("liveStreamingDetails") ?: return null
        return d.optString("concurrentViewers").toIntOrNull()
    }

    private suspend fun call(method: String, url: String, token: String, body: JSONObject? = null): JSONObject =
        withContext(Dispatchers.IO) {
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.requestMethod = method
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.setRequestProperty("Accept", "application/json")
                if (body != null) {
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    conn.outputStream.use { it.write(body.toString().toByteArray()) }
                } else if (method == "POST") {
                    conn.doOutput = true
                    conn.setFixedLengthStreamingMode(0)
                }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val err = runCatching { JSONObject(text).getJSONObject("error") }.getOrNull()
                    val reason = err?.optJSONArray("errors")?.optJSONObject(0)?.optString("reason").orEmpty()
                    throw YouTubeException(code, reason, err?.optString("message") ?: "YouTube error $code")
                }
                if (text.isBlank()) JSONObject() else JSONObject(text)
            } finally {
                conn.disconnect()
            }
        }

    @Suppress("unused")
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
