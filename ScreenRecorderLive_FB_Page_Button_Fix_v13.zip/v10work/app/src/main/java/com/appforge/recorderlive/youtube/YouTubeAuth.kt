package com.appforge.recorderlive.youtube

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.appforge.recorderlive.data.Prefs
import kotlinx.coroutines.suspendCancellableCoroutine
import net.openid.appauth.AuthState
import net.openid.appauth.AuthorizationException
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.AuthorizationResponse
import net.openid.appauth.AuthorizationService
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.ResponseTypeValues
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** The three ways the app can connect to YouTube. */
enum class AuthMode(val key: String) {
    NONE("none"),
    NATIVE("native"),  // Android Google sign-in (channel that belongs to the Gmail itself)
    WEB("web"),        // Google sign-in page in a Chrome tab (can choose brand channels)
    KEY("key");        // YouTube stream key, no sign-in

    companion object {
        fun from(key: String) = entries.firstOrNull { it.key == key } ?: NONE
    }
}

class SignInAgainException : Exception("Please connect your YouTube channel again")

/**
 * One place that knows how the user connected and how to get a fresh YouTube access token.
 */
object YouTubeAuth {

    /**
     * Android OAuth client ID from Google Cloud (Clients → "Recorder – GitHub key").
     * Web sign-in needs "Enable custom URI scheme" ticked on this client (Advanced settings).
     */
    const val WEB_CLIENT_ID = "759731609802-7j6daiuj0d1vd1lk3gl3ugg94pomblr2.apps.googleusercontent.com"
    private const val REDIRECT = "com.appforge.recorderlive:/oauth2redirect"
    private val config = AuthorizationServiceConfiguration(
        Uri.parse("https://accounts.google.com/o/oauth2/v2/auth"),
        Uri.parse("https://oauth2.googleapis.com/token")
    )

    fun mode(context: Context) = AuthMode.from(Prefs(context).authMode)
    fun isConnected(context: Context) = mode(context) != AuthMode.NONE

    /** RTMP address for stream-key mode. */
    fun streamKeyUrl(context: Context): String? =
        Prefs(context).streamKey?.takeIf { it.isNotBlank() }?.let { "rtmp://a.rtmp.youtube.com/live2/${it.trim()}" }

    // ---------------------------------------------------------------- web sign-in

    /** Intent that opens Google's sign-in page (account + brand channel picker) in a Chrome tab. */
    fun webSignInIntent(service: AuthorizationService): Intent {
        val request = AuthorizationRequest.Builder(config, WEB_CLIENT_ID, ResponseTypeValues.CODE, Uri.parse(REDIRECT))
            .setScopes(YouTubeAccount.SCOPE)
            .setPromptValues("select_account", "consent")
            .build()
        return service.getAuthorizationRequestIntent(request)
    }

    /** Finishes web sign-in: exchanges the code for tokens and saves them. */
    suspend fun completeWebSignIn(context: Context, service: AuthorizationService, data: Intent?) {
        val response = data?.let { AuthorizationResponse.fromIntent(it) }
        val error = data?.let { AuthorizationException.fromIntent(it) }
        if (response == null) throw error ?: IllegalStateException("Sign-in cancelled")
        val state = AuthState(response, error)
        val tokens = suspendCancellableCoroutine { cont ->
            service.performTokenRequest(response.createTokenExchangeRequest()) { tokenResponse, ex ->
                if (tokenResponse != null) cont.resume(tokenResponse)
                else cont.resumeWithException(ex ?: IllegalStateException("Could not finish sign-in"))
            }
        }
        state.update(tokens, null)
        val prefs = Prefs(context)
        prefs.webAuthState = state.jsonSerializeString()
        prefs.authMode = AuthMode.WEB.key
    }

    private suspend fun webToken(context: Context): String {
        val prefs = Prefs(context)
        val json = prefs.webAuthState ?: throw SignInAgainException()
        val state = runCatching { AuthState.jsonDeserialize(json) }.getOrNull() ?: throw SignInAgainException()
        val service = AuthorizationService(context.applicationContext)
        try {
            return suspendCancellableCoroutine { cont ->
                state.performActionWithFreshTokens(service) { accessToken, _, ex ->
                    // Save refreshed tokens
                    prefs.webAuthState = state.jsonSerializeString()
                    if (accessToken != null) cont.resume(accessToken)
                    else if (ex != null && ex.type == AuthorizationException.TYPE_OAUTH_TOKEN_ERROR) cont.resumeWithException(SignInAgainException())
                    else cont.resumeWithException(ex ?: SignInAgainException())
                }
            }
        } finally {
            service.dispose()
        }
    }

    // ---------------------------------------------------------------- common

    /** Fresh access token for the current connection (not used in stream-key mode). */
    suspend fun token(context: Context): String = when (mode(context)) {
        AuthMode.NATIVE -> YouTubeAccount.token(context)
        AuthMode.WEB -> webToken(context)
        AuthMode.KEY, AuthMode.NONE -> throw SignInAgainException()
    }

    /** Forget the YouTube connection (any mode). */
    suspend fun disconnect(context: Context) {
        val prefs = Prefs(context)
        if (mode(context) == AuthMode.NATIVE) YouTubeAccount.signOut(context)
        prefs.webAuthState = null
        prefs.streamKey = null
        prefs.authMode = AuthMode.NONE.key
    }
}
