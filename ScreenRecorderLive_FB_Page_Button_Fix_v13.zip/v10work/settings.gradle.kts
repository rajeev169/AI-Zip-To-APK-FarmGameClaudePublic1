pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // RootEncoder (screen capture + RTMP streaming) is published on JitPack
        maven("https://jitpack.io")
    }
}

rootProject.name = "ScreenRecorderLive"
include(":app")
