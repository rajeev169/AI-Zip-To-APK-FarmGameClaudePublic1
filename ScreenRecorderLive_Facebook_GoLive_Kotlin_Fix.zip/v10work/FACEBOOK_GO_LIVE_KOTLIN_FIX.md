# Facebook Go Live Kotlin compile fix

The GitHub Actions compiler reported unresolved references in `FacebookSetupScreen.kt` for `currentAccessToken`, `isExpired`, and `permissions`.

Updated the Facebook SDK calls to explicit Java method invocation:
- `AccessToken.getCurrentAccessToken()`
- `token.isExpired()`
- `token.getPermissions()`

This addresses the reported Kotlin reference-resolution errors. The archive has been checked for ZIP integrity. A full Gradle/Kotlin build has not been verified in this environment because the Gradle distribution download endpoint was unreachable; run the GitHub Actions build to confirm compilation.
