package com.appforge.recorderlive.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** All user choices, saved on the phone. Defaults follow the approved mockup. */
class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    // ---- Recording (Home + Settings) ----
    var recHeight: Int  // 720 or 1080
        get() = sp.getInt("rec_height", 1080)
        set(v) = sp.edit().putInt("rec_height", v).apply()
    var recFps: Int     // 30, 60, 90 or 120
        get() = sp.getInt("rec_fps", 60)
        set(v) = sp.edit().putInt("rec_fps", v).apply()
    var recMic: Boolean
        get() = sp.getBoolean("rec_mic", true)
        set(v) = sp.edit().putBoolean("rec_mic", v).apply()
    var recGameSound: Boolean
        get() = sp.getBoolean("rec_game_sound", true)
        set(v) = sp.edit().putBoolean("rec_game_sound", v).apply()
    var recBubble: Boolean
        get() = sp.getBoolean("rec_bubble", true)
        set(v) = sp.edit().putBoolean("rec_bubble", v).apply()
    var recFaceCam: Boolean
        get() = sp.getBoolean("rec_facecam", false)
        set(v) = sp.edit().putBoolean("rec_facecam", v).apply()

    /** Settings: menu closes after 3 s and the bubble shrinks to a faded dot while idle. */
    var bubbleAutoHide: Boolean
        get() = sp.getBoolean("bubble_auto_hide", false)
        set(v) = sp.edit().putBoolean("bubble_auto_hide", v).apply()

    /** Settings: keep the bubble on screen even when not recording, to start recording from any app. */
    var floatingBubble: Boolean
        get() = sp.getBoolean("floating_bubble", false)
        set(v) = sp.edit().putBoolean("floating_bubble", v).apply()

    /** Settings: bubble colour (ARGB). Default is the light red from the mockup. */
    var bubbleColor: Int
        get() = sp.getInt("bubble_color", 0xFFFF8A80.toInt())
        set(v) = sp.edit().putInt("bubble_color", v).apply()

    /** Settings: floating bubble menu panel. false = Light (default), true = Dark. */
    var bubbleMenuDark: Boolean
        get() = sp.getBoolean("bubble_menu_dark", false)
        set(v) = sp.edit().putBoolean("bubble_menu_dark", v).apply()

    // ---- YouTube connection: "none" | "native" | "web" | "key" ----
    var authMode: String
        get() = sp.getString("auth_mode", "none") ?: "none"
        set(v) = sp.edit().putString("auth_mode", v).apply()
    /** Saved Google web sign-in (AppAuth) state as JSON. */
    var webAuthState: String?
        get() = sp.getString("web_auth_state", null)
        set(v) = sp.edit().putString("web_auth_state", v).apply()
    var streamKey: String?
        get() = sp.getString("stream_key", null)
        set(v) = sp.edit().putString("stream_key", v).apply()

    var facebookRtmpServer: String
        get() = sp.getString("facebook_rtmp_server", "") ?: ""
        set(v) = sp.edit().putString("facebook_rtmp_server", v).apply()
    var facebookRtmpKey: String
        get() = sp.getString("facebook_rtmp_key", "") ?: ""
        set(v) = sp.edit().putString("facebook_rtmp_key", v).apply()

    // Facebook SDK keeps its own access token; these flags remember which setup step
    // the user completed so the screen can show the saved state after reopening.
    var facebookAccountConnected: Boolean
        get() = sp.getBoolean("facebook_account_connected", false)
        set(v) = sp.edit().putBoolean("facebook_account_connected", v).apply()
    var facebookPageAccessGranted: Boolean
        get() = sp.getBoolean("facebook_page_access_granted", false)
        set(v) = sp.edit().putBoolean("facebook_page_access_granted", v).apply()

    // ---- Go live setup ----
    var liveTitle: String
        get() = sp.getString("live_title", "Playing live from my phone") ?: ""
        set(v) = sp.edit().putString("live_title", v).apply()
    var livePrivacy: String // public | unlisted | private
        get() = sp.getString("live_privacy", "public") ?: "public"
        set(v) = sp.edit().putString("live_privacy", v).apply()
    var liveHeight: Int // 480 | 720 | 1080
        get() = sp.getInt("live_height", 720)
        set(v) = sp.edit().putInt("live_height", v).apply()
    var liveFps: Int // 30 or 60 (YouTube Live allows up to 60)
        get() = sp.getInt("live_fps", 30)
        set(v) = sp.edit().putInt("live_fps", v).apply()
    /** YouTube latency for signed-in lives: "normal" | "low" | "ultraLow". */
    var liveLatency: String
        get() = sp.getString("live_latency", "low") ?: "low"
        set(v) = sp.edit().putString("live_latency", v).apply()
    var liveLandscape: Boolean
        get() = sp.getBoolean("live_landscape", true)
        set(v) = sp.edit().putBoolean("live_landscape", v).apply()
    var liveGameSound: Boolean
        get() = sp.getBoolean("live_game_sound", true)
        set(v) = sp.edit().putBoolean("live_game_sound", v).apply()
    var liveMic: Boolean
        get() = sp.getBoolean("live_mic", true)
        set(v) = sp.edit().putBoolean("live_mic", v).apply()
    var liveFaceCam: Boolean
        get() = sp.getBoolean("live_facecam", true)
        set(v) = sp.edit().putBoolean("live_facecam", v).apply()
    var liveBubble: Boolean
        get() = sp.getBoolean("live_bubble", true)
        set(v) = sp.edit().putBoolean("live_bubble", v).apply()

    // ---- Live replays (saved on YouTube; we keep a small list to show in Recordings) ----
    fun replays(): List<Replay> {
        val arr = JSONArray(sp.getString("replays", "[]"))
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Replay(o.getString("id"), o.optString("title"), o.optLong("date"), o.optLong("sec"))
        }
    }

    fun addReplay(r: Replay) {
        val list = listOf(r) + replays().filter { it.id != r.id }
        saveReplays(list.take(200))
    }

    fun removeReplay(id: String) = saveReplays(replays().filter { it.id != id })

    private fun saveReplays(list: List<Replay>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("date", it.dateMs).put("sec", it.durationSec))
        }
        sp.edit().putString("replays", arr.toString()).apply()
    }
}

data class Replay(val id: String, val title: String, val dateMs: Long, val durationSec: Long) {
    val url get() = "https://youtu.be/$id"
}
