package com.appforge.recorderlive.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.facebook.AccessToken
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.appforge.recorderlive.data.Prefs

@Composable
fun FacebookSetupScreen(onBack: () -> Unit, onLogin: (Boolean) -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { Prefs(context) }
    var server by remember { mutableStateOf(prefs.facebookRtmpServer) }
    var key by remember { mutableStateOf(prefs.facebookRtmpKey) }
    var saved by remember { mutableStateOf(false) }
    var showGoLivePreview by remember { mutableStateOf(false) }
    var statusRefresh by remember { mutableIntStateOf(0) }
    val lifecycleOwner = LocalLifecycleOwner.current
    fun refreshFacebookStatus() {
        val token = AccessToken.currentAccessToken
        if (token != null && !token.isExpired) {
            prefs.facebookAccountConnected = true
            if (token.permissions.contains("pages_show_list")) prefs.facebookPageAccessGranted = true
        }
        statusRefresh++
    }
    LaunchedEffect(Unit) { refreshFacebookStatus() }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refreshFacebookStatus()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val accountConnected = remember(statusRefresh) { prefs.facebookAccountConnected }
    val pagePermissionGranted = remember(statusRefresh) { prefs.facebookPageAccessGranted }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
        Text("Facebook connection", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Choose how you want to connect Facebook for streaming.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("1. Facebook account", fontWeight = FontWeight.SemiBold)
            if (accountConnected) Text("✓ Connected — this status is saved on this device.", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            Text("Sign in with Facebook. The basic profile permission authenticates your account; it does not itself enable Live publishing.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = { onLogin(false) }, modifier = Modifier.fillMaxWidth()) { Text(if (accountConnected) "Reconnect Facebook account" else "Continue with Facebook") }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("2. Go Live", fontWeight = FontWeight.SemiBold)
                AssistChip(onClick = { showGoLivePreview = true }, label = { Text("Preview") })
            }
            Text("Start a broadcast to the Facebook Page you choose below.", style = MaterialTheme.typography.bodySmall)
            Button(
                onClick = { showGoLivePreview = true },
                enabled = false,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Go Live") }
            Text(
                "Connect and select a Facebook Page first. Live publishing and encoder integration are not active in this build.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("3. Facebook Page", fontWeight = FontWeight.SemiBold)
            if (pagePermissionGranted) Text("✓ Page-list permission granted and remembered.", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            Text("This confirms permission to request your Page list. It does not yet mean a Page has been retrieved or selected inside ScreenRecorderLive.", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { onLogin(true) }, modifier = Modifier.fillMaxWidth()) { Text(if (pagePermissionGranted) "Refresh Facebook Page permission" else "Connect Facebook Page") }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("4. RTMPS stream key", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(server, { server = it; saved = false }, label = { Text("RTMPS Server URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(key, { key = it; saved = false }, label = { Text("Stream Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = { prefs.facebookRtmpServer = server.trim(); prefs.facebookRtmpKey = key.trim(); saved = true }, modifier = Modifier.fillMaxWidth(), enabled = server.startsWith("rtmps://") && key.isNotBlank()) { Text("Save RTMPS details") }
            if (saved) Text("RTMPS details saved on this device. Streaming output wiring is not active yet.", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        } }
        Text("Your Facebook login and Page-list permission status will remain visible when you reopen the app. Actual Page retrieval/selection, Facebook Live publishing, and multi-platform streaming still need Graph API and encoder integration.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (showGoLivePreview) {
        AlertDialog(
            onDismissRequest = { showGoLivePreview = false },
            title = { Text("Facebook Live preview") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("The finished workflow will let you enter a stream title, review your broadcast settings, preview your screen, and then start the broadcast.")
                    Text("For now, this is a preview only. A Facebook Page has not yet been retrieved and selected inside the app, and the encoder is not connected to Facebook Live.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = { showGoLivePreview = false }) { Text("Got it") }
            }
        )
    }
}
