# Facebook SDK compatibility review and Kotlin fix

Project dependency: `com.facebook.android:facebook-login:18.2.3`.

## AccessToken Kotlin API usage

The SDK exposes Java-style getters. Kotlin accesses these as properties:
- `AccessToken.getCurrentAccessToken()`
- `token.isExpired` (Boolean property; do not call it as a function)
- `token.permissions` (Set property; do not call `getPermissions()` as a function)

## Login callback flow

Updated `MainActivity` to use the AndroidX Activity Result overload:
`logInWithReadPermissions(this, facebookCallbackManager, permissions)`.
The legacy `onActivityResult` override and manual `CallbackManager.onActivityResult` forwarding were removed.

The Page permission flag is reset when a new Page-permission login starts, and refreshed from the active token's permission set when the Facebook setup screen resumes. This records permission only; it does not retrieve or select a Facebook Page and does not enable Facebook Live publishing.

## Verification status

Source-level review and ZIP integrity checks are performed for this update. A successful Gradle compile/APK build is only claimed if the build command completes successfully in an environment with the required Gradle distribution and dependencies.
