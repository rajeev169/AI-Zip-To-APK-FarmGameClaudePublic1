# Material 3 Expressive redesign (v1.6.0)

- New `ui/components/Expressive.kt`: Tone colours, TonalCard, ToneSurface, StepBadge/StepHeader, ExpressiveButton (pill with solid bottom edge, squashes on press), RecordBlob.
- `ui/theme/Theme.kt`: new violet/pink/mint/amber palette (light + dark) and larger corner shapes.
- Restyled screens: Home, Connect, Facebook connection (4 colour-coded steps, masked stream key with Show/Hide).
- Removed stale "preview only / not active yet" text from the Facebook screen.
- versionCode 11, versionName 1.6.0.

Not yet restyled: Live/Starting screens, Recordings, Settings, YouTube setup screens (they pick up the new theme colours and shapes automatically).

Build verification: not compiled in the authoring environment (no network). Run the GitHub Actions build before installing.
