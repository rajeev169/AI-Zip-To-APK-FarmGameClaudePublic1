package com.appforge.recorderlive.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.ui.theme.Brand

/** The app logo: a screen with a record dot and live broadcast waves (drawn on a 120 grid). */
@Composable
fun AppLogo(size: Dp, modifier: Modifier = Modifier, round: Boolean = false) {
    Canvas(modifier.size(size)) {
        val u = this.size.width / 120f
        if (round) drawCircle(Brand.Primary)
        else drawRoundRect(Brand.Primary, cornerRadius = CornerRadius(28 * u, 28 * u))
        val stroke = Stroke(width = 6 * u, cap = StrokeCap.Round)
        drawRoundRect(
            Color.White, topLeft = Offset(20 * u, 34 * u), size = Size(58 * u, 52 * u),
            cornerRadius = CornerRadius(11 * u, 11 * u), style = Stroke(6 * u)
        )
        if (!round) drawRoundRect(
            Color.White, topLeft = Offset(40 * u, 86 * u), size = Size(18 * u, 6 * u),
            cornerRadius = CornerRadius(3 * u, 3 * u)
        )
        drawCircle(Brand.Record, radius = 12 * u, center = Offset(49 * u, 60 * u))
        drawArc(
            Color.White, startAngle = -45f, sweepAngle = 90f, useCenter = false,
            topLeft = Offset((88 - 12.7f - 18) * u, (60 - 18) * u), size = Size(36 * u, 36 * u), style = stroke
        )
        drawArc(
            Color.White.copy(alpha = 0.7f), startAngle = -47f, sweepAngle = 94f, useCenter = false,
            topLeft = Offset((76.6f - 30) * u, (60 - 30) * u), size = Size(60 * u, 60 * u), style = stroke
        )
    }
}

/** Light red round bubble with a video camera, as chosen for the floating bubble. */
@Composable
fun BubbleIcon(size: Dp, modifier: Modifier = Modifier, color: Color = Brand.Bubble) {
    Box(
        modifier.size(size).clip(CircleShape).background(color),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Outlined.Videocam, null, tint = bubbleIconTint(color), modifier = Modifier.size(size * 0.5f))
    }
}

/** Dark icon on light bubbles, white icon on dark bubbles, so the camera always shows. */
fun bubbleIconTint(color: Color): Color = when {
    color == Brand.Bubble -> Brand.BubbleIcon
    color.luminance() > 0.5f -> Color(0xFF1B1B21)
    else -> Color.White
}

/** The 8 bubble colours offered in Settings. */
val BubbleColors = listOf(
    0xFFFF8A80.toInt(), // light red (default)
    0xFFE53935.toInt(), // red
    0xFF1E88E5.toInt(), // blue
    0xFF43A047.toInt(), // green
    0xFF8E24AA.toInt(), // purple
    0xFFFB8C00.toInt(), // orange
    0xFF212121.toInt(), // black
    0xFFFFFFFF.toInt(), // white
)

/** Material 3 segmented button row like in the mockup. */
@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(20.dp))
            .border(1.dp, cs.outline, RoundedCornerShape(20.dp))
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            if (i > 0) Box(Modifier.size(1.dp, 40.dp).background(cs.outline))
            Box(
                Modifier.weight(1f).height(40.dp)
                    .background(if (on) cs.secondaryContainer else Color.Transparent)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    color = if (on) cs.onSecondaryContainer else cs.onSurface
                )
            }
        }
    }
}

@Composable
fun LabeledSection(label: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}

@Composable
fun LivePill(modifier: Modifier = Modifier, text: String = "LIVE") {
    val shape = RoundedCornerShape(50)
    Box(modifier.clip(shape).background(Color(0xFF9E1229))) {
        Row(
            Modifier.padding(bottom = 3.dp).clip(shape).background(Brand.LiveRed).padding(horizontal = 12.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White))
            Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        }
    }
}

fun formatDuration(totalSec: Long): String {
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%02d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}


/** Frame-rate dropdown: unsupported choices are greyed out with the reason. */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun FpsDropdown(
    label: String,
    options: List<com.appforge.recorderlive.data.FpsOption>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    androidx.compose.material3.ExposedDropdownMenuBox(
        expanded = expanded, onExpandedChange = { expanded = it }, modifier = modifier.fillMaxWidth()
    ) {
        androidx.compose.material3.OutlinedTextField(
            value = "$selected fps", onValueChange = {}, readOnly = true,
            label = { Text(label) },
            trailingIcon = { androidx.compose.material3.ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.fillMaxWidth()
                .menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable)
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { o ->
                androidx.compose.material3.DropdownMenuItem(
                    enabled = o.supported,
                    text = {
                        Column(Modifier.padding(vertical = 4.dp)) {
                            Text("${o.fps} fps", fontWeight = if (o.fps == selected) FontWeight.Medium else FontWeight.Normal)
                            if (o.reason != null) Text(
                                o.reason, fontSize = 12.sp, lineHeight = 16.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    onClick = { expanded = false; onSelect(o.fps) }
                )
            }
        }
    }
}
