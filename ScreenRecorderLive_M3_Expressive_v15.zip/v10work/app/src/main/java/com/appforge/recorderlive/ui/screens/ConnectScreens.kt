package com.appforge.recorderlive.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.SwitchAccount
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.ConnectResult
import com.appforge.recorderlive.ui.components.AppLogo
import com.appforge.recorderlive.ui.components.ButtonVariant
import com.appforge.recorderlive.ui.components.ExpressiveButton
import com.appforge.recorderlive.ui.components.ExpressiveButtonText
import androidx.compose.material3.LocalContentColor
import com.appforge.recorderlive.ui.theme.Brand

/** Screen 1 of the live flow: shown when Live is tapped and no YouTube connection is set up. */
@Composable
fun ConnectScreen(
    onClose: () -> Unit,
    onGoogle: (done: (ConnectResult) -> Unit) -> Unit,
    onBrandChannel: (done: (ConnectResult) -> Unit) -> Unit,
    onStreamKey: () -> Unit,
    onFacebook: () -> Unit = {},
) {
    val cs = MaterialTheme.colorScheme
    var busy by remember { mutableStateOf(false) }
    var noChannel by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.height(64.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Outlined.Close, "Close") }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Box(Modifier.size(110.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
                AppLogo(72.dp)
            }
            Text("Go live", fontSize = 30.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
            Text(
                "Connect YouTube or Facebook once to stream your games and screen.",
                fontSize = 16.sp, color = cs.onSurfaceVariant, textAlign = TextAlign.Center, lineHeight = 24.sp
            )
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainer).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                InfoRow(Icons.Outlined.Check, Brand.Good, "Starts and ends live streams on your channel")
                InfoRow(Icons.Outlined.Check, Brand.Good, "Shows your channel name and viewer count")
                InfoRow(Icons.Outlined.Lock, cs.primary, "Never posts or deletes anything else. Sign out any time in settings.", muted = true)
            }
        }
        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ExpressiveButton(
                onClick = {
                    busy = true
                    onGoogle { r -> busy = false; if (r == ConnectResult.NO_CHANNEL) noChannel = true }
                },
                enabled = !busy, modifier = Modifier.fillMaxWidth()
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = LocalContentColor.current, strokeWidth = 2.dp)
                else { Icon(Icons.Outlined.AccountCircle, null); Text("Continue with Google", fontSize = 16.sp, fontWeight = FontWeight.Medium) }
            }
            ExpressiveButton(
                onClick = { busy = true; onBrandChannel { busy = false } },
                variant = ButtonVariant.Tonal, enabled = !busy, modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Outlined.SwitchAccount, null)
                Text("Choose a brand channel", fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
            ExpressiveButtonText("Continue with Facebook", onClick = onFacebook, variant = ButtonVariant.Facebook, enabled = !busy, modifier = Modifier.fillMaxWidth())
            ExpressiveButton(onClick = onStreamKey, variant = ButtonVariant.Tonal, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Key, null, modifier = Modifier.size(18.dp))
                Text("Use a stream key", fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
            TextButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) {
                Text("Not now — just record", fontSize = 14.sp, color = cs.onSurfaceVariant)
            }
        }
    }

    if (noChannel) {
        AlertDialog(
            onDismissRequest = { noChannel = false },
            icon = { Icon(Icons.Outlined.SwitchAccount, null) },
            title = { Text("No channel on this account") },
            text = {
                Text("This Google account has no channel of its own. If your channel is a brand channel (made under your Gmail), choose it on the next screen.")
            },
            confirmButton = {
                TextButton(onClick = { noChannel = false; busy = true; onBrandChannel { busy = false } }) { Text("Choose a brand channel") }
            },
            dismissButton = { TextButton(onClick = { noChannel = false }) { Text("Cancel") } }
        )
    }
}

/** Stream-key setup: works for any channel, no sign-in. */
@Composable
fun StreamKeyScreen(initialKey: String?, onBack: () -> Unit, onOpenStudio: () -> Unit, onSave: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var key by remember { mutableStateOf(initialKey.orEmpty()) }
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.height(64.dp).padding(start = 4.dp, end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back") }
            Text("Stream key", fontSize = 22.sp, fontWeight = FontWeight.Medium)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text(
                "Works with any channel, including brand channels. No sign-in needed.",
                fontSize = 15.sp, color = cs.onSurfaceVariant, lineHeight = 22.sp
            )
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainer).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                listOf(
                    "Open YouTube Studio on the channel you want",
                    "Tap Create → Go live → Stream",
                    "Copy the Stream key and paste it below"
                ).forEachIndexed { i, step ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(26.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                            Text("${i + 1}", color = cs.onPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                        Text(step, fontSize = 14.sp)
                    }
                }
            }
            OutlinedButton(onClick = onOpenStudio, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Text("Open YouTube Studio")
            }
            OutlinedTextField(
                value = key, onValueChange = { key = it.trim() },
                label = { Text("Stream key") }, singleLine = true,
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { show = !show }) {
                        Icon(if (show) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility, if (show) "Hide key" else "Show key")
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Keep your key private: anyone with it can stream to your channel. In this mode the title and who can watch are set in YouTube Studio, and viewer count isn't shown.",
                fontSize = 13.sp, color = cs.onSurfaceVariant, lineHeight = 19.sp
            )
        }
        Button(
            onClick = { onSave(key) }, enabled = key.length >= 8,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp).fillMaxWidth().height(56.dp)
        ) { Text("Save", fontSize = 16.sp) }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, tint: Color, text: String, muted: Boolean = false) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Text(text, fontSize = 14.sp, lineHeight = 20.sp,
            color = if (muted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
    }
}

/** Shown when YouTube says this channel can't live stream yet. */
@Composable
fun NotEnabledScreen(channelName: String?, onClose: () -> Unit, onOpenStudio: () -> Unit, onCheckAgain: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.height(64.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Outlined.Close, "Close") }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Box(Modifier.size(112.dp).clip(CircleShape).background(Color(0xFFFFDEA6)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Schedule, null, tint = Color(0xFF5C4300), modifier = Modifier.size(52.dp))
            }
            Text("Live streaming isn't on yet", fontSize = 26.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
            Text(
                "${channelName ?: "Your"}${if (channelName != null) "'s" else ""} channel needs live streaming turned on in YouTube Studio. It's a one-time step and can take up to 24 hours.",
                fontSize = 16.sp, color = cs.onSurfaceVariant, textAlign = TextAlign.Center, lineHeight = 24.sp
            )
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainer).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                listOf("Open YouTube Studio", "Verify with your phone number", "Come back and tap \"Check again\"")
                    .forEachIndexed { i, s ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(26.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                                Text("${i + 1}", color = cs.onPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            }
                            Text(s, fontSize = 14.sp)
                        }
                    }
            }
            Text("You can still record your screen meanwhile.", fontSize = 13.sp, color = cs.onSurfaceVariant)
        }
        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onOpenStudio, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("Open YouTube Studio", fontSize = 16.sp) }
            OutlinedButton(onClick = onCheckAgain, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Check again", fontSize = 15.sp) }
        }
    }
}
