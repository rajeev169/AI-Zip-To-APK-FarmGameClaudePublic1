package com.appforge.recorderlive.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.appforge.recorderlive.CrashReporter
import com.appforge.recorderlive.data.FacebookPageOption
import com.appforge.recorderlive.data.Prefs
import com.appforge.recorderlive.ui.components.ButtonVariant
import com.appforge.recorderlive.ui.components.ExpressiveButtonText
import com.appforge.recorderlive.ui.components.StepHeader
import com.appforge.recorderlive.ui.components.TonalCard
import com.appforge.recorderlive.ui.components.Tone
import com.appforge.recorderlive.ui.components.toneColors
import com.facebook.AccessToken

@Composable
fun FacebookSetupScreen(
    onBack: () -> Unit,
    onLogin: (Boolean, (List<FacebookPageOption>, String?) -> Unit) -> Unit,
    onSelectPage: (FacebookPageOption) -> Boolean,
    onRemovePage: () -> Unit,
    onStartLive: () -> Unit
) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val prefs = remember(context) { Prefs(context) }
    var server by remember { mutableStateOf(prefs.facebookRtmpServer) }
    var key by remember { mutableStateOf(prefs.facebookRtmpKey) }
    var showKey by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    var statusRefresh by remember { mutableIntStateOf(0) }
    var pages by remember { mutableStateOf<List<FacebookPageOption>>(emptyList()) }
    var selectedPageId by remember { mutableStateOf(prefs.facebookSelectedPageId) }
    var selectedPageName by remember { mutableStateOf(prefs.facebookSelectedPageName) }
    var pageSaveMessage by remember { mutableStateOf<String?>(null) }
    var pagesLoading by remember { mutableStateOf(false) }
    var pageError by remember { mutableStateOf<String?>(null) }
    var pageListLoaded by remember { mutableStateOf(false) }
    var showRemovePageConfirmation by remember { mutableStateOf(false) }
    val lifecycleOwner = LocalLifecycleOwner.current

    fun refreshFacebookStatus() {
        val token = AccessToken.getCurrentAccessToken()
        if (token != null && !token.isExpired) {
            prefs.facebookAccountConnected = true
            prefs.facebookPageAccessGranted = token.permissions.contains("pages_show_list")
        }
        statusRefresh++
    }
    LaunchedEffect(Unit) { refreshFacebookStatus() }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refreshFacebookStatus()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val accountConnected = remember(statusRefresh) { prefs.facebookAccountConnected }
    val pagePermissionGranted = remember(statusRefresh) { prefs.facebookPageAccessGranted }
    val mint = toneColors(Tone.Mint)
    val fieldShape = RoundedCornerShape(16.dp)
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = cs.surfaceContainerLowest,
        unfocusedContainerColor = cs.surfaceContainerLowest
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
        Text("Facebook\nconnection", fontSize = 32.sp, lineHeight = 36.sp, fontWeight = FontWeight.Medium)
        Text("Four short steps to stream your screen to a Facebook Page.", color = cs.onSurfaceVariant)

        // 1. Account
        TonalCard(Tone.Violet) {
            StepHeader(1, "Account", Tone.Violet)
            if (accountConnected) Text("✓ Connected on this device", fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Text("Sign in with Facebook. The basic profile permission only identifies your account; it doesn't enable Live publishing.", fontSize = 13.sp)
            ExpressiveButtonText(
                if (accountConnected) "Reconnect Facebook account" else "Continue with Facebook",
                onClick = { onLogin(false) { _, _ -> } },
                variant = ButtonVariant.Facebook,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 2. Go Live
        TonalCard(Tone.Pink) {
            StepHeader(2, "Go Live", Tone.Pink)
            Text("Start a broadcast to the Facebook Page you choose below.", fontSize = 13.sp)
            val facebookReady = !prefs.facebookSelectedPageId.isNullOrBlank() &&
                prefs.facebookRtmpServer.trim().startsWith("rtmps://", ignoreCase = true) &&
                prefs.facebookRtmpKey.isNotBlank()
            ExpressiveButtonText(
                "Go Live on Facebook",
                onClick = onStartLive,
                enabled = facebookReady,
                variant = ButtonVariant.Live,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "This sends your screen to the RTMPS stream key saved in step 4. Create the broadcast in Facebook Live Producer first, then press Go Live there after the preview appears.",
                fontSize = 12.sp
            )
        }

        // 3. Page
        TonalCard(Tone.Mint) {
            StepHeader(3, "Facebook Page", Tone.Mint)
            if (pagePermissionGranted) Text("✓ Page-list permission granted", fontWeight = FontWeight.Medium, fontSize = 13.sp)
            selectedPageName?.let { name ->
                Text("Saved Page: $name", fontWeight = FontWeight.Medium)
                ExpressiveButtonText("Remove saved Page", onClick = { showRemovePageConfirmation = true }, variant = ButtonVariant.Tonal, modifier = Modifier.fillMaxWidth())
                Text("Remove this Page if it can't go Live, then load and save another Page you manage.", fontSize = 12.sp)
            }
            pageSaveMessage?.let { Text(it, fontWeight = FontWeight.Medium, fontSize = 13.sp) }
            Text("Connect to retrieve the Pages you manage, then pick the one ScreenRecorderLive should use.", fontSize = 13.sp)
            ExpressiveButtonText(
                if (pagesLoading) "Loading Facebook Pages…" else if (selectedPageName != null) "Add or change Facebook Page" else if (pagePermissionGranted) "Load Facebook Pages" else "Connect and load Pages",
                onClick = {
                    pagesLoading = true
                    pageError = null
                    pageSaveMessage = null
                    pageListLoaded = false
                    pages = emptyList()
                    try {
                        onLogin(true) { result, error ->
                            pages = result
                            pageError = error
                            pageListLoaded = true
                            pagesLoading = false
                            if (result.isNotEmpty()) {
                                selectedPageId = result.firstOrNull { it.id == prefs.facebookSelectedPageId }?.id ?: result.first().id
                            }
                        }
                    } catch (error: Exception) {
                        pagesLoading = false
                        pageListLoaded = true
                        pageError = error.localizedMessage ?: "Could not open Facebook Page selection. Please try again."
                        CrashReporter.recordException(context, "Starting Facebook Page selection failed", error)
                    }
                },
                enabled = !pagesLoading,
                variant = ButtonVariant.Tonal,
                modifier = Modifier.fillMaxWidth()
            )
            if (pagesLoading) {
                LinearProgressIndicator(
                    Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = mint.accent, trackColor = cs.surfaceContainerLowest
                )
                Text("Contacting Facebook and retrieving Pages you manage…", fontSize = 12.sp)
            }
            if (pageError != null) Text(pageError ?: "", color = cs.error, fontSize = 13.sp)
            if (pageListLoaded && pages.isEmpty() && pageError == null) Text("No Facebook Pages were returned for this account.", fontSize = 13.sp)
            pages.forEach { page ->
                val selected = selectedPageId == page.id
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(cs.surfaceContainerLowest)
                        .border(if (selected) 2.dp else 1.dp, if (selected) mint.accent else cs.outlineVariant, RoundedCornerShape(16.dp))
                        .clickable { selectedPageId = page.id }
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = selected, onClick = { selectedPageId = page.id })
                    Column(Modifier.weight(1f)) {
                        Text(page.name, fontWeight = FontWeight.Medium, color = cs.onSurface)
                        Text("Page ID: ${page.id}", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    }
                }
            }
            if (pages.isNotEmpty()) {
                ExpressiveButtonText(
                    "Save selected Page",
                    onClick = {
                        val page = pages.firstOrNull { it.id == selectedPageId }
                        if (page != null) {
                            pageSaveMessage = null
                            if (onSelectPage(page)) {
                                selectedPageName = page.name
                                pageSaveMessage = "✓ ${page.name} saved. Continue to step 4."
                            } else {
                                pageSaveMessage = "Page could not be saved. Check the error message and try again."
                            }
                        }
                    },
                    enabled = pages.any { it.id == selectedPageId },
                    variant = ButtonVariant.Success,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // 4. RTMPS
        TonalCard(Tone.Amber) {
            StepHeader(4, "RTMPS stream key", Tone.Amber)
            OutlinedTextField(
                server, { server = it; saved = false },
                label = { Text("RTMPS Server URL") }, shape = fieldShape, colors = fieldColors,
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            OutlinedTextField(
                key, { key = it; saved = false },
                label = { Text("Stream Key") }, shape = fieldShape, colors = fieldColors,
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") } }
            )
            ExpressiveButtonText(
                "Save RTMPS details",
                onClick = {
                    runCatching {
                        prefs.facebookRtmpServer = server.trim()
                        prefs.facebookRtmpKey = key.trim()
                        saved = true
                    }.onFailure { error ->
                        saved = false
                        CrashReporter.recordException(context, "Saving Facebook RTMPS settings failed", error)
                    }
                },
                enabled = server.startsWith("rtmps://") && key.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            )
            if (saved) Text("✓ Saved on this device. Keep the stream key private.", fontWeight = FontWeight.Medium, fontSize = 13.sp)
        }

        Text(
            "The selected Page ID is saved on this device and its Page access token is encrypted with Android Keystore.",
            fontSize = 12.sp, color = cs.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))
    }

    if (showRemovePageConfirmation) {
        AlertDialog(
            onDismissRequest = { showRemovePageConfirmation = false },
            title = { Text("Remove saved Facebook Page?") },
            text = { Text("This removes the saved Page selection and its encrypted Page access token from this device. Your Facebook account connection and RTMPS settings will remain, so you can add another Page.") },
            confirmButton = {
                TextButton(onClick = {
                    onRemovePage()
                    selectedPageId = ""
                    selectedPageName = null
                    pageSaveMessage = "Saved Page removed. Load Facebook Pages and select another Page."
                    showRemovePageConfirmation = false
                }) { Text("Remove Page", color = cs.error) }
            },
            dismissButton = {
                TextButton(onClick = { showRemovePageConfirmation = false }) { Text("Cancel") }
            }
        )
    }
}
