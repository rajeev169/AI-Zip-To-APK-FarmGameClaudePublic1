package com.appforge.recorderlive.ui.screens

import android.Manifest
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.AppActions
import com.appforge.recorderlive.MainViewModel
import com.appforge.recorderlive.R
import com.appforge.recorderlive.service.Mode
import com.appforge.recorderlive.service.SessionStore
import com.appforge.recorderlive.ui.components.AppLogo
import com.appforge.recorderlive.ui.components.BubbleIcon
import com.appforge.recorderlive.ui.components.formatDuration
import com.appforge.recorderlive.ui.components.ExpressiveButtonText
import com.appforge.recorderlive.ui.components.RecordBlob
import com.appforge.recorderlive.ui.components.TonalCard
import com.appforge.recorderlive.ui.components.Tone
import com.appforge.recorderlive.ui.components.ToneSurface
import com.appforge.recorderlive.ui.components.toneColors
import androidx.compose.material.icons.outlined.Videocam
import com.appforge.recorderlive.ui.theme.Brand

@Composable
fun HomeScreen(
    vm: MainViewModel,
    actions: AppActions,
    onGoLive: () -> Unit,
    onSeeAll: () -> Unit,
    onSettings: () -> Unit,
) {
    val prefs = vm.prefs
    val session by SessionStore.state.collectAsState()
    val media by vm.media.collectAsState()
    var bubble by remember { mutableStateOf(prefs.recBubble) }
    var faceCam by remember { mutableStateOf(prefs.recFaceCam) }
    var mic by remember { mutableStateOf(prefs.recMic) }
    val recording = session.mode == Mode.RECORD
    val live = session.mode == Mode.LIVE
    val cs = MaterialTheme.colorScheme

    Column(Modifier.fillMaxSize()) {
        // Top app bar
        Row(
            Modifier.fillMaxWidth().height(64.dp).padding(start = 16.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AppLogo(32.dp)
            Text(stringResource(R.string.app_name), fontSize = 22.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, "Settings", tint = cs.onSurfaceVariant) }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Record hero card
            TonalCard(Tone.Neutral) {
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    RecordBlob(
                        size = 132.dp,
                        color = if (live) cs.outline else Brand.Record,
                        edge = if (live) cs.outlineVariant else Brand.RecordEdge,
                        enabled = !live,
                        onClickLabel = if (recording) "Stop recording" else "Start recording",
                        onClick = { if (recording) actions.stopSession() else actions.startRecording() }
                    ) {
                        if (recording) Box(Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Color.White))
                        else Icon(Icons.Outlined.Videocam, null, tint = Color.White, modifier = Modifier.size(48.dp))
                    }
                    Text(
                        when {
                            live -> "Live in progress"
                            recording -> if (session.paused) "Paused · ${formatDuration(session.elapsedSec)}"
                                         else "Recording · ${formatDuration(session.elapsedSec)}"
                            else -> "Start recording"
                        },
                        fontSize = 22.sp, fontWeight = FontWeight.Medium, color = cs.onSurface
                    )
                    if (recording) {
                        Text("Tap to stop and save", fontSize = 14.sp, color = cs.onSurfaceVariant)
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip("${prefs.recHeight}p")
                            Chip("${prefs.recFps} fps")
                            Chip(if (mic) "Mic on" else "Mic off")
                        }
                    }
                }
            }

            // Go live card
            TonalCard(Tone.Violet) {
                val vc = toneColors(Tone.Violet)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(Modifier.size(52.dp).clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = 0.7f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.Sensors, null, tint = vc.accent, modifier = Modifier.size(28.dp))
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(if (live) "You're live" else "Go live", fontSize = 17.sp, fontWeight = FontWeight.Medium)
                        Text("YouTube or Facebook", fontSize = 13.sp)
                    }
                }
                ExpressiveButtonText(if (live) "Open" else "Go live", onClick = onGoLive, enabled = !recording, modifier = Modifier.fillMaxWidth())
            }

            // Quick toggles
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickTile(
                    label = "Bubble", on = bubble, modifier = Modifier.weight(1f),
                    icon = { BubbleIcon(28.dp, color = Color(SessionStore.bubbleColor.collectAsState().value)) }
                ) {
                    val v = !bubble
                    if (v) actions.ensureOverlay()
                    bubble = v; prefs.recBubble = v
                }
                QuickTile(
                    label = "Face-cam", on = faceCam, modifier = Modifier.weight(1f),
                    icon = { TileIcon(Icons.Outlined.Face, faceCam, Tone.Mint) }
                ) {
                    val v = !faceCam
                    if (v) actions.ensurePermissions(listOf(Manifest.permission.CAMERA)) { actions.ensureOverlay() }
                    faceCam = v; prefs.recFaceCam = v
                }
                QuickTile(
                    label = "Mic", on = mic, modifier = Modifier.weight(1f),
                    icon = { TileIcon(if (mic) Icons.Outlined.Mic else Icons.Outlined.MicOff, mic, Tone.Amber) }
                ) {
                    val v = !mic
                    if (v) actions.ensurePermissions(listOf(Manifest.permission.RECORD_AUDIO)) {}
                    mic = v; prefs.recMic = v
                }
            }

            // Recent
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Recent", fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                TextButton(onClick = onSeeAll) { Text("See all") }
            }
            val recent = media.take(3)
            if (recent.isEmpty()) {
                Text(
                    "Your recordings, live replays and screenshots will show here.",
                    fontSize = 14.sp, color = cs.onSurfaceVariant
                )
            }
            recent.forEach { item ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { actions.open(item) },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MediaThumb(vm, item, 96.dp, 56.dp)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(item.name, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(mediaSubtitle(item), fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun Chip(text: String) {
    Text(
        text, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceContainerLowest)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
private fun TileIcon(icon: ImageVector, on: Boolean, tone: Tone) {
    Icon(icon, null, tint = if (on) toneColors(tone).accent else MaterialTheme.colorScheme.outline, modifier = Modifier.size(24.dp))
}

@Composable
private fun QuickTile(label: String, on: Boolean, modifier: Modifier, icon: @Composable () -> Unit, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val tone = when (label) { "Bubble" -> Tone.Pink; "Face-cam" -> Tone.Mint; else -> Tone.Amber }
    val c = toneColors(tone)
    ToneSurface(
        container = if (on) c.container else cs.surfaceContainer,
        edge = if (on) c.edge else cs.outlineVariant,
        shape = RoundedCornerShape(22.dp),
        modifier = modifier.height(88.dp),
        onClick = onClick, role = Role.Switch, onClickLabel = label
    ) {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            icon()
            Spacer(Modifier.height(6.dp))
            Text("$label · ${if (on) "On" else "Off"}", fontSize = 13.sp, fontWeight = FontWeight.Medium,
                color = if (on) c.onContainer else cs.onSurfaceVariant)
        }
    }
}
