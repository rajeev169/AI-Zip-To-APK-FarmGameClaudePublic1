package com.appforge.recorderlive.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CenterFocusWeak
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.automirrored.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.AppActions
import com.appforge.recorderlive.service.CaptureService
import com.appforge.recorderlive.service.ErrorKind
import com.appforge.recorderlive.service.Mode
import com.appforge.recorderlive.service.Phase
import com.appforge.recorderlive.service.SessionStore
import com.appforge.recorderlive.ui.components.AppLogo
import com.appforge.recorderlive.ui.components.LivePill
import com.appforge.recorderlive.ui.components.ButtonVariant
import com.appforge.recorderlive.ui.components.ExpressiveButtonText
import com.appforge.recorderlive.ui.components.ToneSurface
import androidx.compose.foundation.layout.width
import androidx.compose.ui.semantics.Role
import com.appforge.recorderlive.ui.components.formatDuration
import com.appforge.recorderlive.ui.theme.Brand
import kotlinx.coroutines.delay

private val Night = Color(0xFF1B1B21)
private val NightCard = Color(0xFF2A2A33)
private val NightMuted = Color(0xFFC6C5D0)

/** 3-2-1 countdown with the "created → connected → ready" checklist. */
@Composable
fun StartingScreen(onCancel: () -> Unit, onLive: () -> Unit, onNotEnabled: () -> Unit, onFailed: () -> Unit) {
    val s by SessionStore.state.collectAsState()
    var count by remember { mutableIntStateOf(3) }
    var left by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (count > 0) { delay(1000); count-- }
    }
    LaunchedEffect(s.phase, s.errorKind) {
        if (left || s.phase != Phase.ERROR) return@LaunchedEffect
        left = true
        val kind = s.errorKind
        val msg = s.errorMessage
        SessionStore.reset()
        if (kind == ErrorKind.LIVE_NOT_ENABLED) onNotEnabled()
        else { SessionStore.toast(msg ?: "Could not go live"); onFailed() }
    }
    LaunchedEffect(count, s.liveConnected) {
        if (!left && count == 0 && s.liveConnected) { left = true; onLive() }
    }

    Column(
        Modifier.fillMaxSize().background(Night).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterVertically)
    ) {
        Box(Modifier.size(180.dp).border(6.dp, Brand.Record, CircleShape), contentAlignment = Alignment.Center) {
            if (count > 0) Text("$count", color = Color.White, fontSize = 88.sp, fontWeight = FontWeight.Medium)
            else CircularProgressIndicator(color = Color.White, modifier = Modifier.size(56.dp))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Going live on YouTube", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
            Text(
                if (count == 0 && !s.liveConnected) "Connecting to YouTube…" else "Switch to your game now — the bubble stays on top",
                color = NightMuted, fontSize = 15.sp, textAlign = TextAlign.Center
            )
        }
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(NightCard).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Step(if (s.keyMode) "Stream key ready" else "Live stream created on your channel", s.liveCreated)
            Step("Connected to YouTube", s.liveConnected)
            Step("Screen and sound ready", s.screenReady)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { left = true; onCancel() }) { Text("Cancel", color = Color.White) }
            Button(
                onClick = { left = true; onLive() },
                colors = ButtonDefaults.buttonColors(containerColor = Brand.LiveRed, contentColor = Color.White)
            ) { Text("Skip countdown") }
        }
    }
}

@Composable
private fun Step(label: String, done: Boolean) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(22.dp).clip(CircleShape).background(if (done) Color(0xFF7BD88F) else Color(0xFF5D5C66)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Outlined.Check, null, tint = Night, modifier = Modifier.size(14.dp)) }
        Text(label, color = if (done) Color.White else Color(0xFF918F9A), fontSize = 14.sp)
    }
}

/** In-app view while live: status, viewers, quick controls and End. */
@Composable
fun LiveScreen(actions: AppActions, onEnded: () -> Unit) {
    val s by SessionStore.state.collectAsState()
    val ctx = LocalContext.current
    var sawLive by remember { mutableStateOf(false) }

    LaunchedEffect(s.mode, s.phase) {
        if (s.mode == Mode.LIVE) sawLive = true
        if (s.mode == Mode.NONE && (sawLive || s.phase == Phase.ERROR)) {
            if (s.phase == Phase.ERROR) {
                SessionStore.toast(s.errorMessage ?: "Live stopped"); SessionStore.reset()
            }
            onEnded()
        }
    }

    val fb = s.facebookLive
    val platform = if (fb) "Facebook" else "YouTube"
    val page = s.facebookPageName?.takeIf { it.isNotBlank() }

    Box(Modifier.fillMaxSize().background(Night)) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            LivePill(text = when {
                s.paused -> "PAUSED"
                s.reconnecting -> "RECONNECTING"
                s.phase != Phase.RUNNING -> "STARTING"
                else -> "LIVE"
            })
            DarkPill(formatDuration(s.elapsedSec))
            if (s.viewers != null) DarkPill("${s.viewers} watching", Icons.Outlined.Visibility)
        }

        Column(
            Modifier.align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            ToneSurface(
                container = if (fb) FbBlue else YtRed,
                edge = if (fb) FbBlueEdge else YtRedEdge,
                shape = RoundedCornerShape(26.dp), depth = 5.dp,
                modifier = Modifier.size(78.dp)
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    if (fb) Text("f", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.Bold)
                    else Icon(Icons.Outlined.PlayArrow, null, tint = Color.White, modifier = Modifier.size(46.dp))
                }
            }
            Text(
                if (s.paused) "Viewers see \"Be right back\"" else "You're live on $platform",
                color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center
            )
            Text(
                "Open your game — use the floating bubble to pause, mute or stop.",
                color = NightMuted, fontSize = 15.sp, textAlign = TextAlign.Center
            )
            if (fb) {
                ToneSurface(Color(0xFFD9E8FF), Color(0xFF9DBFF5), shape = RoundedCornerShape(18.dp), depth = 3.dp) {
                    Text(
                        "Sending to ${page ?: "your Facebook Page"}. In Live Producer, press Go Live once the preview appears.",
                        color = Color(0xFF0A2E66), fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Control(
                    if (s.paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause, if (s.paused) "Resume" else "Pause",
                    Color(0xFFE8E2FF), Color(0xFFC7BCF7), Color(0xFF2A1A99)
                ) { CaptureService.command(ctx, CaptureService.ACTION_TOGGLE_PAUSE) }
                if (s.micAvailable) Control(
                    if (s.micOn) Icons.Outlined.Mic else Icons.Outlined.MicOff, if (s.micOn) "Mute mic" else "Mic on",
                    Color(0xFFFFDCE6), Color(0xFFF4B3C6), Color(0xFF5C1535)
                ) { CaptureService.command(ctx, CaptureService.ACTION_TOGGLE_MIC) }
                Control(
                    Icons.Outlined.Face, "Face-cam",
                    Color(0xFFCDF4DA), Color(0xFF9ED9B3), Color(0xFF00402B), selected = s.faceCamOn
                ) { CaptureService.command(ctx, CaptureService.ACTION_TOGGLE_FACECAM) }
                Control(
                    Icons.Outlined.CenterFocusWeak, "Screenshot",
                    Color(0xFFFFE7B8), Color(0xFFEBC472), Color(0xFF4F3300)
                ) { CaptureService.command(ctx, CaptureService.ACTION_SCREENSHOT) }
            }
            val openUrl = when {
                fb -> "https://www.facebook.com/live/producer"
                else -> s.broadcastId?.let { "https://youtu.be/$it" } ?: if (s.keyMode) "https://studio.youtube.com" else null
            }
            val openLabel = when {
                fb -> "Open Live Producer"
                s.keyMode -> "Open YouTube Studio"
                else -> "Open on YouTube"
            }
            openUrl?.let { url ->
                TextButton(onClick = { actions.openUrl(url) }) {
                    Icon(Icons.AutoMirrored.Outlined.OpenInNew, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Text("  $openLabel", color = Color.White, fontWeight = FontWeight.Medium)
                }
            }
        }

        ToneSurface(
            container = Color(0xFFFDF8FF), edge = Color(0xFFC7BCF7),
            shape = RoundedCornerShape(24.dp), depth = 4.dp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).fillMaxWidth()
        ) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(if (s.reconnecting) Color(0xFFE6A100) else Brand.Good))
                Column(Modifier.weight(1f)) {
                    Text("Streaming to $platform", color = Night, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    val conn = if (s.reconnecting) "Reconnecting…" else "Good connection"
                    Text(
                        if (fb && page != null) "$page · ${s.qualityLabel} · $conn" else "${s.qualityLabel} · $conn",
                        color = Color(0xFF46464F), fontSize = 12.sp
                    )
                }
                ExpressiveButtonText("End", onClick = { actions.stopSession() }, variant = ButtonVariant.Live, modifier = Modifier.width(92.dp))
            }
        }
    }
}

private val FbBlue = Color(0xFF1877F2)
private val FbBlueEdge = Color(0xFF0B4FAF)
private val YtRed = Color(0xFFFF4D5E)
private val YtRedEdge = Color(0xFFB01B2E)

@Composable
private fun DarkPill(text: String, icon: ImageVector? = null) {
    val shape = RoundedCornerShape(50)
    Box(Modifier.clip(shape).background(Color(0xFF3A3A44))) {
        Row(
            Modifier.padding(bottom = 3.dp).clip(shape).background(Color.Black).padding(horizontal = 12.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (icon != null) Icon(icon, null, tint = Color.White, modifier = Modifier.size(16.dp))
            Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun Control(
    icon: ImageVector, label: String,
    container: Color, edge: Color, content: Color,
    selected: Boolean = false, onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.width(66.dp)) {
        ToneSurface(
            container = if (selected) Color(0xFF00A06A) else container,
            edge = if (selected) Color(0xFF006B47) else edge,
            shape = CircleShape, depth = 4.dp,
            modifier = Modifier.size(54.dp),
            onClick = onClick, role = Role.Button, onClickLabel = label
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(icon, label, tint = if (selected) Color.White else content, modifier = Modifier.size(24.dp))
            }
        }
        Text(label, color = NightMuted, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}
