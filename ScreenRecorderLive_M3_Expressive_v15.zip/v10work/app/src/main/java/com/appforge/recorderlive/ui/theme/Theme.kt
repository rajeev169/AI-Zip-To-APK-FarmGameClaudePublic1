package com.appforge.recorderlive.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Brand colours (Material 3 Expressive palette). */
object Brand {
    val Primary = Color(0xFF6B4EFF)
    val Record = Color(0xFFFF6B5E)
    val RecordEdge = Color(0xFFB8261B)
    val Bubble = Color(0xFFFF8A80)
    val BubbleIcon = Color(0xFF5F1414)
    val LiveRed = Color(0xFFE5384F)
    val GoLive = Color(0xFFB3261E)
    val Good = Color(0xFF00875A)
}

private val Light = lightColorScheme(
    primary = Color(0xFF6B4EFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8E2FF),
    onPrimaryContainer = Color(0xFF2A1A99),
    secondary = Color(0xFF5B4FA8),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCD3FF),
    onSecondaryContainer = Color(0xFF2A1A99),
    tertiary = Color(0xFF00875A),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFCDF4DA),
    onTertiaryContainer = Color(0xFF00402B),
    error = Color(0xFFB3261E),
    errorContainer = Color(0xFFFFDAD4),
    onErrorContainer = Color(0xFF7A0E07),
    background = Color(0xFFFDF8FF),
    onBackground = Color(0xFF1D1B20),
    surface = Color(0xFFFDF8FF),
    onSurface = Color(0xFF1D1B20),
    surfaceVariant = Color(0xFFE7E0EC),
    onSurfaceVariant = Color(0xFF5E5A66),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF8F2FB),
    surfaceContainer = Color(0xFFF2ECF6),
    surfaceContainerHigh = Color(0xFFECE6F0),
    surfaceContainerHighest = Color(0xFFE6E0EA),
    outline = Color(0xFF7A7385),
    outlineVariant = Color(0xFFCFC7D6),
)

private val Dark = darkColorScheme(
    primary = Color(0xFFC9BEFF),
    onPrimary = Color(0xFF2B1A8A),
    primaryContainer = Color(0xFF4630C2),
    onPrimaryContainer = Color(0xFFE8E2FF),
    secondary = Color(0xFFCBC2F5),
    onSecondary = Color(0xFF30266E),
    secondaryContainer = Color(0xFF473D8A),
    onSecondaryContainer = Color(0xFFE4DEFF),
    tertiary = Color(0xFF7DDBA8),
    onTertiary = Color(0xFF00311F),
    tertiaryContainer = Color(0xFF14503A),
    onTertiaryContainer = Color(0xFFCDF4DA),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF14111A),
    onBackground = Color(0xFFE7E0EB),
    surface = Color(0xFF14111A),
    onSurface = Color(0xFFE7E0EB),
    surfaceVariant = Color(0xFF49454F),
    onSurfaceVariant = Color(0xFFCBC4D2),
    surfaceContainerLowest = Color(0xFF0F0D14),
    surfaceContainerLow = Color(0xFF1C1822),
    surfaceContainer = Color(0xFF211D27),
    surfaceContainerHigh = Color(0xFF2B2731),
    surfaceContainerHighest = Color(0xFF36323C),
    outline = Color(0xFF948D9C),
    outlineVariant = Color(0xFF49454F),
)

/** Large, rounded Material 3 Expressive corners. */
private val ExpressiveShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        shapes = ExpressiveShapes,
        content = content
    )
}
