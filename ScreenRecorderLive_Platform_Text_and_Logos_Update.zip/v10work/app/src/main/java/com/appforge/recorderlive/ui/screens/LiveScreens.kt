package com.appforge.recorderlive.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CenterFocusWeak
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.automirrored.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.AppActions
import com.appforge.recorderlive.service.CaptureService
import com.appforge.recorderlive.service.ErrorKind
import com.appforge.recorderlive.service.Mode
import com.appforge.recorderlive.service.Phase
import com.appforge.recorderlive.service.SessionStore
import com.appforge.recorderlive.ui.components.AppLogo
import com.appforge.recorderlive.ui.components.LivePill
import com.appforge.recorderlive.ui.components.formatDuration
import com.appforge.recorderlive.ui.theme.Brand
import kotlinx.coroutines.delay

private val Night = Color(0xFF1B1B21)
private val NightCard = Color(0xFF2A2A33)
private val NightMuted = Color(0xFFC6C5D0)

/** 3-2-1 countdown with the "created → connected → ready" checklist. */
@Composable
fun StartingScreen(onCancel: () -> Unit, onLive: () -> Unit, onNotEnabled: () -> Unit, onFailed: () -> Unit) {
    val s by SessionStore.state.collectAsState()
    var count by remember { mutableIntStateOf(3) }
    var left by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (count > 0) { delay(1000); count-- }
    }
    LaunchedEffect(s.phase, s.errorKind) {
        if (left || s.phase != Phase.ERROR) return@LaunchedEffect
        left = true
        val kind = s.errorKind
        val msg = s.errorMessage
        SessionStore.reset()
        if (kind == ErrorKind.LIVE_NOT_ENABLED) onNotEnabled()
        else { SessionStore.toast(msg ?: "Could not go live"); onFailed() }
    }
    LaunchedEffect(count, s.liveConnected) {
        if (!left && count == 0 && s.liveConnected) { left = true; onLive() }
    }

    Column(
        Modifier.fillMaxSize().background(Night).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterVertically)
    ) {
        Box(Modifier.size(180.dp).border(6.dp, Brand.Record, CircleShape), contentAlignment = Alignment.Center) {
            if (count > 0) Text("$count", color = Color.White, fontSize = 88.sp, fontWeight = FontWeight.Medium)
            else CircularProgressIndicator(color = Color.White, modifier = Modifier.size(56.dp))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val platform = if (s.facebookLive) "Facebook" else "YouTube"
            Text("Going live on $platform", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
            Text(
                if (count == 0 && !s.liveConnected) "Connecting to $platform…" else "Switch to your game now — the bubble stays on top",
                color = NightMuted, fontSize = 15.sp, textAlign = TextAlign.Center
            )
        }
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(NightCard).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Step(if (s.keyMode) "Stream key ready" else "Live stream created on your channel", s.liveCreated)
            Step("Connected to $platform", s.liveConnected)
            Step("Screen and sound ready", s.screenReady)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { left = true; onCancel() }) { Text("Cancel", color = Color.White) }
            Button(
                onClick = { left = true; onLive() },
                colors = ButtonDefaults.buttonColors(containerColor = Brand.LiveRed, contentColor = Color.White)
            ) { Text("Skip countdown") }
        }
    }
}

@Composable
private fun Step(label: String, done: Boolean) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(22.dp).clip(CircleShape).background(if (done) Color(0xFF7BD88F) else Color(0xFF5D5C66)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Outlined.Check, null, tint = Night, modifier = Modifier.size(14.dp)) }
        Text(label, color = if (done) Color.White else Color(0xFF918F9A), fontSize = 14.sp)
    }
}

/** In-app view while live: status, viewers, quick controls and End. */
@Composable
fun LiveScreen(actions: AppActions, onEnded: () -> Unit) {
    val s by SessionStore.state.collectAsState()
    val ctx = LocalContext.current
    var sawLive by remember { mutableStateOf(false) }

    LaunchedEffect(s.mode, s.phase) {
        if (s.mode == Mode.LIVE) sawLive = true
        if (s.mode == Mode.NONE && (sawLive || s.phase == Phase.ERROR)) {
            if (s.phase == Phase.ERROR) {
                SessionStore.toast(s.errorMessage ?: "Live stopped"); SessionStore.reset()
            }
            onEnded()
        }
    }

    Box(Modifier.fillMaxSize().background(Night)) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            LivePill(text = when {
                s.paused -> "PAUSED"
                s.reconnecting -> "RECONNECTING"
                s.phase != Phase.RUNNING -> "STARTING"
                else -> "LIVE"
            })
            DarkPill(formatDuration(s.elapsedSec))
            if (s.viewers != null) {
                Row(
                    Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xA6000000)).padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.Visibility, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Text("${s.viewers} watching", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        Column(
            Modifier.align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AppLogo(88.dp)
            Text(
                if (s.paused) "Viewers see \"Be right back\"" else "Your screen is live",
                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium
            )
            Text(
                "Open your game — use the floating bubble to pause, mute or stop.",
                color = NightMuted, fontSize = 15.sp, textAlign = TextAlign.Center
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Control(if (s.paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause, if (s.paused) "Resume" else "Pause") {
                    CaptureService.command(ctx, CaptureService.ACTION_TOGGLE_PAUSE)
                }
                if (s.micAvailable) Control(if (s.micOn) Icons.Outlined.Mic else Icons.Outlined.MicOff, if (s.micOn) "Mute mic" else "Mic on") {
                    CaptureService.command(ctx, CaptureService.ACTION_TOGGLE_MIC)
                }
                Control(Icons.Outlined.Face, "Face-cam", selected = s.faceCamOn) {
                    CaptureService.command(ctx, CaptureService.ACTION_TOGGLE_FACECAM)
                }
                Control(Icons.Outlined.CenterFocusWeak, "Screenshot") {
                    CaptureService.command(ctx, CaptureService.ACTION_SCREENSHOT)
                }
            }
            val openUrl = if (s.facebookLive) null else (s.broadcastId?.let { "https://youtu.be/$it" } ?: if (s.keyMode) "https://studio.youtube.com" else null)
            openUrl?.let { url ->
                TextButton(onClick = { actions.openUrl(url) }) {
                    Icon(Icons.AutoMirrored.Outlined.OpenInNew, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Text(if (s.keyMode) "  Open YouTube Studio" else "  Open on YouTube", color = Color.White)
                }
            }
        }

        Row(
            Modifier.align(Alignment.BottomCenter).padding(16.dp).fillMaxWidth().height(56.dp)
                .clip(RoundedCornerShape(16.dp)).background(Color(0xFFFBF8FF)).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(if (s.reconnecting) Color(0xFFE6A100) else Brand.Good))
            Column(Modifier.weight(1f)) {
                Text("Streaming to ${if (s.facebookLive) "Facebook" else "YouTube"}", color = Night, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text(
                    "${s.qualityLabel} · ${if (s.reconnecting) "Reconnecting…" else "Good connection"}",
                    color = Color(0xFF46464F), fontSize = 12.sp
                )
            }
            Button(
                onClick = { actions.stopSession() },
                colors = ButtonDefaults.buttonColors(containerColor = Brand.GoLive, contentColor = Color.White)
            ) { Text("End") }
        }
        Spacer(Modifier.height(1.dp))
    }
}

@Composable
private fun DarkPill(text: String) {
    Text(
        text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xA6000000)).padding(horizontal = 10.dp, vertical = 6.dp)
    )
}

@Composable
private fun Control(icon: ImageVector, label: String, selected: Boolean = false, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        FilledTonalIconButton(
            onClick = onClick, modifier = Modifier.size(52.dp),
            colors = IconButtonDefaults.filledTonalIconButtonColors(
                containerColor = if (selected) Color(0xFFDEE0FF) else NightCard,
                contentColor = if (selected) Color(0xFF00105C) else Color.White
            )
        ) { Icon(icon, label) }
        Text(label, color = NightMuted, fontSize = 11.sp)
    }
}
