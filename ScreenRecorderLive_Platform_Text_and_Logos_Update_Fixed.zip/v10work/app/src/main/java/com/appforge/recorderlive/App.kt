package com.appforge.recorderlive

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class App : Application() {
    companion object {
        const val CHANNEL_CAPTURE = "capture"
        /** Work that must finish even after the service stops (saving a video, ending a broadcast). */
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        /** True while the app's screen is visible (messages show inside the app instead of as a toast). */
        @Volatile var inForeground = false
    }

    override fun onCreate() {
        super.onCreate()
        CrashReporter.install(this)
        val prefs = com.appforge.recorderlive.data.Prefs(this)
        com.appforge.recorderlive.service.SessionStore.setBubbleColor(prefs.bubbleColor)
        com.appforge.recorderlive.service.SessionStore.setBubbleMenuDark(prefs.bubbleMenuDark)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_CAPTURE, "Recording and live", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows while recording or streaming live"
                setShowBadge(false)
            }
        )
    }
}
