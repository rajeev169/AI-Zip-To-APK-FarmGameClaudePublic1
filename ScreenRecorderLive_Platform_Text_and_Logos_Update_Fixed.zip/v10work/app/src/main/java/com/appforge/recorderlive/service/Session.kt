package com.appforge.recorderlive.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

enum class Mode { NONE, RECORD, LIVE }
enum class Phase { IDLE, PREPARING, RUNNING, ENDED, ERROR }
enum class ErrorKind { LIVE_NOT_ENABLED, NO_CHANNEL, SIGN_IN, NETWORK, OTHER }

data class Session(
    val mode: Mode = Mode.NONE,
    val phase: Phase = Phase.IDLE,
    val elapsedSec: Long = 0,
    val paused: Boolean = false,
    val micOn: Boolean = false,
    val micAvailable: Boolean = false,
    val faceCamOn: Boolean = false,
    // live only
    val liveCreated: Boolean = false,
    val liveConnected: Boolean = false,
    val screenReady: Boolean = false,
    val reconnecting: Boolean = false,
    val viewers: Int? = null,
    val broadcastId: String? = null,
    val qualityLabel: String = "",
    /** Live with a stream key (no sign-in): no viewer count / replay link. */
    val keyMode: Boolean = false,
    /** True when this live session is publishing to Facebook rather than YouTube. */
    val facebookLive: Boolean = false,
    // errors / messages
    val errorKind: ErrorKind? = null,
    val errorMessage: String? = null,
)

/** Shared live state between the capture service, the floating bubble and the app screens. */
object SessionStore {
    private val _state = MutableStateFlow(Session())
    val state: StateFlow<Session> = _state

    /** Bumped whenever a recording or screenshot is saved, so lists refresh. */
    private val _mediaVersion = MutableStateFlow(0)
    val mediaVersion: StateFlow<Int> = _mediaVersion

    /** One-off message to show in the app (e.g. "Screenshot saved"). */
    private val _toast = MutableStateFlow<String?>(null)
    val toast: StateFlow<String?> = _toast

    /** Live bubble colour so the overlay and Home tile change instantly when picked in Settings. */
    private val _bubbleColor = MutableStateFlow(0xFFFF8A80.toInt())
    val bubbleColor: StateFlow<Int> = _bubbleColor
    fun setBubbleColor(argb: Int) { _bubbleColor.value = argb }

    private val _bubbleMenuDark = MutableStateFlow(false)
    val bubbleMenuDark: StateFlow<Boolean> = _bubbleMenuDark
    fun setBubbleMenuDark(dark: Boolean) { _bubbleMenuDark.value = dark }

    fun update(block: (Session) -> Session) = _state.update(block)
    fun reset() { _state.value = Session() }
    fun mediaChanged() = _mediaVersion.update { it + 1 }
    fun toast(msg: String?) { _toast.value = msg }

    /** Screen the app should open next (e.g. "connect" when Go live is tapped in the bubble without YouTube). */
    private val _openRoute = MutableStateFlow<String?>(null)
    val openRouteRequest: StateFlow<String?> = _openRoute
    fun openRoute(route: String?) { _openRoute.value = route }

    /** Message box that stays on screen until closed (title to message). */
    private val _alert = MutableStateFlow<Pair<String, String>?>(null)
    val alert: StateFlow<Pair<String, String>?> = _alert
    fun alert(title: String, message: String) { _alert.value = title to message }
    fun clearAlert() { _alert.value = null }
}
