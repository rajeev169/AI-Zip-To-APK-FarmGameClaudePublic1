# ScreenRecorderLive v10 — Facebook integration progress

Base: original ScreenRecorderLive v9 source. Existing YouTube classes and capture service were retained.

## Added in this archive
- Meta Facebook Android Login SDK dependency (`facebook-login:18.2.3`).
- Meta App ID and Client Token resources using values supplied by the project owner.
- Facebook SDK manifest metadata, FacebookActivity, CustomTabActivity and app-targeted callback package.
- Facebook entry point from the existing connect screen.
- Facebook setup screen with distinct account-login, Page-login, and manual RTMPS configuration sections.
- Facebook LoginManager flow requesting `public_profile`; Page path additionally requests `pages_show_list`.
- Local persistence fields for RTMPS server and key.
- App version code/name advanced to 10 / 1.5.0.

## Not yet complete — do not mistake the setup UI for a finished broadcaster
- Facebook Page discovery/selection via Graph API is not yet implemented.
- `pages_show_list` and any publishing permissions may require Meta App Review / Advanced Access and business verification depending on the use case.
- Facebook Live publishing to a personal profile is not generally available through the standard Live API. Do not promise this destination unless Meta explicitly grants the relevant capability.
- Saved Facebook RTMPS URL/key are not yet connected to a second encoder output. Existing capture service starts one `GenericStream` for the current YouTube route. Multi-destination output and simultaneous YouTube/Facebook streaming remain to be implemented.
- Facebook login success currently reports authentication success only; it does not assert that Live is enabled.

## Meta dashboard configuration
- Android package: `com.appforge.recorderlive`
- Default Activity: `com.appforge.recorderlive.MainActivity`
- Add the development and release key hashes matching the actual APK signing keys.
- Keep App Secret off-device and out of the APK. Client Token is not the App Secret.
- Test in Development mode with app roles before App Review / public release.

## Build status
The build was attempted with `./gradlew :app:assembleDebug`, but the environment could not resolve `services.gradle.org` (network DNS unavailable), so no APK build verification was possible. Build and test in your GitHub Actions environment before installing.
