package com.appforge.recorderlive

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.appforge.recorderlive.data.MediaItem
import com.appforge.recorderlive.data.MediaKind
import com.appforge.recorderlive.service.CaptureService
import com.appforge.recorderlive.service.SessionStore
import com.appforge.recorderlive.ui.AppRoot
import com.appforge.recorderlive.ui.theme.AppTheme
import com.appforge.recorderlive.youtube.AuthMode
import com.appforge.recorderlive.youtube.YouTubeAccount
import com.appforge.recorderlive.youtube.YouTubeAuth
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult
import net.openid.appauth.AuthorizationException
import net.openid.appauth.AuthorizationService
import kotlinx.coroutines.launch

enum class ConnectResult { OK, NO_CHANNEL, CANCELLED, FAILED }

/** Everything the screens can ask the Activity to do (permissions, system pickers, starting capture). */
interface AppActions {
    fun startRecording()
    fun stopSession()
    fun startLive(onStarted: () -> Unit)
    /** Android Google sign-in (channel that belongs to the Gmail). */
    fun signInNative(onResult: (ConnectResult) -> Unit)
    /** Google sign-in page in a Chrome tab: can choose a brand channel. */
    fun facebookLogin(page: Boolean)
    fun signInWeb(onResult: (ConnectResult) -> Unit)
    /** Reload the channel name/photo (Retry on the channel card). */
    fun retryChannel()
    fun ensureOverlay(then: () -> Unit = {})
    fun ensurePermissions(perms: List<String>, then: (allGranted: Boolean) -> Unit)
    fun hasPermission(perm: String): Boolean
    fun canDrawOverlays(): Boolean
    fun open(item: MediaItem)
    fun share(item: MediaItem)
    fun edit(item: MediaItem)
    fun openUrl(url: String)
}

class MainActivity : ComponentActivity(), AppActions {

    private val vm: MainViewModel by viewModels()

    private var pendingLive = false
    private var onProjection: ((Boolean) -> Unit)? = null
    private var afterPermissions: ((Boolean) -> Unit)? = null
    private var afterOverlay: (() -> Unit)? = null
    private var afterSignIn: ((ConnectResult) -> Unit)? = null
    private var afterWebSignIn: ((ConnectResult) -> Unit)? = null
    private val facebookCallbackManager: CallbackManager = CallbackManager.Factory.create()
    private var authService: AuthorizationService? = null
    private fun authService() = authService ?: AuthorizationService(this).also { authService = it }
    private var afterConsent: ((Boolean) -> Unit)? = null

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val ok = r.resultCode == RESULT_OK && data != null
        if (ok) CaptureService.start(this, pendingLive, r.resultCode, data!!)
        onProjection?.invoke(ok)
        onProjection = null
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        afterPermissions?.invoke(res.values.all { it })
        afterPermissions = null
    }

    private val overlayLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        afterOverlay?.invoke()
        afterOverlay = null
    }

    private val signInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val done = afterSignIn; afterSignIn = null
        val result = vm.accountFromSignIn(r.data)
        if (result.isFailure) {
            if (r.resultCode == RESULT_OK) SessionStore.toast("Sign-in failed. Check the Google Cloud setup (see README).")
            done?.invoke(if (r.resultCode == RESULT_OK) ConnectResult.FAILED else ConnectResult.CANCELLED)
            return@registerForActivityResult
        }
        loadChannelThen(native = true) { done?.invoke(it) }
    }

    private val webSignInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val done = afterWebSignIn; afterWebSignIn = null
        lifecycleScope.launch {
            try {
                if (YouTubeAuth.mode(this@MainActivity) == AuthMode.NATIVE) YouTubeAccount.signOut(this@MainActivity)
                YouTubeAuth.completeWebSignIn(this@MainActivity, authService(), r.data)
                vm.prefs.streamKey = null
                vm.refreshAuth()
            } catch (e: Exception) {
                val userCancelled = e is AuthorizationException &&
                    e.code == AuthorizationException.GeneralErrors.USER_CANCELED_AUTH_FLOW.code
                if (userCancelled) {
                    SessionStore.alert(
                        "Sign-in not finished",
                        "The Google page closed without sending the answer back to the app.\n\n" +
                            "If you closed it yourself, ignore this.\n\n" +
                            "If you tapped Continue and it still came back here, Google may not have activated " +
                            "\"Enable custom URI scheme\" yet (can take a few hours). Try again later."
                    )
                    done?.invoke(ConnectResult.CANCELLED)
                } else {
                    val detail = if (e is AuthorizationException) "${e.error ?: ""} ${e.errorDescription ?: ""}".trim() else ""
                    SessionStore.alert(
                        "Google sign-in failed",
                        (e.message ?: e.javaClass.simpleName) + (if (detail.isNotBlank()) "\n\nDetails: $detail" else "") +
                            "\n\nCheck in Google Cloud that \"Enable custom URI scheme\" is ticked on your Android client."
                    )
                    done?.invoke(ConnectResult.FAILED)
                }
                return@launch
            }
            loadChannelThen(native = false) { done?.invoke(it) }
        }
    }

    private val consentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        afterConsent?.invoke(r.resultCode == RESULT_OK)
        afterConsent = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        LoginManager.getInstance().registerCallback(facebookCallbackManager, object : FacebookCallback<LoginResult> {
            override fun onSuccess(result: LoginResult) { SessionStore.toast("Facebook account connected. Live publishing still needs Meta permissions and setup.") }
            override fun onCancel() { SessionStore.toast("Facebook login cancelled") }
            override fun onError(error: FacebookException) { SessionStore.alert("Facebook login failed", error.localizedMessage ?: "Please try again") }
        })
        setContent { AppTheme { AppRoot(vm, this) } }
    }


    override fun facebookLogin(page: Boolean) {
        val permissions = if (page) listOf("public_profile", "pages_show_list") else listOf("public_profile")
        LoginManager.getInstance().logInWithReadPermissions(this, permissions)
    }

    @Deprecated("Facebook SDK callback forwarding")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        facebookCallbackManager.onActivityResult(requestCode, resultCode, data)
    }

    override fun onStart() {
        super.onStart()
        App.inForeground = true
        // "Always show bubble": bring the waiting bubble back if Android closed it
        if (vm.prefs.floatingBubble && canDrawOverlays() && SessionStore.state.value.mode == com.appforge.recorderlive.service.Mode.NONE) {
            runCatching { CaptureService.showBubble(this) }
        }
    }

    override fun onDestroy() {
        authService?.dispose()
        authService = null
        super.onDestroy()
    }

    override fun onStop() {
        App.inForeground = false
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        vm.refreshMedia()
    }

    // ---------------------------------------------------------------- capture

    override fun startRecording() {
        val p = vm.prefs
        val perms = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (p.recMic || p.recGameSound) add(Manifest.permission.RECORD_AUDIO)
            if (p.recFaceCam) add(Manifest.permission.CAMERA)
        }
        ensurePermissions(perms) {
            val needOverlay = p.recBubble || p.recFaceCam
            val go = { requestProjection(live = false) {} }
            if (needOverlay) ensureOverlay(go) else go()
        }
    }

    override fun startLive(onStarted: () -> Unit) {
        lifecycleScope.launch {
            when (val r = vm.checkToken()) {
                is ChannelResult.NeedsConsent -> {
                    afterConsent = { ok -> if (ok) startLive(onStarted) }
                    consentLauncher.launch(r.intent)
                    return@launch
                }
                is ChannelResult.Failed -> { SessionStore.toast(r.message); return@launch }
                ChannelResult.Ok, ChannelResult.NoChannel -> {}
            }
            val p = vm.prefs
            val perms = buildList {
                if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
                if (p.liveMic || p.liveGameSound) add(Manifest.permission.RECORD_AUDIO)
                if (p.liveFaceCam) add(Manifest.permission.CAMERA)
            }
            ensurePermissions(perms) {
                val go = { requestProjection(live = true) { ok -> if (ok) onStarted() } }
                if (p.liveBubble || p.liveFaceCam) ensureOverlay(go) else go()
            }
        }
    }

    private fun requestProjection(live: Boolean, done: (Boolean) -> Unit) {
        pendingLive = live
        onProjection = done
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    override fun stopSession() = CaptureService.command(this, CaptureService.ACTION_STOP)

    // ---------------------------------------------------------------- permissions

    override fun hasPermission(perm: String) =
        ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED

    override fun canDrawOverlays() = Settings.canDrawOverlays(this)

    override fun ensurePermissions(perms: List<String>, then: (Boolean) -> Unit) {
        val missing = perms.filterNot { hasPermission(it) }
        if (missing.isEmpty()) { then(true); return }
        afterPermissions = then
        permissionLauncher.launch(missing.toTypedArray())
    }

    override fun ensureOverlay(then: () -> Unit) {
        if (canDrawOverlays()) { then(); return }
        SessionStore.toast("Allow \"Display over other apps\" to show the bubble and face-cam")
        afterOverlay = then
        overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    // ---------------------------------------------------------------- Google / YouTube

    override fun signInNative(onResult: (ConnectResult) -> Unit) {
        lifecycleScope.launch {
            // Sign out first so Android always shows the account picker
            YouTubeAccount.signOut(this@MainActivity)
            afterSignIn = onResult
            signInLauncher.launch(YouTubeAccount.signInIntent(this@MainActivity))
        }
    }

    override fun signInWeb(onResult: (ConnectResult) -> Unit) {
        afterWebSignIn = onResult
        try {
            webSignInLauncher.launch(YouTubeAuth.webSignInIntent(authService()))
        } catch (e: Exception) {
            afterWebSignIn = null
            SessionStore.toast("No browser found for Google sign-in")
            onResult(ConnectResult.FAILED)
        }
    }

    private fun loadChannelThen(native: Boolean, done: (ConnectResult) -> Unit) {
        lifecycleScope.launch {
            when (val r = vm.loadChannel()) {
                ChannelResult.Ok -> done(ConnectResult.OK)
                ChannelResult.NoChannel -> {
                    if (native) {
                        // Gmail without its own channel: undo, the screen offers "Choose a brand channel"
                        vm.undoNativeSignIn()
                    } else {
                        vm.signOut()
                        SessionStore.alert(
                            "No channel on that account",
                            "The account you picked has no YouTube channel. Tap Choose a brand channel again and pick the account that holds your channel."
                        )
                    }
                    done(ConnectResult.NO_CHANNEL)
                }
                is ChannelResult.NeedsConsent -> {
                    afterConsent = { ok -> if (ok) loadChannelThen(native, done) else done(ConnectResult.CANCELLED) }
                    consentLauncher.launch(r.intent)
                }
                is ChannelResult.Failed -> {
                    SessionStore.alert("Couldn't load your channel", r.message)
                    done(ConnectResult.FAILED)
                }
            }
        }
    }

    /** Retry button on the channel card. */
    override fun retryChannel() = loadChannelThen(native = YouTubeAuth.mode(this) == AuthMode.NATIVE) {}

    // ---------------------------------------------------------------- media

    private fun mime(item: MediaItem) = if (item.kind == MediaKind.SCREENSHOT) "image/*" else "video/*"

    override fun open(item: MediaItem) {
        if (item.replay != null) { openUrl(item.replay.url); return }
        val uri = item.uri ?: return
        startSafely(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime(item)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }

    override fun share(item: MediaItem) {
        val send = if (item.replay != null) {
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "${item.name} ${item.replay.url}")
        } else {
            Intent(Intent.ACTION_SEND).setType(mime(item)).putExtra(Intent.EXTRA_STREAM, item.uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startSafely(Intent.createChooser(send, "Share"))
    }

    override fun edit(item: MediaItem) {
        val uri = item.uri ?: return
        val i = Intent(Intent.ACTION_EDIT).setDataAndType(uri, mime(item))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        startSafely(Intent.createChooser(i, "Edit with"), "No video editor app found on this phone")
    }

    override fun openUrl(url: String) = startSafely(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun startSafely(i: Intent, error: String = "No app found to open this") {
        try { startActivity(i) } catch (_: ActivityNotFoundException) { SessionStore.toast(error) }
    }
}
