package com.appforge.recorderlive.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.appforge.recorderlive.data.Prefs

@Composable
fun FacebookSetupScreen(onBack: () -> Unit, onLogin: (Boolean) -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { Prefs(context) }
    var server by remember { mutableStateOf(prefs.facebookRtmpServer) }
    var key by remember { mutableStateOf(prefs.facebookRtmpKey) }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
        Text("Facebook connection", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Choose how you want to connect Facebook for streaming.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("1. Facebook account", fontWeight = FontWeight.SemiBold)
            Text("Sign in with Facebook. The basic profile permission authenticates your account; it does not itself enable Live publishing.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = { onLogin(false) }, modifier = Modifier.fillMaxWidth()) { Text("Continue with Facebook") }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("2. Facebook Page", fontWeight = FontWeight.SemiBold)
            Text("Sign in and request Page selection. Page listing/publishing requires Meta-approved permissions and a Page you manage.", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { onLogin(true) }, modifier = Modifier.fillMaxWidth()) { Text("Connect Facebook Page") }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("3. RTMPS stream key", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(server, { server = it; saved = false }, label = { Text("RTMPS Server URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(key, { key = it; saved = false }, label = { Text("Stream Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = { prefs.facebookRtmpServer = server.trim(); prefs.facebookRtmpKey = key.trim(); saved = true }, modifier = Modifier.fillMaxWidth(), enabled = server.startsWith("rtmps://") && key.isNotBlank()) { Text("Save RTMPS details") }
            if (saved) Text("RTMPS details saved on this device. Streaming output wiring is not active yet.", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        } }
        Text("Note: Facebook Live publishing, Page selection, and multi-platform streaming require additional Meta permissions and encoder integration. This screen does not claim those functions are live yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
