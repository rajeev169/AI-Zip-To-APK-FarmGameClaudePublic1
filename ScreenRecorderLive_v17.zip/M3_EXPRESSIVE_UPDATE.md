# v1.7.0 (versionCode 13)

New
- Go live chooser (route go_live): Home and the Live tab open a screen with a YouTube card and a Facebook card, each with status, stream title and its own Go live button.
- Stream titles: editable on both cards. YouTube uses the existing title; Facebook has its own saved title with a Copy button (Facebook shows it only after it is pasted in Live Producer).
- Settings: YouTube and Facebook cards always visible. Add account when not connected; details, Go live and Sign out (plus Manage on Facebook) when connected. Facebook sign out dialog has "Also remove saved stream key" (ticked).
- Pre-live checklist dialog (network, battery, permissions, storage) before Go live. Only "no internet" blocks.
- Expired Facebook key message with an Open Live Producer button when the first connection is rejected.
- Facebook stream key now stored in the Android Keystore vault (old plain copy is migrated on first read); allowBackup set to false.

Files: ui/components/AccountCards.kt, PreLiveCheck.kt, ui/screens/GoLiveChooserScreen.kt, data/FacebookKeyVault.kt; edits in AppRoot, SettingsScreen, MainActivity, CaptureService, Prefs, Expressive.

Not done: automatic Facebook broadcast creation (needs Meta App Review), Facebook login callback cleanup, redesign of Starting/bubble/Recordings, dual streaming.
Not compiled in the authoring environment (no network): run the GitHub Actions build first.
