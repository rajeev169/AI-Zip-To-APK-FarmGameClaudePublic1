package com.appforge.recorderlive.service

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.appforge.recorderlive.data.Prefs
import com.appforge.recorderlive.ui.theme.AppTheme
import com.appforge.recorderlive.youtube.AuthMode
import com.appforge.recorderlive.youtube.SignInAgainException
import com.appforge.recorderlive.youtube.YouTubeApi
import com.appforge.recorderlive.youtube.YouTubeAuth
import com.appforge.recorderlive.youtube.YouTubeException
import com.google.android.gms.auth.UserRecoverableAuthException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.IOException

/**
 * Small screen opened by the floating bubble's Record / Go live buttons, shown over the game.
 *
 * Go live (no settings here — title, quality, privacy… come from what was set in the app):
 *  1. YouTube and Facebook both ready → asks which one (last used is first). Only one ready → goes straight on.
 *  2. YouTube with Google sign-in: checks access (shows Google's "Allow" if needed) and CREATES the live first.
 *  3. Only then asks Android "Start recording/casting?" — streaming starts the moment the user taps Start.
 *     (Android 14 cancels a capture permission that is left waiting; that caused
 *     "Cannot create VirtualDisplay with non-current MediaProjection".)
 *  4. Stays open (invisible) for a moment until the stream has started, then closes so the user is back in the game.
 */
class CaptureRequestActivity : ComponentActivity() {

    companion object {
        /** true = go live (with the saved Go live settings), false = record */
        const val EXTRA_LIVE = "live"

        fun facebookReady(p: Prefs) = !p.facebookSelectedPageId.isNullOrBlank() &&
            p.facebookRtmpServer.trim().startsWith("rtmps://", ignoreCase = true) && p.facebookRtmpKey.isNotBlank()
    }

    private val live by lazy { intent.getBooleanExtra(EXTRA_LIVE, false) }
    private val prefs by lazy { Prefs(this) }

    /** UI state: choosing a platform, or a short "Preparing…" message */
    private val choosing = mutableStateOf(false)
    private val busyText = mutableStateOf<String?>(null)

    private var facebook = false
    private var readyUrl: String? = null
    private var readyBroadcast: String? = null
    private var readyToken: String? = null

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            if (live) SessionStore.reset()
            CaptureService.start(this, live = live, resultCode = r.resultCode, data = data,
                facebookLive = facebook, readyUrl = readyUrl, readyBroadcast = readyBroadcast)
            readyUrl = null
            if (live) waitUntilStartedThenClose() else finish()
        } else {
            cancelPreparedLive()
            finish()
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        afterPermissions()
    }

    /** Google's "Allow YouTube access" screen (native sign-in), then try again */
    private val consentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) prepareYouTube() else { toast("YouTube access wasn't allowed"); finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) { finish(); return }   // don't run the flow twice after a rotation
        setContent { AppTheme { Ui() } }
        if (!live) { askPermissions(); return }
        val yt = YouTubeAuth.isConnected(this)
        val fb = facebookReady(prefs)
        when {
            yt && fb -> choosing.value = true
            fb -> pick(facebook = true)
            yt -> pick(facebook = false)
            else -> {
                SessionStore.openRoute("connect")
                startActivity(packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                toast("Connect YouTube or Facebook in the app first")
                finish()
            }
        }
    }

    private fun pick(facebook: Boolean) {
        choosing.value = false
        this.facebook = facebook
        prefs.lastLivePlatform = if (facebook) "facebook" else "youtube"
        askPermissions()
    }

    private fun askPermissions() {
        val needed = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            val mic = if (live) prefs.liveMic || prefs.liveGameSound else prefs.recMic || prefs.recGameSound
            val cam = if (live) prefs.liveFaceCam else prefs.recFaceCam
            if (mic) add(Manifest.permission.RECORD_AUDIO)
            if (cam) add(Manifest.permission.CAMERA)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isEmpty()) afterPermissions() else permissionLauncher.launch(needed.toTypedArray())
    }

    private fun afterPermissions() {
        // YouTube with Google sign-in: create the live BEFORE asking for capture. Stream key / Facebook need nothing.
        if (live && !facebook && YouTubeAuth.mode(this) != AuthMode.KEY) prepareYouTube() else askCapture()
    }

    private fun prepareYouTube() {
        busyText.value = "Preparing your YouTube live…"
        lifecycleScope.launch {
            try {
                val token = YouTubeAuth.token(this@CaptureRequestActivity)
                val setup = YouTubeApi.createLive(token, prefs.liveTitle, prefs.livePrivacy, prefs.liveLatency)
                readyToken = token; readyUrl = setup.rtmpUrl; readyBroadcast = setup.broadcastId
                busyText.value = null
                askCapture()
            } catch (e: UserRecoverableAuthException) {
                busyText.value = null
                val i = e.intent
                if (i != null) consentLauncher.launch(i) else { toast("Please allow YouTube access in the app"); finish() }
            } catch (e: SignInAgainException) {
                fail("Open the app and connect YouTube again")
            } catch (e: YouTubeException) {
                fail(if (e.isLiveNotEnabled) "Live streaming isn't turned on for this channel yet" else "Couldn't go live: ${e.message}")
            } catch (e: IOException) {
                fail("No internet connection")
            } catch (e: Exception) {
                fail("Couldn't go live: ${e.message}")
            }
        }
    }

    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    /** Stay (invisible) until the stream is running or failed — max ~8 s — so Android sees the app as active while it starts */
    private fun waitUntilStartedThenClose() {
        busyText.value = null
        lifecycleScope.launch {
            val until = System.currentTimeMillis() + 8000
            delay(600)
            while (System.currentTimeMillis() < until) {
                val st = SessionStore.state.value
                if (st.liveConnected || st.phase == Phase.ERROR) break
                delay(200)
            }
            finish()
        }
    }

    /** Capture was refused after the YouTube live was created: remove it again */
    private fun cancelPreparedLive() {
        val id = readyBroadcast ?: return
        val token = readyToken ?: return
        readyBroadcast = null; readyUrl = null
        com.appforge.recorderlive.App.scope.launch { runCatching { YouTubeApi.endLive(token, id) } }
    }

    private fun fail(msg: String) { busyText.value = null; toast(msg); finish() }

    private fun toast(msg: String) = android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show()

    @androidx.compose.runtime.Composable
    private fun Ui() {
        val pickNow by choosing
        val busy by busyText
        if (pickNow) {
            val fbFirst = prefs.lastLivePlatform == "facebook"
            AlertDialog(
                onDismissRequest = { finish() },
                title = { Text("Go live on") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        val yt = @androidx.compose.runtime.Composable {
                            Button(onClick = { pick(false) }, modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5304A), contentColor = Color.White)) { Text("YouTube") }
                        }
                        val fb = @androidx.compose.runtime.Composable {
                            Button(onClick = { pick(true) }, modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1877F2), contentColor = Color.White)) {
                                Text("Facebook" + (prefs.facebookSelectedPageName?.let { " · $it" } ?: ""), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        if (fbFirst) { fb(); yt() } else { yt(); fb() }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { finish() }) { Text("Cancel") } }
            )
        }
        busy?.let { msg ->
            Dialog(onDismissRequest = {}) {
                Surface(shape = RoundedCornerShape(20.dp), tonalElevation = 6.dp) {
                    Row(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                        Text(msg)
                    }
                }
            }
        }
    }
}
