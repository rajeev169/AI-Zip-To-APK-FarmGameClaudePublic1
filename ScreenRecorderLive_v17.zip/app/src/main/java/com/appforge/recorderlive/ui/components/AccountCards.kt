package com.appforge.recorderlive.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableIntState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.appforge.recorderlive.data.Prefs
import kotlinx.coroutines.delay

/** Account cards shared by the Go live chooser and Settings. */

private val YtRed = Color(0xFFFF4D5E)
private val YtRedEdge = Color(0xFFB01B2E)
private val FbBlue = Color(0xFF1877F2)
private val FbBlueEdge = Color(0xFF0B4FAF)
private val GreyIcon = Color(0xFF9A93A3)
private val GreyIconEdge = Color(0xFF6F6A77)
private val DeepRed = Color(0xFFB3261E)

enum class FbStatus { NOT_ADDED, KEY_MISSING, READY }

fun facebookStatus(p: Prefs): FbStatus = when {
    p.facebookSelectedPageId.isNullOrBlank() -> FbStatus.NOT_ADDED
    !p.facebookRtmpServer.trim().startsWith("rtmps://", ignoreCase = true) || p.facebookRtmpKey.isBlank() -> FbStatus.KEY_MISSING
    else -> FbStatus.READY
}

/** Counter that goes up every time the screen resumes, so cards re-read saved settings. */
@Composable
fun rememberResumeTick(): MutableIntState {
    val tick = remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick.intValue++ }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    return tick
}

@Composable
private fun PlatformTile(facebook: Boolean, active: Boolean) {
    ToneSurface(
        container = if (!active) GreyIcon else if (facebook) FbBlue else YtRed,
        edge = if (!active) GreyIconEdge else if (facebook) FbBlueEdge else YtRedEdge,
        shape = RoundedCornerShape(14.dp), depth = 3.dp, modifier = Modifier.size(40.dp)
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (facebook) Text("f", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            else Icon(Icons.Outlined.PlayArrow, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
private fun StatusChip(text: String, dot: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.78f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1D1B20))
    }
}

@Composable
private fun TitleField(value: String, onChange: (String) -> Unit, trailing: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    OutlinedTextField(
        value = value, onValueChange = { onChange(it.take(100)) },
        label = { Text("Stream title") }, singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = cs.surfaceContainerLowest, unfocusedContainerColor = cs.surfaceContainerLowest
        ),
        trailingIcon = trailing,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun YouTubeAccountCard(
    connected: Boolean,
    name: String,
    detail: String,
    onGoLive: () -> Unit,
    onConnect: () -> Unit,
    modifier: Modifier = Modifier,
    title: String? = null,
    onTitleChange: ((String) -> Unit)? = null,
    onSignOut: (() -> Unit)? = null,
    signOutLabel: String = "Sign out",
    goLiveEnabled: Boolean = true,
) {
    val cs = MaterialTheme.colorScheme
    val c = toneColors(Tone.Red)
    ToneSurface(
        container = if (connected) c.container else cs.surfaceContainer,
        edge = if (connected) c.edge else cs.outlineVariant,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PlatformTile(facebook = false, active = connected)
                Column(Modifier.weight(1f)) {
                    Text(
                        if (connected) name else "YouTube not connected",
                        fontSize = 16.sp, fontWeight = FontWeight.Medium,
                        color = if (connected) c.onContainer else cs.onSurface
                    )
                    Text(
                        if (connected) detail else "Add your Google account or a brand channel to stream.",
                        fontSize = 13.sp, color = if (connected) c.onContainer else cs.onSurfaceVariant
                    )
                }
                if (connected) StatusChip("Ready", Color(0xFF00A06A))
            }
            if (!connected) {
                ExpressiveButtonText("Add YouTube account", onClick = onConnect, modifier = Modifier.fillMaxWidth())
            } else {
                if (title != null && onTitleChange != null) {
                    TitleField(title, onTitleChange) { Icon(Icons.Outlined.Edit, null, modifier = Modifier.size(18.dp)) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    ExpressiveButtonText(
                        "Go live on YouTube", onClick = onGoLive, enabled = goLiveEnabled,
                        variant = ButtonVariant.Live, modifier = Modifier.weight(1f), compact = onSignOut != null
                    )
                    if (onSignOut != null) ExpressiveButtonText(
                        signOutLabel, onClick = onSignOut, variant = ButtonVariant.Tonal, compact = true,
                        modifier = Modifier.weight(0.7f)
                    )
                }
            }
        }
    }
}

@Composable
fun FacebookAccountCard(
    status: FbStatus,
    pageName: String?,
    onGoLive: () -> Unit,
    onSetup: () -> Unit,
    modifier: Modifier = Modifier,
    title: String? = null,
    onTitleChange: ((String) -> Unit)? = null,
    onSignOut: ((removeKey: Boolean) -> Unit)? = null,
    goLiveEnabled: Boolean = true,
) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val blue = FacebookBlueTone()
    val added = status != FbStatus.NOT_ADDED
    var copied by remember { mutableStateOf(false) }
    var confirmSignOut by remember { mutableStateOf(false) }
    var removeKey by remember { mutableStateOf(true) }
    LaunchedEffect(copied) { if (copied) { delay(1500); copied = false } }

    ToneSurface(
        container = if (added) blue.container else cs.surfaceContainer,
        edge = if (added) blue.edge else cs.outlineVariant,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PlatformTile(facebook = true, active = added)
                Column(Modifier.weight(1f)) {
                    Text(
                        if (added) pageName.orEmpty().ifBlank { "Facebook Page" } else "Facebook not connected",
                        fontSize = 16.sp, fontWeight = FontWeight.Medium,
                        color = if (added) blue.onContainer else cs.onSurface
                    )
                    Text(
                        if (added) "Facebook Page" else "Add your Facebook account and a Page to stream.",
                        fontSize = 13.sp, color = if (added) blue.onContainer else cs.onSurfaceVariant
                    )
                }
                when (status) {
                    FbStatus.READY -> StatusChip("Ready", Color(0xFF00A06A))
                    FbStatus.KEY_MISSING -> StatusChip("Key missing", Color(0xFFE6A100))
                    FbStatus.NOT_ADDED -> {}
                }
            }
            when (status) {
                FbStatus.NOT_ADDED -> ExpressiveButtonText(
                    "Add Facebook Page", onClick = onSetup, variant = ButtonVariant.Facebook, modifier = Modifier.fillMaxWidth()
                )
                FbStatus.KEY_MISSING -> {
                    Text("Your Page is saved. Add the RTMPS stream key to finish.", fontSize = 13.sp, color = blue.onContainer)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        ExpressiveButtonText(
                            "Finish setup", onClick = onSetup, variant = ButtonVariant.Facebook,
                            modifier = Modifier.weight(1f), compact = onSignOut != null
                        )
                        if (onSignOut != null) ExpressiveButtonText(
                            "Sign out", onClick = { confirmSignOut = true }, variant = ButtonVariant.Tonal,
                            compact = true, modifier = Modifier.weight(0.7f)
                        )
                    }
                }
                FbStatus.READY -> {
                    if (title != null && onTitleChange != null) {
                        TitleField(title, onTitleChange) {
                            TextButton(onClick = {
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("Stream title", title))
                                copied = true
                            }) { Text(if (copied) "Copied ✓" else "Copy", color = FbBlue, fontWeight = FontWeight.Medium) }
                        }
                        Text(
                            "Saved in the app. Facebook shows it only after you paste it in Live Producer.",
                            fontSize = 12.sp, color = blue.onContainer
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        ExpressiveButtonText(
                            "Go live", onClick = onGoLive, enabled = goLiveEnabled, variant = ButtonVariant.Facebook,
                            modifier = Modifier.weight(1.3f), compact = onSignOut != null
                        )
                        if (onSignOut != null) {
                            ExpressiveButtonText("Manage", onClick = onSetup, variant = ButtonVariant.Tonal, compact = true, modifier = Modifier.weight(1f))
                            ExpressiveButtonText("Sign out", onClick = { confirmSignOut = true }, variant = ButtonVariant.Tonal, compact = true, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }

    if (confirmSignOut && onSignOut != null) {
        AlertDialog(
            onDismissRequest = { confirmSignOut = false },
            title = { Text("Sign out of Facebook?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("This removes the saved Page and its encrypted token from this device.")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = removeKey, onCheckedChange = { removeKey = it })
                        Text("Also remove saved stream key")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { confirmSignOut = false; onSignOut(removeKey) }) {
                    Text("Sign out", color = DeepRed, fontWeight = FontWeight.Medium)
                }
            },
            dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text("Cancel") } }
        )
    }
}

/** Light blue (dark blue in dark mode) tone used for Facebook cards. */
@Composable
private fun FacebookBlueTone(): ToneColors {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    return if (dark) ToneColors(Color(0xFF16335F), Color(0xFF0D2244), Color(0xFFD9E8FF), Color(0xFF8DB8FF), Color(0xFF1D1B20))
    else ToneColors(Color(0xFFD9E8FF), Color(0xFF9DBFF5), Color(0xFF0A2E66), Color(0xFF1877F2), Color.White)
}
