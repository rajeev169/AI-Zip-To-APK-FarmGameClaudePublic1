package com.appforge.recorderlive.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * Material 3 Expressive building blocks.
 * Depth comes from a solid, darker "edge" under every surface (flat fills, no blur),
 * large rounded shapes, and a different tonal colour for each step.
 */

enum class Tone { Violet, Pink, Mint, Amber, Red, Neutral }

data class ToneColors(
    val container: Color,
    val edge: Color,
    val onContainer: Color,
    val accent: Color,
    val onAccent: Color,
)

@Composable
fun toneColors(tone: Tone): ToneColors {
    val dark = isSystemInDarkTheme()
    val onAccent = if (dark) Color(0xFF1D1B20) else Color.White
    return if (dark) when (tone) {
        Tone.Violet -> ToneColors(Color(0xFF352A6E), Color(0xFF231A4D), Color(0xFFE8E2FF), Color(0xFF9C8BFF), onAccent)
        Tone.Pink -> ToneColors(Color(0xFF5C2338), Color(0xFF3F1626), Color(0xFFFFDCE6), Color(0xFFFF8FB1), onAccent)
        Tone.Mint -> ToneColors(Color(0xFF14503A), Color(0xFF0B3626), Color(0xFFCDF4DA), Color(0xFF6FDDA2), onAccent)
        Tone.Amber -> ToneColors(Color(0xFF5A4210), Color(0xFF3D2C08), Color(0xFFFFE7B8), Color(0xFFF2BE5C), onAccent)
        Tone.Red -> ToneColors(Color(0xFF7A2A22), Color(0xFF521A14), Color(0xFFFFDAD4), Color(0xFFFF8A7E), onAccent)
        Tone.Neutral -> ToneColors(Color(0xFF2B2731), Color(0xFF1C1822), Color(0xFFE7E0EB), Color(0xFFCBC4D2), onAccent)
    } else when (tone) {
        Tone.Violet -> ToneColors(Color(0xFFE8E2FF), Color(0xFFC7BCF7), Color(0xFF2A1A99), Color(0xFF6B4EFF), onAccent)
        Tone.Pink -> ToneColors(Color(0xFFFFDCE6), Color(0xFFF4B3C6), Color(0xFF5C1535), Color(0xFFC2185B), onAccent)
        Tone.Mint -> ToneColors(Color(0xFFCDF4DA), Color(0xFF9ED9B3), Color(0xFF00402B), Color(0xFF00875A), onAccent)
        Tone.Amber -> ToneColors(Color(0xFFFFE7B8), Color(0xFFEBC472), Color(0xFF4F3300), Color(0xFFB77400), onAccent)
        Tone.Red -> ToneColors(Color(0xFFFFDAD4), Color(0xFFF2A99F), Color(0xFF7A0E07), Color(0xFFE5384F), onAccent)
        Tone.Neutral -> ToneColors(Color.White, Color(0xFFE4DDEA), Color(0xFF1D1B20), Color(0xFF5E5A66), onAccent)
    }
}

/** Solid surface with a darker bottom edge. Optional click with a pressed state. */
@Composable
fun ToneSurface(
    container: Color,
    edge: Color,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    depth: Dp = 4.dp,
    onClick: (() -> Unit)? = null,
    role: Role? = null,
    onClickLabel: String? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val click = if (onClick != null) Modifier.clickable(onClickLabel = onClickLabel, role = role, onClick = onClick) else Modifier
    Box(modifier.clip(shape).background(edge).then(click)) {
        Box(Modifier.fillMaxWidth().padding(bottom = depth).clip(shape).background(container), content = content)
    }
}

@Composable
fun TonalCard(tone: Tone, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = toneColors(tone)
    ToneSurface(c.container, c.edge, modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            CompositionLocalProvider(LocalContentColor provides c.onContainer) { content() }
        }
    }
}

@Composable
fun StepBadge(number: Int, tone: Tone) {
    val c = toneColors(tone)
    Box(Modifier.size(28.dp).clip(CircleShape).background(c.accent), contentAlignment = Alignment.Center) {
        Text("$number", color = c.onAccent, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun StepHeader(number: Int, title: String, tone: Tone) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StepBadge(number, tone)
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
    }
}

enum class ButtonVariant { Filled, Tonal, Success, Live, Facebook }

private data class BtnColors(val face: Color, val edge: Color, val content: Color, val ring: Color?)

@Composable
private fun btnColors(v: ButtonVariant, enabled: Boolean): BtnColors {
    val dark = isSystemInDarkTheme()
    val cs = MaterialTheme.colorScheme
    if (!enabled) return BtnColors(cs.surfaceContainerHigh, cs.surfaceContainerHigh, cs.onSurface.copy(alpha = 0.38f), null)
    return when (v) {
        ButtonVariant.Filled ->
            if (dark) BtnColors(Color(0xFFC9BEFF), Color(0xFF8E7FE0), Color(0xFF2B1A8A), null)
            else BtnColors(Color(0xFF6B4EFF), Color(0xFF4630C2), Color.White, null)
        ButtonVariant.Tonal -> {
            val edge = toneColors(Tone.Violet).edge
            BtnColors(cs.surfaceContainerLowest, edge, if (dark) Color(0xFFC9BEFF) else Color(0xFF3B2A99), edge)
        }
        ButtonVariant.Success ->
            if (dark) BtnColors(Color(0xFF4CCB93), Color(0xFF0B6B47), Color(0xFF00311F), null)
            else BtnColors(Color(0xFF00A06A), Color(0xFF006B47), Color.White, null)
        ButtonVariant.Live -> BtnColors(Color(0xFFE5384F), Color(0xFF9E1229), Color.White, null)
        ButtonVariant.Facebook -> BtnColors(Color(0xFF1877F2), Color(0xFF0B4FAF), Color.White, null)
    }
}

/** Pill button with a thick bottom edge that squashes when pressed. */
@Composable
fun ExpressiveButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: ButtonVariant = ButtonVariant.Filled,
    enabled: Boolean = true,
    compact: Boolean = false,
    content: @Composable RowScope.() -> Unit,
) {
    val c = btnColors(variant, enabled)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val depth by animateDpAsState(if (pressed && enabled) 1.dp else 4.dp, label = "buttonDepth")
    val shape = RoundedCornerShape(50)
    Box(
        modifier.clip(shape).background(c.edge)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, role = Role.Button, onClick = onClick)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp - depth, bottom = depth).heightIn(min = 46.dp)
                .clip(shape).background(c.face)
                .then(if (c.ring != null) Modifier.border(1.dp, c.ring, shape) else Modifier)
                .padding(horizontal = if (compact) 8.dp else 20.dp, vertical = if (compact) 8.dp else 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
        ) {
            CompositionLocalProvider(LocalContentColor provides c.content) { content() }
        }
    }
}

@Composable
fun ExpressiveButtonText(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: ButtonVariant = ButtonVariant.Filled,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    compact: Boolean = false,
) {
    ExpressiveButton(onClick, modifier, variant, enabled, compact) {
        if (icon != null) Icon(icon, null, modifier = Modifier.size(20.dp))
        Text(text, fontSize = if (compact) 13.sp else 15.sp, fontWeight = FontWeight.Medium)
    }
}

private val BlobShape = RoundedCornerShape(topStartPercent = 42, topEndPercent = 58, bottomEndPercent = 50, bottomStartPercent = 50)

/** The big blob-shaped record button with a darker layer underneath. */
@Composable
fun RecordBlob(
    size: Dp,
    color: Color,
    edge: Color,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClickLabel: String? = null,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val drop by animateDpAsState(if (pressed && enabled) 5.dp else 0.dp, label = "blobDrop")
    Box(modifier.size(width = size, height = size + 8.dp)) {
        Box(Modifier.size(size).offset(y = 8.dp).clip(BlobShape).background(edge))
        Box(
            Modifier.size(size).offset(y = drop).clip(BlobShape).background(color)
                .clickable(interactionSource = interaction, indication = null, enabled = enabled, role = Role.Button, onClickLabel = onClickLabel, onClick = onClick),
            contentAlignment = Alignment.Center,
            content = content
        )
    }
}
