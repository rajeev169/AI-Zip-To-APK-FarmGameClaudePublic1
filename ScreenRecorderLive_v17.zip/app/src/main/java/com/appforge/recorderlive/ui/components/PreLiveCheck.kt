package com.appforge.recorderlive.ui.components

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.StatFs
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.AppActions
import com.appforge.recorderlive.data.Prefs

enum class CheckLevel { OK, WARN, BLOCK }
data class CheckItem(val label: String, val detail: String, val level: CheckLevel)

/** Quick look at the phone before going live. Only "no internet" blocks; the rest are warnings. */
fun runPreLiveChecks(ctx: Context, p: Prefs, actions: AppActions): List<CheckItem> {
    val items = mutableListOf<CheckItem>()

    // Network
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = runCatching { cm.getNetworkCapabilities(cm.activeNetwork) }.getOrNull()
    items += when {
        caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ->
            CheckItem("Network", "No internet connection", CheckLevel.BLOCK)
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->
            CheckItem("Network", "Mobile data. Streaming can use a lot", CheckLevel.WARN)
        else -> CheckItem("Network", "Wi-Fi connected", CheckLevel.OK)
    }

    // Battery
    val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
    val status = bat?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    if (pct >= 0) items += if (pct < 15 && !charging)
        CheckItem("Battery $pct%", "Plug in to stream longer", CheckLevel.WARN)
    else CheckItem("Battery $pct%", if (charging) "Charging" else "Enough to start", CheckLevel.OK)

    // Permissions the live setup will need (the app asks for missing ones)
    val missing = buildList {
        if ((p.liveBubble || p.liveFaceCam) && !actions.canDrawOverlays()) add("overlay")
        if ((p.liveMic || p.liveGameSound) && !actions.hasPermission(Manifest.permission.RECORD_AUDIO)) add("microphone")
        if (p.liveFaceCam && !actions.hasPermission(Manifest.permission.CAMERA)) add("camera")
    }
    items += if (missing.isEmpty()) CheckItem("Permissions", "All set", CheckLevel.OK)
    else CheckItem("Permissions", "Will ask for: ${missing.joinToString(", ")}", CheckLevel.WARN)

    // Storage
    val freeGb = runCatching { StatFs(ctx.filesDir.path).availableBytes / 1_073_741_824.0 }.getOrDefault(-1.0)
    if (freeGb >= 0) items += if (freeGb < 1.0)
        CheckItem("Storage", "Low space. The replay may not save", CheckLevel.WARN)
    else CheckItem("Storage", String.format("%.0f GB free", freeGb), CheckLevel.OK)
    return items
}

@Composable
fun PreLiveDialog(
    p: Prefs,
    actions: AppActions,
    ctx: Context,
    confirmLabel: String,
    onContinue: () -> Unit,
    onDismiss: () -> Unit,
) {
    val items = remember { runPreLiveChecks(ctx, p, actions) }
    val blocked = items.any { it.level == CheckLevel.BLOCK }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ready to go live?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items.forEach { item ->
                    val tone = when (item.level) { CheckLevel.OK -> Tone.Mint; CheckLevel.WARN -> Tone.Amber; CheckLevel.BLOCK -> Tone.Red }
                    val c = toneColors(tone)
                    ToneSurface(c.container, c.edge, Modifier.fillMaxWidth(), shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp), depth = 3.dp) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(if (item.level == CheckLevel.OK) Icons.Outlined.Check else Icons.Outlined.Warning, null, tint = c.accent, modifier = Modifier.size(20.dp))
                            Column {
                                Text(item.label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = c.onContainer)
                                Text(item.detail, fontSize = 12.sp, color = c.onContainer)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            ExpressiveButtonText(confirmLabel, onClick = onContinue, enabled = !blocked, variant = ButtonVariant.Live, compact = true)
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
