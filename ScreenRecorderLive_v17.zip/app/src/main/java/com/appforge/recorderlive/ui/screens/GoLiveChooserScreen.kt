package com.appforge.recorderlive.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.AppActions
import com.appforge.recorderlive.MainViewModel
import com.appforge.recorderlive.service.Mode
import com.appforge.recorderlive.service.SessionStore
import com.appforge.recorderlive.ui.components.FacebookAccountCard
import com.appforge.recorderlive.ui.components.FbStatus
import com.appforge.recorderlive.ui.components.PreLiveDialog
import com.appforge.recorderlive.ui.components.YouTubeAccountCard
import com.appforge.recorderlive.ui.components.facebookStatus
import com.appforge.recorderlive.ui.components.rememberResumeTick
import com.appforge.recorderlive.youtube.AuthMode

/** "Go live" lands here: pick YouTube or Facebook. Each card has its own status, title and Go live button. */
@Composable
fun GoLiveChooserScreen(
    vm: MainViewModel,
    actions: AppActions,
    onBack: () -> Unit,
    onYouTubeGoLive: () -> Unit,
    onConnectYouTube: () -> Unit,
    onFacebookGoLive: () -> Unit,
    onSetupFacebook: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val p = vm.prefs
    val tick by rememberResumeTick()
    val signedIn by vm.signedIn.collectAsState()
    val authMode by vm.authMode.collectAsState()
    val channel by vm.channel.collectAsState()
    val session by SessionStore.state.collectAsState()
    val idle = session.mode == Mode.NONE

    var ytTitle by remember { mutableStateOf(p.liveTitle) }
    var fbTitle by remember { mutableStateOf(p.facebookLiveTitle) }
    var pre by remember { mutableStateOf<String?>(null) } // "yt" or "fb"
    val fbStatus = remember(tick) { facebookStatus(p) }
    val pageName = remember(tick) { p.facebookSelectedPageName }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
        Text("Go live", fontSize = 32.sp, fontWeight = FontWeight.Medium)
        Text("Choose where to stream your screen.", color = cs.onSurfaceVariant)

        YouTubeAccountCard(
            connected = signedIn,
            name = youTubeName(authMode, channel?.title),
            detail = youTubeDetail(authMode, channel?.email, p.streamKey),
            onGoLive = { pre = "yt" },
            onConnect = onConnectYouTube,
            title = if (authMode == AuthMode.KEY) null else ytTitle,
            onTitleChange = if (authMode == AuthMode.KEY) null else ({ t: String -> ytTitle = t; p.liveTitle = t }),
            goLiveEnabled = idle
        )
        FacebookAccountCard(
            status = fbStatus,
            pageName = pageName,
            onGoLive = { pre = "fb" },
            onSetup = onSetupFacebook,
            title = fbTitle,
            onTitleChange = { t -> fbTitle = t; p.facebookLiveTitle = t },
            goLiveEnabled = idle
        )
        Spacer(Modifier.height(12.dp))
    }

    pre?.let { which ->
        PreLiveDialog(
            p = p, actions = actions, ctx = ctx,
            confirmLabel = "Continue",
            onContinue = { pre = null; if (which == "yt") onYouTubeGoLive() else onFacebookGoLive() },
            onDismiss = { pre = null }
        )
    }
}

fun youTubeName(authMode: AuthMode, channelTitle: String?): String = when (authMode) {
    AuthMode.KEY -> "Stream key"
    AuthMode.NONE -> "Not connected"
    else -> channelTitle ?: "Signed in"
}

fun youTubeDetail(authMode: AuthMode, email: String?, streamKey: String?): String = when (authMode) {
    AuthMode.KEY -> "••••" + (streamKey?.takeLast(4) ?: "")
    AuthMode.WEB -> "Brand channel via Google"
    AuthMode.NATIVE -> email.orEmpty().ifBlank { "Google account" }
    AuthMode.NONE -> "Connect to go live"
}
