package com.appforge.recorderlive

import android.content.Context
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Live log: every step of going live (from the bubble or the app) with the time, plus every error.
 * Settings → Live log shows it with Copy / Clear. If a live never got on air, the app shows it the next time it opens.
 * Kept small: only the last ~600 lines.
 */
object LiveLog {
    private const val FILE = "live_log.txt"
    private const val FLAG = "live_log_failed"
    private const val MAX_LINES = 600
    private val lock = Any()
    private lateinit var app: Context

    fun init(context: Context) { app = context.applicationContext }

    private fun file() = File(app.filesDir, FILE)
    private fun sp() = app.getSharedPreferences("live_log", Context.MODE_PRIVATE)

    /** Starts a new block in the log (one per Go live attempt) */
    fun begin(from: String) {
        if (!::app.isInitialized) return
        val v = runCatching { app.packageManager.getPackageInfo(app.packageName, 0).versionName }.getOrNull()
        add("")
        add("===== Go live from $from · app $v · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MANUFACTURER} ${Build.MODEL}")
        sp().edit().putBoolean(FLAG, false).apply()
    }

    fun add(step: String) {
        if (!::app.isInitialized) return
        synchronized(lock) {
            runCatching {
                val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
                val f = file()
                f.appendText(if (step.isEmpty()) "\n" else "$time  $step\n")
                if (f.length() > 120_000) {   // trim to the last lines
                    val lines = f.readLines()
                    f.writeText(lines.takeLast(MAX_LINES).joinToString("\n", postfix = "\n"))
                }
            }
        }
    }

    fun error(step: String, e: Throwable?) =
        add("ERROR $step: ${e?.javaClass?.simpleName}: ${e?.message}" + (e?.stackTrace?.take(4)?.joinToString("") { "\n      at $it" } ?: ""))

    /** The live never got on air: show the log next time the app opens */
    fun markFailed(reason: String?) {
        if (!::app.isInitialized) return
        add("✗ LIVE DID NOT START / STOPPED: $reason")
        sp().edit().putBoolean(FLAG, true).apply()
    }

    fun read(): String = if (!::app.isInitialized) "" else synchronized(lock) { runCatching { file().readText() }.getOrDefault("") }.trim()
    fun failedLastTime(): Boolean = ::app.isInitialized && sp().getBoolean(FLAG, false)
    fun clearFlag() { if (::app.isInitialized) sp().edit().putBoolean(FLAG, false).apply() }
    fun clear() { if (!::app.isInitialized) return; synchronized(lock) { runCatching { file().delete() } }; clearFlag() }
}
