package com.appforge.recorderlive.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.appforge.recorderlive.AppActions
import com.appforge.recorderlive.ConnectResult
import com.appforge.recorderlive.MainViewModel
import com.appforge.recorderlive.data.FacebookPageOption
import com.appforge.recorderlive.service.Mode
import com.appforge.recorderlive.service.SessionStore
import com.appforge.recorderlive.ui.screens.ConnectScreen
import com.appforge.recorderlive.ui.screens.FacebookSetupScreen
import com.appforge.recorderlive.ui.screens.GoLiveChooserScreen
import com.appforge.recorderlive.ui.screens.GoLiveSetupScreen
import com.appforge.recorderlive.ui.screens.HomeScreen
import com.appforge.recorderlive.ui.screens.LiveScreen
import com.appforge.recorderlive.ui.screens.NotEnabledScreen
import com.appforge.recorderlive.ui.screens.RecordingsScreen
import com.appforge.recorderlive.ui.screens.SettingsScreen
import com.appforge.recorderlive.ui.screens.StartingScreen
import com.appforge.recorderlive.ui.screens.StreamKeyScreen

object Routes {
    const val HOME = "home"
    const val RECORDINGS = "recordings"
    const val CONNECT = "connect"
    const val NOT_ENABLED = "not_enabled"
    const val SETUP = "setup"
    const val STARTING = "starting"
    const val LIVE = "live"
    const val SETTINGS = "settings"
    const val STREAM_KEY = "stream_key"
    const val FACEBOOK = "facebook_setup"
    const val GO_LIVE = "go_live"
}

/** Where the "Live" button should go right now. */
fun liveRoute(@Suppress("UNUSED_PARAMETER") signedIn: Boolean): String = when {
    SessionStore.state.value.mode == Mode.LIVE -> Routes.LIVE
    else -> Routes.GO_LIVE
}

fun NavHostController.goTab(route: String) = navigate(route) {
    popUpTo(Routes.HOME) { saveState = true }
    launchSingleTop = true
    restoreState = true
}

@Composable
fun AppRoot(vm: MainViewModel, actions: AppActions) {
    val nav = rememberNavController()
    val snackbar = remember { SnackbarHostState() }
    val toast by SessionStore.toast.collectAsState()
    val signedIn by vm.signedIn.collectAsState()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    val ctx = androidx.compose.ui.platform.LocalContext.current
    val alert by SessionStore.alert.collectAsState()
    var crash by remember { mutableStateOf(com.appforge.recorderlive.CrashReporter.lastCrash(ctx)) }
    // A live that never got on air (e.g. from the bubble while in a game): show its log once the app is opened
    var liveFailed by remember { mutableStateOf(false) }
    val sess by SessionStore.state.collectAsState()
    LaunchedEffect(sess.mode, sess.phase) {
        if (sess.mode == com.appforge.recorderlive.service.Mode.NONE && com.appforge.recorderlive.LiveLog.failedLastTime()) liveFailed = true
    }
    if (liveFailed && crash == null) com.appforge.recorderlive.ui.screens.LiveLogDialog(failed = true) {
        com.appforge.recorderlive.LiveLog.clearFlag(); liveFailed = false
    }

    alert?.let { (title, message) ->
        AlertDialog(
            onDismissRequest = { SessionStore.clearAlert() },
            title = { Text(title) },
            text = { Text(message) },
            confirmButton = { TextButton(onClick = { SessionStore.clearAlert() }) { Text("OK") } },
            dismissButton = {
                if (title.startsWith("Facebook key")) {
                    TextButton(onClick = { SessionStore.clearAlert(); actions.openUrl("https://www.facebook.com/live/producer") }) { Text("Open Live Producer") }
                }
            }
        )
    }

    crash?.let { report ->
        AlertDialog(
            onDismissRequest = { },
            title = { Text("App diagnostic report") },
            text = {
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    Text("An app or Facebook connection error was recorded. Copy this report and send it to the developer:", fontSize = 13.sp)
                    Text(report, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Crash report", report))
                    SessionStore.toast("Crash report copied")
                }) { Text("Copy") }
            },
            dismissButton = {
                TextButton(onClick = {
                    com.appforge.recorderlive.CrashReporter.clear(ctx)
                    crash = null
                }) { Text("Close") }
            }
        )
    }

    val routeRequest by SessionStore.openRouteRequest.collectAsState()
    LaunchedEffect(routeRequest) {
        if (routeRequest == "connect") {
            // Wait until the screens are ready (app may have just been opened from the bubble)
            while (nav.currentBackStackEntry == null) kotlinx.coroutines.delay(50)
            SessionStore.openRoute(null)
            runCatching { nav.navigate(Routes.CONNECT) { launchSingleTop = true } }
        }
    }

    LaunchedEffect(toast) {
        val msg = toast ?: return@LaunchedEffect
        SessionStore.toast(null)
        snackbar.showSnackbar(msg)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (route == Routes.HOME || route == Routes.RECORDINGS) {
                NavigationBar {
                    NavigationBarItem(
                        selected = route == Routes.HOME, onClick = { nav.goTab(Routes.HOME) },
                        icon = { Icon(Icons.Outlined.Home, null) }, label = { Text("Home") }
                    )
                    NavigationBarItem(
                        selected = route == Routes.RECORDINGS, onClick = { nav.goTab(Routes.RECORDINGS) },
                        icon = { Icon(Icons.Outlined.VideoLibrary, null) }, label = { Text("Recordings") }
                    )
                    NavigationBarItem(
                        selected = false, onClick = { nav.navigate(liveRoute(signedIn)) },
                        icon = { Icon(Icons.Outlined.Sensors, null) }, label = { Text("Live") }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = Routes.HOME, modifier = Modifier.padding(padding)) {
            composable(Routes.HOME) {
                HomeScreen(vm, actions,
                    onGoLive = { nav.navigate(liveRoute(signedIn)) },
                    onSeeAll = { nav.goTab(Routes.RECORDINGS) },
                    onSettings = { nav.navigate(Routes.SETTINGS) })
            }
            composable(Routes.RECORDINGS) { RecordingsScreen(vm, actions) }
            composable(Routes.GO_LIVE) {
                GoLiveChooserScreen(vm, actions,
                    onBack = { nav.popBackStack() },
                    onYouTubeGoLive = { nav.navigate(Routes.SETUP) },
                    onConnectYouTube = { nav.navigate(Routes.CONNECT) },
                    onFacebookGoLive = { actions.startFacebookLive { nav.navigate(Routes.STARTING) } },
                    onSetupFacebook = { nav.navigate(Routes.FACEBOOK) })
            }
            composable(Routes.CONNECT) {
                val toSetup = { nav.navigate(Routes.SETUP) { popUpTo(Routes.HOME) } }
                ConnectScreen(
                    onClose = { nav.popBackStack() },
                    onGoogle = { done ->
                        actions.signInNative { r -> done(r); if (r == ConnectResult.OK) toSetup() }
                    },
                    onBrandChannel = { done ->
                        actions.signInWeb { r -> done(r); if (r == ConnectResult.OK) toSetup() }
                    },
                    onStreamKey = { nav.navigate(Routes.STREAM_KEY) },
                    onFacebook = { nav.navigate(Routes.FACEBOOK) }
                )
            }
            composable(Routes.FACEBOOK) {
                FacebookSetupScreen(
                    onBack = { nav.popBackStack() },
                    onLogin = { page, callback -> actions.facebookLogin(page, callback) },
                    onSelectPage = { page -> actions.selectFacebookPage(page) },
                    onRemovePage = { actions.removeFacebookPage() },
                    onStartLive = { actions.startFacebookLive { nav.navigate(Routes.STARTING) } }
                )
            }
            composable(Routes.STREAM_KEY) {
                StreamKeyScreen(
                    initialKey = vm.prefs.streamKey,
                    onBack = { nav.popBackStack() },
                    onOpenStudio = { actions.openUrl("https://studio.youtube.com") },
                    onSave = { key ->
                        vm.saveStreamKey(key)
                        nav.navigate(Routes.SETUP) { popUpTo(Routes.HOME) }
                    }
                )
            }
            composable(Routes.NOT_ENABLED) {
                NotEnabledScreen(
                    channelName = vm.channel.collectAsState().value?.title,
                    onClose = { nav.popBackStack(Routes.HOME, false) },
                    onOpenStudio = { actions.openUrl("https://studio.youtube.com") },
                    onCheckAgain = { nav.popBackStack() }
                )
            }
            composable(Routes.SETUP) {
                GoLiveSetupScreen(vm, actions,
                    onBack = { nav.popBackStack() },
                    onSwitch = { nav.navigate(Routes.CONNECT) },
                    onStarted = { nav.navigate(Routes.STARTING) })
            }
            composable(Routes.STARTING) {
                StartingScreen(
                    onCancel = { actions.stopSession(); nav.popBackStack() },
                    onLive = { nav.navigate(Routes.LIVE) { popUpTo(Routes.SETUP) } },
                    onNotEnabled = { nav.navigate(Routes.NOT_ENABLED) { popUpTo(Routes.SETUP) } },
                    onFailed = { nav.popBackStack() }
                )
            }
            composable(Routes.LIVE) {
                LiveScreen(actions,
                    onEnded = { nav.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } } })
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(vm, actions,
                    onBack = { nav.popBackStack() },
                    onConnectYouTube = { nav.navigate(Routes.CONNECT) },
                    onYouTubeGoLive = { nav.navigate(Routes.SETUP) },
                    onSetupFacebook = { nav.navigate(Routes.FACEBOOK) },
                    onFacebookGoLive = { actions.startFacebookLive { nav.navigate(Routes.STARTING) } })
            }
        }
    }
}
