package com.appforge.recorderlive.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.LiveLog
import com.appforge.recorderlive.service.SessionStore

/** Live log with Copy / Clear. [failed] = opened automatically because the last live didn't start. */
@Composable
fun LiveLogDialog(failed: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val text = LiveLog.read()
    val scroll = rememberScrollState()
    LaunchedEffect(Unit) { scroll.scrollTo(scroll.maxValue) }   // newest lines are at the bottom
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (failed) "Last live didn't start" else "Live log") },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(scroll)) {
                Text(
                    if (failed) "Tap Copy and send this log to the developer. It shows each step and where it stopped."
                    else "Each step of your recent lives. Tap Copy to share it.",
                    fontSize = 13.sp
                )
                SelectionContainer {
                    Text(text.ifBlank { "Nothing yet. Go live once, then come back here." },
                        fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 15.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        },
        confirmButton = {
            TextButton(enabled = text.isNotBlank(), onClick = {
                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Live log", text))
                SessionStore.toast("Live log copied")
            }) { Text("Copy") }
        },
        dismissButton = {
            Row2(
                { TextButton(onClick = { LiveLog.clear(); SessionStore.toast("Live log cleared"); onClose() }) { Text("Clear") } },
                { TextButton(onClick = { LiveLog.clearFlag(); onClose() }) { Text("Close") } }
            )
        }
    )
}

@Composable
private fun Row2(a: @Composable () -> Unit, b: @Composable () -> Unit) =
    androidx.compose.foundation.layout.Row { a(); b() }
