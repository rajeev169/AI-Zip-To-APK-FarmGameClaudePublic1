package com.appforge.recorderlive.ui.screens

import android.Manifest
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.outlined.CenterFocusWeak
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.recorderlive.AppActions
import com.appforge.recorderlive.MainViewModel
import com.appforge.recorderlive.R
import com.appforge.recorderlive.service.CaptureService
import com.appforge.recorderlive.service.SessionStore
import com.appforge.recorderlive.ui.components.BubbleColors
import com.appforge.recorderlive.ui.components.BubbleIcon
import com.appforge.recorderlive.data.FpsSupport
import com.appforge.recorderlive.ui.components.FpsDropdown
import com.appforge.recorderlive.ui.components.LabeledSection
import com.appforge.recorderlive.ui.components.bubbleIconTint
import com.appforge.recorderlive.youtube.AuthMode
import com.appforge.recorderlive.ui.components.Segmented

@Composable
fun SettingsScreen(
    vm: MainViewModel,
    actions: AppActions,
    onBack: () -> Unit,
    onConnectYouTube: () -> Unit,
    onYouTubeGoLive: () -> Unit,
    onSetupFacebook: () -> Unit,
    onFacebookGoLive: () -> Unit,
) {
    val p = vm.prefs
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val signedIn by vm.signedIn.collectAsState()
    val authMode by vm.authMode.collectAsState()
    val channel by vm.channel.collectAsState()
    val liveSession by SessionStore.state.collectAsState()
    val idle = liveSession.mode == com.appforge.recorderlive.service.Mode.NONE
    val resumeTick by com.appforge.recorderlive.ui.components.rememberResumeTick()
    var fbRefresh by remember { mutableStateOf(0) }
    var preLive by remember { mutableStateOf<String?>(null) }
    var res by remember { mutableStateOf(if (p.recHeight >= 1080) 1 else 0) }
    var fps by remember { mutableStateOf(p.recFps) }
    val recHeight = if (res == 1) 1080 else 720
    // Which frame rates this phone can record at the chosen resolution
    val fpsOptions = remember(recHeight) { FpsSupport.recordingOptions(ctx, recHeight) }
    LaunchedEffect(fpsOptions) {
        val best = FpsSupport.bestOf(fpsOptions, fps)
        if (best != fps) { fps = best; p.recFps = best }
    }
    var gameSound by remember { mutableStateOf(p.recGameSound) }
    var autoHide by remember { mutableStateOf(p.bubbleAutoHide) }
    var alwaysBubble by remember { mutableStateOf(p.floatingBubble) }
    val bubbleColor by SessionStore.bubbleColor.collectAsState()
    val menuDark by SessionStore.bubbleMenuDark.collectAsState()

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.height(64.dp).padding(start = 4.dp, end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back") }
            Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Medium)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text("Recording", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = cs.primary)
            LabeledSection("Resolution") {
                Segmented(listOf("720p", "1080p"), res, { res = it; p.recHeight = if (it == 1) 1080 else 720 })
            }
            LabeledSection("Frame rate") {
                FpsDropdown("Recording frame rate", fpsOptions, fps, { fps = it; p.recFps = it })
            }
            Surface(
                shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerLowest,
                border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Record game sound", fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Switch(checked = gameSound, onCheckedChange = {
                        gameSound = it; p.recGameSound = it
                        if (it) actions.ensurePermissions(listOf(Manifest.permission.RECORD_AUDIO)) {}
                    })
                }
            }

            Text("Floating bubble", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = cs.primary)
            Surface(
                shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerLowest,
                border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Always show bubble", fontSize = 15.sp)
                        Text(
                            "Keeps the bubble on screen so you can start recording from inside any app or game. The Start recording button on Home still works too.",
                            fontSize = 13.sp, color = cs.onSurfaceVariant, lineHeight = 18.sp
                        )
                    }
                    Switch(
                        checked = alwaysBubble,
                        onCheckedChange = { on ->
                            if (on) {
                                actions.ensureOverlay {
                                    if (actions.canDrawOverlays()) {
                                        alwaysBubble = true; p.floatingBubble = true
                                        CaptureService.showBubble(ctx)
                                    }
                                }
                            } else {
                                alwaysBubble = false; p.floatingBubble = false
                                CaptureService.hideBubble(ctx)
                            }
                        },
                        modifier = Modifier.padding(start = 12.dp)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerLowest,
                border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Bubble colour", fontSize = 15.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BubbleColors.forEach { argb ->
                            val selected = argb == bubbleColor
                            Box(
                                Modifier.weight(1f).aspectRatio(1f)
                                    .clip(CircleShape)
                                    .border(if (selected) 3.dp else 1.dp, if (selected) cs.primary else cs.outlineVariant, CircleShape)
                                    .padding(if (selected) 4.dp else 0.dp)
                                    .clip(CircleShape)
                                    .background(Color(argb))
                                    .clickable(onClickLabel = "Choose bubble colour") {
                                        p.bubbleColor = argb; SessionStore.setBubbleColor(argb)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (selected) Icon(Icons.Outlined.Check, "Selected", tint = bubbleIconTint(Color(argb)), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                    Text("Menu colour", fontSize = 15.sp)
                    Segmented(listOf("Light", "Dark"), if (menuDark) 1 else 0, { i ->
                        p.bubbleMenuDark = i == 1; SessionStore.setBubbleMenuDark(i == 1)
                    })
                    // Preview: bubble + a small menu strip in the chosen colours
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        BubbleIcon(48.dp, color = Color(bubbleColor))
                        Row(
                            Modifier.clip(RoundedCornerShape(24.dp))
                                .background(if (menuDark) Color(0xFF2A2A33) else Color(0xFFFBF8FF))
                                .border(1.dp, cs.outlineVariant, RoundedCornerShape(24.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val tint = if (menuDark) Color.White else Color(0xFF46464F)
                            Icon(Icons.Outlined.Pause, null, tint = tint, modifier = Modifier.size(20.dp))
                            Box(Modifier.size(14.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFFB3261E)))
                            Icon(Icons.Outlined.Mic, null, tint = tint, modifier = Modifier.size(20.dp))
                            Icon(Icons.Outlined.CenterFocusWeak, null, tint = tint, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerLowest,
                border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Auto-hide bubble", fontSize = 15.sp)
                        Text(
                            "Menu closes after 3 seconds and the bubble shrinks to a small faded dot. Tap the dot to bring it back.",
                            fontSize = 13.sp, color = cs.onSurfaceVariant, lineHeight = 18.sp
                        )
                    }
                    Switch(
                        checked = autoHide,
                        onCheckedChange = { autoHide = it; p.bubbleAutoHide = it },
                        modifier = Modifier.padding(start = 12.dp)
                    )
                }
            }

            Text("YouTube", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = cs.primary)
            com.appforge.recorderlive.ui.components.YouTubeAccountCard(
                connected = signedIn,
                name = youTubeName(authMode, channel?.title),
                detail = youTubeDetail(authMode, channel?.email, p.streamKey),
                onGoLive = { preLive = "yt" },
                onConnect = onConnectYouTube,
                onSignOut = if (signedIn) ({ vm.signOut() }) else null,
                signOutLabel = if (authMode == AuthMode.KEY) "Remove key" else "Sign out",
                goLiveEnabled = idle
            )

            Text("Facebook", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = cs.primary)
            val fbStatus = remember(resumeTick, fbRefresh) { com.appforge.recorderlive.ui.components.facebookStatus(p) }
            val fbPage = remember(resumeTick, fbRefresh) { p.facebookSelectedPageName }
            com.appforge.recorderlive.ui.components.FacebookAccountCard(
                status = fbStatus,
                pageName = fbPage,
                onGoLive = { preLive = "fb" },
                onSetup = onSetupFacebook,
                onSignOut = { removeKey -> actions.facebookSignOut(removeKey); fbRefresh++ },
                goLiveEnabled = idle
            )

            Text("Help", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = cs.primary)
            var showLog by remember { mutableStateOf(false) }
            if (showLog) LiveLogDialog(failed = false) { showLog = false }
            Surface(
                onClick = { showLog = true },
                shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerLowest,
                border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                    Text("Live log", fontSize = 15.sp)
                    Text("Each step of your recent lives — copy it if going live doesn't work", fontSize = 13.sp, color = cs.onSurfaceVariant)
                }
            }

            Text("About", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = cs.primary)
            val version = remember {
                runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""
            }
            Text("${stringResource(R.string.app_name)} $version", fontSize = 14.sp, color = cs.onSurfaceVariant)
        }
    }

    preLive?.let { which ->
        com.appforge.recorderlive.ui.components.PreLiveDialog(
            p = p, actions = actions, ctx = ctx, confirmLabel = "Continue",
            onContinue = { preLive = null; if (which == "yt") onYouTubeGoLive() else onFacebookGoLive() },
            onDismiss = { preLive = null }
        )
    }
}
