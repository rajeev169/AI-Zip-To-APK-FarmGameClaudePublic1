# Facebook integration status (v9 foundation)

This archive adds the Meta Facebook Login Android SDK dependency and app-level configuration using the App ID and Client Token supplied by the app owner.

## Configured
- Facebook Login SDK dependency: `com.facebook.android:facebook-login:18.2.3`
- Meta App ID: `1084883637715469`
- Client Token configured as an Android resource (not the App Secret)
- Facebook SDK manifest metadata, FacebookActivity and CustomTabActivity
- Android package target: `com.appforge.recorderlive`
- Existing YouTube implementation and its source files are left unchanged

## Not yet implemented / not represented as working
- Facebook Login callback and user session UI
- Facebook Page listing/selection and Graph API permission flow
- Facebook personal-profile Live publishing (not generally available via the standard Live API; depends on Meta product access)
- Facebook RTMPS encoder output and independent Facebook start/stop controls
- Simultaneous YouTube + Facebook multi-output streaming

The Client Token is not an App Secret. Never put the App Secret in the APK. A production OAuth/backend design and Meta-approved permissions are required for Page publishing. RTMPS streaming requires a separate output implementation and must be tested with a valid Facebook ingest URL/key.

## Meta dashboard steps still required
1. In Meta App Settings > Basic > Android platform, set package name `com.appforge.recorderlive`.
2. Set Default Activity Class Name to `com.appforge.recorderlive.MainActivity`.
3. Add the debug and release key hashes for the exact signing keys used to build/install the APK.
4. Configure valid OAuth redirect/login settings as required by the selected Facebook Login product.
5. Test in Development mode with app roles first. Request App Review/advanced access before external users use permissions that require it.

## Important
This is an SDK/configuration foundation ZIP, not a claim that all three Facebook streaming modes are complete. The original YouTube path is preserved. Do not use this as a production Facebook streaming release until the missing items above are implemented and tested.
