# ScreenRecorderLive v9 – Facebook integration groundwork

## Included in this ZIP
- Home screen now shows separate YouTube and Facebook destination rows.
- Each row follows the agreed order: platform mark/name, Go Live action, connection status.
- Facebook logo/name and its Go Live action open a dedicated Facebook Integration page.
- Facebook Integration page presents both planned methods: automatic Facebook OAuth/Page connection and manual RTMPS via Facebook Live Producer.
- Existing YouTube connection and live flow were left in place.

## Important implementation status
This is UI/navigation groundwork, not a completed Facebook streaming integration.
- Facebook OAuth is not implemented.
- Manual RTMPS credentials are not collected or stored yet.
- No Facebook RTMPS output has been added to the encoder.
- Simultaneous YouTube + Facebook streaming is not implemented yet.
- The home screen explicitly indicates that multi-output streaming is not enabled.

The current app uses a single RootEncoder stream destination. Supporting two independent destinations requires a tested multi-output/relay implementation. Do not treat the Facebook row as a working broadcaster yet.

## Build verification
A Gradle assembleDebug build was attempted, but the environment could not download Gradle 8.14.3 because network DNS access to services.gradle.org was unavailable. Therefore this ZIP has not been compile-verified or APK-tested.
