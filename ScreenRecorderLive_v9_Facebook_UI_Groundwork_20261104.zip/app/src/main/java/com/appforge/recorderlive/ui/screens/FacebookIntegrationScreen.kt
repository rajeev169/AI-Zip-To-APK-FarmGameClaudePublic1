package com.appforge.recorderlive.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FacebookIntegrationScreen(onBack: () -> Unit, onOpenLiveProducer: () -> Unit) {
    var info by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
            Text("Facebook Integration", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("f", color = androidx.compose.ui.graphics.Color(0xFF1877F2), fontSize = 54.sp, fontWeight = FontWeight.Bold)
            Text("Connect Facebook Live", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Choose how you want to connect Facebook as a streaming destination.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Column(Modifier.fillMaxWidth().padding(4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Option 1 · Automatic connection", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("The planned OAuth flow will let you sign in, select a Facebook Page and create a Live broadcast. Meta app credentials and permissions must be configured before this can work.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { info = true }, modifier = Modifier.fillMaxWidth()) { Text("Connect with Facebook") }
            }
            androidx.compose.material3.HorizontalDivider()
            Column(Modifier.fillMaxWidth().padding(4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Option 2 · Manual RTMPS", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("Get the server URL and stream key from Facebook Live Producer. Credential entry and secure storage will be enabled when the independent Facebook output is implemented.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = onOpenLiveProducer, modifier = Modifier.fillMaxWidth()) { Text("Open Facebook Live Producer") }
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Outlined.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Facebook streaming is not active yet. Your existing YouTube connection and streaming flow are unchanged.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (info) AlertDialog(onDismissRequest = { info = false }, title = { Text("Facebook login not configured") },
        text = { Text("Automatic Facebook connection needs a Meta developer app, approved permissions and OAuth redirect configuration. This project ZIP does not currently contain those credentials.") },
        confirmButton = { TextButton(onClick = { info = false }) { Text("OK") } })
}
