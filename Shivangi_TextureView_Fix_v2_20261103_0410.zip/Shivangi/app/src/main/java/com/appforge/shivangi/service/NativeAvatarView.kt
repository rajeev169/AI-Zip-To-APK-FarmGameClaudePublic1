package com.appforge.shivangi.service

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.util.Log
import android.view.Choreographer
import android.view.TextureView
import android.widget.FrameLayout
import com.google.android.filament.Filament
import com.google.android.filament.View
import com.google.android.filament.android.UiHelper
import com.google.android.filament.utils.ModelViewer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Transparent, native Filament renderer for the floating cat avatar.
 *
 * The GLB is loaded from app assets and is not converted or modified.
 * ModelViewer owns its Filament resources and destroys them when the
 * TextureView detaches from its window.
 */
class NativeAvatarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs), Choreographer.FrameCallback {

    private val textureView = TextureView(context).apply {
        // TextureView does not support background drawables on Android.
        // Keep it non-opaque; transparency is provided by the surface/renderer.
        isOpaque = false
    }

    private var modelViewer: ModelViewer? = null
    private var frameScheduled = false
    private var initializationAttempted = false

    init {
        setBackgroundColor(Color.TRANSPARENT)
        clipChildren = false
        clipToPadding = false
        addView(
            textureView,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        // Wait until Android has measured the TextureView so the camera gets
        // the correct portrait viewport dimensions.
        textureView.post { initializeRenderer() }
    }

    private fun initializeRenderer() {
        if (!isAttachedToWindow || modelViewer != null || initializationAttempted) return
        if (textureView.width <= 0 || textureView.height <= 0) {
            textureView.post { initializeRenderer() }
            return
        }
        initializationAttempted = true

        var candidate: ModelViewer? = null
        try {
            if (filamentInitialized.compareAndSet(false, true)) {
                try {
                    Filament.init()
                } catch (t: Throwable) {
                    filamentInitialized.set(false)
                    throw t
                }
            }

            val viewer = ModelViewer(
                textureView,
                uiHelper = UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK).apply {
                    isOpaque = false
                }
            )
            candidate = viewer

            // Ask Filament to preserve alpha instead of clearing to an opaque
            // background. The Android overlay window is also translucent.
            viewer.renderer.clearOptions = viewer.renderer.clearOptions.apply {
                clear = true
                clearColor = doubleArrayOf(0.0, 0.0, 0.0, 0.0)
            }
            viewer.view.blendMode = View.BlendMode.TRANSLUCENT
            viewer.scene.skybox = null

            val bytes = context.assets.open("avatar/shivangi.glb").use { it.readBytes() }
            val buffer = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
            buffer.put(bytes)
            buffer.flip()

            viewer.loadModelGlb(buffer)
            viewer.transformToUnitCube()

            modelViewer = viewer
            frameScheduled = true
            Choreographer.getInstance().postFrameCallback(this)
            Log.i(TAG, "Native cat GLB loaded (${bytes.size} bytes)")
        } catch (t: Throwable) {
            Log.e(TAG, "Unable to initialize native cat renderer", t)
            candidate?.let { runCatching { it.destroy() } }
            modelViewer = null
        }
    }

    override fun doFrame(frameTimeNanos: Long) {
        val viewer = modelViewer ?: return
        if (!isAttachedToWindow) return
        runCatching { viewer.render(frameTimeNanos) }
            .onFailure { Log.e(TAG, "Native cat render failed", it) }
        if (frameScheduled && isAttachedToWindow) {
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onDetachedFromWindow() {
        frameScheduled = false
        Choreographer.getInstance().removeFrameCallback(this)
        // ModelViewer registers its own TextureView detach listener and
        // releases the Filament engine/swap-chain there.
        modelViewer = null
        initializationAttempted = false
        super.onDetachedFromWindow()
    }

    companion object {
        private const val TAG = "ShivangiNativeAvatar"
        private val filamentInitialized = AtomicBoolean(false)
    }
}
