# Shivangi – AI assistant (AppForge)

Kotlin · Jetpack Compose · Material 3 · minSdk 29 · targetSdk 36 · package `com.appforge.shivangi`

## Before the first build (one time)

### 1. Google sign-in (Web client ID)
1. Google Cloud Console → your project → **APIs & Services → OAuth consent screen** (External, add your email as test user).
2. **Credentials → Create credentials → OAuth client ID → Android**
   package `com.appforge.shivangi`, SHA-1 of the key your pipeline signs with (Family Shield upload key 7E:67:FD:25:…).
   Later, after the first Play upload, add a second Android client with the **App signing key** SHA-1 from Play Console.
3. **Create credentials → OAuth client ID → Web application** (any name). Copy its **Client ID**.
4. Paste it in `app/src/main/res/values/strings.xml` → `google_web_client_id`.

### 2. Wake word model (optional at first)
Run the separate **shivangi-wakeword-trainer** repo on GitHub Actions, download `shivangi.onnx`
and put it at `app/src/main/assets/wake/shivangi.onnx`.
Until then she still wakes on "Shivangi" using the user's own 8 voice samples (less accurate).

### 3. Privacy policy
Replace `privacy_url` in `strings.xml` with your real policy page.

## What's inside
- `brain/` Gemini (user's own key, newest Flash model picked automatically), function-calling tools, permissions
- `voice/` phone text-to-speech + speech recognition in the chosen language
- `wake/` own wake-word engine: openWakeWord features (ONNX) + trained `shivangi.onnx` + personal voice samples
- `service/` background listening, floating bubble, screenshot for "what's on my screen", reminders, boot notice
- `assist/` default digital assistant (long-press power); passes voice typing on to Google so keyboards keep working
- `assets/avatar/` three.js page with her 3D model (`shivangi.glb`): blinking, lip movement, breathing, waving
- `ui/` sign-in, key, voice teaching, 4 setup permissions, home, menu (history, reminders, 16 permissions, language,
  settings, help, share, rate, about)

## Languages
- Her speech: 12 options in Menu → Language (English, Hindi, Hinglish, Bengali, Marathi, Telugu, Tamil, Gujarati, Kannada, Malayalam, Punjabi, Urdu).
- App text: follows the phone language. This version has English and Hindi; other languages show English.

## Play Console declarations you will need
- Foreground service: **microphone** (listening for her name), **specialUse** (floating bubble), **mediaProjection** (one screenshot when asked).
- Permissions: Contacts, Call phone, Calendar, Location (approximate), Photos/videos/audio, Camera, Exact alarms (reminders),
  Notification listener, Modify system settings, Do Not Disturb access, Display over other apps.
- Data safety: voice is processed on the phone for the wake word; spoken requests are sent to Google Gemini with the user's own key;
  chats and voice samples are stored only on the phone.

Open-source: three.js (MIT), openWakeWord models (Apache-2.0), ONNX Runtime (MIT).

## Cat avatar build (native 3D, no WebView)
- The cat is `app/src/main/assets/avatar/cat.glb`, drawn natively by Filament (`avatar/CatRenderer.kt`, `avatar/CatView.kt`) on a fully transparent surface. The same view is used in the app (`ui/AvatarView.kt`) and in the floating overlay (`service/Overlay.kt`).
- The glb was prepared from `model-cat.glb`: smooth normals added, material set to non-metal, fur texture lifted slightly so black fur reads under light.
- Floating cat: appears when the wake word is heard and she says "Yes, I'm here. How can I help you?" (then listens). She stays until X. Tap her: control panel opens (listens) / shrinks closed. Drag to move. X or long-press makes the whole window disappear (background listening continues). Hidden while the app itself is open.
- Shivangi's own `shivangi.glb` is still in the assets folder, unused for now.
- Crash log: saved in the app's private storage (`crash_log.txt`), shown on the next launch with Copy / Clear / Close. Filament and model-load errors go there too.
