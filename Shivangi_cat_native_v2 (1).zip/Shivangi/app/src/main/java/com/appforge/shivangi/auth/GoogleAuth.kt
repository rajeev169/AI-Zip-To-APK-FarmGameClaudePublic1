package com.appforge.shivangi.auth

import android.app.Activity
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.appforge.shivangi.R
import com.appforge.shivangi.brain.CloudSync
import com.appforge.shivangi.data.Prefs
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

sealed class SignInResult {
    data object Ok : SignInResult()
    data object Cancelled : SignInResult()
    data object NotConfigured : SignInResult()
    data class Failed(val message: String) : SignInResult()
}

/** "Continue with Google" using Android's Credential Manager. */
object GoogleAuth {
    suspend fun signIn(activity: Activity): SignInResult {
        val clientId = activity.getString(R.string.google_web_client_id)
        if (clientId.isBlank() || clientId.startsWith("PASTE")) return SignInResult.NotConfigured
        val option = GetSignInWithGoogleOption.Builder(clientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        return try {
            val result = CredentialManager.create(activity).getCredential(activity, request)
            val cred = result.credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                Prefs.googleName = g.displayName ?: g.givenName ?: ""
                Prefs.userEmail = g.id
                CloudSync.connect(g.idToken)   // starts the cloud backup login in the background; never blocks sign-in
                SignInResult.Ok
            } else SignInResult.Failed("Unexpected sign-in result")
        } catch (e: GetCredentialCancellationException) {
            SignInResult.Cancelled
        } catch (e: GetCredentialException) {
            SignInResult.Failed(e.message ?: e.type)
        }
    }

    suspend fun signOut(activity: Activity) {
        runCatching {
            CredentialManager.create(activity).clearCredentialState(androidx.credentials.ClearCredentialStateRequest())
        }
        Prefs.signOut()
    }
}
