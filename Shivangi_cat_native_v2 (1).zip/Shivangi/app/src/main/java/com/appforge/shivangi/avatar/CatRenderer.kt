package com.appforge.shivangi.avatar

import android.content.Context
import android.opengl.Matrix
import android.view.Choreographer
import android.view.Surface
import android.view.TextureView
import com.appforge.shivangi.debug.CrashLog
import com.google.android.filament.Camera
import com.google.android.filament.Engine
import com.google.android.filament.EntityManager
import com.google.android.filament.Filament
import com.google.android.filament.LightManager
import com.google.android.filament.Renderer
import com.google.android.filament.Scene
import com.google.android.filament.SwapChain
import com.google.android.filament.View as FView
import com.google.android.filament.Viewport
import com.google.android.filament.android.UiHelper
import com.google.android.filament.gltfio.AssetLoader
import com.google.android.filament.gltfio.FilamentAsset
import com.google.android.filament.gltfio.Gltfio
import com.google.android.filament.gltfio.ResourceLoader
import com.google.android.filament.gltfio.UbershaderProvider
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Draws the 3D cat (avatar/cat.glb) natively with Filament into a transparent TextureView.
 * No web page, no background: only the cat's own pixels are opaque.
 *
 * The cat has no bones or face shapes, so she moves as one soft body:
 * idle breathing + sway, a squash-and-stretch pulse on every spoken word, and a hop to say hello.
 */
class CatRenderer(private val context: Context, private val textureView: TextureView) {
    var onError: ((String) -> Unit)? = null
    @Volatile var talking = false
    var hasFailed = false
        private set

    private var wordPulse = 0f
    private var waveT = -1f
    private var talkAmt = 0f
    private var time = 0f
    private var lastNanos = 0L
    private var running = false

    private var engine: Engine? = null
    private var renderer: Renderer? = null
    private var scene: Scene? = null
    private var view: FView? = null
    private var camera: Camera? = null
    private var cameraEntity = 0
    private var swapChain: SwapChain? = null
    private var uiHelper: UiHelper? = null
    private var assetLoader: AssetLoader? = null
    private var materialProvider: UbershaderProvider? = null
    private var asset: FilamentAsset? = null
    private var rootInstance = 0
    private val lights = ArrayList<Int>()

    private var aspect = 1.0
    private val size = floatArrayOf(1f, 1f, 1f)       // cat's measured width, height, depth
    private val baseOffset = floatArrayOf(0f, 0f, 0f) // moves the cat so she stands on y=0, centred
    private val matrix = FloatArray(16)
    private val choreographer = Choreographer.getInstance()

    /** How much wider than the cat (whiskers included) the frame is; the floating view uses more so whisker tips are never cut */
    var fitWidth = 1.12

    fun word() { wordPulse = 1f }
    fun wave() { waveT = 0f }

    init {
        try { setup() } catch (t: Throwable) { fail("setup", t) }
    }

    // ------------------------------------------------------------------ setup

    private fun setup() {
        initNative()
        val e = Engine.create()
        engine = e
        val r = e.createRenderer(); renderer = r
        val s = e.createScene(); scene = s
        val v = e.createView(); view = v
        cameraEntity = EntityManager.get().create()
        val cam = e.createCamera(cameraEntity); camera = cam
        cam.setExposure(16f, 1f / 125f, 100f)
        v.camera = cam
        v.scene = s

        // Transparent: nothing but the cat is drawn
        v.blendMode = FView.BlendMode.TRANSLUCENT
        r.clearOptions = Renderer.ClearOptions().apply { clear = true }
        runCatching { v.multiSampleAntiAliasingOptions = FView.MultiSampleAntiAliasingOptions().apply { enabled = true } }

        // Soft three-point lighting: key (front, upper right), fill (left), rim (behind)
        addLight(1.0f, 0.97f, 0.94f, 70_000f, -0.45f, -0.65f, -1.0f)
        addLight(0.92f, 0.95f, 1.0f, 28_000f, 0.9f, -0.2f, -0.7f)
        addLight(1.0f, 0.93f, 0.97f, 22_000f, 0.1f, -0.3f, 1.0f)
        addLight(1.0f, 1.0f, 1.0f, 14_000f, 0.0f, 1.0f, -0.2f)

        loadModel(e, s)

        textureView.isOpaque = false
        val ui = UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK)
        ui.isOpaque = false
        ui.renderCallback = object : UiHelper.RendererCallback {
            override fun onNativeWindowChanged(surface: Surface) {
                val en = engine ?: return
                swapChain?.let { en.destroySwapChain(it) }
                swapChain = en.createSwapChain(surface, ui.swapChainFlags)
            }
            override fun onDetachedFromSurface() {
                val en = engine ?: return
                swapChain?.let { en.destroySwapChain(it); en.flushAndWait(); swapChain = null }
            }
            override fun onResized(width: Int, height: Int) {
                if (width <= 0 || height <= 0) return
                view?.viewport = Viewport(0, 0, width, height)
                aspect = width.toDouble() / height.toDouble()
                placeCamera()
            }
        }
        ui.attachTo(textureView)
        uiHelper = ui
    }

    private fun addLight(r: Float, g: Float, b: Float, lux: Float, dx: Float, dy: Float, dz: Float) {
        val len = sqrt(dx * dx + dy * dy + dz * dz)
        val en = EntityManager.get().create()
        LightManager.Builder(LightManager.Type.DIRECTIONAL)
            .color(r, g, b).intensity(lux)
            .direction(dx / len, dy / len, dz / len)
            .castShadows(false)
            .build(engine!!, en)
        scene!!.addEntity(en)
        lights += en
    }

    private fun loadModel(e: Engine, s: Scene) {
        val bytes = context.assets.open(MODEL_PATH).use { it.readBytes() }
        val buffer = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        buffer.put(bytes); buffer.rewind()
        val provider = UbershaderProvider(e); materialProvider = provider
        val loader = AssetLoader(e, provider, EntityManager.get()); assetLoader = loader
        val a = loader.createAsset(buffer) ?: throw IllegalStateException("$MODEL_PATH could not be read as a glb model")
        ResourceLoader(e).loadResources(a)
        a.releaseSourceData()
        s.addEntities(a.entities)
        asset = a
        val box = a.boundingBox
        val c = box.center; val h = box.halfExtent
        size[0] = h[0] * 2f; size[1] = h[1] * 2f; size[2] = h[2] * 2f
        baseOffset[0] = -c[0]; baseOffset[1] = -(c[1] - h[1]); baseOffset[2] = -c[2]
        rootInstance = e.transformManager.getInstance(a.root)
        applyTransform(0f, 1f, 1f, 0f, 0f, 0f)
    }

    // The whole cat always fits the frame (with room to hop), in tall or wide views
    private fun placeCamera() {
        val cam = camera ?: return
        val fov = 22.0
        val t = tan(Math.toRadians(fov / 2))
        val asp = max(aspect, 0.2)
        val hgt = size[1] * 1.25; val wid = size[0] * fitWidth
        val d = max((hgt / 2) / t, (wid / 2) / (asp * t)) + size[2] / 2
        val cy = size[1] * 0.5
        cam.setProjection(fov, aspect, 0.05, 50.0, Camera.Fov.VERTICAL)
        cam.lookAt(0.0, cy, d, 0.0, cy, 0.0, 0.0, 1.0, 0.0)
    }

    // ------------------------------------------------------------------ frame loop

    fun start() {
        if (hasFailed || running) return
        running = true; lastNanos = 0L
        choreographer.postFrameCallback(frameCallback)
    }

    fun stop() {
        running = false
        choreographer.removeFrameCallback(frameCallback)
    }

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            choreographer.postFrameCallback(this)
            try {
                val dt = if (lastNanos == 0L) 0.016f else ((frameTimeNanos - lastNanos) / 1e9f).coerceIn(0.001f, 0.05f)
                lastNanos = frameTimeNanos
                animate(dt)
                val sc = swapChain ?: return
                val r = renderer ?: return
                if (r.beginFrame(sc, frameTimeNanos)) { r.render(view!!); r.endFrame() }
            } catch (t: Throwable) { stop(); fail("frame", t) }
        }
    }

    private fun animate(dt: Float) {
        time += dt
        val t = time
        // Idle: breathing, slow sway, a small look-around
        var sy = 1f + 0.014f * sin(t * 1.9f); var sx = 1f - 0.007f * sin(t * 1.9f)
        var ry = 0.12f * sin(t * 0.55f); var rz = 0.03f * sin(t * 0.9f); var rx = 0.015f * sin(t * 0.7f)
        var py = 0.006f * size[1] * sin(t * 1.9f)

        // Talking: soft nod, plus a squash-and-stretch pulse with each word
        talkAmt += ((if (talking) 1f else 0f) - talkAmt) * minOf(1f, dt * 8f)
        wordPulse = max(0f, wordPulse - dt * 4f)
        val beat = talkAmt * (0.35f + 0.65f * wordPulse)
        sy += 0.05f * beat * sin(t * 14f); sx -= 0.03f * beat * sin(t * 14f)
        sy += 0.02f * talkAmt * sin(t * 6.1f)
        rx += 0.05f * talkAmt * sin(t * 3.3f)
        rz += 0.03f * talkAmt * sin(t * 2.2f)

        // Hello: two hops with a happy tilt
        if (waveT >= 0f) {
            waveT += dt
            val total = 1.6f
            val env = sin((Math.PI * minOf(1f, waveT / total)).toFloat())
            py += abs(sin(waveT * Math.PI.toFloat() * 2.5f)) * 0.10f * size[1] * env
            rz += 0.22f * sin(waveT * 9f) * env
            sy += 0.04f * sin(waveT * Math.PI.toFloat() * 5f) * env
            if (waveT > total) waveT = -1f
        }
        applyTransform(py, sx, sy, rx, ry, rz)
    }

    private fun applyTransform(py: Float, sx: Float, sy: Float, rx: Float, ry: Float, rz: Float) {
        val e = engine ?: return
        val deg = 180f / Math.PI.toFloat()
        Matrix.setIdentityM(matrix, 0)
        Matrix.translateM(matrix, 0, 0f, py, 0f)
        Matrix.rotateM(matrix, 0, ry * deg, 0f, 1f, 0f)
        Matrix.rotateM(matrix, 0, rx * deg, 1f, 0f, 0f)
        Matrix.rotateM(matrix, 0, rz * deg, 0f, 0f, 1f)
        Matrix.scaleM(matrix, 0, sx, sy, sx)
        Matrix.translateM(matrix, 0, baseOffset[0], baseOffset[1], baseOffset[2])
        e.transformManager.setTransform(rootInstance, matrix)
    }

    // ------------------------------------------------------------------ cleanup / errors

    fun destroy() {
        stop()
        val e = engine ?: return
        engine = null
        runCatching { uiHelper?.detach() }
        runCatching { swapChain?.let { e.destroySwapChain(it) }; swapChain = null }
        runCatching { asset?.let { a -> scene?.removeEntities(a.entities); assetLoader?.destroyAsset(a) } }
        runCatching { materialProvider?.destroyMaterials(); materialProvider?.destroy() }
        runCatching { assetLoader?.destroy() }
        runCatching { lights.forEach { l -> scene?.removeEntity(l); e.lightManager.destroy(l); EntityManager.get().destroy(l) } }
        runCatching { renderer?.let { e.destroyRenderer(it) } }
        runCatching { view?.let { e.destroyView(it) } }
        runCatching { scene?.let { e.destroyScene(it) } }
        runCatching { e.destroyCameraComponent(cameraEntity); EntityManager.get().destroy(cameraEntity) }
        runCatching { e.destroy() }
    }

    private fun fail(where: String, t: Throwable) {
        if (hasFailed) return
        hasFailed = true
        CrashLog.log("Cat 3D ($where)", android.util.Log.getStackTraceString(t))
        onError?.invoke(where)
    }

    companion object {
        private const val MODEL_PATH = "avatar/cat.glb"
        private var nativeReady = false
        private fun initNative() {
            if (nativeReady) return
            Filament.init()
            Gltfio.init()
            nativeReady = true
        }
    }
}
