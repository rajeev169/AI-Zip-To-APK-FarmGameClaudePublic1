package com.appforge.shivangi.avatar

import android.content.Context
import android.content.ContextWrapper
import android.view.TextureView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.appforge.shivangi.brain.Assistant
import com.appforge.shivangi.voice.Speaker

private fun Context.findLifecycleOwner(): LifecycleOwner? {
    var c: Context? = this
    while (c != null) {
        if (c is LifecycleOwner) return c
        c = (c as? ContextWrapper)?.baseContext
    }
    return null
}

/** The native 3D cat on a fully transparent surface. Used in the app and in the floating view. */
@Composable
fun CatView(modifier: Modifier = Modifier, fitWidth: Float = 1.12f, onFailed: () -> Unit = {}) {
    val ctx = LocalContext.current
    val owner = remember(ctx) { ctx.findLifecycleOwner() }
    val textureView = remember { TextureView(ctx).apply { isOpaque = false } }
    val renderer = remember { CatRenderer(ctx, textureView).also { it.fitWidth = fitWidth.toDouble() } }

    AndroidView(modifier = modifier, factory = { textureView })

    LaunchedEffect(renderer) {
        renderer.onError = { onFailed() }
        if (renderer.hasFailed) onFailed()
    }

    // Draw only while the screen/service is started
    DisposableEffect(owner, renderer) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> renderer.start()
                Lifecycle.Event.ON_STOP -> renderer.stop()
                else -> {}
            }
        }
        if (owner != null) owner.lifecycle.addObserver(observer) else renderer.start()
        onDispose {
            owner?.lifecycle?.removeObserver(observer)
            renderer.destroy()
        }
    }

    LaunchedEffect(renderer) { Speaker.speaking.collect { renderer.talking = it } }
    LaunchedEffect(renderer) { Speaker.words.collect { renderer.word() } }
    LaunchedEffect(renderer) { Assistant.wave.collect { renderer.wave() } }
}
