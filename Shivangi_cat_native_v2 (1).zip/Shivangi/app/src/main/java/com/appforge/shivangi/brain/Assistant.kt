package com.appforge.shivangi.brain

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.util.Base64
import com.appforge.shivangi.R
import com.appforge.shivangi.data.ChatMessage
import com.appforge.shivangi.data.Languages
import com.appforge.shivangi.data.Prefs
import com.appforge.shivangi.data.Store
import com.appforge.shivangi.voice.Listener
import com.appforge.shivangi.voice.Speaker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }

sealed class AssistantEvent {
    data class AskPermission(val perm: AppPerm, val retryText: String) : AssistantEvent()
    data class OpenCamera(val question: String) : AssistantEvent()
    data class CaptureScreen(val question: String) : AssistantEvent()
}

data class PendingCall(val name: String, val number: String, val secondsLeft: Int)

/**
 * Shivangi's brain loop: listen → ask Gemini (with phone tools) → act → speak.
 * Shared by the app screen, the floating bubble and the wake word.
 */
@SuppressLint("StaticFieldLeak")
object Assistant {
    private lateinit var app: Context
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val _phase = MutableStateFlow(Phase.IDLE)
    val phase: StateFlow<Phase> = _phase
    private val _session = MutableStateFlow<List<ChatMessage>>(emptyList())
    /** Messages of the current conversation (shown on Home / in the bubble) */
    val session: StateFlow<List<ChatMessage>> = _session
    private val _events = MutableSharedFlow<AssistantEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<AssistantEvent> = _events
    private val _call = MutableStateFlow<PendingCall?>(null)
    val call: StateFlow<PendingCall?> = _call
    /** True while she wants the microphone to herself (wake word must pause) */
    val micBusy = MutableStateFlow(false)
    /** Waves when she greets */
    val wave = MutableSharedFlow<Unit>(extraBufferCapacity = 2)

    private var contents = JSONArray()
    private var turnJob: Job? = null
    private var callJob: Job? = null

    fun init(c: Context) {
        app = c.applicationContext
        Store.init(app)
        Speaker.init(app)
        Learned.init(app)
        CloudSync.init(app)
        CloudSync.syncOnStart()
    }

    // ---------------- Conversation ----------------

    /** Mic button, wake word or bubble tap */
    fun startVoiceTurn() {
        if (_phase.value == Phase.LISTENING || _phase.value == Phase.THINKING) return
        Speaker.stop()
        turnJob?.cancel()
        turnJob = scope.launch {
            micBusy.value = true
            delay(250) // let the wake-word engine release the microphone
            _phase.value = Phase.LISTENING
            val heard = Listener.listen(app)
            _phase.value = Phase.IDLE
            when (heard) {
                is Listener.Heard.Text -> runTurn(heard.text, null)
                Listener.Heard.NoRecognizer -> speak(app.getString(R.string.no_recognizer))
                else -> {}
            }
            micBusy.value = false
        }
    }

    /** Wake word heard: she says "Yes, I'm here..." out loud first, then listens (so she never hears herself) */
    fun wakeAndListen() {
        if (_phase.value == Phase.LISTENING || _phase.value == Phase.THINKING) return
        Speaker.stop()
        turnJob?.cancel()
        turnJob = scope.launch {
            micBusy.value = true
            delay(250) // let the wake-word engine release the microphone
            wave.tryEmit(Unit)
            speak(wakeReply())
            delay(200)
            _phase.value = Phase.LISTENING
            val heard = Listener.listen(app)
            _phase.value = Phase.IDLE
            when (heard) {
                is Listener.Heard.Text -> runTurn(heard.text, null)
                Listener.Heard.NoRecognizer -> speak(app.getString(R.string.no_recognizer))
                else -> {}
            }
            micBusy.value = false
        }
    }

    /** "Yes, I am here. How can I help you?" in her speaking language */
    private fun wakeReply(): String = when (Languages.current.code) {
        "hi" -> "हाँ, मैं यहाँ हूँ। मैं आपकी कैसे मदद कर सकती हूँ?"
        "hinglish" -> "Haan, main yahan hoon. Main aapki kaise madad kar sakti hoon?"
        "bn" -> "হ্যাঁ, আমি এখানে আছি। আমি আপনাকে কীভাবে সাহায্য করতে পারি?"
        "mr" -> "हो, मी इथे आहे. मी तुम्हाला कशी मदत करू?"
        "te" -> "అవును, నేను ఇక్కడే ఉన్నాను. నేను మీకు ఎలా సహాయం చేయగలను?"
        "ta" -> "ஆமாம், நான் இங்கே இருக்கிறேன். நான் உங்களுக்கு எப்படி உதவலாம்?"
        "gu" -> "હા, હું અહીં છું. હું તમારી શું મદદ કરું?"
        "kn" -> "ಹೌದು, ನಾನು ಇಲ್ಲಿದ್ದೇನೆ. ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಲಿ?"
        "ml" -> "അതെ, ഞാൻ ഇവിടെയുണ്ട്. ഞാൻ നിങ്ങളെ എങ്ങനെ സഹായിക്കണം?"
        "pa" -> "ਹਾਂ, ਮੈਂ ਇੱਥੇ ਹਾਂ। ਮੈਂ ਤੁਹਾਡੀ ਕੀ ਮਦਦ ਕਰਾਂ?"
        "ur" -> "جی، میں یہاں ہوں۔ میں آپ کی کیا مدد کروں؟"
        else -> "Yes, I'm here. How can I help you?"
    }

    /** Typed text or a suggestion chip */
    fun ask(text: String) {
        if (text.isBlank()) return
        Speaker.stop()
        turnJob?.cancel()
        turnJob = scope.launch { micBusy.value = true; runTurn(text, null); micBusy.value = false }
    }

    /** Runs the same request again after a permission was given (without repeating the user's bubble) */
    fun retry(text: String) {
        turnJob?.cancel()
        turnJob = scope.launch { micBusy.value = true; runTurn(text, null, showUser = false); micBusy.value = false }
    }

    /** After the camera or a screenshot */
    fun askWithImage(question: String, image: Bitmap) {
        turnJob?.cancel()
        turnJob = scope.launch { micBusy.value = true; runTurn(question, image, showUser = false); micBusy.value = false }
    }

    fun stop() {
        turnJob?.cancel(); Speaker.stop(); _phase.value = Phase.IDLE; micBusy.value = false
    }

    fun clearSession() { _session.value = emptyList(); contents = JSONArray() }

    private fun addMsg(fromUser: Boolean, text: String) {
        val m = ChatMessage(System.currentTimeMillis(), fromUser, text)
        _session.value = (_session.value + m).takeLast(40)
        Store.addMessage(m)
    }

    private suspend fun runTurn(text: String, image: Bitmap?, showUser: Boolean = true) {
        if (showUser) addMsg(true, text)
        // 1) everyday commands she knows herself, 2) things she learned from Gemini before, 3) Gemini
        if (image == null) {
            val builtIn = LocalCommands.match(text)
            if (builtIn != null && runLocal(text, builtIn.tool, builtIn.args, builtIn.say, null)) return
            val learned = Learned.match(text)
            if (learned != null && runLocal(text, learned.tool, learned.args, null, learned.entry)) return
        }
        if (Prefs.geminiKey.isBlank()) { speakAndShow(app.getString(R.string.need_key)); return }
        _phase.value = Phase.THINKING
        val parts = JSONArray().put(JSONObject().put("text", text))
        if (image != null) parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", jpegBase64(image))))
        contents.put(JSONObject().put("role", "user").put("parts", parts))
        trimMemory()
        try {
            var rounds = 0
            while (rounds++ < 5) {
                val reply = Gemini.generate(systemPrompt(), contents, Tools.declarations)
                val rParts = reply.optJSONArray("parts") ?: JSONArray()
                contents.put(JSONObject().put("role", "model").put("parts", rParts))
                val calls = (0 until rParts.length()).map { rParts.getJSONObject(it) }.filter { it.has("functionCall") }
                if (calls.isEmpty()) {
                    val answer = (0 until rParts.length()).mapNotNull { rParts.getJSONObject(it).optString("text").takeIf { t -> t.isNotBlank() } }
                        .joinToString(" ").trim()
                    speakAndShow(answer.ifBlank { app.getString(R.string.done_short) })
                    return
                }
                val responses = JSONArray()
                var endWith: String? = null
                for (call in calls) {
                    val fc = call.getJSONObject("functionCall")
                    val name = fc.getString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    val result = try {
                        withContext(Dispatchers.IO) { Tools.run(app, name, args) }
                    } catch (e: NeedPermission) {
                        // Ask for it now; when granted the same request runs again
                        contents = JSONArray().apply { for (i in 0 until contents.length() - 2) put(contents.get(i)) }
                        _phase.value = Phase.IDLE
                        _events.emit(AssistantEvent.AskPermission(e.perm, text))
                        speakAndShow(app.getString(R.string.need_permission, app.getString(e.perm.title)))
                        return
                    } catch (e: Exception) {
                        ToolResult(JSONObject().put("error", e.message ?: "failed"))
                    }
                    if (result.say != null) endWith = result.say
                    // Gemini just did one action for this sentence and it worked: remember how, for next time
                    if (rounds == 1 && calls.size == 1 && image == null && !result.response.has("error")) Learned.learn(text, name, args)
                    responses.put(JSONObject().put("functionResponse", JSONObject().put("name", name).put("response", result.response)))
                }
                contents.put(JSONObject().put("role", "user").put("parts", responses))
                if (endWith != null) {
                    if (endWith.isNotBlank()) speakAndShow(endWith) else _phase.value = Phase.IDLE
                    return
                }
            }
            _phase.value = Phase.IDLE
        } catch (e: GeminiException) {
            speakAndShow(app.getString(when {
                e.badKey -> R.string.err_key
                e.quota -> R.string.err_quota
                else -> R.string.err_brain
            }))
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            speakAndShow(app.getString(R.string.err_network))
        }
    }

    /**
     * Runs a built-in or learned command on the phone. Returns true when it is finished (done or answered);
     * false means "could not do it here", and Gemini gets the sentence instead (if she has a key).
     */
    private suspend fun runLocal(text: String, tool: String?, args: JSONObject, say: String?, learned: Learned.Entry?): Boolean {
        if (tool == null) { speakAndShow(say ?: return false); return true }
        _phase.value = Phase.THINKING
        val result: ToolResult? = try {
            withContext(Dispatchers.IO) { Tools.run(app, tool, args) }
        } catch (e: NeedPermission) {
            _phase.value = Phase.IDLE
            _events.emit(AssistantEvent.AskPermission(e.perm, text))
            speakAndShow(app.getString(R.string.need_permission, app.getString(e.perm.title)))
            return true
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
        if (result == null || result.response.has("error")) {
            _phase.value = Phase.IDLE
            learned?.let { Learned.reportFailure(it) }
            if (Prefs.geminiKey.isNotBlank()) return false
            val msg = result?.response?.optString("error").orEmpty()
            speakAndShow(if (msg.isNotBlank() && msg.length < 120) msg else app.getString(R.string.err_brain))
            return true
        }
        learned?.let { Learned.reportSuccess(it) }
        speakAndShow(result.say ?: say ?: app.getString(R.string.done_short))
        return true
    }

    private suspend fun speakAndShow(text: String) {
        addMsg(false, text)
        speak(text)
    }

    suspend fun speak(text: String) {
        _phase.value = Phase.SPEAKING
        Speaker.say(text)
        _phase.value = Phase.IDLE
    }

    private fun trimMemory() {
        // Keep the conversation short so it stays fast and cheap: last ~16 entries, starting at a user text
        if (contents.length() <= 16) return
        val list = (0 until contents.length()).map { contents.getJSONObject(it) }.takeLast(16).toMutableList()
        while (list.isNotEmpty() && !(list.first().optString("role") == "user" &&
                list.first().getJSONArray("parts").optJSONObject(0)?.has("text") == true)) list.removeAt(0)
        contents = JSONArray(list)
    }

    private fun systemPrompt(): String {
        val lang = Languages.current
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.ENGLISH).format(Date())
        val name = Prefs.callName.ifBlank { "the user" }
        return """
            You are Shivangi, a warm, friendly Indian woman who is the user's personal assistant on their Android phone.
            The user's name is $name. Talk like a caring friend, polite and natural.
            ALWAYS reply in ${lang.promptName}, even if the user mixes languages.
            Your replies are spoken aloud: keep them short (1–3 sentences), no lists, no markdown, no emojis.
            Current local date and time: $now.
            Use the provided functions to act on the phone (alarms, calls, messages, apps, music, settings, camera, screen, etc.).
            After a function succeeds, confirm briefly in one sentence. If a function returns an error, explain simply and suggest what to do.
            For questions about something the user is looking at, use look_through_camera or look_at_screen.
            Never make up phone numbers, contacts or file names.
        """.trimIndent()
    }

    private fun jpegBase64(b: Bitmap): String {
        val max = 1024f
        val s = minOf(1f, max / maxOf(b.width, b.height))
        val scaled = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    // ---------------- Things tools ask the UI to do ----------------

    fun requestCamera(question: String) { _events.tryEmit(AssistantEvent.OpenCamera(question)) }
    fun requestScreen(question: String) { _events.tryEmit(AssistantEvent.CaptureScreen(question)) }

    fun callingLine(name: String) = app.getString(R.string.calling_now, name)

    /** "Calling Papa…" with a 3-second cancel (if turned on in Settings) */
    fun requestCall(name: String, number: String) {
        callJob?.cancel()
        callJob = scope.launch {
            if (Prefs.confirmCalls) {
                for (s in 3 downTo 1) { _call.value = PendingCall(name, number, s); delay(1000) }
            }
            _call.value = null
            runCatching {
                app.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    fun cancelCall() { callJob?.cancel(); _call.value = null }

    // ---------------- Daily greeting ----------------

    fun greetingText(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val name = Prefs.callName
        val res = when { h < 12 -> R.string.greet_morning; h < 17 -> R.string.greet_afternoon; else -> R.string.greet_evening }
        return app.getString(res, name).replace(" ,", ",").replace(",!", "!").trim()
    }

    /** Spoken aloud and with a wave only the first time each day */
    fun greetIfFirstToday() {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (Prefs.lastGreetDay == today) return
        Prefs.lastGreetDay = today
        scope.launch {
            delay(1200)
            wave.tryEmit(Unit)
            val name = Prefs.callName
            val hello = when (Languages.current.code) {
                "en" -> greetingEnglish()
                "hi" -> "नमस्ते"; "hinglish" -> "Namaste"; "bn" -> "নমস্কার"; "mr" -> "नमस्कार"
                "te" -> "నమస్కారం"; "ta" -> "வணக்கம்"; "gu" -> "નમસ્તે"; "kn" -> "ನಮಸ್ಕಾರ"
                "ml" -> "നമസ്കാരം"; "pa" -> "ਸਤ ਸ੍ਰੀ ਅਕਾਲ"; "ur" -> "السلام علیکم"; else -> "Hello"
            }
            speak("$hello${if (name.isNotBlank()) " $name" else ""}! " + spokenGreetingTail())
        }
    }

    private fun greetingEnglish(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when { h < 12 -> "Good morning"; h < 17 -> "Good afternoon"; else -> "Good evening" }
    }

    /** Greeting tail in her speaking language (the app text may be in another language) */
    private fun spokenGreetingTail(): String = when (Languages.current.code) {
        "hi" -> "आज मैं आपकी क्या मदद करूँ?"
        "hinglish" -> "Aaj main aapki kya madad karun?"
        "bn" -> "আজ আমি আপনাকে কীভাবে সাহায্য করতে পারি?"
        "mr" -> "आज मी तुम्हाला कशी मदत करू?"
        "te" -> "ఈ రోజు నేను మీకు ఎలా సహాయం చేయగలను?"
        "ta" -> "இன்று நான் உங்களுக்கு எப்படி உதவலாம்?"
        "gu" -> "આજે હું તમારી શું મદદ કરું?"
        "kn" -> "ಇಂದು ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಲಿ?"
        "ml" -> "ഇന്ന് ഞാൻ നിങ്ങളെ എങ്ങനെ സഹായിക്കണം?"
        "pa" -> "ਅੱਜ ਮੈਂ ਤੁਹਾਡੀ ਕੀ ਮਦਦ ਕਰਾਂ?"
        "ur" -> "آج میں آپ کی کیا مدد کروں؟"
        else -> "How can I help you today?"
    }
}
