package com.appforge.shivangi.brain

import android.content.Context
import android.content.pm.PackageManager
import com.appforge.shivangi.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Backs up the learned commands to the user's own Firebase account and restores them on a new phone.
 *
 * Plain web calls (no Firebase library), so it can never break the app build. If anything fails
 * (not set up in the Firebase console, no internet ...) she simply keeps working from the phone's
 * own memory; the reason is shown in Settings > Learned commands.
 */
object CloudSync {
    // Firebase project of this app (from google-services.json)
    private const val PROJECT = "fleet-track-3de31"
    private const val API_KEY = "AIzaSyAY7clQ18yYZfNj875ppYzJycuvV1By5WE"
    private const val DOC = "https://firestore.googleapis.com/v1/projects/$PROJECT/databases/(default)/documents"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var app: Context
    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status
    private var idToken = ""
    private var idExpiry = 0L
    private var uploadJob: Job? = null
    private var startedOnce = false

    val connected: Boolean get() = Prefs.firebaseRefresh.isNotBlank() && Prefs.firebaseUid.isNotBlank()

    fun init(c: Context) {
        app = c.applicationContext
        _status.value = if (connected) "Backup is on" else "Not connected"
    }

    /** Called right after Google sign-in with the fresh Google token */
    fun connect(googleIdToken: String) {
        if (!::app.isInitialized) return
        scope.launch {
            try {
                _status.value = "Connecting…"
                val body = JSONObject()
                    .put("postBody", "id_token=${URLEncoder.encode(googleIdToken, "UTF-8")}&providerId=google.com")
                    .put("requestUri", "http://localhost").put("returnSecureToken", true).put("returnIdpCredential", true)
                val j = JSONObject(call("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=$API_KEY", body.toString(), null))
                Prefs.firebaseRefresh = j.getString("refreshToken")
                Prefs.firebaseUid = j.getString("localId")
                idToken = j.getString("idToken")
                idExpiry = System.currentTimeMillis() + (j.optString("expiresIn", "3600").toLongOrNull() ?: 3600L) * 1000 - 60_000
                syncNow()
            } catch (e: Exception) { fail(e) }
        }
    }

    /** Once per app start: merge the cloud copy, then upload */
    fun syncOnStart() {
        if (startedOnce || !connected) return
        startedOnce = true
        scope.launch { try { syncNow() } catch (e: Exception) { fail(e) } }
    }

    fun backupNow() { scope.launch { try { syncNow() } catch (e: Exception) { fail(e) } } }

    /** Waits a few seconds after the last change, then uploads */
    fun scheduleUpload() {
        if (!::app.isInitialized || !connected) return
        uploadJob?.cancel()
        uploadJob = scope.launch { delay(5000); try { upload() } catch (e: Exception) { fail(e) } }
    }

    fun onSignedOut() { idToken = ""; idExpiry = 0L; startedOnce = false; _status.value = "Not connected" }

    // ------------------------------------------------------------------ steps

    private fun syncNow() {
        _status.value = "Syncing…"
        val cloud = download()
        val added = if (cloud != null) Learned.mergeJson(cloud) else 0
        upload()
        _status.value = "Backed up at ${SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())}" + if (added > 0) " · restored $added" else ""
    }

    private fun docUrl() = "$DOC/users/${Prefs.firebaseUid}/data/learned"

    private fun download(): String? {
        return try {
            val r = JSONObject(call("GET", docUrl(), null, token()))
            r.optJSONObject("fields")?.optJSONObject("json")?.optString("stringValue")
        } catch (e: IOException) {
            if (e.message?.startsWith("HTTP 404") == true) null else throw e
        }
    }

    private fun upload() {
        val body = JSONObject().put("fields", JSONObject()
            .put("json", JSONObject().put("stringValue", Learned.exportJson()))
            .put("updated", JSONObject().put("integerValue", System.currentTimeMillis().toString())))
        call("PATCH", docUrl() + "?updateMask.fieldPaths=json&updateMask.fieldPaths=updated", body.toString(), token())
        _status.value = "Backed up at ${SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())}"
    }

    /** A valid Firebase login token (renewed from the saved refresh token when it runs out) */
    private fun token(): String {
        if (idToken.isNotBlank() && System.currentTimeMillis() < idExpiry) return idToken
        val refresh = Prefs.firebaseRefresh
        if (refresh.isBlank()) throw IOException("Not connected")
        val form = "grant_type=refresh_token&refresh_token=${URLEncoder.encode(refresh, "UTF-8")}"
        val j = JSONObject(call("POST", "https://securetoken.googleapis.com/v1/token?key=$API_KEY", form, null, "application/x-www-form-urlencoded"))
        idToken = j.getString("id_token")
        j.optString("refresh_token").takeIf { it.isNotBlank() }?.let { Prefs.firebaseRefresh = it }
        idExpiry = System.currentTimeMillis() + (j.optString("expires_in", "3600").toLongOrNull() ?: 3600L) * 1000 - 60_000
        return idToken
    }

    // ------------------------------------------------------------------ web call

    private fun call(method: String, url: String, body: String?, bearer: String?, type: String = "application/json"): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000; c.readTimeout = 20_000
            // PATCH goes as POST + override header (works with every Android version)
            c.requestMethod = if (method == "PATCH") "POST" else method
            if (method == "PATCH") c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            // The Firebase key is limited to this app: tell Google which app is calling
            c.setRequestProperty("X-Android-Package", app.packageName)
            certSha1()?.let { c.setRequestProperty("X-Android-Cert", it) }
            bearer?.let { c.setRequestProperty("Authorization", "Bearer $it") }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", type)
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IOException("HTTP $code: ${text.take(300)}")
            return text
        } finally { c.disconnect() }
    }

    private fun certSha1(): String? = runCatching {
        val info = app.packageManager.getPackageInfo(app.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        val sig = info.signingInfo?.apkContentsSigners?.firstOrNull() ?: return@runCatching null
        MessageDigest.getInstance("SHA-1").digest(sig.toByteArray()).joinToString("") { "%02X".format(it) }
    }.getOrNull()

    private fun fail(e: Exception) {
        val m = e.message.orEmpty()
        _status.value = when {
            m.contains("PERMISSION_DENIED") || m.contains("HTTP 403") && m.contains("firestore", true) -> "Backup off: set up Firestore and its rules in the Firebase console"
            m.contains("OPERATION_NOT_ALLOWED") || m.contains("CONFIGURATION_NOT_FOUND") -> "Backup off: turn on Google sign-in in Firebase Authentication"
            m.contains("NOT_FOUND") && m.contains("database", true) -> "Backup off: create the Firestore database in the Firebase console"
            m.contains("HTTP 400") || m.contains("HTTP 401") -> "Backup could not sign in. Press Connect to try again. (${m.take(80)})"
            e is java.net.UnknownHostException || e is java.net.SocketTimeoutException -> "No internet: backup will retry later"
            else -> "Backup problem: ${m.take(100)}"
        }
    }
}
