package com.appforge.shivangi.brain

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Her learning memory. The first time Gemini works out how to do something ("open youtube",
 * "set alarm 6 am"), the sentence and the action are saved here. Next time the same kind of sentence
 * runs straight from this memory, without asking Gemini.
 *
 * Saved on the phone (learned.json), so it works offline; CloudSync keeps a backup copy.
 * Numbers and names in the sentence become slots, so "set alarm 6 am" also covers "set alarm 7 am".
 */
object Learned {
    class Entry(val template: String, val tool: String, val args: JSONObject, var uses: Int, val learnedAt: Long, var fails: Int = 0)
    class Plan(val entry: Entry, val tool: String, val args: JSONObject)

    /** Only actions (no live data like weather, no messages): a replay does exactly what Gemini did */
    private val LEARNABLE = setOf(
        "set_alarm", "set_timer", "open_app", "call_contact", "torch", "set_volume", "set_brightness",
        "set_screen_timeout", "do_not_disturb", "wifi_bluetooth", "play_music", "media_control",
        "find_nearby", "show_photos", "share_last_screenshot", "find_document"
    )
    private const val FILE = "learned.json"
    private const val MAX_ENTRIES = 300
    private val SLOT = Regex("\\{([ns])(\\d+)}")
    private val FILLER_START = listOf("hey shivangi", "ok shivangi", "okay shivangi", "shivangi", "hey", "hi", "ok", "okay", "please", "plz", "kindly",
        "can you", "could you", "would you", "will you", "शिवांगी", "कृपया")
    private val FILLER_END = listOf("please", "plz", "ji", "जी", "na", "yaar")
    private val CONFIRMATIONS = setOf("yes", "no", "ok", "okay", "sure", "yeah", "haan", "han", "ha", "nahi", "nope", "do it", "go ahead", "theek hai",
        "kar do", "karo", "हाँ", "हां", "नहीं", "ठीक है", "कर दो", "करो", "that one", "the first one", "this one")

    private lateinit var dir: File
    private val lock = Any()
    private val _items = MutableStateFlow<List<Entry>>(emptyList())
    val items: StateFlow<List<Entry>> = _items

    fun init(c: Context) {
        dir = c.filesDir
        synchronized(lock) { _items.value = parse(runCatching { File(dir, FILE).readText() }.getOrDefault("[]")) }
    }

    // ------------------------------------------------------------ text normalising

    /** Lower case, no punctuation, Hindi digits to 0-9, polite filler words removed */
    fun normalize(raw: String): String {
        var t = raw.lowercase()
        t = t.map { ch -> if (ch in '\u0966'..'\u096F') ('0' + (ch - '\u0966')) else ch }.joinToString("")
        t = t.replace(Regex("[^\\p{L}\\p{N}\\p{M}{}]+"), " ").trim().replace(Regex("\\s+"), " ")
        var changed = true
        while (changed) {
            changed = false
            for (f in FILLER_START) if (t.startsWith("$f ")) { t = t.removePrefix("$f ").trim(); changed = true }
            for (f in FILLER_END) if (t.endsWith(" $f")) { t = t.removeSuffix(" $f").trim(); changed = true }
        }
        return t
    }

    // ------------------------------------------------------------ learning

    /** Called after Gemini ran one tool for this sentence and it worked */
    fun learn(text: String, tool: String, args: JSONObject) {
        if (tool !in LEARNABLE || !::dir.isInitialized) return
        val norm = normalize(text)
        if (norm.length < 3 || norm.split(' ').size < 2 || norm in CONFIRMATIONS) return
        var tpl = norm
        val out = JSONObject()
        var n = 0; var s = 0
        for (key in args.keys()) {
            val v = args.get(key)
            val asText: String? = when (v) {
                is Int, is Long -> v.toString()
                is Double -> if (v % 1.0 == 0.0) v.toLong().toString() else null
                is String -> normalize(v).takeIf { it.isNotBlank() }
                else -> null
            }
            val isNum = v is Int || v is Long || v is Double
            if (asText != null) {
                val re = Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(asText) + "(?![\\p{L}\\p{N}])")
                if (re.containsMatchIn(tpl)) {
                    val slot = if (isNum) "{n${n++}}" else "{s${s++}}"
                    tpl = tpl.replaceFirst(re, slot)
                    out.put(key, slot)
                    continue
                }
            }
            out.put(key, v)
        }
        // Needs at least one real word besides the slots, and the whole sentence must not be just a slot
        val literal = SLOT.replace(tpl, "").trim()
        if (literal.length < 2) return
        synchronized(lock) {
            val list = _items.value.toMutableList()
            val existing = list.firstOrNull { it.template == tpl }
            if (existing != null) { existing.uses++ ; _items.value = list.toList() }
            else {
                list.add(Entry(tpl, tool, out, 0, System.currentTimeMillis()))
                if (list.size > MAX_ENTRIES) list.sortWith(compareBy({ it.uses }, { it.learnedAt })).also { while (list.size > MAX_ENTRIES) list.removeAt(0) }
                _items.value = list.toList()
            }
            save()
        }
        CloudSync.scheduleUpload()
    }

    // ------------------------------------------------------------ replay

    fun match(text: String): Plan? {
        val norm = normalize(text)
        if (norm.isBlank()) return null
        var best: Plan? = null
        var bestScore = -1
        for (e in _items.value) {
            val m = regexFor(e.template).matchEntire(norm) ?: continue
            val args = JSONObject()
            var ok = true
            for (k in e.args.keys()) {
                val v = e.args.get(k)
                val slot = (v as? String)?.let { SLOT.matchEntire(it) }
                if (slot == null) { args.put(k, v); continue }
                val idx = slot.groupValues[2].toInt()
                val kind = slot.groupValues[1]
                val captured = capture(e.template, m, kind, idx) ?: run { ok = false; null }
                if (captured == null) break
                if (kind == "n") args.put(k, captured.toIntOrNull() ?: run { ok = false; 0 }) else args.put(k, captured.trim())
            }
            if (!ok) continue
            val score = SLOT.replace(e.template, "").length * 10 + e.uses
            if (score > bestScore) { bestScore = score; best = Plan(e, e.tool, args) }
        }
        return best
    }

    /** Group number of slot (kind, idx) inside the regex built from the template */
    private fun capture(template: String, m: MatchResult, kind: String, idx: Int): String? {
        var g = 0
        for (t in SLOT.findAll(template)) {
            g++
            if (t.groupValues[1] == kind && t.groupValues[2].toInt() == idx) return m.groupValues.getOrNull(g)
        }
        return null
    }

    private fun regexFor(template: String): Regex {
        val sb = StringBuilder("^")
        var last = 0
        for (t in SLOT.findAll(template)) {
            sb.append(Regex.escape(template.substring(last, t.range.first)))
            sb.append(if (t.groupValues[1] == "n") "(\\d{1,4})" else "(.{1,40}?)")
            last = t.range.last + 1
        }
        sb.append(Regex.escape(template.substring(last))).append("$")
        return Regex(sb.toString())
    }

    fun reportSuccess(e: Entry) { synchronized(lock) { e.uses++; e.fails = 0; save() } }
    fun reportFailure(e: Entry) {
        synchronized(lock) {
            e.fails++
            if (e.fails >= 2) _items.value = _items.value.filter { it !== e }
            save()
        }
    }

    // ------------------------------------------------------------ manage / save / cloud

    fun delete(template: String) { synchronized(lock) { _items.value = _items.value.filter { it.template != template }; save() }; CloudSync.scheduleUpload() }
    fun clear() { synchronized(lock) { _items.value = emptyList(); save() } }

    fun exportJson(): String = synchronized(lock) { toJson(_items.value).toString() }

    /** Adds entries from the cloud copy; keeps what is already here. Returns how many were new. */
    fun mergeJson(json: String): Int {
        val incoming = parse(json)
        var added = 0
        synchronized(lock) {
            val list = _items.value.toMutableList()
            for (e in incoming) {
                val have = list.firstOrNull { it.template == e.template }
                if (have == null) { list.add(e); added++ } else if (e.uses > have.uses) have.uses = e.uses
            }
            _items.value = list.toList(); save()
        }
        return added
    }

    private fun toJson(list: List<Entry>) = JSONArray().apply {
        list.forEach { put(JSONObject().put("t", it.template).put("tool", it.tool).put("args", it.args).put("n", it.uses).put("at", it.learnedAt)) }
    }

    private fun parse(json: String): List<Entry> = runCatching {
        val a = JSONArray(json)
        (0 until a.length()).mapNotNull { i ->
            val o = a.getJSONObject(i)
            val tool = o.optString("tool")
            if (tool !in LEARNABLE) null else Entry(o.getString("t"), tool, o.getJSONObject("args"), o.optInt("n"), o.optLong("at"))
        }
    }.getOrDefault(emptyList())

    private fun save() { runCatching { File(dir, FILE).writeText(toJson(_items.value).toString()) } }
}
