package com.appforge.shivangi.brain

import com.appforge.shivangi.data.Languages
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Everyday commands she understands on the phone itself, with no Gemini and no internet:
 * alarm, timer, open app, call, torch, volume, brightness, silent mode, music controls, time and date.
 * English, Hindi and Hinglish.
 */
object LocalCommands {
    /** [tool] null = she only speaks [say] */
    class Plan(val tool: String?, val args: JSONObject = JSONObject(), val say: String? = null)

    fun match(raw: String): Plan? {
        val t = Learned.normalize(raw)
        if (t.isBlank() || t.length > 90) return null
        return torch(t) ?: volume(t) ?: brightness(t) ?: silent(t) ?: timer(t) ?: alarm(t) ?: media(t) ?: timeDate(t) ?: call(t) ?: openApp(t)
    }

    private fun tokens(t: String) = t.split(' ').toSet()
    private val ON = setOf("on", "chalu", "चालू", "jalao", "जलाओ", "enable", "start", "shuru", "शुरू", "activate")
    private val OFF = setOf("off", "band", "बंद", "bujhao", "बुझाओ", "disable", "stop", "deactivate")
    private val NUM = Regex("\\d{1,3}")

    // ---------------------------------------------------------------- torch

    private val TORCH = listOf("torch", "flashlight", "flash light", "टॉर्च", "टार्च", "फ्लैशलाइट", "फ़्लैशलाइट", "tarch")
    private fun torch(t: String): Plan? {
        if (TORCH.none { t.contains(it) }) return null
        val k = tokens(t)
        val on = when { k.any { it in OFF } -> false; k.any { it in ON } -> true; else -> return null }
        return Plan("torch", JSONObject().put("on", on))
    }

    // ---------------------------------------------------------------- volume / brightness

    private val VOLUME = listOf("volume", "वॉल्यूम", "वोल्यूम", "awaz", "awaaz", "aawaz", "आवाज", "आवाज़")
    private fun volume(t: String): Plan? {
        if (VOLUME.none { t.contains(it) }) return null
        val k = tokens(t)
        val level = level(t) ?: return null
        val stream = when {
            k.any { it in setOf("ring", "ringtone", "ringer", "रिंगटोन") } -> "ring"
            k.any { it in setOf("alarm", "अलार्म") } -> "alarm"
            else -> "media"
        }
        return Plan("set_volume", JSONObject().put("level", level).put("stream", stream))
    }

    private val BRIGHT = listOf("brightness", "ब्राइटनेस", "ब्राईटनेस", "brightnes")
    private fun brightness(t: String): Plan? {
        if (BRIGHT.none { t.contains(it) }) return null
        val level = level(t) ?: return null
        return Plan("set_brightness", JSONObject().put("level", level.coerceAtLeast(1)))
    }

    private fun level(t: String): Int? {
        val k = tokens(t)
        NUM.find(t)?.value?.toIntOrNull()?.let { if (it in 0..100) return it }
        return when {
            k.any { it in setOf("mute", "म्यूट", "zero", "शून्य") } -> 0
            k.any { it in setOf("full", "max", "maximum", "फुल", "मैक्स") } -> 100
            k.any { it in setOf("half", "आधा") } -> 50
            k.any { it in setOf("min", "minimum", "lowest") } -> 5
            else -> null
        }
    }

    // ---------------------------------------------------------------- silent mode

    private fun silent(t: String): Plan? {
        val isDnd = t.contains("do not disturb") || t.contains("dont disturb") || t.split(' ').contains("dnd") ||
            t.contains("silent mode") || t.contains("meeting mode") || t.contains("साइलेंट मोड") || t.contains("सायलेंट मोड") ||
            t.contains("डू नॉट डिस्टर्ब") || t.contains("silent mod")
        if (!isDnd) return null
        val k = tokens(t)
        val on = when { k.any { it in OFF } -> false; else -> true }
        return Plan("do_not_disturb", JSONObject().put("on", on))
    }

    // ---------------------------------------------------------------- timer

    private fun timer(t: String): Plan? {
        if (!(t.contains("timer") || t.contains("टाइमर"))) return null
        val parts = t.split(' ')
        var seconds = 0
        for (i in parts.indices) {
            val n = parts[i].toIntOrNull() ?: continue
            val unit = parts.getOrNull(i + 1) ?: continue
            seconds += when {
                unit.startsWith("sec") || unit.startsWith("सेकंड") || unit.startsWith("सेकेंड") -> n
                unit.startsWith("min") || unit.startsWith("मिनट") || unit.startsWith("minat") -> n * 60
                unit.startsWith("hour") || unit.startsWith("hr") || unit.startsWith("घंट") || unit.startsWith("ghant") -> n * 3600
                else -> 0
            }
        }
        if (seconds <= 0) return null
        val msg = say(en = "Timer set for ${spoken(seconds)}.", hi = "${spoken(seconds)} का टाइमर लगा दिया।", hinglish = "${spoken(seconds)} ka timer laga diya.")
        return Plan("set_timer", JSONObject().put("seconds", seconds), msg)
    }

    private fun spoken(sec: Int): String {
        val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
        return listOfNotNull(
            if (h > 0) "$h hour${if (h > 1) "s" else ""}" else null,
            if (m > 0) "$m minute${if (m > 1) "s" else ""}" else null,
            if (s > 0) "$s second${if (s > 1) "s" else ""}" else null
        ).joinToString(" ")
    }

    // ---------------------------------------------------------------- alarm

    private val WORD_NUM = mapOf("one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7, "eight" to 8,
        "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12)
    private val MORNING = setOf("am", "morning", "subah", "सुबह", "savere", "सवेरे")
    private val EVENING = setOf("pm", "evening", "shaam", "शाम", "afternoon", "dopahar", "दोपहर", "night", "raat", "रात")

    private fun alarm(t: String): Plan? {
        if (!(t.contains("alarm") || t.contains("अलार्म") || t.contains("alaram"))) return null
        val p = t.split(' ').map { WORD_NUM[it]?.toString() ?: it }
        if (p.any { it in setOf("minute", "minutes", "min", "mins", "मिनट", "hour", "hours", "घंटे", "ghante", "baad", "बाद", "after", "in") }) return null
        val idx = p.indexOfFirst { it.toIntOrNull() != null }
        if (idx < 0) return null
        val hour = p[idx].toInt()
        var minute = 0
        p.getOrNull(idx + 1)?.let { nx -> if (nx.length == 2 && nx.toIntOrNull() in 0..59 && p.getOrNull(idx + 2) !in setOf("minute", "minutes", "min", "मिनट")) minute = nx.toInt() }
        if (hour !in 0..23) return null
        val k = p.toSet()
        var h24 = hour
        val night = k.any { it in setOf("night", "raat", "रात") }
        when {
            hour > 12 -> {}
            k.any { it in MORNING } -> h24 = if (hour == 12) 0 else hour
            night -> h24 = when { hour == 12 -> 0; hour >= 6 -> hour + 12; else -> hour }
            k.any { it in EVENING } -> h24 = if (hour == 12) 12 else hour + 12
            else -> h24 = nextOccurrence(hour, minute)   // no am/pm said: the next time that clock reading comes
        }
        val label12 = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h24); set(Calendar.MINUTE, minute) }.time)
        val msg = say(en = "Alarm set for $label12.", hi = "अलार्म $label12 के लिए लगा दिया।", hinglish = "Alarm $label12 ke liye laga diya.")
        return Plan("set_alarm", JSONObject().put("hour", h24).put("minute", minute), msg)
    }

    private fun nextOccurrence(hour12: Int, minute: Int): Int {
        val now = Calendar.getInstance()
        val am = hour12 % 12
        fun delta(h24: Int): Int { val d = (h24 * 60 + minute) - (now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)); return if (d <= 0) d + 1440 else d }
        return if (delta(am) <= delta(am + 12)) am else am + 12
    }

    // ---------------------------------------------------------------- music controls (short phrases only)

    private val PAUSE = setOf("pause", "pause music", "pause the music", "pause song", "pause the song", "pause video", "stop music", "stop the music", "stop song",
        "gana roko", "gaana roko", "गाना रोको", "गाना बंद करो", "gana band karo", "gaana band karo", "music band karo", "music roko", "म्यूजिक बंद करो", "म्यूजिक रोको")
    private val PLAY = setOf("resume", "resume music", "resume song", "play music", "play the music", "continue music", "gana chalao", "gaana chalao", "गाना चलाओ", "music chalao", "म्यूजिक चलाओ")
    private val NEXT = setOf("next", "next song", "next track", "skip", "skip song", "agla gana", "agla gaana", "अगला गाना", "next gana")
    private val PREV = setOf("previous", "previous song", "previous track", "last song", "pichla gana", "pichla gaana", "पिछला गाना")
    private fun media(t: String): Plan? {
        val a = when (t) { in PAUSE -> "pause"; in PLAY -> "play"; in NEXT -> "next"; in PREV -> "previous"; else -> return null }
        return Plan("media_control", JSONObject().put("action", a))
    }

    // ---------------------------------------------------------------- time and date

    private fun timeDate(t: String): Plan? {
        val isTime = t in setOf("what time is it", "what is the time", "whats the time", "tell me the time", "current time", "time please", "time kya hai",
            "time kya hua", "samay kya hua", "kitne baje hain", "kitne baje hai", "abhi kitne baje hain", "टाइम क्या हुआ", "टाइम क्या हुआ है", "समय क्या हुआ है",
            "अभी कितने बजे हैं", "कितने बजे हैं", "what is the time now", "whats the time now")
        val isDate = t in setOf("what is the date today", "whats the date today", "what is todays date", "todays date", "what day is it", "what day is it today",
            "date today", "aaj ki date kya hai", "aaj kaun sa din hai", "aaj kya date hai", "आज की तारीख क्या है", "आज कौन सा दिन है", "आज कौन सा दिन है आज की तारीख")
        if (!isTime && !isDate) return null
        val now = Date()
        return if (isTime) {
            val s = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(now)
            Plan(null, say = say(en = "It's $s.", hi = "अभी $s हुए हैं।", hinglish = "Abhi $s hue hain."))
        } else {
            val s = SimpleDateFormat("EEEE, d MMMM", Locale.ENGLISH).format(now)
            Plan(null, say = say(en = "Today is $s.", hi = "आज $s है।", hinglish = "Aaj $s hai."))
        }
    }

    // ---------------------------------------------------------------- open app / call

    private val OPEN_EN = Regex("^(?:open|launch|start) (?:the )?(?:app )?(.{2,40})$")
    private val OPEN_HI = Regex("^(.{2,40}?) (?:ko )?(?:को )?(?:kholo|khol do|khol dijiye|open karo|open kar do|खोलो|खोल दो|खोलिए|ओपन करो|ओपन कर दो)$")
    private fun openApp(t: String): Plan? {
        val name = (OPEN_EN.matchEntire(t)?.groupValues?.get(1) ?: OPEN_HI.matchEntire(t)?.groupValues?.get(1)) ?: return null
        val clean = name.split(' ').filter { it !in setOf("app", "ko", "को", "एप", "ऐप", "the") }.joinToString(" ").trim()
        if (clean.isBlank() || clean.split(' ').size > 4) return null
        return Plan("open_app", JSONObject().put("name", clean))
    }

    private val CALL_EN = Regex("^(?:call|phone|dial|ring) (.{2,40})$")
    private val CALL_HI = Regex("^(.{2,40}?) (?:ko )?(?:को )?(?:call|phone|कॉल|फोन|फ़ोन) (?:karo|kar do|lagao|laga do|milao|करो|कर दो|लगाओ|लगा दो|मिलाओ)$")
    private fun call(t: String): Plan? {
        val who = (CALL_EN.matchEntire(t)?.groupValues?.get(1) ?: CALL_HI.matchEntire(t)?.groupValues?.get(1)) ?: return null
        val clean = who.split(' ').filter { it !in setOf("ko", "को", "the") }.joinToString(" ").trim()
        if (clean.isBlank() || clean.split(' ').size > 4 || clean in setOf("me", "back", "later")) return null
        return Plan("call_contact", JSONObject().put("who", clean))
    }

    // ---------------------------------------------------------------- reply language

    private fun say(en: String, hi: String, hinglish: String): String = when (Languages.current.code) { "hi" -> hi; "hinglish" -> hinglish; else -> en }
}
