package com.appforge.shivangi.debug

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Keeps a crash log in the app's own storage so it can be shown (and copied) the next time the app opens.
 *  - Catches every uncaught crash and saves the stack trace
 *  - Records avatar / 3D page errors via [log]
 *  - On start, adds the system's report of earlier native crashes, ANRs and low-memory kills
 */
object CrashLog {
    private const val FILE = "crash_log.txt"
    private const val MAX_CHARS = 60_000
    private const val PREFS = "crashlog"
    private const val KEY_LAST_EXIT = "last_exit_ts"

    private lateinit var app: Context
    private val lock = Any()

    fun install(context: Context) {
        app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching { log("CRASH (thread ${thread.name})", Log.getStackTraceString(error)) }
            previous?.uncaughtException(thread, error)
        }
        runCatching { recordEarlierExits() }
    }

    /** Adds one entry to the log. Safe to call from any thread. */
    fun log(tag: String, message: String) {
        if (!::app.isInitialized) return
        Log.e("ShivangiCrashLog", "$tag: $message")
        synchronized(lock) {
            runCatching {
                val f = File(app.filesDir, FILE)
                val entry = buildString {
                    append("=== ").append(now()).append("  ").append(tag).append(" ===\n")
                    append(message.trim()).append("\n\n")
                }
                var text = (if (f.exists()) f.readText() else header()) + entry
                if (text.length > MAX_CHARS) text = header() + "(older entries trimmed)\n\n" + text.takeLast(MAX_CHARS - 600)
                f.writeText(text)
            }
        }
    }

    fun hasLog(context: Context): Boolean = runCatching { File(context.filesDir, FILE).let { it.exists() && it.length() > 0 } }.getOrDefault(false)

    fun read(context: Context): String = runCatching { File(context.filesDir, FILE).readText() }.getOrDefault("")

    fun clear(context: Context) { runCatching { File(context.filesDir, FILE).delete() } }

    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    private fun header(): String {
        val version = runCatching { app.packageManager.getPackageInfo(app.packageName, 0).versionName }.getOrNull()
        return "Shivangi crash log\n" +
            "App version: $version\n" +
            "Phone: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\n"
    }

    private fun recordEarlierExits() {
        val am = app.getSystemService(ActivityManager::class.java) ?: return
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val last = prefs.getLong(KEY_LAST_EXIT, 0L)
        val exits = am.getHistoricalProcessExitReasons(app.packageName, 0, 10)
        var newest = last
        for (e in exits.sortedBy { it.timestamp }) {
            if (e.timestamp <= last) continue
            newest = maxOf(newest, e.timestamp)
            val kind = when (e.reason) {
                ApplicationExitInfo.REASON_CRASH_NATIVE -> "native crash"
                ApplicationExitInfo.REASON_ANR -> "app not responding (ANR)"
                ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "failed to start"
                ApplicationExitInfo.REASON_SIGNALED -> "killed by signal"
                ApplicationExitInfo.REASON_LOW_MEMORY -> "killed: low memory"
                else -> continue   // normal exits and ordinary crashes (already logged above) are skipped
            }
            val trace = if (e.reason == ApplicationExitInfo.REASON_CRASH_NATIVE || e.reason == ApplicationExitInfo.REASON_ANR)
                runCatching { e.traceInputStream?.bufferedReader()?.use { it.readText().take(4000) } }.getOrNull() else null
            log(
                "Earlier exit: $kind",
                "When: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(e.timestamp))}\n" +
                    "Description: ${e.description ?: "-"}\n" +
                    "Importance: ${e.importance}, status: ${e.status}" +
                    (if (trace.isNullOrBlank()) "" else "\n--- trace ---\n$trace")
            )
        }
        if (newest > last) prefs.edit().putLong(KEY_LAST_EXIT, newest).apply()
    }
}
