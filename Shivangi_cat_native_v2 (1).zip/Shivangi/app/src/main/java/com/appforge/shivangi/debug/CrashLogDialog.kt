package com.appforge.shivangi.debug

import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast

/** Shows the saved crash log when the app opens. Copy it, paste it into the chat, then Clear. */
@Composable
fun CrashLogDialog() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(if (CrashLog.hasLog(ctx)) CrashLog.read(ctx) else "") }
    if (text.isBlank()) return
    AlertDialog(
        onDismissRequest = { text = "" },
        title = { Text("Crash log") },
        text = {
            SelectionContainer {
                Text(
                    text, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 14.sp,
                    modifier = Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                ctx.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Shivangi crash log", text))
                Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
            }) { Text("Copy") }
        },
        dismissButton = {
            TextButton(onClick = { CrashLog.clear(ctx); text = "" }) { Text("Clear") }
            TextButton(onClick = { text = "" }) { Text("Close") }
        }
    )
}
