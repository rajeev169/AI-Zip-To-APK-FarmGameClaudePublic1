package com.appforge.shivangi.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.appforge.shivangi.R
import com.appforge.shivangi.avatar.CatView

/** The 3D cat in the app (native, transparent). If the 3D view cannot start, her photo is shown instead and the error goes to the crash log. */
@Composable
fun AvatarView(modifier: Modifier = Modifier, framing: String = "bust") {
    var failed by remember { mutableStateOf(false) }
    Box(modifier, contentAlignment = Alignment.Center) {
        if (!failed) CatView(Modifier.fillMaxSize(), onFailed = { failed = true })
        else Image(painterResource(R.drawable.shivangi_head), null, Modifier.size(140.dp).alpha(0.9f))
    }
}
