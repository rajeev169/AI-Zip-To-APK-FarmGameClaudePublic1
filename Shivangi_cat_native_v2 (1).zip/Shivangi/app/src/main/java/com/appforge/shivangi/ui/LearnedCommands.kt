package com.appforge.shivangi.ui

import android.app.Activity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.shivangi.auth.GoogleAuth
import com.appforge.shivangi.brain.CloudSync
import com.appforge.shivangi.brain.Learned
import kotlinx.coroutines.launch

/** Settings rows: what she has learned to do without Gemini, and the cloud backup of it */
@Composable
fun LearnedCommandsRow(activity: Activity) {
    val items by Learned.items.collectAsState()
    val status by CloudSync.status.collectAsState()
    val scope = rememberCoroutineScope()
    var show by remember { mutableStateOf(false) }
    val connected = remember(status) { CloudSync.connected }

    InfoRow("Learned commands", "${items.size} saved on this phone. She does these without Gemini.") {
        OutlinedButton(onClick = { show = true }) { Text("View") }
    }
    RowDivider()
    InfoRow("Cloud backup", status.ifBlank { "Not connected" }) {
        OutlinedButton(onClick = {
            if (connected) CloudSync.backupNow() else scope.launch { GoogleAuth.signIn(activity) }
        }) { Text(if (connected) "Back up now" else "Connect") }
    }

    if (show) AlertDialog(
        onDismissRequest = { show = false },
        title = { Text("Learned commands") },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (items.isEmpty()) Text("Nothing yet. When Gemini teaches her a new task, it appears here.", fontSize = 14.sp)
                items.sortedByDescending { it.uses }.forEach { e ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("“" + e.template.replace(Regex("\\{[ns]\\d+}"), "…") + "”", fontSize = 14.sp)
                            Text("${e.tool.replace('_', ' ')} · used ${e.uses}×", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { Learned.delete(e.template) }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { show = false }) { Text("Close") } },
        dismissButton = { if (items.isNotEmpty()) TextButton(onClick = { Learned.clear(); CloudSync.scheduleUpload() }) { Text("Clear all") } }
    )
}
