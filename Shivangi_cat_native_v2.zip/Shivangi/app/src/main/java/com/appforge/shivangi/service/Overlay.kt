package com.appforge.shivangi.service

import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.ScreenshotMonitor
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.appforge.shivangi.R
import com.appforge.shivangi.avatar.CatView
import com.appforge.shivangi.brain.Assistant
import com.appforge.shivangi.brain.Phase
import com.appforge.shivangi.voice.Listener
import kotlinx.coroutines.delay

private val Plum = Color(0xFF7A2E6B)
private val Blush = Color(0xFFFFE3EC)
private val Ink = Color(0xFF241A22)

/**
 * Her floating 3D cat over other apps: only the cat is drawn (transparent, no frame).
 * She appears when she wakes or speaks and fades away a few seconds after; tap her to talk, drag to move, long-press to dismiss.
 */
class Overlay(private val service: AssistantService) {
    private val wm = service.getSystemService(WindowManager::class.java)
    private val density = service.resources.displayMetrics.density
    private var view: ComposeView? = null
    private val panelOpen = mutableStateOf(false)

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = (service.resources.displayMetrics.widthPixels - 170 * density).toInt().coerceAtLeast(0)
        y = (260 * density).toInt()
    }

    fun show() {
        if (view != null) return
        val v = ComposeView(service).apply {
            setViewTreeLifecycleOwner(service)
            setViewTreeSavedStateRegistryOwner(service)
            setContent { CatBubble() }
        }
        runCatching { wm.addView(v, params) }.onSuccess { view = v }
    }

    fun hide() { view?.let { runCatching { wm.removeView(it) } }; view = null }
    fun openPanel() { panelOpen.value = true; snapForPanel() }
    fun closePanel() { panelOpen.value = false }

    private fun snapForPanel() {
        val v = view ?: return
        val dm = service.resources.displayMetrics
        params.x = params.x.coerceAtMost((dm.widthPixels - 300 * density).toInt().coerceAtLeast(0))
        runCatching { wm.updateViewLayout(v, params) }
    }

    private fun moveBy(dx: Float, dy: Float) {
        val v = view ?: return
        val dm = service.resources.displayMetrics
        params.x = (params.x + dx).toInt().coerceIn(0, (dm.widthPixels - v.width).coerceAtLeast(0))
        params.y = (params.y + dy).toInt().coerceIn(0, (dm.heightPixels - v.height).coerceAtLeast(0))
        runCatching { wm.updateViewLayout(v, params) }
    }

    @Composable
    private fun CatBubble() {
        val open by panelOpen
        val phase by Assistant.phase.collectAsState()
        var appOnScreen by remember { mutableStateOf(AppState.mainVisible) }
        var lingering by remember { mutableStateOf(false) }
        var dismissed by remember { mutableStateOf(false) }

        // The app shows its own cat when it is open, so the floating one steps aside
        LaunchedEffect(Unit) { while (true) { appOnScreen = AppState.mainVisible; delay(400) } }
        // Appear when she wakes / thinks / speaks; stay a few seconds after she finishes
        LaunchedEffect(phase) {
            if (phase != Phase.IDLE) lingering = true
            else { delay(6000); lingering = false; dismissed = false }
        }
        val showCat = (lingering || open) && !dismissed && !appOnScreen

        Column(horizontalAlignment = Alignment.End) {
            if (showCat) {
                Box(Modifier.size(150.dp)) {
                    CatView(Modifier.fillMaxSize())
                    // Invisible touch layer on top of the cat: drag, tap, long-press
                    Box(
                        Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) { detectDragGestures { ch, d -> ch.consume(); moveBy(d.x, d.y) } }
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = {
                                        if (panelOpen.value) { panelOpen.value = false; Assistant.stop() }
                                        else { openPanel(); Assistant.startVoiceTurn() }
                                    },
                                    onLongPress = {
                                        dismissed = true
                                        if (panelOpen.value) { panelOpen.value = false; Assistant.stop() }
                                    }
                                )
                            }
                    )
                }
            }
            if (open) {
                Spacer(Modifier.size(8.dp))
                Panel()
            }
        }
    }

    @Composable
    private fun Panel() {
        val phase by Assistant.phase.collectAsState()
        val session by Assistant.session.collectAsState()
        val partial by Listener.partial.collectAsState()
        val call by Assistant.call.collectAsState()
        Surface(shape = RoundedCornerShape(22.dp), color = Color.White, shadowElevation = 8.dp, modifier = Modifier.width(290.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(when (phase) {
                            Phase.LISTENING -> R.string.st_listening
                            Phase.THINKING -> R.string.st_thinking
                            Phase.SPEAKING -> R.string.st_speaking
                            Phase.IDLE -> R.string.st_ready
                        }),
                        color = Plum, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { panelOpen.value = false; Assistant.stop() }) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), tint = Ink)
                    }
                }
                val lastUser = session.lastOrNull { it.fromUser }?.text
                val lastHer = session.lastOrNull { !it.fromUser }?.text
                val userLine = if (phase == Phase.LISTENING) partial else lastUser
                if (!userLine.isNullOrBlank()) Text("“$userLine”", color = Ink, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                if (!lastHer.isNullOrBlank() && phase != Phase.LISTENING)
                    Text(lastHer, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 8, overflow = TextOverflow.Ellipsis)
                call?.let { c ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.calling_in, c.name, c.secondsLeft), color = Ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { Assistant.cancelCall() }) { Text(stringResource(R.string.cancel)) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { Assistant.startVoiceTurn() }, colors = ButtonDefaults.buttonColors(containerColor = Plum)) {
                        Icon(Icons.Default.Mic, null); Spacer(Modifier.size(6.dp)); Text(stringResource(R.string.talk))
                    }
                    OutlinedButton(onClick = { Assistant.requestScreen(service.getString(R.string.screen_default_q)) }) {
                        Icon(Icons.Default.ScreenshotMonitor, null, tint = Plum); Spacer(Modifier.size(6.dp))
                        Text(stringResource(R.string.screen_short), color = Plum)
                    }
                }
            }
        }
    }
}
