# Crash-log test

1. Install the debug APK built from this project.
2. Open Shivangi and reproduce the problem with Display over other apps enabled.
3. If the app closes, open Shivangi again.
4. A **Crash log available** dialog should appear.
5. Tap **Copy crash log** and paste the clipboard contents into the support message.
6. The log records the exception, Android version, phone model, app version, and the last startup stage.

The recorded stages include `SERVICE_START_FOREGROUND`, `SERVICE_FOREGROUND_STARTED`, `OVERLAY_CREATE_START`, `OVERLAY_COMPOSE_VIEW_CREATE`, `OVERLAY_SET_CONTENT`, and `OVERLAY_WINDOW_ADD`.

If the app never shows a dialog after reopening, the failure may be a native crash or OS-level kill; in that case an ADB logcat is still required.
