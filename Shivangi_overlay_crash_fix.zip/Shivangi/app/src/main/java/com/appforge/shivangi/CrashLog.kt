package com.appforge.shivangi

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Saves the last uncaught Java/Kotlin crash so it can be copied after the app restarts. */
object CrashLog {
    private const val FILE_NAME = "last_crash.txt"
    @Volatile private var stage = "not started"
    private lateinit var file: File
    private var appVersion = "unknown"
    private var installed = false

    fun init(context: Context) {
        if (installed) return
        installed = true
        val app = context.applicationContext
        file = File(app.filesDir, FILE_NAME)
        appVersion = runCatching { app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "unknown" }.getOrDefault("unknown")
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            write(thread, error)
            previous?.uncaughtException(thread, error)
        }
    }

    fun mark(value: String) {
        stage = value
    }

    fun read(): String? = if (::file.isInitialized && file.exists()) file.readText().takeIf { it.isNotBlank() } else null

    fun clear() {
        if (::file.isInitialized) file.delete()
    }

    private fun write(thread: Thread, error: Throwable) {
        if (!::file.isInitialized) return
        val trace = StringWriter().also { sw -> error.printStackTrace(PrintWriter(sw)) }.toString()
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.US).format(Date())
        val text = buildString {
            appendLine("Shivangi crash log")
            appendLine("time: $now")
            appendLine("thread: ${thread.name}")
            appendLine("stage: $stage")
            appendLine("device: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("app: $appVersion")
            appendLine()
            append(trace)
        }
        runCatching { file.writeText(text) }
    }
}
