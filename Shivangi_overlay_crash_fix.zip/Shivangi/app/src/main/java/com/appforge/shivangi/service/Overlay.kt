package com.appforge.shivangi.service

import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.ScreenshotMonitor
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.appforge.shivangi.R
import com.appforge.shivangi.brain.Assistant
import com.appforge.shivangi.brain.Phase
import com.appforge.shivangi.CrashLog
import com.appforge.shivangi.voice.Listener

private val Plum = Color(0xFF7A2E6B)
private val Blush = Color(0xFFFFE3EC)
private val Ink = Color(0xFF241A22)

/** Her floating face over other apps; tap it to talk. */
class Overlay(private val service: AssistantService) {
    private val wm = service.getSystemService(WindowManager::class.java)
    private val density = service.resources.displayMetrics.density
    private var view: ComposeView? = null
    private val panelOpen = mutableStateOf(false)

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = (service.resources.displayMetrics.widthPixels - 80 * density).toInt()
        y = (260 * density).toInt()
    }

    fun show() {
        if (view != null) return
        CrashLog.mark("OVERLAY_COMPOSE_VIEW_CREATE")
        val v = ComposeView(service).apply {
            CrashLog.mark("OVERLAY_SET_LIFECYCLE")
            setViewTreeLifecycleOwner(service)
            setViewTreeSavedStateRegistryOwner(service)
            CrashLog.mark("OVERLAY_SET_CONTENT")
            setContent { this@Overlay.Content() }
        }
        CrashLog.mark("OVERLAY_WINDOW_ADD")
        runCatching { wm.addView(v, params) }.onSuccess { view = v }
        CrashLog.mark("OVERLAY_WINDOW_ADD_RETURNED")
    }

    fun hide() { view?.let { runCatching { wm.removeView(it) } }; view = null }
    fun openPanel() { panelOpen.value = true; snapForPanel() }
    fun closePanel() { panelOpen.value = false }

    private fun snapForPanel() {
        val v = view ?: return
        val dm = service.resources.displayMetrics
        params.x = params.x.coerceAtMost((dm.widthPixels - 300 * density).toInt().coerceAtLeast(0))
        runCatching { wm.updateViewLayout(v, params) }
    }

    private fun moveBy(dx: Float, dy: Float) {
        val v = view ?: return
        val dm = service.resources.displayMetrics
        params.x = (params.x + dx).toInt().coerceIn(0, (dm.widthPixels - v.width).coerceAtLeast(0))
        params.y = (params.y + dy).toInt().coerceIn(0, (dm.heightPixels - v.height).coerceAtLeast(0))
        runCatching { wm.updateViewLayout(v, params) }
    }

    @Composable
    private fun Content() {
        val open by panelOpen
        Column(horizontalAlignment = Alignment.End) {
            Image(
                painter = painterResource(R.drawable.shivangi_head),
                contentDescription = stringResource(R.string.bubble_cd),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Blush)
                    .border(3.dp, Plum, CircleShape)
                    .pointerInput(Unit) { detectDragGestures { ch, d -> ch.consume(); moveBy(d.x, d.y) } }
                    .pointerInput(Unit) {
                        detectTapGestures(onTap = {
                            if (panelOpen.value) { panelOpen.value = false; Assistant.stop() }
                            else { openPanel(); Assistant.startVoiceTurn() }
                        })
                    }
            )
            if (open) {
                Spacer(Modifier.size(8.dp))
                Panel()
            }
        }
    }

    @Composable
    private fun Panel() {
        val phase by Assistant.phase.collectAsState()
        val session by Assistant.session.collectAsState()
        val partial by Listener.partial.collectAsState()
        val call by Assistant.call.collectAsState()
        Surface(shape = RoundedCornerShape(22.dp), color = Color.White, shadowElevation = 8.dp, modifier = Modifier.width(290.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(when (phase) {
                            Phase.LISTENING -> R.string.st_listening
                            Phase.THINKING -> R.string.st_thinking
                            Phase.SPEAKING -> R.string.st_speaking
                            Phase.IDLE -> R.string.st_ready
                        }),
                        color = Plum, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { panelOpen.value = false; Assistant.stop() }) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), tint = Ink)
                    }
                }
                val lastUser = session.lastOrNull { it.fromUser }?.text
                val lastHer = session.lastOrNull { !it.fromUser }?.text
                val userLine = if (phase == Phase.LISTENING) partial else lastUser
                if (!userLine.isNullOrBlank()) Text("“$userLine”", color = Ink, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                if (!lastHer.isNullOrBlank() && phase != Phase.LISTENING)
                    Text(lastHer, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 8, overflow = TextOverflow.Ellipsis)
                call?.let { c ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.calling_in, c.name, c.secondsLeft), color = Ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { Assistant.cancelCall() }) { Text(stringResource(R.string.cancel)) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { Assistant.startVoiceTurn() }, colors = ButtonDefaults.buttonColors(containerColor = Plum)) {
                        Icon(Icons.Default.Mic, null); Spacer(Modifier.size(6.dp)); Text(stringResource(R.string.talk))
                    }
                    OutlinedButton(onClick = { Assistant.requestScreen(service.getString(R.string.screen_default_q)) }) {
                        Icon(Icons.Default.ScreenshotMonitor, null, tint = Plum); Spacer(Modifier.size(6.dp))
                        Text(stringResource(R.string.screen_short), color = Plum)
                    }
                }
            }
        }
    }
}
