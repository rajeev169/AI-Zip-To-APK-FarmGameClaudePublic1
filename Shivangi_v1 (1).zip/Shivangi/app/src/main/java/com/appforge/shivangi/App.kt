package com.appforge.shivangi

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.appforge.shivangi.brain.Assistant
import com.appforge.shivangi.data.Prefs

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_LISTEN, getString(R.string.ch_listening), NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_REMIND, getString(R.string.ch_reminders), NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_WAKE, getString(R.string.ch_wake), NotificationManager.IMPORTANCE_HIGH)
        )
        Prefs.init(this)
        Assistant.init(this)
    }

    companion object {
        const val CH_LISTEN = "listening"
        const val CH_REMIND = "reminders"
        const val CH_WAKE = "wake"
    }
}
