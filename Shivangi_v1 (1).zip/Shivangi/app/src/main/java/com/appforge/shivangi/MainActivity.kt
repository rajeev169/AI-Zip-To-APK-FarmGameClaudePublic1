package com.appforge.shivangi

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.appforge.shivangi.brain.AppPerm
import com.appforge.shivangi.brain.Assistant
import com.appforge.shivangi.brain.AssistantEvent
import com.appforge.shivangi.data.Prefs
import com.appforge.shivangi.service.AppState
import com.appforge.shivangi.service.AssistantService
import com.appforge.shivangi.service.CaptureActivity
import com.appforge.shivangi.ui.AboutScreen
import com.appforge.shivangi.ui.HelpScreen
import com.appforge.shivangi.ui.HistoryScreen
import com.appforge.shivangi.ui.HomeScreen
import com.appforge.shivangi.ui.Host
import com.appforge.shivangi.ui.KeyScreen
import com.appforge.shivangi.ui.LanguageScreen
import com.appforge.shivangi.ui.LocalHost
import com.appforge.shivangi.ui.PermissionsScreen
import com.appforge.shivangi.ui.RemindersScreen
import com.appforge.shivangi.ui.SettingsScreen
import com.appforge.shivangi.ui.SetupPermsScreen
import com.appforge.shivangi.ui.ShivangiTheme
import com.appforge.shivangi.ui.SignInScreen
import com.appforge.shivangi.ui.VoiceScreen
import com.appforge.shivangi.ui.resumeTick
import kotlinx.coroutines.launch
import java.io.File

object BuildConfigInfo {
    fun version(c: Context): String = runCatching { c.packageManager.getPackageInfo(c.packageName, 0).versionName }.getOrNull() ?: "1.0"
}

class MainActivity : ComponentActivity(), Host {
    companion object {
        const val EXTRA_LISTEN = "listen"
        const val EXTRA_CAMERA = "camera"
        const val EXTRA_PERM = "perm"
        const val EXTRA_RETRY = "retry"
        const val EXTRA_FROM_BOOT = "boot"
    }

    private var permCallback: ((Boolean) -> Unit)? = null
    private var pendingSpecial: AppPerm? = null
    private var photoQuestion = ""
    private var photoUri: Uri? = null
    private val pendingIntent = mutableStateOf<Intent?>(null)

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val ok = res.values.all { it }
        permCallback?.invoke(ok); permCallback = null
        Prefs.changes.value++
        if (ok) AssistantService.refresh(this)
    }
    private val folderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            Prefs.docFolders = Prefs.docFolders + uri.toString()
            permCallback?.invoke(true); permCallback = null
        }
    }
    private val photoLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = photoUri
        if (ok && u != null) {
            val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 }) }
            if (bmp != null) Assistant.askWithImage(photoQuestion.ifBlank { getString(R.string.camera_default_q) }, bmp)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        pendingIntent.value = intent

        lifecycleScope.launch {
            Assistant.events.collect { e ->
                if (!AppState.mainVisible) return@collect
                when (e) {
                    is AssistantEvent.AskPermission -> requestPerm(e.perm) { if (it) Assistant.retry(e.retryText) }
                    is AssistantEvent.OpenCamera -> takePhoto(e.question)
                    is AssistantEvent.CaptureScreen -> if (!AppState.serviceRunning.value) {
                        startActivity(Intent(this@MainActivity, CaptureActivity::class.java).putExtra(AssistantService.EXTRA_QUESTION, e.question))
                    }
                }
            }
        }

        setContent {
            ShivangiTheme {
                CompositionLocalProvider(LocalHost provides this) {
                    val nav = rememberNavController()
                    val start = when {
                        !Prefs.signedIn.value -> "signin"
                        Prefs.geminiKey.isBlank() -> "key"
                        !Prefs.setupDone -> "voice"
                        else -> "home"
                    }
                    NavHost(nav, startDestination = start) {
                        composable("signin") { SignInScreen { nav.go(if (Prefs.geminiKey.isBlank()) "key" else if (!Prefs.setupDone) "voice" else "home", clear = true) } }
                        composable("key") { KeyScreen(step = 1) { nav.go("voice", clear = true) } }
                        composable("voice") { VoiceScreen(step = 2) { nav.go("perms", clear = true) } }
                        composable("perms") {
                            SetupPermsScreen {
                                if (Prefs.speechLang.isBlank()) Prefs.speechLang = com.appforge.shivangi.data.Languages.fromPhone()
                                Prefs.setupDone = true
                                AssistantService.refresh(this@MainActivity)
                                nav.go("home", clear = true)
                            }
                        }
                        composable("home") { HomeScreen { nav.navigate(it) } }
                        composable("history") { HistoryScreen { nav.popBackStack() } }
                        composable("reminders") { RemindersScreen { nav.popBackStack() } }
                        composable("permissions") { PermissionsScreen { nav.popBackStack() } }
                        composable("language") { LanguageScreen { nav.popBackStack() } }
                        composable("help") { HelpScreen { nav.popBackStack() } }
                        composable("about") { AboutScreen { nav.popBackStack() } }
                        composable("settings") {
                            SettingsScreen(onBack = { nav.popBackStack() }, go = { nav.navigate(it) },
                                onSignedOut = { nav.go("signin", clear = true) })
                        }
                        composable("teach") { VoiceScreen(step = null) { nav.popBackStack(); AssistantService.refresh(this@MainActivity) } }
                        composable("key_edit") { KeyScreen(step = null) { nav.popBackStack() } }
                    }
                    // Wake word / assistant button / notification extras
                    LaunchedEffect(pendingIntent.value) {
                        val i = pendingIntent.value ?: return@LaunchedEffect
                        pendingIntent.value = null
                        if (!Prefs.setupDone) return@LaunchedEffect
                        if (i.getBooleanExtra(EXTRA_FROM_BOOT, false)) AssistantService.refresh(this@MainActivity)
                        i.getStringExtra(EXTRA_CAMERA)?.let { takePhoto(it) }
                        i.getStringExtra(EXTRA_PERM)?.let { name ->
                            val retry = i.getStringExtra(EXTRA_RETRY) ?: ""
                            runCatching { AppPerm.valueOf(name) }.getOrNull()?.let { p -> requestPerm(p) { if (it && retry.isNotBlank()) Assistant.retry(retry) } }
                        }
                        if (i.getBooleanExtra(EXTRA_LISTEN, false) || i.action == Intent.ACTION_ASSIST) Assistant.startVoiceTurn()
                    }
                }
            }
        }
    }

    private fun NavHostController.go(route: String, clear: Boolean = false) {
        navigate(route) { if (clear) popUpTo(0) { inclusive = true } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pendingIntent.value = intent
    }

    override fun onResume() {
        super.onResume()
        AppState.mainVisible = true
        resumeTick.intValue++
        pendingSpecial?.let { p -> pendingSpecial = null; permCallback?.invoke(p.granted(this)); permCallback = null; Prefs.changes.value++ }
        if (Prefs.setupDone) AssistantService.refresh(this)
    }

    override fun onPause() {
        AppState.mainVisible = false
        super.onPause()
    }

    // ---------------- Host ----------------

    override fun requestPerm(perm: AppPerm, onDone: (Boolean) -> Unit) {
        if (perm.granted(this)) { onDone(true); return }
        permCallback = onDone
        when {
            perm == AppPerm.DOCUMENTS -> pickFolder()
            perm.isSpecial -> {
                pendingSpecial = perm
                perm.settingsIntent(this)?.let { runCatching { startActivity(it) }.onFailure { pendingSpecial = null; onDone(false) } }
            }
            else -> permLauncher.launch(perm.runtime.toTypedArray())
        }
    }

    override fun pickFolder() { runCatching { folderLauncher.launch(null) } }

    override fun openUrl(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    override fun takePhoto(question: String) {
        if (!AppPerm.CAMERA.granted(this)) { requestPerm(AppPerm.CAMERA) { if (it) takePhoto(question) }; return }
        photoQuestion = question
        val dir = File(cacheDir, "camera").apply { mkdirs() }
        val f = File(dir, "look.jpg")
        photoUri = FileProvider.getUriForFile(this, "$packageName.files", f)
        runCatching { photoLauncher.launch(photoUri!!) }
    }

    override fun share(text: String) {
        runCatching { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null)) }
    }
}
