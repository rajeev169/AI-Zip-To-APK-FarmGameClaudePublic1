package com.appforge.shivangi.assist

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import com.appforge.shivangi.MainActivity

/** Lets the user pick Shivangi as the phone's default digital assistant. */
class ShivangiInteractionService : VoiceInteractionService()

class ShivangiSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = ShivangiSession(this)
}

/** Long-press power (or the assistant gesture): open Shivangi already listening. */
class ShivangiSession(context: Context) : VoiceInteractionSession(context) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        startAssistantActivity(
            Intent(context, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_LISTEN, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
        hide()
    }
}

/**
 * Android requires an assistant to name a recognition service, and makes it the phone's
 * "voice typing" service. So this passes every request on to Google's recogniser,
 * keeping voice typing in other apps working normally.
 */
class ShivangiRecognitionService : RecognitionService() {
    private var sr: SpeechRecognizer? = null

    private fun google(): ComponentName? = packageManager
        .queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
        .map { ComponentName(it.serviceInfo.packageName, it.serviceInfo.name) }
        .filter { it.packageName != packageName }
        .let { l -> l.firstOrNull { it.packageName == "com.google.android.googlequicksearchbox" } ?: l.firstOrNull() }

    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        val cb = listener ?: return
        val comp = google() ?: run { runCatching { cb.error(SpeechRecognizer.ERROR_CLIENT) }; return }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this, comp).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { runCatching { cb.readyForSpeech(p ?: Bundle()) } }
                override fun onBeginningOfSpeech() { runCatching { cb.beginningOfSpeech() } }
                override fun onRmsChanged(rms: Float) { runCatching { cb.rmsChanged(rms) } }
                override fun onBufferReceived(b: ByteArray?) { runCatching { cb.bufferReceived(b ?: ByteArray(0)) } }
                override fun onEndOfSpeech() { runCatching { cb.endOfSpeech() } }
                override fun onError(e: Int) { runCatching { cb.error(e) } }
                override fun onResults(r: Bundle?) { runCatching { cb.results(r ?: Bundle()) } }
                override fun onPartialResults(r: Bundle?) { runCatching { cb.partialResults(r ?: Bundle()) } }
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(recognizerIntent ?: Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH))
        }
    }

    override fun onCancel(listener: Callback?) { sr?.cancel() }
    override fun onStopListening(listener: Callback?) { sr?.stopListening() }
    override fun onDestroy() { sr?.destroy(); sr = null; super.onDestroy() }
}
