package com.appforge.shivangi.brain

import com.appforge.shivangi.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiException(val code: Int, message: String) : Exception(message) {
    val badKey get() = code == 400 && (message ?: "").contains("API key", true) || code == 401 || code == 403
    val quota get() = code == 429
}

/** Talks to Google Gemini over its REST API with the user's own key. */
object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private const val FALLBACK_MODEL = "gemini-2.5-flash"

    /** Checks the key and picks the newest "Flash" model the key can use. Returns the model name. */
    suspend fun checkKey(key: String): String = withContext(Dispatchers.IO) {
        val json = request("GET", "$BASE/models?pageSize=200", key, null)
        val models = json.optJSONArray("models") ?: JSONArray()
        var best: String? = null
        var bestScore = -1.0
        for (i in 0 until models.length()) {
            val m = models.getJSONObject(i)
            val name = m.getString("name").removePrefix("models/")
            val methods = m.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (!methods.contains("generateContent")) continue
            if (!name.startsWith("gemini-") || !name.contains("flash")) continue
            if (listOf("lite", "image", "tts", "live", "audio", "exp", "thinking", "8b").any { name.contains(it) }) continue
            val version = Regex("gemini-(\\d+(?:\\.\\d+)?)").find(name)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
            // Prefer stable over preview of the same version
            val score = version * 10 + if (name.contains("preview")) 0.0 else 1.0
            if (score > bestScore) { bestScore = score; best = name }
        }
        best ?: FALLBACK_MODEL
    }

    /**
     * One call to the model. [contents] is the whole conversation (Gemini format).
     * Returns the model's content object (role "model" with parts).
     */
    suspend fun generate(
        system: String,
        contents: JSONArray,
        tools: JSONArray?,
    ): JSONObject = withContext(Dispatchers.IO) {
        val key = Prefs.geminiKey
        if (key.isBlank()) throw GeminiException(401, "No Gemini key")
        var model = Prefs.geminiModel.ifBlank { FALLBACK_MODEL }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 1024))
        if (tools != null) body.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", tools)))
        val json = try {
            request("POST", "$BASE/models/$model:generateContent", key, body)
        } catch (e: GeminiException) {
            // The saved model may have been retired: pick again once
            if (e.code == 404) {
                model = checkKey(key); Prefs.geminiModel = model
                request("POST", "$BASE/models/$model:generateContent", key, body)
            } else throw e
        }
        val cand = json.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw GeminiException(500, json.optJSONObject("promptFeedback")?.optString("blockReason") ?: "No answer")
        cand.optJSONObject("content") ?: JSONObject().put("role", "model").put("parts", JSONArray())
    }

    private fun request(method: String, url: String, key: String, body: JSONObject?): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.setRequestProperty("x-goog-api-key", key)
        c.setRequestProperty("Content-Type", "application/json")
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrDefault(text.take(200))
            throw GeminiException(code, msg)
        }
        return JSONObject(text)
    }
}
