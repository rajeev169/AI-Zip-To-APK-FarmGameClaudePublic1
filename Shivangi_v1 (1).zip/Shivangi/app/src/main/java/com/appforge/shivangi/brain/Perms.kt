package com.appforge.shivangi.brain

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import com.appforge.shivangi.R
import com.appforge.shivangi.data.Prefs
import com.appforge.shivangi.service.NotifListener

enum class PermGroup { TALK, PHONE, MEDIA }

/**
 * The 16 permissions. Runtime ones are asked with Android's dialog; "special" ones open
 * the matching Android settings screen.
 */
enum class AppPerm(
    val group: PermGroup,
    @StringRes val title: Int,
    @StringRes val desc: Int,
    val runtime: List<String> = emptyList(),
) {
    MIC(PermGroup.TALK, R.string.perm_mic, R.string.perm_mic_d,
        buildList { add(Manifest.permission.RECORD_AUDIO); if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS) }),
    ASSISTANT(PermGroup.TALK, R.string.perm_assistant, R.string.perm_assistant_d),
    OVERLAY(PermGroup.TALK, R.string.perm_overlay, R.string.perm_overlay_d),
    BATTERY(PermGroup.TALK, R.string.perm_battery, R.string.perm_battery_d),

    CONTACTS(PermGroup.PHONE, R.string.perm_contacts, R.string.perm_contacts_d, listOf(Manifest.permission.READ_CONTACTS)),
    PHONE(PermGroup.PHONE, R.string.perm_phone, R.string.perm_phone_d, listOf(Manifest.permission.CALL_PHONE)),
    NOTIF_ACCESS(PermGroup.PHONE, R.string.perm_notif, R.string.perm_notif_d),
    CALENDAR(PermGroup.PHONE, R.string.perm_calendar, R.string.perm_calendar_d,
        listOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)),
    ALARMS(PermGroup.PHONE, R.string.perm_alarms, R.string.perm_alarms_d),
    LOCATION(PermGroup.PHONE, R.string.perm_location, R.string.perm_location_d, listOf(Manifest.permission.ACCESS_COARSE_LOCATION)),
    SYSTEM_SETTINGS(PermGroup.PHONE, R.string.perm_system, R.string.perm_system_d),
    DND(PermGroup.PHONE, R.string.perm_dnd, R.string.perm_dnd_d),

    MUSIC(PermGroup.MEDIA, R.string.perm_music, R.string.perm_music_d,
        listOf(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)),
    PHOTOS(PermGroup.MEDIA, R.string.perm_photos, R.string.perm_photos_d,
        if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)),
    DOCUMENTS(PermGroup.MEDIA, R.string.perm_docs, R.string.perm_docs_d),
    CAMERA(PermGroup.MEDIA, R.string.perm_camera, R.string.perm_camera_d, listOf(Manifest.permission.CAMERA));

    val isSpecial get() = runtime.isEmpty()

    fun granted(c: Context): Boolean = when (this) {
        ASSISTANT -> isDefaultAssistant(c)
        OVERLAY -> Settings.canDrawOverlays(c)
        BATTERY -> c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
        NOTIF_ACCESS -> notificationAccess(c)
        ALARMS -> Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
        SYSTEM_SETTINGS -> Settings.System.canWrite(c)
        DND -> c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
        DOCUMENTS -> Prefs.docFolders.isNotEmpty()
        else -> runtime.all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }
    }

    /** Android settings screen for the special ones */
    fun settingsIntent(c: Context): Intent? {
        val pkg = Uri.parse("package:${c.packageName}")
        return when (this) {
            ASSISTANT -> Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)
            OVERLAY -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)
            BATTERY -> Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            NOTIF_ACCESS -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            ALARMS -> if (Build.VERSION.SDK_INT >= 31) Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg) else null
            SYSTEM_SETTINGS -> Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg)
            DND -> Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            else -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
        }?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    companion object {
        val setupFour = listOf(MIC, ASSISTANT, OVERLAY, BATTERY)

        fun isDefaultAssistant(c: Context): Boolean {
            val rm = c.getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) return rm.isRoleHeld(RoleManager.ROLE_ASSISTANT)
            val cur = Settings.Secure.getString(c.contentResolver, "voice_interaction_service") ?: return false
            return cur.startsWith(c.packageName)
        }

        fun notificationAccess(c: Context): Boolean {
            val flat = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: return false
            val me = ComponentName(c, NotifListener::class.java).flattenToString()
            return flat.split(':').any { it == me }
        }
    }
}

/** Thrown by a tool when it needs a permission the user hasn't given yet. */
class NeedPermission(val perm: AppPerm) : Exception(perm.name)
