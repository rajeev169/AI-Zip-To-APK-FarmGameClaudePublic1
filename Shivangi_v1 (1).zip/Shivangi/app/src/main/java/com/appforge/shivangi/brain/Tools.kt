package com.appforge.shivangi.brain

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.documentfile.provider.DocumentFile
import com.appforge.shivangi.data.Prefs
import com.appforge.shivangi.data.Reminder
import com.appforge.shivangi.data.Store
import com.appforge.shivangi.service.NotifListener
import com.appforge.shivangi.service.ReminderReceiver
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** What a tool sends back to the model. If [say] is set, she says it and the turn ends there. */
data class ToolResult(val response: JSONObject, val say: String? = null)

/** Everything she can do on the phone, described to Gemini as functions. */
object Tools {

    // ---------- Declarations (what Gemini sees) ----------
    private fun obj(vararg props: Pair<String, JSONObject>, required: List<String> = emptyList()) = JSONObject()
        .put("type", "OBJECT")
        .put("properties", JSONObject().apply { props.forEach { put(it.first, it.second) } })
        .apply { if (required.isNotEmpty()) put("required", JSONArray(required)) }
    private fun str(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun int(d: String) = JSONObject().put("type", "INTEGER").put("description", d)
    private fun bool(d: String) = JSONObject().put("type", "BOOLEAN").put("description", d)
    private fun fn(name: String, desc: String, params: JSONObject? = null) =
        JSONObject().put("name", name).put("description", desc).apply { if (params != null) put("parameters", params) }

    val declarations: JSONArray = JSONArray().apply {
        put(fn("set_alarm", "Set an alarm in the phone's clock app.",
            obj("hour" to int("0-23"), "minute" to int("0-59"), "label" to str("optional label"), required = listOf("hour", "minute"))))
        put(fn("set_timer", "Start a countdown timer.",
            obj("seconds" to int("length in seconds"), "label" to str("optional"), required = listOf("seconds"))))
        put(fn("set_reminder", "Remind the user later with a notification. Give either minutes_from_now or at (local time 'YYYY-MM-DD HH:MM').",
            obj("text" to str("what to remind"), "minutes_from_now" to int("minutes from now"), "at" to str("local date time 'YYYY-MM-DD HH:MM'"), required = listOf("text"))))
        put(fn("open_app", "Open an installed app by its name, e.g. YouTube, WhatsApp, Camera.",
            obj("name" to str("app name"), required = listOf("name"))))
        put(fn("call_contact", "Phone call to a saved contact name or a phone number.",
            obj("who" to str("contact name or number"), required = listOf("who"))))
        put(fn("send_message", "Prepare a WhatsApp or SMS message; the user taps send.",
            obj("who" to str("contact name or number"), "text" to str("message text"), "app" to str("'whatsapp' or 'sms'"), required = listOf("who", "text"))))
        put(fn("torch", "Turn the torch (flashlight) on or off.", obj("on" to bool("true = on"), required = listOf("on"))))
        put(fn("set_volume", "Set volume 0-100.", obj("level" to int("0-100"), "stream" to str("'media', 'ring' or 'alarm'"), required = listOf("level"))))
        put(fn("set_brightness", "Set screen brightness 0-100.", obj("level" to int("0-100"), required = listOf("level"))))
        put(fn("set_screen_timeout", "Set how long before the screen turns off.", obj("seconds" to int("15-1800"), required = listOf("seconds"))))
        put(fn("do_not_disturb", "Silent / meeting mode on or off.", obj("on" to bool("true = silent"), required = listOf("on"))))
        put(fn("wifi_bluetooth", "Open the quick panel to switch Wi-Fi, mobile data or Bluetooth.", obj("which" to str("'wifi', 'data' or 'bluetooth'"), required = listOf("which"))))
        put(fn("play_music", "Play a song saved on the phone by title, artist or album.", obj("query" to str("song, artist or album"), required = listOf("query"))))
        put(fn("media_control", "Control whatever music or video is playing (any app).", obj("action" to str("'play', 'pause', 'next' or 'previous'"), required = listOf("action"))))
        put(fn("read_notifications", "Read the user's recent notifications/messages.", obj("app" to str("optional app name filter, e.g. WhatsApp"))))
        put(fn("calendar_events", "List calendar events for a day.", obj("day" to str("'today', 'tomorrow' or 'YYYY-MM-DD'"), required = listOf("day"))))
        put(fn("add_calendar_event", "Add an event to the calendar.",
            obj("title" to str("event title"), "start" to str("local 'YYYY-MM-DD HH:MM'"), "minutes" to int("duration, default 60"), required = listOf("title", "start"))))
        put(fn("get_weather", "Current weather and today's forecast. Without place, uses the phone's location.", obj("place" to str("optional city name"))))
        put(fn("find_nearby", "Find nearby places (ATM, petrol pump, hospital) in Google Maps.", obj("what" to str("what to find"), required = listOf("what"))))
        put(fn("show_photos", "Open the user's photos or videos from a time.", obj("when" to str("'today', 'yesterday' or 'recent'"), "kind" to str("'photo' or 'video'"))))
        put(fn("share_last_screenshot", "Share the latest screenshot to an app (default WhatsApp).", obj("app" to str("optional app name"))))
        put(fn("find_document", "Find and open a document (PDF, Word…) in the folders the user allowed.", obj("name" to str("words in the file name"), required = listOf("name"))))
        put(fn("look_through_camera", "Use the camera to see something and answer about it (what is this, read this text, scan QR).",
            obj("question" to str("what the user wants to know"), required = listOf("question"))))
        put(fn("look_at_screen", "Take a screenshot of what is on the screen now and answer about it (explain, summarise, translate).",
            obj("question" to str("what the user wants to know"), required = listOf("question"))))
    }

    // ---------- Execution ----------
    fun ok(msg: String = "done") = ToolResult(JSONObject().put("result", msg))
    private fun fail(msg: String) = ToolResult(JSONObject().put("error", msg))
    private fun need(c: Context, p: AppPerm) { if (!p.granted(c)) throw NeedPermission(p) }

    @SuppressLint("MissingPermission")
    suspend fun run(c: Context, name: String, a: JSONObject): ToolResult = when (name) {
        "set_alarm" -> start(c, Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
            .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Shivangi"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        "set_timer" -> start(c, Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds"))
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Shivangi"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        "set_reminder" -> reminder(c, a)
        "open_app" -> openApp(c, a.optString("name"))
        "call_contact" -> call(c, a.optString("who"))
        "send_message" -> message(c, a.optString("who"), a.optString("text"), a.optString("app", "whatsapp"))
        "torch" -> torch(c, a.optBoolean("on"))
        "set_volume" -> volume(c, a.optInt("level"), a.optString("stream", "media"))
        "set_brightness" -> {
            need(c, AppPerm.SYSTEM_SETTINGS)
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (a.optInt("level").coerceIn(1, 100) * 255 / 100))
            ok()
        }
        "set_screen_timeout" -> {
            need(c, AppPerm.SYSTEM_SETTINGS)
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, a.optInt("seconds").coerceIn(15, 1800) * 1000)
            ok()
        }
        "do_not_disturb" -> {
            need(c, AppPerm.DND)
            c.getSystemService(NotificationManager::class.java).setInterruptionFilter(
                if (a.optBoolean("on")) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
            ok()
        }
        "wifi_bluetooth" -> when (a.optString("which")) {
            "bluetooth" -> start(c, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            "data" -> start(c, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            else -> start(c, Intent(Settings.Panel.ACTION_WIFI))
        }
        "play_music" -> playMusic(c, a.optString("query"))
        "media_control" -> mediaKey(c, a.optString("action"))
        "read_notifications" -> {
            need(c, AppPerm.NOTIF_ACCESS)
            val filter = a.optString("app", "").lowercase()
            val list = NotifListener.recent().filter { filter.isBlank() || it.app.lowercase().contains(filter) }.take(12)
            ToolResult(JSONObject().put("notifications", JSONArray(list.map {
                JSONObject().put("app", it.app).put("title", it.title).put("text", it.text).put("minutes_ago", (System.currentTimeMillis() - it.time) / 60000)
            })))
        }
        "calendar_events" -> events(c, a.optString("day", "today"))
        "add_calendar_event" -> addEvent(c, a)
        "get_weather" -> weather(c, a.optString("place", ""))
        "find_nearby" -> start(c, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.optString("what") + " near me"))))
        "show_photos" -> photos(c, a.optString("when", "recent"), a.optString("kind", "photo"))
        "share_last_screenshot" -> shareScreenshot(c, a.optString("app", "whatsapp"))
        "find_document" -> document(c, a.optString("name"))
        "look_through_camera" -> { need(c, AppPerm.CAMERA); Assistant.requestCamera(a.optString("question")); ToolResult(JSONObject().put("result", "camera opened"), say = "") }
        "look_at_screen" -> { Assistant.requestScreen(a.optString("question")); ToolResult(JSONObject().put("result", "taking screenshot"), say = "") }
        else -> fail("unknown function $name")
    }

    private fun start(c: Context, i: Intent): ToolResult = try {
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); ok()
    } catch (e: Exception) { fail("not available on this phone") }

    private fun openApp(c: Context, name: String): ToolResult {
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val n = name.lowercase().trim()
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: apps.firstOrNull { n.contains(it.loadLabel(pm).toString().lowercase()) }
            ?: return fail("no app called $name")
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return fail("cannot open")
        return start(c, i)
    }

    /** Finds a phone number for a name in contacts (or returns the digits if a number was said). */
    fun findNumber(c: Context, who: String): Pair<String, String>? {
        val digits = who.filter { it.isDigit() || it == '+' }
        if (digits.length >= 6) return who to digits
        need(c, AppPerm.CONTACTS)
        val cur = c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%${who.trim()}%"), null
        ) ?: return null
        cur.use { if (it.moveToFirst()) return it.getString(0) to it.getString(1) }
        return null
    }

    private fun call(c: Context, who: String): ToolResult {
        val (name, number) = findNumber(c, who) ?: return fail("no contact named $who")
        need(c, AppPerm.PHONE)
        Assistant.requestCall(name, number)
        return ToolResult(JSONObject().put("result", "calling $name"), say = Assistant.callingLine(name))
    }

    private fun message(c: Context, who: String, text: String, app: String): ToolResult {
        val (_, number) = findNumber(c, who) ?: return fail("no contact named $who")
        val clean = number.filter { it.isDigit() || it == '+' }
        return if (app.contains("sms", true)) {
            start(c, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$clean")).putExtra("sms_body", text))
        } else {
            val intl = if (clean.startsWith("+")) clean.drop(1) else if (clean.length == 10) "91$clean" else clean
            start(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$intl?text=" + URLEncoder.encode(text, "UTF-8"))))
        }
    }

    private fun torch(c: Context, on: Boolean): ToolResult {
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return fail("no torch")
        cm.setTorchMode(id, on); return ok()
    }

    private fun volume(c: Context, level: Int, stream: String): ToolResult {
        val am = c.getSystemService(AudioManager::class.java)
        val s = when (stream) { "ring" -> AudioManager.STREAM_RING; "alarm" -> AudioManager.STREAM_ALARM; else -> AudioManager.STREAM_MUSIC }
        return try {
            am.setStreamVolume(s, am.getStreamMaxVolume(s) * level.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI); ok()
        } catch (e: SecurityException) { throw NeedPermission(AppPerm.DND) }
    }

    private fun mediaKey(c: Context, action: String): ToolResult {
        val code = when (action) {
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE; "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; else -> KeyEvent.KEYCODE_MEDIA_PLAY
        }
        val am = c.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ok()
    }

    private fun playMusic(c: Context, q: String): ToolResult {
        need(c, AppPerm.MUSIC)
        val sel = "${MediaStore.Audio.Media.IS_MUSIC}!=0 AND (${MediaStore.Audio.Media.TITLE} LIKE ? OR ${MediaStore.Audio.Media.ARTIST} LIKE ? OR ${MediaStore.Audio.Media.ALBUM} LIKE ?)"
        val like = "%${q.trim()}%"
        c.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE), sel, arrayOf(like, like, like), null)?.use {
            if (it.moveToFirst()) {
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it.getLong(0))
                val r = start(c, Intent(Intent.ACTION_VIEW).setDataAndType(uri, "audio/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                return if (r.response.has("error")) r else ok("playing ${it.getString(1)}")
            }
        }
        return fail("song not found on the phone")
    }

    private fun reminder(c: Context, a: JSONObject): ToolResult {
        val text = a.optString("text")
        val time = when {
            a.has("minutes_from_now") -> System.currentTimeMillis() + a.optInt("minutes_from_now") * 60_000L
            a.optString("at").isNotBlank() -> parseLocal(a.optString("at")) ?: return fail("could not read the time")
            else -> return fail("when?")
        }
        need(c, AppPerm.ALARMS)
        val id = (time / 1000 % Int.MAX_VALUE).toInt()
        val pi = PendingIntent.getBroadcast(c, id,
            Intent(c, ReminderReceiver::class.java).putExtra("id", id).putExtra("text", text),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = c.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) throw NeedPermission(AppPerm.ALARMS)
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
        Store.addReminder(Reminder(id, time, text))
        return ok("reminder set for " + SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(time))
    }

    fun parseLocal(s: String): Long? = listOf("yyyy-MM-dd HH:mm", "yyyy-MM-dd'T'HH:mm", "yyyy-MM-dd")
        .firstNotNullOfOrNull { f -> runCatching { SimpleDateFormat(f, Locale.US).parse(s.trim())?.time }.getOrNull() }

    private fun dayRange(day: String): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        when (day) {
            "today" -> {}
            "tomorrow" -> cal.add(Calendar.DAY_OF_YEAR, 1)
            else -> parseLocal(day)?.let { cal.timeInMillis = it }
        }
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        return cal.timeInMillis to cal.timeInMillis + 86_400_000L
    }

    private fun events(c: Context, day: String): ToolResult {
        need(c, AppPerm.CALENDAR)
        val (s, e) = dayRange(day)
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also {
            ContentUris.appendId(it, s); ContentUris.appendId(it, e)
        }.build()
        val out = JSONArray()
        val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        c.contentResolver.query(uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
            null, null, CalendarContract.Instances.BEGIN)?.use {
            while (it.moveToNext()) out.put(JSONObject().put("title", it.getString(0)).put("time", if (it.getInt(2) == 1) "all day" else fmt.format(it.getLong(1))))
        }
        return ToolResult(JSONObject().put("events", out))
    }

    private fun addEvent(c: Context, a: JSONObject): ToolResult {
        need(c, AppPerm.CALENDAR)
        val start = parseLocal(a.optString("start")) ?: return fail("could not read the time")
        val calId = c.contentResolver.query(CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID), "${CalendarContract.Calendars.VISIBLE}=1 AND ${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL}>=500",
            null, "${CalendarContract.Calendars.IS_PRIMARY} DESC")?.use { if (it.moveToFirst()) it.getLong(0) else null }
            ?: return fail("no calendar account on this phone")
        val v = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, calId)
            put(CalendarContract.Events.TITLE, a.optString("title"))
            put(CalendarContract.Events.DTSTART, start)
            put(CalendarContract.Events.DTEND, start + a.optInt("minutes", 60) * 60_000L)
            put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
        }
        c.contentResolver.insert(CalendarContract.Events.CONTENT_URI, v) ?: return fail("could not add")
        return ok()
    }

    @SuppressLint("MissingPermission")
    private fun weather(c: Context, place: String): ToolResult {
        var lat: Double; var lon: Double; var label: String
        if (place.isNotBlank()) {
            val g = JSONObject(URL("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + URLEncoder.encode(place, "UTF-8")).readText())
            val r = g.optJSONArray("results")?.optJSONObject(0) ?: return fail("place not found")
            lat = r.getDouble("latitude"); lon = r.getDouble("longitude"); label = r.getString("name")
        } else {
            need(c, AppPerm.LOCATION)
            val lm = c.getSystemService(LocationManager::class.java)
            val loc = lm.getProviders(true).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
                ?: return fail("location not known yet; ask the user for the city")
            lat = loc.latitude; lon = loc.longitude; label = "your location"
        }
        val w = JSONObject(URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&forecast_days=1&timezone=auto").readText())
        return ToolResult(JSONObject().put("place", label).put("current", w.optJSONObject("current")).put("today", w.optJSONObject("daily"))
            .put("note", "weather_code is WMO code"))
    }

    private fun photos(c: Context, whenS: String, kind: String): ToolResult {
        need(c, AppPerm.PHOTOS)
        val video = kind.contains("video")
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val (s, e) = when (whenS) { "today" -> dayRange("today"); "yesterday" -> dayRange("today").let { it.first - 86_400_000L to it.first }; else -> 0L to Long.MAX_VALUE }
        c.contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID),
            "${MediaStore.MediaColumns.DATE_ADDED}>=? AND ${MediaStore.MediaColumns.DATE_ADDED}<?", arrayOf((s / 1000).toString(), (e / 1000).toString()),
            "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use {
            if (!it.moveToFirst()) return fail("no ${if (video) "videos" else "photos"} found for $whenS")
            val n = it.count
            val uri = ContentUris.withAppendedId(base, it.getLong(0))
            start(c, Intent(Intent.ACTION_VIEW).setDataAndType(uri, if (video) "video/*" else "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            return ok("opened the latest of $n")
        }
        return fail("could not read photos")
    }

    private fun shareScreenshot(c: Context, app: String): ToolResult {
        need(c, AppPerm.PHOTOS)
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        c.contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID),
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("%Screenshot%"), "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use {
            if (!it.moveToFirst()) return fail("no screenshots")
            val uri = ContentUris.withAppendedId(base, it.getLong(0))
            val send = Intent(Intent.ACTION_SEND).setType("image/*").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (app.contains("whats", true)) send.setPackage("com.whatsapp")
            return start(c, if (send.`package` != null) send else Intent.createChooser(send, null))
        }
        return fail("no screenshots")
    }

    private fun document(c: Context, name: String): ToolResult {
        need(c, AppPerm.DOCUMENTS)
        val words = name.lowercase().split(' ').filter { it.isNotBlank() }
        var found: DocumentFile? = null
        fun walk(d: DocumentFile, depth: Int) {
            if (found != null || depth > 4) return
            for (f in d.listFiles()) {
                if (found != null) return
                if (f.isDirectory) walk(f, depth + 1)
                else if (words.all { f.name?.lowercase()?.contains(it) == true }) found = f
            }
        }
        Prefs.docFolders.forEach { t -> DocumentFile.fromTreeUri(c, Uri.parse(t))?.let { walk(it, 0) } }
        val f = found ?: return fail("no document matching '$name' in the chosen folders")
        val r = start(c, Intent(Intent.ACTION_VIEW).setDataAndType(f.uri, f.type ?: "*/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        return if (r.response.has("error")) r else ok("opened ${f.name}")
    }
}
