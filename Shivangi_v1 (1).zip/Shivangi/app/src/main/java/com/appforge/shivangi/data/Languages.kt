package com.appforge.shivangi.data

import java.util.Locale

/** A language she can listen and talk in. [tag] is used for speech recognition and the voice. */
data class SpeechLanguage(val code: String, val native: String, val english: String, val tag: String, val promptName: String)

object Languages {
    val all = listOf(
        SpeechLanguage("en", "English", "English", "en-IN", "English"),
        SpeechLanguage("hi", "हिन्दी", "Hindi", "hi-IN", "Hindi (Devanagari script)"),
        SpeechLanguage("hinglish", "Hinglish", "Hindi + English", "hi-IN", "Hinglish (Hindi mixed with English words, written in Latin letters)"),
        SpeechLanguage("bn", "বাংলা", "Bengali", "bn-IN", "Bengali"),
        SpeechLanguage("mr", "मराठी", "Marathi", "mr-IN", "Marathi"),
        SpeechLanguage("te", "తెలుగు", "Telugu", "te-IN", "Telugu"),
        SpeechLanguage("ta", "தமிழ்", "Tamil", "ta-IN", "Tamil"),
        SpeechLanguage("gu", "ગુજરાતી", "Gujarati", "gu-IN", "Gujarati"),
        SpeechLanguage("kn", "ಕನ್ನಡ", "Kannada", "kn-IN", "Kannada"),
        SpeechLanguage("ml", "മലയാളം", "Malayalam", "ml-IN", "Malayalam"),
        SpeechLanguage("pa", "ਪੰਜਾਬੀ", "Punjabi", "pa-IN", "Punjabi (Gurmukhi script)"),
        SpeechLanguage("ur", "اردو", "Urdu", "ur-IN", "Urdu"),
    )

    fun byCode(code: String) = all.firstOrNull { it.code == code } ?: all[0]

    /** First-time setup: start with the phone's language if we support it, otherwise English. */
    fun fromPhone(): String {
        val phone = Locale.getDefault().language
        return all.firstOrNull { it.code == phone }?.code ?: "en"
    }

    val current: SpeechLanguage get() = byCode(Prefs.speechLang.ifBlank { fromPhone() })
}
