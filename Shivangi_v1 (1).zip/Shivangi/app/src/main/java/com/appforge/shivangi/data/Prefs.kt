package com.appforge.shivangi.data

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** All saved settings. The Gemini key is encrypted with a key kept in the phone's secure keystore. */
object Prefs {
    private lateinit var sp: SharedPreferences

    /** Changes the UI listens to */
    val changes = MutableStateFlow(0)
    private val _signedIn = MutableStateFlow(false)
    val signedIn: StateFlow<Boolean> = _signedIn

    fun init(c: Context) {
        sp = c.getSharedPreferences("shivangi", Context.MODE_PRIVATE)
        _signedIn.value = userEmail.isNotBlank()
    }

    private fun bump() { changes.value++ }

    // ---- Account ----
    var userEmail: String
        get() = sp.getString("email", "") ?: ""
        set(v) { sp.edit().putString("email", v).apply(); _signedIn.value = v.isNotBlank(); bump() }
    var googleName: String
        get() = sp.getString("gname", "") ?: ""
        set(v) { sp.edit().putString("gname", v).apply(); bump() }
    /** "What should I call you?" — empty means use the Google first name */
    var nickname: String
        get() = sp.getString("nick", "") ?: ""
        set(v) { sp.edit().putString("nick", v.trim()).apply(); bump() }
    val callName: String get() = nickname.ifBlank { googleName.substringBefore(' ') }

    // ---- Brain ----
    var geminiKey: String
        get() = sp.getString("gk", null)?.let { runCatching { decrypt(it) }.getOrNull() } ?: ""
        set(v) { sp.edit().putString("gk", if (v.isBlank()) null else encrypt(v.trim())).apply(); bump() }
    var geminiModel: String
        get() = sp.getString("gmodel", "") ?: ""
        set(v) { sp.edit().putString("gmodel", v).apply() }

    // ---- Setup progress ----
    var voiceTaught: Boolean
        get() = sp.getBoolean("voice", false)
        set(v) { sp.edit().putBoolean("voice", v).apply(); bump() }
    var setupDone: Boolean
        get() = sp.getBoolean("setup", false)
        set(v) { sp.edit().putBoolean("setup", v).apply(); bump() }

    // ---- Language (her speaking and listening). Empty = not chosen yet ----
    var speechLang: String
        get() = sp.getString("lang", "") ?: ""
        set(v) { sp.edit().putString("lang", v).apply(); bump() }

    // ---- Settings ----
    var wakeOn: Boolean
        get() = sp.getBoolean("wake", true)
        set(v) { sp.edit().putBoolean("wake", v).apply(); bump() }
    /** 0..100, higher wakes more easily */
    var sensitivity: Int
        get() = sp.getInt("sens", 50)
        set(v) { sp.edit().putInt("sens", v).apply(); bump() }
    var bubbleOn: Boolean
        get() = sp.getBoolean("bubble", true)
        set(v) { sp.edit().putBoolean("bubble", v).apply(); bump() }
    /** 0.6..1.6 */
    var speechRate: Float
        get() = sp.getFloat("rate", 1.0f)
        set(v) { sp.edit().putFloat("rate", v).apply(); bump() }
    /** "system" | "light" | "dark" */
    var theme: String
        get() = sp.getString("theme", "system") ?: "system"
        set(v) { sp.edit().putString("theme", v).apply(); bump() }
    var confirmCalls: Boolean
        get() = sp.getBoolean("confirmCall", true)
        set(v) { sp.edit().putBoolean("confirmCall", v).apply(); bump() }
    var saveHistory: Boolean
        get() = sp.getBoolean("history", true)
        set(v) { sp.edit().putBoolean("history", v).apply(); bump() }

    /** Day (yyyyMMdd) when she last spoke the greeting aloud */
    var lastGreetDay: String
        get() = sp.getString("greet", "") ?: ""
        set(v) { sp.edit().putString("greet", v).apply() }

    /** Folders the user picked for "Documents" (tree URIs) */
    var docFolders: Set<String>
        get() = sp.getStringSet("folders", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("folders", v).apply(); bump() }

    fun signOut() {
        val keepLang = speechLang
        sp.edit().clear().apply()
        speechLang = keepLang
        _signedIn.value = false
        bump()
    }

    // ---- Encryption for the Gemini key ----
    private const val ALIAS = "shivangi_key"
    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, secretKey())
        val out = c.iv + c.doFinal(plain.toByteArray())
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    private fun decrypt(enc: String): String {
        val all = Base64.decode(enc, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        return String(c.doFinal(all.copyOfRange(12, all.size)))
    }
}
