package com.appforge.shivangi.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ChatMessage(val time: Long, val fromUser: Boolean, val text: String)
data class Reminder(val id: Int, val time: Long, val text: String)

/** Chat history and reminders, saved as small JSON files on the phone. */
object Store {
    private lateinit var dir: File
    private val _history = MutableStateFlow<List<ChatMessage>>(emptyList())
    val history: StateFlow<List<ChatMessage>> = _history
    private val _reminders = MutableStateFlow<List<Reminder>>(emptyList())
    val reminders: StateFlow<List<Reminder>> = _reminders

    fun init(c: Context) {
        dir = c.filesDir
        _history.value = readArray("history.json").map {
            ChatMessage(it.getLong("t"), it.getBoolean("u"), it.getString("x"))
        }
        _reminders.value = readArray("reminders.json").map {
            Reminder(it.getInt("id"), it.getLong("t"), it.getString("x"))
        }.filter { it.time > System.currentTimeMillis() - 86_400_000L }
    }

    fun addMessage(m: ChatMessage) {
        if (!Prefs.saveHistory) return
        _history.value = (_history.value + m).takeLast(1000)
        writeArray("history.json", _history.value.map { JSONObject().put("t", it.time).put("u", it.fromUser).put("x", it.text) })
    }

    fun clearHistory() {
        _history.value = emptyList()
        File(dir, "history.json").delete()
    }

    fun addReminder(r: Reminder) {
        _reminders.value = (_reminders.value + r).sortedBy { it.time }
        saveReminders()
    }

    fun removeReminder(id: Int) {
        _reminders.value = _reminders.value.filterNot { it.id == id }
        saveReminders()
    }

    private fun saveReminders() =
        writeArray("reminders.json", _reminders.value.map { JSONObject().put("id", it.id).put("t", it.time).put("x", it.text) })

    private fun readArray(name: String): List<JSONObject> {
        val f = File(dir, name)
        if (!f.exists()) return emptyList()
        return runCatching {
            val a = JSONArray(f.readText())
            (0 until a.length()).map { a.getJSONObject(it) }
        }.getOrDefault(emptyList())
    }

    private fun writeArray(name: String, items: List<JSONObject>) {
        val a = JSONArray(); items.forEach { a.put(it) }
        runCatching { File(dir, name).writeText(a.toString()) }
    }
}
