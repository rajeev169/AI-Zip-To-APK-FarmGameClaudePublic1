package com.appforge.shivangi.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import com.appforge.shivangi.App
import com.appforge.shivangi.MainActivity
import com.appforge.shivangi.R
import com.appforge.shivangi.brain.Assistant
import com.appforge.shivangi.brain.AssistantEvent
import com.appforge.shivangi.data.Prefs
import com.appforge.shivangi.wake.WakeEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.concurrent.thread

/** Shared flags between the screen and the service */
object AppState {
    @Volatile var mainVisible = false
    val serviceRunning = MutableStateFlow(false)
    val wakeActive = MutableStateFlow(false)
}

/**
 * Runs in the background: listens for "Shivangi", shows the floating bubble,
 * and takes a screenshot when she is asked "what's on my screen?".
 */
class AssistantService : LifecycleService(), SavedStateRegistryOwner {
    companion object {
        const val ACTION_REFRESH = "refresh"
        const val ACTION_STOP = "stop"
        const val ACTION_CAPTURE = "capture"
        const val ACTION_OPEN_PANEL = "panel"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_QUESTION = "question"
        private const val NOTIF_ID = 7

        fun refresh(c: Context) {
            val wantWake = Prefs.wakeOn && ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val wantBubble = Prefs.bubbleOn && Settings.canDrawOverlays(c)
            if (!Prefs.setupDone || (!wantWake && !wantBubble)) {
                if (AppState.serviceRunning.value) c.startService(Intent(c, AssistantService::class.java).setAction(ACTION_STOP))
                return
            }
            runCatching { ContextCompat.startForegroundService(c, Intent(c, AssistantService::class.java).setAction(ACTION_REFRESH)) }
        }
    }

    private val ssrc = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = ssrc.savedStateRegistry

    private var overlay: Overlay? = null
    @Volatile private var running = false
    private var wakeThread: Thread? = null
    private var micType = false
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate() {
        ssrc.performAttach(); ssrc.performRestore(null)
        super.onCreate()
        AppState.serviceRunning.value = true
        lifecycleScope.launch {
            Assistant.events.collect { e ->
                when (e) {
                    is AssistantEvent.CaptureScreen -> startCapture(e.question)
                    is AssistantEvent.OpenCamera -> if (!AppState.mainVisible) openApp { it.putExtra(MainActivity.EXTRA_CAMERA, e.question) }
                    is AssistantEvent.AskPermission -> if (!AppState.mainVisible) openApp { it.putExtra(MainActivity.EXTRA_PERM, e.perm.name).putExtra(MainActivity.EXTRA_RETRY, e.retryText) }
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> { stopEverything(); return START_NOT_STICKY }
            ACTION_CAPTURE -> { handleCapture(intent); return START_STICKY }
            ACTION_OPEN_PANEL -> { goForeground(); overlay?.openPanel(); return START_STICKY }
        }
        goForeground()
        return START_STICKY
    }

    private fun goForeground(withProjection: Boolean = false) {
        val wantWake = Prefs.wakeOn && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val wantBubble = Prefs.bubbleOn && Settings.canDrawOverlays(this)
        var type = 0
        if (wantWake) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (withProjection) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (type == 0 || wantBubble) type = type or if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, notification(wantWake), type)
        } catch (e: Exception) {
            // Android refused the microphone from the background (e.g. right after a reboot)
            try {
                ServiceCompat.startForeground(this, NOTIF_ID, notification(false),
                    if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
            } catch (_: Exception) { stopSelf(); return }
            micType = false
            applyBubble(wantBubble)
            stopWake()
            return
        }
        micType = wantWake
        applyBubble(wantBubble)
        if (wantWake) startWake() else stopWake()
    }

    private fun applyBubble(on: Boolean) {
        if (on) { if (overlay == null) overlay = Overlay(this).also { it.show() } }
        else { overlay?.hide(); overlay = null }
    }

    private fun notification(listening: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, App.CH_LISTEN)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(getString(if (listening) R.string.notif_listening else R.string.notif_bubble))
            .setContentText(getString(R.string.notif_tap))
            .setContentIntent(open)
            .addAction(0, getString(R.string.stop), stop)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    // ---------------- Wake word ----------------

    @SuppressLint("MissingPermission")
    private fun startWake() {
        if (running) return
        running = true
        AppState.wakeActive.value = true
        wakeThread = thread(name = "wake") {
            val engine = runCatching { WakeEngine(this) }.getOrNull()
            if (engine == null) { running = false; AppState.wakeActive.value = false; return@thread }
            val buf = ShortArray(WakeEngine.CHUNK)
            var rec: AudioRecord? = null
            try {
                while (running) {
                    if (Assistant.micBusy.value) {
                        rec?.let { runCatching { it.stop(); it.release() } }; rec = null
                        Thread.sleep(150); continue
                    }
                    if (rec == null) {
                        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                        rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000, AudioFormat.CHANNEL_IN_MONO,
                            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, WakeEngine.CHUNK * 4))
                        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); rec = null; Thread.sleep(1000); continue }
                        rec.startRecording(); engine.reset()
                    }
                    var got = 0
                    while (got < buf.size && running && !Assistant.micBusy.value) {
                        val n = rec.read(buf, got, buf.size - got); if (n <= 0) break; got += n
                    }
                    if (got < buf.size) continue
                    if (engine.process(buf)) main.post { onWake() }
                }
            } catch (_: Exception) {
            } finally {
                rec?.let { runCatching { it.stop(); it.release() } }
                engine.close()
                AppState.wakeActive.value = false
            }
        }
    }

    private fun stopWake() { running = false; wakeThread = null }

    private fun onWake() {
        if (Assistant.micBusy.value) return
        runCatching {
            getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(40, 120))
        }
        if (AppState.mainVisible) { Assistant.startVoiceTurn(); return }
        overlay?.let { it.openPanel(); Assistant.startVoiceTurn(); return }
        openApp { it.putExtra(MainActivity.EXTRA_LISTEN, true) }
    }

    private fun openApp(extra: (Intent) -> Unit) {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        extra(i)
        runCatching { startActivity(i) }
    }

    // ---------------- "What's on my screen?" ----------------

    private fun startCapture(question: String) {
        overlay?.closePanel()
        main.postDelayed({
            runCatching {
                startActivity(Intent(this, CaptureActivity::class.java)
                    .putExtra(EXTRA_QUESTION, question).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }, 300)
    }

    @Suppress("DEPRECATION")
    private fun handleCapture(intent: Intent) {
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent = (if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
            else intent.getParcelableExtra(EXTRA_DATA)) ?: return
        val question = intent.getStringExtra(EXTRA_QUESTION) ?: ""
        goForeground(withProjection = true)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val projection = runCatching { mpm.getMediaProjection(code, data) }.getOrNull() ?: run { goForeground(); return }
        val dm = resources.displayMetrics
        val w = dm.widthPixels / 2; val h = dm.heightPixels / 2
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        projection.registerCallback(object : MediaProjection.Callback() {}, main)
        val vd = projection.createVirtualDisplay("shivangi-shot", w, h, dm.densityDpi / 2,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, main)
        var done = false
        reader.setOnImageAvailableListener({ r ->
            if (done) return@setOnImageAvailableListener
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            done = true
            val plane = img.planes[0]
            val rowPad = plane.rowStride - plane.pixelStride * w
            val bmp = Bitmap.createBitmap(w + rowPad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(plane.buffer)
            img.close()
            val shot = Bitmap.createBitmap(bmp, 0, 0, w, h)
            vd?.release(); reader.close(); projection.stop()
            goForeground()
            overlay?.openPanel()
            Assistant.askWithImage(question.ifBlank { getString(R.string.screen_default_q) }, shot)
        }, main)
    }

    private fun stopEverything() {
        stopWake()
        overlay?.hide(); overlay = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopWake()
        overlay?.hide(); overlay = null
        AppState.serviceRunning.value = false
        super.onDestroy()
    }
}
