package com.appforge.shivangi.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.appforge.shivangi.App
import com.appforge.shivangi.MainActivity
import com.appforge.shivangi.R
import com.appforge.shivangi.data.Prefs
import com.appforge.shivangi.data.Store

/** Asks Android once for permission to see the screen, then hands it to the service. */
class CaptureActivity : Activity() {
    private var question = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        question = intent.getStringExtra(AssistantService.EXTRA_QUESTION) ?: ""
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && data != null) {
            ContextCompat.startForegroundService(this, Intent(this, AssistantService::class.java)
                .setAction(AssistantService.ACTION_CAPTURE)
                .putExtra(AssistantService.EXTRA_CODE, resultCode)
                .putExtra(AssistantService.EXTRA_DATA, data)
                .putExtra(AssistantService.EXTRA_QUESTION, question))
        }
        finish()
        @Suppress("DEPRECATION") overridePendingTransition(0, 0)
    }
}

/** Keeps the latest notifications so she can read them out ("read my messages"). */
class NotifListener : NotificationListenerService() {
    data class Item(val app: String, val title: String, val text: String, val time: Long)

    companion object {
        private val items = ArrayDeque<Item>()
        fun recent(): List<Item> = synchronized(items) { items.toList().reversed() }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val app = runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() }
            .getOrDefault(sbn.packageName)
        synchronized(items) {
            items.addLast(Item(app, title, text, sbn.postTime))
            while (items.size > 40) items.removeFirst()
        }
    }
}

/** After a restart Android won't let apps open the mic by themselves, so ask for one tap. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (!Prefs.setupDone) return
        if (!(Prefs.wakeOn || Prefs.bubbleOn)) return
        val pi = PendingIntent.getActivity(c, 3,
            Intent(c, MainActivity::class.java).putExtra(MainActivity.EXTRA_FROM_BOOT, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, App.CH_WAKE)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(c.getString(R.string.boot_title))
            .setContentText(c.getString(R.string.boot_text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        runCatching { c.getSystemService(NotificationManager::class.java).notify(11, n) }
    }
}

/** Shows a reminder she set. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val text = intent.getStringExtra("text") ?: return
        val pi = PendingIntent.getActivity(c, id, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, App.CH_REMIND)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(c.getString(R.string.reminder_title))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        runCatching { c.getSystemService(NotificationManager::class.java).notify(id, n) }
        Store.init(c); Store.removeReminder(id)
    }
}
