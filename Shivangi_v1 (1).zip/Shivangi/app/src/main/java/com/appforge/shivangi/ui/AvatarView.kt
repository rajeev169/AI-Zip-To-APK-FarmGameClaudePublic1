package com.appforge.shivangi.ui

import android.annotation.SuppressLint
import android.graphics.Color
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.appforge.shivangi.R
import com.appforge.shivangi.brain.Assistant
import com.appforge.shivangi.voice.Speaker

/** Shivangi in 3D (three.js page from the app's assets). Lips move while she speaks. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AvatarView(modifier: Modifier = Modifier, framing: String = "bust") {
    var web by remember { mutableStateOf<WebView?>(null) }
    var ready by remember { mutableStateOf(false) }

    fun js(code: String) { web?.evaluateJavascript("window.av && $code", null) }

    Box(modifier, contentAlignment = Alignment.Center) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val loader = WebViewAssetLoader.Builder()
                    .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
                    .build()
                WebView(ctx).apply {
                    setBackgroundColor(Color.TRANSPARENT)
                    settings.javaScriptEnabled = true
                    settings.allowFileAccess = false
                    settings.mediaPlaybackRequiresUserGesture = true
                    isVerticalScrollBarEnabled = false
                    isHorizontalScrollBarEnabled = false
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                            loader.shouldInterceptRequest(request.url)
                    }
                    addJavascriptInterface(object {
                        @JavascriptInterface fun onReady() { post { ready = true; evaluateJavascript("window.av.frame('$framing')", null) } }
                        @JavascriptInterface fun onError(msg: String) {}
                    }, "Android")
                    loadUrl("https://appassets.androidplatform.net/assets/avatar/index.html")
                    web = this
                }
            },
            onRelease = { it.destroy() }
        )
        // Her photo shows until the 3D model has loaded
        if (!ready) Image(painterResource(R.drawable.shivangi_head), null, Modifier.size(140.dp).alpha(0.9f))
    }

    LaunchedEffect(web) { Speaker.speaking.collect { js("window.av.setTalking($it)") } }
    LaunchedEffect(web) { Speaker.words.collect { js("window.av.word()") } }
    LaunchedEffect(web) { Assistant.wave.collect { js("window.av.wave()") } }
    DisposableEffect(Unit) { onDispose { web = null } }
}
