package com.appforge.shivangi.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.QuestionMark
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.shivangi.BuildConfigInfo
import com.appforge.shivangi.R
import com.appforge.shivangi.brain.Assistant
import com.appforge.shivangi.brain.Phase
import com.appforge.shivangi.data.Prefs
import com.appforge.shivangi.service.AppState
import com.appforge.shivangi.voice.Listener
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val host = LocalHost.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val phase by Assistant.phase.collectAsState()
    val session by Assistant.session.collectAsState()
    val partial by Listener.partial.collectAsState()
    val wakeActive by AppState.wakeActive.collectAsState()
    val call by Assistant.call.collectAsState()
    val tick by Prefs.changes.collectAsState()
    var input by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { Assistant.greetIfFirstToday() }

    ModalNavigationDrawer(drawerState = drawer, drawerContent = {
        MenuDrawer(onPick = { route ->
            scope.launch { drawer.close() }
            when (route) {
                "home" -> {}
                "share" -> host.share(ctx.getString(R.string.share_text, ctx.packageName))
                "rate" -> host.openUrl("https://play.google.com/store/apps/details?id=${ctx.packageName}")
                else -> go(route)
            }
        })
    }) {
        Column(
            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding().imePadding()
                .padding(horizontal = 18.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top bar
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, stringResource(R.string.menu)) }
                Text(stringResource(R.string.app_name), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                IconButton(onClick = { go("settings") }) { Icon(Icons.Default.Settings, stringResource(R.string.m_settings)) }
            }
            // Status pill
            val on = wakeActive && Prefs.wakeOn.also { tick }
            Row(Modifier.align(Alignment.CenterHorizontally).clip(RoundedCornerShape(16.dp))
                .background(if (on) Green.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (on) { Box(Modifier.size(8.dp).clip(CircleShape).background(Green)); Spacer(Modifier.width(8.dp)) }
                Text(stringResource(if (on) R.string.listening_for else R.string.wake_off), fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = if (on) Green else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            // Shivangi + her speech bubble
            Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                AvatarView(Modifier.fillMaxSize().padding(top = 70.dp))
                val herLast = session.lastOrNull { !it.fromUser }?.text
                val bubble = when (phase) {
                    Phase.LISTENING -> partial.ifBlank { stringResource(R.string.st_listening) }
                    Phase.THINKING -> stringResource(R.string.st_thinking)
                    else -> herLast ?: Assistant.greetingText()
                }
                Surface(Modifier.padding(16.dp).fillMaxWidth().heightIn(max = 150.dp), shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp),
                    color = MaterialTheme.colorScheme.surface) {
                    Text(bubble, Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp),
                        fontSize = 15.sp, lineHeight = 21.sp, fontWeight = if (herLast == null && phase == Phase.IDLE) FontWeight.Bold else FontWeight.Normal)
                }
            }
            // Pending call with 3-second cancel
            call?.let { c ->
                Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.calling_in, c.name, c.secondsLeft), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { Assistant.cancelCall() }) { Text(stringResource(R.string.cancel)) }
                    }
                }
            }
            // What the user said last
            session.lastOrNull { it.fromUser }?.let { m ->
                Text(m.text, Modifier.align(Alignment.End).clip(RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp))
                    .background(MaterialTheme.colorScheme.primary).padding(horizontal = 14.dp, vertical = 10.dp),
                    color = MaterialTheme.colorScheme.onPrimary, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
            // Suggestion chips
            if (session.isEmpty()) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.chip_alarm, R.string.chip_screen, R.string.chip_messages, R.string.chip_torch, R.string.chip_weather).forEach { r ->
                        val t = stringResource(r)
                        SuggestionChip(onClick = { Assistant.ask(t) }, label = { Text(t) })
                    }
                }
            }
            // Type or talk
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it }, placeholder = { Text(stringResource(R.string.type_hint)) },
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(28.dp), singleLine = true)
                Spacer(Modifier.width(10.dp))
                val busy = phase == Phase.LISTENING || phase == Phase.SPEAKING || phase == Phase.THINKING
                FilledIconButton(
                    onClick = {
                        when {
                            input.isNotBlank() -> { Assistant.ask(input.trim()); input = "" }
                            busy -> Assistant.stop()
                            else -> Assistant.startVoiceTurn()
                        }
                    },
                    modifier = Modifier.size(60.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(when { input.isNotBlank() -> Icons.AutoMirrored.Filled.Send; busy -> Icons.Default.Stop; else -> Icons.Default.Mic },
                        contentDescription = stringResource(R.string.talk), modifier = Modifier.size(28.dp))
                }
            }
        }
    }
}

@Composable
private fun MenuDrawer(onPick: (String) -> Unit) {
    val items: List<Triple<String, Int, ImageVector>> = listOf(
        Triple("home", R.string.m_home, Icons.Default.Home),
        Triple("history", R.string.m_history, Icons.Default.ChatBubbleOutline),
        Triple("reminders", R.string.m_reminders, Icons.Default.Alarm),
        Triple("permissions", R.string.m_permissions, Icons.Default.Shield),
        Triple("language", R.string.m_language, Icons.Default.Language),
        Triple("settings", R.string.m_settings, Icons.Default.Settings),
    )
    val more: List<Triple<String, Int, ImageVector>> = listOf(
        Triple("help", R.string.m_help, Icons.Default.QuestionMark),
        Triple("share", R.string.m_share, Icons.Default.Share),
        Triple("rate", R.string.m_rate, Icons.Default.Star),
        Triple("about", R.string.m_about, Icons.Default.Info),
    )
    ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.background, modifier = Modifier.width(310.dp)) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.shivangi_head), null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(56.dp).clip(CircleShape).border(2.dp, MaterialTheme.colorScheme.primary, CircleShape))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(stringResource(R.string.app_name), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text(Prefs.userEmail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.size(8.dp))
        items.forEach { (route, label, icon) ->
            NavigationDrawerItem(label = { Text(stringResource(label), fontWeight = FontWeight.SemiBold) }, icon = { Icon(icon, null) },
                selected = route == "home", onClick = { onPick(route) },
                modifier = Modifier.padding(horizontal = 12.dp),
                colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer))
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(16.dp))
        more.forEach { (route, label, icon) ->
            NavigationDrawerItem(label = { Text(stringResource(label), fontWeight = FontWeight.SemiBold) }, icon = { Icon(icon, null) },
                selected = false, onClick = { onPick(route) }, modifier = Modifier.padding(horizontal = 12.dp))
        }
        Spacer(Modifier.weight(1f))
        Text(stringResource(R.string.version_line, BuildConfigInfo.version(LocalContext.current)), Modifier.padding(28.dp),
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
