package com.appforge.shivangi.ui

import android.content.Intent
import android.provider.AlarmClock
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.shivangi.R
import com.appforge.shivangi.brain.AppPerm
import com.appforge.shivangi.brain.PermGroup
import com.appforge.shivangi.data.Languages
import com.appforge.shivangi.data.Prefs
import com.appforge.shivangi.data.Store
import com.appforge.shivangi.voice.Speaker
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun Screen(title: String, onBack: () -> Unit, actions: @Composable () -> Unit = {}, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding()) {
        BackBar(title, onBack, actions)
        content()
    }
}

// ---------------- Chat history ----------------

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val all by Store.history.collectAsState()
    var q by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    val list = all.filter { q.isBlank() || it.text.contains(q, true) }.reversed()
    val dayFmt = remember { SimpleDateFormat("d MMM yyyy", Locale.getDefault()) }
    val timeFmt = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    Screen(stringResource(R.string.m_history), onBack, actions = {
        IconButton(onClick = { confirm = true }) { Icon(Icons.Default.DeleteSweep, stringResource(R.string.clear_all)) }
    }) {
        OutlinedTextField(q, { q = it }, placeholder = { Text(stringResource(R.string.search)) }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(24.dp))
        if (list.isEmpty()) Text(stringResource(R.string.history_empty), Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), reverseLayout = false) {
            var lastDay = ""
            items(list) { m ->
                val day = dayFmt.format(m.time)
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.fromUser) Alignment.End else Alignment.Start) {
                    if (day != lastDay) {
                        lastDay = day
                        Text(day, Modifier.align(Alignment.CenterHorizontally).padding(vertical = 6.dp), fontSize = 12.sp,
                            fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Surface(shape = RoundedCornerShape(16.dp), color = if (m.fromUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                        modifier = Modifier.widthIn(max = 300.dp)) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Text(m.text, color = if (m.fromUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                            Text(timeFmt.format(m.time), fontSize = 11.sp,
                                color = (if (m.fromUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant).copy(alpha = 0.8f))
                        }
                    }
                }
            }
        }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false },
        confirmButton = { TextButton({ Store.clearHistory(); confirm = false }) { Text(stringResource(R.string.delete)) } },
        dismissButton = { TextButton({ confirm = false }) { Text(stringResource(R.string.cancel)) } },
        text = { Text(stringResource(R.string.clear_confirm)) })
}

// ---------------- Reminders ----------------

@Composable
fun RemindersScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val list by Store.reminders.collectAsState()
    val fmt = remember { SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault()) }
    Screen(stringResource(R.string.m_reminders), onBack) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (list.isEmpty()) Text(stringResource(R.string.reminders_empty), color = MaterialTheme.colorScheme.onSurfaceVariant)
            else CardGroup {
                list.forEachIndexed { i, r ->
                    if (i > 0) RowDivider()
                    InfoRow(r.text, fmt.format(r.time)) {
                        IconButton(onClick = { Store.removeReminder(r.id) }) { Icon(Icons.Default.Delete, stringResource(R.string.delete)) }
                    }
                }
            }
            Text(stringResource(R.string.reminders_alarms_note), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
            OutlinedButton(onClick = {
                runCatching { ctx.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }) { Text(stringResource(R.string.open_clock)) }
        }
    }
}

// ---------------- All 16 permissions ----------------

@Composable
fun PermissionsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val host = LocalHost.current
    val tick by Prefs.changes.collectAsState()
    val resume = resumeTick.intValue
    val states = remember(tick, resume) { AppPerm.entries.associateWith { it.granted(ctx) } }
    Screen(stringResource(R.string.m_permissions), onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.perms_count, states.values.count { it }, states.size), fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 20.sp)
            listOf(PermGroup.TALK to R.string.grp_talk, PermGroup.PHONE to R.string.grp_phone, PermGroup.MEDIA to R.string.grp_media).forEach { (g, label) ->
                SectionLabel(stringResource(label))
                CardGroup {
                    AppPerm.entries.filter { it.group == g }.forEachIndexed { i, p ->
                        if (i > 0) RowDivider()
                        val on = states[p] == true
                        val sub = if (p == AppPerm.DOCUMENTS)
                            (if (Prefs.docFolders.isEmpty()) stringResource(R.string.no_folders) else stringResource(R.string.folders_n, Prefs.docFolders.size))
                        else stringResource(p.desc)
                        InfoRow(stringResource(p.title), sub) {
                            if (p == AppPerm.DOCUMENTS) OutlinedButton(onClick = { host.pickFolder() }) { Text(stringResource(R.string.choose)) }
                            else Switch(checked = on, onCheckedChange = {
                                // Turning off is only possible in Android settings
                                if (on) p.settingsIntent(ctx)?.let { runCatching { ctx.startActivity(it) } } else host.requestPerm(p)
                            })
                        }
                    }
                }
            }
            Spacer(Modifier.size(24.dp))
        }
    }
}

// ---------------- Language ----------------

@Composable
fun LanguageScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var sel by remember { mutableStateOf(Languages.current.code) }
    var noVoice by remember { mutableStateOf(false) }
    Screen(stringResource(R.string.m_language), onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.lang_sub), color = MaterialTheme.colorScheme.onSurfaceVariant)
            CardGroup {
                Languages.all.forEachIndexed { i, l ->
                    if (i > 0) RowDivider()
                    Row(Modifier.fillMaxWidth().selectable(sel == l.code, role = Role.RadioButton) { sel = l.code }
                        .background(if (sel == l.code) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = sel == l.code, onClick = null)
                        Spacer(Modifier.size(8.dp))
                        Text(l.native, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        Text(l.english, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (noVoice) Text(stringResource(R.string.lang_no_voice), color = MaterialTheme.colorScheme.error, fontSize = 14.sp)
        }
        Column(Modifier.padding(16.dp)) {
            BigButton(stringResource(R.string.save)) {
                Prefs.speechLang = sel
                scope.launch {
                    if (Speaker.supports(Languages.byCode(sel).tag)) onBack() else noVoice = true
                }
            }
        }
    }
}

// ---------------- Help & About ----------------

@Composable
fun HelpScreen(onBack: () -> Unit) {
    Screen(stringResource(R.string.m_help), onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.help_sub), color = MaterialTheme.colorScheme.onSurfaceVariant)
            CardGroup {
                stringArrayResource(R.array.help_examples).forEachIndexed { i, s ->
                    if (i > 0) RowDivider()
                    Text(s, Modifier.padding(horizontal = 16.dp, vertical = 12.dp), fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val host = LocalHost.current
    Screen(stringResource(R.string.m_about), onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(stringResource(R.string.about_text), fontSize = 15.sp, lineHeight = 22.sp)
            Button(onClick = { host.openUrl(ctx.getString(R.string.privacy_url)) }) { Text(stringResource(R.string.privacy_policy)) }
            Text(stringResource(R.string.credits), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(stringResource(R.string.version_line, com.appforge.shivangi.BuildConfigInfo.version(ctx)), fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
