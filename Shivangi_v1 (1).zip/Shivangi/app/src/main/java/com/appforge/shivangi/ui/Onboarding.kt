package com.appforge.shivangi.ui

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.appforge.shivangi.R
import com.appforge.shivangi.auth.GoogleAuth
import com.appforge.shivangi.auth.SignInResult
import com.appforge.shivangi.brain.AppPerm
import com.appforge.shivangi.brain.Gemini
import com.appforge.shivangi.data.Prefs
import com.appforge.shivangi.wake.Enrollment
import kotlinx.coroutines.launch

@Composable
private fun Page(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp), content = content
    )
}

// ---------------- 1 · Sign in ----------------

@Composable
fun SignInScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val host = LocalHost.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Page {
        Box(Modifier.fillMaxWidth().height(330.dp).clip(RoundedCornerShape(140.dp, 140.dp, 32.dp, 32.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)) {
            AvatarView(Modifier.fillMaxSize())
        }
        Text(stringResource(R.string.signin_title), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text(stringResource(R.string.signin_sub), fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), lineHeight = 23.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = {
                busy = true
                scope.launch {
                    when (val r = GoogleAuth.signIn(ctx as Activity)) {
                        SignInResult.Ok -> onDone()
                        SignInResult.Cancelled -> {}
                        SignInResult.NotConfigured -> error = ctx.getString(R.string.signin_not_configured)
                        is SignInResult.Failed -> error = ctx.getString(R.string.signin_failed, r.message)
                    }
                    busy = false
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(28.dp)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            else {
                Text("G", fontWeight = FontWeight.ExtraBold, color = Color(0xFF4285F4), fontSize = 20.sp)
                Spacer(Modifier.size(12.dp))
                Text(stringResource(R.string.continue_google), fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface)
            }
        }
        TextButton(onClick = { host.openUrl(ctx.getString(R.string.privacy_url)) }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.privacy_note), fontSize = 13.sp, textAlign = TextAlign.Center)
        }
    }
    error?.let { msg ->
        AlertDialog(onDismissRequest = { error = null }, confirmButton = { TextButton({ error = null }) { Text(stringResource(R.string.ok)) } },
            text = { Text(msg) })
    }
}

// ---------------- 2 · Gemini key ----------------

@Composable
fun KeyScreen(step: Int?, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val host = LocalHost.current
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(Prefs.geminiKey) }
    var state by remember { mutableIntStateOf(0) } // 0 idle, 1 checking, 2 ok, 3 bad
    fun check() {
        if (key.isBlank()) return
        state = 1
        scope.launch {
            state = runCatching { Prefs.geminiModel = Gemini.checkKey(key.trim()); 2 }.getOrDefault(3)
        }
    }
    Page {
        if (step != null) StepHeader(step, 3, stringResource(R.string.key_title), stringResource(R.string.key_sub))
        else Text(stringResource(R.string.key_title), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(R.string.key_step1, R.string.key_step2, R.string.key_step3).forEachIndexed { i, s ->
                    Row(verticalAlignment = Alignment.Top) {
                        Box(Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                            Text("${i + 1}", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.size(12.dp))
                        Text(stringResource(s), fontSize = 15.sp, lineHeight = 21.sp)
                    }
                }
            }
        }
        OutlinedButton(onClick = { host.openUrl("https://aistudio.google.com/apikey") }, modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(26.dp)) {
            Text(stringResource(R.string.open_ai_studio), fontWeight = FontWeight.Bold)
            Spacer(Modifier.size(8.dp)); Icon(Icons.AutoMirrored.Filled.OpenInNew, null, Modifier.size(18.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = key, onValueChange = { key = it; state = 0 }, label = { Text(stringResource(R.string.key_label)) },
                singleLine = true, modifier = Modifier.weight(1f))
            Spacer(Modifier.size(8.dp))
            OutlinedButton(onClick = {
                val cm = ctx.getSystemService(ClipboardManager::class.java)
                cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()?.trim()?.let { key = it; check() }
            }) { Text(stringResource(R.string.paste)) }
        }
        when (state) {
            1 -> Text(stringResource(R.string.key_checking), color = MaterialTheme.colorScheme.onSurfaceVariant)
            2 -> Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(18.dp)); Spacer(Modifier.size(6.dp))
                Text(stringResource(R.string.key_works), color = Green, fontWeight = FontWeight.SemiBold)
            }
            3 -> Text(stringResource(R.string.key_bad), color = MaterialTheme.colorScheme.error)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Lock, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.size(8.dp))
            Text(stringResource(R.string.key_saved_note), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        BigButton(stringResource(R.string.save_continue), enabled = key.isNotBlank() && state != 1) {
            if (state == 2) { Prefs.geminiKey = key.trim(); onDone() } else check()
        }
        LaunchedEffect(state) { if (state == 2 && step != null) { Prefs.geminiKey = key.trim() } }
    }
}

// ---------------- 3 · Teach your voice ----------------

@Composable
fun VoiceScreen(step: Int?, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val host = LocalHost.current
    val scope = rememberCoroutineScope()
    val total = 8
    val enroll = remember { runCatching { Enrollment(ctx) }.getOrNull() }
    var count by remember { mutableIntStateOf(0) }
    var recording by remember { mutableStateOf(false) }
    var level by remember { mutableFloatStateOf(0f) }
    var retry by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { com.appforge.shivangi.brain.Assistant.micBusy.value = true; onDispose { com.appforge.shivangi.brain.Assistant.micBusy.value = false } }

    fun recordNext() {
        if (enroll == null || recording) return
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            host.requestPerm(AppPerm.MIC); return
        }
        recording = true; retry = false
        scope.launch {
            val ok = enroll.recordOne { level = it }
            recording = false
            if (ok) count = enroll.count else retry = true
            if (count >= total) { enroll.save(); Prefs.voiceTaught = true }
        }
    }

    Page {
        if (step != null) StepHeader(step, 3, stringResource(R.string.voice_title), stringResource(R.string.voice_sub))
        else Text(stringResource(R.string.voice_title), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(22.dp)) {
            Box(Modifier.size(220.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) {
                Box(Modifier.size(150.dp).scale(1f + level * 0.35f).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer))
                FilledIconButton(onClick = { recordNext() }, enabled = count < total && !recording, modifier = Modifier.size(96.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Icon(Icons.Default.Mic, contentDescription = stringResource(R.string.voice_tap), Modifier.size(44.dp))
                }
            }
            Text(stringResource(when {
                count >= total -> R.string.voice_done
                recording -> R.string.voice_now
                else -> R.string.voice_tap
            }), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                repeat(total) { i ->
                    Box(Modifier.size(16.dp).clip(CircleShape).background(
                        if (i < count) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline))
                }
            }
            Text(stringResource(R.string.voice_count, count, total), color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (retry) Text(stringResource(R.string.voice_retry), color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
        }
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
            Text(stringResource(R.string.voice_tip), Modifier.padding(14.dp), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (count >= total) BigButton(stringResource(R.string.cont)) { onDone() }
        else TextButton(onClick = { enroll?.discard(); onDone() }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.skip), fontWeight = FontWeight.Bold)
        }
    }
}

// ---------------- 4 · Four permissions ----------------

@Composable
fun SetupPermsScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val host = LocalHost.current
    val tick by Prefs.changes.collectAsState()
    Page {
        StepHeader(3, 3, stringResource(R.string.perms_title), stringResource(R.string.perms_sub))
        CardGroup {
            AppPerm.setupFour.forEachIndexed { i, p ->
                if (i > 0) RowDivider()
                val granted = remember(tick, resumeTick.intValue) { p.granted(ctx) }
                InfoRow(stringResource(p.title), stringResource(p.desc)) {
                    if (granted) Text(stringResource(R.string.allowed), color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    else Button(onClick = { host.requestPerm(p) }, shape = RoundedCornerShape(22.dp)) {
                        Text(stringResource(if (p == AppPerm.ASSISTANT) R.string.set else R.string.allow))
                    }
                }
            }
        }
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
            Text(stringResource(R.string.perms_example), Modifier.padding(14.dp), fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 20.sp)
        }
        BigButton(stringResource(R.string.start_shivangi)) { onDone() }
    }
}

/** Bumped by the Activity on every resume so special permissions re-check after Settings */
val resumeTick = mutableIntStateOf(0)
