package com.appforge.shivangi.ui

import android.app.Activity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.shivangi.R
import com.appforge.shivangi.auth.GoogleAuth
import com.appforge.shivangi.brain.AppPerm
import com.appforge.shivangi.data.Prefs
import com.appforge.shivangi.data.Store
import com.appforge.shivangi.service.AssistantService
import com.appforge.shivangi.wake.WakeEngine
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onBack: () -> Unit, go: (String) -> Unit, onSignedOut: () -> Unit) {
    val ctx = LocalContext.current
    val host = LocalHost.current
    val scope = rememberCoroutineScope()
    val tick by Prefs.changes.collectAsState()
    var sens by remember { mutableFloatStateOf(Prefs.sensitivity.toFloat()) }
    var speed by remember { mutableFloatStateOf(Prefs.speechRate) }
    var editName by remember { mutableStateOf(false) }
    var clearAsk by remember { mutableStateOf(false) }
    var signOutAsk by remember { mutableStateOf(false) }
    val hasModel = remember { runCatching { ctx.assets.open("wake/shivangi.onnx").close(); true }.getOrDefault(false) }
    tick // re-read prefs on change

    Screen(stringResource(R.string.m_settings), onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionLabel(stringResource(R.string.s_wake))
            CardGroup {
                InfoRow(stringResource(R.string.s_listen)) {
                    Switch(Prefs.wakeOn, onCheckedChange = { on ->
                        if (on && !AppPerm.MIC.granted(ctx)) host.requestPerm(AppPerm.MIC) { if (it) { Prefs.wakeOn = true; AssistantService.refresh(ctx) } }
                        else { Prefs.wakeOn = on; AssistantService.refresh(ctx) }
                    })
                }
                RowDivider()
                Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text(stringResource(R.string.s_sensitivity), fontSize = 15.sp)
                    Slider(value = sens, onValueChange = { sens = it }, onValueChangeFinished = { Prefs.sensitivity = sens.toInt() }, valueRange = 0f..100f)
                    Row { Text(stringResource(R.string.s_fewer), fontSize = 12.sp, modifier = Modifier.weight(1f)); Text(stringResource(R.string.s_easier), fontSize = 12.sp) }
                }
                RowDivider()
                InfoRow(stringResource(R.string.s_teach), if (hasModel) null else stringResource(R.string.s_model_missing)) {
                    OutlinedButton(onClick = { go("teach") }) { Text(stringResource(R.string.change)) }
                }
            }

            SectionLabel(stringResource(R.string.s_look))
            CardGroup {
                InfoRow(stringResource(R.string.s_bubble)) {
                    Switch(Prefs.bubbleOn, onCheckedChange = { on ->
                        if (on && !AppPerm.OVERLAY.granted(ctx)) host.requestPerm(AppPerm.OVERLAY) { if (it) { Prefs.bubbleOn = true; AssistantService.refresh(ctx) } }
                        else { Prefs.bubbleOn = on; AssistantService.refresh(ctx) }
                    })
                }
                RowDivider()
                Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text(stringResource(R.string.s_speed) + "  ·  ${"%.1f".format(speed)}x", fontSize = 15.sp)
                    Slider(value = speed, onValueChange = { speed = it }, onValueChangeFinished = { Prefs.speechRate = speed }, valueRange = 0.6f..1.6f, steps = 9)
                }
                RowDivider()
                Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text(stringResource(R.string.s_theme), fontSize = 15.sp)
                    Spacer(Modifier.size(8.dp))
                    val opts = listOf("system" to R.string.theme_system, "light" to R.string.theme_light, "dark" to R.string.theme_dark)
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        opts.forEachIndexed { i, (k, label) ->
                            SegmentedButton(selected = Prefs.theme == k, onClick = { Prefs.theme = k },
                                shape = SegmentedButtonDefaults.itemShape(i, opts.size)) { Text(stringResource(label)) }
                        }
                    }
                }
            }

            SectionLabel(stringResource(R.string.s_behaviour))
            CardGroup {
                InfoRow(stringResource(R.string.s_confirm_call)) { Switch(Prefs.confirmCalls, onCheckedChange = { Prefs.confirmCalls = it }) }
            }

            SectionLabel(stringResource(R.string.s_privacy))
            CardGroup {
                InfoRow(stringResource(R.string.s_save_history)) { Switch(Prefs.saveHistory, onCheckedChange = { Prefs.saveHistory = it }) }
                RowDivider()
                InfoRow(stringResource(R.string.s_clear_chats)) { OutlinedButton(onClick = { clearAsk = true }) { Text(stringResource(R.string.delete)) } }
            }

            SectionLabel(stringResource(R.string.s_account))
            CardGroup {
                InfoRow(stringResource(R.string.s_call_me),
                    Prefs.nickname.ifBlank { stringResource(R.string.s_from_google, Prefs.googleName.substringBefore(' ')) }) {
                    OutlinedButton(onClick = { editName = true }) { Text(stringResource(R.string.change)) }
                }
                RowDivider()
                val k = Prefs.geminiKey
                InfoRow(stringResource(R.string.s_gemini_key),
                    if (k.isBlank()) stringResource(R.string.s_key_missing) else stringResource(R.string.s_key_ok, k.take(6) + "••••" + k.takeLast(3))) {
                    OutlinedButton(onClick = { go("key_edit") }) { Text(stringResource(R.string.change)) }
                }
                RowDivider()
                InfoRow(stringResource(R.string.s_google), Prefs.userEmail) {
                    OutlinedButton(onClick = { signOutAsk = true }) { Text(stringResource(R.string.sign_out), color = MaterialTheme.colorScheme.error) }
                }
            }
            Spacer(Modifier.size(24.dp))
        }
    }

    if (editName) {
        var v by remember { mutableStateOf(Prefs.nickname) }
        AlertDialog(onDismissRequest = { editName = false },
            title = { Text(stringResource(R.string.s_call_me)) },
            text = { OutlinedTextField(v, { v = it }, placeholder = { Text(stringResource(R.string.nickname_hint)) }, singleLine = true) },
            confirmButton = { TextButton({ Prefs.nickname = v; editName = false }) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton({ editName = false }) { Text(stringResource(R.string.cancel)) } })
    }
    if (clearAsk) AlertDialog(onDismissRequest = { clearAsk = false },
        text = { Text(stringResource(R.string.clear_confirm)) },
        confirmButton = { TextButton({ Store.clearHistory(); clearAsk = false }) { Text(stringResource(R.string.delete)) } },
        dismissButton = { TextButton({ clearAsk = false }) { Text(stringResource(R.string.cancel)) } })
    if (signOutAsk) AlertDialog(onDismissRequest = { signOutAsk = false },
        text = { Text(stringResource(R.string.sign_out_confirm)) },
        confirmButton = {
            TextButton({
                signOutAsk = false
                scope.launch {
                    AssistantService.refresh(ctx)
                    GoogleAuth.signOut(ctx as Activity)
                    java.io.File(ctx.filesDir, WakeEngine.TEMPLATE_FILE).delete()
                    Store.clearHistory()
                    AssistantService.refresh(ctx)
                    onSignedOut()
                }
            }) { Text(stringResource(R.string.sign_out)) }
        },
        dismissButton = { TextButton({ signOutAsk = false }) { Text(stringResource(R.string.cancel)) } })
}
