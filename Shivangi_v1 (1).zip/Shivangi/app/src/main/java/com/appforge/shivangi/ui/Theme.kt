package com.appforge.shivangi.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import com.appforge.shivangi.data.Prefs

val Plum = Color(0xFF7A2E6B)
val Green = Color(0xFF1E6B3A)

private val Light = lightColorScheme(
    primary = Plum, onPrimary = Color.White,
    primaryContainer = Color(0xFFFFD9E6), onPrimaryContainer = Color(0xFF3A0B32),
    secondaryContainer = Color(0xFFFFE3EC), onSecondaryContainer = Color(0xFF3A0B32),
    background = Color(0xFFFFF7F9), onBackground = Color(0xFF241A22),
    surface = Color.White, onSurface = Color(0xFF241A22),
    surfaceVariant = Color(0xFFFFE3EC), onSurfaceVariant = Color(0xFF5E5260),
    outline = Color(0xFFE3CCD8), outlineVariant = Color(0xFFF0DDE5),
)

private val Dark = darkColorScheme(
    primary = Color(0xFFFFADE5), onPrimary = Color(0xFF4A1040),
    primaryContainer = Color(0xFF632557), onPrimaryContainer = Color(0xFFFFD8EE),
    secondaryContainer = Color(0xFF3D2A37), onSecondaryContainer = Color(0xFFFFD8EE),
    background = Color(0xFF19121A), onBackground = Color(0xFFEFDFE9),
    surface = Color(0xFF221A23), onSurface = Color(0xFFEFDFE9),
    surfaceVariant = Color(0xFF34283A), onSurfaceVariant = Color(0xFFD5C2CF),
    outline = Color(0xFF6E5F6A), outlineVariant = Color(0xFF4A3D48),
)

@Composable
fun ShivangiTheme(content: @Composable () -> Unit) {
    val tick by Prefs.changes.collectAsState()
    val dark = when (Prefs.theme.also { tick }) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = Typography(), content = content)
}
