package com.appforge.shivangi.voice

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.appforge.shivangi.data.Languages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/** Listens to one sentence using the phone's speech recognition, in the chosen language. */
object Listener {
    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial
    private val _level = MutableStateFlow(0f)
    /** Mic loudness 0..1 for the listening animation */
    val level: StateFlow<Float> = _level

    sealed class Heard {
        data class Text(val text: String) : Heard()
        data object Nothing : Heard()
        data object NoRecognizer : Heard()
        data object Error : Heard()
    }

    private fun recognizer(c: Context): ComponentName? {
        val list = c.packageManager.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
            .map { ComponentName(it.serviceInfo.packageName, it.serviceInfo.name) }
            .filter { it.packageName != c.packageName }
        return list.firstOrNull { it.packageName == "com.google.android.googlequicksearchbox" }
            ?: list.firstOrNull { it.packageName.startsWith("com.google") }
            ?: list.firstOrNull()
    }

    suspend fun listen(c: Context): Heard = withContext<Heard>(Dispatchers.Main) {
        if (recognizer(c) == null && !SpeechRecognizer.isRecognitionAvailable(c)) return@withContext Heard.NoRecognizer
        _partial.value = ""
        suspendCancellableCoroutine { cont ->
            // When Shivangi is the default assistant Android also points "voice recognition" at her
            // placeholder service, so always pick a real recogniser (Google's first).
            val sr = recognizer(c)?.let { SpeechRecognizer.createSpeechRecognizer(c.applicationContext, it) }
                ?: SpeechRecognizer.createSpeechRecognizer(c.applicationContext)
            fun done(h: Heard) { if (cont.isActive) { _level.value = 0f; sr.destroy(); cont.resume(h) } }
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { _level.value = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    done(if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) Heard.Nothing else Heard.Error)
                }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    done(if (t.isBlank()) Heard.Nothing else Heard.Text(t))
                }
                override fun onPartialResults(r: Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { _partial.value = it }
                }
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            val lang = Languages.current.tag
            sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, c.packageName))
            cont.invokeOnCancellation { runCatching { sr.cancel(); sr.destroy() } }
        }
    }
}
