package com.appforge.shivangi.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.appforge.shivangi.data.Languages
import com.appforge.shivangi.data.Prefs
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale
import java.util.UUID

/** Her voice: the phone's text-to-speech, with events that move her lips. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = CompletableDeferred<Boolean>()
    private val waiting = HashMap<String, CompletableDeferred<Unit>>()

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking
    /** One event per word she says (used for lip movement) */
    val words = MutableSharedFlow<Unit>(extraBufferCapacity = 32)

    fun init(c: Context) {
        if (tts != null) return
        tts = TextToSpeech(c.applicationContext) { status -> ready.complete(status == TextToSpeech.SUCCESS) }.apply {
            setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String) { _speaking.value = true }
                override fun onDone(id: String) { finish(id) }
                @Deprecated("old api") override fun onError(id: String) { finish(id) }
                override fun onError(id: String, code: Int) { finish(id) }
                override fun onStop(id: String, interrupted: Boolean) { finish(id) }
                override fun onRangeStart(id: String, start: Int, end: Int, frame: Int) { words.tryEmit(Unit) }
            })
        }
    }

    private fun finish(id: String) {
        _speaking.value = false
        synchronized(waiting) { waiting.remove(id) }?.complete(Unit)
    }

    /** True if the phone has a voice for this language */
    suspend fun supports(tag: String): Boolean {
        val t = tts ?: return false
        if (!ready.await()) return false
        return t.isLanguageAvailable(Locale.forLanguageTag(tag)) >= TextToSpeech.LANG_AVAILABLE
    }

    /** Speaks and waits until she has finished. */
    suspend fun say(text: String) {
        val t = tts ?: return
        if (text.isBlank() || !ready.await()) return
        val lang = Languages.current
        val loc = Locale.forLanguageTag(lang.tag)
        t.language = loc
        // Prefer a female voice for this language when the phone has one
        runCatching {
            t.voices?.filter { it.locale.language == loc.language && !it.isNetworkConnectionRequired }
                ?.sortedWith(compareByDescending<Voice> { it.name.contains("female", true) || it.name.contains("#female") }.thenByDescending { it.quality })
                ?.firstOrNull()?.let { t.voice = it }
        }
        t.setSpeechRate(Prefs.speechRate)
        t.setPitch(1.08f)
        val id = UUID.randomUUID().toString()
        val done = CompletableDeferred<Unit>()
        synchronized(waiting) { waiting[id] = done }
        _speaking.value = true
        t.speak(clean(text), TextToSpeech.QUEUE_FLUSH, Bundle(), id)
        done.await()
    }

    fun stop() {
        tts?.stop()
        _speaking.value = false
        synchronized(waiting) { waiting.values.forEach { it.complete(Unit) }; waiting.clear() }
    }

    /** Removes markdown symbols so she doesn't read out stars and hashes */
    private fun clean(s: String) = s.replace(Regex("[*#_`>]+"), "").replace(Regex("\\[(.*?)]\\(.*?\\)"), "$1")
}
