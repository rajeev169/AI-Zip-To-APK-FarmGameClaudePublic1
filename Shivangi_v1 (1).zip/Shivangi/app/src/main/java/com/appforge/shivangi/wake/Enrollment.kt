package com.appforge.shivangi.wake

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** "Teach her your voice": records the user saying "Shivangi" a few times. */
class Enrollment(context: Context) {
    private val engine = WakeEngine(context)
    private val samples = mutableListOf<FloatArray>()
    val count get() = samples.size

    /** Records ~2.2 s. Returns true if a good sample was kept. */
    @SuppressLint("MissingPermission")
    suspend fun recordOne(onLevel: (Float) -> Unit): Boolean = withContext(Dispatchers.IO) {
        val total = 16000 * 22 / 10
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096))
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return@withContext false }
        val out = ShortArray(total)
        rec.startRecording()
        var got = 0
        val part = ShortArray(1600)
        while (got < total) {
            val n = rec.read(part, 0, minOf(part.size, total - got)); if (n <= 0) break
            System.arraycopy(part, 0, out, got, n); got += n
            var peak = 0; for (i in 0 until n) peak = maxOf(peak, kotlin.math.abs(part[i].toInt()))
            onLevel((peak / 12000f).coerceIn(0f, 1f))
        }
        rec.stop(); rec.release()
        onLevel(0f)
        val t = engine.templateFrom(out) ?: return@withContext false
        samples.add(t)
        true
    }

    fun save() { engine.saveTemplates(samples.toList()); engine.close() }
    fun discard() { engine.close() }
}
