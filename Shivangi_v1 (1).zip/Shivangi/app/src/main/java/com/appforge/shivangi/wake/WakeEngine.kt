package com.appforge.shivangi.wake

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import com.appforge.shivangi.data.Prefs
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.nio.FloatBuffer
import kotlin.math.sqrt

/**
 * Shivangi's own wake-word engine.
 * Base: the open-source openWakeWord speech features (Apache-2.0), run with ONNX Runtime.
 * On top: "shivangi.onnx" trained by the GitHub trainer, plus the user's own voice samples.
 *
 * Feed it 80 ms chunks (1280 samples, 16 kHz, 16-bit mono).
 */
class WakeEngine(private val context: Context) {
    companion object {
        const val CHUNK = 1280
        private const val MEL_CONTEXT = 1280 + 480
        private const val EMB_FRAMES = 76
        private const val WINDOW = 16
        private const val EMB = 96
        const val TEMPLATE_FILE = "voice_templates.bin"
    }

    private val env = OrtEnvironment.getEnvironment()
    private val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(1) }
    private val mel: OrtSession = env.createSession(asset("wake/melspectrogram.onnx"), opts)
    private val emb: OrtSession = env.createSession(asset("wake/embedding_model.onnx"), opts)
    /** null until the trainer's model is added to the app */
    private val clf: OrtSession? = runCatching { env.createSession(asset("wake/shivangi.onnx"), opts) }.getOrNull()
    val hasTrainedModel get() = clf != null

    private val raw = FloatArray(MEL_CONTEXT)
    private val melFrames = ArrayDeque<FloatArray>()
    private val embFrames = ArrayDeque<FloatArray>()
    private var templates: List<FloatArray> = loadTemplates()
    private var cooldown = 0
    var lastScore = 0f; private set
    var lastSimilarity = 0f; private set

    private fun asset(name: String) = context.assets.open(name).use { it.readBytes() }

    fun reset() { raw.fill(0f); melFrames.clear(); embFrames.clear(); cooldown = 0 }

    fun reloadTemplates() { templates = loadTemplates() }

    /** Adds one chunk; returns the newest 16×96 window when one is ready. */
    private fun push(chunk: ShortArray): FloatArray? {
        System.arraycopy(raw, CHUNK, raw, 0, MEL_CONTEXT - CHUNK)
        for (i in 0 until CHUNK) raw[MEL_CONTEXT - CHUNK + i] = chunk[i].toFloat()
        // Mel spectrogram (8 new frames of 32)
        OnnxTensor.createTensor(env, FloatBuffer.wrap(raw), longArrayOf(1, MEL_CONTEXT.toLong())).use { t ->
            mel.run(mapOf(mel.inputNames.first() to t)).use { r ->
                val fb = (r[0] as OnnxTensor).floatBuffer
                val n = fb.remaining() / 32
                for (f in 0 until n) {
                    val frame = FloatArray(32) { fb.get(f * 32 + it) / 10f + 2f }
                    melFrames.addLast(frame)
                }
            }
        }
        while (melFrames.size > EMB_FRAMES + 24) melFrames.removeFirst()
        if (melFrames.size < EMB_FRAMES) return null
        // Speech embedding of the last 76 mel frames
        val input = FloatArray(EMB_FRAMES * 32)
        val start = melFrames.size - EMB_FRAMES
        for (i in 0 until EMB_FRAMES) System.arraycopy(melFrames[start + i], 0, input, i * 32, 32)
        OnnxTensor.createTensor(env, FloatBuffer.wrap(input), longArrayOf(1, EMB_FRAMES.toLong(), 32, 1)).use { t ->
            emb.run(mapOf(emb.inputNames.first() to t)).use { r ->
                val fb = (r[0] as OnnxTensor).floatBuffer
                embFrames.addLast(FloatArray(EMB) { fb.get(it) })
            }
        }
        while (embFrames.size > WINDOW) embFrames.removeFirst()
        if (embFrames.size < WINDOW) return null
        val w = FloatArray(WINDOW * EMB)
        for (i in 0 until WINDOW) System.arraycopy(embFrames[i], 0, w, i * EMB, EMB)
        return w
    }

    /** Feed a chunk; returns true when "Shivangi" was heard. */
    fun process(chunk: ShortArray): Boolean {
        val w = push(chunk) ?: return false
        if (cooldown > 0) { cooldown--; return false }
        val s = Prefs.sensitivity / 100f
        lastSimilarity = templates.maxOfOrNull { cosine(it, w) } ?: 0f
        val hit = if (clf != null) {
            lastScore = OnnxTensor.createTensor(env, FloatBuffer.wrap(w), longArrayOf(1, WINDOW.toLong(), EMB.toLong())).use { t ->
                clf.run(mapOf(clf.inputNames.first() to t)).use { r -> (r[0] as OnnxTensor).floatBuffer.get(0) }
            }
            val thr = 0.85f - 0.5f * s            // 0.85 (strict) … 0.35 (easy)
            lastScore >= thr || (templates.isNotEmpty() && lastScore >= thr * 0.5f && lastSimilarity >= 0.80f - 0.08f * s)
        } else {
            // No trained model yet: match only against the user's own recordings
            templates.isNotEmpty() && lastSimilarity >= 0.93f - 0.10f * s
        }
        if (hit) { cooldown = 25; embFrames.clear() }
        return hit
    }

    /**
     * Builds a voice sample from one recording of the user saying "Shivangi"
     * (about 2 seconds, 16 kHz). Returns null if it was too quiet.
     */
    fun templateFrom(recording: ShortArray): FloatArray? {
        reset()
        val pad = ShortArray(CHUNK * 20) // 1.6 s of silence so the windows fill up
        val audio = pad + recording + ShortArray(CHUNK * 4)
        val chunks = audio.size / CHUNK
        val rms = FloatArray(chunks)
        val windows = arrayOfNulls<FloatArray>(chunks)
        for (c in 0 until chunks) {
            val part = audio.copyOfRange(c * CHUNK, (c + 1) * CHUNK)
            var sum = 0.0; for (v in part) sum += v * v.toDouble()
            rms[c] = sqrt(sum / CHUNK).toFloat()
            windows[c] = push(part)
        }
        reset()
        val peak = rms.maxOrNull() ?: return null
        if (peak < 500f) return null
        val end = (rms.indices.lastOrNull { rms[it] > peak * 0.25f } ?: return null)
        return windows[(end + 2).coerceAtMost(chunks - 1)] ?: windows.lastOrNull { it != null }
    }

    fun saveTemplates(list: List<FloatArray>) {
        DataOutputStream(File(context.filesDir, TEMPLATE_FILE).outputStream().buffered()).use { out ->
            out.writeInt(list.size)
            list.forEach { t -> out.writeInt(t.size); t.forEach { out.writeFloat(it) } }
        }
        templates = list
    }

    private fun loadTemplates(): List<FloatArray> {
        val f = File(context.filesDir, TEMPLATE_FILE)
        if (!f.exists()) return emptyList()
        return runCatching {
            DataInputStream(f.inputStream().buffered()).use { inp ->
                List(inp.readInt()) { FloatArray(inp.readInt()) { inp.readFloat() } }
            }
        }.getOrDefault(emptyList())
    }

    private fun cosine(a: FloatArray, b: FloatArray): Float {
        var d = 0f; var na = 0f; var nb = 0f
        for (i in a.indices) { d += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        return if (na == 0f || nb == 0f) 0f else d / (sqrt(na) * sqrt(nb))
    }

    fun close() { runCatching { mel.close(); emb.close(); clf?.close() } }
}
