package com.appforge.studio3d.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Animation
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.ThreeSixty
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.ViewInAr
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.FilterCenterFocus
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.studio3d.R
import com.appforge.studio3d.ar.ArActivity
import com.appforge.studio3d.data.Library
import com.appforge.studio3d.data.ModelItem
import com.appforge.studio3d.data.Prefs
import com.appforge.studio3d.engine.EngineController
import com.appforge.studio3d.engine.EngineListener
import com.appforge.studio3d.engine.EngineState
import com.appforge.studio3d.engine.MediaSaver
import org.json.JSONObject
import java.io.File

enum class Tool(val icon: ImageVector, val label: Int) {
    Light(Icons.Rounded.WbSunny, R.string.tool_light),
    Display(Icons.Rounded.Palette, R.string.tool_display),
    Inspect(Icons.Rounded.Straighten, R.string.tool_inspect),
    Parts(Icons.Rounded.Layers, R.string.tool_parts),
    Animate(Icons.Rounded.Animation, R.string.tool_animate),
    Edit(Icons.Rounded.Edit, R.string.tool_edit),
}

/** UI-side copy of the viewer settings, so panels show the right values. */
class ViewerUi(prefs: Prefs) {
    var env by mutableStateOf(prefs.defaultEnv)
    var bg by mutableStateOf("gradient")
    var bgColor by mutableStateOf("#101321")
    var exposure by mutableStateOf(1f)
    var envRotation by mutableStateOf(0f)
    var keyLight by mutableStateOf(1.6f)
    var shadows by mutableStateOf(true)
    var bloom by mutableStateOf(false)
    var ao by mutableStateOf(false)
    var tone by mutableStateOf("aces")
    var mode by mutableStateOf("shaded")
    var grid by mutableStateOf(false)
    var axes by mutableStateOf(false)
    var fov by mutableStateOf(40f)
    var autoRotate by mutableStateOf(prefs.autoRotate)
    var measure by mutableStateOf(false)
    var unit by mutableStateOf(prefs.unit)
    var section by mutableStateOf(false)
    var sectionAxis by mutableStateOf("y")
    var sectionPos by mutableStateOf(0.5f)
    var sectionFlip by mutableStateOf(false)
    var explode by mutableStateOf(0f)
    var speed by mutableStateOf(1f)
    var loop by mutableStateOf("repeat")
    var skeleton by mutableStateOf(false)
    val morphValues = mutableMapOf<String, Float>()
    var metalness by mutableStateOf(0.5f)
    var roughness by mutableStateOf(0.5f)
    var opacity by mutableStateOf(1f)
    var edited by mutableStateOf(false)
}

@Composable
fun ViewerScreen(item: ModelItem?, sample: String?, prefs: Prefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val state = remember { EngineState() }
    val ctl = remember { EngineController() }
    val ui = remember { ViewerUi(prefs) }
    var tool by remember { mutableStateOf<Tool?>(null) }
    var showInfo by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var pendingAr by remember { mutableStateOf(false) }
    var lastSaved by remember { mutableStateOf<Pair<android.net.Uri, String>?>(null) }

    val listener = remember {
        object : EngineListener {
            override fun onBlob(kind: String, name: String, file: File) {
                when (kind) {
                    "ar" -> openAr(ctx, file)
                    else -> {
                        val uri = MediaSaver.saveToPublic(ctx, file, kind)
                        if (uri != null) {
                            lastSaved = uri to MediaSaver.mimeFor(file.name)
                            val msg = when (kind) { "screenshot" -> R.string.saved_screenshot; "video" -> R.string.saved_video; else -> R.string.saved_glb }
                            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                        } else Toast.makeText(ctx, R.string.save_failed, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            override fun onThumbnail(jpeg: ByteArray) { if (item != null) Library.saveThumb(ctx, item.id, jpeg) }
        }
    }

    // initial setup + load
    LaunchedEffect(Unit) {
        val strings = JSONObject()
            .put("loading", ctx.getString(R.string.loading))
            .put("preparing", ctx.getString(R.string.preparing))
            .put("measureHint", ctx.getString(R.string.measure_hint))
        ctl.cmd("init", "strings" to strings, "quality" to prefs.quality, "unit" to prefs.unit, "env" to prefs.defaultEnv, "autoRotate" to prefs.autoRotate)
        if (item != null) ctl.cmd("load", "url" to item.engineUrl(), "name" to item.name, "ext" to item.ext, "size" to item.size)
        else ctl.cmd("sample", "id" to (sample ?: "helmet"))
    }
    LaunchedEffect(state.toastKey) {
        val k = state.toastKey ?: return@LaunchedEffect
        val res = when (k) { "noSkeleton" -> R.string.no_skeleton; "error_video" -> R.string.err_video; "error_export" -> R.string.err_export; else -> R.string.err_generic }
        Toast.makeText(ctx, res, Toast.LENGTH_SHORT).show()
        state.toastKey = null
    }

    StudioTheme("dark") {
        Box(Modifier.fillMaxSize().background(Brand.Night)) {
            EngineView("viewer", state, ctl, listener, Modifier.fillMaxSize())

            // ---------- top bar
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.55f), Color.Transparent)))
                    .statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back), tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text(
                        if (item != null) item.name else sampleTitle(sample),
                        color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    if (state.loaded) Text(
                        statsLine(state), color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp, maxLines = 1,
                    )
                }
                IconButton(onClick = { showInfo = true }, enabled = state.loaded) { Icon(Icons.Rounded.Info, stringResource(R.string.model_info), tint = Color.White) }
                Box {
                    IconButton(onClick = { moreMenu = true }) { Icon(Icons.Rounded.MoreVert, stringResource(R.string.more), tint = Color.White) }
                    DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                        DropdownMenuItem(text = { Text(stringResource(R.string.export_glb)) }, leadingIcon = { Icon(Icons.Rounded.Download, null) },
                            enabled = state.loaded && state.info.kind != "splat",
                            onClick = { moreMenu = false; ctl.cmd("exportGLB") })
                        if (item != null) DropdownMenuItem(text = { Text(stringResource(R.string.share_original)) }, leadingIcon = { Icon(Icons.Rounded.Share, null) },
                            onClick = {
                                moreMenu = false
                                runCatching { MediaSaver.share(ctx, MediaSaver.shareUri(ctx, item.file(ctx)), MediaSaver.mimeFor(item.name), ctx.getString(R.string.share)) }
                            })
                        lastSaved?.let { (uri, mime) ->
                            DropdownMenuItem(text = { Text(stringResource(R.string.share_last)) }, leadingIcon = { Icon(Icons.Rounded.Share, null) },
                                onClick = { moreMenu = false; MediaSaver.share(ctx, uri, mime, ctx.getString(R.string.share)) })
                        }
                    }
                }
            }

            // ---------- right action rail
            Column(
                Modifier.align(Alignment.CenterEnd).padding(end = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                RailButton(Icons.Rounded.ViewInAr, stringResource(R.string.view_in_ar), highlight = true, enabled = state.loaded && state.info.kind != "splat" && state.info.kind != "points") {
                    // GLB files go straight to AR; anything else (or edited models) is converted first.
                    if (item != null && item.ext == "glb" && !ui.edited) openAr(ctx, item.file(ctx))
                    else { pendingAr = true; ctl.cmd("exportAR") }
                }
                RailButton(Icons.Rounded.ThreeSixty, stringResource(R.string.auto_rotate), active = ui.autoRotate) {
                    ui.autoRotate = !ui.autoRotate; ctl.cmd("autoRotate", "on" to ui.autoRotate)
                }
                RailButton(Icons.Rounded.CenterFocusStrong, stringResource(R.string.reset_view)) { ctl.cmd("resetView") }
                RailButton(Icons.Rounded.CameraAlt, stringResource(R.string.screenshot), enabled = state.loaded) { ctl.cmd("screenshot") }
                RailButton(Icons.Rounded.Videocam, stringResource(R.string.video_360), enabled = state.loaded && !state.recording) { ctl.cmd("turntable", "seconds" to 8) }
            }

            // ---------- status chips (measure, selection, recording)
            Column(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 64.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedVisibility(state.recording, enter = fadeIn(), exit = fadeOut()) {
                    Pill(Color(0xFFE53950)) { Text(stringResource(R.string.recording), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                }
                AnimatedVisibility(ui.measure, enter = fadeIn(), exit = fadeOut()) {
                    Pill(Brand.Violet.copy(alpha = 0.92f)) {
                        Text(if (state.measureText.isNotEmpty()) state.measureText else stringResource(R.string.measure_hint), color = Color.White, fontSize = 13.sp)
                    }
                }
                AnimatedVisibility(state.busy, enter = fadeIn(), exit = fadeOut()) {
                    Pill(Color.Black.copy(alpha = 0.7f)) {
                        CircularProgressIndicator(Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.working), color = Color.White, fontSize = 13.sp)
                    }
                }
            }

            // ---------- bottom: selection bar + panel + tool dock
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()) {
                AnimatedVisibility(state.selectedId >= 0 && !ui.measure, enter = fadeIn(), exit = fadeOut()) {
                    SelectionBar(state, ctl, onEdit = { tool = Tool.Edit })
                }
                AnimatedVisibility(tool != null && state.loaded, enter = slideInVertically { it / 2 } + fadeIn(), exit = slideOutVertically { it / 2 } + fadeOut()) {
                    Box(
                        Modifier.padding(horizontal = 10.dp).fillMaxWidth().heightIn(max = 340.dp)
                            .clip(RoundedCornerShape(24.dp)).background(Brand.Panel.copy(alpha = 0.94f))
                    ) {
                        when (tool) {
                            Tool.Light -> LightPanel(ui, ctl)
                            Tool.Display -> DisplayPanel(ui, ctl, state)
                            Tool.Inspect -> InspectPanel(ui, ctl, state)
                            Tool.Parts -> PartsPanel(ctl, state)
                            Tool.Animate -> AnimatePanel(ui, ctl, state)
                            Tool.Edit -> EditPanel(ui, ctl, state)
                            null -> {}
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                ToolDock(tool, enabled = state.loaded, kind = state.info.kind) { t -> tool = if (tool == t) null else t }
                Spacer(Modifier.height(8.dp))
            }

            // ---------- error card
            state.error?.let { code ->
                Column(
                    Modifier.align(Alignment.Center).padding(32.dp).clip(RoundedCornerShape(24.dp)).background(Brand.Panel).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(Icons.Rounded.Close, null, tint = Brand.Pink, modifier = Modifier.size(40.dp))
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(if (code == "unsupported") R.string.err_unsupported else R.string.err_failed), color = Color.White,
                        textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(stringResource(R.string.err_hint), color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
                }
            }

            if (showInfo) InfoSheet(state, ui.unit) { showInfo = false }
        }
    }
}

private fun openAr(ctx: android.content.Context, file: File) {
    ctx.startActivity(Intent(ctx, ArActivity::class.java).putExtra(ArActivity.EXTRA_PATH, file.absolutePath))
}

@Composable
private fun sampleTitle(id: String?) = stringResource(
    when (id) { "robot" -> R.string.sample_robot; "materials" -> R.string.sample_materials; else -> R.string.sample_helmet }
)

@Composable
private fun statsLine(s: EngineState): String {
    val i = s.info
    return if (i.kind == "splat") stringResource(R.string.stats_splats, fmtCount(i.splats))
    else stringResource(R.string.stats_line, fmtCount(i.triangles), i.meshes, i.materials)
}

fun fmtCount(n: Long): String = when {
    n >= 1_000_000 -> String.format("%.1fM", n / 1_000_000.0)
    n >= 10_000 -> String.format("%.0fK", n / 1_000.0)
    n >= 1_000 -> String.format("%.1fK", n / 1_000.0)
    else -> n.toString()
}

@Composable
private fun RailButton(icon: ImageVector, desc: String, active: Boolean = false, highlight: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val bg = when {
        highlight -> Brand.accent
        active -> Brush.linearGradient(listOf(Brand.Violet, Brand.Violet))
        else -> Brush.linearGradient(listOf(Color.Black.copy(alpha = 0.45f), Color.Black.copy(alpha = 0.45f)))
    }
    Box(
        Modifier.size(48.dp).clip(CircleShape).background(bg)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = if (enabled) Color.White else Color.White.copy(alpha = 0.35f)) }
}

@Composable
private fun Pill(color: Color, content: @Composable () -> Unit) {
    Row(
        Modifier.padding(4.dp).clip(RoundedCornerShape(50)).background(color).padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

@Composable
private fun ToolDock(current: Tool?, enabled: Boolean, kind: String, onTool: (Tool) -> Unit) {
    val tools = if (kind == "splat") listOf(Tool.Light, Tool.Inspect) else Tool.entries.toList()
    Row(
        Modifier.padding(horizontal = 10.dp).fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brand.Panel.copy(alpha = 0.92f)).horizontalScroll(rememberScrollState()).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        tools.forEach { t ->
            val sel = current == t
            Column(
                Modifier.clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Brand.Violet.copy(alpha = 0.35f) else Color.Transparent)
                    .clickable(enabled = enabled) { onTool(t) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(t.icon, null, tint = if (sel) Color.White else Color.White.copy(alpha = if (enabled) 0.8f else 0.3f), modifier = Modifier.size(22.dp))
                Spacer(Modifier.height(3.dp))
                Text(stringResource(t.label), color = Color.White.copy(alpha = if (enabled) 0.9f else 0.3f), fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun SelectionBar(state: EngineState, ctl: EngineController, onEdit: () -> Unit) {
    val id = state.selectedId
    val part = state.parts.firstOrNull { it.id == id }
    Row(
        Modifier.padding(horizontal = 10.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Brand.PanelHigh.copy(alpha = 0.95f)).padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(state.selectedName, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (part != null) Text(stringResource(R.string.part_tris, fmtCount(part.tris)), color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
        }
        IconButton(onClick = { ctl.cmd("focus", "id" to id) }) { Icon(Icons.Rounded.FilterCenterFocus, stringResource(R.string.focus), tint = Color.White) }
        IconButton(onClick = { ctl.cmd("isolate", "id" to id) }) { Icon(Icons.Rounded.Visibility, stringResource(R.string.isolate), tint = Color.White) }
        IconButton(onClick = {
            ctl.cmd("partVisible", "id" to id, "visible" to false)
            val i = state.parts.indexOfFirst { it.id == id }
            if (i >= 0) state.parts[i] = state.parts[i].copy(visible = false)
            ctl.cmd("select", "id" to -1); state.selectedId = -1
        }) { Icon(Icons.Rounded.VisibilityOff, stringResource(R.string.hide), tint = Color.White) }
        IconButton(onClick = onEdit) { Icon(Icons.Rounded.Edit, stringResource(R.string.tool_edit), tint = Color.White) }
        IconButton(onClick = { ctl.cmd("select", "id" to -1); state.selectedId = -1 }) { Icon(Icons.Rounded.Close, stringResource(R.string.close), tint = Color.White) }
    }
}
