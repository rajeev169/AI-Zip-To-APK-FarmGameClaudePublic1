# Studio 3D Viewer — by AppForge

All-in-one advanced 3D model viewer for Android (Kotlin + Jetpack Compose, Material 3).

- **Package:** `com.appforge.studio3d` · **Version:** 1.0.0 (code 1) · **minSdk** 26 · **targetSdk** 35
- **Build:** standard Gradle project (AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9). Push this ZIP to your
  "Universal ZIP to APK" GitHub repo — it is detected as `android-gradle` and built with `assembleDebug`.
  For Play Store use your AAB build repo (`bundleRelease`).

## What's inside
| Area | Features |
|---|---|
| Formats | GLB, GLTF (+Draco, KTX2, Meshopt), FBX, OBJ (+MTL), STL, PLY (mesh / point cloud / Gaussian splat), 3MF, USDZ/USDA/USDC, DAE, 3DS, AMF, VRML, PCD, XYZ, SPLAT, KSPLAT, SPZ, and ZIP (model + textures together) |
| Rendering | PBR, 8 HDRI/studio lighting presets, light rotation, exposure, key light, shadows, bloom, ambient occlusion (GTAO), tone mapping (ACES/AgX/Neutral/Filmic), SMAA, 3 quality levels |
| Display modes | Shaded, Wireframe, Shaded+Wire, X-ray, Clay, Matcap, Normals, UV checker, Texture only · grid, axes, 7 camera views, FOV |
| Inspect | Stats (triangles, vertices, meshes, materials, textures, bones, morphs, dimensions, file size), tap-to-measure (m/cm/mm/in/ft), cross-section X/Y/Z with flip, exploded view |
| Parts | Parts list with search, show/hide, isolate, tap-to-select with outline, focus |
| Animation | Clip list, play/pause, timeline scrub, speed 0.25–2×, loop modes, skeleton view, morph-target sliders |
| Edit | Color, metalness, roughness, opacity per part or whole model, rotate 90° on X/Y/Z, reset |
| AR | ARCore via SceneView: place on floor/table, move, pinch-scale, twist-rotate, table size / real size. Non-GLB and edited models are converted to GLB automatically |
| Export & share | Screenshot (PNG → Pictures/Studio3D), 360° turntable video (MP4/WebM → Movies/Studio3D), export as GLB (any format → GLB → Downloads/Studio3D), share original |
| Library | Imported models with auto thumbnails, favorites, search, sort, rename, delete, share |
| App | Live 3D hero on home screen, 3 samples, opens files from Files/Drive/WhatsApp ("Open with"/"Share"), 25 languages (follows phone + picker in Settings), Dark/Light/System theme, adaptive + themed launcher icon |

## Project layout
```
app/src/main/java/com/appforge/studio3d/
  ui/        MainActivity, Home, Viewer, Panels, Settings, Theme, EngineView
  engine/    WebView bridge to the 3D engine, media saving/sharing
  ar/        ArActivity (ARCore + SceneView)
  data/      Library (imported models), Prefs
app/src/main/assets/web/   3D engine (three.js r187, GaussianSplats3D) — fully offline
app/src/main/res/values-*/ 25 languages
i18n/                      translation sources (edit .txt, run `python3 i18n/gen.py`)
store/play_icon_512.png    Play Store icon
```

## Not in v1 (planned for v2)
AI image/text-to-3D, cloud sync, annotations/comments, VR mode.

## Licenses
three.js (MIT), GaussianSplats3D (MIT), SceneView & Filament & ARCore SDK (Apache 2.0).
Samples: "Damaged Helmet" by theblueflame (CC BY 4.0), "Robot Expressive" by Tomás Laulhé (CC0), HDRIs from Poly Haven (CC0).
Credits are shown in Settings → Open-source licenses.
