// Studio 3D Viewer — rendering engine (three.js r187, WebGL2)
// Talks to the Android app through window.Android (JavascriptInterface) and S3D.cmd(json).

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { HDRLoader } from 'three/addons/loaders/HDRLoader.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';
import { OutlinePass } from 'three/addons/postprocessing/OutlinePass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { SMAAPass } from 'three/addons/postprocessing/SMAAPass.js';
import { loadModel, detectKind } from './loaders.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';

// ---------------------------------------------------------------- bridge
const params = new URLSearchParams(location.search);
const MODE = params.get('mode') || 'viewer'; // viewer | hero
const native = window.Android || null;
function post(type, data = {}) {
  const msg = JSON.stringify({ type, ...data });
  if (native && native.postMessage) native.postMessage(msg);
  else console.log('[S3D→]', msg.length > 400 ? msg.slice(0, 400) + '…' : msg);
}
// Big binary payloads go to Android in base64 chunks (keeps the bridge stable).
let chunkSeq = 0;
async function sendBlob(kind, name, blob) {
  const id = 'c' + (++chunkSeq) + '_' + Date.now();
  const buf = new Uint8Array(await blob.arrayBuffer());
  if (!native || !native.chunkBegin) { console.log('[S3D] blob', kind, name, buf.length); window.__lastBlob = { kind, name, size: buf.length }; return; }
  native.chunkBegin(id, kind, name, buf.length);
  const CH = 384 * 1024;
  for (let i = 0; i < buf.length; i += CH) {
    const part = buf.subarray(i, Math.min(i + CH, buf.length));
    let s = ''; for (let j = 0; j < part.length; j += 0x8000) s += String.fromCharCode.apply(null, part.subarray(j, j + 0x8000));
    native.chunkAppend(id, btoa(s));
    if ((i / CH) % 8 === 7) await new Promise(r => setTimeout(r, 0));
  }
  native.chunkEnd(id);
}

let T = { loading: 'Loading…', preparing: 'Preparing…', measureHint: 'Tap two points on the model', unsupported: 'This file type is not supported',
  failed: 'Could not open this model', recording: 'Recording 360° video…', tapAnywhere: 'Tap to select a part' };

// ---------------------------------------------------------------- renderer
const stage = document.getElementById('stage');
const labelsEl = document.getElementById('labels');
if (MODE === 'hero') document.body.classList.add('hero');

const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: true, preserveDrawingBuffer: false, powerPreference: 'high-performance' });
renderer.setClearColor(0x000000, 0);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.localClippingEnabled = true;
stage.appendChild(renderer.domElement);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, 1, 0.01, 200);
camera.position.set(3.2, 2.0, 4.2);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.rotateSpeed = 0.9;
controls.zoomSpeed = 1.0;
controls.panSpeed = 0.8;
controls.minDistance = 0.05;
controls.maxDistance = 60;
controls.autoRotateSpeed = 1.6;
if (MODE === 'hero') { controls.enableZoom = false; controls.enablePan = false; controls.autoRotate = true; controls.autoRotateSpeed = 2.2; }

const pmrem = new THREE.PMREMGenerator(renderer);
const roomEnv = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
scene.environment = roomEnv;

// key light + ground shadow catcher
const keyLight = new THREE.DirectionalLight(0xffffff, 1.6);
keyLight.position.set(3, 6, 4);
keyLight.castShadow = true;
keyLight.shadow.mapSize.set(2048, 2048);
keyLight.shadow.bias = -0.0004;
keyLight.shadow.normalBias = 0.02;
const sc = keyLight.shadow.camera; sc.left = -3; sc.right = 3; sc.top = 3; sc.bottom = -3; sc.near = 0.1; sc.far = 20;
scene.add(keyLight, keyLight.target);
const fillLight = new THREE.HemisphereLight(0xffffff, 0x404060, 0.25);
scene.add(fillLight);

const ground = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.ShadowMaterial({ opacity: 0.32 }));
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; ground.name = '__ground';
scene.add(ground);
const grid = new THREE.GridHelper(6, 24, 0x8b7bff, 0x3a3f5c);
grid.material.transparent = true; grid.material.opacity = 0.55; grid.visible = false;
scene.add(grid);
const axes = new THREE.AxesHelper(1.4); axes.visible = false; scene.add(axes);

// ---------------------------------------------------------------- post-processing
const composer = new EffectComposer(renderer, new THREE.WebGLRenderTarget(1, 1, { type: THREE.HalfFloatType, samples: 4 }));
const renderPass = new RenderPass(scene, camera);
renderPass.clearAlpha = 0;
composer.addPass(renderPass);
const gtao = new GTAOPass(scene, camera, 1, 1);
gtao.enabled = false;
gtao.blendIntensity = 1.0;
composer.addPass(gtao);
const outline = new OutlinePass(new THREE.Vector2(1, 1), scene, camera);
outline.edgeStrength = 4; outline.edgeGlow = 0.6; outline.edgeThickness = 1.5; outline.pulsePeriod = 0;
outline.visibleEdgeColor.set('#9d8cff'); outline.hiddenEdgeColor.set('#3b2f8f');
composer.addPass(outline);
const bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.3, 0.4, 1.0);
bloom.enabled = false;
composer.addPass(bloom);
composer.addPass(new OutputPass());
const smaa = new SMAAPass();
smaa.enabled = false;
composer.addPass(smaa);

// ---------------------------------------------------------------- state
const S = {
  quality: 'high', pixelRatio: 2,
  bgMode: 'gradient', bgColor: '#101321', envId: 'studio', envRotation: 0, envBlur: 0.45,
  displayMode: 'shaded', autoRotate: false,
  model: null, modelRoot: new THREE.Group(), scaleFactor: 1, size: new THREE.Vector3(1, 1, 1), radius: 1,
  meshes: [], mixer: null, clips: [], actions: [], curClip: -1, playing: false, speed: 1, loop: 'repeat',
  morphNames: [], skeleton: null, splat: null, kind: 'mesh',
  measureMode: false, measurePts: [], measures: [], unit: 'm',
  section: { on: false, axis: 'y', pos: 0.5, flip: false },
  explode: 0, selected: -1, info: null, sourceExt: '', sourceName: ''
};
S.modelRoot.name = '__modelRoot';
scene.add(S.modelRoot);
const clipPlane = new THREE.Plane(new THREE.Vector3(0, -1, 0), 0);
const clock = new THREE.Timer();

function setQuality(q) {
  S.quality = q;
  const dpr = window.devicePixelRatio || 1;
  S.pixelRatio = q === 'low' ? Math.min(dpr, 1) : q === 'medium' ? Math.min(dpr, 1.5) : Math.min(dpr, 2.25);
  if (MODE === 'hero') S.pixelRatio = Math.min(dpr, 1.5);
  keyLight.shadow.mapSize.set(q === 'low' ? 1024 : 2048, q === 'low' ? 1024 : 2048);
  if (keyLight.shadow.map) { keyLight.shadow.map.dispose(); keyLight.shadow.map = null; }
  smaa.enabled = q !== 'low';
  resize();
}

function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setPixelRatio(S.pixelRatio);
  renderer.setSize(w, h, false);
  composer.setPixelRatio(S.pixelRatio);
  composer.setSize(w, h);
  camera.aspect = w / Math.max(h, 1);
  camera.updateProjectionMatrix();
}
window.addEventListener('resize', resize);

// ---------------------------------------------------------------- environments
const ENVS = {
  studio: { type: 'room' },
  soft: { type: 'hdr', file: 'hdri/ferndale_studio_04_1k.hdr' },
  mono: { type: 'hdr', file: 'hdri/monochrome_studio_02_1k.hdr' },
  sunset: { type: 'hdr', file: 'hdri/venice_sunset_1k.hdr' },
  sunrise: { type: 'hdr', file: 'hdri/spruit_sunrise_1k.hdr' },
  outdoor: { type: 'hdr', file: 'hdri/quarry_01_1k.hdr' },
  city: { type: 'hdr', file: 'hdri/pedestrian_overpass_1k.hdr' },
  night: { type: 'hdr', file: 'hdri/moonless_golf_1k.hdr' }
};
const envCache = {};
const hdrLoader = new HDRLoader();
async function setEnv(id) {
  const def = ENVS[id] || ENVS.studio;
  S.envId = ENVS[id] ? id : 'studio';
  let tex;
  if (def.type === 'room') tex = roomEnv;
  else if (envCache[id]) tex = envCache[id];
  else {
    const hdr = await hdrLoader.loadAsync(def.file);
    hdr.mapping = THREE.EquirectangularReflectionMapping;
    tex = pmrem.fromEquirectangular(hdr).texture;
    envCache[id] = tex;
    envCache[id + '_raw'] = hdr;
  }
  scene.environment = tex;
  applyBackground();
}
function applyBackground() {
  const bgEl = document.getElementById('bg');
  document.body.classList.toggle('transparent', S.bgMode !== 'gradient' || MODE === 'hero');
  if (S.bgMode === 'env') {
    scene.background = envCache[S.envId + '_raw'] || scene.environment;
    scene.backgroundBlurriness = S.envBlur;
    scene.backgroundIntensity = 1;
  } else if (S.bgMode === 'color') {
    scene.background = new THREE.Color(S.bgColor);
  } else {
    scene.background = null;
  }
  bgEl.style.display = S.bgMode === 'gradient' && MODE !== 'hero' ? 'block' : 'none';
}
function setEnvRotation(deg) {
  S.envRotation = deg;
  const r = THREE.MathUtils.degToRad(deg);
  scene.environmentRotation.set(0, r, 0);
  scene.backgroundRotation.set(0, r, 0);
  placeKeyLight();
}
function placeKeyLight() {
  const r = THREE.MathUtils.degToRad(S.envRotation);
  const d = 5;
  keyLight.position.set(Math.sin(r + 0.6) * d * 0.7, d, Math.cos(r + 0.6) * d * 0.7);
  keyLight.target.position.set(0, 0, 0);
}

// ---------------------------------------------------------------- model load
function disposeObject(o) {
  o.traverse(c => {
    if (c.geometry) c.geometry.dispose();
    const mats = c.material ? (Array.isArray(c.material) ? c.material : [c.material]) : [];
    mats.forEach(m => { for (const k in m) { const v = m[k]; if (v && v.isTexture) v.dispose(); } m.dispose && m.dispose(); });
  });
}
function clearModel() {
  clearMeasures();
  setSelected(-1);
  if (S.skeleton) { scene.remove(S.skeleton); S.skeleton = null; }
  if (S.mixer) { S.mixer.stopAllAction(); S.mixer = null; }
  if (S.splat) { try { S.splat.dispose && S.splat.dispose(); } catch (e) {} }
  S.splat = null;
  while (S.modelRoot.children.length) { const c = S.modelRoot.children[0]; S.modelRoot.remove(c); disposeObject(c); }
  S.modelRoot.position.set(0, 0, 0); S.modelRoot.rotation.set(0, 0, 0); S.modelRoot.scale.set(1, 1, 1);
  S.model = null; S.meshes = []; S.clips = []; S.actions = []; S.curClip = -1; S.morphNames = []; S.explode = 0;
}

const loaderEl = document.getElementById('loader');
function showProgress(p, text) {
  loaderEl.classList.remove('hidden');
  const v = Math.max(0, Math.min(1, p));
  document.getElementById('ringbar').style.strokeDashoffset = String(276.5 * (1 - v));
  document.getElementById('pct').textContent = Math.round(v * 100) + '%';
  document.getElementById('loadtext').textContent = text || T.loading;
}
function hideProgress() { loaderEl.classList.add('hidden'); }

let loadToken = 0;
async function load({ url, name, ext, size }) {
  const token = ++loadToken;
  clearModel();
  S.sourceExt = (ext || '').toLowerCase(); S.sourceName = name || '';
  showProgress(0, T.loading);
  let lastSent = 0;
  const onProgress = (p) => {
    if (token !== loadToken) return;
    showProgress(p, p >= 0.999 ? T.preparing : T.loading);
    const now = performance.now();
    if (now - lastSent > 150) { lastSent = now; post('progress', { p }); }
  };
  try {
    const res = await loadModel({ url, name, ext: S.sourceExt, renderer, onProgress });
    if (token !== loadToken) return;
    if (res.kind === 'splat') await setupSplat(res);
    else setupModel(res);
    hideProgress();
    S.info = buildInfo(res, size);
    post('loaded', { info: S.info, parts: partsList(), clips: S.clips.map((c, i) => ({ i, name: c.name || ('Clip ' + (i + 1)), duration: +c.duration.toFixed(3) })), morphs: S.morphNames, kind: S.kind });
    if (S.clips.length && MODE !== 'hero') playClip(0);
    setTimeout(() => { if (token === loadToken) makeThumbnail(); }, 900);
  } catch (e) {
    console.error(e);
    hideProgress();
    if (token === loadToken) post('error', { code: e && e.code === 'unsupported' ? 'unsupported' : 'failed', message: String(e && e.message || e) });
  }
}

function setupModel(res) {
  S.kind = res.kind;
  const obj = res.object;
  obj.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(obj, true);
  if (box.isEmpty()) throw new Error('Model is empty');
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const maxDim = Math.max(size.x, size.y, size.z) || 1;
  const k = 2.0 / maxDim;
  S.scaleFactor = k;
  S.size.copy(size);
  // centre horizontally, sit on the ground
  obj.position.sub(new THREE.Vector3(center.x, box.min.y, center.z));
  const holder = new THREE.Group(); holder.name = '__holder';
  holder.add(obj);
  holder.scale.setScalar(k);
  S.modelRoot.add(holder);
  S.model = holder;

  S.meshes = [];
  obj.traverse(c => {
    if (c.isMesh || c.isPoints || c.isLine) {
      if (c.isMesh) { c.castShadow = true; c.receiveShadow = true; }
      c.userData.partId = S.meshes.length;
      c.userData.origMat = c.material;
      S.meshes.push(c);
      const mats = Array.isArray(c.material) ? c.material : [c.material];
      mats.forEach(m => { if (m && m.map) m.map.anisotropy = renderer.capabilities.getMaxAnisotropy(); });
    }
  });
  // animation
  S.clips = res.animations || [];
  if (S.clips.length) {
    S.mixer = new THREE.AnimationMixer(obj);
    S.actions = S.clips.map(c => S.mixer.clipAction(c));
  }
  // morph targets
  const names = new Set();
  S.meshes.forEach(m => { if (m.morphTargetDictionary) Object.keys(m.morphTargetDictionary).forEach(n => names.add(n)); });
  S.morphNames = [...names];
  // explode data
  S.modelRoot.updateMatrixWorld(true);
  const mc = new THREE.Box3().setFromObject(S.modelRoot, true).getCenter(new THREE.Vector3());
  S.meshes.forEach(m => {
    const c = new THREE.Box3().setFromObject(m, true).getCenter(new THREE.Vector3());
    m.userData.explodeDir = c.sub(mc);
    m.userData.basePos = m.position.clone();
  });
  applyDisplayMode(S.displayMode);
  applySection();
  frameModel(true);
  fitShadow();
}

async function setupSplat(res) {
  S.kind = 'splat';
  const { DropInViewer } = await import('../vendor/gs3d/index.js');
  const v = new DropInViewer({ gpuAcceleratedSort: false, sharedMemoryForWorkers: false, integerBasedSort: true, sphericalHarmonicsDegree: 0, dynamicScene: false });
  S.splat = v;
  S.modelRoot.add(v);
  await v.addSplatScene(res.url, { showLoadingUI: false, progressiveLoad: false, splatAlphaRemovalThreshold: 5, format: res.format,
    onProgress: (p) => showProgress(Math.min(0.99, (p || 0) / 100), T.loading) });
  // splat bounds
  let box = new THREE.Box3();
  try {
    const mesh = v.viewer.splatMesh; const n = mesh.getSplatCount(); const p = new THREE.Vector3();
    const step = Math.max(1, Math.floor(n / 4000));
    for (let i = 0; i < n; i += step) { mesh.getSplatCenter(i, p); box.expandByPoint(p); }
    S.info_splatCount = n;
  } catch (e) { box.set(new THREE.Vector3(-1, -1, -1), new THREE.Vector3(1, 1, 1)); }
  const size = box.getSize(new THREE.Vector3()); const center = box.getCenter(new THREE.Vector3());
  const maxDim = Math.max(size.x, size.y, size.z) || 1;
  const k = 2.0 / maxDim; S.scaleFactor = k; S.size.copy(size);
  v.scale.setScalar(k);
  v.position.set(-center.x * k, -box.min.y * k, -center.z * k);
  S.model = v; S.meshes = [];
  ground.visible = false;
  frameModel(true);
}

function frameModel(instant) {
  const box = new THREE.Box3().setFromObject(S.modelRoot, true);
  if (box.isEmpty()) return;
  const sphere = box.getBoundingSphere(new THREE.Sphere());
  S.radius = sphere.radius;
  const sz = box.getSize(new THREE.Vector3());
  const vf = THREE.MathUtils.degToRad(camera.fov);
  const hf = 2 * Math.atan(Math.tan(vf / 2) * camera.aspect);
  const halfW = 0.5 * Math.hypot(sz.x, sz.z) * 0.9, halfH = 0.5 * (sz.y + 0.35 * Math.hypot(sz.x, sz.z));
  const depth = 0.5 * Math.hypot(sz.x, sz.z);
  const dist = (Math.max(halfH / Math.tan(vf / 2), halfW / Math.tan(hf / 2)) + depth * 0.6) * (MODE === 'hero' ? 0.92 : 1.12);
  const dir = new THREE.Vector3(0.75, 0.42, 1).normalize();
  const target = sphere.center.clone();
  const pos = target.clone().add(dir.multiplyScalar(dist));
  camera.near = Math.max(0.001, dist / 500); camera.far = dist * 60; camera.updateProjectionMatrix();
  controls.maxDistance = dist * 8; controls.minDistance = dist * 0.02;
  flyTo(pos, target, instant ? 0 : 500);
  grid.scale.setScalar(Math.max(1, sphere.radius / 1.5));
}
function fitShadow() {
  const r = Math.max(1.2, S.radius * 1.4);
  sc.left = -r; sc.right = r; sc.top = r; sc.bottom = -r; sc.far = 30; sc.updateProjectionMatrix();
  ground.visible = S.kind !== 'splat' && S.kind !== 'points';
}

let fly = null;
function flyTo(pos, target, ms) {
  if (!ms) { camera.position.copy(pos); controls.target.copy(target); controls.update(); fly = null; return; }
  fly = { p0: camera.position.clone(), t0: controls.target.clone(), p1: pos.clone(), t1: target.clone(), start: performance.now(), ms };
}
function setView(v) {
  const t = new THREE.Box3().setFromObject(S.modelRoot, true).getCenter(new THREE.Vector3());
  const d = camera.position.distanceTo(controls.target);
  const dirs = { front: [0, 0, 1], back: [0, 0, -1], left: [-1, 0, 0], right: [1, 0, 0], top: [0, 1, 0.0001], bottom: [0, -1, 0.0001], iso: [0.75, 0.55, 1] };
  const dv = new THREE.Vector3(...(dirs[v] || dirs.iso)).normalize().multiplyScalar(d);
  flyTo(t.clone().add(dv), t, 550);
}

// ---------------------------------------------------------------- info / parts
function buildInfo(res, fileSize) {
  let verts = 0, tris = 0, bones = 0;
  const mats = new Set(), texs = new Map();
  S.meshes.forEach(m => {
    const g = m.geometry; if (!g) return;
    const pc = g.attributes.position ? g.attributes.position.count : 0;
    verts += pc;
    if (m.isMesh) tris += g.index ? g.index.count / 3 : pc / 3;
    const ms = Array.isArray(m.userData.origMat) ? m.userData.origMat : [m.userData.origMat];
    ms.forEach(mt => { if (!mt) return; mats.add(mt); for (const k in mt) { const v = mt[k]; if (v && v.isTexture && v.image) texs.set(v.uuid, v); } });
    if (m.isSkinnedMesh && m.skeleton) bones = Math.max(bones, m.skeleton.bones.length);
  });
  let maxTex = 0;
  texs.forEach(t => { const im = t.image; const w = im.width || (im.data && im.data.width) || 0; const h = im.height || 0; maxTex = Math.max(maxTex, w, h); });
  return {
    name: S.sourceName, format: (S.sourceExt || '').toUpperCase(), fileSize: fileSize || 0, kind: S.kind,
    meshes: S.meshes.length, vertices: Math.round(verts), triangles: Math.round(tris), materials: mats.size,
    textures: texs.size, maxTexture: maxTex, animations: S.clips.length, bones, morphs: S.morphNames.length,
    splats: S.kind === 'splat' ? (S.info_splatCount || 0) : 0,
    dimX: +S.size.x.toPrecision(5), dimY: +S.size.y.toPrecision(5), dimZ: +S.size.z.toPrecision(5)
  };
}
function partName(m, i) {
  let n = m.name;
  if (!n || /^mesh_?\d*$/i.test(n)) n = (m.parent && m.parent.name && !m.parent.name.startsWith('__')) ? m.parent.name : '';
  return n || ('Part ' + (i + 1));
}
function partsList() {
  return S.meshes.slice(0, 600).map((m, i) => {
    const g = m.geometry; const pc = g && g.attributes.position ? g.attributes.position.count : 0;
    const t = m.isMesh ? (g.index ? g.index.count / 3 : pc / 3) : 0;
    const mt = Array.isArray(m.userData.origMat) ? m.userData.origMat[0] : m.userData.origMat;
    return { id: i, name: partName(m, i), tris: Math.round(t), visible: m.visible, material: (mt && mt.name) || '' };
  });
}

// ---------------------------------------------------------------- display modes
let checkerTex = null, matcapTex = null;
function getChecker() {
  if (checkerTex) return checkerTex;
  const c = document.createElement('canvas'); c.width = c.height = 512; const g = c.getContext('2d');
  const n = 16, s = 512 / n;
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) { g.fillStyle = (x + y) % 2 ? '#e9e6ff' : '#6f5cff'; g.fillRect(x * s, y * s, s, s); }
  g.fillStyle = '#ff5c8a'; g.font = 'bold 22px sans-serif';
  for (let y = 0; y < n; y += 2) for (let x = 0; x < n; x += 2) g.fillText(String.fromCharCode(65 + (x / 2)) + (y / 2 + 1), x * s + 4, y * s + 22);
  checkerTex = new THREE.CanvasTexture(c); checkerTex.colorSpace = THREE.SRGBColorSpace; checkerTex.wrapS = checkerTex.wrapT = THREE.RepeatWrapping;
  return checkerTex;
}
function getMatcap() {
  if (matcapTex) return matcapTex;
  const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d');
  const gr = g.createRadialGradient(95, 80, 10, 128, 128, 128);
  gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.25, '#d9d2ff'); gr.addColorStop(0.65, '#6b5bd6'); gr.addColorStop(1, '#120d33');
  g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
  matcapTex = new THREE.CanvasTexture(c); matcapTex.colorSpace = THREE.SRGBColorSpace;
  return matcapTex;
}
function modeMaterial(mode, orig, isPoints) {
  if (isPoints) return orig;
  const base = orig || {};
  switch (mode) {
    case 'wire': return new THREE.MeshBasicMaterial({ color: 0x9d8cff, wireframe: true });
    case 'xray': return new THREE.MeshBasicMaterial({ color: 0x55c8ff, transparent: true, opacity: 0.16, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
    case 'normals': return new THREE.MeshNormalMaterial({ side: THREE.DoubleSide });
    case 'clay': return new THREE.MeshStandardMaterial({ color: 0xd8d2c8, roughness: 0.62, metalness: 0.0, side: THREE.DoubleSide });
    case 'matcap': return new THREE.MeshMatcapMaterial({ matcap: getMatcap(), side: THREE.DoubleSide });
    case 'uv': return new THREE.MeshBasicMaterial({ map: getChecker(), side: THREE.DoubleSide });
    case 'texture': return new THREE.MeshBasicMaterial({ map: base.map || null, color: base.map ? 0xffffff : (base.color ? base.color.clone() : 0xcccccc), side: base.side || THREE.FrontSide, transparent: !!base.transparent, alphaTest: base.alphaTest || 0 });
    default: return orig;
  }
}
const wireOverlayMat = new THREE.MeshBasicMaterial({ color: 0x0b0b14, wireframe: true, transparent: true, opacity: 0.45, depthTest: true });
function removeOverlays(m) {
  if (m.userData.overlay) { m.remove(m.userData.overlay); m.userData.overlay = null; }
}
function applyDisplayMode(mode) {
  S.displayMode = mode;
  S.meshes.forEach(m => {
    removeOverlays(m);
    const orig = m.userData.origMat;
    // dispose previous temporary materials
    if (m.userData.tmpMat) { (Array.isArray(m.userData.tmpMat) ? m.userData.tmpMat : [m.userData.tmpMat]).forEach(x => x && x.dispose && x.dispose()); m.userData.tmpMat = null; }
    if (mode === 'shaded' || mode === 'shadedWire' || !m.isMesh) {
      m.material = orig;
    } else {
      const nm = Array.isArray(orig) ? orig.map(o => modeMaterial(mode, o, false)) : modeMaterial(mode, orig, false);
      m.material = nm; m.userData.tmpMat = nm;
    }
    if (mode === 'shadedWire' && m.isMesh) {
      let ov;
      if (m.isSkinnedMesh) { ov = new THREE.SkinnedMesh(m.geometry, wireOverlayMat); ov.bind(m.skeleton, m.bindMatrix); ov.bindMode = m.bindMode; }
      else ov = new THREE.Mesh(m.geometry, wireOverlayMat);
      if (m.morphTargetInfluences) { ov.morphTargetInfluences = m.morphTargetInfluences; ov.morphTargetDictionary = m.morphTargetDictionary; }
      ov.raycast = () => {}; ov.name = '__overlay'; ov.renderOrder = 1;
      m.add(ov); m.userData.overlay = ov;
    }
    m.castShadow = m.isMesh && mode !== 'xray' && mode !== 'wire';
  });
  applySection();
}

// ---------------------------------------------------------------- section (clipping)
function applySection() {
  const sct = S.section;
  const box = new THREE.Box3().setFromObject(S.modelRoot, true);
  if (!box.isEmpty() && sct.on) {
    const ax = sct.axis;
    const n = new THREE.Vector3(ax === 'x' ? 1 : 0, ax === 'y' ? 1 : 0, ax === 'z' ? 1 : 0);
    const v = box.min[ax] + (box.max[ax] - box.min[ax]) * sct.pos;
    if (sct.flip) { clipPlane.normal.copy(n); clipPlane.constant = -v; }
    else { clipPlane.normal.copy(n).negate(); clipPlane.constant = v; }
  }
  const planes = sct.on ? [clipPlane] : null;
  const setMat = (mt) => { if (!mt) return; mt.clippingPlanes = planes; mt.clipShadows = true; if (sct.on) { mt.userData.prevSide ??= mt.side; mt.side = THREE.DoubleSide; } else if (mt.userData.prevSide !== undefined) { mt.side = mt.userData.prevSide; delete mt.userData.prevSide; } mt.needsUpdate = true; };
  S.meshes.forEach(m => {
    [m.material, m.userData.origMat].forEach(mm => (Array.isArray(mm) ? mm : [mm]).forEach(setMat));
  });
  wireOverlayMat.clippingPlanes = planes; wireOverlayMat.needsUpdate = true;
}

// ---------------------------------------------------------------- explode
function applyExplode(a) {
  S.explode = a;
  const k = a * 1.2;
  S.meshes.forEach(m => {
    if (!m.userData.basePos || !m.parent) return;
    const dir = m.userData.explodeDir;
    m.position.copy(m.userData.basePos);
    if (a <= 0 || dir.lengthSq() < 1e-10) return;
    m.parent.updateMatrixWorld(true);
    const worldBase = m.parent.localToWorld(m.userData.basePos.clone());
    const worldTarget = worldBase.clone().add(dir.clone().multiplyScalar(k));
    const localTarget = m.parent.worldToLocal(worldTarget);
    m.position.copy(localTarget);
  });
}

// ---------------------------------------------------------------- selection & parts
function setSelected(id) {
  S.selected = id;
  outline.selectedObjects = id >= 0 && S.meshes[id] ? [S.meshes[id]] : [];
}
function selectPart(id, notify) {
  setSelected(id);
  if (notify) post('selected', { id, name: id >= 0 && S.meshes[id] ? partName(S.meshes[id], id) : '' });
}
function setPartVisible(id, vis) { const m = S.meshes[id]; if (m) m.visible = vis; }
function isolatePart(id) { S.meshes.forEach((m, i) => m.visible = (i === id)); post('parts', { parts: partsList() }); }
function showAllParts() { S.meshes.forEach(m => m.visible = true); post('parts', { parts: partsList() }); }
function focusPart(id) {
  const m = S.meshes[id]; if (!m) return;
  const box = new THREE.Box3().setFromObject(m, true); if (box.isEmpty()) return;
  const sp = box.getBoundingSphere(new THREE.Sphere());
  const dir = camera.position.clone().sub(controls.target).normalize();
  const dist = Math.max(sp.radius / Math.sin(THREE.MathUtils.degToRad(camera.fov) / 2) * 1.2, camera.near * 10);
  flyTo(sp.center.clone().add(dir.multiplyScalar(dist)), sp.center, 550);
}
function editMaterial(id, props) {
  const targets = id >= 0 ? [S.meshes[id]] : S.meshes;
  targets.forEach(m => {
    if (!m || !m.isMesh) return;
    if (!m.userData.editedFrom) {
      m.userData.editedFrom = m.userData.origMat;
      const cl = Array.isArray(m.userData.origMat) ? m.userData.origMat.map(x => x.clone()) : m.userData.origMat.clone();
      m.userData.origMat = cl;
    }
    (Array.isArray(m.userData.origMat) ? m.userData.origMat : [m.userData.origMat]).forEach(mt => {
      if (props.color && mt.color) mt.color.set(props.color);
      if (props.metalness !== undefined && 'metalness' in mt) mt.metalness = props.metalness;
      if (props.roughness !== undefined && 'roughness' in mt) mt.roughness = props.roughness;
      if (props.opacity !== undefined) { mt.opacity = props.opacity; mt.transparent = props.opacity < 1; }
      if (props.emissive !== undefined && mt.emissive) { mt.emissive.set(props.emissiveColor || '#ffffff'); mt.emissiveIntensity = props.emissive; }
      mt.needsUpdate = true;
    });
  });
  applyDisplayMode(S.displayMode);
}
function resetMaterials() {
  S.meshes.forEach(m => { if (m.userData.editedFrom) { m.userData.origMat = m.userData.editedFrom; m.userData.editedFrom = null; } });
  applyDisplayMode(S.displayMode);
}
function rotateModel(axis, deg) {
  if (!S.model) return;
  const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(axis === 'x' ? 1 : 0, axis === 'y' ? 1 : 0, axis === 'z' ? 1 : 0), THREE.MathUtils.degToRad(deg));
  S.modelRoot.quaternion.premultiply(q);
  S.modelRoot.position.set(0, 0, 0);
  S.modelRoot.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(S.modelRoot, true);
  const c = box.getCenter(new THREE.Vector3());
  S.modelRoot.position.set(-c.x, -box.min.y, -c.z);
  S.modelRoot.updateMatrixWorld(true);
  frameModel(false); applySection();
}
function setModelScale(s) {
  S.modelRoot.scale.setScalar(s);
  S.modelRoot.position.set(0, 0, 0); S.modelRoot.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(S.modelRoot, true);
  const c = box.getCenter(new THREE.Vector3());
  S.modelRoot.position.set(-c.x, -box.min.y, -c.z);
  applySection();
}

// ---------------------------------------------------------------- animation
function playClip(i) {
  if (!S.mixer) return;
  S.actions.forEach((a, j) => { if (j !== i) a.fadeOut(0.25); });
  const a = S.actions[i]; if (!a) return;
  S.curClip = i;
  a.reset(); a.enabled = true; a.setEffectiveWeight(1); a.fadeIn(0.25);
  applyLoop(); a.timeScale = S.speed; a.paused = false; a.play();
  S.playing = true;
  post('anim', { clip: i, playing: true, time: 0, duration: S.clips[i].duration });
}
function applyLoop() {
  const a = S.actions[S.curClip]; if (!a) return;
  if (S.loop === 'once') { a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true; }
  else if (S.loop === 'pingpong') a.setLoop(THREE.LoopPingPong, Infinity);
  else a.setLoop(THREE.LoopRepeat, Infinity);
}
function setPlaying(p) {
  const a = S.actions[S.curClip]; if (!a) { if (p && S.actions.length) playClip(0); return; }
  if (p && !a.isRunning() && a.time >= a.getClip().duration - 1e-3) { a.reset(); a.play(); }
  a.paused = !p; S.playing = p;
  post('anim', { clip: S.curClip, playing: p, time: a.time, duration: a.getClip().duration });
}
function seek(t) {
  const a = S.actions[S.curClip]; if (!a || !S.mixer) return;
  if (!a.isRunning()) a.play();
  a.time = Math.max(0, Math.min(t, a.getClip().duration)); a.paused = !S.playing; S.mixer.update(0);
}
function setMorph(name, value) {
  S.meshes.forEach(m => { if (m.morphTargetDictionary && name in m.morphTargetDictionary) m.morphTargetInfluences[m.morphTargetDictionary[name]] = value; });
}
function setSkeleton(on) {
  if (S.skeleton) { scene.remove(S.skeleton); S.skeleton.dispose && S.skeleton.dispose(); S.skeleton = null; }
  if (on && S.model) {
    let has = false; S.model.traverse(o => { if (o.isBone) has = true; });
    if (!has) return false;
    S.skeleton = new THREE.SkeletonHelper(S.model);
    S.skeleton.material.linewidth = 2; S.skeleton.material.depthTest = false; S.skeleton.material.transparent = true;
    scene.add(S.skeleton);
  }
  return true;
}

// ---------------------------------------------------------------- measure
const raycaster = new THREE.Raycaster();
const ndc = new THREE.Vector2();
const markerGeo = new THREE.SphereGeometry(1, 16, 12);
const markerMat = new THREE.MeshBasicMaterial({ color: 0xff5c8a, depthTest: false });
const lineMat = new THREE.LineBasicMaterial({ color: 0xffd25c, depthTest: false });
function pick(clientX, clientY) {
  const r = renderer.domElement.getBoundingClientRect();
  ndc.set(((clientX - r.left) / r.width) * 2 - 1, -((clientY - r.top) / r.height) * 2 + 1);
  raycaster.setFromCamera(ndc, camera);
  raycaster.params.Points.threshold = S.radius * 0.01;
  const targets = S.meshes.filter(m => m.visible);
  const hits = raycaster.intersectObjects(targets, false).filter(h => !S.section.on || clipPlane.distanceToPoint(h.point) >= -1e-6);
  return hits[0] || null;
}
function unitFactor() { return { m: 1, cm: 100, mm: 1000, in: 39.3701, ft: 3.28084 }[S.unit] || 1; }
function fmtDist(modelUnits) { const v = modelUnits * unitFactor(); return (v >= 100 ? v.toFixed(1) : v >= 1 ? v.toFixed(3) : v.toPrecision(3)) + ' ' + S.unit; }
function addMeasurePoint(p) {
  const mk = new THREE.Mesh(markerGeo, markerMat); mk.scale.setScalar(S.radius * 0.012); mk.position.copy(p); mk.renderOrder = 10; scene.add(mk);
  S.measurePts.push({ p: p.clone(), mk });
  if (S.measurePts.length === 2) {
    const [a, b] = S.measurePts;
    const g = new THREE.BufferGeometry().setFromPoints([a.p, b.p]);
    const line = new THREE.Line(g, lineMat); line.renderOrder = 9; scene.add(line);
    const dModel = a.p.distanceTo(b.p) / (S.scaleFactor * S.modelRoot.scale.x);
    const el = document.createElement('div'); el.className = 'mlabel'; labelsEl.appendChild(el);
    const m = { a: a.p, b: b.p, d: dModel, line, mks: [a.mk, b.mk], el };
    el.textContent = fmtDist(dModel);
    S.measures.push(m); S.measurePts = [];
    post('measure', { distance: dModel, text: fmtDist(dModel), count: S.measures.length });
  }
}
function clearMeasures() {
  S.measures.forEach(m => { scene.remove(m.line); m.line.geometry.dispose(); m.mks.forEach(k => scene.remove(k)); m.el.remove(); });
  S.measurePts.forEach(p => scene.remove(p.mk));
  S.measures = []; S.measurePts = [];
}
const tmpV = new THREE.Vector3();
function updateLabels() {
  const w = window.innerWidth, h = window.innerHeight;
  S.measures.forEach(m => {
    tmpV.copy(m.a).add(m.b).multiplyScalar(0.5).project(camera);
    const vis = tmpV.z < 1;
    m.el.style.display = vis ? 'block' : 'none';
    m.el.style.left = ((tmpV.x + 1) / 2 * w) + 'px'; m.el.style.top = ((1 - tmpV.y) / 2 * h) + 'px';
  });
}

// ---------------------------------------------------------------- pointer (tap vs drag)
let down = null, lastTap = 0;
renderer.domElement.addEventListener('pointerdown', e => { if (e.isPrimary) down = { x: e.clientX, y: e.clientY, t: performance.now() }; });
renderer.domElement.addEventListener('pointerup', e => {
  if (!down || !e.isPrimary || MODE === 'hero') return;
  const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y);
  const dt = performance.now() - down.t; down = null;
  if (moved > 8 || dt > 450) return;
  const now = performance.now();
  const hit = pick(e.clientX, e.clientY);
  if (now - lastTap < 300) { // double tap → orbit around that point
    lastTap = 0;
    if (hit) { const d = camera.position.distanceTo(controls.target) * 0.6; const dir = camera.position.clone().sub(controls.target).normalize(); flyTo(hit.point.clone().add(dir.multiplyScalar(d)), hit.point, 450); }
    else frameModel(false);
    return;
  }
  lastTap = now;
  if (S.measureMode) { if (hit) addMeasurePoint(hit.point); return; }
  if (S.kind === 'splat') return;
  selectPart(hit ? hit.object.userData.partId ?? -1 : -1, true);
});
controls.addEventListener('start', () => { if (S.autoRotate && MODE !== 'hero') { /* keep */ } fly = null; });

// ---------------------------------------------------------------- capture
function renderOnce() { controls.update(); composer.render(); }
function snapshot(type = 'image/png', q = 0.95) { renderOnce(); return renderer.domElement.toDataURL(type, q); }
function dataUrlToBlob(u) { const [h, b] = u.split(','); const mime = h.match(/:(.*?);/)[1]; const bin = atob(b); const a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Blob([a], { type: mime }); }
async function screenshot() {
  const prev = outline.selectedObjects; outline.selectedObjects = [];
  let blob;
  if (S.bgMode === 'gradient') { // bake the gradient into the picture
    const src = renderer.domElement; renderOnce();
    const c = document.createElement('canvas'); c.width = src.width; c.height = src.height; const g = c.getContext('2d');
    const gr = g.createRadialGradient(c.width / 2, c.height * 0.2, 0, c.width / 2, c.height * 0.2, Math.max(c.width, c.height) * 0.9);
    gr.addColorStop(0, '#2a2f4a'); gr.addColorStop(0.55, '#14172a'); gr.addColorStop(1, '#07080f');
    g.fillStyle = gr; g.fillRect(0, 0, c.width, c.height); g.drawImage(src, 0, 0);
    blob = dataUrlToBlob(c.toDataURL('image/png'));
  } else blob = dataUrlToBlob(snapshot());
  outline.selectedObjects = prev;
  await sendBlob('screenshot', (S.sourceName || 'model').replace(/\.[^.]+$/, '') + '_' + Date.now() + '.png', blob);
}
function makeThumbnail() {
  try {
    const prev = outline.selectedObjects; outline.selectedObjects = [];
    renderOnce();
    const src = renderer.domElement;
    const c = document.createElement('canvas'); c.width = c.height = 320; const g = c.getContext('2d');
    const gr = g.createLinearGradient(0, 0, 0, 320); gr.addColorStop(0, '#262a45'); gr.addColorStop(1, '#0c0e1a');
    g.fillStyle = gr; g.fillRect(0, 0, 320, 320);
    const s = Math.min(src.width, src.height); g.drawImage(src, (src.width - s) / 2, (src.height - s) / 2, s, s, 0, 0, 320, 320);
    outline.selectedObjects = prev;
    const u = c.toDataURL('image/jpeg', 0.82);
    if (native && native.thumbnail) native.thumbnail(u.split(',')[1]); else window.__thumb = u.length;
  } catch (e) { console.warn('thumb', e); }
}
let recording = null;
async function turntable(seconds = 8) {
  if (recording) return;
  const canvas = renderer.domElement;
  const types = ['video/mp4;codecs=avc1', 'video/mp4', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
  const mime = types.find(t => window.MediaRecorder && MediaRecorder.isTypeSupported(t));
  if (!mime) { post('error', { code: 'video', message: 'MediaRecorder not supported' }); return; }
  const stream = canvas.captureStream(30);
  const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 8_000_000 });
  const parts = []; rec.ondataavailable = e => { if (e.data && e.data.size) parts.push(e.data); };
  const done = new Promise(r => rec.onstop = r);
  const prevSel = outline.selectedObjects; outline.selectedObjects = [];
  const target = controls.target.clone(); const off = camera.position.clone().sub(target);
  const prevAuto = controls.autoRotate; controls.autoRotate = false;
  const prevBg = S.bgMode; if (S.bgMode === 'gradient') { S.bgMode = 'color'; S.bgColor = '#14172a'; applyBackground(); }
  recording = { start: performance.now(), ms: seconds * 1000, target, off };
  post('recording', { on: true, seconds });
  rec.start(250);
  await new Promise(r => { recording.finish = r; });
  rec.stop(); await done;
  controls.autoRotate = prevAuto; outline.selectedObjects = prevSel;
  if (prevBg === 'gradient') { S.bgMode = 'gradient'; applyBackground(); }
  recording = null;
  post('recording', { on: false });
  const blob = new Blob(parts, { type: mime.split(';')[0] });
  const ext = mime.includes('mp4') ? 'mp4' : 'webm';
  await sendBlob('video', (S.sourceName || 'model').replace(/\.[^.]+$/, '') + '_360_' + Date.now() + '.' + ext, blob);
}

async function exportGLB(kind = 'glb') {
  if (!S.model || S.kind === 'splat') { post('error', { code: 'export', message: 'Nothing to export' }); return; }
  const prevMode = S.displayMode, prevExplode = S.explode, prevSection = S.section.on;
  if (prevMode !== 'shaded') applyDisplayMode('shaded');
  if (prevExplode) applyExplode(0);
  if (prevSection) { S.section.on = false; applySection(); }
  try {
    post('progress', { p: 0.2, exporting: true });
    const exporter = new GLTFExporter();
    const root = S.modelRoot; // includes orientation / scale fixes
    const saved = { p: root.position.clone(), q: root.quaternion.clone(), s: root.scale.clone() };
    const holder = S.model; const hs = holder.scale.clone();
    holder.scale.setScalar(1); root.updateMatrixWorld(true); // export in original units
    const anims = S.clips;
    const result = await exporter.parseAsync(root, { binary: true, animations: anims, onlyVisible: true, maxTextureSize: kind === 'ar' ? 2048 : 4096 });
    holder.scale.copy(hs); root.position.copy(saved.p); root.quaternion.copy(saved.q); root.scale.copy(saved.s); root.updateMatrixWorld(true);
    const blob = new Blob([result], { type: 'model/gltf-binary' });
    await sendBlob(kind, (S.sourceName || 'model').replace(/\.[^.]+$/, '') + '.glb', blob);
  } catch (e) {
    console.error(e); post('error', { code: 'export', message: String(e && e.message || e) });
  } finally {
    if (prevMode !== 'shaded') applyDisplayMode(prevMode);
    if (prevExplode) applyExplode(prevExplode);
    if (prevSection) { S.section.on = true; applySection(); }
  }
}

// ---------------------------------------------------------------- samples
async function loadSample(id) {
  if (id === 'helmet') return load({ url: 'models/helmet/DamagedHelmet.gltf', name: 'Sci-Fi Helmet.gltf', ext: 'gltf', size: 3770000 });
  if (id === 'robot') return load({ url: 'models/robot.glb', name: 'Robot.glb', ext: 'glb', size: 463988 });
  if (id === 'materials') {
    const token = ++loadToken; clearModel(); S.sourceExt = 'demo'; S.sourceName = 'Material Lab';
    const g = new THREE.Group();
    const geo = new THREE.SphereGeometry(0.42, 64, 48);
    const cols = ['#ff5c8a', '#ffb35c', '#ffe45c', '#5cffb0', '#5cc8ff', '#9d8cff'];
    for (let r = 0; r < 4; r++) for (let c = 0; c < 6; c++) {
      const m = new THREE.Mesh(geo, new THREE.MeshPhysicalMaterial({ color: cols[c], metalness: r / 3, roughness: c / 5 * 0.9 + 0.05, clearcoat: r === 0 ? 1 : 0, clearcoatRoughness: 0.08 }));
      m.material.name = `metal ${Math.round(r / 3 * 100)}% · rough ${Math.round((c / 5 * 0.9 + 0.05) * 100)}%`;
      m.name = m.material.name; m.position.set((c - 2.5) * 1.0, 0.45 + (3 - r) * 1.0, 0); g.add(m);
    }
    const knot = new THREE.Mesh(new THREE.TorusKnotGeometry(0.7, 0.24, 300, 48), new THREE.MeshPhysicalMaterial({ color: '#ffffff', metalness: 0, roughness: 0.05, transmission: 1, thickness: 0.8, ior: 1.5 }));
    knot.name = 'Glass knot'; knot.position.set(0, 1.6, -2.2); g.add(knot);
    if (token !== loadToken) return;
    setupModel({ kind: 'mesh', object: g, animations: [] });
    S.info = buildInfo({}, 0);
    post('loaded', { info: S.info, parts: partsList(), clips: [], morphs: [], kind: S.kind });
    setTimeout(makeThumbnail, 700);
  }
}

// ---------------------------------------------------------------- command dispatcher
const api = {
  init(d) { if (d.strings) T = Object.assign(T, d.strings); if (d.quality) setQuality(d.quality); if (d.unit) S.unit = d.unit; if (d.env) setEnv(d.env); if (d.autoRotate !== undefined) api.autoRotate({ on: d.autoRotate }); },
  load(d) { return load(d); },
  sample(d) { return loadSample(d.id); },
  env(d) { return setEnv(d.id); },
  envRotation(d) { setEnvRotation(d.deg); },
  background(d) { S.bgMode = d.mode || S.bgMode; if (d.color) S.bgColor = d.color; if (d.blur !== undefined) S.envBlur = d.blur; applyBackground(); },
  exposure(d) { renderer.toneMappingExposure = d.value; },
  toneMapping(d) { renderer.toneMapping = { aces: THREE.ACESFilmicToneMapping, agx: THREE.AgXToneMapping, neutral: THREE.NeutralToneMapping, filmic: THREE.CineonToneMapping, none: THREE.NoToneMapping }[d.id] ?? THREE.ACESFilmicToneMapping; },
  keyLight(d) { if (d.intensity !== undefined) keyLight.intensity = d.intensity; if (d.color) keyLight.color.set(d.color); },
  shadows(d) { keyLight.castShadow = !!d.on; ground.material.opacity = d.on ? 0.32 : 0; if (d.opacity !== undefined) ground.material.opacity = d.opacity; },
  bloom(d) { bloom.enabled = !!d.on; if (d.strength !== undefined) bloom.strength = d.strength; },
  ao(d) { gtao.enabled = !!d.on; },
  quality(d) { setQuality(d.id); },
  displayMode(d) { if (S.kind !== 'splat') applyDisplayMode(d.id); },
  autoRotate(d) { S.autoRotate = !!d.on; controls.autoRotate = S.autoRotate || MODE === 'hero'; },
  resetView() { frameModel(false); },
  view(d) { setView(d.id); },
  fov(d) { camera.fov = d.value; camera.updateProjectionMatrix(); },
  grid(d) { grid.visible = !!d.on; },
  axes(d) { axes.visible = !!d.on; axes.scale.setScalar(Math.max(1, S.radius)); },
  measureMode(d) { S.measureMode = !!d.on; if (!d.on) { S.measurePts.forEach(p => scene.remove(p.mk)); S.measurePts = []; } else selectPart(-1, true); },
  clearMeasures() { clearMeasures(); post('measure', { distance: 0, text: '', count: 0 }); },
  unit(d) { S.unit = d.id; S.measures.forEach(m => m.el.textContent = fmtDist(m.d)); },
  section(d) { Object.assign(S.section, d); applySection(); },
  explode(d) { applyExplode(d.value); },
  partVisible(d) { setPartVisible(d.id, d.visible); },
  isolate(d) { isolatePart(d.id); },
  showAll() { showAllParts(); },
  select(d) { selectPart(d.id, false); if (d.focus) focusPart(d.id); },
  focus(d) { focusPart(d.id); },
  editMaterial(d) { editMaterial(d.id ?? -1, d); },
  resetMaterials() { resetMaterials(); },
  rotateModel(d) { rotateModel(d.axis, d.deg); },
  scaleModel(d) { setModelScale(d.value); },
  playClip(d) { playClip(d.i); },
  play(d) { setPlaying(!!d.on); },
  seek(d) { seek(d.time); },
  speed(d) { S.speed = d.value; const a = S.actions[S.curClip]; if (a) a.timeScale = d.value; },
  loop(d) { S.loop = d.id; applyLoop(); },
  morph(d) { setMorph(d.name, d.value); },
  skeleton(d) { const ok = setSkeleton(!!d.on); if (!ok) post('toast', { key: 'noSkeleton' }); },
  screenshot() { return screenshot(); },
  turntable(d) { return turntable(d.seconds || 8); },
  exportGLB() { return exportGLB('glb'); },
  exportAR() { return exportGLB('ar'); },
  thumbnail() { makeThumbnail(); },
  pause(d) { paused = !!d.on; if (!paused) clock.update(); }
};
let paused = false;
window.S3D = {
  cmd(msg) {
    try { const d = typeof msg === 'string' ? JSON.parse(msg) : msg; const f = api[d.cmd]; if (f) return f(d); console.warn('unknown cmd', d.cmd); }
    catch (e) { console.error('cmd failed', e); post('error', { code: 'cmd', message: String(e && e.message || e) }); }
  },
  _state: S, _scene: scene, _api: api, detectKind
};

// ---------------------------------------------------------------- loop
let lastAnimPost = 0;
function tick() {
  requestAnimationFrame(tick);
  if (paused) return;
  clock.update(); const dt = Math.min(clock.getDelta(), 0.1);
  if (fly) {
    const t = Math.min(1, (performance.now() - fly.start) / fly.ms); const e = 1 - Math.pow(1 - t, 3);
    camera.position.lerpVectors(fly.p0, fly.p1, e); controls.target.lerpVectors(fly.t0, fly.t1, e);
    if (t >= 1) fly = null;
  }
  if (recording) {
    const t = Math.min(1, (performance.now() - recording.start) / recording.ms);
    const ang = t * Math.PI * 2;
    const o = recording.off.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), ang);
    camera.position.copy(recording.target).add(o); controls.target.copy(recording.target);
    if (t >= 1 && recording.finish) { const f = recording.finish; recording.finish = null; setTimeout(f, 120); }
  }
  controls.update(dt);
  if (S.mixer) {
    S.mixer.update(dt);
    const now = performance.now();
    if (S.playing && now - lastAnimPost > 200 && S.actions[S.curClip]) { lastAnimPost = now; post('animTime', { time: S.actions[S.curClip].time }); }
  }
  if (S.splat) { /* drop-in viewer updates itself on render */ }
  updateLabels();
  composer.render(dt);
}

setQuality(MODE === 'hero' ? 'medium' : 'high');
placeKeyLight();
applyBackground();
resize();
tick();
post('ready', { mode: MODE, webgl2: renderer.capabilities.isWebGL2, maxTexture: renderer.capabilities.maxTextureSize });
if (MODE === 'hero') { setEnv('sunset').then(() => { bloom.enabled = true; bloom.strength = 0.32; loadSample('helmet'); }); }
const autoload = params.get('sample'); if (autoload && MODE !== 'hero') loadSample(autoload);
