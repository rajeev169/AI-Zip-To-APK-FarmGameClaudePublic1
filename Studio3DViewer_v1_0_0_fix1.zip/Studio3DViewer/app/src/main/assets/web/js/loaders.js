// Studio 3D Viewer — format loaders. Every loader is imported lazily so opening a GLB never pays for FBX code.
import * as THREE from 'three';

const MESH_EXT = ['glb', 'gltf', 'obj', 'stl', 'fbx', 'ply', '3mf', 'usdz', 'usda', 'usdc', 'usd', 'dae', '3ds', 'amf', 'wrl', 'vrml', 'pcd', 'xyz'];
const SPLAT_EXT = ['splat', 'ksplat', 'spz'];
const MAIN_PRIORITY = ['glb', 'gltf', 'fbx', 'obj', 'dae', 'usdz', 'usda', 'usdc', 'usd', '3mf', 'stl', 'ply', '3ds', 'amf', 'wrl', 'vrml', 'splat', 'ksplat', 'spz', 'pcd', 'xyz'];

export function detectKind(ext) {
  ext = (ext || '').toLowerCase();
  if (SPLAT_EXT.includes(ext)) return 'splat';
  if (MESH_EXT.includes(ext) || ext === 'zip') return 'mesh';
  return 'unknown';
}
function unsupported() { const e = new Error('unsupported'); e.code = 'unsupported'; return e; }

let ktx2 = null, draco = null;
async function gltfLoader(manager, renderer) {
  const { GLTFLoader } = await import('three/addons/loaders/GLTFLoader.js');
  const { DRACOLoader } = await import('three/addons/loaders/DRACOLoader.js');
  const { KTX2Loader } = await import('three/addons/loaders/KTX2Loader.js');
  const { MeshoptDecoder } = await import('three/addons/libs/meshopt_decoder.module.js');
  const l = new GLTFLoader(manager);
  if (!draco) { draco = new DRACOLoader(); draco.setDecoderPath('vendor/three/addons/libs/draco/gltf/'); }
  if (!ktx2) { ktx2 = new KTX2Loader(); ktx2.setTranscoderPath('vendor/three/addons/libs/basis/'); ktx2.detectSupport(renderer); }
  l.setDRACOLoader(draco); l.setKTX2Loader(ktx2); l.setMeshoptDecoder(MeshoptDecoder);
  return l;
}

function defaultMaterial(geom) {
  const hasColor = !!geom.attributes.color;
  return new THREE.MeshStandardMaterial({ color: hasColor ? 0xffffff : 0xb9bed1, vertexColors: hasColor, roughness: 0.48, metalness: 0.08, side: THREE.DoubleSide });
}
function geometryToObject(geom, name) {
  if (!geom.index && geom.attributes.position && !geom.attributes.normal && geom.attributes.position.count % 3 !== 0) {
    return pointsFrom(geom, name);
  }
  if (!geom.attributes.normal) geom.computeVertexNormals();
  const m = new THREE.Mesh(geom, defaultMaterial(geom)); m.name = name || 'Mesh';
  return m;
}
function pointsFrom(geom, name) {
  const hasColor = !!geom.attributes.color;
  geom.computeBoundingSphere();
  const r = geom.boundingSphere ? geom.boundingSphere.radius : 1;
  const p = new THREE.Points(geom, new THREE.PointsMaterial({ size: r * 0.004, vertexColors: hasColor, color: hasColor ? 0xffffff : 0x9d8cff, sizeAttenuation: true }));
  p.name = name || 'Point cloud';
  return p;
}
async function fetchBuf(url, onProgress) {
  const res = await fetch(url);
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const total = +res.headers.get('content-length') || 0;
  if (!res.body || !total) { const b = await res.arrayBuffer(); onProgress(1); return b; }
  const reader = res.body.getReader(); const chunks = []; let got = 0;
  for (;;) { const { done, value } = await reader.read(); if (done) break; chunks.push(value); got += value.length; onProgress(Math.min(0.98, got / total)); }
  const out = new Uint8Array(got); let o = 0; chunks.forEach(c => { out.set(c, o); o += c.length; });
  onProgress(1);
  return out.buffer;
}
function plyHeader(buf) {
  const head = new TextDecoder().decode(new Uint8Array(buf, 0, Math.min(buf.byteLength, 4096)));
  const end = head.indexOf('end_header');
  return end >= 0 ? head.slice(0, end) : head;
}

// ---- ZIP: gltf/obj + textures packed together. Files become blob URLs resolved by name.
async function openZip(url, onProgress) {
  const { unzipSync } = await import('three/addons/libs/fflate.module.js');
  const buf = await fetchBuf(url, p => onProgress(p * 0.6));
  const files = unzipSync(new Uint8Array(buf));
  const map = new Map(); const entries = [];
  for (const path in files) {
    if (path.endsWith('/') || path.startsWith('__MACOSX')) continue;
    const blobUrl = URL.createObjectURL(new Blob([files[path]]));
    const base = path.split('/').pop().toLowerCase();
    map.set(path.toLowerCase(), blobUrl); map.set(base, blobUrl);
    try { map.set(decodeURIComponent(base), blobUrl); } catch (e) {}
    entries.push({ path, ext: base.split('.').pop(), size: files[path].length });
  }
  let main = null;
  for (const ext of MAIN_PRIORITY) { const c = entries.filter(e => e.ext === ext).sort((a, b) => b.size - a.size)[0]; if (c) { main = c; break; } }
  if (!main) throw unsupported();
  const manager = new THREE.LoadingManager();
  manager.setURLModifier(u => {
    if (u.startsWith('blob:') || u.startsWith('data:')) return u;
    let clean = u.split('?')[0].replace(/\\/g, '/');
    try { clean = decodeURIComponent(clean); } catch (e) {}
    const lower = clean.toLowerCase();
    const key = lower.replace(/^zip:\/\/main\//, '');
    return map.get(key) || map.get(lower.split('/').pop()) || u;
  });
  const mtl = entries.find(e => e.ext === 'mtl');
  return { mainUrl: 'zip://main/' + main.path, ext: main.ext, manager, mtlUrl: mtl ? 'zip://main/' + mtl.path : null, splatBlob: SPLAT_EXT.includes(main.ext) || main.ext === 'ply' ? map.get(main.path.toLowerCase()) : null };
}

export async function loadModel({ url, name, ext, renderer, onProgress }) {
  ext = (ext || (name || url).split('.').pop() || '').toLowerCase();
  let manager = new THREE.LoadingManager();
  let mtlUrl = null;
  let base = 0, span = 1;
  const prog = (p) => onProgress(base + span * p);
  if (ext === 'zip') {
    const z = await openZip(url, onProgress);
    manager = z.manager; ext = z.ext; mtlUrl = z.mtlUrl; base = 0.6; span = 0.4;
    if (z.splatBlob && SPLAT_EXT.includes(ext)) return { kind: 'splat', url: z.splatBlob, format: splatFormat(ext) };
    url = z.mainUrl;
    if (ext === 'ply') url = manager.resolveURL(url);
  }
  const xhrProg = (e) => { if (e && e.total) prog(Math.min(0.99, e.loaded / e.total)); };

  if (SPLAT_EXT.includes(ext)) return { kind: 'splat', url, format: splatFormat(ext) };

  switch (ext) {
    case 'glb': case 'gltf': {
      const l = await gltfLoader(manager, renderer);
      const g = await l.loadAsync(url, xhrProg);
      const obj = g.scene || g.scenes[0];
      return { kind: 'mesh', object: obj, animations: g.animations || [] };
    }
    case 'fbx': {
      const { FBXLoader } = await import('three/addons/loaders/FBXLoader.js');
      const obj = await new FBXLoader(manager).loadAsync(url, xhrProg);
      obj.traverse(c => { if (c.isMesh) { const ms = Array.isArray(c.material) ? c.material : [c.material]; ms.forEach(m => { if (m && m.map) m.map.colorSpace = THREE.SRGBColorSpace; }); } });
      return { kind: 'mesh', object: obj, animations: obj.animations || [] };
    }
    case 'obj': {
      const { OBJLoader } = await import('three/addons/loaders/OBJLoader.js');
      const l = new OBJLoader(manager);
      if (mtlUrl) {
        const { MTLLoader } = await import('three/addons/loaders/MTLLoader.js');
        try { const mats = await new MTLLoader(manager).loadAsync(mtlUrl); mats.preload(); l.setMaterials(mats); } catch (e) { console.warn('mtl', e); }
      }
      const obj = await l.loadAsync(url, xhrProg);
      obj.traverse(c => {
        if (c.isMesh) {
          const ms = Array.isArray(c.material) ? c.material : [c.material];
          const fixed = ms.map(m => (!mtlUrl || !m) ? defaultMaterial(c.geometry) : m);
          c.material = Array.isArray(c.material) ? fixed : fixed[0];
          if (!c.geometry.attributes.normal) c.geometry.computeVertexNormals();
        }
      });
      return { kind: 'mesh', object: obj, animations: [] };
    }
    case 'stl': {
      const { STLLoader } = await import('three/addons/loaders/STLLoader.js');
      const geom = await new STLLoader(manager).loadAsync(url, xhrProg);
      const m = geometryToObject(geom, (name || 'STL').replace(/\.[^.]+$/, ''));
      if (geom.hasColors) { m.material.vertexColors = true; m.material.color.set(0xffffff); }
      return { kind: 'mesh', object: m, animations: [] };
    }
    case 'ply': {
      const buf = await fetchBuf(url, prog);
      const header = plyHeader(buf);
      if (/property\s+\w+\s+f_dc_0/.test(header) || /element\s+chunk/.test(header)) {
        const blobUrl = URL.createObjectURL(new Blob([buf]));
        return { kind: 'splat', url: blobUrl, format: 2 };
      }
      const { PLYLoader } = await import('three/addons/loaders/PLYLoader.js');
      const geom = new PLYLoader().parse(buf);
      const faces = /element\s+face\s+(\d+)/.exec(header);
      const hasFaces = faces && +faces[1] > 0;
      const obj = hasFaces ? geometryToObject(geom, (name || 'PLY').replace(/\.[^.]+$/, '')) : pointsFrom(geom, name);
      return { kind: hasFaces ? 'mesh' : 'points', object: obj, animations: [] };
    }
    case '3mf': {
      const { ThreeMFLoader } = await import('three/addons/loaders/3MFLoader.js');
      const obj = await new ThreeMFLoader(manager).loadAsync(url, xhrProg);
      obj.rotation.x = -Math.PI / 2; // 3MF is Z-up
      const wrap = new THREE.Group(); wrap.add(obj);
      return { kind: 'mesh', object: wrap, animations: [] };
    }
    case 'usdz': case 'usda': case 'usdc': case 'usd': {
      const { USDLoader } = await import('three/addons/loaders/USDLoader.js');
      const obj = await new USDLoader(manager).loadAsync(url, xhrProg);
      return { kind: 'mesh', object: obj, animations: obj.animations || [] };
    }
    case 'dae': {
      const { ColladaLoader } = await import('three/addons/loaders/ColladaLoader.js');
      const c = await new ColladaLoader(manager).loadAsync(url, xhrProg);
      return { kind: 'mesh', object: c.scene, animations: c.scene.animations || [] };
    }
    case '3ds': {
      const { TDSLoader } = await import('three/addons/loaders/TDSLoader.js');
      const obj = await new TDSLoader(manager).loadAsync(url, xhrProg);
      obj.rotation.x = -Math.PI / 2;
      const wrap = new THREE.Group(); wrap.add(obj);
      return { kind: 'mesh', object: wrap, animations: [] };
    }
    case 'amf': {
      const { AMFLoader } = await import('three/addons/loaders/AMFLoader.js');
      const obj = await new AMFLoader(manager).loadAsync(url, xhrProg);
      obj.rotation.x = -Math.PI / 2;
      const wrap = new THREE.Group(); wrap.add(obj);
      return { kind: 'mesh', object: wrap, animations: [] };
    }
    case 'wrl': case 'vrml': {
      const { VRMLLoader } = await import('three/addons/loaders/VRMLLoader.js');
      const obj = await new VRMLLoader(manager).loadAsync(url, xhrProg);
      return { kind: 'mesh', object: obj, animations: [] };
    }
    case 'pcd': {
      const { PCDLoader } = await import('three/addons/loaders/PCDLoader.js');
      const pts = await new PCDLoader(manager).loadAsync(url, xhrProg);
      pts.geometry.computeBoundingSphere();
      pts.material.size = pts.geometry.boundingSphere.radius * 0.004;
      return { kind: 'points', object: pts, animations: [] };
    }
    case 'xyz': {
      const { XYZLoader } = await import('three/addons/loaders/XYZLoader.js');
      const geom = await new XYZLoader(manager).loadAsync(url, xhrProg);
      return { kind: 'points', object: pointsFrom(geom, name), animations: [] };
    }
    default:
      throw unsupported();
  }
}
function splatFormat(ext) { return { splat: 0, ksplat: 1, ply: 2, spz: 3 }[ext]; }
