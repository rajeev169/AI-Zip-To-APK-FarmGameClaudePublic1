package com.appforge.studio3d.ar

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.studio3d.R
import com.appforge.studio3d.ui.Brand
import com.appforge.studio3d.ui.StudioTheme
import com.google.android.filament.Engine
import com.google.ar.core.Anchor
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.Plane
import com.google.ar.core.TrackingFailureReason
import io.github.sceneview.ar.ARScene
import io.github.sceneview.ar.arcore.createAnchorOrNull
import io.github.sceneview.ar.arcore.getUpdatedPlanes
import io.github.sceneview.ar.arcore.isValid
import io.github.sceneview.ar.getDescription
import io.github.sceneview.ar.node.AnchorNode
import io.github.sceneview.ar.rememberARCameraNode
import io.github.sceneview.loaders.ModelLoader
import io.github.sceneview.math.Position
import io.github.sceneview.node.ModelNode
import io.github.sceneview.rememberCollisionSystem
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberModelLoader
import io.github.sceneview.rememberNodes
import io.github.sceneview.rememberOnGestureListener
import io.github.sceneview.rememberView
import java.io.File

/** Places the model in the real world with ARCore. Expects a .glb file path. */
class ArActivity : AppCompatActivity() {
    companion object { const val EXTRA_PATH = "path" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val path = intent.getStringExtra(EXTRA_PATH)
        val file = path?.let { File(it) }?.takeIf { it.exists() }
        val availability = runCatching { ArCoreApk.getInstance().checkAvailability(this) }.getOrNull()
        val unsupported = availability == ArCoreApk.Availability.UNSUPPORTED_DEVICE_NOT_CAPABLE

        setContent {
            StudioTheme("dark") {
                Box(Modifier.fillMaxSize().background(Color.Black)) {
                    if (file == null || unsupported) {
                        Column(Modifier.align(Alignment.Center).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(stringResource(if (unsupported) R.string.ar_unsupported else R.string.err_failed), color = Color.White,
                                textAlign = TextAlign.Center, fontSize = 16.sp)
                            Spacer(Modifier.height(16.dp))
                            Text(stringResource(R.string.back), color = Brand.VioletSoft, modifier = Modifier.clickable { finish() }.padding(12.dp))
                        }
                    } else {
                        ArContent(file) { finish() }
                    }
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun ArContent(file: File, onBack: () -> Unit) {
    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine)
    val cameraNode = rememberARCameraNode(engine)
    val childNodes = rememberNodes()
    val view = rememberView(engine)
    val collisionSystem = rememberCollisionSystem(view)
    var planeRenderer by remember { mutableStateOf(true) }
    var trackingFailure by remember { mutableStateOf<TrackingFailureReason?>(null) }
    var frame by remember { mutableStateOf<Frame?>(null) }
    var realSize by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    fun place(anchor: Anchor) {
        val node = runCatching { createAnchorNode(engine, modelLoader, anchor, file, realSize) }.getOrNull()
        if (node == null) { loadError = true; anchor.detach(); return }
        childNodes.clear()
        childNodes += node
        planeRenderer = false
    }

    ARScene(
        modifier = Modifier.fillMaxSize(),
        childNodes = childNodes,
        engine = engine,
        view = view,
        modelLoader = modelLoader,
        collisionSystem = collisionSystem,
        sessionConfiguration = { session, config ->
            config.depthMode = if (session.isDepthModeSupported(Config.DepthMode.AUTOMATIC)) Config.DepthMode.AUTOMATIC else Config.DepthMode.DISABLED
            config.instantPlacementMode = Config.InstantPlacementMode.LOCAL_Y_UP
            config.lightEstimationMode = Config.LightEstimationMode.ENVIRONMENTAL_HDR
        },
        cameraNode = cameraNode,
        planeRenderer = planeRenderer,
        onTrackingFailureChanged = { trackingFailure = it },
        onSessionUpdated = { _, updatedFrame ->
            frame = updatedFrame
            if (childNodes.isEmpty() && !loadError) {
                updatedFrame.getUpdatedPlanes()
                    .firstOrNull { it.type == Plane.Type.HORIZONTAL_UPWARD_FACING }
                    ?.let { it.createAnchorOrNull(it.centerPose) }
                    ?.let { place(it) }
            }
        },
        onGestureListener = rememberOnGestureListener(
            onSingleTapConfirmed = { motionEvent, node ->
                if (node == null) {
                    frame?.hitTest(motionEvent.x, motionEvent.y)
                        ?.firstOrNull { it.isValid(depthPoint = false, point = false) }
                        ?.createAnchorOrNull()
                        ?.let { place(it) }
                }
            }
        ),
    )

    // top bar
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.45f))) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back), tint = Color.White)
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = { childNodes.clear(); planeRenderer = true }, modifier = Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.45f))) {
            Icon(Icons.Rounded.DeleteSweep, stringResource(R.string.ar_clear), tint = Color.White)
        }
    }

    Box(Modifier.fillMaxSize()) {
        // hint
        Text(
            text = when {
                loadError -> stringResource(R.string.err_failed)
                trackingFailure != null -> trackingFailure!!.getDescription(ctx)
                childNodes.isEmpty() -> stringResource(R.string.ar_point_down)
                else -> stringResource(R.string.ar_tap_to_move)
            },
            color = Color.White, fontSize = 15.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 70.dp, start = 32.dp, end = 32.dp)
                .clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 14.dp, vertical = 8.dp),
        )
        // size toggle
        Row(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp)
                .clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.55f)).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            listOf(false to R.string.ar_fit, true to R.string.ar_real_size).forEach { (v, label) ->
                Text(
                    stringResource(label), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (realSize == v) Brand.Violet else Color.Transparent)
                        .clickable { realSize = v; childNodes.clear(); planeRenderer = true }
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                )
            }
        }
    }
}

private fun createAnchorNode(engine: Engine, modelLoader: ModelLoader, anchor: Anchor, file: File, realSize: Boolean): AnchorNode {
    val anchorNode = AnchorNode(engine = engine, anchor = anchor)
    val modelNode = ModelNode(
        modelInstance = modelLoader.createModelInstance(file),
        scaleToUnits = if (realSize) null else 0.5f,
        centerOrigin = Position(x = 0.0f, y = -1.0f, z = 0.0f),
    ).apply {
        isEditable = true
        editableScaleRange = 0.0001f..1000f
    }
    anchorNode.addChildNode(modelNode)
    return anchorNode
}
