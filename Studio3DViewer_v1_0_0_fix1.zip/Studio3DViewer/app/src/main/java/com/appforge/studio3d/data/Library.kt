package com.appforge.studio3d.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class ModelItem(
    val id: String,
    val name: String,
    val ext: String,
    val size: Long,
    val addedAt: Long,
    val lastOpened: Long,
    val favorite: Boolean,
) {
    fun dir(ctx: Context) = File(Library.root(ctx), id)
    fun file(ctx: Context) = File(dir(ctx), Library.safeName(name))
    fun thumb(ctx: Context) = File(dir(ctx), "thumb.jpg")
    /** URL the 3D engine uses to fetch the file through the in-app asset server. */
    fun engineUrl() = "https://appassets.androidplatform.net/lib/$id/" + Uri.encode(Library.safeName(name))
}

object Library {
    val SUPPORTED = setOf(
        "glb", "gltf", "obj", "stl", "fbx", "ply", "3mf", "usdz", "usda", "usdc", "usd",
        "dae", "3ds", "amf", "wrl", "vrml", "pcd", "xyz", "splat", "ksplat", "spz", "zip"
    )
    val items = mutableStateListOf<ModelItem>()
    /** Bumped whenever a thumbnail file changes so images reload. */
    var thumbTick by mutableIntStateOf(0)
    private var loaded = false

    fun root(ctx: Context) = File(ctx.filesDir, "library").apply { mkdirs() }
    private fun index(ctx: Context) = File(root(ctx), "index.json")

    fun safeName(n: String): String = n.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120).ifBlank { "model" }

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        items.clear()
        val f = index(ctx)
        if (!f.exists()) return
        runCatching {
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val item = ModelItem(
                    o.getString("id"), o.getString("name"), o.getString("ext"), o.optLong("size"),
                    o.optLong("addedAt"), o.optLong("lastOpened"), o.optBoolean("favorite")
                )
                if (item.file(ctx).exists()) items.add(item)
            }
        }
    }

    private fun save(ctx: Context) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("name", it.name); put("ext", it.ext); put("size", it.size)
                put("addedAt", it.addedAt); put("lastOpened", it.lastOpened); put("favorite", it.favorite)
            })
        }
        index(ctx).writeText(arr.toString())
    }

    fun extOf(name: String): String = name.substringAfterLast('.', "").lowercase()

    fun isSupported(name: String) = extOf(name) in SUPPORTED

    /** Copies a picked/shared file into the private library. Returns null if the type is not supported. */
    suspend fun import(ctx: Context, uri: Uri): ModelItem? = withContext(Dispatchers.IO) {
        var name = "model"
        var size = -1L
        runCatching {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) c.getString(ni)?.let { name = it }
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        }
        if (name == "model") uri.lastPathSegment?.substringAfterLast('/')?.let { name = it }
        if (!isSupported(name)) return@withContext null
        val id = UUID.randomUUID().toString().take(12)
        val item = ModelItem(id, name, extOf(name), size, System.currentTimeMillis(), System.currentTimeMillis(), false)
        val dst = item.file(ctx)
        dst.parentFile?.mkdirs()
        val ok = runCatching {
            ctx.contentResolver.openInputStream(uri)?.use { input -> dst.outputStream().use { input.copyTo(it, 256 * 1024) } } != null
        }.getOrDefault(false)
        if (!ok || !dst.exists() || dst.length() == 0L) { item.dir(ctx).deleteRecursively(); return@withContext null }
        val real = item.copy(size = dst.length())
        withContext(Dispatchers.Main) {
            items.add(0, real)
            save(ctx)
        }
        real
    }

    fun touch(ctx: Context, id: String) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) { items[i] = items[i].copy(lastOpened = System.currentTimeMillis()); save(ctx) }
    }

    fun toggleFavorite(ctx: Context, id: String) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) { items[i] = items[i].copy(favorite = !items[i].favorite); save(ctx) }
    }

    fun rename(ctx: Context, id: String, newBase: String) {
        val i = items.indexOfFirst { it.id == id }
        if (i < 0 || newBase.isBlank()) return
        val old = items[i]
        val newName = safeName(newBase.trim()) + "." + old.ext
        val src = old.file(ctx)
        val dst = File(old.dir(ctx), safeName(newName))
        if (src.renameTo(dst)) { items[i] = old.copy(name = newName); save(ctx) }
    }

    fun delete(ctx: Context, id: String) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) { items[i].dir(ctx).deleteRecursively(); items.removeAt(i); save(ctx) }
    }

    fun clear(ctx: Context) {
        items.toList().forEach { it.dir(ctx).deleteRecursively() }
        items.clear(); save(ctx)
    }

    fun saveThumb(ctx: Context, id: String, jpeg: ByteArray) {
        val item = items.firstOrNull { it.id == id } ?: return
        runCatching { item.thumb(ctx).writeBytes(jpeg) }
        thumbTick++
    }

    fun totalSize(): Long = items.sumOf { it.size.coerceAtLeast(0) }
}
