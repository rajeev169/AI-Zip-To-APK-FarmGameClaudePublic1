package com.appforge.studio3d.data

import android.content.Context

/** Simple persisted settings. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("studio3d_prefs", Context.MODE_PRIVATE)

    var theme: String // system | dark | light
        get() = sp.getString("theme", "system") ?: "system"
        set(v) = sp.edit().putString("theme", v).apply()

    var quality: String // low | medium | high
        get() = sp.getString("quality", "high") ?: "high"
        set(v) = sp.edit().putString("quality", v).apply()

    var defaultEnv: String
        get() = sp.getString("env", "studio") ?: "studio"
        set(v) = sp.edit().putString("env", v).apply()

    var unit: String // m | cm | mm | in | ft
        get() = sp.getString("unit", "m") ?: "m"
        set(v) = sp.edit().putString("unit", v).apply()

    var autoRotate: Boolean
        get() = sp.getBoolean("autoRotate", false)
        set(v) = sp.edit().putBoolean("autoRotate", v).apply()

    var librarySort: String // recent | name | size
        get() = sp.getString("sort", "recent") ?: "recent"
        set(v) = sp.edit().putString("sort", v).apply()

    var gestureTipsShown: Boolean
        get() = sp.getBoolean("tips", false)
        set(v) = sp.edit().putBoolean("tips", v).apply()
}
