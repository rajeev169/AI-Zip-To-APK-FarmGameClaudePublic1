package com.appforge.studio3d.engine

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

data class ModelInfo(
    val name: String = "", val format: String = "", val fileSize: Long = 0, val kind: String = "mesh",
    val meshes: Int = 0, val vertices: Long = 0, val triangles: Long = 0, val materials: Int = 0,
    val textures: Int = 0, val maxTexture: Int = 0, val animations: Int = 0, val bones: Int = 0,
    val morphs: Int = 0, val splats: Long = 0, val dimX: Double = 0.0, val dimY: Double = 0.0, val dimZ: Double = 0.0,
)

data class Part(val id: Int, val name: String, val tris: Long, val visible: Boolean, val material: String)
data class Clip(val i: Int, val name: String, val duration: Float)

/** Everything the viewer UI shows, fed by messages from the 3D engine. */
class EngineState {
    var ready by mutableStateOf(false)
    var loaded by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var error by mutableStateOf<String?>(null)
    var info by mutableStateOf(ModelInfo())
    val parts = mutableStateListOf<Part>()
    val clips = mutableStateListOf<Clip>()
    val morphs = mutableStateListOf<String>()
    var curClip by mutableIntStateOf(-1)
    var playing by mutableStateOf(false)
    var animTime by mutableFloatStateOf(0f)
    var animDuration by mutableFloatStateOf(0f)
    var selectedId by mutableIntStateOf(-1)
    var selectedName by mutableStateOf("")
    var measureText by mutableStateOf("")
    var measureCount by mutableIntStateOf(0)
    var recording by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var toastKey by mutableStateOf<String?>(null)
}

interface EngineListener {
    fun onBlob(kind: String, name: String, file: File) {}
    fun onThumbnail(jpeg: ByteArray) {}
}

/** Sends commands into the engine page. */
class EngineController {
    var webView: WebView? = null
    private val pending = mutableListOf<String>()
    var isReady = false
        private set

    fun cmd(name: String, vararg kv: Pair<String, Any?>) {
        val o = JSONObject().put("cmd", name)
        kv.forEach { (k, v) -> o.put(k, v ?: JSONObject.NULL) }
        send(o)
    }

    fun send(o: JSONObject) {
        val js = "window.S3D && S3D.cmd(" + JSONObject.quote(o.toString()) + ")"
        if (!isReady) { pending += js; return }
        webView?.evaluateJavascript(js, null)
    }

    fun markReady() {
        isReady = true
        val wv = webView ?: return
        pending.forEach { wv.evaluateJavascript(it, null) }
        pending.clear()
    }

    fun reset() { isReady = false; pending.clear() }
}

class EngineBridge(
    private val context: Context,
    private val state: EngineState,
    private val controller: EngineController,
    private val listener: EngineListener,
) {
    private val main = Handler(Looper.getMainLooper())
    private class Chunk(val kind: String, val name: String, val file: File, val out: FileOutputStream)
    private val chunks = HashMap<String, Chunk>()

    @JavascriptInterface
    fun postMessage(json: String) {
        val o = runCatching { JSONObject(json) }.getOrNull() ?: return
        main.post { handle(o) }
    }

    @JavascriptInterface
    fun chunkBegin(id: String, kind: String, name: String, size: Long) {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, name.replace(Regex("[\\\\/:*?\"<>|]"), "_"))
        synchronized(chunks) { chunks[id] = Chunk(kind, name, f, FileOutputStream(f)) }
        main.post { state.busy = true }
    }

    @JavascriptInterface
    fun chunkAppend(id: String, b64: String) {
        val c = synchronized(chunks) { chunks[id] } ?: return
        runCatching { c.out.write(Base64.decode(b64, Base64.DEFAULT)) }
    }

    @JavascriptInterface
    fun chunkEnd(id: String) {
        val c = synchronized(chunks) { chunks.remove(id) } ?: return
        runCatching { c.out.flush(); c.out.close() }
        main.post { state.busy = false; listener.onBlob(c.kind, c.name, c.file) }
    }

    @JavascriptInterface
    fun thumbnail(b64: String) {
        val bytes = runCatching { Base64.decode(b64, Base64.DEFAULT) }.getOrNull() ?: return
        main.post { listener.onThumbnail(bytes) }
    }

    private fun handle(o: JSONObject) {
        when (o.optString("type")) {
            "ready" -> { state.ready = true; controller.markReady() }
            "progress" -> { state.progress = o.optDouble("p", 0.0).toFloat(); if (o.optBoolean("exporting")) state.busy = true }
            "loaded" -> {
                val i = o.optJSONObject("info") ?: JSONObject()
                state.info = ModelInfo(
                    i.optString("name"), i.optString("format"), i.optLong("fileSize"), i.optString("kind", "mesh"),
                    i.optInt("meshes"), i.optLong("vertices"), i.optLong("triangles"), i.optInt("materials"),
                    i.optInt("textures"), i.optInt("maxTexture"), i.optInt("animations"), i.optInt("bones"),
                    i.optInt("morphs"), i.optLong("splats"), i.optDouble("dimX"), i.optDouble("dimY"), i.optDouble("dimZ"),
                )
                setParts(o.optJSONArray("parts"))
                state.clips.clear()
                o.optJSONArray("clips")?.let { a -> for (k in 0 until a.length()) { val c = a.getJSONObject(k); state.clips += Clip(c.optInt("i"), c.optString("name"), c.optDouble("duration").toFloat()) } }
                state.morphs.clear()
                o.optJSONArray("morphs")?.let { a -> for (k in 0 until a.length()) state.morphs += a.optString(k) }
                state.error = null; state.loaded = true; state.progress = 1f
            }
            "parts" -> setParts(o.optJSONArray("parts"))
            "error" -> {
                val code = o.optString("code")
                state.busy = false
                if (code == "unsupported" || code == "failed") { state.error = code } else state.toastKey = "error_$code"
            }
            "anim" -> {
                state.curClip = o.optInt("clip", -1); state.playing = o.optBoolean("playing")
                state.animTime = o.optDouble("time", 0.0).toFloat(); state.animDuration = o.optDouble("duration", 0.0).toFloat()
            }
            "animTime" -> state.animTime = o.optDouble("time", 0.0).toFloat()
            "selected" -> { state.selectedId = o.optInt("id", -1); state.selectedName = o.optString("name") }
            "measure" -> { state.measureText = o.optString("text"); state.measureCount = o.optInt("count") }
            "recording" -> state.recording = o.optBoolean("on")
            "toast" -> state.toastKey = o.optString("key")
        }
    }

    private fun setParts(a: JSONArray?) {
        state.parts.clear()
        if (a == null) return
        for (k in 0 until a.length()) {
            val p = a.getJSONObject(k)
            state.parts += Part(p.optInt("id"), p.optString("name"), p.optLong("tris"), p.optBoolean("visible", true), p.optString("material"))
        }
    }
}

private val MIME = mapOf(
    "html" to "text/html", "js" to "text/javascript", "mjs" to "text/javascript", "css" to "text/css",
    "json" to "application/json", "wasm" to "application/wasm", "png" to "image/png", "jpg" to "image/jpeg",
    "jpeg" to "image/jpeg", "webp" to "image/webp", "svg" to "image/svg+xml", "gltf" to "model/gltf+json",
    "glb" to "model/gltf-binary", "txt" to "text/plain",
)
private fun mimeOf(path: String) = MIME[path.substringAfterLast('.', "").lowercase()] ?: "application/octet-stream"

@SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
fun createEngineWebView(
    context: Context,
    mode: String,
    state: EngineState,
    controller: EngineController,
    listener: EngineListener,
    libraryRoot: File,
): WebView {
    val assets = context.assets
    val loader = WebViewAssetLoader.Builder()
        .addPathHandler("/assets/") { path ->
            runCatching { WebResourceResponse(mimeOf(path), if (mimeOf(path).startsWith("text")) "utf-8" else null, assets.open(path)) }.getOrNull()
        }
        .addPathHandler("/lib/") { path ->
            val f = File(libraryRoot, path)
            if (!f.canonicalPath.startsWith(libraryRoot.canonicalPath) || !f.exists()) null
            else WebResourceResponse(mimeOf(f.name), null, FileInputStream(f)).apply {
                responseHeaders = mapOf("Content-Length" to f.length().toString(), "Cache-Control" to "no-cache")
            }
        }
        .build()

    val interactive = mode != "hero"
    val wv = object : WebView(context) {
        // The home hero is decorative: let touches fall through so the page scrolls.
        override fun dispatchTouchEvent(ev: android.view.MotionEvent?): Boolean = if (interactive) super.dispatchTouchEvent(ev) else false
    }
    wv.setBackgroundColor(Color.TRANSPARENT)
    wv.settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        allowFileAccess = false
        allowContentAccess = false
        mediaPlaybackRequiresUserGesture = false
        setSupportZoom(false)
        builtInZoomControls = false
        displayZoomControls = false
    }
    wv.isVerticalScrollBarEnabled = false
    wv.isHorizontalScrollBarEnabled = false
    wv.overScrollMode = WebView.OVER_SCROLL_NEVER
    wv.webViewClient = object : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
            loader.shouldInterceptRequest(request.url)

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
    }
    controller.reset()
    controller.webView = wv
    wv.addJavascriptInterface(EngineBridge(context, state, controller, listener), "Android")
    wv.loadUrl("https://appassets.androidplatform.net/assets/web/index.html?mode=$mode")
    return wv
}
