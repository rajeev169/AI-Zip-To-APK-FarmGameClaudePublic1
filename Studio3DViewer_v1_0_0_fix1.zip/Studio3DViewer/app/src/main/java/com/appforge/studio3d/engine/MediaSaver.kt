package com.appforge.studio3d.engine

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

object MediaSaver {
    private const val FOLDER = "Studio3D"

    /** Saves to the public gallery / downloads. Returns a shareable uri, or null on failure. */
    fun saveToPublic(ctx: Context, src: File, kind: String): Uri? {
        val mime = when (src.extension.lowercase()) {
            "png" -> "image/png"; "jpg", "jpeg" -> "image/jpeg"; "mp4" -> "video/mp4"; "webm" -> "video/webm"
            "glb" -> "model/gltf-binary"; else -> "application/octet-stream"
        }
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val (collection, relPath) = when (kind) {
                    "screenshot" -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to "${Environment.DIRECTORY_PICTURES}/$FOLDER"
                    "video" -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to "${Environment.DIRECTORY_MOVIES}/$FOLDER"
                    else -> MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER"
                }
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, src.name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val r = ctx.contentResolver
                val uri = r.insert(collection, values) ?: return null
                r.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                r.update(uri, values, null, null)
                uri
            } else {
                // Android 8–9: keep in the app's own media folder and share through FileProvider
                val dir = File(ctx.getExternalFilesDir(null), FOLDER).apply { mkdirs() }
                val dst = File(dir, src.name)
                src.copyTo(dst, overwrite = true)
                shareUri(ctx, dst)
            }
        }.getOrNull()
    }

    fun shareUri(ctx: Context, file: File): Uri =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)

    fun share(ctx: Context, uri: Uri, mime: String, chooserTitle: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, chooserTitle).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun mimeFor(name: String) = when (name.substringAfterLast('.', "").lowercase()) {
        "png" -> "image/png"; "jpg", "jpeg" -> "image/jpeg"; "mp4" -> "video/mp4"; "webm" -> "video/webm"
        "glb" -> "model/gltf-binary"; "gltf" -> "model/gltf+json"; "stl" -> "model/stl"; "obj" -> "model/obj"
        else -> "application/octet-stream"
    }
}
