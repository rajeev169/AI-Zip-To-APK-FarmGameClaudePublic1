package com.appforge.studio3d.ui

import android.webkit.WebView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.appforge.studio3d.data.Library
import com.appforge.studio3d.engine.EngineController
import com.appforge.studio3d.engine.EngineListener
import com.appforge.studio3d.engine.EngineState
import com.appforge.studio3d.engine.createEngineWebView

/** Hosts the 3D engine page. The WebView lives exactly as long as this composable. */
@Composable
fun EngineView(
    mode: String,
    state: EngineState,
    controller: EngineController,
    listener: EngineListener,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val webView: WebView = remember {
        createEngineWebView(ctx, mode, state, controller, listener, Library.root(ctx))
    }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_PAUSE -> { webView.onPause(); controller.cmd("pause", "on" to true) }
                Lifecycle.Event.ON_RESUME -> { webView.onResume(); controller.cmd("pause", "on" to false) }
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose {
            lifecycle.removeObserver(obs)
            controller.webView = null
            controller.reset()
            webView.stopLoading()
            webView.removeJavascriptInterface("Android")
            webView.destroy()
        }
    }
    AndroidView(factory = { webView }, modifier = modifier)
}
