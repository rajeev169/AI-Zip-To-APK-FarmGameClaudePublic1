package com.appforge.studio3d.ui

import android.graphics.BitmapFactory
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.ViewInAr
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.studio3d.R
import com.appforge.studio3d.data.Library
import com.appforge.studio3d.data.ModelItem
import com.appforge.studio3d.data.Prefs
import com.appforge.studio3d.engine.EngineController
import com.appforge.studio3d.engine.EngineListener
import com.appforge.studio3d.engine.EngineState
import com.appforge.studio3d.engine.MediaSaver

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    importing: Boolean,
    onOpenUri: (android.net.Uri) -> Unit,
    onOpenItem: (ModelItem) -> Unit,
    onOpenSample: (String) -> Unit,
    onSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) onOpenUri(uri) }
    var query by rememberSaveable { mutableStateOf("") }
    var searching by rememberSaveable { mutableStateOf(false) }
    var favOnly by rememberSaveable { mutableStateOf(false) }
    var sort by remember { mutableStateOf(prefs.librarySort) }
    var sortMenu by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<ModelItem?>(null) }
    var renameFor by remember { mutableStateOf<ModelItem?>(null) }
    var deleteFor by remember { mutableStateOf<ModelItem?>(null) }

    val heroState = remember { EngineState() }
    val heroCtl = remember { EngineController() }

    val items = Library.items
        .filter { !favOnly || it.favorite }
        .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
        .let { list -> when (sort) { "name" -> list.sortedBy { it.name.lowercase() }; "size" -> list.sortedByDescending { it.size }; else -> list.sortedByDescending { it.lastOpened } } }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            // ---------------- hero with live 3D
            Box(
                Modifier.fillMaxWidth().height(400.dp)
                    .background(Brand.heroBg)
            ) {
                EngineView("hero", heroState, heroCtl, object : EngineListener {}, Modifier.fillMaxSize())
                // soft fade into the page
                Box(Modifier.fillMaxWidth().height(140.dp).align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, MaterialTheme.colorScheme.background))))
                Row(Modifier.statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(Brand.accent), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.ViewInAr, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.app_name), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(stringResource(R.string.by_appforge), color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                    }
                    IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, stringResource(R.string.settings), tint = Color.White) }
                }
                Column(Modifier.align(Alignment.BottomStart).padding(start = 20.dp, end = 20.dp, bottom = 20.dp)) {
                    Text(stringResource(R.string.hero_title), color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp, lineHeight = 34.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(stringResource(R.string.hero_subtitle), color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f), fontSize = 14.sp)
                }
            }

            // ---------------- open button
            Column(Modifier.padding(horizontal = 20.dp)) {
                GlowButton(
                    text = stringResource(R.string.open_file),
                    icon = Icons.Rounded.FolderOpen,
                    loading = importing,
                    onClick = { picker.launch(arrayOf("*/*")) },
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    stringResource(R.string.formats_line),
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.55f), fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                )
            }

            // ---------------- samples
            SectionTitle(stringResource(R.string.samples))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SampleCard(stringResource(R.string.sample_helmet), stringResource(R.string.sample_helmet_sub), listOf(Color(0xFF3A2F8F), Color(0xFF0F7FA8))) { onOpenSample("helmet") }
                SampleCard(stringResource(R.string.sample_robot), stringResource(R.string.sample_robot_sub), listOf(Color(0xFF8F2F6A), Color(0xFFE0883A))) { onOpenSample("robot") }
                SampleCard(stringResource(R.string.sample_materials), stringResource(R.string.sample_materials_sub), listOf(Color(0xFF1F7A5A), Color(0xFF3A5BE0))) { onOpenSample("materials") }
            }

            // ---------------- library
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 26.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.library), fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { searching = !searching; if (!searching) query = "" }) { Icon(Icons.Rounded.Search, stringResource(R.string.search)) }
                Box {
                    IconButton(onClick = { sortMenu = true }) { Icon(Icons.Rounded.Sort, stringResource(R.string.sort)) }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        listOf("recent" to R.string.sort_recent, "name" to R.string.sort_name, "size" to R.string.sort_size).forEach { (k, r) ->
                            DropdownMenuItem(text = { Text(stringResource(r)) }, onClick = { sort = k; prefs.librarySort = k; sortMenu = false })
                        }
                    }
                }
            }
            AnimatedVisibility(searching) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text(stringResource(R.string.search_models)) },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
                )
            }
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !favOnly, onClick = { favOnly = false }, label = { Text(stringResource(R.string.all_models)) })
                FilterChip(selected = favOnly, onClick = { favOnly = true }, label = { Text(stringResource(R.string.favorites)) },
                    leadingIcon = { Icon(Icons.Rounded.Favorite, null, Modifier.size(16.dp)) })
            }
            Spacer(Modifier.height(10.dp))
            if (items.isEmpty()) {
                EmptyLibrary(favOnly || query.isNotBlank())
            } else {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEach { item ->
                                Box(Modifier.weight(1f)) {
                                    ModelCard(item, onClick = { onOpenItem(item) }, onLongClick = { menuFor = item })
                                    DropdownMenu(expanded = menuFor?.id == item.id, onDismissRequest = { menuFor = null }) {
                                        DropdownMenuItem(
                                            text = { Text(stringResource(if (item.favorite) R.string.unfavorite else R.string.favorite)) },
                                            leadingIcon = { Icon(if (item.favorite) Icons.Rounded.FavoriteBorder else Icons.Rounded.Favorite, null) },
                                            onClick = { Library.toggleFavorite(ctx, item.id); menuFor = null })
                                        DropdownMenuItem(text = { Text(stringResource(R.string.rename)) }, leadingIcon = { Icon(Icons.Rounded.DriveFileRenameOutline, null) },
                                            onClick = { renameFor = item; menuFor = null })
                                        DropdownMenuItem(text = { Text(stringResource(R.string.share)) }, leadingIcon = { Icon(Icons.Rounded.Share, null) },
                                            onClick = {
                                                menuFor = null
                                                runCatching { MediaSaver.share(ctx, MediaSaver.shareUri(ctx, item.file(ctx)), MediaSaver.mimeFor(item.name), ctx.getString(R.string.share)) }
                                            })
                                        DropdownMenuItem(text = { Text(stringResource(R.string.delete)) }, leadingIcon = { Icon(Icons.Rounded.Delete, null) },
                                            onClick = { deleteFor = item; menuFor = null })
                                    }
                                }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            Spacer(Modifier.navigationBarsPadding().height(32.dp))
        }
    }

    renameFor?.let { item ->
        var text by remember(item.id) { mutableStateOf(item.name.substringBeforeLast('.')) }
        AlertDialog(
            onDismissRequest = { renameFor = null },
            title = { Text(stringResource(R.string.rename)) },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { Library.rename(ctx, item.id, text); renameFor = null }) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton(onClick = { renameFor = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
    deleteFor?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text(stringResource(R.string.delete_title)) },
            text = { Text(stringResource(R.string.delete_message, item.name)) },
            confirmButton = { TextButton(onClick = { Library.delete(ctx, item.id); deleteFor = null }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
fun GlowButton(text: String, icon: ImageVector, loading: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "glow")
    val glow by t.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "g")
    Box(
        modifier.fillMaxWidth().height(58.dp)
            .graphicsLayer { shadowElevation = 24f * glow; shape = RoundedCornerShape(18.dp); clip = true }
            .background(Brand.accent)
            .clickable(enabled = !loading, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (loading) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.5.dp)
            else Icon(icon, null, tint = Color.White)
            Spacer(Modifier.width(10.dp))
            Text(if (loading) stringResource(R.string.importing) else text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(start = 20.dp, top = 26.dp, bottom = 12.dp))
}

@Composable
private fun SampleCard(title: String, sub: String, colors: List<Color>, onClick: () -> Unit) {
    Column(
        Modifier.width(168.dp).clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(colors))
            .clickable(onClick = onClick).padding(16.dp)
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White)
        }
        Spacer(Modifier.height(28.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(sub, color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp, maxLines = 2)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ModelCard(item: ModelItem, onClick: () -> Unit, onLongClick: () -> Unit) {
    val ctx = LocalContext.current
    val tick = Library.thumbTick
    val bmp = remember(item.id, tick) {
        val f = item.thumb(ctx)
        if (f.exists()) runCatching { BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() }.getOrNull() else null
    }
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) {
        Column {
            Box(Modifier.fillMaxWidth().aspectRatio(1f).background(Brand.heroBg), contentAlignment = Alignment.Center) {
                if (bmp != null) {
                    androidx.compose.animation.AnimatedVisibility(visible = true, enter = fadeIn()) {
                        Image(bmp, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    }
                } else Icon(Icons.Rounded.ViewInAr, null, tint = Brand.VioletSoft, modifier = Modifier.size(44.dp))
                Text(
                    item.ext.uppercase(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopStart).padding(8.dp).clip(RoundedCornerShape(6.dp))
                        .background(Brand.Violet.copy(alpha = 0.85f)).padding(horizontal = 6.dp, vertical = 2.dp)
                )
                if (item.favorite) Icon(Icons.Rounded.Favorite, null, tint = Brand.Pink,
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(18.dp))
            }
            Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                Text(item.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(Formatter.formatShortFileSize(ctx, item.size), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun EmptyLibrary(filtered: Boolean) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.ViewInAr, null, tint = Brand.VioletSoft, modifier = Modifier.size(36.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(stringResource(if (filtered) R.string.empty_filtered else R.string.empty_library), color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}
