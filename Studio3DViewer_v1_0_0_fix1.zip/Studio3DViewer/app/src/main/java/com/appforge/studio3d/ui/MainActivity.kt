package com.appforge.studio3d.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import com.appforge.studio3d.R
import com.appforge.studio3d.data.Library
import com.appforge.studio3d.data.ModelItem
import com.appforge.studio3d.data.Prefs
import kotlinx.coroutines.launch

sealed class Screen {
    data object Home : Screen()
    data class Viewer(val item: ModelItem?, val sample: String?) : Screen()
    data object Settings : Screen()
}

class MainActivity : AppCompatActivity() {
    private var screen by mutableStateOf<Screen>(Screen.Home)
    var importing by mutableStateOf(false)
        private set
    lateinit var prefs: Prefs
    var themePref by mutableStateOf("system")

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        prefs = Prefs(this)
        themePref = prefs.theme
        Library.load(this)
        setContent {
            StudioTheme(themePref) {
                BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }
                AnimatedContent(targetState = screen, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "nav") { s ->
                    when (s) {
                        Screen.Home -> HomeScreen(
                            importing = importing,
                            onOpenUri = { importAndOpen(it) },
                            onOpenItem = { openItem(it) },
                            onOpenSample = { screen = Screen.Viewer(null, it) },
                            onSettings = { screen = Screen.Settings },
                        )
                        is Screen.Viewer -> ViewerScreen(
                            item = s.item, sample = s.sample, prefs = prefs,
                            onBack = { screen = Screen.Home },
                        )
                        Screen.Settings -> SettingsScreen(
                            prefs = prefs,
                            onThemeChanged = { themePref = it },
                            onBack = { screen = Screen.Home },
                        )
                    }
                }
            }
        }
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        intent ?: return
        val uri: Uri? = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                                  else @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_STREAM)
            else -> null
        }
        if (uri != null) importAndOpen(uri)
    }

    fun openItem(item: ModelItem) {
        Library.touch(this, item.id)
        screen = Screen.Viewer(item, null)
    }

    fun importAndOpen(uri: Uri) {
        if (importing) return
        importing = true
        lifecycleScope.launch {
            val item = runCatching { Library.import(this@MainActivity, uri) }.getOrNull()
            importing = false
            if (item == null) Toast.makeText(this@MainActivity, R.string.err_unsupported, Toast.LENGTH_LONG).show()
            else openItem(item)
        }
    }
}
