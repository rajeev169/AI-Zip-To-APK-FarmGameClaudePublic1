package com.appforge.studio3d.ui

import android.text.format.Formatter
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Rotate90DegreesCw
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appforge.studio3d.R
import com.appforge.studio3d.engine.EngineController
import com.appforge.studio3d.engine.EngineState
import java.util.Locale

// ------------------------------------------------------------------ building blocks
private val TextMain = Color.White
private val TextDim = Color.White.copy(alpha = 0.62f)

@Composable
private fun PanelBody(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp), content = content)
}

@Composable
private fun Label(text: String) {
    Text(text.uppercase(Locale.getDefault()), color = TextDim, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp,
        modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
}

@Composable
private fun <T> Chips(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, label) ->
            FilterChip(
                selected = k == selected, onClick = { onSelect(k) }, label = { Text(label, maxLines = 1) },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = Color.White.copy(alpha = 0.06f), labelColor = TextMain,
                    selectedContainerColor = Brand.Violet, selectedLabelColor = Color.White,
                ),
                border = null,
            )
        }
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = TextMain, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(valueText, color = TextDim, fontSize = 13.sp)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Brand.VioletSoft, inactiveTrackColor = Color.White.copy(alpha = 0.15f)),
        )
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = if (enabled) TextMain else TextDim, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled,
            colors = SwitchDefaults.colors(checkedTrackColor = Brand.Violet, checkedThumbColor = Color.White))
    }
}

private fun f1(v: Float) = String.format(Locale.US, "%.1f", v)
private fun f2(v: Float) = String.format(Locale.US, "%.2f", v)

// ------------------------------------------------------------------ Lighting
@Composable
fun LightPanel(ui: ViewerUi, ctl: EngineController) {
    PanelBody {
        Label(stringResource(R.string.environment))
        Chips(
            listOf(
                "studio" to stringResource(R.string.env_studio), "soft" to stringResource(R.string.env_soft),
                "mono" to stringResource(R.string.env_mono), "sunset" to stringResource(R.string.env_sunset),
                "sunrise" to stringResource(R.string.env_sunrise), "outdoor" to stringResource(R.string.env_outdoor),
                "city" to stringResource(R.string.env_city), "night" to stringResource(R.string.env_night),
            ), ui.env
        ) { ui.env = it; ctl.cmd("env", "id" to it) }
        Label(stringResource(R.string.background))
        Chips(
            listOf("gradient" to stringResource(R.string.bg_gradient), "env" to stringResource(R.string.bg_env), "color" to stringResource(R.string.bg_color)),
            ui.bg
        ) { ui.bg = it; ctl.cmd("background", "mode" to it, "color" to ui.bgColor) }
        if (ui.bg == "color") {
            Spacer(Modifier.height(8.dp))
            Swatches(listOf("#101321", "#000000", "#2B2D42", "#F2F2F7", "#FFFFFF", "#1B3A4B", "#3D2C5C", "#4A1F2E"), ui.bgColor) {
                ui.bgColor = it; ctl.cmd("background", "mode" to "color", "color" to it)
            }
        }
        Label(stringResource(R.string.light))
        SliderRow(stringResource(R.string.exposure), ui.exposure, 0.2f..2.5f, f2(ui.exposure)) { ui.exposure = it; ctl.cmd("exposure", "value" to it.toDouble()) }
        SliderRow(stringResource(R.string.light_rotation), ui.envRotation, 0f..360f, "${ui.envRotation.toInt()}°") { ui.envRotation = it; ctl.cmd("envRotation", "deg" to it.toDouble()) }
        SliderRow(stringResource(R.string.key_light), ui.keyLight, 0f..5f, f1(ui.keyLight)) { ui.keyLight = it; ctl.cmd("keyLight", "intensity" to it.toDouble()) }
        Label(stringResource(R.string.effects))
        ToggleRow(stringResource(R.string.shadows), ui.shadows) { ui.shadows = it; ctl.cmd("shadows", "on" to it) }
        ToggleRow(stringResource(R.string.bloom), ui.bloom) { ui.bloom = it; ctl.cmd("bloom", "on" to it, "strength" to 0.3) }
        ToggleRow(stringResource(R.string.ambient_occlusion), ui.ao) { ui.ao = it; ctl.cmd("ao", "on" to it) }
        Label(stringResource(R.string.tone_mapping))
        Chips(listOf("aces" to "ACES", "agx" to "AgX", "neutral" to stringResource(R.string.tone_neutral), "filmic" to stringResource(R.string.tone_filmic), "none" to stringResource(R.string.off)), ui.tone) {
            ui.tone = it; ctl.cmd("toneMapping", "id" to it)
        }
    }
}

@Composable
private fun Swatches(colors: List<String>, selected: String, onPick: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            val col = Color(android.graphics.Color.parseColor(c))
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(col)
                    .border(if (c.equals(selected, true)) 3.dp else 1.dp, if (c.equals(selected, true)) Brand.VioletSoft else Color.White.copy(alpha = 0.25f), CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
}

// ------------------------------------------------------------------ Display
@Composable
fun DisplayPanel(ui: ViewerUi, ctl: EngineController, state: EngineState) {
    PanelBody {
        Label(stringResource(R.string.render_mode))
        val modes = listOf(
            "shaded" to R.string.mode_shaded, "wire" to R.string.mode_wire, "shadedWire" to R.string.mode_shaded_wire,
            "xray" to R.string.mode_xray, "clay" to R.string.mode_clay, "matcap" to R.string.mode_matcap,
            "normals" to R.string.mode_normals, "uv" to R.string.mode_uv, "texture" to R.string.mode_texture,
        )
        modes.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (k, r) ->
                    val sel = ui.mode == k
                    Box(
                        Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(14.dp))
                            .background(if (sel) Brand.Violet else Color.White.copy(alpha = 0.07f))
                            .clickable { ui.mode = k; ctl.cmd("displayMode", "id" to k) },
                        contentAlignment = Alignment.Center,
                    ) { Text(stringResource(r), color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 6.dp)) }
                }
            }
        }
        Label(stringResource(R.string.camera_views))
        Chips(
            listOf("iso" to R.string.view_iso, "front" to R.string.view_front, "back" to R.string.view_back, "left" to R.string.view_left,
                "right" to R.string.view_right, "top" to R.string.view_top, "bottom" to R.string.view_bottom).map { it.first to stringResource(it.second) },
            "",
        ) { ctl.cmd("view", "id" to it) }
        SliderRow(stringResource(R.string.field_of_view), ui.fov, 15f..90f, "${ui.fov.toInt()}°") { ui.fov = it; ctl.cmd("fov", "value" to it.toDouble()) }
        Label(stringResource(R.string.helpers))
        ToggleRow(stringResource(R.string.grid), ui.grid) { ui.grid = it; ctl.cmd("grid", "on" to it) }
        ToggleRow(stringResource(R.string.axes), ui.axes) { ui.axes = it; ctl.cmd("axes", "on" to it) }
    }
}

// ------------------------------------------------------------------ Inspect
@Composable
fun InspectPanel(ui: ViewerUi, ctl: EngineController, state: EngineState) {
    val ctx = LocalContext.current
    val i = state.info
    PanelBody {
        Label(stringResource(R.string.statistics))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (i.kind == "splat") StatTile(stringResource(R.string.stat_splats), fmtCount(i.splats), Modifier.weight(1f))
            else {
                StatTile(stringResource(R.string.stat_triangles), fmtCount(i.triangles), Modifier.weight(1f))
                StatTile(stringResource(R.string.stat_vertices), fmtCount(i.vertices), Modifier.weight(1f))
                StatTile(stringResource(R.string.stat_meshes), i.meshes.toString(), Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile(stringResource(R.string.stat_size), sizeText(i.dimX, i.dimY, i.dimZ, ui.unit), Modifier.weight(2f))
            StatTile(stringResource(R.string.stat_file), if (i.fileSize > 0) Formatter.formatShortFileSize(ctx, i.fileSize) else "—", Modifier.weight(1f))
        }
        Label(stringResource(R.string.measure))
        ToggleRow(stringResource(R.string.measure_mode), ui.measure) { ui.measure = it; ctl.cmd("measureMode", "on" to it) }
        Chips(listOf("m" to "m", "cm" to "cm", "mm" to "mm", "in" to "in", "ft" to "ft"), ui.unit) { ui.unit = it; ctl.cmd("unit", "id" to it) }
        if (state.measureCount > 0) TextButton(onClick = { ctl.cmd("clearMeasures") }) { Text(stringResource(R.string.clear_measures), color = Brand.VioletSoft) }
        Text(stringResource(R.string.units_note), color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        if (i.kind != "splat") {
            Label(stringResource(R.string.cross_section))
            ToggleRow(stringResource(R.string.section_enable), ui.section) { ui.section = it; sendSection(ui, ctl) }
            if (ui.section) {
                Chips(listOf("x" to "X", "y" to "Y", "z" to "Z"), ui.sectionAxis) { ui.sectionAxis = it; sendSection(ui, ctl) }
                SliderRow(stringResource(R.string.section_position), ui.sectionPos, 0f..1f, "${(ui.sectionPos * 100).toInt()}%") { ui.sectionPos = it; sendSection(ui, ctl) }
                ToggleRow(stringResource(R.string.section_flip), ui.sectionFlip) { ui.sectionFlip = it; sendSection(ui, ctl) }
            }
            Label(stringResource(R.string.exploded_view))
            SliderRow(stringResource(R.string.explode), ui.explode, 0f..1f, "${(ui.explode * 100).toInt()}%") { ui.explode = it; ctl.cmd("explode", "value" to it.toDouble()) }
        }
    }
}

private fun sendSection(ui: ViewerUi, ctl: EngineController) {
    ctl.cmd("section", "on" to ui.section, "axis" to ui.sectionAxis, "pos" to ui.sectionPos.toDouble(), "flip" to ui.sectionFlip)
}

fun sizeText(x: Double, y: Double, z: Double, unit: String): String {
    val k = when (unit) { "cm" -> 100.0; "mm" -> 1000.0; "in" -> 39.3701; "ft" -> 3.28084; else -> 1.0 }
    fun s(v: Double) = (v * k).let { if (it >= 100) String.format(Locale.US, "%.0f", it) else if (it >= 10) String.format(Locale.US, "%.1f", it) else String.format(Locale.US, "%.2f", it) }
    return "${s(x)} × ${s(y)} × ${s(z)} $unit"
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.06f)).padding(horizontal = 12.dp, vertical = 10.dp)) {
        Text(value, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, color = TextDim, fontSize = 11.sp, maxLines = 1)
    }
}

// ------------------------------------------------------------------ Parts
@Composable
fun PartsPanel(ctl: EngineController, state: EngineState) {
    var filter by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.parts_count, state.parts.size), color = TextMain, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(start = 4.dp))
            TextButton(onClick = {
                ctl.cmd("showAll")
            }) { Text(stringResource(R.string.show_all), color = Brand.VioletSoft) }
        }
        if (state.parts.size > 8) {
            OutlinedTextField(filter, { filter = it }, singleLine = true, placeholder = { Text(stringResource(R.string.search_parts)) },
                modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp), shape = RoundedCornerShape(14.dp))
        }
        val list = state.parts.filter { filter.isBlank() || it.name.contains(filter, true) }
        LazyColumn(Modifier.fillMaxWidth().height(240.dp)) {
            items(list, key = { it.id }) { p ->
                val sel = state.selectedId == p.id
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(if (sel) Brand.Violet.copy(alpha = 0.3f) else Color.Transparent)
                        .clickable { state.selectedId = p.id; state.selectedName = p.name; ctl.cmd("select", "id" to p.id, "focus" to true) }
                        .padding(start = 10.dp, top = 2.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = if (p.visible) TextMain else TextDim, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(listOfNotNull(stringResource(R.string.part_tris, fmtCount(p.tris)), p.material.ifBlank { null }).joinToString(" · "),
                            color = TextDim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = {
                        val idx = state.parts.indexOfFirst { it.id == p.id }
                        if (idx >= 0) state.parts[idx] = p.copy(visible = !p.visible)
                        ctl.cmd("partVisible", "id" to p.id, "visible" to !p.visible)
                    }) { Icon(if (p.visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff, null, tint = if (p.visible) TextMain else TextDim) }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Animate
@Composable
fun AnimatePanel(ui: ViewerUi, ctl: EngineController, state: EngineState) {
    PanelBody {
        if (state.clips.isEmpty() && state.morphs.isEmpty()) {
            Text(stringResource(R.string.no_animations), color = TextDim, fontSize = 14.sp, modifier = Modifier.padding(vertical = 12.dp))
        }
        if (state.clips.isNotEmpty()) {
            Label(stringResource(R.string.clips_count, state.clips.size))
            Chips(state.clips.map { it.i to it.name }, state.curClip) { ctl.cmd("playClip", "i" to it) }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(Brand.accent).clickable { ctl.cmd("play", "on" to !state.playing) },
                    contentAlignment = Alignment.Center,
                ) { Icon(if (state.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, stringResource(if (state.playing) R.string.pause else R.string.play), tint = Color.White) }
                Spacer(Modifier.width(10.dp))
                val dur = state.animDuration.coerceAtLeast(0.01f)
                Column(Modifier.weight(1f)) {
                    Slider(
                        value = (state.animTime % dur).coerceIn(0f, dur), valueRange = 0f..dur,
                        onValueChange = { state.animTime = it; ctl.cmd("seek", "time" to it.toDouble()) },
                        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Brand.Cyan, inactiveTrackColor = Color.White.copy(alpha = 0.15f)),
                    )
                    Text("${f2(state.animTime % dur)} / ${f2(dur)} s", color = TextDim, fontSize = 11.sp)
                }
            }
            Label(stringResource(R.string.speed))
            Chips(listOf(0.25f to "0.25×", 0.5f to "0.5×", 1f to "1×", 1.5f to "1.5×", 2f to "2×"), ui.speed) { ui.speed = it; ctl.cmd("speed", "value" to it.toDouble()) }
            Label(stringResource(R.string.loop))
            Chips(listOf("repeat" to stringResource(R.string.loop_repeat), "once" to stringResource(R.string.loop_once), "pingpong" to stringResource(R.string.loop_pingpong)), ui.loop) {
                ui.loop = it; ctl.cmd("loop", "id" to it)
            }
        }
        if (state.info.bones > 0) {
            Label(stringResource(R.string.rig))
            ToggleRow(stringResource(R.string.show_skeleton), ui.skeleton) { ui.skeleton = it; ctl.cmd("skeleton", "on" to it) }
        }
        if (state.morphs.isNotEmpty()) {
            Label(stringResource(R.string.morph_targets))
            state.morphs.forEach { name ->
                var v by remember(name) { mutableFloatStateOf(ui.morphValues[name] ?: 0f) }
                SliderRow(name, v, 0f..1f, "${(v * 100).toInt()}%") { v = it; ui.morphValues[name] = it; ctl.cmd("morph", "name" to name, "value" to it.toDouble()) }
            }
        }
    }
}

// ------------------------------------------------------------------ Edit
@Composable
fun EditPanel(ui: ViewerUi, ctl: EngineController, state: EngineState) {
    val target = state.selectedId
    fun edit(vararg kv: Pair<String, Any?>) { ui.edited = true; ctl.cmd("editMaterial", "id" to target, *kv) }
    PanelBody {
        Text(
            if (target >= 0) stringResource(R.string.editing_part, state.selectedName) else stringResource(R.string.editing_all),
            color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
        )
        Text(stringResource(R.string.edit_hint), color = TextDim, fontSize = 12.sp)
        Label(stringResource(R.string.color))
        Swatches(listOf("#FFFFFF", "#D9D9D9", "#2B2B2B", "#E53950", "#FF8A3D", "#FFD23D", "#3DDC84", "#36D6FF", "#3D6BFF", "#9D8CFF", "#FF5CC8", "#8B5A2B"), "") { edit("color" to it) }
        Label(stringResource(R.string.material))
        SliderRow(stringResource(R.string.metalness), ui.metalness, 0f..1f, f2(ui.metalness)) { ui.metalness = it; edit("metalness" to it.toDouble()) }
        SliderRow(stringResource(R.string.roughness), ui.roughness, 0f..1f, f2(ui.roughness)) { ui.roughness = it; edit("roughness" to it.toDouble()) }
        SliderRow(stringResource(R.string.opacity), ui.opacity, 0.05f..1f, "${(ui.opacity * 100).toInt()}%") { ui.opacity = it; edit("opacity" to it.toDouble()) }
        TextButton(onClick = { ctl.cmd("resetMaterials") }) { Text(stringResource(R.string.reset_materials), color = Brand.VioletSoft) }
        Label(stringResource(R.string.orientation))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("x", "y", "z").forEach { ax ->
                OutlinedButton(onClick = { ui.edited = true; ctl.cmd("rotateModel", "axis" to ax, "deg" to 90) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Rotate90DegreesCw, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(ax.uppercase(), color = Color.White)
                }
            }
        }
        Text(stringResource(R.string.orientation_hint), color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { ctl.cmd("exportGLB") }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.export_glb), color = Color.White) }
    }
}

// ------------------------------------------------------------------ Info dialog
@Composable
fun InfoSheet(state: EngineState, unit: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val i = state.info
    val rows = buildList {
        add(stringResource(R.string.info_format) to i.format.ifBlank { "—" })
        if (i.fileSize > 0) add(stringResource(R.string.stat_file) to Formatter.formatFileSize(ctx, i.fileSize))
        if (i.kind == "splat") add(stringResource(R.string.stat_splats) to fmtCount(i.splats))
        else {
            add(stringResource(R.string.stat_meshes) to i.meshes.toString())
            add(stringResource(R.string.stat_triangles) to String.format(Locale.getDefault(), "%,d", i.triangles))
            add(stringResource(R.string.stat_vertices) to String.format(Locale.getDefault(), "%,d", i.vertices))
            add(stringResource(R.string.info_materials) to i.materials.toString())
            add(stringResource(R.string.info_textures) to if (i.textures > 0) "${i.textures} (max ${i.maxTexture}px)" else "0")
            add(stringResource(R.string.info_animations) to i.animations.toString())
            add(stringResource(R.string.info_bones) to i.bones.toString())
            add(stringResource(R.string.morph_targets) to i.morphs.toString())
        }
        add(stringResource(R.string.stat_size) to sizeText(i.dimX, i.dimY, i.dimZ, unit))
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(i.name.ifBlank { stringResource(R.string.model_info) }, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                rows.forEach { (k, v) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Text(k, modifier = Modifier.weight(1f), color = TextDim, fontSize = 14.sp)
                        Text(v, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.close)) } },
        containerColor = Brand.PanelHigh,
    )
}
