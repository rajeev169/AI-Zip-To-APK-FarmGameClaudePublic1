package com.appforge.studio3d.ui

import android.content.Intent
import android.net.Uri
import android.text.format.Formatter
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.os.LocaleListCompat
import com.appforge.studio3d.BuildConfigInfo
import com.appforge.studio3d.R
import com.appforge.studio3d.data.Library
import com.appforge.studio3d.data.Prefs

/** The 25 built-in languages, shown in their own script. Empty tag = follow the phone. */
val LANGUAGES = listOf(
    "en" to "English", "hi" to "हिन्दी", "bn" to "বাংলা", "mr" to "मराठी", "te" to "తెలుగు", "ta" to "தமிழ்",
    "gu" to "ગુજરાતી", "kn" to "ಕನ್ನಡ", "ml" to "മലയാളം", "pa" to "ਪੰਜਾਬੀ", "or" to "ଓଡ଼ିଆ", "ur" to "اردو",
    "es" to "Español", "pt" to "Português", "fr" to "Français", "de" to "Deutsch", "ru" to "Русский",
    "ar" to "العربية", "id" to "Bahasa Indonesia", "tr" to "Türkçe", "vi" to "Tiếng Việt", "ja" to "日本語",
    "ko" to "한국어", "zh-CN" to "简体中文", "th" to "ไทย",
)

@Composable
fun SettingsScreen(prefs: Prefs, onThemeChanged: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf<String?>(null) }
    var quality by remember { mutableStateOf(prefs.quality) }
    var env by remember { mutableStateOf(prefs.defaultEnv) }
    var unit by remember { mutableStateOf(prefs.unit) }
    var theme by remember { mutableStateOf(prefs.theme) }
    var autoRotate by remember { mutableStateOf(prefs.autoRotate) }
    val currentTag = AppCompatDelegate.getApplicationLocales().toLanguageTags().substringBefore(',')
    val langName = if (currentTag.isBlank()) stringResource(R.string.lang_system)
        else LANGUAGES.firstOrNull { it.first.equals(currentTag, true) || currentTag.startsWith(it.first.substringBefore('-')) }?.second ?: currentTag

    val qualityNames = mapOf("low" to R.string.quality_low, "medium" to R.string.quality_medium, "high" to R.string.quality_high)
    val themeNames = mapOf("system" to R.string.theme_system, "dark" to R.string.theme_dark, "light" to R.string.theme_light)
    val envNames = mapOf("studio" to R.string.env_studio, "soft" to R.string.env_soft, "mono" to R.string.env_mono, "sunset" to R.string.env_sunset,
        "sunrise" to R.string.env_sunrise, "outdoor" to R.string.env_outdoor, "city" to R.string.env_city, "night" to R.string.env_night)
    val unitNames = mapOf("m" to "m", "cm" to "cm", "mm" to "mm", "in" to "in", "ft" to "ft")

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back)) }
            Text(stringResource(R.string.settings), fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding()) {
            Group(stringResource(R.string.general)) {
                Item(stringResource(R.string.language), langName) { dialog = "lang" }
                Item(stringResource(R.string.theme), stringResource(themeNames[theme] ?: R.string.theme_system)) { dialog = "theme" }
            }
            Group(stringResource(R.string.viewer)) {
                Item(stringResource(R.string.render_quality), stringResource(qualityNames[quality] ?: R.string.quality_high)) { dialog = "quality" }
                Item(stringResource(R.string.default_lighting), stringResource(envNames[env] ?: R.string.env_studio)) { dialog = "env" }
                Item(stringResource(R.string.measure_units), unit) { dialog = "unit" }
                Row(Modifier.fillMaxWidth().clickable { autoRotate = !autoRotate; prefs.autoRotate = autoRotate }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.auto_rotate_open), modifier = Modifier.weight(1f), fontSize = 15.sp)
                    Switch(autoRotate, { autoRotate = it; prefs.autoRotate = it })
                }
            }
            Group(stringResource(R.string.storage)) {
                Item(stringResource(R.string.library_size), stringResource(R.string.library_size_value, Library.items.size, Formatter.formatShortFileSize(ctx, Library.totalSize()))) {}
                Item(stringResource(R.string.clear_library), "") { dialog = "clear" }
            }
            Group(stringResource(R.string.about)) {
                Item(stringResource(R.string.version), BuildConfigInfo.versionName(ctx)) {}
                Item(stringResource(R.string.developer), "AppForge") {}
                Item(stringResource(R.string.licenses), stringResource(R.string.licenses_sub)) { dialog = "licenses" }
                Item(stringResource(R.string.rate_app), "") {
                    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + ctx.packageName))) }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    when (dialog) {
        "lang" -> PickDialog(stringResource(R.string.language),
            listOf("" to stringResource(R.string.lang_system)) + LANGUAGES, currentTag, onDismiss = { dialog = null }) { tag ->
            AppCompatDelegate.setApplicationLocales(if (tag.isBlank()) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(tag))
            dialog = null
        }
        "theme" -> PickDialog(stringResource(R.string.theme), themeNames.map { it.key to stringResource(it.value) }, theme, { dialog = null }) {
            theme = it; prefs.theme = it; onThemeChanged(it); dialog = null
        }
        "quality" -> PickDialog(stringResource(R.string.render_quality), qualityNames.map { it.key to stringResource(it.value) }, quality, { dialog = null }) {
            quality = it; prefs.quality = it; dialog = null
        }
        "env" -> PickDialog(stringResource(R.string.default_lighting), envNames.map { it.key to stringResource(it.value) }, env, { dialog = null }) {
            env = it; prefs.defaultEnv = it; dialog = null
        }
        "unit" -> PickDialog(stringResource(R.string.measure_units), unitNames.toList(), unit, { dialog = null }) {
            unit = it; prefs.unit = it; dialog = null
        }
        "clear" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(stringResource(R.string.clear_library)) },
            text = { Text(stringResource(R.string.clear_library_msg)) },
            confirmButton = { TextButton(onClick = { Library.clear(ctx); dialog = null }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.cancel)) } },
        )
        "licenses" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(stringResource(R.string.licenses)) },
            text = { Text(stringResource(R.string.licenses_text), fontSize = 13.sp, modifier = Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.close)) } },
        )
    }
}

@Composable
private fun Group(title: String, content: @Composable () -> Unit) {
    Text(title, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
        modifier = Modifier.padding(start = 8.dp, top = 18.dp, bottom = 8.dp))
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceContainer)) { content() }
}

@Composable
private fun Item(title: String, value: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 13.dp)) {
        Text(title, fontSize = 15.sp)
        if (value.isNotBlank()) Text(value, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PickDialog(title: String, options: List<Pair<String, String>>, selected: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(options, key = { it.first }) { (k, label) ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onPick(k) }.padding(horizontal = 8.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(label, modifier = Modifier.weight(1f), fontSize = 15.sp)
                        if (k.equals(selected, true)) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
