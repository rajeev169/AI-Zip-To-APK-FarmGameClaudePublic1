package com.appforge.studio3d.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Brand {
    val Violet = Color(0xFF7C5CFF)
    val VioletSoft = Color(0xFF9D8CFF)
    val Cyan = Color(0xFF36D6FF)
    val Pink = Color(0xFFFF5C8A)
    val Night = Color(0xFF0B0D18)
    val Panel = Color(0xFF151829)
    val PanelHigh = Color(0xFF1E2238)
    val accent = Brush.linearGradient(listOf(Violet, Cyan))
    val heroBg = Brush.verticalGradient(listOf(Color(0xFF1B1F3A), Color(0xFF0E1022), Night))
}

private val DarkColors = darkColorScheme(
    primary = Brand.VioletSoft,
    onPrimary = Color(0xFF140B3D),
    primaryContainer = Color(0xFF34298A),
    onPrimaryContainer = Color(0xFFE6E0FF),
    secondary = Brand.Cyan,
    onSecondary = Color(0xFF00222C),
    tertiary = Brand.Pink,
    background = Brand.Night,
    onBackground = Color(0xFFE8E8F2),
    surface = Brand.Night,
    onSurface = Color(0xFFE8E8F2),
    surfaceVariant = Brand.PanelHigh,
    onSurfaceVariant = Color(0xFFB9BBD1),
    surfaceContainer = Brand.Panel,
    surfaceContainerHigh = Brand.PanelHigh,
    surfaceContainerHighest = Color(0xFF282C47),
    surfaceContainerLow = Color(0xFF111324),
    outline = Color(0xFF4A4E6E),
    outlineVariant = Color(0xFF2E3250),
)

private val LightColors = lightColorScheme(
    primary = Brand.Violet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE6E0FF),
    onPrimaryContainer = Color(0xFF1E1263),
    secondary = Color(0xFF0090B8),
    tertiary = Color(0xFFD63B6B),
    background = Color(0xFFF6F6FB),
    surface = Color(0xFFF6F6FB),
    surfaceVariant = Color(0xFFE6E6F0),
    surfaceContainer = Color(0xFFEDEDF5),
    surfaceContainerHigh = Color(0xFFE6E6F0),
    surfaceContainerHighest = Color(0xFFDDDDEA),
    surfaceContainerLow = Color(0xFFF1F1F8),
)

@Composable
fun StudioTheme(themePref: String, content: @Composable () -> Unit) {
    val dark = when (themePref) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
