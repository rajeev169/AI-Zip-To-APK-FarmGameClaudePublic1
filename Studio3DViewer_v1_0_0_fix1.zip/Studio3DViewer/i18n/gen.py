import re, glob, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from en import EN, KEYS, NO_TRANSLATE, LICENSES
RES = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'res')
FOLDER = {'en': 'values', 'zh-CN': 'values-zh-rCN', 'id': 'values-in'}
def esc(s):
    s = s.replace('\\n', '\n')
    s = s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    s = s.replace('\\', '\\\\').replace("'", "\\'").replace('"', '\\"').replace('\n', '\\n')
    if s.startswith('@') or s.startswith('?'): s = '\\' + s
    return s
def write(lang, d):
    folder = FOLDER.get(lang, 'values-' + lang)
    os.makedirs(os.path.join(RES, folder), exist_ok=True)
    out = ['<?xml version="1.0" encoding="utf-8"?>', '<resources>']
    for k in KEYS:
        if lang != 'en' and k in NO_TRANSLATE: continue
        v = LICENSES if k == 'licenses_text' else d[k]
        attr = ' translatable="false"' if k in NO_TRANSLATE else ''
        out.append(f'    <string name="{k}"{attr}>{esc(v)}</string>')
    out.append('</resources>\n')
    open(os.path.join(RES, folder, 'strings.xml'), 'w', encoding='utf-8').write('\n'.join(out))
ph = re.compile(r'%\d\$[sd]')
write('en', EN)
ok = True; langs = []
for f in sorted(glob.glob(os.path.join(os.path.dirname(__file__), 't_*.txt'))):
    cur = None; data = {}
    for line in open(f, encoding='utf-8'):
        line = line.rstrip('\n')
        if not line.strip(): continue
        if line.startswith('@@'): cur = line[2:].strip(); data[cur] = {}; continue
        k, v = line.split('=', 1)
        data[cur][k.strip()] = v
    for lang, d in data.items():
        need = [k for k in KEYS if k not in NO_TRANSLATE]
        missing = [k for k in need if k not in d]; extra = [k for k in d if k not in EN]
        bad = [k for k in d if k in EN and sorted(ph.findall(d[k])) != sorted(ph.findall(EN[k]))]
        if missing or extra or bad: ok = False; print(lang, 'MISSING', missing, 'EXTRA', extra, 'PLACEHOLDER', bad)
        else: write(lang, d); langs.append(lang)
print('written:', ['en'] + langs, len(langs) + 1)
