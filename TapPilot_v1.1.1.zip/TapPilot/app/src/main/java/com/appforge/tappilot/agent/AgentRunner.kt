package com.appforge.tappilot.agent

import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.PilotService
import com.appforge.tappilot.service.SafetyGuard
import kotlinx.coroutines.delay
import org.json.JSONObject

/**
 * The AI phone agent: look at the screen → ask Gemini for the next step → do it → repeat,
 * until the task is done, the step limit is reached, or a safety rule stops it.
 */
class AgentRunner(private val svc: PilotService, private val task: String) {

    private val history = mutableListOf<String>()

    /** Words the agent may use only when the user's own command contains them. */
    private val allowIfAsked = listOf("install", "uninstall", "delete account", "factory reset")

    suspend fun run(): String {
        val limit = Prefs.stepLimit
        svc.status("Starting… going to the home screen")
        svc.home()
        delay(900)

        var sameActionCount = 0
        var lastActionKey = ""

        for (step in 1..limit) {
            delay(700) // let the screen settle
            val root = svc.rootInActiveWindow
            val pkg = root?.packageName?.toString() ?: svc.currentPackage
            SafetyGuard.check(root, pkg)?.let { reason ->
                svc.stopAll(reason, blocked = true)
                return reason
            }

            val (w, h) = svc.screenSize()
            val snap = ScreenReader.read(root, w, h)
            val shot = if (Prefs.useScreenshots && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) svc.screenshot() else null

            svc.status("Step $step/$limit: thinking…")
            val user = buildString {
                append("TASK: ").append(task).append("\n\n")
                append("Step ").append(step).append(" of at most ").append(limit).append(".\n")
                append("Current app package: ").append(pkg ?: "unknown").append("\n")
                if (history.isNotEmpty()) {
                    append("\nWhat you already did (oldest first):\n")
                    history.takeLast(10).forEach { append("- ").append(it).append('\n') }
                }
                if (sameActionCount >= 2) {
                    append("\nWARNING: you repeated the same action several times without progress. Try something different, or finish with fail.\n")
                }
                append("\nSCREEN ELEMENTS (id, type, label, @x,y on a 0-1000 scale):\n")
                append(snap.text)
                if (shot != null) append("\nA screenshot of the current screen is attached.\n")
                append("\nReply with ONE JSON object for the next action.")
            }

            val reply = GeminiClient.generate(SYSTEM_PROMPT, user, shot, json = true)
            val act = try {
                GeminiClient.parseJson(reply)
            } catch (e: Exception) {
                history.add("(reply not understood)")
                continue
            }

            val action = act.optString("action").lowercase().trim()
            val thought = act.optString("thought").take(120)
            if (thought.isNotBlank()) svc.status("Step $step: $thought")

            val key = action + act.optInt("id", -1) + act.optString("text") + act.optInt("x", -1) + act.optInt("y", -1)
            sameActionCount = if (key == lastActionKey) sameActionCount + 1 else 0
            lastActionKey = key
            if (sameActionCount >= 4) return "Stopped: the agent got stuck repeating the same step."

            val result = execute(action, act, snap, w, h)
            history.add(describe(action, act, snap) + " → " + result)

            when (result) {
                RESULT_DONE -> return act.optString("message").ifBlank { "Task finished" }
                RESULT_FAIL -> return "Could not finish: " + act.optString("message").ifBlank { "the agent gave up" }
                RESULT_BLOCKED -> return "Stopped: the next step was a payment/purchase or risky button. Please do that part yourself."
            }
        }
        return "Reached the step limit ($limit). Increase it in Settings if the task needs more steps."
    }

    private fun describe(action: String, a: JSONObject, snap: ScreenReader.Snapshot): String {
        val id = a.optInt("id", -1)
        val el = snap.elements.firstOrNull { it.id == id }
        return when (action) {
            "tap", "long_press" -> if (el != null) "$action [$id] \"${el.label}\"" else "$action at ${a.optInt("x")},${a.optInt("y")}"
            "type" -> "type \"${a.optString("text").take(40)}\"" + if (el != null) " into [$id]" else ""
            "open_app" -> "open_app ${a.optString("app")}"
            "scroll" -> "scroll ${a.optString("direction")}"
            "wait" -> "wait ${a.optInt("seconds", 2)}s"
            else -> action
        }
    }

    private fun riskyFor(label: String?): Boolean {
        if (label.isNullOrBlank()) return false
        if (!SafetyGuard.isDangerousLabel(label)) return false
        val l = label.lowercase()
        val t = task.lowercase()
        // Install/uninstall-style buttons are fine when the user asked for exactly that
        val allowed = allowIfAsked.any { w -> l.contains(w) && t.contains(w) }
        return !allowed
    }

    private suspend fun execute(
        action: String,
        a: JSONObject,
        snap: ScreenReader.Snapshot,
        w: Int,
        h: Int
    ): String {
        val el = snap.elements.firstOrNull { it.id == a.optInt("id", -1) }
        fun px(v: Int, size: Int): Float = (v.coerceIn(0, 1000) / 1000f) * size

        return when (action) {
            "tap", "long_press" -> {
                if (el != null) {
                    if (riskyFor(el.label)) return RESULT_BLOCKED
                    val ok = if (action == "tap") svc.clickNode(el.node)
                    else svc.longPress(el.bounds.exactCenterX(), el.bounds.exactCenterY())
                    if (ok) "ok" else "failed"
                } else if (a.has("x") && a.has("y")) {
                    val x = px(a.optInt("x"), w)
                    val y = px(a.optInt("y"), h)
                    val ok = if (action == "tap") svc.tap(x, y) else svc.longPress(x, y)
                    if (ok) "ok" else "failed"
                } else "failed: no target"
            }

            "type" -> {
                val text = a.optString("text")
                val ok = if (el != null && el.editable) {
                    svc.clickNode(el.node)
                    delay(250)
                    svc.typeInto(el.node, text)
                } else {
                    svc.typeIntoFocused(text)
                }
                if (ok && a.optBoolean("submit", false)) {
                    delay(250)
                    pressEnter()
                }
                if (ok) "ok" else "failed: no text box focused"
            }

            "scroll" -> if (svc.scroll(a.optString("direction", "up"))) "ok" else "failed"

            "swipe" -> {
                val ok = svc.swipe(
                    px(a.optInt("x1"), w), px(a.optInt("y1"), h),
                    px(a.optInt("x2"), w), px(a.optInt("y2"), h), 350
                )
                if (ok) "ok" else "failed"
            }

            "open_app" -> {
                val app = a.optString("app")
                if (SafetyGuard.isBlockedPackage(app)) return RESULT_BLOCKED
                val pkg = svc.openApp(app)
                if (pkg != null) {
                    delay(1800)
                    "opened $pkg"
                } else "failed: app \"$app\" not found or not allowed"
            }

            "back" -> { svc.back(); "ok" }
            "home" -> { svc.home(); "ok" }
            "recents" -> { svc.recents(); "ok" }
            "notifications" -> { svc.notifications(); "ok" }
            "wait" -> { delay(a.optInt("seconds", 2).coerceIn(1, 10) * 1000L); "ok" }
            "done" -> RESULT_DONE
            "fail" -> RESULT_FAIL
            else -> "unknown action"
        }
    }

    private fun pressEnter() {
        val f = svc.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
    }

    companion object {
        private const val RESULT_DONE = "__done__"
        private const val RESULT_FAIL = "__fail__"
        private const val RESULT_BLOCKED = "__blocked__"

        private val SYSTEM_PROMPT = """
You are TapPilot, an assistant that operates an Android phone for its owner, one step at a time.
The owner may write in Hindi, English or Hinglish. Understand all of them.

Each turn you get the task, what you already did, a numbered list of screen elements and often a screenshot.
Choose exactly ONE next action and reply with a single JSON object:

{"thought": "<very short reason>", "action": "<action>", ...fields}

Actions:
- {"action":"tap","id":N}                    tap element N (preferred)
- {"action":"tap","x":X,"y":Y}               tap a point seen in the screenshot (0-1000 scale; 0,0 = top-left)
- {"action":"long_press","id":N} or with x,y
- {"action":"type","id":N,"text":"...","submit":false}   type into a TextBox (omit id to use the focused box). submit=true presses Enter/Search.
- {"action":"scroll","direction":"up|down|left|right"}   "up" moves the page content up to reveal more below
- {"action":"swipe","x1":..,"y1":..,"x2":..,"y2":..}
- {"action":"open_app","app":"<app name>"}   open an installed app by name (fastest way to start)
- {"action":"back"} {"action":"home"} {"action":"recents"} {"action":"notifications"}
- {"action":"wait","seconds":2}             wait for loading
- {"action":"done","message":"<short result for the owner, in the owner's language>"}
- {"action":"fail","message":"<why it cannot be done>"}

Rules:
- Prefer element ids over x,y. Use x,y only for things missing from the list.
- Check the screen after each step; if something didn't work, try another way.
- Finish with "done" as soon as the task is complete. Answer questions (e.g. "what's the weather") in the done message.
- NEVER pay, buy, purchase, subscribe, recharge, transfer or send money, or confirm any order. If the task needs that, prepare everything and stop with "fail" saying the owner must complete payment personally.
- NEVER type or read passwords, OTPs, PINs or card details. Never change security settings.
- Never delete data, uninstall apps, or send messages/emails/posts to anyone the owner did not clearly ask for.
- Dismiss pop-ups, ads and permission dialogs sensibly (allow only what the task needs).
""".trimIndent()
    }
}
