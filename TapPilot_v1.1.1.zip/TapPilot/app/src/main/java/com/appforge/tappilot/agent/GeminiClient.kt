package com.appforge.tappilot.agent

import android.graphics.Bitmap
import android.util.Base64
import com.appforge.tappilot.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class GeminiException(message: String) : Exception(message)

/** Talks to Google Gemini with the user's own (free) API key. Paces requests to stay inside free limits. */
object GeminiClient {

    private val lock = Mutex()
    private var lastCall = 0L

    private suspend fun pace() {
        val gap = 60_000L / Prefs.requestsPerMinute.coerceAtLeast(1)
        val wait = lastCall + gap - System.currentTimeMillis()
        if (wait > 0) delay(wait)
        lastCall = System.currentTimeMillis()
    }

    /**
     * Sends text (+ optional screenshot) and returns the model's text reply.
     * With [json] = true the reply is forced to be a JSON object.
     */
    suspend fun generate(
        system: String,
        user: String,
        image: Bitmap? = null,
        json: Boolean = true
    ): String = lock.withLock {
        val key = Prefs.apiKey
        if (key.isBlank()) throw GeminiException("Add your free Gemini API key in Settings first.")

        val parts = JSONArray().put(JSONObject().put("text", user))
        if (image != null) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", "image/jpeg").put("data", toJpegBase64(image))
                )
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put(
                "generationConfig",
                JSONObject().put("temperature", 0.2).apply {
                    if (json) put("responseMimeType", "application/json")
                }
            )

        var attempt = 0
        while (true) {
            pace()
            val (code, text) = post(Prefs.model, key, body.toString())
            if (code == 200) return@withLock extractText(text)
            val msg = errorMessage(text)
            if ((code == 429 || code == 503 || code == 500) && attempt < 2) {
                attempt++
                delay(if (code == 429) 20_000L else 4_000L)
                continue
            }
            throw GeminiException(
                when (code) {
                    400 -> if (msg.contains("API key", true)) "Gemini API key is not valid. Check it in Settings." else "Gemini error: $msg"
                    403 -> "Gemini refused the key (403). Make sure the Generative Language API is enabled for it."
                    404 -> "Model \"${Prefs.model}\" not found. Change the model name in Settings."
                    429 -> "Free Gemini limit reached. Wait a minute, or lower 'requests per minute' in Settings."
                    -1 -> "No internet connection."
                    else -> "Gemini error $code: $msg"
                }
            )
        }
        ""
    }

    private suspend fun post(model: String, key: String, body: String): Pair<Int, String> =
        withContext(Dispatchers.IO) {
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 20_000
                conn.readTimeout = 60_000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.setRequestProperty("x-goog-api-key", key)
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                conn.disconnect()
                code to text
            } catch (e: Exception) {
                -1 to (e.message ?: "network error")
            }
        }

    private fun extractText(raw: String): String {
        val o = JSONObject(raw)
        val cands = o.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val block = o.optJSONObject("promptFeedback")?.optString("blockReason")
            throw GeminiException("Gemini gave no answer${if (!block.isNullOrBlank()) " ($block)" else ""}.")
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw GeminiException("Gemini gave an empty answer.")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.optBoolean("thought", false)) continue
            sb.append(p.optString("text", ""))
        }
        return sb.toString().trim()
    }

    private fun errorMessage(raw: String): String = try {
        JSONObject(raw).optJSONObject("error")?.optString("message") ?: raw.take(200)
    } catch (e: Exception) {
        raw.take(200)
    }

    /** Smaller image = faster + fewer tokens. */
    private fun toJpegBase64(src: Bitmap): String {
        val maxW = 720
        val bmp = if (src.width > maxW) {
            val h = (src.height * (maxW.toFloat() / src.width)).toInt()
            Bitmap.createScaledBitmap(src, maxW, h, true)
        } else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** Pulls the first {...} object out of a reply, in case the model wraps it in text. */
    fun parseJson(reply: String): JSONObject {
        val start = reply.indexOf('{')
        val end = reply.lastIndexOf('}')
        if (start < 0 || end <= start) throw GeminiException("Gemini reply was not understood.")
        return JSONObject(reply.substring(start, end + 1))
    }
}
