package com.appforge.tappilot.agent

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/** Turns the screen's accessibility tree into a short numbered list the AI can act on. */
object ScreenReader {

    data class Element(
        val id: Int,
        val node: AccessibilityNodeInfo,
        val bounds: Rect,
        val label: String,
        val editable: Boolean,
        val clickable: Boolean,
        val scrollable: Boolean
    )

    data class Snapshot(val text: String, val elements: List<Element>)

    fun read(root: AccessibilityNodeInfo?, screenW: Int, screenH: Int, maxElements: Int = 90): Snapshot {
        if (root == null) return Snapshot("(screen could not be read)", emptyList())
        val out = mutableListOf<Element>()
        val screen = Rect(0, 0, screenW, screenH)
        walk(root, out, screen, maxElements, 0)
        val sb = StringBuilder()
        for (e in out) {
            val kind = when {
                e.editable -> "TextBox"
                e.scrollable && e.label.isBlank() -> "ScrollArea"
                e.clickable -> "Button"
                else -> "Text"
            }
            sb.append('[').append(e.id).append("] ").append(kind)
            if (e.label.isNotBlank()) sb.append(" \"").append(e.label).append('"')
            if (e.node.isChecked) sb.append(" (checked)")
            if (e.node.isSelected) sb.append(" (selected)")
            if (!e.node.isEnabled) sb.append(" (disabled)")
            // Positions are given on a 0-1000 scale (same scale the AI uses for the screenshot)
            sb.append(" @").append(e.bounds.centerX() * 1000 / screenW.coerceAtLeast(1))
                .append(',').append(e.bounds.centerY() * 1000 / screenH.coerceAtLeast(1))
            sb.append('\n')
        }
        if (out.isEmpty()) sb.append("(no readable elements — use the screenshot)\n")
        return Snapshot(sb.toString(), out)
    }

    private fun walk(
        n: AccessibilityNodeInfo,
        out: MutableList<Element>,
        screen: Rect,
        max: Int,
        depth: Int
    ) {
        if (out.size >= max || depth > 40) return
        if (!n.isVisibleToUser) return
        val r = Rect()
        n.getBoundsInScreen(r)
        if (!Rect.intersects(r, screen) || r.width() <= 1 || r.height() <= 1) return

        val text = n.text?.toString()?.trim().orEmpty()
        val desc = n.contentDescription?.toString()?.trim().orEmpty()
        val hint = if (android.os.Build.VERSION.SDK_INT >= 26) n.hintText?.toString()?.trim().orEmpty() else ""
        var label = when {
            text.isNotEmpty() && desc.isNotEmpty() && desc != text -> "$text | $desc"
            text.isNotEmpty() -> text
            desc.isNotEmpty() -> desc
            else -> ""
        }
        if (n.isEditable && label.isEmpty() && hint.isNotEmpty()) label = "hint: $hint"
        if (label.length > 80) label = label.take(77) + "..."
        label = label.replace('\n', ' ').replace('"', '\'')

        val interesting = n.isEditable || n.isClickable || n.isLongClickable || n.isCheckable ||
            n.isScrollable || label.isNotEmpty()

        if (interesting) {
            // Skip plain text that just repeats its clickable parent
            val dup = !n.isClickable && !n.isEditable && out.lastOrNull()?.let {
                it.label.contains(label) && Rect(it.bounds).contains(r)
            } == true
            if (!dup) {
                out.add(
                    Element(
                        id = out.size + 1,
                        node = n,
                        bounds = r,
                        label = label,
                        editable = n.isEditable,
                        clickable = n.isClickable || n.isLongClickable || n.isCheckable,
                        scrollable = n.isScrollable
                    )
                )
            }
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            walk(c, out, screen, max, depth + 1)
            if (out.size >= max) return
        }
    }
}
