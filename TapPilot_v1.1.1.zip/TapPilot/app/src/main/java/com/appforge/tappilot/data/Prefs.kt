package com.appforge.tappilot.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Board area of a match-3 game, in screen pixels. */
data class BoardConfig(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val rows: Int,
    val cols: Int
) {
    val cellW: Float get() = (right - left).toFloat() / cols
    val cellH: Float get() = (bottom - top).toFloat() / rows
    fun cellCenterX(c: Int): Float = left + cellW * (c + 0.5f)
    fun cellCenterY(r: Int): Float = top + cellH * (r + 0.5f)

    fun toJson(): JSONObject = JSONObject()
        .put("l", left).put("t", top).put("r", right).put("b", bottom)
        .put("rows", rows).put("cols", cols)

    companion object {
        fun fromJson(o: JSONObject) = BoardConfig(
            o.getInt("l"), o.getInt("t"), o.getInt("r"), o.getInt("b"),
            o.getInt("rows"), o.getInt("cols")
        )
    }
}

/** One recorded gesture. type = "tap", "long" or "swipe". delayMs = wait before doing it. */
data class MacroStep(
    val type: String,
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float,
    val durationMs: Long,
    val delayMs: Long
) {
    fun toJson(): JSONObject = JSONObject()
        .put("type", type).put("x1", x1.toDouble()).put("y1", y1.toDouble())
        .put("x2", x2.toDouble()).put("y2", y2.toDouble())
        .put("dur", durationMs).put("delay", delayMs)

    companion object {
        fun fromJson(o: JSONObject) = MacroStep(
            o.getString("type"),
            o.getDouble("x1").toFloat(), o.getDouble("y1").toFloat(),
            o.getDouble("x2").toFloat(), o.getDouble("y2").toFloat(),
            o.getLong("dur"), o.getLong("delay")
        )
    }
}

data class Macro(
    val id: Long,
    val name: String,
    val packageName: String?,
    val steps: List<MacroStep>
) {
    fun toJson(): JSONObject {
        val arr = JSONArray()
        steps.forEach { arr.put(it.toJson()) }
        return JSONObject().put("id", id).put("name", name)
            .put("pkg", packageName ?: "").put("steps", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): Macro {
            val arr = o.getJSONArray("steps")
            val steps = (0 until arr.length()).map { MacroStep.fromJson(arr.getJSONObject(it)) }
            val pkg = o.optString("pkg", "")
            return Macro(o.getLong("id"), o.getString("name"), pkg.ifBlank { null }, steps)
        }
    }
}

/**
 * What Gemini learned about a game, saved per app.
 * type: "match3", "chess" or "general". The board box itself is saved as a BoardConfig.
 */
data class GameProfile(
    val type: String,
    val name: String,
    val goal: String,
    val goalOnCells: Boolean,
    val rules: String,
    val bottomIsWhite: Boolean,
    val turnBased: Boolean
) {
    fun toJson(): JSONObject = JSONObject()
        .put("type", type).put("name", name).put("goal", goal).put("goalCells", goalOnCells)
        .put("rules", rules).put("bottomWhite", bottomIsWhite).put("turnBased", turnBased)

    companion object {
        fun fromJson(o: JSONObject) = GameProfile(
            o.optString("type", "match3"), o.optString("name", ""), o.optString("goal", ""),
            o.optBoolean("goalCells", false), o.optString("rules", ""),
            o.optBoolean("bottomWhite", true), o.optBoolean("turnBased", true)
        )
    }
}

object Prefs {
    private lateinit var sp: SharedPreferences

    private val _macros = MutableStateFlow<List<Macro>>(emptyList())
    val macros: StateFlow<List<Macro>> = _macros

    fun init(context: Context) {
        if (::sp.isInitialized) return
        sp = context.applicationContext.getSharedPreferences("tappilot", Context.MODE_PRIVATE)
        _macros.value = loadMacros()
    }

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) = sp.edit().putString("model", v.trim()).apply()

    /** Free Gemini keys allow only a few requests per minute; TapPilot paces itself to this. */
    var requestsPerMinute: Int
        get() = sp.getInt("rpm", 10)
        set(v) = sp.edit().putInt("rpm", v.coerceIn(1, 60)).apply()

    var stepLimit: Int
        get() = sp.getInt("step_limit", 25)
        set(v) = sp.edit().putInt("step_limit", v.coerceIn(3, 100)).apply()

    /** "hi-IN" or "en-IN" */
    var voiceLang: String
        get() = sp.getString("voice_lang", "hi-IN") ?: "hi-IN"
        set(v) = sp.edit().putString("voice_lang", v).apply()

    var runAfterVoice: Boolean
        get() = sp.getBoolean("run_after_voice", true)
        set(v) = sp.edit().putBoolean("run_after_voice", v).apply()

    var useScreenshots: Boolean
        get() = sp.getBoolean("use_screens", true)
        set(v) = sp.edit().putBoolean("use_screens", v).apply()

    /** Human-like pacing in game mode: slower moves, random pauses and breaks. */
    var humanMode: Boolean
        get() = sp.getBoolean("human_mode", true)
        set(v) = sp.edit().putBoolean("human_mode", v).apply()

    var disclosureAccepted: Boolean
        get() = sp.getBoolean("disclosure_ok", false)
        set(v) = sp.edit().putBoolean("disclosure_ok", v).apply()

    // ---------- game boards (one per game package) ----------

    fun board(pkg: String): BoardConfig? {
        val s = sp.getString("board_$pkg", null) ?: return null
        return try { BoardConfig.fromJson(JSONObject(s)) } catch (e: Exception) { null }
    }

    fun saveBoard(pkg: String, cfg: BoardConfig) {
        sp.edit().putString("board_$pkg", cfg.toJson().toString()).apply()
        val set = boardPackages().toMutableSet().apply { add(pkg) }
        sp.edit().putStringSet("board_pkgs", set).apply()
    }

    fun boardPackages(): Set<String> = sp.getStringSet("board_pkgs", emptySet())?.toSet() ?: emptySet()

    fun deleteBoard(pkg: String) {
        val set = boardPackages().toMutableSet().apply { remove(pkg) }
        sp.edit().remove("board_$pkg").putStringSet("board_pkgs", set).apply()
    }

    // ---------- game profiles (from Gemini auto-detect) ----------

    fun profile(pkg: String): GameProfile? {
        val s = sp.getString("profile_$pkg", null) ?: return null
        return try { GameProfile.fromJson(JSONObject(s)) } catch (e: Exception) { null }
    }

    fun saveProfile(pkg: String, p: GameProfile) {
        sp.edit().putString("profile_$pkg", p.toJson().toString()).apply()
        val set = boardPackages().toMutableSet().apply { add(pkg) }
        sp.edit().putStringSet("board_pkgs", set).apply()
    }

    /** Forget everything about a game so it is detected again. */
    fun forgetGame(pkg: String) {
        sp.edit().remove("profile_$pkg").apply()
        deleteBoard(pkg)
    }

    var chessThinkMs: Int
        get() = sp.getInt("chess_ms", 1500)
        set(v) = sp.edit().putInt("chess_ms", v.coerceIn(300, 8000)).apply()

    // ---------- recordings ----------

    private fun loadMacros(): List<Macro> {
        val s = sp.getString("macros", "[]") ?: "[]"
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map { Macro.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun storeMacros(list: List<Macro>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp.edit().putString("macros", arr.toString()).apply()
        _macros.value = list
    }

    fun addMacro(m: Macro) = storeMacros(_macros.value + m)

    fun deleteMacro(id: Long) = storeMacros(_macros.value.filterNot { it.id == id })

    fun renameMacro(id: Long, name: String) =
        storeMacros(_macros.value.map { if (it.id == id) it.copy(name = name) else it })
}
