package com.appforge.tappilot.game

import android.graphics.Bitmap
import com.appforge.tappilot.agent.GeminiClient
import com.appforge.tappilot.data.BoardConfig
import com.appforge.tappilot.data.GameProfile
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.PilotService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Looks at the game once with Gemini: what kind of game, where the board is, how big, what the goal is.
 * Then fine-tunes the board position on the phone and saves it, so Gemini isn't needed again for this game.
 */
class GameDetector(private val svc: PilotService) {

    data class Detected(val profile: GameProfile, val board: BoardConfig?)

    class NotReady(message: String) : Exception(message)

    suspend fun detect(pkg: String): Detected {
        if (Prefs.apiKey.isBlank()) {
            throw NotReady("Auto-detect needs your free Gemini key (Settings). Or set the grid by hand with ⊞ Grid.")
        }
        val popups = PopupHandler(svc)
        repeat(5) { attempt ->
            val bmp = svc.screenshot() ?: throw NotReady("Game mode needs Android 11 or newer.")
            svc.status("Gemini is looking at the game…")
            val o = GeminiClient.parseJson(GeminiClient.generate(SYSTEM, "Describe this game screen.", bmp, json = true))

            val state = o.optString("screen_state", "playing").lowercase()
            val type = o.optString("type", "other").lowercase()
            if (type == "not_a_game") throw NotReady("This doesn't look like a game. Open your game and try again.")
            if (o.optBoolean("online_vs_humans", false)) {
                throw NotReady("This is a match against real people online. TapPilot only plays against the computer or solo levels.")
            }
            if (state != "playing") {
                // Get past menus, ads and popups to an actual board first
                svc.status("Not on the board yet ($state). Getting there…")
                popups.handle(bmp, 3)
                delay(2500L + attempt * 500L)
                return@repeat
            }

            val (w, h) = svc.screenSize()
            val box = o.optJSONArray("board_box")
            val rough = if (box != null && box.length() == 4) {
                val ymin = box.optInt(0); val xmin = box.optInt(1); val ymax = box.optInt(2); val xmax = box.optInt(3)
                BoardConfig(
                    left = xmin * w / 1000, top = ymin * h / 1000,
                    right = xmax * w / 1000, bottom = ymax * h / 1000,
                    rows = o.optInt("rows", 8).coerceIn(3, 14),
                    cols = o.optInt("cols", 8).coerceIn(3, 14)
                )
            } else null

            val profile = GameProfile(
                type = when (type) {
                    "match3", "match-3" -> "match3"
                    "chess" -> "chess"
                    else -> "general"
                },
                name = o.optString("game_name", "game").take(40),
                goal = o.optString("goal", "").take(160),
                goalOnCells = o.optBoolean("goal_on_cells", false),
                rules = o.optString("rules", "").take(500),
                bottomIsWhite = o.optString("bottom_color", "white").lowercase() != "black",
                turnBased = o.optBoolean("turn_based", true)
            )

            val board = when (profile.type) {
                "match3" -> {
                    if (rough == null) throw NotReady("Gemini couldn't find the board. Use ⊞ Grid to set it by hand.")
                    svc.status("Lining up the grid…")
                    val tuned = withContext(Dispatchers.Default) { BoardReader.refine(Frame.of(bmp), rough) }
                    val check = BoardReader.read(bmp, tuned)
                    if (check.knownRatio < 0.4f) {
                        throw NotReady("Couldn't read the candies clearly. Use ⊞ Grid to set the board by hand.")
                    }
                    tuned
                }
                "chess" -> {
                    if (rough == null) throw NotReady("Gemini couldn't find the chess board.")
                    // chess boards are square: make the box square around its centre
                    val side = ((rough.right - rough.left) + (rough.bottom - rough.top)) / 2
                    val cx = (rough.left + rough.right) / 2
                    val cy = (rough.top + rough.bottom) / 2
                    BoardConfig(cx - side / 2, cy - side / 2, cx + side / 2, cy + side / 2, 8, 8)
                }
                else -> rough
            }

            if (profile.type == "general" && !profile.turnBased) {
                throw NotReady("${profile.name} is a fast real-time game. TapPilot can only play turn-based games.")
            }
            Prefs.saveProfile(pkg, profile)
            if (board != null) Prefs.saveBoard(pkg, board)
            return Detected(profile, board)
        }
        throw NotReady("Couldn't reach the game board. Start a level, then tap Play again.")
    }

    /**
     * For match-3 goals like ice or jelly: asks Gemini which cells still hold the goal.
     * Returns a rows×cols map (true = goal cell), or null.
     */
    suspend fun goalCells(bmp: Bitmap, cfg: BoardConfig, goal: String): Array<BooleanArray>? {
        val l = cfg.left.coerceAtLeast(0)
        val t = cfg.top.coerceAtLeast(0)
        val r = cfg.right.coerceAtMost(bmp.width)
        val b = cfg.bottom.coerceAtMost(bmp.height)
        if (r - l < 20 || b - t < 20) return null
        val crop = Bitmap.createBitmap(bmp, l, t, r - l, b - t)
        val prompt = "This image is exactly the game board: ${cfg.rows} rows × ${cfg.cols} columns of equal cells. " +
            "Level goal: \"$goal\". Mark every cell that still contains the goal item to clear " +
            "(for example ice, jelly, frosting, blockers the goal asks for). " +
            "Reply JSON: {\"grid\": [\"<${cfg.cols} chars>\", ... ${cfg.rows} strings]} using T for goal cells and . for others."
        return try {
            val o: JSONObject = GeminiClient.parseJson(
                GeminiClient.generate("You map grid cells precisely. Reply with JSON only.", prompt, crop, json = true)
            )
            val arr = o.optJSONArray("grid") ?: return null
            if (arr.length() != cfg.rows) return null
            Array(cfg.rows) { row ->
                val line = arr.optString(row, "")
                BooleanArray(cfg.cols) { c -> c < line.length && (line[c] == 'T' || line[c] == 't') }
            }
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        private val SYSTEM = """
You identify mobile games from a screenshot so an auto-player can set itself up.
Reply with ONE JSON object:
{
 "game_name": "<name if known, else short description>",
 "type": "match3 | chess | other | not_a_game",
 "screen_state": "playing | menu | level_start | level_end | ad | popup | loading",
 "turn_based": true|false,        // false for fast real-time games (runners, shooters, racing)
 "board_box": [ymin, xmin, ymax, xmax],  // the playing grid only, 0-1000 scale of the screenshot
 "rows": <number of cell rows in the grid>,
 "cols": <number of cell columns>,
 "goal": "<the level goal shown on screen, e.g. 'clear 13 ice in 26 moves'>",
 "goal_on_cells": true|false,     // true if the goal is items sitting in grid cells (ice, jelly, frosting)
 "bottom_color": "white | black", // chess only: colour of the pieces nearest the bottom
 "rules": "<2-3 short sentences: how to play and what action makes progress>",
 "online_vs_humans": true|false   // true if this is a live match against real people online
}
For match3, rows/cols count the full rectangle including empty corner cells; board_box covers that whole rectangle.
"screen_state" is "playing" only when the board is visible and waiting for a move.
""".trimIndent()
    }
}
