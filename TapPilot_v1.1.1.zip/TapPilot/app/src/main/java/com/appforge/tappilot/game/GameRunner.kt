package com.appforge.tappilot.game

import android.os.Build
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.game.chess.ChessRunner
import com.appforge.tappilot.service.PilotService

/**
 * Starts the right player for the game in front:
 * uses the saved profile, or asks Gemini to detect the game the first time.
 */
class GameRunner(private val svc: PilotService, private val gamePkg: String) {

    suspend fun run(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return "Game mode needs Android 11 or newer (screenshots)."
        }
        return try {
            var profile = Prefs.profile(gamePkg)
            var board = Prefs.board(gamePkg)
            if (profile == null && board != null) {
                // grid was set by hand (v1 style): treat as match-3
                profile = com.appforge.tappilot.data.GameProfile("match3", "game", "", false, "", true, true)
            }
            if (profile == null) {
                val d = GameDetector(svc).detect(gamePkg)
                profile = d.profile
                board = d.board
                svc.status("Detected: ${profile.name} (${label(profile.type)})")
            }
            when (profile.type) {
                "match3" -> Match3Runner(svc, gamePkg, profile, board ?: throw StopGame("No board saved. Tap ↻ to detect again.")).run()
                "chess" -> ChessRunner(svc, gamePkg, profile, board ?: throw StopGame("No board saved. Tap ↻ to detect again.")).run()
                else -> GeneralRunner(svc, gamePkg, profile).run()
            }
        } catch (e: GameDetector.NotReady) {
            e.message ?: "Couldn't detect the game."
        } catch (e: StopGame) {
            e.message ?: "Stopped."
        }
    }

    companion object {
        fun label(type: String) = when (type) {
            "match3" -> "match-3"
            "chess" -> "chess"
            else -> "General AI"
        }
    }
}
