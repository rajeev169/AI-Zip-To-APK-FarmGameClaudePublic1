package com.appforge.tappilot.game

import com.appforge.tappilot.agent.GeminiClient
import com.appforge.tappilot.data.GameProfile
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.PilotService
import com.appforge.tappilot.service.SafetyGuard
import kotlinx.coroutines.delay

/**
 * General AI mode for turn-based games without a built-in solver (puzzles, ludo vs computer, card games…).
 * Gemini looks at each screen and decides the next tap or swipe. Slow (one move every few seconds)
 * because the free key allows only a few requests per minute.
 */
class GeneralRunner(
    private val svc: PilotService,
    private val gamePkg: String,
    private val profile: GameProfile
) {
    private val guard = GameGuard(svc, gamePkg)
    private val history = ArrayDeque<String>()

    suspend fun run(): String {
        if (Prefs.apiKey.isBlank()) return "General AI mode needs your free Gemini key (Settings)."
        var moves = 0
        var waits = 0
        var errors = 0
        svc.status("General AI mode: ${profile.name}")

        while (true) {
            if (!guard.ensureInGame()) continue
            val bmp = svc.screenshot() ?: run { delay(800); null } ?: continue
            val (w, h) = svc.screenSize()

            val user = buildString {
                append("Game: ").append(profile.name).append('\n')
                if (profile.rules.isNotBlank()) append("How to play: ").append(profile.rules).append('\n')
                if (profile.goal.isNotBlank()) append("Goal: ").append(profile.goal).append('\n')
                if (history.isNotEmpty()) {
                    append("Your last actions (oldest first):\n")
                    history.forEach { append("- ").append(it).append('\n') }
                }
                append("Decide the single best next action from the screenshot.")
            }
            val o = try {
                GeminiClient.parseJson(GeminiClient.generate(SYSTEM, user, bmp, json = true))
            } catch (e: Exception) {
                errors++
                svc.status("Gemini: ${e.message}")
                if (errors >= 5) return "Stopped: Gemini kept failing (${e.message})."
                delay(5000)
                continue
            }
            errors = 0

            val action = o.optString("action").lowercase()
            val label = o.optString("label")
            val why = o.optString("thought").take(80)
            fun px(v: Int, size: Int) = v.coerceIn(0, 1000) / 1000f * size

            when (action) {
                "tap" -> {
                    if (SafetyGuard.isDangerousLabel(label)) {
                        remember("refused to tap \"$label\" (purchase/ad)")
                    } else {
                        svc.tap(px(o.optInt("x"), w), px(o.optInt("y"), h))
                        remember("tap ${o.optInt("x")},${o.optInt("y")} \"$label\"")
                        moves++
                    }
                }
                "swipe", "drag" -> {
                    svc.swipe(
                        px(o.optInt("x1"), w), px(o.optInt("y1"), h),
                        px(o.optInt("x2"), w), px(o.optInt("y2"), h),
                        o.optLong("ms", 400L).coerceIn(100L, 2000L)
                    )
                    remember("swipe ${o.optInt("x1")},${o.optInt("y1")} → ${o.optInt("x2")},${o.optInt("y2")}")
                    moves++
                }
                "back" -> { svc.back(); remember("back") }
                "wait" -> {
                    waits++
                    remember("wait")
                    if (waits > 40) return "Stopped: the game kept waiting for too long."
                    delay(o.optInt("seconds", 3).coerceIn(1, 15) * 1000L)
                    continue
                }
                "out_of_lives" -> return "Out of lives / energy after $moves moves. Try again later."
                "stop" -> return "Gemini stopped: ${o.optString("message").ifBlank { "nothing more to do" }}"
                else -> remember("unknown action")
            }
            waits = 0
            svc.status("AI move $moves: $why")
            guard.afterMove(1200, 1500, 3500)
        }
        return "Stopped"
    }

    private fun remember(s: String) {
        history.addLast(s)
        while (history.size > 8) history.removeFirst()
    }

    companion object {
        private val SYSTEM = """
You are playing a turn-based mobile game for the phone's owner, one action at a time, from screenshots.
Play well and keep the game going: make good moves, continue to the next level or a new game when one ends,
close ads (× / Skip / Close) and popups.
NEVER tap: buy, purchase, prices (₹, $), install, shop, offers, "watch ad"/"watch video", or anything that opens a store.
Never play against real people online; if the game is an online match against real players, answer stop.
Reply ONE JSON object:
{"thought": "<very short reason>",
 "action": "tap | swipe | back | wait | out_of_lives | stop",
 "x": 0-1000, "y": 0-1000, "label": "<what you tap>",          // for tap
 "x1": .., "y1": .., "x2": .., "y2": .., "ms": 400,             // for swipe/drag
 "seconds": 3,                                                   // for wait
 "message": "<for stop>"}
Coordinates are on a 0-1000 scale of the screenshot (0,0 = top-left). Aim at the exact centre of the target.
Use wait while the opponent/computer is moving, during animations, loading, or an ad countdown.
""".trimIndent()
    }
}
