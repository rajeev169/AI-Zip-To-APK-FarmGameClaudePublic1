package com.appforge.tappilot.game

import com.appforge.tappilot.data.BoardConfig
import com.appforge.tappilot.data.GameProfile
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.PilotService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.random.Random

/**
 * Plays a match-3 game: screenshot → read colours → best swap → swipe → repeat.
 * - Goal cells (ice, jelly) are refreshed with Gemini every few moves and get priority.
 * - If a swipe changes nothing, that move is skipped; repeated failures re-detect the board.
 * - When the board isn't visible (ads, popups, level end) the PopupHandler takes over.
 */
class Match3Runner(
    private val svc: PilotService,
    private val gamePkg: String,
    private val profile: GameProfile,
    private var cfg: BoardConfig
) {
    private val popups = PopupHandler(svc)
    private val guard = GameGuard(svc, gamePkg)
    private val detector = GameDetector(svc)

    suspend fun run(): String {
        var moves = 0
        var prev: BoardReader.Reading? = null
        var stableTries = 0
        var noMove = 0
        var popupStreak = 0
        var targets: Array<BooleanArray>? = null
        var movesSinceTargets = 999
        var lastMoveBoard: BoardReader.Reading? = null
        var lastMoveKey: String? = null
        val badMoves = HashSet<String>()
        var failedMoves = 0
        val useGoal = profile.goalOnCells && Prefs.apiKey.isNotBlank()

        svc.status("Playing ${profile.name.ifBlank { "match-3" }}…")

        while (true) {
            if (!guard.ensureInGame()) continue

            val bmp = svc.screenshot()
            if (bmp == null) { delay(800); continue }
            val reading = withContext(Dispatchers.Default) { BoardReader.read(bmp, cfg) }

            if (reading.knownRatio < 0.45f) {
                // Not on the board: ad, popup, level end…
                popupStreak++
                prev = null
                targets = null
                movesSinceTargets = 999
                when (popups.handle(bmp, popupStreak)) {
                    PopupHandler.Result.OUT_OF_LIVES -> return "Out of lives after $moves moves. Try again later."
                    PopupHandler.Result.TAPPED -> svc.status("Closed a popup / continued (moves: $moves)")
                    PopupHandler.Result.BACK -> svc.status("Pressed back (moves: $moves)")
                    PopupHandler.Result.WAITED -> svc.status("Waiting for the board… (moves: $moves)")
                }
                if (popupStreak > 30) return "Stuck on a screen after $moves moves. Stopped."
                delay(1500)
                continue
            }
            popupStreak = 0

            // Wait until candies stop falling (two equal readings in a row)
            if (!reading.sameAs(prev) && stableTries < 5) {
                prev = reading
                stableTries++
                delay(350)
                continue
            }
            stableTries = 0
            prev = null

            // Self-check: did the last swipe do anything?
            if (lastMoveBoard != null && reading.sameAs(lastMoveBoard)) {
                lastMoveKey?.let { badMoves.add(it) }
                failedMoves++
                if (failedMoves >= 4) {
                    svc.status("Moves aren't working — re-aligning the grid…")
                    val rough = cfg
                    val tuned = withContext(Dispatchers.Default) { BoardReader.refine(Frame.of(bmp), rough) }
                    cfg = tuned
                    Prefs.saveBoard(gamePkg, tuned)
                    failedMoves = 0
                    badMoves.clear()
                }
            } else if (lastMoveBoard != null) {
                failedMoves = 0
                badMoves.clear()
            }

            // Refresh goal cells (ice, jelly…) now and then
            if (useGoal && movesSinceTargets >= 8) {
                svc.status("Checking goal cells…")
                targets = detector.goalCells(bmp, cfg, profile.goal) ?: targets
                movesSinceTargets = 0
            }

            val move = Match3Solver.bestMove(reading.board, random = guard.human, targets = targets, skip = badMoves)
            if (move == null) {
                noMove++
                lastMoveBoard = null
                if (noMove >= 4) {
                    // Board-like screen with no moves: maybe a level-end screen drawn over the board
                    noMove = 0
                    popups.handle(bmp, 3)
                    delay(1500)
                } else delay(1200)
                continue
            }
            noMove = 0

            val x1 = cfg.cellCenterX(move.c1)
            val y1 = cfg.cellCenterY(move.r1)
            val x2 = cfg.cellCenterX(move.c2)
            val y2 = cfg.cellCenterY(move.r2)
            if (guard.human) {
                val jx = cfg.cellW * 0.12f
                val jy = cfg.cellH * 0.12f
                svc.swipe(
                    x1 + Random.nextFloat() * 2 * jx - jx, y1 + Random.nextFloat() * 2 * jy - jy,
                    x2 + Random.nextFloat() * 2 * jx - jx, y2 + Random.nextFloat() * 2 * jy - jy,
                    Random.nextLong(170, 330)
                )
            } else {
                svc.swipe(x1, y1, x2, y2, 160)
            }
            lastMoveBoard = reading
            lastMoveKey = move.key
            moves++
            movesSinceTargets++
            svc.status("Playing… moves: $moves" + if (targets != null) " · aiming at goal cells" else "")
            guard.afterMove(1100, 1600, 3800)
        }
        return "Stopped"
    }
}
