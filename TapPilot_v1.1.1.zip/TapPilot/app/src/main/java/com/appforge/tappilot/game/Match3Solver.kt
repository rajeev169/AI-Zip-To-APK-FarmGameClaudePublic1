package com.appforge.tappilot.game

/**
 * Finds the best swap on a match-3 board.
 * Board cells hold a colour index (0..5) or -1 for "unknown / blocker / empty".
 * Priority: 5 in a row (colour bomb) > T/L shape (wrapped) > 4 in a row (striped) > 3 in a row.
 * Matches on goal cells (ice, jelly…) get a big bonus. Ties go to lower moves (more cascades).
 */
object Match3Solver {

    data class Move(val r1: Int, val c1: Int, val r2: Int, val c2: Int, val score: Double) {
        val key: String get() = "$r1,$c1-$r2,$c2"
    }

    fun bestMove(
        board: Array<IntArray>,
        random: Boolean = false,
        targets: Array<BooleanArray>? = null,
        skip: Set<String> = emptySet()
    ): Move? {
        val rows = board.size
        if (rows == 0) return null
        val cols = board[0].size
        val moves = mutableListOf<Move>()
        val matched = HashSet<Int>()

        fun consider(r1: Int, c1: Int, r2: Int, c2: Int) {
            matched.clear()
            val s = scoreSwap(board, r1, c1, r2, c2, matched)
            if (s <= 0) return
            var bonus = 0.0
            if (targets != null) {
                for (cell in matched) {
                    val rr = cell / cols
                    val cc = cell % cols
                    if (rr < targets.size && cc < targets[rr].size && targets[rr][cc]) bonus += 18.0
                }
            }
            val m = Move(r1, c1, r2, c2, s + bonus + maxOf(r1, r2) * 0.05)
            if (m.key !in skip) moves.add(m)
        }

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (board[r][c] < 0) continue
                if (c + 1 < cols && board[r][c + 1] >= 0 && board[r][c + 1] != board[r][c]) consider(r, c, r, c + 1)
                if (r + 1 < rows && board[r + 1][c] >= 0 && board[r + 1][c] != board[r][c]) consider(r, c, r + 1, c)
            }
        }
        if (moves.isEmpty()) return null
        if (random) {
            // Human mode: usually the best move, sometimes a decent but not perfect one
            val top = moves.sortedByDescending { it.score }.take(3)
            return if (Math.random() < 0.8 || top.size == 1) top.first() else top.random()
        }
        return moves.maxByOrNull { it.score }
    }

    private fun scoreSwap(b: Array<IntArray>, r1: Int, c1: Int, r2: Int, c2: Int, matched: MutableSet<Int>): Double {
        val a = b[r1][c1]
        val bb = b[r2][c2]
        b[r1][c1] = bb
        b[r2][c2] = a
        val s = scoreAt(b, r1, c1, matched) + scoreAt(b, r2, c2, matched)
        b[r1][c1] = a
        b[r2][c2] = bb
        return s
    }

    private fun scoreAt(b: Array<IntArray>, r: Int, c: Int, matched: MutableSet<Int>): Double {
        val color = b[r][c]
        if (color < 0) return 0.0
        val rows = b.size
        val cols = b[0].size

        var left = 0
        while (c - left - 1 >= 0 && b[r][c - left - 1] == color) left++
        var right = 0
        while (c + right + 1 < cols && b[r][c + right + 1] == color) right++
        var up = 0
        while (r - up - 1 >= 0 && b[r - up - 1][c] == color) up++
        var down = 0
        while (r + down + 1 < rows && b[r + down + 1][c] == color) down++

        val h = left + right + 1
        val v = up + down + 1
        val hMatch = h >= 3
        val vMatch = v >= 3
        if (!hMatch && !vMatch) return 0.0

        if (hMatch) for (cc in (c - left)..(c + right)) matched.add(r * cols + cc)
        if (vMatch) for (rr in (r - up)..(r + down)) matched.add(rr * cols + c)

        return when {
            h >= 5 || v >= 5 -> 100.0
            hMatch && vMatch -> 60.0
            h == 4 || v == 4 -> 40.0
            else -> 10.0 + (if (hMatch) h else 0) + (if (vMatch) v else 0)
        }
    }
}
