package com.appforge.tappilot.game

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.appforge.tappilot.agent.GeminiClient
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.PilotService
import com.appforge.tappilot.service.SafetyGuard
import org.json.JSONObject

/**
 * Gets the game back to the board when something else is on screen:
 * level-complete screens, popups, daily spins, and ads (waits for the ×, then closes).
 * First tries readable buttons; for unknown screens asks Gemini once and remembers the answer.
 */
class PopupHandler(private val svc: PilotService) {

    enum class Result { TAPPED, WAITED, BACK, OUT_OF_LIVES }

    private val cache = mutableListOf<Pair<Long, Pair<Int, Int>>>() // screen hash -> tap point (0-1000)
    private var lastGeminiAt = 0L
    private var noKeyStreak = 0

    private val closeWords = listOf(
        "close", "skip", "skip ad", "skip video", "no thanks", "no, thanks", "not now", "later",
        "maybe later", "dismiss", "cancel", "close ad", "×", "✕", "✖", "x"
    )
    private val goWords = listOf(
        "continue", "next", "play", "play again", "retry", "try again", "ok", "okay", "start",
        "tap to continue", "collect", "claim", "got it", "level", "resume"
    )
    private val avoidWords = listOf("watch", "video for", "free lives", "get more", "shop", "store", "offer", "deal")

    suspend fun handle(bmp: Bitmap?, streak: Int): Result {
        // 1) A readable close/continue button?
        findButton(closeWords)?.let { svc.clickNode(it); return Result.TAPPED }
        if (streak >= 2) findButton(goWords)?.let { svc.clickNode(it); return Result.TAPPED }

        // Give ads and level animations a moment before doing anything else
        if (streak < 2 || bmp == null) return Result.WAITED

        // 2) Remembered screen?
        val (w, h) = svc.screenSize()
        val hash = dHash(bmp)
        cache.firstOrNull { java.lang.Long.bitCount(it.first xor hash) <= 5 }?.let { (_, pt) ->
            svc.tap(pt.first / 1000f * w, pt.second / 1000f * h)
            return Result.TAPPED
        }

        // 3) Ask Gemini (if a key is set), at most every 8 seconds
        if (Prefs.apiKey.isBlank()) {
            noKeyStreak++
            return if (noKeyStreak % 4 == 0) { svc.back(); Result.BACK } else Result.WAITED
        }
        if (System.currentTimeMillis() - lastGeminiAt < 8000) return Result.WAITED
        lastGeminiAt = System.currentTimeMillis()

        svc.status("Unknown screen — asking Gemini what to tap…")
        val reply = try {
            GeminiClient.parseJson(GeminiClient.generate(SYSTEM, "What should I tap now?", bmp, json = true))
        } catch (e: Exception) {
            svc.status("Gemini: ${e.message}")
            return Result.WAITED
        }
        return when (reply.optString("action").lowercase()) {
            "tap" -> {
                val label = reply.optString("label")
                if (SafetyGuard.isDangerousLabel(label) || avoidWords.any { label.lowercase().contains(it) }) {
                    Result.WAITED
                } else {
                    val x = reply.optInt("x", -1)
                    val y = reply.optInt("y", -1)
                    if (x in 0..1000 && y in 0..1000) {
                        if (reply.optBoolean("same_every_time", true)) cache.add(hash to (x to y))
                        if (cache.size > 40) cache.removeAt(0)
                        svc.tap(x / 1000f * w, y / 1000f * h)
                        Result.TAPPED
                    } else Result.WAITED
                }
            }
            "back" -> { svc.back(); Result.BACK }
            "out_of_lives" -> Result.OUT_OF_LIVES
            else -> Result.WAITED
        }
    }

    private fun findButton(words: List<String>): AccessibilityNodeInfo? {
        val root = svc.rootInActiveWindow ?: return null
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        var seen = 0
        while (stack.isNotEmpty() && seen < 500) {
            val n = stack.removeLast()
            seen++
            if (n.isVisibleToUser && (n.isClickable || n.parent?.isClickable == true)) {
                val label = listOfNotNull(
                    n.text?.toString(), n.contentDescription?.toString(),
                    n.viewIdResourceName?.substringAfterLast('/')?.replace('_', ' ')
                ).joinToString(" ").lowercase().trim()
                if (label.isNotEmpty() && label.length < 60 &&
                    !SafetyGuard.isDangerousLabel(label) && avoidWords.none { label.contains(it) } &&
                    words.any { w -> if (w.length <= 1) label == w else SafetyGuard.containsWord(label, w) }
                ) {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    if (!r.isEmpty) return n
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.addLast(it) }
        }
        return null
    }

    /** 64-bit difference hash: similar screens give similar hashes. */
    private fun dHash(src: Bitmap): Long {
        val small = Bitmap.createScaledBitmap(src, 9, 8, true)
        var hash = 0L
        var bit = 0
        for (y in 0 until 8) {
            for (x in 0 until 8) {
                val a = lum(small.getPixel(x, y))
                val b = lum(small.getPixel(x + 1, y))
                if (a > b) hash = hash or (1L shl bit)
                bit++
            }
        }
        return hash
    }

    private fun lum(c: Int): Int = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000

    companion object {
        private val SYSTEM = """
You help an auto-player of a casual match-3 mobile game get back to playing.
You see a screenshot where the candy board is NOT in normal play. Decide ONE action.
Goal: close ads and popups, and continue to the next or same level (Play / Next / Continue / Retry / OK / X).
NEVER tap: buy, purchase, prices (₹, $), install, "watch ad"/"watch video", shop, offers, or anything that opens a store or website.
If an ad shows a countdown and no close button yet, or a loading screen, answer wait.
If the player has no lives left and must wait or pay, answer out_of_lives.
Reply JSON only:
{"action":"tap|wait|back|out_of_lives","x":0-1000,"y":0-1000,"label":"<text or icon you tap>","same_every_time":true|false}
x,y are on a 0-1000 scale of the screenshot (0,0 top-left). same_every_time=false if the button position changes (e.g. ad close buttons).
""".trimIndent()
    }
}
