package com.appforge.tappilot.game.chess

/**
 * Full chess rules: legal moves incl. castling, en passant and promotion.
 * Squares 0..63 = a1..h8 (index = rank * 8 + file). Pieces: 1..6 white P N B R Q K, +8 for black.
 * Moves are packed Ints: from | to<<6 | promo<<12 | flags<<16. (Verified against standard perft numbers.)
 */
class ChessBoard {
    val sq = IntArray(64)
    var side = WHITE
    var castle = 0
    var ep = -1
    var half = 0
    val king = intArrayOf(4, 60)

    private val histMove = IntArray(1024)
    private val histCap = IntArray(1024)
    private val histCastle = IntArray(1024)
    private val histEp = IntArray(1024)
    private val histHalf = IntArray(1024)
    var ply = 0
        private set

    fun copy(): ChessBoard {
        val b = ChessBoard()
        sq.copyInto(b.sq)
        b.side = side; b.castle = castle; b.ep = ep; b.half = half
        b.king[0] = king[0]; b.king[1] = king[1]
        return b
    }

    fun attacked(s: Int, by: Int): Boolean {
        val f = s % 8
        val r = s / 8
        val pr = if (by == WHITE) r - 1 else r + 1
        val pawn = P or (by * 8)
        if (pr in 0..7) {
            if (f - 1 >= 0 && sq[pr * 8 + f - 1] == pawn) return true
            if (f + 1 <= 7 && sq[pr * 8 + f + 1] == pawn) return true
        }
        val knight = N or (by * 8)
        for (k in 0 until 8) {
            val ff = f + KN_DF[k]; val rr = r + KN_DR[k]
            if (ff in 0..7 && rr in 0..7 && sq[rr * 8 + ff] == knight) return true
        }
        val kg = K or (by * 8)
        for (k in 0 until 8) {
            val ff = f + KG_DF[k]; val rr = r + KG_DR[k]
            if (ff in 0..7 && rr in 0..7 && sq[rr * 8 + ff] == kg) return true
        }
        val bishop = B or (by * 8)
        val rook = R or (by * 8)
        val queen = Q or (by * 8)
        for (k in 0 until 8) {
            val df = KG_DF[k]; val dr = KG_DR[k]
            val diagonal = df != 0 && dr != 0
            var ff = f + df; var rr = r + dr
            while (ff in 0..7 && rr in 0..7) {
                val p = sq[rr * 8 + ff]
                if (p != 0) {
                    if (p == queen || (diagonal && p == bishop) || (!diagonal && p == rook)) return true
                    break
                }
                ff += df; rr += dr
            }
        }
        return false
    }

    fun inCheck(who: Int = side): Boolean = attacked(king[who], 1 - who)

    /** Pseudo-legal moves; capsOnly = captures and queen promotions (for quiescence search). */
    fun pseudo(out: IntArray, capsOnly: Boolean = false): Int {
        var n = 0
        val us = side
        val them = 1 - us
        for (i in 0 until 64) {
            val p = sq[i]
            if (p == 0 || (p shr 3) != us) continue
            val t = p and 7
            val f = i % 8
            val r = i / 8
            when (t) {
                P -> {
                    val d = if (us == WHITE) 8 else -8
                    val start = if (us == WHITE) 1 else 6
                    val last = if (us == WHITE) 7 else 0
                    val to = i + d
                    if (to in 0..63 && sq[to] == 0) {
                        if (to / 8 == last) {
                            out[n++] = mv(i, to, Q)
                            if (!capsOnly) { out[n++] = mv(i, to, R); out[n++] = mv(i, to, B); out[n++] = mv(i, to, N) }
                        } else if (!capsOnly) {
                            out[n++] = mv(i, to)
                            if (r == start && sq[to + d] == 0) out[n++] = mv(i, to + d, 0, F_DOUBLE)
                        }
                    }
                    for (df in intArrayOf(-1, 1)) {
                        val ff = f + df
                        if (ff !in 0..7) continue
                        val ct = i + d + df
                        if (ct !in 0..63) continue
                        val q = sq[ct]
                        if (q != 0 && (q shr 3) == them) {
                            if (ct / 8 == last) {
                                out[n++] = mv(i, ct, Q, F_CAP)
                                if (!capsOnly) { out[n++] = mv(i, ct, R, F_CAP); out[n++] = mv(i, ct, B, F_CAP); out[n++] = mv(i, ct, N, F_CAP) }
                            } else out[n++] = mv(i, ct, 0, F_CAP)
                        } else if (ct == ep) {
                            out[n++] = mv(i, ct, 0, F_CAP or F_EP)
                        }
                    }
                }
                N, K -> {
                    val dfs = if (t == N) KN_DF else KG_DF
                    val drs = if (t == N) KN_DR else KG_DR
                    for (k in 0 until 8) {
                        val ff = f + dfs[k]; val rr = r + drs[k]
                        if (ff !in 0..7 || rr !in 0..7) continue
                        val to = rr * 8 + ff
                        val q = sq[to]
                        if (q == 0) {
                            if (!capsOnly) out[n++] = mv(i, to)
                        } else if ((q shr 3) == them) out[n++] = mv(i, to, 0, F_CAP)
                    }
                    if (t == K && !capsOnly) {
                        val base = if (us == WHITE) 0 else 56
                        if (i == base + 4 && !attacked(i, them)) {
                            val ks = if (us == WHITE) 1 else 4
                            val qs = if (us == WHITE) 2 else 8
                            val rookP = R or (us * 8)
                            if ((castle and ks) != 0 && sq[base + 5] == 0 && sq[base + 6] == 0 && sq[base + 7] == rookP &&
                                !attacked(base + 5, them) && !attacked(base + 6, them)
                            ) out[n++] = mv(i, base + 6, 0, F_CASTLE)
                            if ((castle and qs) != 0 && sq[base + 3] == 0 && sq[base + 2] == 0 && sq[base + 1] == 0 &&
                                sq[base] == rookP && !attacked(base + 3, them) && !attacked(base + 2, them)
                            ) out[n++] = mv(i, base + 2, 0, F_CASTLE)
                        }
                    }
                }
                else -> {
                    for (k in 0 until 8) {
                        val df = KG_DF[k]; val dr = KG_DR[k]
                        val diagonal = df != 0 && dr != 0
                        if (t == B && !diagonal) continue
                        if (t == R && diagonal) continue
                        var ff = f + df; var rr = r + dr
                        while (ff in 0..7 && rr in 0..7) {
                            val to = rr * 8 + ff
                            val q = sq[to]
                            if (q == 0) {
                                if (!capsOnly) out[n++] = mv(i, to)
                            } else {
                                if ((q shr 3) == them) out[n++] = mv(i, to, 0, F_CAP)
                                break
                            }
                            ff += df; rr += dr
                        }
                    }
                }
            }
        }
        return n
    }

    fun make(m: Int) {
        val fr = from(m); val to = toSq(m); val pr = promo(m); val fl = flags(m)
        val p = sq[fr]
        val us = side
        var cap = sq[to]
        if ((fl and F_EP) != 0) {
            val capSq = if (us == WHITE) to - 8 else to + 8
            cap = sq[capSq]
            sq[capSq] = 0
        }
        histMove[ply] = m; histCap[ply] = cap; histCastle[ply] = castle; histEp[ply] = ep; histHalf[ply] = half
        ply++
        sq[to] = if (pr != 0) pr or (us * 8) else p
        sq[fr] = 0
        if ((p and 7) == K) {
            king[us] = to
            if ((fl and F_CASTLE) != 0) {
                val base = if (us == WHITE) 0 else 56
                if (to == base + 6) { sq[base + 5] = sq[base + 7]; sq[base + 7] = 0 }
                else { sq[base + 3] = sq[base]; sq[base] = 0 }
            }
        }
        castle = castle and CASTLE_MASK[fr] and CASTLE_MASK[to]
        ep = if ((fl and F_DOUBLE) != 0) (fr + to) / 2 else -1
        half = if ((p and 7) == P || cap != 0) 0 else half + 1
        side = 1 - us
    }

    fun unmake() {
        ply--
        val m = histMove[ply]
        val cap = histCap[ply]
        val fr = from(m); val to = toSq(m); val pr = promo(m); val fl = flags(m)
        side = 1 - side
        val us = side
        var p = sq[to]
        if (pr != 0) p = P or (us * 8)
        sq[fr] = p
        sq[to] = 0
        if ((fl and F_EP) != 0) {
            sq[if (us == WHITE) to - 8 else to + 8] = cap
        } else {
            sq[to] = cap
        }
        if ((p and 7) == K) {
            king[us] = fr
            if ((fl and F_CASTLE) != 0) {
                val base = if (us == WHITE) 0 else 56
                if (to == base + 6) { sq[base + 7] = sq[base + 5]; sq[base + 5] = 0 }
                else { sq[base] = sq[base + 3]; sq[base + 3] = 0 }
            }
        }
        castle = histCastle[ply]; ep = histEp[ply]; half = histHalf[ply]
    }

    /** All legal moves. */
    fun legal(capsOnly: Boolean = false): IntArray {
        val buf = IntArray(256)
        val n = pseudo(buf, capsOnly)
        val res = IntArray(n)
        var k = 0
        for (i in 0 until n) {
            make(buf[i])
            if (!attacked(king[1 - side], side)) res[k++] = buf[i]
            unmake()
        }
        return res.copyOf(k)
    }

    /** Pieces only (no turn info): true where a square is occupied. */
    fun occupancy(): BooleanArray = BooleanArray(64) { sq[it] != 0 }

    fun toFen(): String {
        val sb = StringBuilder()
        for (rank in 7 downTo 0) {
            var empty = 0
            for (f in 0 until 8) {
                val p = sq[rank * 8 + f]
                if (p == 0) { empty++; continue }
                if (empty > 0) { sb.append(empty); empty = 0 }
                val ch = "?pnbrqk"[p and 7]
                sb.append(if ((p shr 3) == WHITE) ch.uppercaseChar() else ch)
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        sb.append(if (side == WHITE) " w " else " b ")
        var cs = ""
        if ((castle and 1) != 0) cs += "K"
        if ((castle and 2) != 0) cs += "Q"
        if ((castle and 4) != 0) cs += "k"
        if ((castle and 8) != 0) cs += "q"
        sb.append(cs.ifEmpty { "-" })
        sb.append(' ').append(if (ep < 0) "-" else squareName(ep))
        sb.append(' ').append(half).append(" 1")
        return sb.toString()
    }

    companion object {
        const val WHITE = 0
        const val BLACK = 1
        const val P = 1; const val N = 2; const val B = 3; const val R = 4; const val Q = 5; const val K = 6
        const val F_CAP = 1; const val F_EP = 2; const val F_CASTLE = 4; const val F_DOUBLE = 8

        val KN_DF = intArrayOf(1, 2, 2, 1, -1, -2, -2, -1)
        val KN_DR = intArrayOf(2, 1, -1, -2, -2, -1, 1, 2)
        val KG_DF = intArrayOf(1, 1, 0, -1, -1, -1, 0, 1)
        val KG_DR = intArrayOf(0, 1, 1, 1, 0, -1, -1, -1)

        val CASTLE_MASK = IntArray(64) { 15 }.also {
            it[0] = 15 and 2.inv(); it[7] = 15 and 1.inv(); it[4] = 15 and 3.inv()
            it[56] = 15 and 8.inv(); it[63] = 15 and 4.inv(); it[60] = 15 and 12.inv()
        }

        fun mv(fr: Int, to: Int, promo: Int = 0, flags: Int = 0): Int = fr or (to shl 6) or (promo shl 12) or (flags shl 16)
        fun from(m: Int) = m and 63
        fun toSq(m: Int) = (m shr 6) and 63
        fun promo(m: Int) = (m shr 12) and 7
        fun flags(m: Int) = (m shr 16) and 15

        fun squareName(s: Int): String = "" + ('a' + s % 8) + ('1' + s / 8)

        fun uci(m: Int): String {
            val pr = promo(m)
            return squareName(from(m)) + squareName(toSq(m)) + if (pr != 0) "?pnbrqk"[pr].toString() else ""
        }

        fun start(): ChessBoard = fromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")

        fun fromFen(fen: String): ChessBoard {
            val b = ChessBoard()
            val parts = fen.trim().split(Regex("\\s+"))
            val rows = parts[0].split('/')
            for ((i, row) in rows.withIndex()) {
                if (i > 7) break
                val rank = 7 - i
                var f = 0
                for (ch in row) {
                    if (f > 7) break
                    if (ch.isDigit()) { f += ch - '0'; continue }
                    val t = "?pnbrqk".indexOf(ch.lowercaseChar())
                    if (t <= 0) { f++; continue }
                    val color = if (ch.isUpperCase()) WHITE else BLACK
                    b.sq[rank * 8 + f] = t or (color * 8)
                    if (t == K) b.king[color] = rank * 8 + f
                    f++
                }
            }
            b.side = if (parts.size < 2 || parts[1] == "w") WHITE else BLACK
            val cs = parts.getOrElse(2) { "-" }
            b.castle = (if ('K' in cs) 1 else 0) or (if ('Q' in cs) 2 else 0) or (if ('k' in cs) 4 else 0) or (if ('q' in cs) 8 else 0)
            val e = parts.getOrElse(3) { "-" }
            b.ep = if (e.length == 2 && e[0] in 'a'..'h' && e[1] in '1'..'8') (e[1] - '1') * 8 + (e[0] - 'a') else -1
            return b
        }
    }
}
