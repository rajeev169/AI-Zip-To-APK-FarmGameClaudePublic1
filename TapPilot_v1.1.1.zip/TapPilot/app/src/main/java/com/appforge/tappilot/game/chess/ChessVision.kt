package com.appforge.tappilot.game.chess

import com.appforge.tappilot.data.BoardConfig
import com.appforge.tappilot.game.Frame
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Sees a chess board without recognising piece shapes:
 * a square with a piece has lots of detail (high brightness variation), an empty square is flat.
 * Which move was played is then worked out from the rules (see ChessRunner).
 */
class ChessVision(var cfg: BoardConfig, var bottomIsWhite: Boolean) {

    /** Per-square look: detail (std of brightness), average colour, brightness of the centre. */
    class SquareLook(val detail: Float, val r: Float, val g: Float, val b: Float, val centerLum: Float) {
        fun differs(o: SquareLook): Boolean =
            abs(detail - o.detail) > 6f || abs(r - o.r) + abs(g - o.g) + abs(b - o.b) > 30f || abs(centerLum - o.centerLum) > 25f
    }

    var threshold = 12f

    /** Screen position (col,row 0..7 from top-left) of a board square (0 = a1). */
    fun screenCell(square: Int): Pair<Int, Int> {
        val file = square % 8
        val rank = square / 8
        return if (bottomIsWhite) file to (7 - rank) else (7 - file) to rank
    }

    fun centerX(square: Int): Float = cfg.cellCenterX(screenCell(square).first)
    fun centerY(square: Int): Float = cfg.cellCenterY(screenCell(square).second)

    fun look(f: Frame): Array<SquareLook> = lookWith(f, cfg)

    private fun lookWith(f: Frame, c: BoardConfig): Array<SquareLook> = Array(64) { sq ->
        val (col, row) = screenCell(sq)
        val cx = c.cellCenterX(col)
        val cy = c.cellCenterY(row)
        val span = 0.68f
        val n = 9
        var sum = 0f; var sq2 = 0f; var rs = 0f; var gs = 0f; var bs = 0f; var cnt = 0
        var cSum = 0f; var cCnt = 0
        for (i in 0 until n) for (j in 0 until n) {
            val x = (cx - c.cellW * span / 2 + c.cellW * span * (i + 0.5f) / n).toInt()
            val y = (cy - c.cellH * span / 2 + c.cellH * span * (j + 0.5f) / n).toInt()
            if (x < 0 || y < 0 || x >= f.width || y >= f.height) continue
            val p = f.px(x, y)
            val r = ((p shr 16) and 0xFF).toFloat()
            val g = ((p shr 8) and 0xFF).toFloat()
            val b = (p and 0xFF).toFloat()
            val lum = 0.299f * r + 0.587f * g + 0.114f * b
            sum += lum; sq2 += lum * lum; rs += r; gs += g; bs += b; cnt++
            if (i in 3..5 && j in 3..5) { cSum += lum; cCnt++ }
        }
        if (cnt == 0) SquareLook(0f, 0f, 0f, 0f, 0f) else {
            val mean = sum / cnt
            val v = (sq2 / cnt - mean * mean).coerceAtLeast(0f)
            SquareLook(sqrt(v), rs / cnt, gs / cnt, bs / cnt, if (cCnt > 0) cSum / cCnt else mean)
        }
    }

    fun occupancy(looks: Array<SquareLook>): BooleanArray = BooleanArray(64) { looks[it].detail > threshold }

    /** Otsu split of the 64 detail values into "empty" and "piece". */
    fun autoThreshold(looks: Array<SquareLook>): Float {
        val v = looks.map { it.detail }.sorted()
        var bestT = threshold
        var bestVar = -1f
        for (k in 1 until v.size) {
            val a = v.subList(0, k)
            val b = v.subList(k, v.size)
            val ma = a.average().toFloat()
            val mb = b.average().toFloat()
            val between = a.size.toFloat() * b.size * (ma - mb) * (ma - mb)
            if (between > bestVar) { bestVar = between; bestT = (v[k - 1] + v[k]) / 2f }
        }
        return bestT
    }

    /** How many squares match the standard starting layout (ranks 1,2,7,8 full, rest empty). */
    fun startMatches(occ: BooleanArray): Int {
        var m = 0
        for (s in 0 until 64) {
            val rank = s / 8
            val expect = rank <= 1 || rank >= 6
            if (occ[s] == expect) m++
        }
        return m
    }

    /** Bottom pieces lighter than top pieces → White is at the bottom. */
    fun bottomLooksWhite(looks: Array<SquareLook>): Boolean {
        // compare by screen rows, independent of the current orientation guess
        var bottom = 0f; var top = 0f
        for (s in 0 until 64) {
            val row = screenCell(s).second
            if (row >= 6) bottom += looks[s].centerLum
            if (row <= 1) top += looks[s].centerLum
        }
        return bottom >= top
    }

    /**
     * If the board is at the starting position, nudges the board box until the
     * starting layout is seen perfectly, and sets the detail threshold from it. Returns true on success.
     */
    fun calibrateOnStart(f: Frame): Boolean {
        var best: BoardConfig? = null
        var bestScore = -1f
        for (scale in floatArrayOf(0.95f, 0.98f, 1f, 1.02f, 1.05f)) {
            for (sx in -3..3) for (sy in -3..3) {
                val c = transform(cfg, scale, sx * cfg.cellW * 0.08f, sy * cfg.cellH * 0.08f)
                val looks = lookWith(f, c)
                var occ = 0f; var emp = 0f
                for (s in 0 until 64) {
                    val rank = s / 8
                    if (rank <= 1 || rank >= 6) occ += looks[s].detail else emp += looks[s].detail
                }
                val score = occ / 32f - emp / 32f
                if (score > bestScore) { bestScore = score; best = c }
            }
        }
        val c = best ?: return false
        val looks = lookWith(f, c)
        val t = autoThreshold(looks)
        val occ = BooleanArray(64) { looks[it].detail > t }
        if (startMatches(occ) < 62) return false
        cfg = c
        threshold = t
        return true
    }

    private fun transform(b: BoardConfig, scale: Float, dx: Float, dy: Float): BoardConfig {
        val cx = (b.left + b.right) / 2f + dx
        val cy = (b.top + b.bottom) / 2f + dy
        val hw = (b.right - b.left) / 2f * scale
        val hh = (b.bottom - b.top) / 2f * scale
        return b.copy(
            left = (cx - hw).toInt(), right = (cx + hw).toInt(),
            top = (cy - hh).toInt(), bottom = (cy + hh).toInt()
        )
    }
}
