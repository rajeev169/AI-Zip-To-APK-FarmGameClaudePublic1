package com.appforge.tappilot.game.chess

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.OutputStreamWriter

/**
 * Optional Stockfish support. If the project contains
 *   app/src/main/jniLibs/arm64-v8a/libstockfish.so   (the Stockfish Android binary, renamed)
 * TapPilot uses it instead of the built-in engine. Otherwise this stays unused.
 */
class UciEngine private constructor(private val proc: Process) {

    private val input: BufferedReader = proc.inputStream.bufferedReader()
    private val output = OutputStreamWriter(proc.outputStream)

    private fun send(cmd: String) {
        output.write(cmd + "\n")
        output.flush()
    }

    private fun waitFor(prefix: String, timeoutMs: Long): String? {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            val line = input.readLine() ?: return null
            if (line.startsWith(prefix)) return line
        }
        return null
    }

    /** Best move in UCI form ("e2e4", "e7e8q"), or null. */
    suspend fun bestMove(fen: String, timeMs: Long): String? = withContext(Dispatchers.IO) {
        try {
            send("position fen $fen")
            send("go movetime $timeMs")
            waitFor("bestmove", timeMs + 5000)?.split(" ")?.getOrNull(1)?.takeIf { it != "(none)" }
        } catch (e: Exception) {
            null
        }
    }

    fun close() {
        try { send("quit") } catch (_: Exception) {}
        proc.destroy()
    }

    companion object {
        suspend fun startIfBundled(context: Context): UciEngine? = withContext(Dispatchers.IO) {
            val f = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")
            if (!f.exists()) return@withContext null
            try {
                val p = ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
                val e = UciEngine(p)
                e.send("uci")
                if (e.waitFor("uciok", 4000) == null) { e.close(); return@withContext null }
                e.send("isready")
                if (e.waitFor("readyok", 4000) == null) { e.close(); return@withContext null }
                e
            } catch (ex: Exception) {
                null
            }
        }
    }
}
