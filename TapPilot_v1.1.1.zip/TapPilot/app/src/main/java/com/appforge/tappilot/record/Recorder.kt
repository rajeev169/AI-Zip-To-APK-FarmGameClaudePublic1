package com.appforge.tappilot.record

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.appforge.tappilot.data.Macro
import com.appforge.tappilot.data.MacroStep
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.FloatingPanel
import com.appforge.tappilot.service.PilotService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.hypot

/**
 * Records taps, long presses and swipes.
 * A clear full-screen layer catches each touch, saves it, then passes the same gesture on to the app below.
 */
class Recorder(private val svc: PilotService) {

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var layer: View? = null
    private var layerParams: WindowManager.LayoutParams? = null
    private val steps = mutableListOf<MacroStep>()
    private var lastEnd = 0L
    private var pkg: String? = null

    val isRecording: Boolean get() = layer != null

    fun start() {
        if (layer != null) return
        steps.clear()
        pkg = null
        lastEnd = 0L
        svc.scope.launch {
            for (i in 3 downTo 1) {
                svc.panel.show("Recording starts in $i… open the app you want", listOf(cancelBtn()))
                delay(1000)
            }
            addLayer()
            updatePanel()
        }
    }

    private fun cancelBtn() = FloatingPanel.Btn("Cancel", FloatingPanel.GREY) { stop(save = false) }

    private fun updatePanel() {
        svc.panel.show(
            "● Recording — ${steps.size} steps. Use the phone normally.",
            listOf(
                cancelBtn(),
                FloatingPanel.Btn("Save", FloatingPanel.GREEN) { stop(save = true) }
            )
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addLayer() {
        val v = View(svc).apply { setBackgroundColor(Color.parseColor("#0A3D2BB5")) }
        var downX = 0f
        var downY = 0f
        var downAt = 0L
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; downAt = SystemClock.uptimeMillis()
                }
                MotionEvent.ACTION_UP -> {
                    val upX = e.rawX
                    val upY = e.rawY
                    val dur = (SystemClock.uptimeMillis() - downAt).coerceAtLeast(40L)
                    val dist = hypot((upX - downX).toDouble(), (upY - downY).toDouble())
                    val type = when {
                        dist < 25 && dur >= 500 -> "long"
                        dist < 25 -> "tap"
                        else -> "swipe"
                    }
                    val delayMs = if (lastEnd == 0L) 600L else (downAt - lastEnd).coerceIn(150L, 30_000L)
                    val step = MacroStep(type, downX, downY, upX, upY, if (type == "tap") 60L else dur.coerceAtMost(3000L), delayMs)
                    if (pkg == null) pkg = svc.foregroundPackage()
                    steps.add(step)
                    passOn(step)
                }
            }
            true
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            wm.addView(v, lp)
            layer = v
            layerParams = lp
            // keep the control panel above the recording layer
            svc.panel.hide()
        } catch (e: Exception) {
            svc.status("Could not start recording: ${e.message}")
        }
    }

    /** Lets the touch through to the real app by replaying it with the layer switched off. */
    private fun passOn(step: MacroStep) {
        val v = layer ?: return
        val p = layerParams ?: return
        svc.scope.launch {
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
            perform(svc, step)
            delay(120)
            if (layer != null) {
                p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
            }
            lastEnd = SystemClock.uptimeMillis()
            updatePanel()
        }
    }

    fun stop(save: Boolean) {
        layer?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        layer = null
        layerParams = null
        if (save && steps.isNotEmpty()) {
            val n = Prefs.macros.value.size + 1
            Prefs.addMacro(Macro(System.currentTimeMillis(), "Recording $n", pkg, steps.toList()))
            svc.panel.show("Saved \"Recording $n\" (${steps.size} steps). Rename it in TapPilot.",
                listOf(FloatingPanel.Btn("OK", FloatingPanel.GREEN) { svc.panel.hide() }))
        } else {
            svc.panel.hide()
        }
        steps.clear()
    }

    companion object {
        suspend fun perform(svc: PilotService, s: MacroStep): Boolean = when (s.type) {
            "long" -> svc.longPress(s.x1, s.y1, s.durationMs.coerceAtLeast(500L))
            "swipe" -> svc.swipe(s.x1, s.y1, s.x2, s.y2, s.durationMs.coerceIn(80L, 3000L))
            else -> svc.tap(s.x1, s.y1)
        }

        /** Plays a recording [times] times (0 = until stopped). */
        suspend fun replay(svc: PilotService, m: Macro, times: Int): String {
            val pkg = m.packageName
            if (pkg != null && svc.launchPackage(pkg)) {
                svc.status("Opening the app…")
                delay(2000)
            } else {
                delay(1500) // let TapPilot's own screen slide away first
            }
            var round = 0
            while (times == 0 || round < times) {
                round++
                svc.status("Replaying \"${m.name}\" — round $round${if (times > 0) " of $times" else ""}")
                for (s in m.steps) {
                    delay(s.delayMs)
                    perform(svc, s)
                }
                delay(800)
            }
            return "Replayed \"${m.name}\" $round time(s)"
        }
    }
}
