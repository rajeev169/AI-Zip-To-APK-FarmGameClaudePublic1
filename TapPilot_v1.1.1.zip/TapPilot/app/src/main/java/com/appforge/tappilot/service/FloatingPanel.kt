package com.appforge.tappilot.service

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** A small draggable control panel shown on top of every app (uses the accessibility overlay, no extra permission). */
class FloatingPanel(private val context: Context) {

    data class Btn(val label: String, val color: Int, val onClick: () -> Unit)

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var statusView: TextView? = null
    private var buttonRow: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var lastX = 0
    private var lastY = 260

    val isShowing: Boolean get() = root != null

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), context.resources.displayMetrics
    ).toInt()

    @SuppressLint("ClickableViewAccessibility")
    fun show(status: String, buttons: List<Btn>) {
        if (root == null) {
            val card = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(10))
                background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    setColor(Color.parseColor("#E6241A7A"))
                }
                elevation = dp(6).toFloat()
            }
            val st = TextView(context).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                maxWidth = dp(220)
                maxLines = 3
                setPadding(dp(2), 0, dp(2), dp(6))
            }
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            card.addView(st)
            card.addView(row)

            // Drag the panel by its status text
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            st.setOnTouchListener { _, e ->
                val p = params ?: return@setOnTouchListener false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = startX + (e.rawX - downX).toInt()
                        p.y = startY + (e.rawY - downY).toInt()
                        lastX = p.x; lastY = p.y
                        try { wm.updateViewLayout(root, p) } catch (_: Exception) {}
                    }
                }
                true
            }

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = lastX
                y = lastY
            }
            try {
                wm.addView(card, lp)
            } catch (e: Exception) {
                return
            }
            root = card
            statusView = st
            buttonRow = row
            params = lp
        }
        statusView?.text = status
        setButtons(buttons)
    }

    fun update(status: String) {
        statusView?.text = status
    }

    fun setButtons(buttons: List<Btn>) {
        val row = buttonRow ?: return
        row.removeAllViews()
        buttons.forEachIndexed { i, b ->
            val tv = TextView(context).apply {
                text = b.label
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                gravity = Gravity.CENTER
                minWidth = dp(52)
                setPadding(dp(12), dp(9), dp(12), dp(9))
                background = GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setColor(b.color)
                }
                setOnClickListener { b.onClick() }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            if (i > 0) lp.marginStart = dp(6)
            row.addView(tv, lp)
        }
    }

    /** Area of the panel on screen, so game mode / agent can avoid tapping it. */
    fun boundsContains(x: Float, y: Float): Boolean {
        val v: View = root ?: return false
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return x >= loc[0] && x <= loc[0] + v.width && y >= loc[1] && y <= loc[1] + v.height
    }

    /** While true, the panel is see-through and lets touches pass to the app below. */
    fun passThrough(on: Boolean) {
        val v = root ?: return
        val p = params ?: return
        p.flags = if (on) p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        else p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        v.alpha = if (on) 0.25f else 1f
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    fun hide() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        statusView = null
        buttonRow = null
        params = null
    }

    companion object {
        val RED = Color.parseColor("#E53935")
        val GREEN = Color.parseColor("#2E9D5B")
        val BLUE = Color.parseColor("#3F6BE0")
        val GREY = Color.parseColor("#5A5480")
        val ORANGE = Color.parseColor("#E07B1F")
    }
}
