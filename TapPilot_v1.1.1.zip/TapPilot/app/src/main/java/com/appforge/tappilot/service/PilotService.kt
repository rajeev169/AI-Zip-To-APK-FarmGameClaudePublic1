package com.appforge.tappilot.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.appforge.tappilot.data.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

/**
 * The heart of TapPilot: reads the screen, taps, swipes, types and takes screenshots.
 * Every automation (AI agent, game mode, replay) runs as one "job" here, with a floating Stop button.
 */
class PilotService : AccessibilityService() {

    sealed class RunState {
        object Idle : RunState()
        data class Running(val label: String) : RunState()
        data class Finished(val message: String) : RunState()
        data class Blocked(val reason: String) : RunState()
    }

    companion object {
        @Volatile
        var instance: PilotService? = null
            private set

        private val _connected = MutableStateFlow(false)
        val connected: StateFlow<Boolean> = _connected

        private val _state = MutableStateFlow<RunState>(RunState.Idle)
        val state: StateFlow<RunState> = _state

        private val _log = MutableStateFlow<List<String>>(emptyList())
        val log: StateFlow<List<String>> = _log

        private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

        fun log(msg: String) {
            val line = "${timeFmt.format(Date())}  $msg"
            _log.value = (_log.value + line).takeLast(80)
        }

        fun clearLog() {
            _log.value = emptyList()
        }
    }

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var jobGen = 0
    lateinit var panel: FloatingPanel
        private set

    /** Package of the app currently in front. */
    @Volatile
    var currentPackage: String? = null
        private set

    /** When true, every screen change is checked by SafetyGuard. */
    @Volatile
    var guardActive = false
    private var lastGuardCheck = 0L

    val isBusy: Boolean get() = job?.isActive == true

    override fun onServiceConnected() {
        super.onServiceConnected()
        Prefs.init(this)
        panel = FloatingPanel(this)
        instance = this
        _connected.value = true
        log("TapPilot assistant is on")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString()
            if (pkg != null && pkg != packageName && pkg != "com.android.systemui") {
                currentPackage = pkg
            }
        }
        if (guardActive && isBusy) {
            val now = System.currentTimeMillis()
            if (now - lastGuardCheck > 700) {
                lastGuardCheck = now
                val reason = SafetyGuard.check(rootInActiveWindow, rootInActiveWindow?.packageName?.toString())
                if (reason != null) stopAll(reason, blocked = true)
            }
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        stopAll("Assistant turned off")
        instance = null
        _connected.value = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        _connected.value = false
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ jobs

    /**
     * Runs one automation. Any running job is stopped first.
     * Shows the floating panel with a Stop button while it runs.
     */
    fun startJob(
        label: String,
        extraButtons: List<FloatingPanel.Btn> = emptyList(),
        guard: Boolean = true,
        block: suspend () -> String
    ) {
        job?.cancel()
        clearLog()
        val gen = ++jobGen
        guardActive = guard
        _state.value = RunState.Running(label)
        log("Started: $label")
        panel.show(label, extraButtons + FloatingPanel.Btn("■ Stop", FloatingPanel.RED) { stopAll("Stopped by you") })
        job = scope.launch {
            try {
                val result = block()
                ensureActive() // a safety stop inside the job wins over its result
                _state.value = RunState.Finished(result)
                log("Done: $result")
                panel.update("✔ $result")
                panel.setButtons(listOf(FloatingPanel.Btn("OK", FloatingPanel.GREEN) { panel.hide() }))
                scope.launch {
                    delay(6000)
                    if (jobGen == gen && !isBusy) panel.hide()
                }
            } catch (e: CancellationException) {
                // stopAll already updated the state
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                _state.value = RunState.Finished("Error: $msg")
                log("Error: $msg")
                panel.update("⚠ $msg")
                panel.setButtons(listOf(FloatingPanel.Btn("OK", FloatingPanel.GREY) { panel.hide() }))
            } finally {
                if (jobGen == gen) guardActive = false
            }
        }
    }

    fun stopAll(reason: String, blocked: Boolean = false) {
        val wasRunning = job?.isActive == true
        job?.cancel()
        job = null
        guardActive = false
        if (wasRunning || blocked) {
            _state.value = if (blocked) RunState.Blocked(reason) else RunState.Finished(reason)
            log(if (blocked) "Blocked: $reason" else reason)
        }
        if (::panel.isInitialized) {
            if (blocked) {
                panel.show("⛔ $reason", listOf(FloatingPanel.Btn("OK", FloatingPanel.GREY) { panel.hide() }))
            } else {
                panel.hide()
            }
        }
    }

    fun status(text: String) {
        if (::panel.isInitialized) panel.update(text)
        log(text)
    }

    // --------------------------------------------------------------- gestures

    private suspend fun gesture(path: Path, durationMs: Long, x: Float, y: Float, x2: Float = x, y2: Float = y): Boolean {
        val overPanel = ::panel.isInitialized && (panel.boundsContains(x, y) || panel.boundsContains(x2, y2))
        if (overPanel) panel.passThrough(true)
        val dur = durationMs.coerceIn(1L, 59_000L)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, dur))
            .build()
        val ok = suspendCancellableCoroutine<Boolean> { cont ->
            val sent = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }, null)
            if (!sent && cont.isActive) cont.resume(false)
        }
        if (overPanel) panel.passThrough(false)
        return ok
    }

    suspend fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x.coerceAtLeast(0f), y.coerceAtLeast(0f)) }
        return gesture(p, 60L, x, y)
    }

    suspend fun longPress(x: Float, y: Float, ms: Long = 700L): Boolean {
        val p = Path().apply { moveTo(x.coerceAtLeast(0f), y.coerceAtLeast(0f)) }
        return gesture(p, ms, x, y)
    }

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 300L): Boolean {
        val p = Path().apply {
            moveTo(x1.coerceAtLeast(0f), y1.coerceAtLeast(0f))
            lineTo(x2.coerceAtLeast(0f), y2.coerceAtLeast(0f))
        }
        return gesture(p, ms, x1, y1, x2, y2)
    }

    fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    /** Swipe the screen content: direction "up" scrolls down the page, like a finger moving up. */
    suspend fun scroll(direction: String): Boolean {
        val (w, h) = screenSize()
        val cx = w / 2f
        val cy = h / 2f
        return when (direction.lowercase()) {
            "up" -> swipe(cx, h * 0.72f, cx, h * 0.30f, 350)
            "down" -> swipe(cx, h * 0.30f, cx, h * 0.72f, 350)
            "left" -> swipe(w * 0.85f, cy, w * 0.15f, cy, 300)
            "right" -> swipe(w * 0.15f, cy, w * 0.85f, cy, 300)
            else -> false
        }
    }

    // ------------------------------------------------------------ node actions

    suspend fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 5) {
            if (n.isClickable && n.isEnabled) {
                if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                break
            }
            n = n.parent
            depth++
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.isEmpty) return false
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    fun typeInto(node: AccessibilityNodeInfo, text: String): Boolean {
        if (node.isPassword) return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Types into whichever text box currently has focus. */
    fun typeIntoFocused(text: String): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return typeInto(f, text)
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun foregroundPackage(): String? =
        rootInActiveWindow?.packageName?.toString() ?: currentPackage

    // -------------------------------------------------------------- open apps

    data class AppEntry(val label: String, val pkg: String)

    fun launchableApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        return list.map {
            AppEntry(it.loadLabel(packageManager).toString(), it.activityInfo.packageName)
        }.distinctBy { it.pkg }
    }

    /** Opens an app by its name ("WhatsApp", "youtube") or package name. Returns the package opened. */
    fun openApp(nameOrPkg: String): String? {
        val q = nameOrPkg.trim().lowercase()
        if (q.isEmpty()) return null
        val apps = launchableApps()
        val match = apps.firstOrNull { it.pkg.lowercase() == q }
            ?: apps.firstOrNull { it.label.lowercase() == q }
            ?: apps.firstOrNull { it.label.lowercase().startsWith(q) }
            ?: apps.firstOrNull { it.label.lowercase().contains(q) }
            ?: apps.firstOrNull { q.contains(it.label.lowercase()) && it.label.length >= 3 }
            ?: return null
        if (SafetyGuard.isBlockedPackage(match.pkg)) return null
        return if (launchPackage(match.pkg)) match.pkg else null
    }

    fun launchPackage(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openTapPilot() {
        launchPackage(packageName)
    }

    // ------------------------------------------------------------- screenshots

    /** Takes a screenshot as a normal (readable) bitmap. Needs Android 11+. */
    suspend fun screenshot(): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        repeat(3) { attempt ->
            val bmp = screenshotOnce()
            if (bmp != null) return bmp
            delay(350L + attempt * 150L)
        }
        return null
    }

    private suspend fun screenshotOnce(): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return suspendCancellableCoroutine { cont ->
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val hb = screenshot.hardwareBuffer
                        val bmp = try {
                            Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, false)
                        } catch (e: Exception) {
                            null
                        } finally {
                            hb.close()
                        }
                        if (cont.isActive) cont.resume(bmp)
                    }

                    override fun onFailure(errorCode: Int) {
                        if (cont.isActive) cont.resume(null)
                    }
                })
            } catch (e: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }
    }
}
