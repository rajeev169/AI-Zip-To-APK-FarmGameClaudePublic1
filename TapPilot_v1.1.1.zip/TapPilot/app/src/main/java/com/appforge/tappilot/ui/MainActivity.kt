package com.appforge.tappilot.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.voice.VoiceInput

class MainActivity : ComponentActivity() {

    private lateinit var voice: VoiceInput

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        voice = VoiceInput(this)
        enableEdgeToEdge()
        setContent {
            TapPilotTheme {
                AppRoot(voice = voice, sendToBackground = { moveTaskToBack(true) })
            }
        }
    }

    override fun onDestroy() {
        voice.stop()
        super.onDestroy()
    }
}
