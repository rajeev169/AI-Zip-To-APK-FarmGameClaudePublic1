@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.appforge.tappilot.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.appforge.tappilot.data.Macro
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.Controls
import com.appforge.tappilot.service.PilotService
import com.appforge.tappilot.voice.VoiceInput

private data class TabItem(val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("Agent", Icons.Filled.SmartToy),
    TabItem("Game", Icons.Filled.SportsEsports),
    TabItem("Record", Icons.Filled.FiberManualRecord),
    TabItem("Settings", Icons.Filled.Settings)
)

@Composable
fun AppRoot(voice: VoiceInput, sendToBackground: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val connected by PilotService.connected.collectAsState()
    var keySet by remember { mutableStateOf(Prefs.apiKey.isNotBlank()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("TapPilot", fontWeight = FontWeight.Bold)
                        Text(
                            "Your phone, on autopilot",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = { StatusPill(connected) }
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> AgentScreen(voice, connected, keySet, goSettings = { tab = 3 })
                1 -> GameScreen(connected, sendToBackground)
                2 -> RecordScreen(connected, sendToBackground)
                else -> SettingsScreen(onKeyChanged = { keySet = it })
            }
        }
    }
}

@Composable
private fun StatusPill(on: Boolean) {
    Surface(
        shape = RoundedCornerShape(50),
        color = if (on) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.errorContainer,
        modifier = Modifier.padding(end = 12.dp)
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(8.dp).padding(0.dp)
            ) {
                Surface(shape = CircleShape, color = if (on) Color(0xFF2E9D5B) else Color(0xFFD93025), modifier = Modifier.fillMaxSize()) {}
            }
            Spacer(Modifier.width(6.dp))
            Text(if (on) "Ready" else "Off", style = MaterialTheme.typography.labelMedium)
        }
    }
}

// ---------------------------------------------------------------- setup

private fun openAccessibilitySettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

private fun openAppInfo(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {}
}

private fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

@Composable
private fun TurnOnCard() {
    val ctx = LocalContext.current
    var showDisclosure by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Step 1 · Turn on the assistant", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                "TapPilot needs the Accessibility permission to see the screen and tap for you. " +
                    "In the list, open \"TapPilot Assistant\" and switch it on.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))
            Button(onClick = {
                if (Prefs.disclosureAccepted) openAccessibilitySettings(ctx) else showDisclosure = true
            }) { Text("Turn on") }
            Spacer(Modifier.height(8.dp))
            Text(
                "Switch greyed out (\"Restricted setting\")? Open App info → ⋮ (top right) → " +
                    "\"Allow restricted settings\", then try again.",
                style = MaterialTheme.typography.bodySmall
            )
            TextButton(onClick = { openAppInfo(ctx) }) { Text("Open App info") }
        }
    }

    if (showDisclosure) {
        AlertDialog(
            onDismissRequest = { showDisclosure = false },
            icon = { Icon(Icons.Filled.Shield, null) },
            title = { Text("How TapPilot uses Accessibility") },
            text = {
                Text(
                    "• TapPilot reads what's on your screen and taps, swipes and types for you — only when you " +
                        "give a command, start game mode or play a recording.\n\n" +
                        "• For AI commands, the screen's text and a screenshot are sent to Google Gemini using " +
                        "YOUR API key, one step at a time. TapPilot keeps nothing and has no server.\n\n" +
                        "• It stops on banking, UPI, OTP, PIN and password screens and never pays or buys.\n\n" +
                        "• A floating Stop button is shown whenever it is acting."
                )
            },
            confirmButton = {
                Button(onClick = {
                    Prefs.disclosureAccepted = true
                    showDisclosure = false
                    openAccessibilitySettings(ctx)
                }) { Text("Agree & continue") }
            },
            dismissButton = { TextButton(onClick = { showDisclosure = false }) { Text("Not now") } }
        )
    }
}

@Composable
private fun KeyCard(goSettings: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Step 2 · Add your free Gemini key", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                "AI commands use Google Gemini. Get a free key from Google AI Studio and paste it in Settings. " +
                    "Recordings and hand-set candy grids work without it.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))
            FilledTonalButton(onClick = goSettings) { Text("Go to Settings") }
        }
    }
}

// ---------------------------------------------------------------- agent

private val examples = listOf(
    "WhatsApp kholo aur Rahul ko 'Main 10 minute me aa raha hoon' bhejo",
    "Open YouTube and search for Bihar news",
    "Kal subah 6 baje ka alarm lagao",
    "Turn on Bluetooth",
    "Play Store me Tractor Khata dhundo"
)

@Composable
private fun AgentScreen(voice: VoiceInput, connected: Boolean, keySet: Boolean, goSettings: () -> Unit) {
    val ctx = LocalContext.current
    var cmd by rememberSaveable { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var lang by remember { mutableStateOf(Prefs.voiceLang) }
    val state by PilotService.state.collectAsState()
    val log by PilotService.log.collectAsState()

    val run: (String) -> Unit = { text ->
        msg = Controls.runCommand(text)
    }
    val startVoice: () -> Unit = {
        msg = null
        voice.start(
            lang = lang,
            onPartial = { cmd = it },
            onResult = { text ->
                cmd = text
                if (Prefs.runAfterVoice) run(text)
            },
            onFail = { msg = it },
            onListening = { listening = it }
        )
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) msg = "Microphone permission is needed for voice commands."
        if (granted) startVoice()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!connected) TurnOnCard()
        if (!keySet) KeyCard(goSettings)

        Text("What should I do?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = cmd,
            onValueChange = { cmd = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("e.g. WhatsApp kholo aur Papa ko 'Hi' bhejo") },
            minLines = 2,
            maxLines = 5,
            shape = RoundedCornerShape(16.dp)
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledIconButton(
                onClick = {
                    val hasMic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                        PackageManager.PERMISSION_GRANTED
                    when {
                        listening -> {
                            listening = false
                            voice.stop()
                        }
                        hasMic -> startVoice()
                        else -> micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                modifier = Modifier.size(56.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = if (listening) Color(0xFFE53935) else MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(if (listening) Icons.Filled.Stop else Icons.Filled.Mic, contentDescription = "Speak")
            }
            Spacer(Modifier.width(10.dp))
            FilterChip(
                selected = lang == "hi-IN",
                onClick = { lang = "hi-IN"; Prefs.voiceLang = "hi-IN" },
                label = { Text("हिंदी") }
            )
            Spacer(Modifier.width(6.dp))
            FilterChip(
                selected = lang == "en-IN",
                onClick = { lang = "en-IN"; Prefs.voiceLang = "en-IN" },
                label = { Text("English") }
            )
            Spacer(Modifier.weight(1f))
            Button(
                onClick = { run(cmd) },
                enabled = cmd.isNotBlank(),
                modifier = Modifier.height(48.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, null)
                Spacer(Modifier.width(6.dp))
                Text("Run")
            }
        }
        if (listening) Text("Listening… speak now", color = MaterialTheme.colorScheme.primary)
        msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        Text("Try saying", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            examples.forEach { ex ->
                SuggestionChip(onClick = { cmd = ex }, label = { Text(ex, maxLines = 1) })
            }
        }

        StateCard(state)

        if (log.isNotEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Activity", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { PilotService.clearLog() }) { Text("Clear") }
                    }
                    log.takeLast(14).forEach { line ->
                        Text(line, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun StateCard(state: PilotService.RunState) {
    when (state) {
        is PilotService.RunState.Running -> Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Working…", fontWeight = FontWeight.Bold)
                    Text(state.label, style = MaterialTheme.typography.bodySmall)
                }
                Button(
                    onClick = { Controls.stop() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
                ) { Text("Stop") }
            }
        }
        is PilotService.RunState.Finished -> Card(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF2E9D5B))
                Spacer(Modifier.width(10.dp))
                Text(state.message)
            }
        }
        is PilotService.RunState.Blocked -> Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Shield, null)
                Spacer(Modifier.width(10.dp))
                Text(state.reason)
            }
        }
        PilotService.RunState.Idle -> {}
    }
}

// ---------------------------------------------------------------- game

@Composable
private fun GameScreen(connected: Boolean, sendToBackground: () -> Unit) {
    var msg by remember { mutableStateOf<String?>(null) }
    var human by remember { mutableStateOf(Prefs.humanMode) }
    var boards by remember { mutableStateOf(Prefs.boardPackages().toList().sorted()) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!connected) TurnOnCard()

        Text("Game auto-play", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "Open a game and tap Play: Gemini works out the game, its goal and where the board is " +
                "(first time only). Then the phone plays by itself, closes ads and continues to the next level.\n\n" +
                "• Candy / match-3: on-phone solver, aims at goals like ice and jelly\n" +
                "• Chess vs computer: built-in chess engine\n" +
                "• Other turn-based games: General AI mode (Gemini decides each move, slower)",
            style = MaterialTheme.typography.bodyMedium
        )

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            WarnCard("Game mode needs Android 11 or newer. Your phone runs an older version, so only the agent and recordings will work.")
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("How to start", fontWeight = FontWeight.Bold)
                Text("1. Tap \"Start game mode\" — a small TapPilot panel appears.")
                Text("2. Open your game and start a level (or a new game vs computer).")
                Text("3. Tap ▶ Play. The first time, Gemini detects the game — needs your free key.")
                Text("4. Tap ■ Stop any time. ↻ detects the game again; ⊞ sets a candy grid by hand.")
            }
        }

        Button(
            onClick = {
                val err = Controls.showGamePanel()
                msg = err
                if (err == null) sendToBackground()
            },
            enabled = connected,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Icon(Icons.Filled.SportsEsports, null)
            Spacer(Modifier.width(8.dp))
            Text("Start game mode")
        }
        msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        Card(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Human-like mode", fontWeight = FontWeight.Bold)
                    Text(
                        "Normal speed with small random pauses, slightly varied swipes and a short break every 20–30 minutes. Recommended for online games.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(checked = human, onCheckedChange = { human = it; Prefs.humanMode = it })
            }
        }

        WarnCard(
            "Candy Crush Saga (King) syncs progress online and its rules don't allow bots. " +
                "There's a small chance of a progress reset or account ban — the risk is yours. " +
                "Offline games have almost no risk. Hard levels may need several retries. " +
                "TapPilot never plays live matches against real people."
        )

        if (boards.isNotEmpty()) {
            Text("Learned games", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            boards.forEach { pkg ->
                val cfg = Prefs.board(pkg)
                val prof = Prefs.profile(pkg)
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 16.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(Controls.appLabel(pkg), fontWeight = FontWeight.SemiBold)
                            val kind = when (prof?.type ?: "match3") {
                                "chess" -> "Chess"
                                "general" -> "General AI"
                                else -> "Match-3" + if (cfg != null) " · ${cfg.rows} × ${cfg.cols}" else ""
                            }
                            Text(kind, style = MaterialTheme.typography.bodySmall)
                            if (!prof?.goal.isNullOrBlank()) {
                                Text("Goal: ${prof?.goal}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            }
                        }
                        IconButton(onClick = {
                            Prefs.forgetGame(pkg)
                            boards = Prefs.boardPackages().toList().sorted()
                        }) { Icon(Icons.Filled.Delete, contentDescription = "Forget game") }
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun WarnCard(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp)) {
            Icon(Icons.Filled.Warning, null, tint = MaterialTheme.colorScheme.onTertiaryContainer)
            Spacer(Modifier.width(10.dp))
            Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onTertiaryContainer)
        }
    }
}

// ---------------------------------------------------------------- record

@Composable
private fun RecordScreen(connected: Boolean, sendToBackground: () -> Unit) {
    val macros by Prefs.macros.collectAsState()
    var msg by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<Macro?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!connected) TurnOnCard()

        Text("Record & replay", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "Record a set of taps and swipes once, then replay them any number of times. " +
                "Good for simple repeated jobs. No internet needed.",
            style = MaterialTheme.typography.bodyMedium
        )

        Button(
            onClick = {
                val err = Controls.startRecording()
                msg = err
                if (err == null) sendToBackground()
            },
            enabled = connected,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
        ) {
            Icon(Icons.Filled.FiberManualRecord, null)
            Spacer(Modifier.width(8.dp))
            Text("New recording")
        }
        Text(
            "After 3 seconds, use your phone normally. Tap Save on the floating panel when done.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        if (macros.isEmpty()) {
            Text("No recordings yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        macros.forEach { m ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(m.name, fontWeight = FontWeight.Bold)
                            val app = m.packageName?.let { Controls.appLabel(it) } ?: "any screen"
                            Text("${m.steps.size} steps · $app", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { renaming = m }) { Icon(Icons.Filled.Edit, contentDescription = "Rename") }
                        IconButton(onClick = { Prefs.deleteMacro(m.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1 to "Play 1×", 5 to "5×", 0 to "Loop").forEach { (times, label) ->
                            OutlinedButton(onClick = {
                                val err = Controls.replay(m, times)
                                msg = err
                                if (err == null) sendToBackground()
                            }, enabled = connected) {
                                Icon(if (times == 0) Icons.Filled.Repeat else Icons.Filled.PlayArrow, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(label)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }

    renaming?.let { m ->
        var name by remember(m.id) { mutableStateOf(m.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename recording") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) Prefs.renameMacro(m.id, name.trim())
                    renaming = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- settings

@Composable
private fun SettingsScreen(onKeyChanged: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Prefs.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(Prefs.model) }
    var rpm by remember { mutableFloatStateOf(Prefs.requestsPerMinute.toFloat()) }
    var steps by remember { mutableFloatStateOf(Prefs.stepLimit.toFloat()) }
    var shots by remember { mutableStateOf(Prefs.useScreenshots) }
    var chessSec by remember { mutableFloatStateOf(Prefs.chessThinkMs / 1000f) }
    var autoRun by remember { mutableStateOf(Prefs.runAfterVoice) }
    var saved by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Gemini AI", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it; saved = false },
                    label = { Text("Gemini API key") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = "Show key")
                        }
                    }
                )
                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it; saved = false },
                    label = { Text("Model") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    supportingText = { Text("Default: gemini-2.5-flash. Use gemini-2.5-flash-lite for higher free limits.") }
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {
                        Prefs.apiKey = key
                        Prefs.model = model.ifBlank { "gemini-2.5-flash" }
                        onKeyChanged(key.isNotBlank())
                        saved = true
                    }) { Text("Save") }
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { openUrl(ctx, "https://aistudio.google.com/apikey") }) { Text("Get a free key") }
                    if (saved) Text("Saved ✔", color = Color(0xFF2E9D5B))
                }
                Text(
                    "Your key stays on this phone and is sent only to Google.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Text("Agent", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Gemini requests per minute: ${rpm.toInt()}", fontWeight = FontWeight.SemiBold)
                Text("Free keys allow about 10 per minute. Lower = slower but no limit errors.", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = rpm,
                    onValueChange = { rpm = it },
                    onValueChangeFinished = { Prefs.requestsPerMinute = rpm.toInt() },
                    valueRange = 2f..30f,
                    steps = 27
                )
                Text("Step limit per command: ${steps.toInt()}", fontWeight = FontWeight.SemiBold)
                Text("The agent stops after this many steps.", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = steps,
                    onValueChange = { steps = it },
                    onValueChangeFinished = { Prefs.stepLimit = steps.toInt() },
                    valueRange = 5f..60f,
                    steps = 54
                )
                Text("Chess thinking time: ${"%.1f".format(chessSec)} s", fontWeight = FontWeight.SemiBold)
                Text("Longer = stronger moves.", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = chessSec,
                    onValueChange = { chessSec = it },
                    onValueChangeFinished = { Prefs.chessThinkMs = (chessSec * 1000).toInt() },
                    valueRange = 0.5f..6f
                )
                SettingSwitch("Send screenshots to Gemini", "More accurate, slightly slower. Needs Android 11+.", shots) {
                    shots = it; Prefs.useScreenshots = it
                }
                SettingSwitch("Run right after voice command", "Otherwise you tap Run yourself.", autoRun) {
                    autoRun = it; Prefs.runAfterVoice = it
                }
            }
        }

        Text("Safety", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("• Floating ■ Stop button whenever TapPilot is acting.")
                Text("• Stops on banking, UPI and wallet apps, and on OTP, PIN and password screens.")
                Text("• Never taps Pay, Buy, Subscribe or price buttons.")
                Text("• Step limit for every AI command.")
            }
        }
        Text(
            "TapPilot 1.1 · AppForge",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun SettingSwitch(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
