package com.appforge.tappilot.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(
    primary = Color(0xFF3D2BB5),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3DEFF),
    onPrimaryContainer = Color(0xFF16084F),
    secondary = Color(0xFF2E9D5B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD3F2DF),
    onSecondaryContainer = Color(0xFF07361A),
    tertiary = Color(0xFFE07B1F),
    tertiaryContainer = Color(0xFFFFE3C7),
    onTertiaryContainer = Color(0xFF4A2300),
    background = Color(0xFFF7F5FF),
    surface = Color(0xFFF7F5FF),
    surfaceVariant = Color(0xFFE8E4F5),
    errorContainer = Color(0xFFFFDAD6)
)

private val Dark = darkColorScheme(
    primary = Color(0xFFC4BAFF),
    onPrimary = Color(0xFF241A7A),
    primaryContainer = Color(0xFF3D2BB5),
    onPrimaryContainer = Color(0xFFE3DEFF),
    secondary = Color(0xFF8FD8AA),
    secondaryContainer = Color(0xFF1C5A35),
    onSecondaryContainer = Color(0xFFD3F2DF),
    tertiary = Color(0xFFFFB877),
    tertiaryContainer = Color(0xFF6B3A00),
    onTertiaryContainer = Color(0xFFFFE3C7),
    background = Color(0xFF13111C),
    surface = Color(0xFF13111C),
    surfaceVariant = Color(0xFF2A2638)
)

@Composable
fun TapPilotTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
