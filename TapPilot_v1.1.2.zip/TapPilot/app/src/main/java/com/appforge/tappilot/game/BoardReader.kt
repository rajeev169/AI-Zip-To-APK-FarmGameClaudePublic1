package com.appforge.tappilot.game

import android.graphics.Bitmap
import com.appforge.tappilot.data.BoardConfig

/** A screenshot copied into a plain pixel array (much faster than Bitmap.getPixel in loops). */
class Frame(val width: Int, val height: Int, val pixels: IntArray) {
    fun px(x: Int, y: Int): Int = pixels[y * width + x]

    companion object {
        fun of(bmp: Bitmap): Frame {
            val arr = IntArray(bmp.width * bmp.height)
            bmp.getPixels(arr, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            return Frame(bmp.width, bmp.height, arr)
        }
    }
}

/**
 * Reads candy colours from a screenshot.
 * Each cell's centre area is sampled; strongly coloured pixels vote for a colour.
 * Cells with no clear colour (empty, blockers, chocolate, colour bombs) become -1.
 */
object BoardReader {

    const val UNKNOWN = -1
    val COLOR_NAMES = arrayOf("red", "orange", "yellow", "green", "blue", "purple")

    data class Reading(val board: Array<IntArray>, val knownRatio: Float, val clarity: Float) {
        /**
         * A real candy board: enough readable cells, at least 3 colours, no colour taking over,
         * and (once settled) almost no ready-made 3-in-a-rows. Rejects yellow menus, ads, swirls.
         */
        fun looksLikeBoard(checkMatches: Boolean = true): Boolean {
            if (knownRatio < 0.45f) return false
            val counts = IntArray(6)
            var known = 0
            for (row in board) for (v in row) if (v >= 0) { counts[v]++; known++ }
            if (known == 0) return false
            if (counts.count { it * 12 >= known } < 3) return false
            if (counts.max() * 100 > known * 55) return false
            return !checkMatches || existingMatches() <= 3
        }

        fun existingMatches(): Int {
            var n = 0
            val rows = board.size
            val cols = if (rows > 0) board[0].size else 0
            for (r in 0 until rows) for (c in 0 until cols) {
                val v = board[r][c]
                if (v < 0) continue
                if (c + 2 < cols && board[r][c + 1] == v && board[r][c + 2] == v) n++
                if (r + 2 < rows && board[r + 1][c] == v && board[r + 2][c] == v) n++
            }
            return n
        }

        fun sameAs(other: Reading?): Boolean {
            if (other == null || other.board.size != board.size) return false
            for (r in board.indices) if (!board[r].contentEquals(other.board[r])) return false
            return true
        }
    }

    private fun bucket(h: Float): Int = when {
        h >= 345f || h < 14f -> 0   // red
        h < 38f -> 1                // orange
        h < 70f -> 2                // yellow
        h < 165f -> 3               // green
        h < 255f -> 4               // blue
        else -> 5                   // purple / pink
    }

    fun read(bmp: Bitmap, cfg: BoardConfig): Reading = read(Frame.of(bmp), cfg)

    fun read(f: Frame, cfg: BoardConfig, grid: Int = 7): Reading {
        val board = Array(cfg.rows) { IntArray(cfg.cols) { UNKNOWN } }
        var known = 0
        var claritySum = 0f
        val hsv = FloatArray(3)
        val votes = IntArray(6)

        for (r in 0 until cfg.rows) {
            for (c in 0 until cfg.cols) {
                votes.fill(0)
                var samples = 0
                // running stats to spot flat background (sky, empty tiles) that only looks like a candy colour
                var vSum = 0f; var vSq = 0f; var sSum = 0f; var sSq = 0f
                val cx = cfg.cellCenterX(c)
                val cy = cfg.cellCenterY(r)
                // middle 62% of the cell: enough to catch ring-shaped candies, not the tile edges
                val spanX = cfg.cellW * 0.62f
                val spanY = cfg.cellH * 0.62f
                for (i in 0 until grid) {
                    for (j in 0 until grid) {
                        val x = (cx - spanX / 2 + spanX * (i + 0.5f) / grid).toInt()
                        val y = (cy - spanY / 2 + spanY * (j + 0.5f) / grid).toInt()
                        if (x < 0 || y < 0 || x >= f.width || y >= f.height) continue
                        samples++
                        toHsv(f.px(x, y), hsv)
                        val s = hsv[1]
                        val v = hsv[2]
                        vSum += v; vSq += v * v; sSum += s; sSq += s * s
                        if (s < 0.45f || v < 0.42f) continue
                        val b = bucket(hsv[0])
                        // dark orange is usually chocolate / wooden blockers
                        if (b == 1 && v < 0.55f) continue
                        votes[b]++
                    }
                }
                if (samples == 0) continue
                val vStd = std(vSum, vSq, samples)
                val sStd = std(sSum, sSq, samples)
                if (vStd < 0.03f && sStd < 0.05f) continue // flat colour = background, not a candy
                var best = -1
                var bestVotes = 0
                var second = 0
                for (k in 0 until 6) {
                    if (votes[k] > bestVotes) {
                        second = bestVotes; bestVotes = votes[k]; best = k
                    } else if (votes[k] > second) second = votes[k]
                }
                // Need a clear winner covering a good part of the sample
                if (best >= 0 && bestVotes >= samples * 0.22f && bestVotes >= second * 2f) {
                    board[r][c] = best
                    known++
                    claritySum += (bestVotes - second).toFloat() / samples
                }
            }
        }
        val total = (cfg.rows * cfg.cols).coerceAtLeast(1)
        return Reading(board, known.toFloat() / total, claritySum / total)
    }

    /**
     * Fine-tunes a rough board box (e.g. from Gemini): tries small shifts, sizes and ±1 row/column,
     * and keeps the grid where candies read most clearly.
     */
    fun refine(f: Frame, rough: BoardConfig, tryRowsCols: Boolean = true): BoardConfig {
        var best = rough
        var bestScore = score(f, rough)
        // levels change board size, so try up to ±2 rows/columns
        val rcOptions = if (tryRowsCols) {
            (-2..2).flatMap { dr -> (-2..2).map { dc -> dr to dc } }.filter { (dr, dc) -> kotlin.math.abs(dr - dc) <= 1 }
        } else listOf(0 to 0)

        for ((dr, dc) in rcOptions) {
            val rows = (rough.rows + dr).coerceIn(4, 14)
            val cols = (rough.cols + dc).coerceIn(4, 14)
            val base = rough.copy(rows = rows, cols = cols)
            // coarse search
            for (scale in floatArrayOf(0.94f, 0.97f, 1f, 1.03f, 1.06f)) {
                for (sx in -3..3) for (sy in -3..3) {
                    val cand = transform(base, scale, sx * base.cellW * 0.12f, sy * base.cellH * 0.12f)
                    val s = score(f, cand)
                    if (s > bestScore) { bestScore = s; best = cand }
                }
            }
        }
        // fine search around the best
        val coarse = best
        for (scale in floatArrayOf(0.985f, 1f, 1.015f)) {
            for (sx in -2..2) for (sy in -2..2) {
                val cand = transform(coarse, scale, sx * coarse.cellW * 0.04f, sy * coarse.cellH * 0.04f)
                val s = score(f, cand)
                if (s > bestScore) { bestScore = s; best = cand }
            }
        }
        return best
    }

    /** Clear readings in well-aligned cells score high; a slight bonus for more known cells. */
    private fun score(f: Frame, cfg: BoardConfig): Float {
        val r = read(f, cfg, grid = 5)
        val base = r.clarity + r.knownRatio * 0.15f
        return if (r.looksLikeBoard()) base else base - 1f
    }

    private fun transform(b: BoardConfig, scale: Float, dx: Float, dy: Float): BoardConfig {
        val cx = (b.left + b.right) / 2f + dx
        val cy = (b.top + b.bottom) / 2f + dy
        val hw = (b.right - b.left) / 2f * scale
        val hh = (b.bottom - b.top) / 2f * scale
        return b.copy(
            left = (cx - hw).toInt(), right = (cx + hw).toInt(),
            top = (cy - hh).toInt(), bottom = (cy + hh).toInt()
        )
    }

    private fun std(sum: Float, sq: Float, n: Int): Float {
        val m = sum / n
        val v = sq / n - m * m
        return if (v > 0f) kotlin.math.sqrt(v) else 0f
    }

    /** Fast RGB → HSV (h 0..360, s 0..1, v 0..1) without the JNI call of Color.colorToHSV. */
    fun toHsv(c: Int, out: FloatArray) {
        val r = ((c shr 16) and 0xFF) / 255f
        val g = ((c shr 8) and 0xFF) / 255f
        val b = (c and 0xFF) / 255f
        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val d = max - min
        var h = when {
            d == 0f -> 0f
            max == r -> 60f * (((g - b) / d) % 6f)
            max == g -> 60f * (((b - r) / d) + 2f)
            else -> 60f * (((r - g) / d) + 4f)
        }
        if (h < 0f) h += 360f
        out[0] = h
        out[1] = if (max == 0f) 0f else d / max
        out[2] = max
    }

    fun describe(board: Array<IntArray>): String = board.joinToString("\n") { row ->
        row.joinToString(" ") { if (it < 0) "." else COLOR_NAMES[it].first().uppercase() }
    }
}
