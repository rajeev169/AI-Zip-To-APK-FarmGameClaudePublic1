package com.appforge.tappilot.game

import com.appforge.tappilot.data.BoardConfig
import com.appforge.tappilot.data.GameProfile
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.PilotService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.random.Random

/**
 * Plays a match-3 game: screenshot → read colours → best swap → swipe → repeat.
 * - Goal cells (ice, jelly) are refreshed with Gemini every few moves and get priority.
 * - If a swipe changes nothing, that move is skipped; repeated failures re-detect the board.
 * - When the board isn't visible (ads, popups, level end) the PopupHandler takes over.
 */
class Match3Runner(
    private val svc: PilotService,
    private val gamePkg: String,
    private val profile: GameProfile,
    @Volatile private var cfg: BoardConfig
) {
    private val popups = PopupHandler(svc)
    private val guard = GameGuard(svc, gamePkg)
    private val detector = GameDetector(svc)

    suspend fun run(): String {
        var moves = 0
        var prev: BoardReader.Reading? = null
        var stableTries = 0
        var noMove = 0
        var popupStreak = 0
        var targets: Array<BooleanArray>? = null
        var movesSinceTargets = 999
        var lastMoveBoard: BoardReader.Reading? = null
        var lastMoveKey: String? = null
        val badMoves = HashSet<String>()
        var failedMoves = 0
        var goal = profile.goal
        var useGoal = profile.goalOnCells && Prefs.apiKey.isNotBlank()
        var goalAsked = goal.isNotBlank()
        var goalJob: Job? = null
        var needRefit = true          // re-fit the grid at start and whenever a new level appears
        var lastRedetect = 0L

        svc.status("Playing ${profile.name.ifBlank { "match-3" }}…")

        while (true) {
            if (!guard.ensureInGame()) continue

            val bmp = svc.screenshot()
            if (bmp == null) { delay(800); continue }
            var reading = withContext(Dispatchers.Default) { BoardReader.read(bmp, cfg) }

            // New level / different board size: re-fit the grid on the phone (no Gemini, under a second)
            if (needRefit || (!reading.looksLikeBoard() && popupStreak == 1)) {
                val fitted = refit(bmp)
                if (fitted != null) {
                    reading = fitted
                    needRefit = false
                } else if (needRefit) {
                    needRefit = popupStreak < 3
                }
            }

            // Still unreadable for a while: ask Gemini once for the new board (max once a minute)
            if (!reading.looksLikeBoard() && popupStreak == 6 && Prefs.apiKey.isNotBlank() &&
                System.currentTimeMillis() - lastRedetect > 60_000
            ) {
                lastRedetect = System.currentTimeMillis()
                svc.status("Board changed — asking Gemini where it is…")
                try {
                    val d = detector.detect(gamePkg)
                    if (d.profile.type == "match3" && d.board != null) {
                        cfg = d.board
                        reading = withContext(Dispatchers.Default) { BoardReader.read(bmp, cfg) }
                    }
                } catch (e: Exception) {
                    // not on a board right now; the popup handler below deals with it
                }
            }

            if (!reading.looksLikeBoard(checkMatches = false)) {
                // Not on the board: ad, popup, level end…
                popupStreak++
                prev = null
                targets = null
                movesSinceTargets = 999
                needRefit = true
                when (popups.handle(bmp, popupStreak)) {
                    PopupHandler.Result.OUT_OF_LIVES -> return "Out of lives after $moves moves. Try again later."
                    PopupHandler.Result.TAPPED -> svc.status("Closed a popup / continued (moves: $moves)")
                    PopupHandler.Result.BACK -> svc.status("Pressed back (moves: $moves)")
                    PopupHandler.Result.WAITED -> svc.status("Waiting for the board… (moves: $moves)")
                }
                if (popupStreak > 30) return "Stuck on a screen after $moves moves. Stopped."
                delay(1500)
                continue
            }
            popupStreak = 0

            // Candies still falling / matches still clearing
            if (reading.existingMatches() > 3) {
                prev = null
                delay(300)
                continue
            }

            // Wait until candies stop falling (two equal readings in a row)
            if (!reading.sameAs(prev) && stableTries < 5) {
                prev = reading
                stableTries++
                delay(250)
                continue
            }
            stableTries = 0
            prev = null

            // Self-check: did the last swipe do anything?
            if (lastMoveBoard != null && reading.sameAs(lastMoveBoard)) {
                lastMoveKey?.let { badMoves.add(it) }
                failedMoves++
                if (failedMoves >= 4) {
                    svc.status("Moves aren't working — re-aligning the grid…")
                    val rough = cfg
                    val tuned = withContext(Dispatchers.Default) {
                        BoardReader.findBoard(Frame.of(bmp)) ?: BoardReader.refine(Frame.of(bmp), rough)
                    }
                    cfg = tuned
                    Prefs.saveBoard(gamePkg, tuned)
                    failedMoves = 0
                    badMoves.clear()
                }
            } else if (lastMoveBoard != null) {
                failedMoves = 0
                badMoves.clear()
            }

            // Learn the level goal once, in the background (play never waits for Gemini)
            if (!goalAsked && Prefs.apiKey.isNotBlank() && goalJob?.isActive != true) {
                goalAsked = true
                val shot = bmp
                goalJob = CoroutineScope(currentCoroutineContext()).launch {
                    detector.readGoal(shot)?.let { (text, onCells) ->
                        goal = text
                        useGoal = onCells
                        Prefs.saveProfile(gamePkg, profile.copy(goal = text, goalOnCells = onCells))
                        movesSinceTargets = 999
                    }
                }
            }

            // Refresh goal cells (ice, jelly…) in the background
            if (useGoal && movesSinceTargets >= 12 && goalJob?.isActive != true) {
                movesSinceTargets = 0
                val shot = bmp
                val board = cfg
                val g = goal
                goalJob = CoroutineScope(currentCoroutineContext()).launch {
                    detector.goalCells(shot, board, g)?.let { if (board == cfg) targets = it }
                }
            }

            val move = Match3Solver.bestMove(reading.board, random = guard.human, targets = targets, skip = badMoves)
            if (move == null) {
                noMove++
                lastMoveBoard = null
                if (noMove == 2) {
                    // maybe the grid is off: re-fit before bothering Gemini
                    refit(bmp)
                    delay(400)
                } else if (noMove >= 4) {
                    // Board-like screen with no moves: maybe a level-end screen drawn over the board
                    noMove = 0
                    popups.handle(bmp, 3)
                    delay(1500)
                } else delay(700)
                continue
            }
            noMove = 0

            val x1 = cfg.cellCenterX(move.c1)
            val y1 = cfg.cellCenterY(move.r1)
            val x2 = cfg.cellCenterX(move.c2)
            val y2 = cfg.cellCenterY(move.r2)
            if (guard.human) {
                val jx = cfg.cellW * 0.12f
                val jy = cfg.cellH * 0.12f
                svc.swipe(
                    x1 + Random.nextFloat() * 2 * jx - jx, y1 + Random.nextFloat() * 2 * jy - jy,
                    x2 + Random.nextFloat() * 2 * jx - jx, y2 + Random.nextFloat() * 2 * jy - jy,
                    Random.nextLong(170, 330)
                )
            } else {
                svc.swipe(x1, y1, x2, y2, 160)
            }
            lastMoveBoard = reading
            lastMoveKey = move.key
            moves++
            movesSinceTargets++
            svc.status("Playing… moves: $moves" + if (targets != null) " · aiming at goal cells" else "")
            guard.afterMove(600, 1600, 3800)
        }
        return "Stopped"
    }

    /** Re-fits the grid to the current board. Returns the new reading if the board reads well. */
    private suspend fun refit(bmp: android.graphics.Bitmap): BoardReader.Reading? {
        val old = cfg
        val (tuned, r) = withContext(Dispatchers.Default) {
            val f = Frame.of(bmp)
            // quick nudge first; if the board really changed, search the whole screen
            var t = BoardReader.refine(f, old, tryRowsCols = true, light = true)
            var rr = BoardReader.read(f, t)
            if (rr.knownRatio < 0.7f || !rr.looksLikeBoard()) {
                BoardReader.findBoard(f)?.let { nb -> t = nb; rr = BoardReader.read(f, nb) }
            }
            t to rr
        }
        if (r.knownRatio < 0.6f || !r.looksLikeBoard()) return null
        svc.panel.moveAwayFrom(tuned.top, tuned.bottom)
        if (tuned != old) {
            cfg = tuned
            Prefs.saveBoard(gamePkg, tuned)
            if (tuned.rows != old.rows || tuned.cols != old.cols) {
                svc.status("New board: ${tuned.rows} × ${tuned.cols}")
            }
        }
        return r
    }
}
