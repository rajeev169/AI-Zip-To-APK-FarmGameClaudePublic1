package com.appforge.tappilot.game

import android.graphics.Bitmap
import com.appforge.tappilot.data.BoardConfig

/** A screenshot copied into a plain pixel array (much faster than Bitmap.getPixel in loops). */
class Frame(val width: Int, val height: Int, val pixels: IntArray) {
    fun px(x: Int, y: Int): Int = pixels[y * width + x]

    companion object {
        fun of(bmp: Bitmap): Frame {
            val arr = IntArray(bmp.width * bmp.height)
            bmp.getPixels(arr, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            return Frame(bmp.width, bmp.height, arr)
        }
    }
}

/**
 * Reads candy colours from a screenshot.
 * Each cell's centre area is sampled; strongly coloured pixels vote for a colour.
 * Cells with no clear colour (empty, blockers, chocolate, colour bombs) become -1.
 */
object BoardReader {

    const val UNKNOWN = -1
    val COLOR_NAMES = arrayOf("red", "orange", "yellow", "green", "blue", "purple")

    data class Reading(val board: Array<IntArray>, val knownRatio: Float, val clarity: Float, val strong: Int = 0) {
        /**
         * A real candy board: enough readable cells, at least 3 colours, no colour taking over,
         * and (once settled) almost no ready-made 3-in-a-rows. Rejects yellow menus, ads, swirls.
         */
        fun looksLikeBoard(checkMatches: Boolean = true): Boolean {
            val counts = IntArray(6)
            var known = 0
            for (row in board) for (v in row) if (v >= 0) { counts[v]++; known++ }
            // dense boards, or sparse/odd-shaped boards with enough solid candies
            if (!isSolid(known)) return false
            if (counts.count { it * 12 >= known } < 3) return false
            if (counts.max() * 100 > known * 55) return false
            return !checkMatches || existingMatches() <= 3
        }

        /** Enough clearly-drawn candies to be a board (works for boards full of gaps too). */
        fun isSolid(known: Int = knownCount()): Boolean =
            known >= 9 && strong * 10 >= known * 6 && (knownRatio >= 0.45f || strong >= 12)

        fun knownCount(): Int {
            var k = 0
            for (row in board) for (v in row) if (v >= 0) k++
            return k
        }

        fun existingMatches(): Int {
            var n = 0
            val rows = board.size
            val cols = if (rows > 0) board[0].size else 0
            for (r in 0 until rows) for (c in 0 until cols) {
                val v = board[r][c]
                if (v < 0) continue
                if (c + 2 < cols && board[r][c + 1] == v && board[r][c + 2] == v) n++
                if (r + 2 < rows && board[r + 1][c] == v && board[r + 2][c] == v) n++
            }
            return n
        }

        fun sameAs(other: Reading?): Boolean {
            if (other == null || other.board.size != board.size) return false
            for (r in board.indices) if (!board[r].contentEquals(other.board[r])) return false
            return true
        }
    }

    private fun bucket(h: Float): Int = when {
        h >= 345f || h < 14f -> 0   // red
        h < 38f -> 1                // orange
        h < 70f -> 2                // yellow
        h < 165f -> 3               // green
        h < 255f -> 4               // blue
        else -> 5                   // purple / pink
    }

    fun read(bmp: Bitmap, cfg: BoardConfig): Reading = read(Frame.of(bmp), cfg)

    fun read(f: Frame, cfg: BoardConfig, grid: Int = 7): Reading {
        val board = Array(cfg.rows) { IntArray(cfg.cols) { UNKNOWN } }
        var known = 0
        var strong = 0
        var claritySum = 0f
        val hsv = FloatArray(3)
        val votes = IntArray(6)

        for (r in 0 until cfg.rows) {
            for (c in 0 until cfg.cols) {
                votes.fill(0)
                var samples = 0
                // running stats to spot flat background (sky, empty tiles) that only looks like a candy colour
                var vSum = 0f; var vSq = 0f; var sSum = 0f; var sSq = 0f
                val cx = cfg.cellCenterX(c)
                val cy = cfg.cellCenterY(r)
                // middle 62% of the cell: enough to catch ring-shaped candies, not the tile edges
                val spanX = cfg.cellW * 0.62f
                val spanY = cfg.cellH * 0.62f
                for (i in 0 until grid) {
                    for (j in 0 until grid) {
                        val x = (cx - spanX / 2 + spanX * (i + 0.5f) / grid).toInt()
                        val y = (cy - spanY / 2 + spanY * (j + 0.5f) / grid).toInt()
                        if (x < 0 || y < 0 || x >= f.width || y >= f.height) continue
                        samples++
                        toHsv(f.px(x, y), hsv)
                        val s = hsv[1]
                        val v = hsv[2]
                        vSum += v; vSq += v * v; sSum += s; sSq += s * s
                        if (s < 0.45f || v < 0.42f) continue
                        val b = bucket(hsv[0])
                        // dark orange is usually chocolate / wooden blockers
                        if (b == 1 && v < 0.55f) continue
                        votes[b]++
                    }
                }
                if (samples == 0) continue
                val vStd = std(vSum, vSq, samples)
                val sStd = std(sSum, sSq, samples)
                if (vStd < 0.06f && sStd < 0.12f) continue // flat or blurry colour = background, not a candy
                var best = -1
                var bestVotes = 0
                var second = 0
                for (k in 0 until 6) {
                    if (votes[k] > bestVotes) {
                        second = bestVotes; bestVotes = votes[k]; best = k
                    } else if (votes[k] > second) second = votes[k]
                }
                // Need a clear winner covering a good part of the sample
                if (best >= 0 && bestVotes >= samples * 0.22f && bestVotes >= second * 2f) {
                    board[r][c] = best
                    known++
                    // a candy on a tile has strong colour/brightness changes; blurry backgrounds don't
                    if (sStd >= 0.17f || vStd >= 0.10f) strong++
                    claritySum += (bestVotes - second).toFloat() / samples
                }
            }
        }
        val total = (cfg.rows * cfg.cols).coerceAtLeast(1)
        return Reading(board, known.toFloat() / total, claritySum / total, strong)
    }

    /**
     * Finds a match-3 board on the screen with no help from Gemini, also for boards with gaps
     * and odd shapes:
     *  1. find candy-sized blobs of strong colour (the sky, frosting and blurry backgrounds are
     *     either too pale or far too big),
     *  2. the usual distance between neighbouring candies gives the cell size,
     *  3. the candies' positions give the grid offset; the board is the main cluster of candies on it.
     * Returns null when no board is visible (menu, ad, popup, home screen).
     */
    fun findBoard(f: Frame): BoardConfig? {
        val d = 4
        val sw = f.width / d
        val sh = f.height / d
        if (sw < 20 || sh < 20) return null
        val lab = IntArray(sw * sh) { -1 }
        val hsv = FloatArray(3)
        for (y in 0 until sh) for (x in 0 until sw) {
            toHsv(f.px(x * d, y * d), hsv)
            if (hsv[1] >= 0.55f && hsv[2] >= 0.45f) lab[y * sw + x] = bucket(hsv[0])
        }

        // 1) blobs
        class Blob(val x: Float, val y: Float, val w: Float, val h: Float)
        val blobs = ArrayList<Blob>()
        val seen = BooleanArray(sw * sh)
        val queue = IntArray(sw * sh)
        for (start in 0 until sw * sh) {
            val c = lab[start]
            if (c < 0 || seen[start]) continue
            var head = 0; var tail = 0
            queue[tail++] = start; seen[start] = true
            var minX = sw; var maxX = 0; var minY = sh; var maxY = 0; var area = 0
            while (head < tail) {
                val p = queue[head++]
                val px = p % sw; val py = p / sw
                area++
                if (px < minX) minX = px; if (px > maxX) maxX = px
                if (py < minY) minY = py; if (py > maxY) maxY = py
                if (px + 1 < sw) { val n = p + 1; if (!seen[n] && lab[n] == c) { seen[n] = true; queue[tail++] = n } }
                if (px > 0) { val n = p - 1; if (!seen[n] && lab[n] == c) { seen[n] = true; queue[tail++] = n } }
                if (py + 1 < sh) { val n = p + sw; if (!seen[n] && lab[n] == c) { seen[n] = true; queue[tail++] = n } }
                if (py > 0) { val n = p - sw; if (!seen[n] && lab[n] == c) { seen[n] = true; queue[tail++] = n } }
            }
            val bw = (maxX - minX + 1) * d.toFloat()
            val bh = (maxY - minY + 1) * d.toFloat()
            val ratio = bw / bh
            if (bw < f.width * 0.04f || bh < f.width * 0.04f || bw > f.width * 0.2f || bh > f.width * 0.2f) continue
            if (ratio < 0.6f || ratio > 1.6f) continue
            if (area * d * d < 0.3f * bw * bh) continue
            blobs.add(Blob((minX + maxX + 1) / 2f * d, (minY + maxY + 1) / 2f * d, bw, bh))
        }
        if (blobs.size < 9) return null
        val sizes = blobs.map { maxOf(it.w, it.h) }.sorted()
        val med = sizes[sizes.size / 2]
        val cand = blobs.filter { val m = maxOf(it.w, it.h); m >= 0.7f * med && m <= 1.35f * med }
        if (cand.size < 9) return null

        // 2) cell size = typical gap between neighbouring candies in a row or column
        val gaps = ArrayList<Float>()
        for (a in cand) {
            var best = Float.MAX_VALUE
            for (b in cand) {
                if (a === b) continue
                val dx = kotlin.math.abs(a.x - b.x)
                val dy = kotlin.math.abs(a.y - b.y)
                val g = when {
                    dy < 0.25f * med && dx > 0.8f * med -> dx
                    dx < 0.25f * med && dy > 0.8f * med -> dy
                    else -> continue
                }
                if (g < best) best = g
            }
            if (best < Float.MAX_VALUE) gaps.add(best)
        }
        if (gaps.size < 6) return null
        gaps.sort()
        val cell = gaps[gaps.size / 2]

        // 3) grid offset (circular mean of positions modulo the cell size)
        fun phase(vals: List<Float>): Float {
            var sx = 0.0; var sy = 0.0
            for (v in vals) { val a = v / cell * 2 * Math.PI; sx += kotlin.math.cos(a); sy += kotlin.math.sin(a) }
            return (kotlin.math.atan2(sy, sx) / (2 * Math.PI) * cell).toFloat()
        }
        val ox = phase(cand.map { it.x })
        val oy = phase(cand.map { it.y })
        fun frac(v: Float, o: Float): Float { val t = (v - o) / cell; return kotlin.math.abs(t - kotlin.math.round(t)) }
        val on = cand.filter { frac(it.x, ox) < 0.2f && frac(it.y, oy) < 0.2f }
        if (on.size < 9 || on.size < cand.size * 0.75f) return null
        var pts = on.map { Pair(kotlin.math.round((it.x - ox) / cell).toInt(), kotlin.math.round((it.y - oy) / cell).toInt()) }

        // keep the main cluster: split where 3+ empty rows/columns separate groups (e.g. booster buttons)
        fun biggest(list: List<Pair<Int, Int>>, byRow: Boolean): List<Pair<Int, Int>> {
            val vals = list.map { if (byRow) it.second else it.first }.distinct().sorted()
            val groups = ArrayList<IntRange>()
            var gs = vals[0]; var prev = vals[0]
            for (v in vals.drop(1)) {
                if (v - prev > 2) { groups.add(gs..prev); gs = v }
                prev = v
            }
            groups.add(gs..prev)
            val best = groups.maxBy { g -> list.count { (if (byRow) it.second else it.first) in g } }
            return list.filter { (if (byRow) it.second else it.first) in best }
        }
        pts = biggest(pts, true)
        pts = biggest(pts, false)
        // trim stray edge rows/columns holding a single blob (icons next to the board)
        var changed = true
        while (changed && pts.size >= 9) {
            changed = false
            for (byRow in listOf(true, false)) {
                val vals = pts.map { if (byRow) it.second else it.first }
                val lo = vals.min(); val hi = vals.max()
                if (hi - lo < 4) continue
                for (edge in listOf(lo, hi)) {
                    if (vals.count { it == edge } <= 1) {
                        pts = pts.filter { (if (byRow) it.second else it.first) != edge }
                        changed = true
                        break
                    }
                }
                if (changed) break
            }
        }
        if (pts.size < 9) return null
        val c0 = pts.minOf { it.first }; val c1 = pts.maxOf { it.first }
        val r0 = pts.minOf { it.second }; val r1 = pts.maxOf { it.second }
        val cols = c1 - c0 + 1
        val rows = r1 - r0 + 1
        if (cols < 3 || rows < 3 || cols > 14 || rows > 14) return null
        val left = ox + (c0 - 0.5f) * cell
        val top = oy + (r0 - 0.5f) * cell
        val cfg = BoardConfig(left.toInt(), top.toInt(), (left + cols * cell).toInt(), (top + rows * cell).toInt(), rows, cols)

        // final check with the normal cell reader
        val r = read(f, cfg)
        return if (r.looksLikeBoard(checkMatches = false)) cfg else null
    }

    /**
     * Fine-tunes a rough board box (e.g. from Gemini): tries small shifts, sizes and ±1 row/column,
     * and keeps the grid where candies read most clearly.
     */
    fun refine(f: Frame, rough: BoardConfig, tryRowsCols: Boolean = true, light: Boolean = false): BoardConfig {
        var best = rough
        var bestScore = score(f, rough)
        // levels change board size, so try up to ±2 rows/columns
        val rcOptions = if (tryRowsCols) {
            val span = if (light) 1 else 2
            (-span..span).flatMap { dr -> (-span..span).map { dc -> dr to dc } }.filter { (dr, dc) -> kotlin.math.abs(dr - dc) <= 1 }
        } else listOf(0 to 0)

        for ((dr, dc) in rcOptions) {
            val rows = (rough.rows + dr).coerceIn(4, 14)
            val cols = (rough.cols + dc).coerceIn(4, 14)
            val base = rough.copy(rows = rows, cols = cols)
            // coarse search
            val scales = if (light) floatArrayOf(0.97f, 1f, 1.03f) else floatArrayOf(0.94f, 0.97f, 1f, 1.03f, 1.06f)
            val shift = if (light) 2 else 3
            for (scale in scales) {
                for (sx in -shift..shift) for (sy in -shift..shift) {
                    val cand = transform(base, scale, sx * base.cellW * 0.12f, sy * base.cellH * 0.12f)
                    val s = score(f, cand)
                    if (s > bestScore) { bestScore = s; best = cand }
                }
            }
        }
        // fine search around the best
        val coarse = best
        for (scale in floatArrayOf(0.985f, 1f, 1.015f)) {
            for (sx in -2..2) for (sy in -2..2) {
                val cand = transform(coarse, scale, sx * coarse.cellW * 0.04f, sy * coarse.cellH * 0.04f)
                val s = score(f, cand)
                if (s > bestScore) { bestScore = s; best = cand }
            }
        }
        return best
    }

    /** Clear readings in well-aligned cells score high; a slight bonus for more known cells. */
    private fun score(f: Frame, cfg: BoardConfig): Float {
        val r = read(f, cfg, grid = 5)
        val base = r.clarity + r.knownRatio * 0.15f
        return if (r.looksLikeBoard()) base else base - 1f
    }

    private fun transform(b: BoardConfig, scale: Float, dx: Float, dy: Float): BoardConfig {
        val cx = (b.left + b.right) / 2f + dx
        val cy = (b.top + b.bottom) / 2f + dy
        val hw = (b.right - b.left) / 2f * scale
        val hh = (b.bottom - b.top) / 2f * scale
        return b.copy(
            left = (cx - hw).toInt(), right = (cx + hw).toInt(),
            top = (cy - hh).toInt(), bottom = (cy + hh).toInt()
        )
    }

    private fun std(sum: Float, sq: Float, n: Int): Float {
        val m = sum / n
        val v = sq / n - m * m
        return if (v > 0f) kotlin.math.sqrt(v) else 0f
    }

    /** Fast RGB → HSV (h 0..360, s 0..1, v 0..1) without the JNI call of Color.colorToHSV. */
    fun toHsv(c: Int, out: FloatArray) {
        val r = ((c shr 16) and 0xFF) / 255f
        val g = ((c shr 8) and 0xFF) / 255f
        val b = (c and 0xFF) / 255f
        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val d = max - min
        var h = when {
            d == 0f -> 0f
            max == r -> 60f * (((g - b) / d) % 6f)
            max == g -> 60f * (((b - r) / d) + 2f)
            else -> 60f * (((r - g) / d) + 4f)
        }
        if (h < 0f) h += 360f
        out[0] = h
        out[1] = if (max == 0f) 0f else d / max
        out[2] = max
    }

    fun describe(board: Array<IntArray>): String = board.joinToString("\n") { row ->
        row.joinToString(" ") { if (it < 0) "." else COLOR_NAMES[it].first().uppercase() }
    }
}
