package com.appforge.tappilot.game.chess

import com.appforge.tappilot.game.chess.ChessBoard.Companion.B
import com.appforge.tappilot.game.chess.ChessBoard.Companion.F_CAP
import com.appforge.tappilot.game.chess.ChessBoard.Companion.K
import com.appforge.tappilot.game.chess.ChessBoard.Companion.N
import com.appforge.tappilot.game.chess.ChessBoard.Companion.P
import com.appforge.tappilot.game.chess.ChessBoard.Companion.Q
import com.appforge.tappilot.game.chess.ChessBoard.Companion.R
import com.appforge.tappilot.game.chess.ChessBoard.Companion.WHITE

/**
 * Built-in chess engine (runs on the phone, no internet):
 * alpha-beta search with iterative deepening, quiescence, check extension,
 * MVV-LVA + killer move ordering and piece-square evaluation. Roughly club-player strength.
 */
class ChessEngine {

    private lateinit var b: ChessBoard
    private var deadline = 0L
    private var nodes = 0L
    private var stopped = false
    private val moveBuf = Array(MAX_PLY) { IntArray(256) }
    private val scoreBuf = Array(MAX_PLY) { IntArray(256) }
    private val killers = Array(MAX_PLY) { IntArray(2) }

    /** Returns the best move for the side to move, or 0 when there is none (mate/stalemate). */
    fun bestMove(board: ChessBoard, timeMs: Long): Int {
        b = board.copy()
        deadline = System.currentTimeMillis() + timeMs
        nodes = 0
        stopped = false
        for (k in killers) { k[0] = 0; k[1] = 0 }

        val root = b.legal()
        if (root.isEmpty()) return 0
        if (root.size == 1) return root[0]
        var best = root[0]
        val order = root.toMutableList()

        for (depth in 1 until MAX_PLY - 8) {
            var alpha = -INF
            var iterBest = 0
            var completed = true
            for (m in order) {
                b.make(m)
                val score = -negamax(depth - 1, -INF, -alpha, 1)
                b.unmake()
                if (stopped) { completed = false; break }
                if (score > alpha) { alpha = score; iterBest = m }
            }
            if (completed && iterBest != 0) {
                best = iterBest
                order.remove(best)
                order.add(0, best)
            } else if (!completed && iterBest != 0 && iterBest == order[0]) {
                best = iterBest
            }
            if (stopped || System.currentTimeMillis() > deadline) break
            if (alpha > MATE - 200) break // found a forced mate
        }
        return best
    }

    private fun timeUp(): Boolean {
        if ((++nodes and 2047L) == 0L && System.currentTimeMillis() > deadline) stopped = true
        return stopped
    }

    private fun negamax(depthIn: Int, alphaIn: Int, beta: Int, ply: Int): Int {
        if (timeUp()) return 0
        if (b.half >= 100) return 0
        var alpha = alphaIn
        val inCheck = b.inCheck()
        var depth = depthIn
        if (inCheck && ply < MAX_PLY - 10) depth++
        if (depth <= 0 || ply >= MAX_PLY - 2) return quiesce(alpha, beta, ply)

        val moves = moveBuf[ply]
        val scores = scoreBuf[ply]
        val n = b.pseudo(moves)
        scoreMoves(moves, scores, n, ply)

        var legal = 0
        for (i in 0 until n) {
            pickBest(moves, scores, i, n)
            val m = moves[i]
            b.make(m)
            if (b.attacked(b.king[1 - b.side], b.side)) { b.unmake(); continue }
            legal++
            val score = -negamax(depth - 1, -beta, -alpha, ply + 1)
            b.unmake()
            if (stopped) return 0
            if (score >= beta) {
                if ((ChessBoard.flags(m) and F_CAP) == 0 && killers[ply][0] != m) {
                    killers[ply][1] = killers[ply][0]
                    killers[ply][0] = m
                }
                return beta
            }
            if (score > alpha) alpha = score
        }
        if (legal == 0) return if (inCheck) -MATE + ply else 0
        return alpha
    }

    private fun quiesce(alphaIn: Int, beta: Int, ply: Int): Int {
        if (timeUp()) return 0
        var alpha = alphaIn
        val stand = evaluate()
        if (stand >= beta) return beta
        if (stand > alpha) alpha = stand
        if (ply >= MAX_PLY - 1) return alpha

        val moves = moveBuf[ply]
        val scores = scoreBuf[ply]
        val n = b.pseudo(moves, capsOnly = true)
        scoreMoves(moves, scores, n, ply)
        for (i in 0 until n) {
            pickBest(moves, scores, i, n)
            val m = moves[i]
            b.make(m)
            if (b.attacked(b.king[1 - b.side], b.side)) { b.unmake(); continue }
            val score = -quiesce(-beta, -alpha, ply + 1)
            b.unmake()
            if (stopped) return 0
            if (score >= beta) return beta
            if (score > alpha) alpha = score
        }
        return alpha
    }

    private fun scoreMoves(moves: IntArray, scores: IntArray, n: Int, ply: Int) {
        for (i in 0 until n) {
            val m = moves[i]
            var s = 0
            if ((ChessBoard.flags(m) and F_CAP) != 0) {
                val victim = b.sq[ChessBoard.to(m)] and 7
                val attacker = b.sq[ChessBoard.from(m)] and 7
                s = 10_000 + VALUE[if (victim == 0) P else victim] * 10 - attacker
            }
            if (ChessBoard.promo(m) == Q) s += 9_000
            if (s == 0) {
                if (m == killers[ply][0]) s = 8_000 else if (m == killers[ply][1]) s = 7_000
            }
            scores[i] = s
        }
    }

    private fun pickBest(moves: IntArray, scores: IntArray, start: Int, n: Int) {
        var bi = start
        for (j in start + 1 until n) if (scores[j] > scores[bi]) bi = j
        if (bi != start) {
            val tm = moves[start]; moves[start] = moves[bi]; moves[bi] = tm
            val ts = scores[start]; scores[start] = scores[bi]; scores[bi] = ts
        }
    }

    /** Material + piece-square tables, from the side to move's point of view. */
    private fun evaluate(): Int {
        var score = 0
        var bishopsW = 0
        var bishopsB = 0
        var material = 0
        for (s in 0 until 64) {
            val p = b.sq[s]
            if (p == 0) continue
            val t = p and 7
            if (t != K && t != P) material += VALUE[t]
        }
        val endgame = material <= 2600
        for (s in 0 until 64) {
            val p = b.sq[s]
            if (p == 0) continue
            val t = p and 7
            val white = (p shr 3) == WHITE
            val r = s / 8
            val f = s % 8
            // tables are written from White's side with rank 8 first
            val idx = if (white) (7 - r) * 8 + f else r * 8 + f
            val pst = when (t) {
                P -> PST_P[idx]
                N -> PST_N[idx]
                B -> PST_B[idx]
                R -> PST_R[idx]
                Q -> PST_Q[idx]
                else -> if (endgame) PST_K_END[idx] else PST_K_MID[idx]
            }
            val v = VALUE[t] + pst
            if (white) score += v else score -= v
            if (t == B) { if (white) bishopsW++ else bishopsB++ }
        }
        if (bishopsW >= 2) score += 30
        if (bishopsB >= 2) score -= 30
        return if (b.side == WHITE) score else -score
    }

    companion object {
        const val INF = 1_000_000
        const val MATE = 100_000
        const val MAX_PLY = 64

        val VALUE = intArrayOf(0, 100, 320, 330, 500, 900, 0)

        val PST_P = intArrayOf(
            0, 0, 0, 0, 0, 0, 0, 0,
            50, 50, 50, 50, 50, 50, 50, 50,
            10, 10, 20, 30, 30, 20, 10, 10,
            5, 5, 10, 25, 25, 10, 5, 5,
            0, 0, 0, 20, 20, 0, 0, 0,
            5, -5, -10, 0, 0, -10, -5, 5,
            5, 10, 10, -20, -20, 10, 10, 5,
            0, 0, 0, 0, 0, 0, 0, 0
        )
        val PST_N = intArrayOf(
            -50, -40, -30, -30, -30, -30, -40, -50,
            -40, -20, 0, 0, 0, 0, -20, -40,
            -30, 0, 10, 15, 15, 10, 0, -30,
            -30, 5, 15, 20, 20, 15, 5, -30,
            -30, 0, 15, 20, 20, 15, 0, -30,
            -30, 5, 10, 15, 15, 10, 5, -30,
            -40, -20, 0, 5, 5, 0, -20, -40,
            -50, -40, -30, -30, -30, -30, -40, -50
        )
        val PST_B = intArrayOf(
            -20, -10, -10, -10, -10, -10, -10, -20,
            -10, 0, 0, 0, 0, 0, 0, -10,
            -10, 0, 5, 10, 10, 5, 0, -10,
            -10, 5, 5, 10, 10, 5, 5, -10,
            -10, 0, 10, 10, 10, 10, 0, -10,
            -10, 10, 10, 10, 10, 10, 10, -10,
            -10, 5, 0, 0, 0, 0, 5, -10,
            -20, -10, -10, -10, -10, -10, -10, -20
        )
        val PST_R = intArrayOf(
            0, 0, 0, 0, 0, 0, 0, 0,
            5, 10, 10, 10, 10, 10, 10, 5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            0, 0, 0, 5, 5, 0, 0, 0
        )
        val PST_Q = intArrayOf(
            -20, -10, -10, -5, -5, -10, -10, -20,
            -10, 0, 0, 0, 0, 0, 0, -10,
            -10, 0, 5, 5, 5, 5, 0, -10,
            -5, 0, 5, 5, 5, 5, 0, -5,
            0, 0, 5, 5, 5, 5, 0, -5,
            -10, 5, 5, 5, 5, 5, 0, -10,
            -10, 0, 5, 0, 0, 0, 0, -10,
            -20, -10, -10, -5, -5, -10, -10, -20
        )
        val PST_K_MID = intArrayOf(
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -20, -30, -30, -40, -40, -30, -30, -20,
            -10, -20, -20, -20, -20, -20, -20, -10,
            20, 20, 0, 0, 0, 0, 20, 20,
            20, 30, 10, 0, 0, 10, 30, 20
        )
        val PST_K_END = intArrayOf(
            -50, -40, -30, -20, -20, -30, -40, -50,
            -30, -20, -10, 0, 0, -10, -20, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -30, 0, 0, 0, 0, -30, -30,
            -50, -30, -30, -30, -30, -30, -30, -50
        )
    }
}
