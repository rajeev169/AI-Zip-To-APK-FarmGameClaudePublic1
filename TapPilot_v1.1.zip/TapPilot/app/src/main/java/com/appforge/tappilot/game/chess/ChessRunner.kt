package com.appforge.tappilot.game.chess

import com.appforge.tappilot.agent.GeminiClient
import com.appforge.tappilot.data.BoardConfig
import com.appforge.tappilot.data.GameProfile
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.game.Frame
import com.appforge.tappilot.game.GameGuard
import com.appforge.tappilot.game.PopupHandler
import com.appforge.tappilot.game.StopGame
import com.appforge.tappilot.service.PilotService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.random.Random

/**
 * Plays chess against the computer in an offline chess app.
 * It keeps its own copy of the game: after each opponent move it compares the screen with every
 * legal move and picks the one that matches, then the engine chooses TapPilot's reply.
 */
class ChessRunner(
    private val svc: PilotService,
    private val gamePkg: String,
    private val profile: GameProfile,
    cfg: BoardConfig
) {
    private val vision = ChessVision(cfg, profile.bottomIsWhite)
    private val engine = ChessEngine()
    private val guard = GameGuard(svc, gamePkg)
    private val popups = PopupHandler(svc)

    private var board = ChessBoard.start()
    private var myColor = ChessBoard.WHITE
    private var baseline: Array<ChessVision.SquareLook>? = null

    suspend fun run(): String {
        val uci = UciEngine.startIfBundled(svc)
        svc.status(if (uci != null) "Chess: using Stockfish" else "Chess: using the built-in engine")
        var games = 0
        try {
            var needSync = true
            while (true) {
                if (needSync) sync()
                val result = playOneGame(uci)
                games++
                svc.status("Game $games: $result. Waiting for a new game…")
                // true = a game is already in progress again (read by Gemini), so no fresh sync needed
                needSync = !waitForNewGame()
            }
        } finally {
            uci?.close()
        }
        return "Stopped"
    }

    private suspend fun frame(): Frame? {
        val bmp = svc.screenshot() ?: return null
        return withContext(Dispatchers.Default) { Frame.of(bmp) }
    }

    /** Works out the current position: the starting position by sight, otherwise asks Gemini. */
    private suspend fun sync() {
        repeat(12) { attempt ->
            if (!guard.ensureInGame()) return@repeat
            val f = frame() ?: run { delay(800); return@repeat }
            val atStart = withContext(Dispatchers.Default) { vision.calibrateOnStart(f) }
            if (atStart) {
                val looks = vision.look(f)
                vision.bottomIsWhite = vision.bottomLooksWhite(looks)
                board = ChessBoard.start()
                myColor = if (vision.bottomIsWhite) ChessBoard.WHITE else ChessBoard.BLACK
                baseline = vision.look(f)
                Prefs.saveBoard(gamePkg, vision.cfg)
                svc.status("New game. TapPilot plays ${if (myColor == ChessBoard.WHITE) "White" else "Black"}.")
                return
            }
            if (Prefs.apiKey.isNotBlank() && attempt >= 1) {
                val ok = syncWithGemini()
                if (ok) return
            }
            val bmp = svc.screenshot()
            popups.handle(bmp, 3)
            delay(2000)
        }
        throw StopGame("Couldn't follow the chess board. Start a new game against the computer, then tap Play.")
    }

    private suspend fun syncWithGemini(): Boolean {
        val bmp = svc.screenshot() ?: return false
        svc.status("Asking Gemini to read the position…")
        return try {
            val o = GeminiClient.parseJson(
                GeminiClient.generate(
                    "You read chess positions from screenshots precisely. Reply JSON only.",
                    "Read this chess board. Reply {\"on_board\": true|false, \"fen\": \"<full FEN incl. side to move>\", " +
                        "\"bottom_color\": \"white|black\"}. on_board=false if no chess board in play is visible.",
                    bmp, json = true
                )
            )
            if (!o.optBoolean("on_board", true)) return false
            val fen = o.optString("fen", "")
            if (fen.count { it == '/' } != 7 || !fen.contains('K') || !fen.contains('k')) return false
            val b = ChessBoard.fromFen(fen)
            vision.bottomIsWhite = o.optString("bottom_color", "white").lowercase() != "black"
            val f = withContext(Dispatchers.Default) { Frame.of(bmp) }
            val looks = vision.look(f)
            vision.threshold = vision.autoThreshold(looks)
            val occ = vision.occupancy(looks)
            val exp = b.occupancy()
            val match = (0 until 64).count { occ[it] == exp[it] }
            if (match < 60) return false
            board = b
            myColor = if (vision.bottomIsWhite) ChessBoard.WHITE else ChessBoard.BLACK
            baseline = looks
            svc.status("Position read. TapPilot plays ${if (myColor == ChessBoard.WHITE) "White" else "Black"}.")
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Plays until the game ends. Returns a short result. */
    private suspend fun playOneGame(uci: UciEngine?): String {
        var unclear = 0
        var waitingSince = System.currentTimeMillis()
        while (true) {
            if (!guard.ensureInGame()) continue
            val legal = board.legal()
            if (legal.isEmpty()) {
                return if (board.inCheck()) {
                    if (board.side == myColor) "TapPilot lost" else "TapPilot won by checkmate"
                } else "draw (stalemate)"
            }
            if (board.half >= 100) return "draw (50-move rule)"

            if (board.side == myColor) {
                val move = chooseMove(uci, legal)
                if (guard.human) delay(Random.nextLong(600, 3000))
                if (!playMove(move)) {
                    // screen didn't show the move: re-read the position
                    svc.status("Move didn't register — re-reading the board…")
                    if (!syncWithGemini()) sync()
                    continue
                }
                waitingSince = System.currentTimeMillis()
            } else {
                svc.status("Waiting for the opponent…")
                val f = frame() ?: run { delay(700); null } ?: continue
                val looks = vision.look(f)
                val occ = vision.occupancy(looks)
                val now = board.occupancy()
                val changed = baseline?.let { base -> (0 until 64).filter { looks[it].differs(base[it]) } } ?: emptyList()
                if (occ.contentEquals(now) && changed.size < 2) {
                    if (System.currentTimeMillis() - waitingSince > 120_000) {
                        // nothing for 2 minutes: maybe a popup or the game ended on time
                        popups.handle(svc.screenshot(), 3)
                        waitingSince = System.currentTimeMillis()
                    }
                    delay(700)
                    continue
                }
                delay(450) // let the animation finish, then confirm
                val f2 = frame() ?: continue
                val looks2 = vision.look(f2)
                val occ2 = vision.occupancy(looks2)
                if (!occ2.contentEquals(occ)) continue

                val (m, mismatch) = inferMove(legal, occ2, looks2)
                if (m != 0 && (mismatch == 0 || (mismatch <= 2 && unclear >= 2))) {
                    board.make(m)
                    baseline = looks2
                    unclear = 0
                    svc.status("Opponent played ${ChessBoard.uci(m)}")
                    waitingSince = System.currentTimeMillis()
                } else {
                    unclear++
                    if (unclear >= 6) {
                        unclear = 0
                        if (mismatch > 10) {
                            // board covered: result screen or popup
                            return "game ended or a popup covered the board"
                        }
                        svc.status("Lost track of the game — re-reading…")
                        if (!syncWithGemini()) sync()
                    } else delay(500)
                }
            }
        }
        return "stopped"
    }

    private suspend fun chooseMove(uci: UciEngine?, legal: IntArray): Int {
        val ms = Prefs.chessThinkMs.toLong()
        svc.status("Thinking…")
        var move = 0
        if (uci != null) {
            val best = uci.bestMove(board.toFen(), ms)
            if (best != null) move = legal.firstOrNull { ChessBoard.uci(it) == best } ?: 0
        }
        if (move == 0) move = withContext(Dispatchers.Default) { engine.bestMove(board, ms) }
        if (move == 0) move = legal[0]
        // chess apps usually auto-promote to a queen; keep our copy in step with that
        if (ChessBoard.promo(move) != 0 && ChessBoard.promo(move) != ChessBoard.Q) {
            legal.firstOrNull {
                ChessBoard.from(it) == ChessBoard.from(move) && ChessBoard.to(it) == ChessBoard.to(move) &&
                    ChessBoard.promo(it) == ChessBoard.Q
            }?.let { move = it }
        }
        return move
    }

    /** Taps the move on screen and checks that the board now shows it. */
    private suspend fun playMove(m: Int): Boolean {
        val from = ChessBoard.from(m)
        val to = ChessBoard.to(m)
        svc.status("Playing ${ChessBoard.uci(m)}")
        val after = board.copy().apply { make(m) }.occupancy()

        for (attempt in 0 until 3) {
            when (attempt) {
                0 -> {
                    svc.tap(vision.centerX(from), vision.centerY(from))
                    delay(300)
                    svc.tap(vision.centerX(to), vision.centerY(to))
                }
                1 -> svc.swipe(vision.centerX(from), vision.centerY(from), vision.centerX(to), vision.centerY(to), 450)
                else -> {
                    // promotion pickers usually show the queen on the target square
                    svc.tap(vision.centerX(to), vision.centerY(to))
                }
            }
            delay(1000)
            val f = frame() ?: continue
            val looks = vision.look(f)
            val occ = vision.occupancy(looks)
            val mismatch = (0 until 64).count { occ[it] != after[it] }
            if (mismatch <= 1) {
                board.make(m)
                baseline = looks
                return true
            }
        }
        return false
    }

    /** Picks the legal move whose result looks most like the screen. Returns (move, mismatching squares). */
    private fun inferMove(legal: IntArray, occ: BooleanArray, looks: Array<ChessVision.SquareLook>): Pair<Int, Int> {
        val base = baseline
        var best = 0
        var bestMis = Int.MAX_VALUE
        var bestBonus = -1
        for (m in legal) {
            board.make(m)
            val exp = board.occupancy()
            board.unmake()
            val mis = (0 until 64).count { exp[it] != occ[it] }
            // for captures the target stays occupied, so also check that it visibly changed
            val bonus = if (base != null && looks[ChessBoard.to(m)].differs(base[ChessBoard.to(m)])) 1 else 0
            if (mis < bestMis || (mis == bestMis && bonus > bestBonus)) {
                best = m; bestMis = mis; bestBonus = bonus
            }
        }
        return best to bestMis
    }

    /** Returns false when a fresh game is at the start position, true when Gemini found a game in progress. */
    private suspend fun waitForNewGame(): Boolean {
        var tries = 0
        while (true) {
            if (!guard.ensureInGame()) continue
            val f = frame()
            if (f != null && withContext(Dispatchers.Default) { vision.calibrateOnStart(f) }) return false
            tries++
            if (tries > 40) throw StopGame("No new game started. Stopped.")
            // maybe the game simply continues after a popup
            if (tries % 5 == 0 && Prefs.apiKey.isNotBlank() && syncWithGemini() && board.legal().isNotEmpty()) return true
            popups.handle(svc.screenshot(), 3)
            delay(2000)
        }
        return false
    }
}
