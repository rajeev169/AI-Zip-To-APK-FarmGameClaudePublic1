# TapPilot 1.0 (AppForge)

AI phone agent + match-3 game auto-play + record & replay for Android.

- Package: `com.appforge.tappilot`
- minSdk 26 (Android 8), targetSdk 35. Game mode and screenshots need Android 11+.
- Kotlin + Jetpack Compose (Material 3), AGP 8.7.3, Gradle 8.11.1 wrapper, JDK 17.
- No server, no Firebase. AI uses the user's own free Gemini API key.

## Build
Push this folder (zipped) through the "Universal ZIP to APK" workflow, or locally:
```
./gradlew assembleRelease      # APK
./gradlew bundleRelease        # AAB for Play
```

## First run on the phone
1. Open TapPilot → **Turn on** → agree → Accessibility → TapPilot Assistant → On.
   If the switch is greyed out ("Restricted setting", sideloaded APK on Android 13+):
   App info → ⋮ → **Allow restricted settings**, then turn it on.
2. Settings → paste a free key from https://aistudio.google.com/apikey → Save.
3. Agent tab: type or speak (हिंदी / English) and tap Run.

## Features
- **Agent** (`agent/`): reads the screen (accessibility tree + screenshot), asks Gemini for one
  action at a time (tap / type / scroll / open app / back / done), step limit, request pacing for free keys.
- **Game mode** (`game/`): one-time grid calibration per game, colour reading, on-phone solver
  (5 → T/L → 4 → 3, lower moves preferred), popup & ad handling (readable buttons first, Gemini
  vision for unknown screens, cached), human-like mode with breaks, out-of-lives detection.
- **Record & replay** (`record/`): records taps/long-presses/swipes and replays 1×, 5× or in a loop.
- **Safety** (`service/SafetyGuard.kt`): floating Stop button, blocks banking/UPI/wallet/broker apps,
  OTP/PIN/password screens, never taps Pay/Buy/Subscribe/price buttons.

## Play Store notes
Google Play restricts the Accessibility API. For this app you must:
- Fill the **Accessibility API declaration** in Play Console (explain the automation use, add a short video).
- Keep the in-app prominent disclosure (already shown before opening Accessibility settings).
- Add a privacy policy saying screen content is sent to Google Gemini only with the user's own key.
Expect a stricter review than usual; a rejection is possible for non-accessibility automation apps.
