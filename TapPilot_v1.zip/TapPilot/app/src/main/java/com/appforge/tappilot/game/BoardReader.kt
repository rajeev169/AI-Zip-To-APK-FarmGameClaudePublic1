package com.appforge.tappilot.game

import android.graphics.Bitmap
import android.graphics.Color
import com.appforge.tappilot.data.BoardConfig

/**
 * Reads candy colours from a screenshot.
 * Each cell's centre area is sampled; saturated pixels vote for a colour bucket.
 * Cells with no clear colour (empty, blockers, chocolate, colour bombs) become -1.
 */
object BoardReader {

    const val UNKNOWN = -1
    val COLOR_NAMES = arrayOf("red", "orange", "yellow", "green", "blue", "purple")

    data class Reading(val board: Array<IntArray>, val knownRatio: Float) {
        fun sameAs(other: Reading?): Boolean {
            if (other == null || other.board.size != board.size) return false
            for (r in board.indices) if (!board[r].contentEquals(other.board[r])) return false
            return true
        }
    }

    private fun bucket(h: Float): Int = when {
        h >= 345f || h < 14f -> 0   // red
        h < 38f -> 1                // orange
        h < 70f -> 2                // yellow
        h < 165f -> 3               // green
        h < 255f -> 4               // blue
        else -> 5                   // purple / pink
    }

    fun read(bmp: Bitmap, cfg: BoardConfig): Reading {
        val board = Array(cfg.rows) { IntArray(cfg.cols) { UNKNOWN } }
        var known = 0
        val hsv = FloatArray(3)
        val votes = IntArray(6)
        val grid = 6 // 6x6 samples per cell

        for (r in 0 until cfg.rows) {
            for (c in 0 until cfg.cols) {
                votes.fill(0)
                var samples = 0
                val cx = cfg.cellCenterX(c)
                val cy = cfg.cellCenterY(r)
                // sample the middle 45% of the cell (avoids the background between candies)
                val spanX = cfg.cellW * 0.45f
                val spanY = cfg.cellH * 0.45f
                for (i in 0 until grid) {
                    for (j in 0 until grid) {
                        val x = (cx - spanX / 2 + spanX * (i + 0.5f) / grid).toInt()
                        val y = (cy - spanY / 2 + spanY * (j + 0.5f) / grid).toInt()
                        if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) continue
                        samples++
                        Color.colorToHSV(bmp.getPixel(x, y), hsv)
                        val s = hsv[1]
                        val v = hsv[2]
                        if (s < 0.38f || v < 0.40f) continue
                        // dark orange is usually chocolate / wooden blockers
                        val b = bucket(hsv[0])
                        if (b == 1 && v < 0.55f) continue
                        votes[b]++
                    }
                }
                if (samples == 0) continue
                var best = -1
                var bestVotes = 0
                var second = 0
                for (k in 0 until 6) {
                    if (votes[k] > bestVotes) {
                        second = bestVotes; bestVotes = votes[k]; best = k
                    } else if (votes[k] > second) second = votes[k]
                }
                // Need a clear winner covering a good part of the sample
                if (best >= 0 && bestVotes >= samples * 0.30f && bestVotes >= second * 1.8f) {
                    board[r][c] = best
                    known++
                }
            }
        }
        return Reading(board, known.toFloat() / (cfg.rows * cfg.cols))
    }

    fun describe(board: Array<IntArray>): String = board.joinToString("\n") { row ->
        row.joinToString(" ") { if (it < 0) "." else COLOR_NAMES[it].first().uppercase() }
    }
}
