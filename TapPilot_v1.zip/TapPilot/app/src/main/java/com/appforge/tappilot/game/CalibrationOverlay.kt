package com.appforge.tappilot.game

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.appforge.tappilot.data.BoardConfig
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.PilotService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Full-screen overlay where the user drags a grid over the game board once per game.
 * "Test" reads the board through the grid and shows the detected colours as dots.
 */
class CalibrationOverlay(
    private val svc: PilotService,
    private val gamePkg: String,
    private val onClose: (saved: Boolean) -> Unit
) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: FrameLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private lateinit var gridView: GridView
    private lateinit var info: TextView
    private lateinit var bar: LinearLayout
    private var rows = 9
    private var cols = 9
    private var barAtTop = false

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), svc.resources.displayMetrics
    ).toInt()

    fun show() {
        val (w, h) = svc.screenSize()
        val saved = Prefs.board(gamePkg)
        val rect = if (saved != null) {
            rows = saved.rows; cols = saved.cols
            RectF(saved.left.toFloat(), saved.top.toFloat(), saved.right.toFloat(), saved.bottom.toFloat())
        } else {
            val l = w * 0.04f
            val r = w * 0.96f
            val t = h * 0.28f
            RectF(l, t, r, t + (r - l))
        }

        val frame = FrameLayout(svc)
        gridView = GridView(svc, rect)
        frame.addView(gridView, FrameLayout.LayoutParams(-1, -1))

        bar = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(Color.parseColor("#F0241A7A"))
            }
        }
        info = TextView(svc).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            text = "Drag the box so each line sits between candies. Drag corners to resize."
        }
        bar.addView(info)
        bar.addView(row(
            btn("Rows −") { rows = (rows - 1).coerceAtLeast(3); refresh() },
            btn("Rows +") { rows = (rows + 1).coerceAtMost(14); refresh() },
            btn("Cols −") { cols = (cols - 1).coerceAtLeast(3); refresh() },
            btn("Cols +") { cols = (cols + 1).coerceAtMost(14); refresh() }
        ))
        bar.addView(row(
            btn("⇅") { barAtTop = !barAtTop; placeBar() },
            btn("Test") { test() },
            btn("Cancel", Color.parseColor("#5A5480")) { close(false) },
            btn("Save", Color.parseColor("#2E9D5B")) { save() }
        ))
        frame.addView(bar)
        placeBar()

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            wm.addView(frame, lp)
            root = frame
            params = lp
            refresh()
        } catch (e: Exception) {
            onClose(false)
        }
    }

    private fun placeBar() {
        val lp = FrameLayout.LayoutParams(-1, -2).apply {
            gravity = if (barAtTop) Gravity.TOP else Gravity.BOTTOM
            setMargins(dp(10), dp(36), dp(10), dp(36))
        }
        bar.layoutParams = lp
    }

    private fun row(vararg views: View): LinearLayout = LinearLayout(svc).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(8), 0, 0)
        views.forEach { v ->
            addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        }
    }

    private fun btn(label: String, color: Int = Color.parseColor("#3F6BE0"), onClick: () -> Unit): TextView =
        TextView(svc).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(dp(4), dp(10), dp(4), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(color)
            }
            setOnClickListener { onClick() }
        }

    private fun refresh() {
        gridView.rows = rows
        gridView.cols = cols
        gridView.dots = null
        gridView.invalidate()
        info.text = "Grid $rows × $cols. Line up the box with the candy board, then tap Test."
    }

    private fun currentConfig(): BoardConfig {
        val r = gridView.screenRect()
        return BoardConfig(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt(), rows, cols)
    }

    private fun test() {
        val v = root ?: return
        val p = params ?: return
        svc.scope.launch {
            info.text = "Reading the board…"
            v.visibility = View.INVISIBLE
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
            delay(450)
            val bmp = svc.screenshot()
            v.visibility = View.VISIBLE
            p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
            if (bmp == null) {
                info.text = "Screenshot failed. Game mode needs Android 11 or newer."
                return@launch
            }
            val reading = BoardReader.read(bmp, currentConfig())
            gridView.dots = reading.board
            gridView.invalidate()
            val total = rows * cols
            val known = (reading.knownRatio * total).toInt()
            val move = Match3Solver.bestMove(reading.board)
            info.text = "Read $known of $total cells. " +
                (if (move != null) "Best move found ✔ " else "No move found. ") +
                "Dots should match the candy colours. If OK, tap Save."
        }
    }

    private fun save() {
        Prefs.saveBoard(gamePkg, currentConfig())
        close(true)
    }

    private fun close(saved: Boolean) {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        onClose(saved)
    }

    /** Draws the dimmed screen, the board box, grid lines, corner handles and test dots. */
    @SuppressLint("ViewConstructor")
    private class GridView(ctx: Context, initialScreenRect: RectF) : View(ctx) {
        var rows = 9
        var cols = 9
        var dots: Array<IntArray>? = null

        // kept in SCREEN coordinates (same as screenshots and gestures)
        private val rect = RectF(initialScreenRect)
        private val dim = Paint().apply { color = Color.parseColor("#66000000") }
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFFFC940"); style = Paint.Style.STROKE; strokeWidth = 5f
        }
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CCFFFFFF"); style = Paint.Style.STROKE; strokeWidth = 2f
        }
        private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFFFC940") }
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val dotEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f
        }
        private val dotColors = intArrayOf(
            Color.parseColor("#FF2D2D"), Color.parseColor("#FF8C1A"), Color.parseColor("#FFE01A"),
            Color.parseColor("#2ECC40"), Color.parseColor("#2D7DFF"), Color.parseColor("#B04DFF")
        )

        private var mode = 0 // 0 none, 1 move, 2..5 corners TL,TR,BL,BR
        private var lastX = 0f
        private var lastY = 0f
        private val loc = IntArray(2)

        fun screenRect(): RectF = RectF(rect)

        private fun offset(): Pair<Float, Float> {
            getLocationOnScreen(loc)
            return loc[0].toFloat() to loc[1].toFloat()
        }

        override fun onDraw(canvas: Canvas) {
            val (ox, oy) = offset()
            val r = RectF(rect.left - ox, rect.top - oy, rect.right - ox, rect.bottom - oy)
            canvas.drawRect(0f, 0f, width.toFloat(), r.top, dim)
            canvas.drawRect(0f, r.bottom, width.toFloat(), height.toFloat(), dim)
            canvas.drawRect(0f, r.top, r.left, r.bottom, dim)
            canvas.drawRect(r.right, r.top, width.toFloat(), r.bottom, dim)
            val cw = r.width() / cols
            val ch = r.height() / rows
            for (i in 1 until cols) canvas.drawLine(r.left + cw * i, r.top, r.left + cw * i, r.bottom, line)
            for (i in 1 until rows) canvas.drawLine(r.left, r.top + ch * i, r.right, r.top + ch * i, line)
            canvas.drawRect(r, stroke)
            val hs = 22f
            for ((x, y) in listOf(r.left to r.top, r.right to r.top, r.left to r.bottom, r.right to r.bottom)) {
                canvas.drawCircle(x, y, hs, handle)
            }
            dots?.let { d ->
                if (d.size == rows && d.isNotEmpty() && d[0].size == cols) {
                    val rad = minOf(cw, ch) * 0.16f
                    for (rr in 0 until rows) for (cc in 0 until cols) {
                        val v = d[rr][cc]
                        if (v < 0) continue
                        dotPaint.color = dotColors[v]
                        val x = r.left + cw * (cc + 0.5f)
                        val y = r.top + ch * (rr + 0.5f)
                        canvas.drawCircle(x, y, rad, dotPaint)
                        canvas.drawCircle(x, y, rad, dotEdge)
                    }
                }
            }
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(e: MotionEvent): Boolean {
            val x = e.rawX
            val y = e.rawY
            val grab = 70f
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    mode = when {
                        near(x, y, rect.left, rect.top, grab) -> 2
                        near(x, y, rect.right, rect.top, grab) -> 3
                        near(x, y, rect.left, rect.bottom, grab) -> 4
                        near(x, y, rect.right, rect.bottom, grab) -> 5
                        rect.contains(x, y) -> 1
                        else -> 0
                    }
                    lastX = x; lastY = y
                    return mode != 0
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = x - lastX
                    val dy = y - lastY
                    lastX = x; lastY = y
                    val min = 120f
                    when (mode) {
                        1 -> rect.offset(dx, dy)
                        2 -> { rect.left = minOf(rect.left + dx, rect.right - min); rect.top = minOf(rect.top + dy, rect.bottom - min) }
                        3 -> { rect.right = maxOf(rect.right + dx, rect.left + min); rect.top = minOf(rect.top + dy, rect.bottom - min) }
                        4 -> { rect.left = minOf(rect.left + dx, rect.right - min); rect.bottom = maxOf(rect.bottom + dy, rect.top + min) }
                        5 -> { rect.right = maxOf(rect.right + dx, rect.left + min); rect.bottom = maxOf(rect.bottom + dy, rect.top + min) }
                    }
                    dots = null
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mode = 0
                    return true
                }
            }
            return false
        }

        private fun near(x: Float, y: Float, px: Float, py: Float, d: Float) = abs(x - px) < d && abs(y - py) < d
    }
}
