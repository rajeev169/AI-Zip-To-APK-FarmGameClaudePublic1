package com.appforge.tappilot.game

import android.os.Build
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.PilotService
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * Plays a match-3 game: screenshot → read colours → best swap → swipe → repeat.
 * When the board isn't visible (ads, popups, level end) the PopupHandler takes over.
 */
class GameRunner(private val svc: PilotService, private val gamePkg: String) {

    private val popups = PopupHandler(svc)

    suspend fun run(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return "Game mode needs Android 11 or newer (screenshots)."
        }
        val cfg = Prefs.board(gamePkg) ?: return "Set the grid for this game first (Grid button)."
        val human = Prefs.humanMode

        var moves = 0
        var prev: BoardReader.Reading? = null
        var stableTries = 0
        var noMove = 0
        var popupStreak = 0
        var offApp = 0
        var playStart = System.currentTimeMillis()
        var nextBreakAfter = randomBreakGap()

        svc.status("Playing… (moves: 0)")

        while (true) {
            // Human-like breaks
            if (human && System.currentTimeMillis() - playStart > nextBreakAfter) {
                val mins = Random.nextInt(2, 6)
                svc.status("Taking a $mins-minute break (human mode)…")
                delay(mins * 60_000L)
                playStart = System.currentTimeMillis()
                nextBreakAfter = randomBreakGap()
            }

            // Make sure the game is in front
            val fg = svc.foregroundPackage()
            if (fg != null && fg != gamePkg) {
                if (fg == "com.android.systemui") { delay(1500); continue }
                offApp++
                svc.status("Left the game ($fg). Going back…")
                if (offApp % 3 == 0) svc.launchPackage(gamePkg) else svc.back()
                delay(2500)
                if (offApp > 12) return "Couldn't get back to the game. Stopped."
                continue
            }
            offApp = 0

            val bmp = svc.screenshot()
            if (bmp == null) { delay(800); continue }
            val reading = BoardReader.read(bmp, cfg)

            if (reading.knownRatio >= 0.45f) {
                popupStreak = 0
                // wait until candies stop falling (two equal readings in a row)
                if (!reading.sameAs(prev) && stableTries < 5) {
                    prev = reading
                    stableTries++
                    delay(350)
                    continue
                }
                stableTries = 0
                prev = null

                val move = Match3Solver.bestMove(reading.board, random = human)
                if (move == null) {
                    noMove++
                    if (noMove >= 4) {
                        // board-like screen with no moves: maybe a level-end screen over the board
                        noMove = 0
                        popups.handle(bmp, 3)
                        delay(1500)
                    } else delay(1200)
                    continue
                }
                noMove = 0

                val x1 = cfg.cellCenterX(move.c1)
                val y1 = cfg.cellCenterY(move.r1)
                val x2 = cfg.cellCenterX(move.c2)
                val y2 = cfg.cellCenterY(move.r2)
                if (human) {
                    val jx = cfg.cellW * 0.12f
                    val jy = cfg.cellH * 0.12f
                    svc.swipe(
                        x1 + Random.nextFloat() * 2 * jx - jx, y1 + Random.nextFloat() * 2 * jy - jy,
                        x2 + Random.nextFloat() * 2 * jx - jx, y2 + Random.nextFloat() * 2 * jy - jy,
                        Random.nextLong(170, 330)
                    )
                } else {
                    svc.swipe(x1, y1, x2, y2, 160)
                }
                moves++
                svc.status("Playing… moves: $moves")
                delay(if (human) Random.nextLong(1600, 3800) else 1100)
            } else {
                popupStreak++
                prev = null
                when (popups.handle(bmp, popupStreak)) {
                    PopupHandler.Result.OUT_OF_LIVES ->
                        return "Out of lives after $moves moves. Try again later."
                    PopupHandler.Result.TAPPED -> svc.status("Closed a popup / continued (moves: $moves)")
                    PopupHandler.Result.BACK -> svc.status("Pressed back (moves: $moves)")
                    PopupHandler.Result.WAITED -> svc.status("Waiting for the board… (moves: $moves)")
                }
                if (popupStreak > 30) return "Stuck on a screen after $moves moves. Stopped."
                delay(1500)
            }
        }
        return "Stopped"
    }

    private fun randomBreakGap(): Long = Random.nextLong(18, 31) * 60_000L
}
