package com.appforge.tappilot.game

/**
 * Finds the best swap on a match-3 board.
 * Board cells hold a colour index (0..5) or -1 for "unknown / blocker / empty".
 * Priority: 5 in a row (colour bomb) > T/L shape (wrapped) > 4 in a row (striped) > 3 in a row.
 * Ties go to moves lower on the board, which tend to cause more cascades.
 */
object Match3Solver {

    data class Move(val r1: Int, val c1: Int, val r2: Int, val c2: Int, val score: Double)

    fun bestMove(board: Array<IntArray>, random: Boolean = false): Move? {
        val rows = board.size
        if (rows == 0) return null
        val cols = board[0].size
        val moves = mutableListOf<Move>()

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (board[r][c] < 0) continue
                // right neighbour
                if (c + 1 < cols && board[r][c + 1] >= 0 && board[r][c + 1] != board[r][c]) {
                    val s = scoreSwap(board, r, c, r, c + 1)
                    if (s > 0) moves.add(Move(r, c, r, c + 1, s + r * 0.05))
                }
                // bottom neighbour
                if (r + 1 < rows && board[r + 1][c] >= 0 && board[r + 1][c] != board[r][c]) {
                    val s = scoreSwap(board, r, c, r + 1, c)
                    if (s > 0) moves.add(Move(r, c, r + 1, c, s + (r + 1) * 0.05))
                }
            }
        }
        if (moves.isEmpty()) return null
        if (random) {
            // Human mode: usually the best move, sometimes a decent but not perfect one
            val sorted = moves.sortedByDescending { it.score }
            val top = sorted.take(3)
            return if (Math.random() < 0.8) top.first() else top.random()
        }
        return moves.maxByOrNull { it.score }
    }

    private fun scoreSwap(b: Array<IntArray>, r1: Int, c1: Int, r2: Int, c2: Int): Double {
        val a = b[r1][c1]
        val bb = b[r2][c2]
        b[r1][c1] = bb
        b[r2][c2] = a
        val s = scoreAt(b, r1, c1) + scoreAt(b, r2, c2)
        b[r1][c1] = a
        b[r2][c2] = bb
        return s
    }

    private fun scoreAt(b: Array<IntArray>, r: Int, c: Int): Double {
        val color = b[r][c]
        if (color < 0) return 0.0
        val rows = b.size
        val cols = b[0].size

        var left = 0
        var cc = c - 1
        while (cc >= 0 && b[r][cc] == color) { left++; cc-- }
        var right = 0
        cc = c + 1
        while (cc < cols && b[r][cc] == color) { right++; cc++ }
        var up = 0
        var rr = r - 1
        while (rr >= 0 && b[rr][c] == color) { up++; rr-- }
        var down = 0
        rr = r + 1
        while (rr < rows && b[rr][c] == color) { down++; rr++ }

        val h = left + right + 1
        val v = up + down + 1
        val hMatch = h >= 3
        val vMatch = v >= 3
        if (!hMatch && !vMatch) return 0.0

        return when {
            h >= 5 || v >= 5 -> 100.0
            hMatch && vMatch -> 60.0
            h == 4 || v == 4 -> 40.0
            else -> 10.0 + (if (hMatch) h else 0) + (if (vMatch) v else 0)
        }
    }
}
