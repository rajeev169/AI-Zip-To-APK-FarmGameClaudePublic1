package com.appforge.tappilot.service

import com.appforge.tappilot.agent.AgentRunner
import com.appforge.tappilot.data.Macro
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.game.CalibrationOverlay
import com.appforge.tappilot.game.GameRunner
import com.appforge.tappilot.record.Recorder

/** Entry points used by the app screens. Each returns an error message, or null when it started. */
object Controls {

    private var recorder: Recorder? = null
    private var recorderOwner: PilotService? = null

    private fun svc(): PilotService? = PilotService.instance

    fun runCommand(text: String): String? {
        val s = svc() ?: return "Turn on the TapPilot assistant first."
        if (text.isBlank()) return "Type or say a command."
        if (Prefs.apiKey.isBlank()) return "Add your free Gemini API key in Settings first."
        s.startJob("🤖 " + text.take(60)) { AgentRunner(s, text.trim()).run() }
        return null
    }

    fun appLabel(pkg: String): String {
        val s = svc() ?: return pkg
        return try {
            val ai = s.packageManager.getApplicationInfo(pkg, 0)
            s.packageManager.getApplicationLabel(ai).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    /** Shows the floating game panel: Grid (set up once per game) and Play. */
    fun showGamePanel(message: String? = null): String? {
        val s = svc() ?: return "Turn on the TapPilot assistant first."
        val btns = listOf(
            FloatingPanel.Btn("⊞ Grid", FloatingPanel.BLUE) { openCalibration() },
            FloatingPanel.Btn("▶ Play", FloatingPanel.GREEN) { startGame() },
            FloatingPanel.Btn("✕", FloatingPanel.GREY) { s.panel.hide() }
        )
        s.panel.show(
            message ?: "🎮 Game mode: open your candy game, then tap Grid (first time only) and Play.",
            btns
        )
        return null
    }

    private fun gameInFront(s: PilotService): String? {
        val pkg = s.foregroundPackage()
        return if (pkg == null || pkg == s.packageName || pkg == "com.android.systemui") null else pkg
    }

    private fun openCalibration() {
        val s = svc() ?: return
        val pkg = gameInFront(s)
        if (pkg == null) {
            s.panel.update("Open your game first, then tap Grid.")
            return
        }
        s.panel.hide()
        CalibrationOverlay(s, pkg) { saved ->
            showGamePanel(
                if (saved) "Grid saved for ${appLabel(pkg)}. Start a level and tap Play."
                else "Grid not saved. Tap Grid to try again."
            )
        }.show()
    }

    private fun startGame() {
        val s = svc() ?: return
        val pkg = gameInFront(s)
        if (pkg == null) {
            s.panel.update("Open your game first, then tap Play.")
            return
        }
        if (Prefs.board(pkg) == null) {
            s.panel.update("Tap Grid first to set up ${appLabel(pkg)}'s board.")
            return
        }
        val name = appLabel(pkg)
        s.startJob("🎮 Playing $name") { GameRunner(s, pkg).run() }
    }

    fun startRecording(): String? {
        val s = svc() ?: return "Turn on the TapPilot assistant first."
        if (s.isBusy) s.stopAll("Stopped to start recording")
        if (recorder == null || recorderOwner !== s) {
            recorder = Recorder(s)
            recorderOwner = s
        }
        val r = recorder ?: return "Could not start recording."
        if (r.isRecording) return "Already recording."
        r.start()
        return null
    }

    fun replay(m: Macro, times: Int): String? {
        val s = svc() ?: return "Turn on the TapPilot assistant first."
        s.startJob("▶ ${m.name}") { Recorder.replay(s, m, times) }
        return null
    }

    fun stop() {
        svc()?.stopAll("Stopped by you")
    }
}
