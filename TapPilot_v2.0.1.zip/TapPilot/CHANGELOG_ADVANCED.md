## Version 2.0.1 merge

Merges the 2.0.0 universal-agent pass with the 1.1.4 game fixes. 2.0.0 was built from 1.1.3, so it had lost the new board finder:
- Restored the 1.1.4 blob-based board finder, so boards with gaps and odd shapes are found on the phone in milliseconds.
- Restored the "keep the smallest board" start-up check and the faster re-fit on new levels.
- The agent's planning step is now limited to 15 seconds, so a slow or rate-limited Gemini key can't delay a command.
- The Settings version label now matches the build.


## Version 2.0.0 universal-agent pass

The v2 build adds on-device ML Kit OCR for Latin and Devanagari text, which supplements the accessibility tree for canvas and WebView interfaces. It also adds a bounded persistent run trace containing short redacted plan, policy, and verification events, plus local capability hints for common app families such as messaging, video, browsers, alarms, settings, mail, and app stores.

These features improve observation and verification but do not bypass Android permissions, CAPTCHAs, biometric prompts, protected payment flows, or an app that exposes no usable UI surface.
