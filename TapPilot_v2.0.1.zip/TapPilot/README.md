# TapPilot 2.0.1 Universal Agent (AppForge)

AI phone agent + match-3 game auto-play + record & replay for Android.

- Package: `com.appforge.tappilot`
- minSdk 26 (Android 8), targetSdk 35. Game mode and screenshots need Android 11+.
- Kotlin + Jetpack Compose (Material 3), AGP 8.7.3, Gradle 8.11.1 wrapper, JDK 17.
- No server, no Firebase. AI uses the user's own free Gemini API key.

## Build
Push this folder (zipped) through the "Universal ZIP to APK" workflow, or locally:
```
./gradlew assembleRelease      # APK
./gradlew bundleRelease        # AAB for Play
```

## First run on the phone
1. Open TapPilot → **Turn on** → agree → Accessibility → TapPilot Assistant → On.
   If the switch is greyed out ("Restricted setting", sideloaded APK on Android 13+):
   App info → ⋮ → **Allow restricted settings**, then turn it on.
2. Settings → paste a free key from https://aistudio.google.com/apikey → Save.
3. Agent tab: type or speak (हिंदी / English) and tap Run.

## Features
- **Agent** (`agent/`): reads the screen (accessibility tree + screenshot), asks Gemini for one
  action at a time (tap / type / scroll / open app / back / done), step limit, request pacing for free keys.
- **Game mode** (`game/`) — v1.1 auto-detect:
  - `GameDetector`: one Gemini look per game → type (match-3 / chess / other), board box, rows/cols,
    goal, rules. The grid is then fine-tuned on the phone (`BoardReader.refine`) and saved.
  - Board finding (`BoardReader.findBoard`, v1.1.4+): finds candy blobs, measures the cell size from
    neighbouring candies and builds the grid from their positions, so boards with gaps and odd shapes
    work. Runs on the phone in a few milliseconds, no Gemini needed to start playing.
  - Match-3 (`Match3Runner`): colour reading (handles ring candies, ignores flat background),
    solver 5 → T/L → 4 → 3, goal cells (ice/jelly) refreshed by Gemini every 8 moves and prioritised,
    skips moves that do nothing and re-aligns the grid if moves keep failing.
  - Chess vs computer (`chess/`): full rules (perft-verified), built-in alpha-beta engine,
    sees pieces by square detail (no shape recognition) and infers the opponent's move from legal moves;
    reads mid-game positions with Gemini. Optional Stockfish: put the Android arm64 binary at
    `app/src/main/jniLibs/arm64-v8a/libstockfish.so` and it is used automatically.
  - General AI (`GeneralRunner`): Gemini decides each move for other turn-based games (slow).
  - Ads/popups/next level via `PopupHandler`; human-like mode with breaks; refuses live matches vs real people.
- **Record & replay** (`record/`): records taps/long-presses/swipes and replays 1×, 5× or in a loop.
- **Safety** (`service/SafetyGuard.kt`): floating Stop button, blocks banking/UPI/wallet/broker apps,
  OTP/PIN/password screens, never taps Pay/Buy/Subscribe/price buttons.

## Advanced automation behavior

This build adds a stronger autonomous control layer while keeping the safety boundaries above:

- Every gesture, accessibility click, and text-entry action performs a fresh sensitive-screen check
  immediately before dispatch. This protects against fast screen transitions that occur between
  accessibility events.
- Coordinates are clamped to the current display bounds before a gesture is sent, reducing failures
  on devices with cutouts, navigation bars, or unusual display sizes.
- Game mode automatically tries the local board detector first, then Gemini detection when needed,
  remembers the detected profile per package, re-fits changed boards, handles popups and level
  transitions, and returns to the game if it is temporarily covered by another non-sensitive app.
- If a game or automation run enters a blocked app or sensitive screen, the run stops immediately
  rather than navigating through it.
- Recording overlays are discarded without saving if Android disconnects the accessibility service.
- Universal agent tasks now start with a structured high-level plan, then use an observe → act →
  verify loop. After every action it compares the new accessibility state with the previous state,
  reports progress or no-progress to the planner, and asks for recovery rather than blindly repeating.
- The planner has explicit completion signals and safe-task rules. A failed or malformed model action
  remains local and cannot directly dispatch an unrecognized command.
- On-device ML Kit OCR (Latin and Devanagari) supplements accessibility data on canvas and WebView
  screens, without sending the OCR operation to a remote server.
- Common-app capability hints improve verification strategy for messaging, video search, browsers,
  alarms, settings, mail, and app stores. A bounded persistent trace keeps recent plan/policy/
  verification events for diagnostics without storing full screenshots or API keys.

TapPilot is intentionally not an unrestricted “do anything” bot. It will not automate payments,
banking, OTP/PIN/password entry, destructive account actions, or live matches against real people.
Screen-recognition automation can still fail on custom-rendered interfaces, so important actions
should be supervised and the floating Stop button should remain available.

## Play Store notes
Google Play restricts the Accessibility API. For this app you must:
- Fill the **Accessibility API declaration** in Play Console (explain the automation use, add a short video).
- Keep the in-app prominent disclosure (already shown before opening Accessibility settings).
- Add a privacy policy saying screen content is sent to Google Gemini only with the user's own key.
Expect a stricter review than usual; a rejection is possible for non-accessibility automation apps.
