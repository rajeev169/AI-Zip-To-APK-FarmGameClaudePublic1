package com.appforge.tappilot.agent

import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.PilotService
import com.appforge.tappilot.service.SafetyGuard
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject

/**
 * The AI phone agent: look at the screen → ask Gemini for the next step → do it → repeat,
 * until the task is done, the step limit is reached, or a safety rule stops it.
 */
class AgentRunner(private val svc: PilotService, private val task: String) {

    private data class TaskPlan(
        val objective: String,
        val steps: List<String>,
        val completionSignals: List<String>
    ) {
        fun asPrompt(): String = buildString {
            append("OBJECTIVE: ").append(objective).append('\n')
            if (steps.isNotEmpty()) {
                append("HIGH-LEVEL PLAN:\n")
                steps.forEachIndexed { i, step -> append(i + 1).append(". ").append(step).append('\n') }
            }
            if (completionSignals.isNotEmpty()) {
                append("SUCCESS SIGNALS: ").append(completionSignals.joinToString("; ")).append('\n')
            }
        }
    }

    private val history = mutableListOf<String>()
    private var plan = TaskPlan(task, emptyList(), emptyList())
    private var lastVerification = "No action has been taken yet."

    /** Words the agent may use only when the user's own command contains them. */
    private val allowIfAsked = listOf("install", "uninstall", "delete account", "factory reset")

    suspend fun run(): String {
        val limit = Prefs.stepLimit
        svc.status("Starting… going to the home screen")
        svc.home()
        delay(900)
        // The plan is a helpful extra, never a blocker: give it at most 15 seconds
        plan = withTimeoutOrNull(15_000) { createPlan() } ?: TaskPlan(task, emptyList(), emptyList())
        svc.status("Plan ready: ${plan.steps.size.coerceAtMost(6)} high-level steps")
        Prefs.recordRunEvent("plan", "task started; ${plan.steps.size} planned steps")

        var sameActionCount = 0
        var lastActionKey = ""

        for (step in 1..limit) {
            delay(700) // let the screen settle
            val root = svc.rootInActiveWindow
            val pkg = root?.packageName?.toString() ?: svc.currentPackage
            SafetyGuard.check(root, pkg)?.let { reason ->
                svc.stopAll(reason, blocked = true)
                return reason
            }

            val (w, h) = svc.screenSize()
            val snap = ScreenReader.read(root, w, h)
            val shot = if (Prefs.useScreenshots && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) svc.screenshot() else null
            val ocrText = if (shot != null && snap.elements.size < 18) {
                try {
                    OcrReader.format(OcrReader.read(shot, Prefs.voiceLang.startsWith("hi")), w, h)
                } catch (_: Exception) {
                    "(OCR unavailable)"
                }
            } else ""

            svc.status("Step $step/$limit: thinking…")
            val user = buildString {
                append("TASK: ").append(task).append("\n\n")
                append(plan.asPrompt()).append('\n')
                append("Step ").append(step).append(" of at most ").append(limit).append(".\n")
                append("Current app package: ").append(pkg ?: "unknown").append("\n")
                AppCapabilities.forPackage(pkg)?.let { hint ->
                    append("APP CAPABILITY HINT (").append(hint.family).append("): ")
                        .append(hint.guidance).append('\n')
                }
                if (history.isNotEmpty()) {
                    append("\nWhat you already did (oldest first):\n")
                    history.takeLast(10).forEach { append("- ").append(it).append('\n') }
                }
                if (sameActionCount >= 2) {
                    append("\nWARNING: you repeated the same action several times without progress. Try something different, or finish with fail.\n")
                }
                append("\nSCREEN ELEMENTS (id, type, label, @x,y on a 0-1000 scale):\n")
                append(snap.text)
                if (ocrText.isNotBlank()) append("\nOCR TEXT (on-device, for canvas/WebView screens):\n").append(ocrText)
                append("\nLAST ACTION VERIFICATION: ").append(lastVerification).append('\n')
                if (shot != null) append("\nA screenshot of the current screen is attached.\n")
                append("\nReply with ONE JSON object for the next action.")
            }

            val reply = GeminiClient.generate(SYSTEM_PROMPT, user, shot, json = true)
            val act = try {
                GeminiClient.parseJson(reply)
            } catch (e: Exception) {
                history.add("(reply not understood)")
                continue
            }

            val action = act.optString("action").lowercase().trim()
            val invalidAction = validateAction(action, act)
            if (invalidAction != null) {
                val problem = invalidAction
                lastVerification = "INVALID ACTION: $problem"
                history.add("model action rejected → $problem")
                Prefs.recordRunEvent("policy", "model action rejected: $problem")
                continue
            }
            val thought = act.optString("thought").take(120)
            if (thought.isNotBlank()) svc.status("Step $step: $thought")

            val key = action + act.optInt("id", -1) + act.optString("text") + act.optInt("x", -1) + act.optInt("y", -1)
            sameActionCount = if (key == lastActionKey) sameActionCount + 1 else 0
            lastActionKey = key
            if (sameActionCount >= 4) return "Stopped: the agent got stuck repeating the same step."

            val beforeFingerprint = fingerprint(pkg, snap)
            val result = execute(action, act, snap, w, h)
            delay(if (action == "wait") 120L else 500L)
            val afterRoot = svc.rootInActiveWindow
            val afterPkg = afterRoot?.packageName?.toString() ?: svc.foregroundPackage()
            val afterSnap = ScreenReader.read(afterRoot, w, h)
            lastVerification = verify(action, result, beforeFingerprint, fingerprint(afterPkg, afterSnap), afterPkg)
            history.add(describe(action, act, snap) + " → " + result + " → " + lastVerification)
            Prefs.recordRunEvent("verify", "$action: $lastVerification")

            when (result) {
                RESULT_DONE -> return act.optString("message").ifBlank { "Task finished" }
                RESULT_FAIL -> return "Could not finish: " + act.optString("message").ifBlank { "the agent gave up" }
                RESULT_BLOCKED -> return "Stopped: the next step was a payment/purchase or risky button. Please do that part yourself."
            }
        }
        return "Reached the step limit ($limit). Increase it in Settings if the task needs more steps."
    }

    private fun fingerprint(pkg: String?, snap: ScreenReader.Snapshot): String =
        (pkg.orEmpty() + "|" + snap.text).hashCode().toString()

    private fun validateAction(action: String, a: JSONObject): String? = when (action) {
        "tap", "long_press" -> if (
            !a.has("id") && (!a.has("x") || !a.has("y") ||
                a.optInt("x", -1) !in 0..1000 || a.optInt("y", -1) !in 0..1000)
        ) "tap needs a valid element id or x/y in 0..1000" else null
        "type" -> if (a.optString("text").isEmpty()) "type needs non-empty text" else null
        "scroll" -> if (a.optString("direction") !in setOf("up", "down", "left", "right"))
            "scroll direction is invalid" else null
        "swipe" -> if (listOf("x1", "y1", "x2", "y2").any { a.optInt(it, -1) !in 0..1000 })
            "swipe coordinates must be in 0..1000" else null
        "open_app" -> if (a.optString("app").isBlank()) "open_app needs an app name" else null
        "back", "home", "recents", "notifications", "wait", "done", "fail" -> null
        else -> "unknown action '$action'"
    }

    private fun verify(
        action: String,
        result: String,
        before: String,
        after: String,
        afterPkg: String?
    ): String {
        if (result.startsWith("failed")) return "FAILED: $result; choose a different target or recovery action."
        if (action == "done" || action == "fail") return "Terminal action accepted."
        if (action == "open_app") {
            return if (afterPkg != null && afterPkg != svc.packageName) {
                "Verified app transition to $afterPkg."
            } else {
                "No app transition observed; the requested app may not have opened."
            }
        }
        if (action == "wait") return "Wait completed; inspect the new screen."
        return if (before != after) {
            "Screen changed after $action; inspect the new state before continuing."
        } else {
            "NO PROGRESS detected after $action; recover, retry a different target, or report failure."
        }
    }

    private suspend fun createPlan(): TaskPlan {
        return try {
            val reply = GeminiClient.generate(
                "You are a task planner for an Android automation agent. Make a short, safe, " +
                    "observable plan. Never include payment, credential, OTP, PIN, destructive, or " +
                    "unsolicited messaging actions. Reply with JSON only.",
                "Create a plan for this user task: $task. Reply {\"objective\":\"...\", " +
                    "\"steps\":[\"...\"], \"completion_signals\":[\"...\"]}. Use 2-8 short steps.",
                json = true
            ).let { GeminiClient.parseJson(it) }
            val steps = reply.optJSONArray("steps")?.let { a ->
                (0 until a.length()).mapNotNull { i -> a.optString(i).takeIf { it.isNotBlank() } }.take(8)
            } ?: emptyList()
            val signals = reply.optJSONArray("completion_signals")?.let { a ->
                (0 until a.length()).mapNotNull { i -> a.optString(i).takeIf { it.isNotBlank() } }.take(6)
            } ?: emptyList()
            TaskPlan(reply.optString("objective", task).take(240), steps, signals)
        } catch (_: Exception) {
            TaskPlan(task, emptyList(), emptyList())
        }
    }

    private fun describe(action: String, a: JSONObject, snap: ScreenReader.Snapshot): String {
        val id = a.optInt("id", -1)
        val el = snap.elements.firstOrNull { it.id == id }
        return when (action) {
            "tap", "long_press" -> if (el != null) "$action [$id] \"${el.label}\"" else "$action at ${a.optInt("x")},${a.optInt("y")}"
            "type" -> "type \"${a.optString("text").take(40)}\"" + if (el != null) " into [$id]" else ""
            "open_app" -> "open_app ${a.optString("app")}"
            "scroll" -> "scroll ${a.optString("direction")}"
            "wait" -> "wait ${a.optInt("seconds", 2)}s"
            else -> action
        }
    }

    private fun riskyFor(label: String?): Boolean {
        if (label.isNullOrBlank()) return false
        if (!SafetyGuard.isDangerousLabel(label)) return false
        val l = label.lowercase()
        val t = task.lowercase()
        // Install/uninstall-style buttons are fine when the user asked for exactly that
        val allowed = allowIfAsked.any { w -> l.contains(w) && t.contains(w) }
        return !allowed
    }

    private suspend fun execute(
        action: String,
        a: JSONObject,
        snap: ScreenReader.Snapshot,
        w: Int,
        h: Int
    ): String {
        val el = snap.elements.firstOrNull { it.id == a.optInt("id", -1) }
        fun px(v: Int, size: Int): Float = (v.coerceIn(0, 1000) / 1000f) * size

        return when (action) {
            "tap", "long_press" -> {
                if (el != null) {
                    if (riskyFor(el.label)) return RESULT_BLOCKED
                    val ok = if (action == "tap") svc.clickNode(el.node)
                    else svc.longPress(el.bounds.exactCenterX(), el.bounds.exactCenterY())
                    if (ok) "ok" else "failed"
                } else if (a.has("x") && a.has("y")) {
                    val x = px(a.optInt("x"), w)
                    val y = px(a.optInt("y"), h)
                    val ok = if (action == "tap") svc.tap(x, y) else svc.longPress(x, y)
                    if (ok) "ok" else "failed"
                } else "failed: no target"
            }

            "type" -> {
                val text = a.optString("text")
                val ok = if (el != null && el.editable) {
                    svc.clickNode(el.node)
                    delay(250)
                    svc.typeInto(el.node, text)
                } else {
                    svc.typeIntoFocused(text)
                }
                if (ok && a.optBoolean("submit", false)) {
                    delay(250)
                    pressEnter()
                }
                if (ok) "ok" else "failed: no text box focused"
            }

            "scroll" -> if (svc.scroll(a.optString("direction", "up"))) "ok" else "failed"

            "swipe" -> {
                val ok = svc.swipe(
                    px(a.optInt("x1"), w), px(a.optInt("y1"), h),
                    px(a.optInt("x2"), w), px(a.optInt("y2"), h), 350
                )
                if (ok) "ok" else "failed"
            }

            "open_app" -> {
                val app = a.optString("app")
                if (SafetyGuard.isBlockedPackage(app)) return RESULT_BLOCKED
                val pkg = svc.openApp(app)
                if (pkg != null) {
                    delay(1800)
                    "opened $pkg"
                } else "failed: app \"$app\" not found or not allowed"
            }

            "back" -> { svc.back(); "ok" }
            "home" -> { svc.home(); "ok" }
            "recents" -> { svc.recents(); "ok" }
            "notifications" -> { svc.notifications(); "ok" }
            "wait" -> { delay(a.optInt("seconds", 2).coerceIn(1, 10) * 1000L); "ok" }
            "done" -> RESULT_DONE
            "fail" -> RESULT_FAIL
            else -> "unknown action"
        }
    }

    private fun pressEnter() {
        val f = svc.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
    }

    companion object {
        private const val RESULT_DONE = "__done__"
        private const val RESULT_FAIL = "__fail__"
        private const val RESULT_BLOCKED = "__blocked__"

        private val SYSTEM_PROMPT = """
You are TapPilot, an assistant that operates an Android phone for its owner, one step at a time.
The owner may write in Hindi, English or Hinglish. Understand all of them.

Each turn you get the task, what you already did, a numbered list of screen elements and often a screenshot.
Choose exactly ONE next action and reply with a single JSON object:

{"thought": "<very short reason>", "action": "<action>", ...fields}

Actions:
- {"action":"tap","id":N}                    tap element N (preferred)
- {"action":"tap","x":X,"y":Y}               tap a point seen in the screenshot (0-1000 scale; 0,0 = top-left)
- {"action":"long_press","id":N} or with x,y
- {"action":"type","id":N,"text":"...","submit":false}   type into a TextBox (omit id to use the focused box). submit=true presses Enter/Search.
- {"action":"scroll","direction":"up|down|left|right"}   "up" moves the page content up to reveal more below
- {"action":"swipe","x1":..,"y1":..,"x2":..,"y2":..}
- {"action":"open_app","app":"<app name>"}   open an installed app by name (fastest way to start)
- {"action":"back"} {"action":"home"} {"action":"recents"} {"action":"notifications"}
- {"action":"wait","seconds":2}             wait for loading
- {"action":"done","message":"<short result for the owner, in the owner's language>"}
- {"action":"fail","message":"<why it cannot be done>"}

Rules:
- Prefer element ids over x,y. Use x,y only for things missing from the list.
- Check the screen after each step; if something didn't work, try another way.
- Finish with "done" as soon as the task is complete. Answer questions (e.g. "what's the weather") in the done message.
- Use LAST ACTION VERIFICATION: when it says NO PROGRESS or FAILED, do not repeat blindly. Try a different
  element, dismiss a blocker, scroll, wait for loading, or go back and recover. Confirm important state
  changes from the next screen before declaring success.
- NEVER pay, buy, purchase, subscribe, recharge, transfer or send money, or confirm any order. If the task needs that, prepare everything and stop with "fail" saying the owner must complete payment personally.
- NEVER type or read passwords, OTPs, PINs or card details. Never change security settings.
- Never delete data, uninstall apps, or send messages/emails/posts to anyone the owner did not clearly ask for.
- Dismiss pop-ups, ads and permission dialogs sensibly (allow only what the task needs).
""".trimIndent()
    }
}
