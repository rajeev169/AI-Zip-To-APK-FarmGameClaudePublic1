package com.appforge.tappilot.agent

/** Local hints for common app families; actions still use the live screen and safety policy. */
object AppCapabilities {
    data class Hint(val family: String, val guidance: String)

    fun forPackage(pkg: String?): Hint? {
        val p = pkg?.lowercase().orEmpty()
        return when {
            "whatsapp" in p -> Hint("messaging", "Verify the conversation title and recipient before typing; after send, verify the outgoing bubble.")
            "youtube" in p -> Hint("video", "Use the search field, submit, then verify the results screen contains the requested query.")
            "chrome" in p || "browser" in p -> Hint("browser", "Prefer the address/search field; after navigation verify the page title or URL changed.")
            "alarm" in p || "clock" in p -> Hint("clock", "After saving, verify the alarm row and time are visible; do not alter existing alarms without confirmation.")
            "settings" in p -> Hint("settings", "Treat security, account, accessibility, and reset settings as takeover-required.")
            "gmail" in p || "mail" in p -> Hint("mail", "Verify account and recipient before composing; never send without explicit user authorization.")
            "play" in p && "store" in p -> Hint("store", "Search is allowed, but installation, purchase, subscription, and account changes require user takeover.")
            else -> null
        }
    }
}
