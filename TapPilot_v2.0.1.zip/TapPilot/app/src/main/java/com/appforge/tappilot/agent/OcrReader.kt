package com.appforge.tappilot.agent

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import kotlinx.coroutines.tasks.await

/** On-device OCR used to recover text from canvas/WebView/custom-rendered screens. */
object OcrReader {
    data class Line(val text: String, val bounds: Rect?)

    suspend fun read(bitmap: Bitmap, devanagari: Boolean = false): List<Line> {
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = if (devanagari) {
            TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        } else {
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
        return try {
            val result = recognizer.process(image).await()
            result.textBlocks.flatMap { block ->
                if (block.lines.isEmpty()) listOf(Line(block.text, block.boundingBox))
                else block.lines.map { line -> Line(line.text, line.boundingBox) }
            }.filter { it.text.isNotBlank() }
        } finally {
            recognizer.close()
        }
    }

    fun format(lines: List<Line>, width: Int, height: Int): String = buildString {
        lines.take(160).forEachIndexed { index, line ->
            val r = line.bounds
            val position = if (r == null) "" else {
                " @${r.centerX() * 1000 / width.coerceAtLeast(1)},${r.centerY() * 1000 / height.coerceAtLeast(1)}"
            }
            append("[OCR ").append(index + 1).append("] ")
                .append(line.text.replace('\n', ' ')).append(position).append('\n')
        }
    }
}
