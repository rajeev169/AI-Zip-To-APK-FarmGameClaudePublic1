package com.appforge.tappilot.game

import com.appforge.tappilot.data.Prefs
import com.appforge.tappilot.service.PilotService
import com.appforge.tappilot.service.SafetyGuard
import kotlinx.coroutines.delay
import kotlin.random.Random

/** Thrown to end a game run with a message for the user. */
class StopGame(message: String) : Exception(message)

/** Things every game mode needs: staying inside the game and human-like breaks. */
class GameGuard(private val svc: PilotService, private val gamePkg: String) {

    val human = Prefs.humanMode
    private var offApp = 0
    private var playStart = System.currentTimeMillis()
    private var nextBreakAfter = randomBreakGap()

    /** Returns true when the game is in front and ready; false means "try again shortly". */
    suspend fun ensureInGame(): Boolean {
        if (human && System.currentTimeMillis() - playStart > nextBreakAfter) {
            val mins = Random.nextInt(2, 6)
            svc.status("Taking a $mins-minute break (human mode)…")
            delay(mins * 60_000L)
            playStart = System.currentTimeMillis()
            nextBreakAfter = randomBreakGap()
        }
        val fg = svc.foregroundPackage()
        SafetyGuard.check(svc.rootInActiveWindow, fg)?.let { reason ->
            svc.stopAll(reason, blocked = true)
            return false
        }
        if (fg != null && fg != gamePkg) {
            if (fg == "com.android.systemui") { delay(1500); return false }
            offApp++
            if (offApp > 12) throw StopGame("Couldn't get back to the game. Stopped.")
            svc.status("Left the game ($fg). Going back…")
            if (offApp % 3 == 0) svc.launchPackage(gamePkg) else svc.back()
            delay(2500)
            return false
        }
        offApp = 0
        return true
    }

    /** Pause after a move: quick in fast mode, varied in human mode. */
    suspend fun afterMove(fastMs: Long, humanMin: Long, humanMax: Long) {
        delay(if (human) Random.nextLong(humanMin, humanMax) else fastMs)
    }

    private fun randomBreakGap(): Long = Random.nextLong(18, 31) * 60_000L
}
