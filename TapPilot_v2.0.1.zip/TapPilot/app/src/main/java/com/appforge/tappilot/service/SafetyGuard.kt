package com.appforge.tappilot.service

import android.view.accessibility.AccessibilityNodeInfo

/**
 * Stops TapPilot on banking, UPI, payment, OTP and password screens.
 * Returns a reason string when the current screen must not be touched.
 */
object SafetyGuard {

    private val blockedPackages = setOf(
        // UPI & wallets
        "com.google.android.apps.nbu.paisa.user", // Google Pay
        "net.one97.paytm",                        // Paytm
        "com.phonepe.app",                        // PhonePe
        "in.org.npci.upiapp",                     // BHIM
        "in.amazon.mShop.android.shopping.pay",
        "com.mobikwik_new",
        "com.freecharge.android",
        "money.super.payments",                   // super.money
        "com.dreamplug.androidapp",               // CRED
        "com.whatsapp.payments",
        // Banks
        "com.sbi.lotusintouch",                   // YONO SBI
        "com.sbi.SBIFreedomPlus",
        "com.sbi.upi",
        "com.snapwork.hdfc",                      // HDFC
        "com.hdfcbank.payzapp",
        "com.csam.icici.bank.imobile",            // ICICI
        "com.axis.mobile",                        // Axis
        "com.msf.kbank.mobile",                   // Kotak
        "com.bankofbaroda.mconnect",
        "com.baroda.barobank",
        "com.infrasofttech.indianBank",
        "com.pnb.pnbone",                         // PNB ONE
        "com.unionbank.ecommerce.mobile.android",
        "com.canarabank.mobility",
        "com.indusind.indie",
        "com.idfcfirstbank.optimus",
        "com.yesbank",
        "com.fss.pnbpsp",
        "com.boi.mpay",
        "com.ucobank.ucoapp",
        "com.centralbank.cbsmart",
        "com.lcode.apgvbmobilebanking",
        "com.dbs.in.digitalbank",
        "com.fampay.in",
        // Brokers & trading
        "com.zerodha.kite3",
        "com.nextbillion.groww",
        "com.msf.angelmobile",
        "com.upstox.pro",
        "com.dhan.live",
        // System security screens
        "com.android.settings.biometrics"
    )

    /** Package fragments that look like banking/payment apps we don't list by name. */
    private val blockedPackageHints = listOf("bank", ".upi", "upiapp", "payments", "wallet", "netbanking")

    private val blockedPhrases = listOf(
        "otp", "one time password", "one-time password", "verification code",
        "upi pin", "enter pin", "enter your pin", "mpin", "m-pin", "atm pin", "cvv",
        "card number", "net banking", "internet banking", "transaction password",
        "passcode", "security code", "security question", "transaction pin",
        "ओटीपी", "यूपीआई पिन", "पिन दर्ज"
    )

    fun isBlockedPackage(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        if (pkg in blockedPackages) return true
        val p = pkg.lowercase()
        return blockedPackageHints.any { p.contains(it) }
    }

    /** Checks the whole visible screen. Returns a reason, or null when it is safe. */
    fun check(root: AccessibilityNodeInfo?, pkg: String?): String? {
        if (isBlockedPackage(pkg)) return "Banking/payment app is open ($pkg). TapPilot never acts there."
        if (root == null) return null
        var visited = 0
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        while (stack.isNotEmpty() && visited < 600) {
            val n = stack.removeLast()
            visited++
            if (n.isPassword) return "A password field is on screen. TapPilot stopped for your safety."
            val text = (n.text?.toString().orEmpty() + " " + n.contentDescription?.toString().orEmpty()).lowercase()
            if (text.isNotBlank() && text.length < 200) {
                val hit = blockedPhrases.firstOrNull { phrase -> containsWord(text, phrase) }
                if (hit != null) return "OTP / PIN / banking screen detected (\"$hit\"). TapPilot stopped for your safety."
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                stack.addLast(c)
            }
        }
        return null
    }

    /**
     * Fast pre-action check. Accessibility events can lag behind the visible screen,
     * so checking only from onAccessibilityEvent is not sufficient.
     */
    fun beforeAction(root: AccessibilityNodeInfo?, pkg: String?): String? = check(root, pkg)

    /** Word-ish match so "otp" doesn't trigger on words like "hotpot". */
    fun containsWord(text: String, phrase: String): Boolean {
        var idx = text.indexOf(phrase)
        while (idx >= 0) {
            val before = if (idx == 0) ' ' else text[idx - 1]
            val afterIdx = idx + phrase.length
            val after = if (afterIdx >= text.length) ' ' else text[afterIdx]
            if (!before.isLetterOrDigit() && !after.isLetterOrDigit()) return true
            idx = text.indexOf(phrase, idx + 1)
        }
        return false
    }

    /** Words in a button that the agent and game mode must never tap. */
    val dangerousButtonWords = listOf(
        "pay", "buy", "purchase", "subscribe", "install", "₹", "$", "rs.", "checkout",
        "place order", "confirm payment", "send money", "transfer", "delete account",
        "uninstall", "factory reset"
    )

    fun isDangerousLabel(label: String?): Boolean {
        if (label.isNullOrBlank()) return false
        val l = label.lowercase()
        return dangerousButtonWords.any { w ->
            if (w.length <= 2 || !w.first().isLetter()) l.contains(w) else containsWord(l, w)
        }
    }
}
