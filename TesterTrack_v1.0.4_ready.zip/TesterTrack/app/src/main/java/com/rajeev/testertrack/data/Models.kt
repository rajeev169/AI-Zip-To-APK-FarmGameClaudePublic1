package com.rajeev.testertrack.data

import com.google.firebase.firestore.DocumentSnapshot
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Role {
    const val ADMIN = "admin"
    const val MEMBER = "member"
}

object TaskStatus {
    const val PENDING = "pending"   // बाकी
    const val WORKING = "working"   // चालू
    const val DONE = "done"         // पूरे

    fun label(s: String) = when (s) {
        DONE -> tr("पूरा", "Done")
        WORKING -> tr("चालू", "Working")
        else -> tr("बाकी", "Pending")
    }
}

data class UserProfile(
    val uid: String,
    val name: String,
    val email: String,
    val photo: String,
    val role: String,
    val teamId: String,
    val consentAt: Long,
)

data class TrackedApp(val name: String, val pkg: String)

data class Team(
    val id: String,
    val name: String,
    val adminUid: String,
    val adminName: String,
    val apps: List<TrackedApp>,
)

data class Member(
    val uid: String,
    val name: String,
    val email: String,
    val photo: String,
    val onDuty: Boolean,
    val dutyStart: Long,
    val sessionId: String,
    val lastSeen: Long,
)

data class Invite(val email: String, val name: String, val teamId: String)

data class WorkTask(
    val id: String,
    val title: String,
    val appName: String,
    val note: String,
    val assigneeUid: String,
    val assigneeName: String,
    val status: String,
    val createdAt: Long,
    val startedAt: Long,
    val doneAt: Long,
)

data class Session(
    val id: String,
    val uid: String,
    val name: String,
    val start: Long,
    val end: Long,     // 0 while running
    val date: String,
) {
    fun durationMs(now: Long = System.currentTimeMillis()): Long =
        ((if (end > 0) end else now) - start).coerceAtLeast(0)
}

/** usage/{uid_date}: sessions -> (encoded pkg -> millis) */
data class UsageDay(
    val uid: String,
    val date: String,
    val sessions: Map<String, Map<String, Long>>,
) {
    /** pkg -> total millis for the day */
    fun perApp(): Map<String, Long> {
        val out = HashMap<String, Long>()
        sessions.values.forEach { m ->
            m.forEach { (k, v) -> val p = decodePkg(k); out[p] = (out[p] ?: 0L) + v }
        }
        return out
    }
}

fun encodePkg(p: String) = p.replace('.', ',')
fun decodePkg(p: String) = p.replace(',', '.')

// ---------- mapping ----------

fun DocumentSnapshot.toUser(): UserProfile = UserProfile(
    uid = id,
    name = getString("name") ?: "",
    email = getString("email") ?: "",
    photo = getString("photo") ?: "",
    role = getString("role") ?: "",
    teamId = getString("teamId") ?: "",
    consentAt = getLong("consentAt") ?: 0L,
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toTeam(): Team {
    val raw = get("apps") as? List<Map<String, Any?>> ?: emptyList()
    return Team(
        id = id,
        name = getString("name") ?: "",
        adminUid = getString("adminUid") ?: "",
        adminName = getString("adminName") ?: "",
        apps = raw.map { TrackedApp(it["name"] as? String ?: "", it["pkg"] as? String ?: "") }
            .filter { it.pkg.isNotBlank() },
    )
}

fun DocumentSnapshot.toMember(): Member = Member(
    uid = id,
    name = getString("name") ?: "",
    email = getString("email") ?: "",
    photo = getString("photo") ?: "",
    onDuty = getBoolean("onDuty") ?: false,
    dutyStart = getLong("dutyStart") ?: 0L,
    sessionId = getString("sessionId") ?: "",
    lastSeen = getLong("lastSeen") ?: 0L,
)

fun DocumentSnapshot.toInvite(): Invite = Invite(
    email = id,
    name = getString("name") ?: "",
    teamId = getString("teamId") ?: "",
)

fun DocumentSnapshot.toTask(): WorkTask = WorkTask(
    id = id,
    title = getString("title") ?: "",
    appName = getString("appName") ?: "",
    note = getString("note") ?: "",
    assigneeUid = getString("assigneeUid") ?: "",
    assigneeName = getString("assigneeName") ?: "",
    status = getString("status") ?: TaskStatus.PENDING,
    createdAt = getLong("createdAt") ?: 0L,
    startedAt = getLong("startedAt") ?: 0L,
    doneAt = getLong("doneAt") ?: 0L,
)

fun DocumentSnapshot.toSession(): Session = Session(
    id = id,
    uid = getString("uid") ?: "",
    name = getString("name") ?: "",
    start = getLong("start") ?: 0L,
    end = getLong("end") ?: 0L,
    date = getString("date") ?: "",
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toUsage(): UsageDay {
    val raw = get("sessions") as? Map<String, Map<String, Any?>> ?: emptyMap()
    return UsageDay(
        uid = getString("uid") ?: "",
        date = getString("date") ?: "",
        sessions = raw.mapValues { (_, m) -> m.mapValues { (it.value as? Number)?.toLong() ?: 0L } },
    )
}

// ---------- date / time helpers ----------

object Dates {
    private fun fmt(p: String) = SimpleDateFormat(p, Locale.ENGLISH)

    fun dayKey(t: Long = System.currentTimeMillis()): String = fmt("yyyy-MM-dd").format(Date(t))

    fun daysAgoKey(n: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -n)
        return dayKey(c.timeInMillis)
    }

    fun time(t: Long): String = if (t <= 0) "" else fmt("h:mm a").format(Date(t))
    fun dateTime(t: Long): String = if (t <= 0) "" else fmt("d MMM, h:mm a").format(Date(t))

    fun dayLabel(key: String): String {
        if (key == dayKey()) return tr("आज", "Today")
        if (key == daysAgoKey(1)) return tr("कल", "Yesterday")
        return try {
            val d = fmt("yyyy-MM-dd").parse(key)
            if (d == null) key else fmt("EEE, d MMM").format(d)
        } catch (e: Exception) { key }
    }

    /** e.g. "5 घंटे 20 मिनट" */
    fun hoursLong(ms: Long): String {
        val totalMin = ms / 60000
        val h = totalMin / 60
        val m = totalMin % 60
        return when {
            h == 0L -> tr("$m मिनट", "$m min")
            m == 0L -> tr("$h घंटे", "$h hr")
            else -> tr("$h घंटे $m मिनट", "$h hr $m min")
        }
    }

    /** e.g. "5 घं 20 मि" */
    fun hoursShort(ms: Long): String {
        val totalMin = ms / 60000
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h == 0L) tr("$m मि", "$m m") else tr("$h घं $m मि", "$h h $m m")
    }
}
