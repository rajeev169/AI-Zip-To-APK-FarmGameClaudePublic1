package com.rajeev.testertrack.tracking

import com.rajeev.testertrack.data.tr
import android.Manifest
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.rajeev.testertrack.MainActivity
import com.rajeev.testertrack.R
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.UserProfile
import java.util.concurrent.TimeUnit

/** Small local store so the background worker knows the running duty session. */
object DutyPrefs {
    private const val FILE = "duty"
    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun save(c: Context, teamId: String, uid: String, sessionId: String, start: Long) {
        p(c).edit().putString("teamId", teamId).putString("uid", uid)
            .putString("sessionId", sessionId).putLong("start", start).apply()
    }

    fun clear(c: Context) {
        p(c).edit().remove("teamId").remove("uid").remove("sessionId").remove("start").apply()
    }

    fun sessionId(c: Context) = p(c).getString("sessionId", "") ?: ""
    fun teamId(c: Context) = p(c).getString("teamId", "") ?: ""
    fun uid(c: Context) = p(c).getString("uid", "") ?: ""
    fun start(c: Context) = p(c).getLong("start", 0L)

    fun setPackages(c: Context, pkgs: Set<String>) {
        p(c).edit().putStringSet("pkgs", pkgs).apply()
    }

    fun packages(c: Context): Set<String> = p(c).getStringSet("pkgs", emptySet()) ?: emptySet()
}

object UsageAccess {
    // Raw event codes (ACTIVITY_RESUMED=1, ACTIVITY_PAUSED=2, ACTIVITY_STOPPED=23) so this works on Android 8+
    private const val EV_RESUMED = 1
    private const val EV_PAUSED = 2
    private const val EV_STOPPED = 23

    fun granted(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openSettings(c: Context) {
        val i = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.startActivity(i) } catch (_: Exception) {
            c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /**
     * Foreground time (ms) per package between [from] and [to], counted ONLY for [pkgs]
     * (the admin's own apps). Nothing else on the phone is read or uploaded.
     */
    fun measure(c: Context, from: Long, to: Long, pkgs: Set<String>): Map<String, Long> {
        if (pkgs.isEmpty() || !granted(c) || to <= from) return emptyMap()
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(from, to)
        val openSince = HashMap<String, Long>()
        val total = HashMap<String, Long>()
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            if (pkg !in pkgs) continue
            when (e.eventType) {
                EV_RESUMED -> openSince[pkg] = e.timeStamp
                EV_PAUSED, EV_STOPPED -> {
                    val s = openSince.remove(pkg)
                    if (s != null) total[pkg] = (total[pkg] ?: 0L) + (e.timeStamp - s).coerceAtLeast(0)
                }
            }
        }
        // still open at the end of the window
        openSince.forEach { (pkg, s) -> total[pkg] = (total[pkg] ?: 0L) + (to - s).coerceAtLeast(0) }
        return total.filterValues { it > 0 }
    }
}

object DutyNotice {
    const val CHANNEL = "duty"
    private const val ID = 7001

    fun createChannel(c: Context) {
        val ch = NotificationChannel(CHANNEL, tr("ड्यूटी स्थिति", "Duty status"), NotificationManager.IMPORTANCE_LOW).apply {
            description = tr("ड्यूटी चालू होने पर दिखता है", "Shown while duty is on")
        }
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    fun show(c: Context, start: Long) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(tr("ड्यूटी चालू है · ${Dates.time(start)} से", "On duty · since ${Dates.time(start)}"))
            .setContentText(tr("काम का समय और चुने गए ऐप्स का उपयोग गिना जा रहा है", "Work time and selected app usage are being counted"))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
        try { NotificationManagerCompat.from(c).notify(ID, n) } catch (_: SecurityException) {}
    }

    fun hide(c: Context) = NotificationManagerCompat.from(c).cancel(ID)
}

/** Every ~15 minutes while on duty: upload usage of the admin's apps for this session. */
class UsageWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        val sessionId = DutyPrefs.sessionId(c)
        if (sessionId.isBlank()) { Duty.cancelWorker(c); return Result.success() }
        return try {
            Duty.syncUsage(c)
            DutyNotice.show(c, DutyPrefs.start(c))
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object Duty {
    private const val WORK = "usage_sync"

    fun scheduleWorker(c: Context) {
        val req = PeriodicWorkRequestBuilder<UsageWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun cancelWorker(c: Context) = WorkManager.getInstance(c).cancelUniqueWork(WORK)

    suspend fun syncUsage(c: Context) {
        val sessionId = DutyPrefs.sessionId(c)
        val teamId = DutyPrefs.teamId(c)
        val uid = DutyPrefs.uid(c)
        val start = DutyPrefs.start(c)
        if (sessionId.isBlank() || teamId.isBlank() || uid.isBlank()) return
        val now = System.currentTimeMillis()
        val usage = UsageAccess.measure(c, start, now, DutyPrefs.packages(c))
        Repo.writeUsage(teamId, uid, Dates.dayKey(start), sessionId, usage)
    }

    suspend fun start(c: Context, user: UserProfile) {
        val (sid, start) = Repo.startDuty(user)
        DutyPrefs.save(c, user.teamId, user.uid, sid, start)
        DutyNotice.show(c, start)
        scheduleWorker(c)
    }

    suspend fun stop(c: Context, user: UserProfile, sessionIdFromServer: String) {
        val sid = DutyPrefs.sessionId(c).ifBlank { sessionIdFromServer }
        try { if (DutyPrefs.sessionId(c).isNotBlank()) syncUsage(c) } catch (_: Exception) {}
        Repo.stopDuty(user.teamId, user.uid, sid)
        DutyPrefs.clear(c)
        DutyNotice.hide(c)
        cancelWorker(c)
    }

    /** Make local state match the server (e.g. after reinstall or a second phone). */
    fun restoreIfNeeded(c: Context, user: UserProfile, serverSessionId: String, serverStart: Long, onDuty: Boolean) {
        if (onDuty && serverSessionId.isNotBlank() && DutyPrefs.sessionId(c) != serverSessionId) {
            DutyPrefs.save(c, user.teamId, user.uid, serverSessionId, serverStart)
            DutyNotice.show(c, serverStart)
            scheduleWorker(c)
        } else if (!onDuty && DutyPrefs.sessionId(c).isNotBlank()) {
            DutyPrefs.clear(c)
            DutyNotice.hide(c)
            cancelWorker(c)
        }
    }
}
