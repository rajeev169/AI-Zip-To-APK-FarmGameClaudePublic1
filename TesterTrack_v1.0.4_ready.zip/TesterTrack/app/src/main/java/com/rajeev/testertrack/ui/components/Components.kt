package com.rajeev.testertrack.ui.components

import com.rajeev.testertrack.data.tr
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.testertrack.R
import com.rajeev.testertrack.ui.theme.InfoBlue
import com.rajeev.testertrack.ui.theme.InfoBlueInk
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.LogoBlue
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.theme.Tile

fun decodePhoto(b64: String): ImageBitmap? {
    if (b64.isBlank()) return null
    return try {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
    } catch (e: Exception) { null }
}

/** Profile photo in a circle. No photo -> app logo (header) or first letter (lists). */
@Composable
fun Avatar(photo: String, name: String, size: Dp, logoFallback: Boolean = false, onClick: (() -> Unit)? = null) {
    val bmp = remember(photo) { decodePhoto(photo) }
    val mod = Modifier.size(size).clip(CircleShape).let { if (onClick != null) it.clickable { onClick() } else it }
    when {
        bmp != null -> Image(bmp, contentDescription = name, contentScale = ContentScale.Crop, modifier = mod)
        logoFallback -> Box(mod.background(LogoBlue), contentAlignment = Alignment.Center) {
            Image(
                painterResource(R.drawable.ic_launcher_foreground), contentDescription = null,
                modifier = Modifier.size(size * 1.35f)
            )
        }
        else -> Box(mod.background(Tile), contentAlignment = Alignment.Center) {
            Text(
                (name.trim().firstOrNull() ?: '?').uppercase(),
                color = Purple, fontWeight = FontWeight.SemiBold, fontSize = (size.value * 0.42f).sp
            )
        }
    }
}

data class MenuEntry(val label: String, val onClick: () -> Unit)
data class Chip(val text: String, val solid: Boolean)
data class TileData(val label: String, val value: String, val valueColor: Color = Ink, val onClick: () -> Unit)

/**
 * Purple header + overlapping white summary card — same layout as Samuh Khata.
 */
@Composable
fun HeaderWithCard(
    teamName: String,
    userName: String,
    photo: String,
    chips: List<Chip>,
    menu: List<MenuEntry>,
    onAvatar: () -> Unit,
    onSettings: () -> Unit,
    cardTitle: String,
    cardValue: String,
    tiles: List<TileData>,
) {
    var headerH by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val purpleH = with(density) { headerH.toDp() } + 84.dp
    Box(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(purpleH).background(Purple))
        Column(Modifier.fillMaxWidth()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .onSizeChanged { headerH = it.height }
                    .statusBarsPadding()
                    .padding(start = 18.dp, end = 12.dp, top = 22.dp, bottom = 26.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(photo, userName, 60.dp, logoFallback = true, onClick = onAvatar)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(teamName, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            tr("नमस्ते, ${firstName(userName)}", "Hello, ${firstName(userName)}"), color = Color.White, fontSize = 27.sp,
                            fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    HeaderMenuButton(menu)
                    Spacer(Modifier.width(8.dp))
                    HeaderSquareButton(Icons.Filled.Settings, tr("सेटिंग्स", "Settings"), onSettings)
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    chips.forEach { c ->
                        Text(
                            c.text,
                            color = if (c.solid) Purple else Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (c.solid) Color.White else Color.White.copy(alpha = 0.18f))
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }
            SummaryCard(cardTitle, cardValue, tiles)
        }
    }
}

fun firstName(n: String) = n.trim().substringBefore(" ").ifBlank { n }

@Composable
private fun HeaderSquareButton(icon: ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(56.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.16f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(icon, desc, tint = Color.White, modifier = Modifier.size(28.dp)) }
}

@Composable
private fun HeaderMenuButton(items: List<MenuEntry>) {
    var open by remember { mutableStateOf(false) }
    Box {
        HeaderSquareButton(Icons.Filled.Menu, tr("मेनू", "Menu")) { open = true }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEach { m ->
                DropdownMenuItem(text = { Text(m.label) }, onClick = { open = false; m.onClick() })
            }
        }
    }
}

@Composable
fun SummaryCard(title: String, value: String, tiles: List<TileData>) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = Color.White,
        modifier = Modifier
            .padding(horizontal = 14.dp)
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(28.dp))
    ) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 16.dp)) {
            Text(title, color = Sub, fontSize = 17.sp, modifier = Modifier.padding(start = 16.dp))
            Spacer(Modifier.height(8.dp))
            Text(
                value, color = Ink, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(start = 16.dp), maxLines = 1
            )
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                tiles.forEach { t -> SmallTile(t) }
            }
        }
    }
}

@Composable
private fun RowScope.SmallTile(t: TileData) {
    Column(
        Modifier
            .weight(1f)
            .clip(RoundedCornerShape(20.dp))
            .background(Tile)
            .clickable { t.onClick() }
            .padding(horizontal = 14.dp, vertical = 14.dp)
    ) {
        Text("${t.label} ›", color = Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp))
        Text(t.value, color = t.valueColor, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun SectionCard(
    title: String,
    action: String? = null,
    onAction: (() -> Unit)? = null,
    trailing: String? = null,
    content: @Composable () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(28.dp), color = Color.White,
        modifier = Modifier.padding(horizontal = 14.dp).fillMaxWidth()
    ) {
        Column(Modifier.padding(vertical = 20.dp)) {
            Row(Modifier.padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.weight(1f))
                if (action != null && onAction != null) {
                    Text(
                        action, color = Purple, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { onAction() }.padding(6.dp)
                    )
                } else if (trailing != null) {
                    Text(trailing, color = Sub, fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun InfoBanner(icon: ImageVector, text: String, onClick: (() -> Unit)? = null) {
    Row(
        Modifier
            .padding(horizontal = 14.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(InfoBlue)
            .let { if (onClick != null) it.clickable { onClick() } else it }
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = InfoBlueInk, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(14.dp))
        Text(text, color = InfoBlueInk, fontSize = 15.sp, modifier = Modifier.weight(1f), lineHeight = 22.sp)
        if (onClick != null) Text("›", color = InfoBlueInk, fontSize = 26.sp, modifier = Modifier.padding(start = 8.dp))
    }
}

/** Purple bar with back button for inner screens. */
@Composable
fun SubTopBar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Purple)
            .statusBarsPadding()
            .padding(horizontal = 6.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("वापस", "Back"), tint = Color.White)
        }
        Text(
            title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        actions()
    }
}

@Composable
fun Pill(text: String, fg: Color, bg: Color) {
    Text(
        text, color = fg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 10.dp, vertical = 3.dp)
    )
}

@Composable
fun EmptyNote(text: String) {
    Text(text, color = Sub, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
}

/** हिंदी | English segmented switch. [onDark] = white style for the purple sign-in screen. */
@Composable
fun LanguageSwitch(onDark: Boolean = false) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (onDark) Color.White.copy(alpha = 0.12f) else Tile)
            .padding(3.dp)
    ) {
        listOf("hi" to "हिंदी", "en" to "English").forEach { (code, label) ->
            val sel = com.rajeev.testertrack.data.Lang.code == code
            Text(
                label,
                color = when {
                    sel && onDark -> Purple
                    sel -> Color.White
                    onDark -> Color.White
                    else -> Purple
                },
                fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) (if (onDark) Color.White else Purple) else Color.Transparent)
                    .clickable { com.rajeev.testertrack.data.Lang.set(ctx, code) }
                    .padding(horizontal = 16.dp, vertical = 7.dp)
            )
        }
    }
}
