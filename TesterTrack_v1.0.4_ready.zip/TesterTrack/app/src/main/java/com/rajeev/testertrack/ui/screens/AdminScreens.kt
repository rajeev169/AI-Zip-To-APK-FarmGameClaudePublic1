package com.rajeev.testertrack.ui.screens

import com.rajeev.testertrack.data.tr
import androidx.compose.foundation.clickable
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Invite
import com.rajeev.testertrack.data.Member
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.Session
import com.rajeev.testertrack.data.TaskStatus
import com.rajeev.testertrack.data.Team
import com.rajeev.testertrack.data.UsageDay
import com.rajeev.testertrack.data.UserProfile
import com.rajeev.testertrack.data.WorkTask
import com.rajeev.testertrack.ui.Runner
import com.rajeev.testertrack.ui.Screen
import com.rajeev.testertrack.ui.components.Avatar
import com.rajeev.testertrack.ui.components.Chip
import com.rajeev.testertrack.ui.components.EmptyNote
import com.rajeev.testertrack.ui.components.HeaderWithCard
import com.rajeev.testertrack.ui.components.InfoBanner
import com.rajeev.testertrack.ui.components.MenuEntry
import com.rajeev.testertrack.ui.components.Pill
import com.rajeev.testertrack.ui.components.SectionCard
import com.rajeev.testertrack.ui.components.SubTopBar
import com.rajeev.testertrack.ui.components.SummaryCard
import com.rajeev.testertrack.ui.components.TileData
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.GreenSoft
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.theme.Tile
import com.rajeev.testertrack.ui.todayMs
import com.rajeev.testertrack.ui.usageTotal

// ======================= ADMIN HOME =======================

@Composable
fun AdminHome(
    user: UserProfile,
    team: Team?,
    members: List<Member>,
    tasks: List<WorkTask>,
    sessions: List<Session>,
    usageToday: List<UsageDay>,
    now: Long,
    nav: (Screen) -> Unit,
    run: Runner,
    onSignOut: () -> Unit,
) {
    val today = Dates.dayKey(now)
    var addTask by remember { mutableStateOf(false) }
    val done = tasks.count { it.status == TaskStatus.DONE }
    val working = tasks.count { it.status == TaskStatus.WORKING }
    val pending = tasks.count { it.status == TaskStatus.PENDING }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                HeaderWithCard(
                    teamName = team?.name ?: "",
                    userName = user.name,
                    photo = user.photo,
                    chips = listOf(Chip(tr("एडमिन", "Admin"), true), Chip(tr("${members.size} टेस्टर", "${members.size} testers"), false)),
                    menu = listOf(
                        MenuEntry(tr("टेस्टर जोड़ें / हटाएं", "Add / remove testers")) { nav(Screen.Testers) },
                        MenuEntry(tr("ट्रैक होने वाले ऐप्स", "Tracked apps")) { nav(Screen.Apps) },
                        MenuEntry(tr("नया टास्क", "New task")) { addTask = true },
                        MenuEntry(tr("सभी टास्क", "All tasks")) { nav(Screen.Tasks(null)) },
                        MenuEntry(tr("साइन आउट", "Sign out")) { onSignOut() },
                    ),
                    onAvatar = { nav(Screen.Settings) },
                    onSettings = { nav(Screen.Settings) },
                    cardTitle = tr("आज ग्रुप का काम", "Group work today"),
                    cardValue = Dates.hoursLong(todayMs(sessions, null, today, now)),
                    tiles = listOf(
                        TileData(tr("पूरे टास्क", "Done tasks"), "$done") { nav(Screen.Tasks(TaskStatus.DONE)) },
                        TileData(tr("चालू टास्क", "Working tasks"), "$working") { nav(Screen.Tasks(TaskStatus.WORKING)) },
                        TileData(tr("बाकी टास्क", "Pending tasks"), "$pending", Purple) { nav(Screen.Tasks(TaskStatus.PENDING)) },
                    ),
                )
            }

            if (members.isEmpty()) {
                item {
                    InfoBanner(Icons.Filled.Person, tr("अभी कोई टेस्टर नहीं है। टेस्टर का Gmail जोड़ें — वह साइन इन करते ही अपने-आप जुड़ जाएगा।", "No testers yet. Add your tester's Gmail — they join automatically when they sign in.")) {
                        nav(Screen.Testers)
                    }
                }
            }
            if (team != null && team.apps.isEmpty()) {
                item {
                    InfoBanner(Icons.Filled.Info, tr("अपने ऐप्स जोड़ें, ताकि ड्यूटी के दौरान टेस्टर का उनमें बिताया समय गिना जा सके।", "Add your apps so the tester's time in them is counted during duty.")) {
                        nav(Screen.Apps)
                    }
                }
            }

            if (members.isNotEmpty()) {
                item {
                    SectionCard(tr("टेस्टर", "Tester"), action = tr("जोड़ें", "Add"), onAction = { nav(Screen.Testers) }) {
                        members.sortedByDescending { it.onDuty }.forEachIndexed { i, m ->
                            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                            TesterRow(
                                m = m,
                                todayWork = todayMs(sessions, m.uid, today, now),
                                appTime = usageTotal(usageToday.firstOrNull { it.uid == m.uid }),
                                working = tasks.count { it.assigneeUid == m.uid && it.status == TaskStatus.WORKING },
                                pending = tasks.count { it.assigneeUid == m.uid && it.status == TaskStatus.PENDING },
                                onClick = { nav(Screen.TesterDetail(m.uid)) }
                            )
                        }
                    }
                }
            }

            item {
                SectionCard(tr("हाल के टास्क", "Recent tasks"), action = tr("सभी देखें", "See all"), onAction = { nav(Screen.Tasks(null)) }) {
                    val recent = tasks.sortedByDescending { maxOf(it.createdAt, it.startedAt, it.doneAt) }.take(5)
                    if (recent.isEmpty()) EmptyNote(tr("कोई टास्क नहीं। नीचे “नया टास्क” दबाएं।", "No tasks. Tap “New task” below."))
                    recent.forEachIndexed { i, t ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        TaskRow(t, isAdmin = true, teamId = user.teamId, run = run)
                    }
                }
            }
            item { Spacer(Modifier.height(96.dp)) }
        }

        ExtendedFloatingActionButton(
            onClick = { addTask = true },
            containerColor = Purple, contentColor = Color.White,
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text(tr("नया टास्क", "New task")) },
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(18.dp)
        )
    }

    if (addTask) {
        AddTaskDialog(team, members, onDismiss = { addTask = false }) { title, app, note, m ->
            addTask = false
            run(tr("टास्क जोड़ा", "Task added")) { Repo.addTask(user.teamId, title, app, note, m) }
        }
    }
}

@Composable
private fun TesterRow(m: Member, todayWork: Long, appTime: Long, working: Int, pending: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(m.photo, m.name, 48.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.name, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.width(8.dp))
                if (m.onDuty) Pill(tr("ड्यूटी पर", "On duty"), Green, GreenSoft) else Pill(tr("ड्यूटी बंद", "Off duty"), Sub, Tile)
            }
            Text(
                tr("आज ${Dates.hoursShort(todayWork)} · ऐप्स में ${Dates.hoursShort(appTime)}", "Today ${Dates.hoursShort(todayWork)} · in apps ${Dates.hoursShort(appTime)}"),
                color = Sub, fontSize = 13.sp
            )
            Text(tr("$working चालू · $pending बाकी टास्क", "$working working · $pending pending tasks"), color = Sub, fontSize = 13.sp)
        }
        Text("›", color = Sub, fontSize = 26.sp)
    }
}

// ======================= ADD TASK =======================

@Composable
fun AddTaskDialog(
    team: Team?,
    members: List<Member>,
    onDismiss: () -> Unit,
    onAdd: (title: String, app: String, note: String, member: Member) -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var app by remember { mutableStateOf(team?.apps?.firstOrNull()?.name ?: "") }
    var note by remember { mutableStateOf("") }
    var who by remember { mutableStateOf(members.firstOrNull()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("नया टास्क", "New task")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (members.isEmpty()) {
                    Text(tr("पहले ☰ → टेस्टर जोड़ें। टेस्टर के साइन इन करने के बाद ही टास्क दिया जा सकता है।", "First add a tester from ☰. You can assign tasks once the tester has signed in."), color = Red)
                    return@Column
                }
                OutlinedTextField(
                    title, { title = it }, label = { Text(tr("क्या करना है", "What to do")) },
                    placeholder = { Text(tr("जैसे: लॉगिन और फ़ोटो अपलोड जाँचें", "e.g. Check login and photo upload")) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Text(tr("ऐप", "App"), color = Sub, fontSize = 14.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (team?.apps?.map { it.name } ?: emptyList()).plus(tr("अन्य", "Other")).forEach { n ->
                        val key = if (n == tr("अन्य", "Other")) "" else n
                        FilterChip(
                            selected = app == key, onClick = { app = key }, label = { Text(n) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple, selectedLabelColor = Color.White)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(tr("किसे देना है", "Assign to"), color = Sub, fontSize = 14.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    members.forEach { m ->
                        FilterChip(
                            selected = who?.uid == m.uid, onClick = { who = m }, label = { Text(m.name) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple, selectedLabelColor = Color.White)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    note, { note = it }, label = { Text(tr("नोट (वैकल्पिक)", "Note (optional)")) },
                    modifier = Modifier.fillMaxWidth(), minLines = 2
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { who?.let { onAdd(title, app, note, it) } },
                enabled = title.isNotBlank() && who != null
            ) { Text(tr("जोड़ें", "Add")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("रद्द करें", "Cancel")) } }
    )
}

// ======================= TESTER DETAIL =======================

@Composable
fun TesterDetailScreen(
    member: Member,
    team: Team?,
    tasks: List<WorkTask>,
    sessions: List<Session>,
    usageToday: UsageDay?,
    now: Long,
    nav: (Screen) -> Unit,
    run: Runner,
    onBack: () -> Unit,
) {
    val today = Dates.dayKey(now)
    Column(Modifier.fillMaxSize()) {
        SubTopBar(member.name, onBack)
        LazyColumn(
            Modifier.navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(Modifier.height(14.dp))
                Row(Modifier.padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(member.photo, member.name, 56.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(member.email, color = Sub, fontSize = 14.sp)
                        Text(
                            if (member.onDuty) tr("ड्यूटी पर · ${Dates.time(member.dutyStart)} से", "On duty · since ${Dates.time(member.dutyStart)}")
                            else tr("ड्यूटी बंद", "Off duty") + if (member.lastSeen > 0) tr(" · आखिरी बार ${Dates.dateTime(member.lastSeen)}", " · last seen ${Dates.dateTime(member.lastSeen)}") else "",
                            color = if (member.onDuty) Green else Sub, fontWeight = FontWeight.SemiBold, fontSize = 15.sp
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                SummaryCard(
                    tr("आज का काम", "Today's work"),
                    Dates.hoursLong(todayMs(sessions, member.uid, today, now)),
                    listOf(
                        TileData(tr("पूरे टास्क", "Done tasks"), "${tasks.count { it.status == TaskStatus.DONE }}") { nav(Screen.Tasks(TaskStatus.DONE, member.uid)) },
                        TileData(tr("चालू टास्क", "Working tasks"), "${tasks.count { it.status == TaskStatus.WORKING }}") { nav(Screen.Tasks(TaskStatus.WORKING, member.uid)) },
                        TileData(tr("बाकी टास्क", "Pending tasks"), "${tasks.count { it.status == TaskStatus.PENDING }}", Purple) { nav(Screen.Tasks(TaskStatus.PENDING, member.uid)) },
                    )
                )
            }
            item {
                SectionCard(tr("आज ऐप उपयोग", "App usage today"), trailing = Dates.hoursShort(usageTotal(usageToday))) {
                    UsageList(
                        usageToday?.perApp() ?: emptyMap(), team?.apps ?: emptyList(),
                        if (team?.apps.isNullOrEmpty()) tr("☰ → ट्रैक होने वाले ऐप्स में अपने ऐप्स जोड़ें", "Add your apps in ☰ → Tracked apps")
                        else tr("आज ड्यूटी के दौरान आपके ऐप्स नहीं खोले गए (या टेस्टर ने उपयोग अनुमति नहीं दी)", "Your apps weren't opened during duty today (or the tester hasn't allowed usage access)")
                    )
                }
            }
            item {
                SectionCard(tr("इस हफ़्ते", "This week"), action = tr("पूरा इतिहास", "Full history"), onAction = { nav(Screen.History(member.uid, member.name)) }) {
                    Text(
                        tr("7 दिन में कुल ${Dates.hoursLong(sessions.sumOf { it.durationMs(now) })} · ${sessions.map { it.date }.distinct().size} दिन काम", "${Dates.hoursLong(sessions.sumOf { it.durationMs(now) })} in 7 days · worked ${sessions.map { it.date }.distinct().size} days"),
                        color = Ink, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 22.dp)
                    )
                }
            }
            item {
                SectionCard(tr("चल रहे टास्क", "Active tasks"), action = tr("सभी देखें", "See all"), onAction = { nav(Screen.Tasks(null, member.uid)) }) {
                    val active = tasks.filter { it.status != TaskStatus.DONE }.sortedByDescending { it.createdAt }
                    if (active.isEmpty()) EmptyNote(tr("कोई बाकी या चालू टास्क नहीं", "No pending or working tasks"))
                    active.forEachIndexed { i, t ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        TaskRow(t, isAdmin = true, teamId = team?.id ?: "", run = run, showAssignee = false)
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

// ======================= TESTERS (add / remove) =======================

@Composable
fun TestersScreen(team: Team?, members: List<Member>, invites: List<Invite>, run: Runner, onBack: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var removeTarget by remember { mutableStateOf<Pair<String, String?>?>(null) } // email, uid
    val joinedEmails = members.map { it.email.lowercase() }.toSet()
    val waiting = invites.filter { it.email !in joinedEmails }
    val validEmail = email.trim().contains("@") && email.trim().contains(".")

    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("टेस्टर", "Testers"), onBack)
        LazyColumn(Modifier.navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Spacer(Modifier.height(14.dp))
                SectionCard(tr("नया टेस्टर जोड़ें", "Add a new tester")) {
                    Column(Modifier.padding(horizontal = 22.dp)) {
                        OutlinedTextField(
                            email, { email = it }, label = { Text(tr("टेस्टर का Gmail", "Tester's Gmail")) }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            name, { name = it }, label = { Text(tr("नाम (वैकल्पिक)", "Name (optional)")) }, singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val e = email; val n = name
                                email = ""; name = ""
                                run(tr("जोड़ दिया — अब टेस्टर इसी Gmail से साइन इन करे", "Added — now the tester signs in with this Gmail")) {
                                    Repo.addInvite(team!!.id, team.name, e, n)
                                }
                            },
                            enabled = team != null && validEmail,
                            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                        ) { Text(tr("जोड़ें", "Add")) }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            tr("टेस्टर ऐप इंस्टॉल करके इसी Gmail से साइन इन करेगा तो अपने-आप आपके ग्रुप से जुड़ जाएगा।", "When the tester installs the app and signs in with this Gmail, they join your group automatically."),
                            color = Sub, fontSize = 13.sp
                        )
                    }
                }
            }
            item {
                SectionCard(tr("जुड़े हुए टेस्टर", "Joined testers"), trailing = "${members.size}") {
                    if (members.isEmpty()) EmptyNote(tr("अभी कोई नहीं", "None yet"))
                    members.forEachIndexed { i, m ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        Row(Modifier.padding(start = 22.dp, end = 10.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(m.photo, m.name, 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(m.name, color = Ink, fontSize = 16.sp)
                                Text(m.email, color = Sub, fontSize = 13.sp)
                            }
                            IconButton(onClick = { removeTarget = m.email to m.uid }) {
                                Icon(Icons.Filled.Delete, tr("हटाएं", "Remove"), tint = Red)
                            }
                        }
                    }
                }
            }
            if (waiting.isNotEmpty()) {
                item {
                    SectionCard(tr("साइन इन का इंतज़ार", "Waiting for sign-in")) {
                        waiting.forEach { inv ->
                            Row(Modifier.padding(start = 22.dp, end = 10.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    if (inv.name.isNotBlank()) Text(inv.name, color = Ink, fontSize = 16.sp)
                                    Text(inv.email, color = Sub, fontSize = 13.sp)
                                }
                                IconButton(onClick = { removeTarget = inv.email to null }) {
                                    Icon(Icons.Filled.Delete, tr("हटाएं", "Remove"), tint = Red)
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    removeTarget?.let { (e, uid) ->
        AlertDialog(
            onDismissRequest = { removeTarget = null },
            title = { Text(tr("टेस्टर हटाएं?", "Remove tester?")) },
            text = { Text(tr("$e ग्रुप से हट जाएगा। उसका पुराना काम का इतिहास बना रहेगा।", "$e will be removed from the group. Their past work history stays.")) },
            confirmButton = {
                TextButton(onClick = {
                    removeTarget = null
                    run(tr("हटा दिया", "Removed")) { Repo.removeTester(team?.id ?: "", e, uid) }
                }) { Text(tr("हटाएं", "Remove"), color = Red) }
            },
            dismissButton = { TextButton(onClick = { removeTarget = null }) { Text(tr("रहने दें", "Keep")) } }
        )
    }
}

// ======================= TRACKED APPS =======================

@Composable
fun AppsScreen(team: Team?, run: Runner, onBack: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var pkg by remember { mutableStateOf("") }
    val validPkg = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$").matches(pkg.trim())

    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("ट्रैक होने वाले ऐप्स", "Tracked apps"), onBack)
        LazyColumn(Modifier.navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Spacer(Modifier.height(14.dp))
                InfoBanner(
                    Icons.Filled.Info,
                    tr("टेस्टर के फ़ोन पर सिर्फ़ इन्हीं ऐप्स का समय गिना जाता है, और सिर्फ़ ड्यूटी चालू रहने पर।", "Only these apps are counted on the tester's phone, and only while duty is on.")
                )
            }
            item {
                SectionCard(tr("ऐप जोड़ें", "Add app")) {
                    Column(Modifier.padding(horizontal = 22.dp)) {
                        OutlinedTextField(
                            name, { name = it }, label = { Text(tr("ऐप का नाम", "App name")) },
                            placeholder = { Text(tr("जैसे Samuh Khata", "e.g. Samuh Khata")) }, singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            pkg, { pkg = it.trim() }, label = { Text(tr("पैकेज नाम", "Package name")) },
                            placeholder = { Text("com.rajeev.samuhkhata") }, singleLine = true,
                            isError = pkg.isNotBlank() && !validPkg,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            tr("पैकेज नाम Play Console में या ऐप के Play Store लिंक में id= के बाद मिलता है।", "Find the package name in Play Console, or after id= in the app's Play Store link."),
                            color = Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val n = name; val p = pkg
                                name = ""; pkg = ""
                                run(tr("ऐप जोड़ा", "App added")) { Repo.addApp(team!!.id, n.ifBlank { p }, p) }
                            },
                            enabled = team != null && validPkg && team.apps.none { it.pkg == pkg.trim() },
                            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                        ) { Text(tr("जोड़ें", "Add")) }
                    }
                }
            }
            item {
                SectionCard(tr("आपके ऐप्स", "Your apps"), trailing = "${team?.apps?.size ?: 0}") {
                    val apps = team?.apps ?: emptyList()
                    if (apps.isEmpty()) EmptyNote(tr("अभी कोई ऐप नहीं जोड़ा", "No apps added yet"))
                    apps.forEachIndexed { i, a ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        Row(Modifier.padding(start = 22.dp, end = 10.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar("", a.name, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(a.name, color = Ink, fontSize = 16.sp)
                                Text(a.pkg, color = Sub, fontSize = 13.sp)
                            }
                            IconButton(onClick = { run(tr("ऐप हटाया", "App removed")) { Repo.removeApp(team!!.id, a) } }) {
                                Icon(Icons.Filled.Delete, tr("हटाएं", "Remove"), tint = Red)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
