package com.rajeev.testertrack.ui.screens

import com.rajeev.testertrack.data.tr
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuthRecentLoginRequiredException
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.Role
import com.rajeev.testertrack.data.Session
import com.rajeev.testertrack.data.TaskStatus
import com.rajeev.testertrack.data.Team
import com.rajeev.testertrack.data.TrackedApp
import com.rajeev.testertrack.data.UserProfile
import com.rajeev.testertrack.data.WorkTask
import com.rajeev.testertrack.ui.Runner
import com.rajeev.testertrack.ui.components.Avatar
import com.rajeev.testertrack.ui.components.EmptyNote
import com.rajeev.testertrack.ui.components.Pill
import com.rajeev.testertrack.ui.components.SectionCard
import com.rajeev.testertrack.ui.components.SubTopBar
import com.rajeev.testertrack.ui.theme.Amber
import com.rajeev.testertrack.ui.theme.AmberSoft
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.GreenSoft
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.theme.Tile

// ---------------- task row ----------------

@Composable
fun StatusPill(status: String) = when (status) {
    TaskStatus.DONE -> Pill(tr("पूरा", "Done"), Green, GreenSoft)
    TaskStatus.WORKING -> Pill(tr("चालू", "Working"), Purple, Tile)
    else -> Pill(tr("बाकी", "Pending"), Amber, AmberSoft)
}

/**
 * Admin: tap row to change status / delete.
 * Tester: inline "शुरू करें" / "पूरा करें" buttons.
 */
@Composable
fun TaskRow(task: WorkTask, isAdmin: Boolean, teamId: String, run: Runner, showAssignee: Boolean = true) {
    var dialog by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .let { if (isAdmin) it.clickable { dialog = true } else it }
            .padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar("", task.appName.ifBlank { task.title }, 44.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                task.title, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            val bits = listOfNotNull(
                task.appName.takeIf { it.isNotBlank() },
                task.assigneeName.takeIf { showAssignee && it.isNotBlank() },
                when (task.status) {
                    TaskStatus.DONE -> tr("पूरा ${Dates.dateTime(task.doneAt)}", "Done ${Dates.dateTime(task.doneAt)}")
                    TaskStatus.WORKING -> tr("शुरू ${Dates.dateTime(task.startedAt)}", "Started ${Dates.dateTime(task.startedAt)}")
                    else -> Dates.dateTime(task.createdAt)
                }
            )
            Text(bits.joinToString(" · "), color = Sub, fontSize = 13.sp, maxLines = 2)
            if (task.note.isNotBlank()) {
                Text(task.note, color = Sub, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (!isAdmin && task.status != TaskStatus.DONE) {
                Spacer(Modifier.height(8.dp))
                if (task.status == TaskStatus.PENDING) {
                    Button(
                        onClick = { run(tr("टास्क शुरू", "Task started")) { Repo.setTaskStatus(teamId, task.id, TaskStatus.WORKING) } },
                        shape = RoundedCornerShape(12.dp), modifier = Modifier.height(38.dp)
                    ) { Text(tr("शुरू करें", "Start")) }
                } else {
                    Button(
                        onClick = { run(tr("टास्क पूरा ✔", "Task done ✔")) { Repo.setTaskStatus(teamId, task.id, TaskStatus.DONE) } },
                        colors = ButtonDefaults.buttonColors(containerColor = Green),
                        shape = RoundedCornerShape(12.dp), modifier = Modifier.height(38.dp)
                    ) { Text(tr("पूरा करें", "Mark done")) }
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        StatusPill(task.status)
    }

    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text(task.title) },
            text = {
                Column {
                    Text(tr("स्थिति बदलें", "Change status"), color = Sub)
                    Spacer(Modifier.height(8.dp))
                    listOf(TaskStatus.PENDING, TaskStatus.WORKING, TaskStatus.DONE).forEach { st ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    dialog = false
                                    run(tr("बदल दिया", "Updated")) { Repo.setTaskStatus(teamId, task.id, st) }
                                }
                                .padding(vertical = 10.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusPill(st)
                            if (st == task.status) Text(tr("  (अभी)", "  (current)"), color = Sub)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = false }) { Text(tr("बंद करें", "Close")) } },
            dismissButton = {
                TextButton(onClick = {
                    dialog = false
                    run(tr("टास्क हटाया", "Task deleted")) { Repo.deleteTask(teamId, task.id) }
                }) { Text(tr("हटाएं", "Remove"), color = Red) }
            }
        )
    }
}

// ---------------- all tasks ----------------

@Composable
fun TasksScreen(
    isAdmin: Boolean,
    teamId: String,
    tasks: List<WorkTask>,
    title: String,
    initialFilter: String?,
    run: Runner,
    onBack: () -> Unit,
) {
    var filter by remember { mutableStateOf(initialFilter) }
    val shown = tasks.filter { filter == null || it.status == filter }.sortedByDescending { it.createdAt }
    Column(Modifier.fillMaxSize()) {
        SubTopBar(title, onBack)
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val opts = listOf(
                null to tr("सभी (${tasks.size})", "All (${tasks.size})"),
                TaskStatus.DONE to tr("पूरे (${tasks.count { it.status == TaskStatus.DONE }})", "Done (${tasks.count { it.status == TaskStatus.DONE }})"),
                TaskStatus.WORKING to tr("चालू (${tasks.count { it.status == TaskStatus.WORKING }})", "Working (${tasks.count { it.status == TaskStatus.WORKING }})"),
                TaskStatus.PENDING to tr("बाकी (${tasks.count { it.status == TaskStatus.PENDING }})", "Pending (${tasks.count { it.status == TaskStatus.PENDING }})"),
            )
            opts.forEach { (key, label) ->
                FilterChip(
                    selected = filter == key, onClick = { filter = key }, label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Purple, selectedLabelColor = Color.White
                    )
                )
            }
        }
        if (shown.isEmpty()) {
            EmptyNote(tr("यहाँ कोई टास्क नहीं है", "No tasks here"))
        } else {
            Surface(
                shape = RoundedCornerShape(24.dp), color = Color.White,
                modifier = Modifier.padding(horizontal = 14.dp).fillMaxWidth()
            ) {
                LazyColumn(Modifier.navigationBarsPadding()) {
                    items(shown, key = { it.id }) { t ->
                        TaskRow(t, isAdmin, teamId, run)
                        HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                    }
                }
            }
        }
    }
}

// ---------------- app usage list ----------------

@Composable
fun UsageList(perApp: Map<String, Long>, apps: List<TrackedApp>, emptyText: String) {
    if (perApp.isEmpty()) { EmptyNote(emptyText); return }
    val max = perApp.values.maxOrNull()?.coerceAtLeast(1L) ?: 1L
    perApp.entries.sortedByDescending { it.value }.forEach { (pkg, ms) ->
        val name = apps.find { it.pkg == pkg }?.name?.ifBlank { null } ?: pkg
        Column(Modifier.padding(horizontal = 22.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(name, color = Ink, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(Dates.hoursShort(ms), color = Purple, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(Tile)) {
                Box(
                    Modifier.fillMaxWidth((ms.toFloat() / max).coerceIn(0.03f, 1f)).height(8.dp)
                        .clip(RoundedCornerShape(50)).background(Purple)
                )
            }
        }
    }
}

// ---------------- 7-day work history ----------------

@Composable
fun HistoryScreen(name: String, sessions: List<Session>, now: Long, onBack: () -> Unit) {
    val days = (0..6).map { Dates.daysAgoKey(it) }
    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("$name · 7 दिन का काम", "$name · last 7 days"), onBack)
        LazyColumn(Modifier.navigationBarsPadding()) {
            item {
                val total = sessions.sumOf { it.durationMs(now) }
                Text(
                    tr("कुल: ${Dates.hoursLong(total)}", "Total: ${Dates.hoursLong(total)}"), fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    color = Ink, modifier = Modifier.padding(22.dp)
                )
            }
            items(days) { d ->
                val list = sessions.filter { it.date == d }.sortedBy { it.start }
                val ms = list.sumOf { it.durationMs(now) }
                Surface(
                    shape = RoundedCornerShape(22.dp), color = Color.White,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp).fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(Dates.dayLabel(d), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.weight(1f))
                            Text(if (ms > 0) Dates.hoursShort(ms) else tr("छुट्टी", "Off"), color = if (ms > 0) Purple else Sub, fontWeight = FontWeight.SemiBold)
                        }
                        list.forEach { s ->
                            Text(
                                "${Dates.time(s.start)} – ${if (s.end > 0) Dates.time(s.end) else tr("अभी चालू", "running")}  ·  ${Dates.hoursShort(s.durationMs(now))}",
                                color = Sub, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

// ---------------- settings / profile ----------------

private fun photoToBase64(ctx: android.content.Context, uri: Uri): String? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    if (src == null) null else {
        val side = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        val small = Bitmap.createScaledBitmap(sq, 256, 256, true)
        val out = java.io.ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 75, out)
        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
} catch (e: Exception) { null }

@Composable
fun SettingsScreen(
    user: UserProfile,
    team: Team?,
    run: Runner,
    onSignOut: () -> Unit,
    onDeleted: () -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    val isAdmin = user.role == Role.ADMIN
    var name by remember(user.name) { mutableStateOf(user.name) }
    var teamName by remember(team?.name) { mutableStateOf(team?.name ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val b64 = photoToBase64(ctx, uri)
            if (b64 != null) run(tr("फ़ोटो बदल दी", "Photo updated")) { Repo.updateProfile(user, user.name, b64) }
        }
    }
    val pickPhoto = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }

    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("सेटिंग्स", "Settings"), onBack)
        Column(
            Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionCard(tr("प्रोफ़ाइल", "Profile")) {
                Column(Modifier.padding(horizontal = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Box {
                            Avatar(user.photo, user.name, 104.dp, logoFallback = true, onClick = pickPhoto)
                            Box(
                                Modifier.align(Alignment.BottomEnd).size(34.dp).clip(CircleShape)
                                    .background(Purple).clickable { pickPhoto() },
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Filled.Edit, tr("फ़ोटो बदलें", "Change photo"), tint = Color.White, modifier = Modifier.size(18.dp)) }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(user.email, color = Sub, fontSize = 14.sp)
                    if (user.photo.isNotBlank()) {
                        TextButton(onClick = { run(tr("फ़ोटो हटाई", "Photo removed")) { Repo.updateProfile(user, user.name, "") } }) {
                            Text(tr("फ़ोटो हटाएं", "Remove photo"), color = Red)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        name, { name = it }, label = { Text(tr("आपका नाम (नमस्ते में दिखेगा)", "Your name (shown in the greeting)")) },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { run(tr("नाम सेव हुआ", "Name saved")) { Repo.updateProfile(user, name, user.photo) } },
                        enabled = name.isNotBlank() && name.trim() != user.name,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                    ) { Text(tr("नाम सेव करें", "Save name")) }
                }
            }

            SectionCard("भाषा / Language") {
                Column(Modifier.padding(horizontal = 22.dp)) {
                    Text(
                        tr("ऐप की भाषा चुनें। यह सिर्फ़ इस फ़ोन पर बदलेगी।", "Choose the app language. It changes only on this phone."),
                        color = Sub, fontSize = 14.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    com.rajeev.testertrack.ui.components.LanguageSwitch()
                }
            }

            if (isAdmin && team != null) {
                SectionCard(tr("ग्रुप", "Group")) {
                    Column(Modifier.padding(horizontal = 22.dp)) {
                        OutlinedTextField(
                            teamName, { teamName = it }, label = { Text(tr("ग्रुप का नाम (हेडर में दिखेगा)", "Group name (shown in the header)")) },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { run(tr("ग्रुप का नाम सेव हुआ", "Group name saved")) { Repo.updateTeamName(team.id, teamName) } },
                            enabled = teamName.isNotBlank() && teamName.trim() != team.name,
                            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                        ) { Text(tr("सेव करें", "Save")) }
                    }
                }
            }

            SectionCard(tr("क्या ट्रैक होता है", "What is tracked")) {
                Text(
                    tr("ड्यूटी का समय, टास्क की स्थिति, और ड्यूटी चालू रहने पर सिर्फ़ एडमिन के चुने हुए ऐप्स में बिताया समय। ", "Duty time, task status, and — only while duty is on — time in the admin's chosen apps. ") +
                        tr("लोकेशन, मैसेज, कॉल, फ़ोटो और बाकी ऐप्स कभी नहीं देखे जाते।", "Location, messages, calls, photos and other apps are never seen."),
                    color = Sub, fontSize = 15.sp, lineHeight = 22.sp, modifier = Modifier.padding(horizontal = 22.dp)
                )
            }

            SectionCard(tr("खाता", "Account")) {
                Column(Modifier.padding(horizontal = 22.dp)) {
                    OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Text(tr("साइन आउट", "Sign out"))
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(tr("खाता और डेटा हमेशा के लिए हटाएं", "Delete account and data permanently"), color = Red)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(tr("खाता हटाएं?", "Delete account?")) },
            text = {
                Text(
                    if (isAdmin) tr("आपका ग्रुप, टेस्टर की सूची और आपका खाता हट जाएगा। यह वापस नहीं होगा।", "Your group, tester list and account will be deleted. This can't be undone.")
                    else tr("आपका काम का इतिहास, ऐप उपयोग और खाता हट जाएगा। यह वापस नहीं होगा।", "Your work history, app usage and account will be deleted. This can't be undone.")
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    run(null) {
                        try {
                            Repo.deleteAccount(user)
                        } catch (e: FirebaseAuthRecentLoginRequiredException) {
                            throw Exception(tr("डेटा हट गया। खाता हटाने के लिए एक बार साइन आउट करके फिर साइन इन करें और दोबारा कोशिश करें।", "Data deleted. To delete the account, sign out, sign in again and retry."))
                        }
                        onDeleted()
                    }
                }) { Text(tr("हाँ, हटाएं", "Yes, delete"), color = Red) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(tr("रहने दें", "Keep")) } }
        )
    }
}
