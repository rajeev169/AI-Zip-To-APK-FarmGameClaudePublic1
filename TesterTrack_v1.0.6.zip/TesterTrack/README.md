# Tester Track v1.0

Admin + tester app in the Samuh Khata style (purple header, "नमस्ते, Name", white summary card).

- Package: `com.rajeev.testertrack` (name "Tester Track" can be changed later in `res/values/strings.xml`)
- Kotlin + Jetpack Compose, Firebase Auth (Google sign-in) + Firestore, minSdk 26, targetSdk 35

## Features
**Admin (you)**
- Home: team name, नमस्ते + your photo, chips (एडमिन, N टेस्टर)
- Card "आज टीम का काम" with total hours + tiles: पूरे / चालू / बाकी टास्क
- Testers list: duty on/off, today hours, time in your apps, active tasks
- Tester detail: today's hours, task tiles, per-app usage today, 7-day history
- ☰ menu: add/remove testers (by Gmail), tracked apps, new task, all tasks
- Tap any task to change status or delete

**Tester**
- Same header ("टेस्टर", "ड्यूटी पर / बंद")
- Card "आज का काम" + पूरे / चालू / बाकी tiles
- Duty start/stop button (ongoing notification while on duty)
- My tasks with "शुरू करें" / "पूरा करें"
- Sees their own app usage too (transparency)

**Both**: ☰ opens a full Menu page; profile photo + name in ⚙️ Settings; **English / हिंदी** switch only in Settings (English by default, saved per phone); sign out; delete account.

**Tester mobile number**: required once right after joining, editable in Settings. Admin sees it on the tester's page with a **Call** button, and a 📞 button in the home Tester list (opens the dialer).

**Waiting testers**: Gmails the admin added that haven't signed in show on the home screen as "Not signed in yet"; the header chip (e.g. "1 tester · 1 waiting") opens the Testers page.

**Home design (v1.0.6)**: admin and tester homes have a purple background; the header and white work card stay fixed while the list scrolls under a rounded, card-shaped edge; short tile labels (Done / Working / Pending); long names shrink to fit; no floating New task button (New task is in ☰ Menu); Sign out only in Settings.

**App link on tasks**: New task has an optional App link (Play closed-testing or Google Drive APK link); testers get an Open link button. Free — nothing is stored in Firebase Storage.

**Tester notifications**: bell with unread count next to the duty chip, Notifications page (Mark all read). Created when the admin adds a task, changes its status, or deletes it. Phone notifications appear instantly while the app is open and via a background check about every 15 minutes when closed (no paid Firebase plan needed).

**Icon**: AppForge logo (launcher icon, login page, header fallback) + white silhouette notification icon.

**Linking**: admin creates the group with its name (editable in Settings) and adds testers by Gmail. The tester signs in with that Gmail and joins directly, then sees a one-time "what is tracked" consent screen. A Gmail that isn't added gets a "Recheck" / "Create team (admin)" screen, so a tester can't become admin by accident.

**App usage**: counted only for the package names you add in "ट्रैक होने वाले ऐप्स", only while duty is on, uploaded every ~15 min and on duty stop. Tester must allow "Usage access" once (app shows a banner).

## Firebase setup (one time)
1. Firebase Console → new project **Tester Track**.
2. Add Android app, package `com.rajeev.testertrack`, add the **same SHA-1** as your other apps.
3. Authentication → Sign-in method → enable **Google**.
4. Firestore Database → Create (production mode) → Rules → paste `firestore.rules` from this zip → Publish.
5. Download `google-services.json` → put it in the **`app/`** folder of this project.
6. Zip and push to your build repo as usual.

Without `google-services.json` the app still builds, but sign-in shows a "file missing" message.

## Play Store notes
- Declare in Data safety: name, email, photo, app activity (app usage of selected apps), collected for app functionality, deletable in-app.
- Privacy policy should say: no location, no messages/calls/photos; usage counted only for the admin's apps during duty, with the tester's consent.
