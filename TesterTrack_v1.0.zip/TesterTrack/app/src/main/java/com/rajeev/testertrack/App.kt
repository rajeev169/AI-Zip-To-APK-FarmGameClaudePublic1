package com.rajeev.testertrack

import android.app.Application
import com.rajeev.testertrack.tracking.DutyNotice

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        DutyNotice.createChannel(this)
    }
}
