package com.rajeev.testertrack

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import com.rajeev.testertrack.data.AuthState
import com.rajeev.testertrack.data.GoogleAuth
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.tracking.DutyNotice
import com.rajeev.testertrack.tracking.DutyPrefs
import com.rajeev.testertrack.tracking.Duty
import com.rajeev.testertrack.ui.AppRoot
import com.rajeev.testertrack.ui.screens.ConsentScreen
import com.rajeev.testertrack.ui.screens.ErrorScreen
import com.rajeev.testertrack.ui.screens.LoadingScreen
import com.rajeev.testertrack.ui.screens.NotLinkedScreen
import com.rajeev.testertrack.ui.screens.SignInScreen
import com.rajeev.testertrack.ui.theme.TesterTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var state by mutableStateOf<AuthState>(AuthState.Loading)

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun refresh() {
        state = AuthState.Loading
        lifecycleScope.launch { state = Repo.resolve() }
    }

    fun signOut() {
        lifecycleScope.launch {
            val ctx = this@MainActivity
            if (DutyPrefs.sessionId(ctx).isNotBlank()) {
                // End duty first so hours are not left running
                val s = state
                if (s is AuthState.Ready) {
                    try { Duty.stop(ctx, s.user, DutyPrefs.sessionId(ctx)) } catch (_: Exception) {}
                }
            }
            DutyPrefs.clear(ctx)
            DutyNotice.hide(ctx)
            Duty.cancelWorker(ctx)
            GoogleAuth.signOut(ctx)
            state = AuthState.SignedOut
        }
    }

    fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // white status-bar icons over the purple header
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        refresh()
        setContent {
            TesterTheme {
                val scope = rememberCoroutineScope()
                when (val s = state) {
                    AuthState.Loading -> LoadingScreen()
                    AuthState.SignedOut -> SignInScreen(onSignIn = { setError ->
                        scope.launch {
                            val err = GoogleAuth.signIn(this@MainActivity)
                            if (err == null) refresh() else setError(err)
                        }
                    })
                    is AuthState.NotLinked -> NotLinkedScreen(
                        email = s.email,
                        googleName = s.name,
                        onRecheck = { refresh() },
                        onCreateTeam = { team, name, done ->
                            scope.launch {
                                try { Repo.createTeam(team, name); refresh() } catch (e: Exception) { done(e.message) }
                            }
                        },
                        onSignOut = { signOut() },
                    )
                    is AuthState.NeedsConsent -> ConsentScreen(
                        onAccept = {
                            scope.launch {
                                try { Repo.giveConsent(s.user.uid) } catch (_: Exception) {}
                                askNotificationPermission()
                                refresh()
                            }
                        },
                        onSignOut = { signOut() },
                    )
                    is AuthState.Ready -> AppRoot(
                        initialUser = s.user,
                        onSignOut = { signOut() },
                        onRemoved = { refresh() },
                        askNotificationPermission = { askNotificationPermission() },
                    )
                    is AuthState.Error -> ErrorScreen(s.message, onRetry = { refresh() }, onSignOut = { signOut() })
                }
            }
        }
    }
}
