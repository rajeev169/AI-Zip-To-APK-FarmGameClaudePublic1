package com.rajeev.testertrack.data

import android.app.Activity
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.tasks.await

object GoogleAuth {
    /** Returns null on success, otherwise a Hindi error message. */
    suspend fun signIn(activity: Activity): String? {
        val resId = activity.resources.getIdentifier("default_web_client_id", "string", activity.packageName)
        if (resId == 0) return "google-services.json नहीं मिली। Firebase फ़ाइल app/ फ़ोल्डर में डालकर फिर से बनाएं।"
        val clientId = activity.getString(resId)
        return try {
            val option = GetSignInWithGoogleOption.Builder(clientId).build()
            val req = GetCredentialRequest.Builder().addCredentialOption(option).build()
            val res = CredentialManager.create(activity).getCredential(activity, req)
            val cred = res.credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                Repo.auth.signInWithCredential(GoogleAuthProvider.getCredential(g.idToken, null)).await()
                null
            } else "Google खाता नहीं मिला"
        } catch (e: GetCredentialCancellationException) {
            "साइन-इन रद्द किया गया"
        } catch (e: Exception) {
            e.message ?: "साइन-इन नहीं हो पाया"
        }
    }

    suspend fun signOut(activity: Activity) {
        Repo.auth.signOut()
        try {
            CredentialManager.create(activity).clearCredentialState(ClearCredentialStateRequest())
        } catch (_: Exception) {}
    }
}
