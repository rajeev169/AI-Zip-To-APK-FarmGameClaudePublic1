package com.rajeev.testertrack.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.testertrack.R
import com.rajeev.testertrack.ui.theme.Bg
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.LogoBlue
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub

@Composable
fun LoadingScreen() {
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Purple)
    }
}

@Composable
private fun Logo(size: Int = 96) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(LogoBlue),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size((size * 1.35f).dp))
    }
}

@Composable
fun SignInScreen(onSignIn: (setError: (String) -> Unit) -> Unit) {
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().background(Purple).statusBarsPadding().navigationBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Logo(110)
        Spacer(Modifier.height(24.dp))
        Text("Tester Track", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "टेस्टर का काम, टास्क और ड्यूटी का समय — एक जगह",
            color = Color.White.copy(alpha = 0.85f), fontSize = 16.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(40.dp))
        Button(
            onClick = {
                error = null; busy = true
                onSignIn { e -> error = e; busy = false }
            },
            enabled = !busy,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Purple),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Purple, strokeWidth = 2.dp)
            else Text("Google से साइन इन करें", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
        error?.let {
            Spacer(Modifier.height(16.dp))
            Text(it, color = Color(0xFFFFD6D6), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "एडमिन ने जिस Gmail को जोड़ा है, उससे साइन इन करते ही टेस्टर अपने-आप टीम से जुड़ जाता है।",
            color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, textAlign = TextAlign.Center
        )
    }
}

/** Gmail is not added to any team. Tester waits for admin; admin creates a team. */
@Composable
fun NotLinkedScreen(
    email: String,
    googleName: String,
    onRecheck: () -> Unit,
    onCreateTeam: (team: String, name: String, done: (String?) -> Unit) -> Unit,
    onSignOut: () -> Unit,
) {
    var creating by remember { mutableStateOf(false) }
    var team by remember { mutableStateOf("") }
    var name by remember { mutableStateOf(googleName) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(30.dp))
        Logo(84)
        Spacer(Modifier.height(18.dp))
        Text("नमस्ते, $googleName", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(email, color = Sub, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))

        Surface(shape = RoundedCornerShape(24.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("टेस्टर हैं?", fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Ink)
                Spacer(Modifier.height(6.dp))
                Text(
                    "यह Gmail अभी किसी टीम में नहीं जुड़ा है। एडमिन से कहें कि वह ☰ → टेस्टर में आपका Gmail जोड़ दें, फिर नीचे “फिर से जाँचें” दबाएं।",
                    color = Sub, fontSize = 15.sp, lineHeight = 22.sp
                )
                Spacer(Modifier.height(14.dp))
                Button(onClick = onRecheck, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Text("फिर से जाँचें")
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Surface(shape = RoundedCornerShape(24.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("एडमिन हैं?", fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Ink)
                Spacer(Modifier.height(6.dp))
                if (!creating) {
                    Text("अपनी टीम बनाएं और टेस्टर जोड़ें।", color = Sub, fontSize = 15.sp)
                    Spacer(Modifier.height(14.dp))
                    OutlinedButton(onClick = { creating = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Text("नई टीम बनाएं")
                    }
                } else {
                    OutlinedTextField(
                        team, { team = it }, label = { Text("टीम का नाम") },
                        placeholder = { Text("जैसे AppForge Testing") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        name, { name = it }, label = { Text("आपका नाम") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            busy = true; error = null
                            onCreateTeam(team, name) { e -> busy = false; error = e }
                        },
                        enabled = !busy && team.isNotBlank() && name.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                    ) { Text(if (busy) "बन रही है…" else "टीम बनाएं (मैं एडमिन हूँ)") }
                    error?.let { Text(it, color = Red, modifier = Modifier.padding(top = 8.dp)) }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        TextButton(onClick = onSignOut) { Text("दूसरे Gmail से साइन इन करें") }
    }
}

/** Shown once to the tester: exactly what is and isn't tracked. */
@Composable
fun ConsentScreen(onAccept: () -> Unit, onSignOut: () -> Unit) {
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(22.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("आप टीम से जुड़ गए हैं 🎉", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(6.dp))
        Text("शुरू करने से पहले जान लें कि यह ऐप क्या देखता है:", color = Sub, fontSize = 15.sp)
        Spacer(Modifier.height(18.dp))
        ConsentBlock(
            "एडमिन को दिखेगा", Green, listOf(
                "ड्यूटी शुरू और खत्म करने का समय, रोज़ के कुल घंटे",
                "आपके टास्क की स्थिति — बाकी, चालू, पूरे",
                "सिर्फ़ एडमिन के चुने हुए ऐप्स में बिताया समय, और सिर्फ़ ड्यूटी चालू रहने पर",
                "आपका नाम, Gmail और प्रोफ़ाइल फ़ोटो",
            )
        )
        Spacer(Modifier.height(12.dp))
        ConsentBlock(
            "कभी नहीं देखा जाता", Red, listOf(
                "आपकी लोकेशन",
                "मैसेज, कॉल, फ़ोटो, कैमरा या माइक",
                "बाकी सभी ऐप्स का उपयोग",
                "ड्यूटी बंद होने के बाद कुछ भी",
            )
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "ड्यूटी चालू रहने पर सूचना-पट्टी में एक नोटिफ़िकेशन दिखता रहेगा। आप अपना डेटा देख सकते हैं और सेटिंग्स से खाता हटा सकते हैं।",
            color = Sub, fontSize = 14.sp, lineHeight = 20.sp
        )
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { busy = true; onAccept() }, enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)
        ) { Text("मैं सहमत हूँ", fontSize = 17.sp) }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) { Text("सहमत नहीं — साइन आउट करें") }
    }
}

@Composable
private fun ConsentBlock(title: String, dot: Color, lines: List<String>) {
    Surface(shape = RoundedCornerShape(22.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, color = Ink)
            Spacer(Modifier.height(8.dp))
            lines.forEach {
                Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
                    Box(Modifier.padding(top = 8.dp).size(8.dp).clip(CircleShape).background(dot))
                    Spacer(Modifier.width(10.dp))
                    Text(it, color = Ink, fontSize = 15.sp, lineHeight = 21.sp)
                }
            }
        }
    }
}

@Composable
fun ErrorScreen(message: String, onRetry: () -> Unit, onSignOut: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("कुछ गड़बड़ हुई", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text(message, color = Sub, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRetry) { Text("फिर कोशिश करें") }
        TextButton(onClick = onSignOut) { Text("साइन आउट") }
    }
}
