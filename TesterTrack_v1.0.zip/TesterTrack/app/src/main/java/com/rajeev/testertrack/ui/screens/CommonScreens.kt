package com.rajeev.testertrack.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuthRecentLoginRequiredException
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.Role
import com.rajeev.testertrack.data.Session
import com.rajeev.testertrack.data.TaskStatus
import com.rajeev.testertrack.data.Team
import com.rajeev.testertrack.data.TrackedApp
import com.rajeev.testertrack.data.UserProfile
import com.rajeev.testertrack.data.WorkTask
import com.rajeev.testertrack.ui.Runner
import com.rajeev.testertrack.ui.components.Avatar
import com.rajeev.testertrack.ui.components.EmptyNote
import com.rajeev.testertrack.ui.components.Pill
import com.rajeev.testertrack.ui.components.SectionCard
import com.rajeev.testertrack.ui.components.SubTopBar
import com.rajeev.testertrack.ui.theme.Amber
import com.rajeev.testertrack.ui.theme.AmberSoft
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.GreenSoft
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.theme.Tile

// ---------------- task row ----------------

@Composable
fun StatusPill(status: String) = when (status) {
    TaskStatus.DONE -> Pill("पूरा", Green, GreenSoft)
    TaskStatus.WORKING -> Pill("चालू", Purple, Tile)
    else -> Pill("बाकी", Amber, AmberSoft)
}

/**
 * Admin: tap row to change status / delete.
 * Tester: inline "शुरू करें" / "पूरा करें" buttons.
 */
@Composable
fun TaskRow(task: WorkTask, isAdmin: Boolean, teamId: String, run: Runner, showAssignee: Boolean = true) {
    var dialog by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .let { if (isAdmin) it.clickable { dialog = true } else it }
            .padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar("", task.appName.ifBlank { task.title }, 44.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                task.title, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            val bits = listOfNotNull(
                task.appName.takeIf { it.isNotBlank() },
                task.assigneeName.takeIf { showAssignee && it.isNotBlank() },
                when (task.status) {
                    TaskStatus.DONE -> "पूरा ${Dates.dateTime(task.doneAt)}"
                    TaskStatus.WORKING -> "शुरू ${Dates.dateTime(task.startedAt)}"
                    else -> Dates.dateTime(task.createdAt)
                }
            )
            Text(bits.joinToString(" · "), color = Sub, fontSize = 13.sp, maxLines = 2)
            if (task.note.isNotBlank()) {
                Text(task.note, color = Sub, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (!isAdmin && task.status != TaskStatus.DONE) {
                Spacer(Modifier.height(8.dp))
                if (task.status == TaskStatus.PENDING) {
                    Button(
                        onClick = { run("टास्क शुरू") { Repo.setTaskStatus(teamId, task.id, TaskStatus.WORKING) } },
                        shape = RoundedCornerShape(12.dp), modifier = Modifier.height(38.dp)
                    ) { Text("शुरू करें") }
                } else {
                    Button(
                        onClick = { run("टास्क पूरा ✔") { Repo.setTaskStatus(teamId, task.id, TaskStatus.DONE) } },
                        colors = ButtonDefaults.buttonColors(containerColor = Green),
                        shape = RoundedCornerShape(12.dp), modifier = Modifier.height(38.dp)
                    ) { Text("पूरा करें") }
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        StatusPill(task.status)
    }

    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text(task.title) },
            text = {
                Column {
                    Text("स्थिति बदलें", color = Sub)
                    Spacer(Modifier.height(8.dp))
                    listOf(TaskStatus.PENDING, TaskStatus.WORKING, TaskStatus.DONE).forEach { st ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    dialog = false
                                    run("बदल दिया") { Repo.setTaskStatus(teamId, task.id, st) }
                                }
                                .padding(vertical = 10.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusPill(st)
                            if (st == task.status) Text("  (अभी)", color = Sub)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = false }) { Text("बंद करें") } },
            dismissButton = {
                TextButton(onClick = {
                    dialog = false
                    run("टास्क हटाया") { Repo.deleteTask(teamId, task.id) }
                }) { Text("हटाएं", color = Red) }
            }
        )
    }
}

// ---------------- all tasks ----------------

@Composable
fun TasksScreen(
    isAdmin: Boolean,
    teamId: String,
    tasks: List<WorkTask>,
    title: String,
    initialFilter: String?,
    run: Runner,
    onBack: () -> Unit,
) {
    var filter by remember { mutableStateOf(initialFilter) }
    val shown = tasks.filter { filter == null || it.status == filter }.sortedByDescending { it.createdAt }
    Column(Modifier.fillMaxSize()) {
        SubTopBar(title, onBack)
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val opts = listOf(
                null to "सभी (${tasks.size})",
                TaskStatus.DONE to "पूरे (${tasks.count { it.status == TaskStatus.DONE }})",
                TaskStatus.WORKING to "चालू (${tasks.count { it.status == TaskStatus.WORKING }})",
                TaskStatus.PENDING to "बाकी (${tasks.count { it.status == TaskStatus.PENDING }})",
            )
            opts.forEach { (key, label) ->
                FilterChip(
                    selected = filter == key, onClick = { filter = key }, label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Purple, selectedLabelColor = Color.White
                    )
                )
            }
        }
        if (shown.isEmpty()) {
            EmptyNote("यहाँ कोई टास्क नहीं है")
        } else {
            Surface(
                shape = RoundedCornerShape(24.dp), color = Color.White,
                modifier = Modifier.padding(horizontal = 14.dp).fillMaxWidth()
            ) {
                LazyColumn(Modifier.navigationBarsPadding()) {
                    items(shown, key = { it.id }) { t ->
                        TaskRow(t, isAdmin, teamId, run)
                        HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                    }
                }
            }
        }
    }
}

// ---------------- app usage list ----------------

@Composable
fun UsageList(perApp: Map<String, Long>, apps: List<TrackedApp>, emptyText: String) {
    if (perApp.isEmpty()) { EmptyNote(emptyText); return }
    val max = perApp.values.maxOrNull()?.coerceAtLeast(1L) ?: 1L
    perApp.entries.sortedByDescending { it.value }.forEach { (pkg, ms) ->
        val name = apps.find { it.pkg == pkg }?.name?.ifBlank { null } ?: pkg
        Column(Modifier.padding(horizontal = 22.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(name, color = Ink, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(Dates.hoursShort(ms), color = Purple, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(Tile)) {
                Box(
                    Modifier.fillMaxWidth((ms.toFloat() / max).coerceIn(0.03f, 1f)).height(8.dp)
                        .clip(RoundedCornerShape(50)).background(Purple)
                )
            }
        }
    }
}

// ---------------- 7-day work history ----------------

@Composable
fun HistoryScreen(name: String, sessions: List<Session>, now: Long, onBack: () -> Unit) {
    val days = (0..6).map { Dates.daysAgoKey(it) }
    Column(Modifier.fillMaxSize()) {
        SubTopBar("$name · 7 दिन का काम", onBack)
        LazyColumn(Modifier.navigationBarsPadding()) {
            item {
                val total = sessions.sumOf { it.durationMs(now) }
                Text(
                    "कुल: ${Dates.hoursLong(total)}", fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    color = Ink, modifier = Modifier.padding(22.dp)
                )
            }
            items(days) { d ->
                val list = sessions.filter { it.date == d }.sortedBy { it.start }
                val ms = list.sumOf { it.durationMs(now) }
                Surface(
                    shape = RoundedCornerShape(22.dp), color = Color.White,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp).fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(Dates.dayLabel(d), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.weight(1f))
                            Text(if (ms > 0) Dates.hoursShort(ms) else "छुट्टी", color = if (ms > 0) Purple else Sub, fontWeight = FontWeight.SemiBold)
                        }
                        list.forEach { s ->
                            Text(
                                "${Dates.time(s.start)} – ${if (s.end > 0) Dates.time(s.end) else "अभी चालू"}  ·  ${Dates.hoursShort(s.durationMs(now))}",
                                color = Sub, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

// ---------------- settings / profile ----------------

private fun photoToBase64(ctx: android.content.Context, uri: Uri): String? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    if (src == null) null else {
        val side = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        val small = Bitmap.createScaledBitmap(sq, 256, 256, true)
        val out = java.io.ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 75, out)
        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
} catch (e: Exception) { null }

@Composable
fun SettingsScreen(
    user: UserProfile,
    team: Team?,
    run: Runner,
    onSignOut: () -> Unit,
    onDeleted: () -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    val isAdmin = user.role == Role.ADMIN
    var name by remember(user.name) { mutableStateOf(user.name) }
    var teamName by remember(team?.name) { mutableStateOf(team?.name ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val b64 = photoToBase64(ctx, uri)
            if (b64 != null) run("फ़ोटो बदल दी") { Repo.updateProfile(user, user.name, b64) }
        }
    }
    val pickPhoto = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }

    Column(Modifier.fillMaxSize()) {
        SubTopBar("सेटिंग्स", onBack)
        Column(
            Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionCard("प्रोफ़ाइल") {
                Column(Modifier.padding(horizontal = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Box {
                            Avatar(user.photo, user.name, 104.dp, logoFallback = true, onClick = pickPhoto)
                            Box(
                                Modifier.align(Alignment.BottomEnd).size(34.dp).clip(CircleShape)
                                    .background(Purple).clickable { pickPhoto() },
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Filled.Edit, "फ़ोटो बदलें", tint = Color.White, modifier = Modifier.size(18.dp)) }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(user.email, color = Sub, fontSize = 14.sp)
                    if (user.photo.isNotBlank()) {
                        TextButton(onClick = { run("फ़ोटो हटाई") { Repo.updateProfile(user, user.name, "") } }) {
                            Text("फ़ोटो हटाएं", color = Red)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        name, { name = it }, label = { Text("आपका नाम (नमस्ते में दिखेगा)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { run("नाम सेव हुआ") { Repo.updateProfile(user, name, user.photo) } },
                        enabled = name.isNotBlank() && name.trim() != user.name,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                    ) { Text("नाम सेव करें") }
                }
            }

            if (isAdmin && team != null) {
                SectionCard("टीम") {
                    Column(Modifier.padding(horizontal = 22.dp)) {
                        OutlinedTextField(
                            teamName, { teamName = it }, label = { Text("टीम का नाम (हेडर में दिखेगा)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { run("टीम का नाम सेव हुआ") { Repo.updateTeamName(team.id, teamName) } },
                            enabled = teamName.isNotBlank() && teamName.trim() != team.name,
                            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                        ) { Text("सेव करें") }
                    }
                }
            }

            SectionCard("क्या ट्रैक होता है") {
                Text(
                    "ड्यूटी का समय, टास्क की स्थिति, और ड्यूटी चालू रहने पर सिर्फ़ एडमिन के चुने हुए ऐप्स में बिताया समय। " +
                        "लोकेशन, मैसेज, कॉल, फ़ोटो और बाकी ऐप्स कभी नहीं देखे जाते।",
                    color = Sub, fontSize = 15.sp, lineHeight = 22.sp, modifier = Modifier.padding(horizontal = 22.dp)
                )
            }

            SectionCard("खाता") {
                Column(Modifier.padding(horizontal = 22.dp)) {
                    OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Text("साइन आउट")
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("खाता और डेटा हमेशा के लिए हटाएं", color = Red)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("खाता हटाएं?") },
            text = {
                Text(
                    if (isAdmin) "आपकी टीम, टेस्टर की सूची और आपका खाता हट जाएगा। यह वापस नहीं होगा।"
                    else "आपका काम का इतिहास, ऐप उपयोग और खाता हट जाएगा। यह वापस नहीं होगा।"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    run(null) {
                        try {
                            Repo.deleteAccount(user)
                        } catch (e: FirebaseAuthRecentLoginRequiredException) {
                            throw Exception("डेटा हट गया। खाता हटाने के लिए एक बार साइन आउट करके फिर साइन इन करें और दोबारा कोशिश करें।")
                        }
                        onDeleted()
                    }
                }) { Text("हाँ, हटाएं", color = Red) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("रहने दें") } }
        )
    }
}
