package com.rajeev.testertrack.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Member
import com.rajeev.testertrack.data.Session
import com.rajeev.testertrack.data.TaskStatus
import com.rajeev.testertrack.data.Team
import com.rajeev.testertrack.data.UsageDay
import com.rajeev.testertrack.data.UserProfile
import com.rajeev.testertrack.data.WorkTask
import com.rajeev.testertrack.tracking.UsageAccess
import com.rajeev.testertrack.ui.Runner
import com.rajeev.testertrack.ui.Screen
import com.rajeev.testertrack.ui.components.Chip
import com.rajeev.testertrack.ui.components.EmptyNote
import com.rajeev.testertrack.ui.components.HeaderWithCard
import com.rajeev.testertrack.ui.components.InfoBanner
import com.rajeev.testertrack.ui.components.MenuEntry
import com.rajeev.testertrack.ui.components.SectionCard
import com.rajeev.testertrack.ui.components.TileData
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.todayMs
import com.rajeev.testertrack.ui.usageTotal

@Composable
fun MemberHome(
    user: UserProfile,
    team: Team?,
    me: Member?,
    tasks: List<WorkTask>,
    sessions: List<Session>,
    usageToday: UsageDay?,
    now: Long,
    nav: (Screen) -> Unit,
    run: Runner,
    onDutyToggle: (Member) -> Unit,
    onSignOut: () -> Unit,
) {
    val ctx = LocalContext.current
    val today = Dates.dayKey(now)
    var usageOk by remember { mutableStateOf(UsageAccess.granted(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { usageOk = UsageAccess.granted(ctx) }

    val onDuty = me?.onDuty == true
    val done = tasks.count { it.status == TaskStatus.DONE }
    val working = tasks.count { it.status == TaskStatus.WORKING }
    val pending = tasks.count { it.status == TaskStatus.PENDING }

    LazyColumn(
        Modifier.fillMaxSize().navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            HeaderWithCard(
                teamName = team?.name ?: "",
                userName = user.name,
                photo = user.photo,
                chips = listOf(Chip("टेस्टर", true), Chip(if (onDuty) "ड्यूटी पर" else "ड्यूटी बंद", false)),
                menu = listOf(
                    MenuEntry("मेरे टास्क") { nav(Screen.Tasks(null)) },
                    MenuEntry("काम का इतिहास") { nav(Screen.History(user.uid, user.name)) },
                    MenuEntry("ऐप उपयोग अनुमति") { UsageAccess.openSettings(ctx) },
                    MenuEntry("साइन आउट") { onSignOut() },
                ),
                onAvatar = { nav(Screen.Settings) },
                onSettings = { nav(Screen.Settings) },
                cardTitle = "आज का काम",
                cardValue = Dates.hoursLong(todayMs(sessions, user.uid, today, now)),
                tiles = listOf(
                    TileData("पूरे टास्क", "$done") { nav(Screen.Tasks(TaskStatus.DONE)) },
                    TileData("चालू टास्क", "$working") { nav(Screen.Tasks(TaskStatus.WORKING)) },
                    TileData("बाकी टास्क", "$pending", Purple) { nav(Screen.Tasks(TaskStatus.PENDING)) },
                ),
            )
        }

        // Duty start / stop
        item {
            SectionCard(
                "ड्यूटी",
                trailing = if (onDuty) "${Dates.time(me?.dutyStart ?: 0)} से" else null
            ) {
                Column(Modifier.padding(horizontal = 22.dp)) {
                    if (onDuty) {
                        Text(
                            "चालू: ${Dates.hoursLong((now - (me?.dutyStart ?: now)).coerceAtLeast(0))}",
                            color = Green, fontSize = 18.sp, fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(10.dp))
                    } else {
                        Text("काम शुरू करते समय ड्यूटी चालू करें।", color = Sub, fontSize = 15.sp)
                        Spacer(Modifier.height(10.dp))
                    }
                    Button(
                        onClick = { me?.let(onDutyToggle) },
                        enabled = me != null,
                        colors = ButtonDefaults.buttonColors(containerColor = if (onDuty) Red else Green),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().height(54.dp)
                    ) {
                        Text(if (onDuty) "ड्यूटी खत्म करें" else "ड्यूटी शुरू करें", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        if (!usageOk && team?.apps?.isNotEmpty() == true) {
            item {
                InfoBanner(
                    Icons.Filled.Lock,
                    "ऐप्स में बिताया समय गिनने के लिए “Usage access” में Tester Track को चालू करें। सिर्फ़ एडमिन के ऐप्स, सिर्फ़ ड्यूटी में।"
                ) { UsageAccess.openSettings(ctx) }
            }
        }

        item {
            SectionCard("मेरे टास्क", action = "सभी देखें", onAction = { nav(Screen.Tasks(null)) }) {
                val active = tasks.filter { it.status != TaskStatus.DONE }
                    .sortedWith(compareBy<WorkTask> { if (it.status == TaskStatus.WORKING) 0 else 1 }.thenByDescending { it.createdAt })
                if (active.isEmpty()) EmptyNote("अभी कोई टास्क नहीं — एडमिन के टास्क यहाँ दिखेंगे")
                active.forEachIndexed { i, t ->
                    if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                    TaskRow(t, isAdmin = false, teamId = user.teamId, run = run, showAssignee = false)
                }
            }
        }

        item {
            SectionCard("आज ऐप उपयोग", trailing = Dates.hoursShort(usageTotal(usageToday))) {
                UsageList(
                    usageToday?.perApp() ?: emptyMap(), team?.apps ?: emptyList(),
                    "ड्यूटी के दौरान एडमिन के ऐप्स में बिताया समय यहाँ दिखेगा (हर ~15 मिनट में अपडेट)"
                )
            }
        }

        item {
            SectionCard("इस हफ़्ते", action = "इतिहास", onAction = { nav(Screen.History(user.uid, user.name)) }) {
                Text(
                    "7 दिन में कुल ${Dates.hoursLong(sessions.sumOf { it.durationMs(now) })}",
                    color = Ink, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 22.dp)
                )
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
