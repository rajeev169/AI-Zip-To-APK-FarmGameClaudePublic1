package com.rajeev.testertrack.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Same palette as Samuh Khata's header and cards
val Purple = Color(0xFF5B3A8C)
val PurpleSoft = Color(0xFF7A5BA8)
val Bg = Color(0xFFF6F4FA)
val Tile = Color(0xFFEFE9F7)
val Ink = Color(0xFF1E1A24)
val Sub = Color(0xFF6B6577)
val Line = Color(0xFFE6E1EE)
val InfoBlue = Color(0xFFE8F0FB)
val InfoBlueInk = Color(0xFF1F4FA3)
val LogoBlue = Color(0xFF2F7BE8)
val Green = Color(0xFF2E7D32)
val GreenSoft = Color(0xFFE5F3E6)
val Amber = Color(0xFFB45309)
val AmberSoft = Color(0xFFFDF0DF)
val Red = Color(0xFFC62828)

private val scheme = lightColorScheme(
    primary = Purple,
    onPrimary = Color.White,
    primaryContainer = Tile,
    onPrimaryContainer = Purple,
    secondary = PurpleSoft,
    background = Bg,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Tile,
    onSurfaceVariant = Sub,
    outline = Line,
    error = Red,
)

@Composable
fun TesterTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
