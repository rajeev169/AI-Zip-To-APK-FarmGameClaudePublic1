package com.rajeev.testertrack.ui.screens

import com.rajeev.testertrack.ui.components.ButtonHint
import com.rajeev.testertrack.ui.components.BtnKind
import com.rajeev.testertrack.ui.components.AppButton
import com.rajeev.testertrack.ui.components.fieldColors
import com.rajeev.testertrack.data.tr
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.testertrack.R
import com.rajeev.testertrack.ui.theme.Bg
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.LogoBlue
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub

@Composable
fun LoadingScreen() {
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Purple)
    }
}

@Composable
private fun Logo(size: Int = 96) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.appforge_logo), null, Modifier.size((size * 0.78f).dp))
    }
}

@Composable
fun SignInScreen(onSignIn: (setError: (String) -> Unit) -> Unit) {
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().background(Purple).statusBarsPadding().navigationBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Logo(110)
        Spacer(Modifier.height(24.dp))
        Text("Tester Track", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            tr("टेस्टर का काम, टास्क और ड्यूटी का समय — एक जगह", "Tester work, tasks and duty time — in one place"),
            color = Color.White.copy(alpha = 0.85f), fontSize = 16.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(40.dp))
        Button(
            onClick = {
                error = null; busy = true
                onSignIn { e -> error = e; busy = false }
            },
            enabled = !busy,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Purple),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Purple, strokeWidth = 2.dp)
            else Text(tr("Google से साइन इन करें", "Sign in with Google"), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
        error?.let {
            Spacer(Modifier.height(16.dp))
            Text(it, color = Color(0xFFFFD6D6), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
        Text(
            tr("एडमिन ने जिस Gmail को जोड़ा है, उससे साइन इन करते ही टेस्टर अपने-आप ग्रुप से जुड़ जाता है।", "A tester joins the group automatically by signing in with the Gmail the admin added."),
            color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, textAlign = TextAlign.Center
        )
    }
}

/** Gmail is not added to any team. Tester waits for admin; admin creates a team. */
@Composable
fun NotLinkedScreen(
    email: String,
    googleName: String,
    onRecheck: () -> Unit,
    onCreateTeam: (team: String, name: String, done: (String?) -> Unit) -> Unit,
    onSignOut: () -> Unit,
) {
    var creating by remember { mutableStateOf(false) }
    var team by remember { mutableStateOf("") }
    var name by remember { mutableStateOf(googleName) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(30.dp))
        Logo(84)
        Spacer(Modifier.height(18.dp))
        Text(tr("नमस्ते, $googleName", "Hello, $googleName"), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(email, color = Sub, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))

        Surface(shape = RoundedCornerShape(24.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text(tr("टेस्टर हैं?", "Are you a tester?"), fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Ink)
                Spacer(Modifier.height(6.dp))
                Text(
                    tr("यह Gmail अभी किसी ग्रुप में नहीं जुड़ा है। एडमिन से कहें कि वह ☰ → टेस्टर में आपका Gmail जोड़ दें, फिर नीचे “फिर से जाँचें” दबाएं।", "This Gmail isn't in any group yet. Ask your admin to add it from ☰ → Testers, then tap “Check again” below."),
                    color = Sub, fontSize = 15.sp, lineHeight = 22.sp
                )
                Spacer(Modifier.height(14.dp))
                AppButton(tr("फिर से जाँचें", "Check again"), onRecheck, modifier = Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(14.dp))
        Surface(shape = RoundedCornerShape(24.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text(tr("एडमिन हैं?", "Are you the admin?"), fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Ink)
                Spacer(Modifier.height(6.dp))
                if (!creating) {
                    Text(tr("अपना ग्रुप बनाएं और टेस्टर जोड़ें।", "Create your group and add testers."), color = Sub, fontSize = 15.sp)
                    Spacer(Modifier.height(14.dp))
                    AppButton(tr("नया ग्रुप बनाएं", "Create new group"), { creating = true }, modifier = Modifier.fillMaxWidth(), kind = BtnKind.Outline)
                } else {
                    OutlinedTextField(
                        team, { team = it }, label = { Text(tr("ग्रुप का नाम", "Group name")) },
                        placeholder = { Text(tr("जैसे AppForge Testing", "e.g. AppForge Testing")) }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        name, { name = it }, label = { Text(tr("आपका नाम", "Your name")) }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                    Spacer(Modifier.height(14.dp))
                    AppButton(
                        if (busy) tr("बन रहा है…", "Creating…") else tr("ग्रुप बनाएं (मैं एडमिन हूँ)", "Create group (I'm the admin)"),
                        {
                            busy = true; error = null
                            onCreateTeam(team, name) { e -> busy = false; error = e }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !busy && team.isNotBlank() && name.isNotBlank()
                    )
                    ButtonHint(if (!busy && (team.isBlank() || name.isBlank())) tr("बटन चालू करने के लिए दोनों नाम लिखें", "Type both names to enable this button") else "")
                    error?.let { Text(it, color = Red, modifier = Modifier.padding(top = 8.dp)) }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        AppButton(tr("दूसरे Gmail से साइन इन करें", "Sign in with another Gmail"), onSignOut, modifier = Modifier.fillMaxWidth(), kind = BtnKind.Outline)
    }
}

/** Shown once to the tester: exactly what is and isn't tracked. */
@Composable
fun ConsentScreen(onAccept: () -> Unit, onSignOut: () -> Unit) {
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(22.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text(tr("आप ग्रुप से जुड़ गए हैं 🎉", "You've joined the group 🎉"), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(6.dp))
        Text(tr("शुरू करने से पहले जान लें कि यह ऐप क्या देखता है:", "Before you start, here's what this app sees:"), color = Sub, fontSize = 15.sp)
        Spacer(Modifier.height(18.dp))
        ConsentBlock(
            tr("एडमिन को दिखेगा", "Visible to the admin"), Green, listOf(
                tr("ड्यूटी शुरू और खत्म करने का समय, रोज़ के कुल घंटे", "Duty start and end times, total hours per day"),
                tr("आपके टास्क की स्थिति — बाकी, चालू, पूरे", "Your task status — pending, working, done"),
                tr("सिर्फ़ एडमिन के चुने हुए ऐप्स में बिताया समय, और सिर्फ़ ड्यूटी चालू रहने पर", "Time spent only in the admin's chosen apps, and only while duty is on"),
                tr("आपका नाम, Gmail और प्रोफ़ाइल फ़ोटो", "Your name, Gmail and profile photo"),
            )
        )
        Spacer(Modifier.height(12.dp))
        ConsentBlock(
            tr("कभी नहीं देखा जाता", "Never seen"), Red, listOf(
                tr("आपकी लोकेशन", "Your location"),
                tr("मैसेज, कॉल, फ़ोटो, कैमरा या माइक", "Messages, calls, photos, camera or mic"),
                tr("बाकी सभी ऐप्स का उपयोग", "Usage of all other apps"),
                tr("ड्यूटी बंद होने के बाद कुछ भी", "Anything after duty is off"),
            )
        )
        Spacer(Modifier.height(12.dp))
        Text(
            tr("ड्यूटी चालू रहने पर सूचना-पट्टी में एक नोटिफ़िकेशन दिखता रहेगा। आप अपना डेटा देख सकते हैं और सेटिंग्स से खाता हटा सकते हैं।", "A notification stays visible while duty is on. You can see your own data and delete your account from Settings."),
            color = Sub, fontSize = 14.sp, lineHeight = 20.sp
        )
        Spacer(Modifier.height(24.dp))
        AppButton(tr("मैं सहमत हूँ", "I agree"), { busy = true; onAccept() }, modifier = Modifier.fillMaxWidth(), enabled = !busy)
        Spacer(Modifier.height(10.dp))
        AppButton(tr("सहमत नहीं — साइन आउट करें", "I don't agree — sign out"), onSignOut, modifier = Modifier.fillMaxWidth(), kind = BtnKind.Outline)
    }
}

@Composable
private fun ConsentBlock(title: String, dot: Color, lines: List<String>) {
    Surface(shape = RoundedCornerShape(22.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, color = Ink)
            Spacer(Modifier.height(8.dp))
            lines.forEach {
                Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
                    Box(Modifier.padding(top = 8.dp).size(8.dp).clip(CircleShape).background(dot))
                    Spacer(Modifier.width(10.dp))
                    Text(it, color = Ink, fontSize = 15.sp, lineHeight = 21.sp)
                }
            }
        }
    }
}

@Composable
fun ErrorScreen(message: String, onRetry: () -> Unit, onSignOut: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(tr("कुछ गड़बड़ हुई", "Something went wrong"), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text(message, color = Sub, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        AppButton(tr("फिर कोशिश करें", "Try again"), onRetry, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        AppButton(tr("साइन आउट", "Sign out"), onSignOut, modifier = Modifier.fillMaxWidth(), kind = BtnKind.Outline)
    }
}

/** Shows the last crash so it can be copied and sent for fixing. */
@Composable
fun CrashScreen(text: String, onContinue: () -> Unit) {
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().padding(20.dp)
    ) {
        Text(tr("पिछली बार ऐप बंद हो गया था", "The app closed unexpectedly last time"), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(6.dp))
        Text(tr("नीचे की गड़बड़ी कॉपी करके भेजें, ताकि इसे ठीक किया जा सके।", "Copy the error below and send it so it can be fixed."), color = Sub, fontSize = 15.sp)
        Spacer(Modifier.height(12.dp))
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.weight(1f).fillMaxWidth()) {
            Text(
                text, color = Ink, fontSize = 12.sp, lineHeight = 16.sp,
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(14.dp)
            )
        }
        Spacer(Modifier.height(12.dp))
        AppButton(tr("गड़बड़ी कॉपी करें", "Copy error"), { clip.setText(androidx.compose.ui.text.AnnotatedString(text)) }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        AppButton(tr("आगे बढ़ें", "Continue"), onContinue, modifier = Modifier.fillMaxWidth(), kind = BtnKind.Outline)
    }
}
