package com.rajeev.testertrack.ui.screens

import com.rajeev.testertrack.ui.components.BtnKind
import com.rajeev.testertrack.ui.components.AppButton
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Notif
import com.rajeev.testertrack.data.NotifType
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.TaskStatus
import com.rajeev.testertrack.data.tr
import com.rajeev.testertrack.ui.Runner
import com.rajeev.testertrack.ui.components.EmptyNote
import com.rajeev.testertrack.ui.components.SubTopBar
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.GreenSoft
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.theme.Tile

/** Tester's list of notifications; opens from the bell on the home screen. */
@Composable
fun NotificationsScreen(teamId: String, list: List<Notif>, run: Runner, onOpenTasks: () -> Unit, onBack: () -> Unit) {
    val sorted = list.sortedByDescending { it.createdAt }
    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("सूचनाएं", "Notifications"), onBack)
        val unreadCount = sorted.count { !it.read }
        if (unreadCount > 0) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(tr("$unreadCount नई", "$unreadCount unread"), color = Sub, fontSize = 14.sp, modifier = Modifier.weight(1f))
                AppButton(tr("सब पढ़ा हुआ", "Mark all read"), { run(null) { Repo.markAllRead(teamId, sorted) } },
                    kind = BtnKind.Outline, small = true)
            }
        }
        if (sorted.isEmpty()) {
            Spacer(Modifier.size(16.dp))
            EmptyNote(tr("अभी कोई सूचना नहीं। एडमिन नया टास्क देगा तो यहाँ दिखेगा।", "No notifications yet. New tasks from the admin will show here."))
            return@Column
        }
        Surface(
            shape = RoundedCornerShape(24.dp), color = Color.White,
            modifier = Modifier.padding(14.dp).fillMaxWidth()
        ) {
            LazyColumn(Modifier.navigationBarsPadding()) {
                itemsIndexed(sorted, key = { _, n -> n.id }) { i, n ->
                    if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 16.dp))
                    NotifRow(n) {
                        if (!n.read) run(null) { Repo.markRead(teamId, n.id) }
                        if (n.type != NotifType.DELETED) onOpenTasks()
                    }
                }
            }
        }
    }
}

@Composable
private fun NotifRow(n: Notif, onClick: () -> Unit) {
    val (icon, bg, fg) = when (n.type) {
        NotifType.NEW_TASK -> Triple(Icons.AutoMirrored.Filled.List, Tile, Purple)
        NotifType.STATUS -> Triple(Icons.Filled.CheckCircle, GreenSoft, Green)
        else -> Triple(Icons.Filled.Delete, Color(0xFFFDECEC), Red)
    }
    val title = when (n.type) {
        NotifType.NEW_TASK -> tr("नया टास्क: ${n.title}", "New task: ${n.title}")
        NotifType.STATUS -> tr("एडमिन ने “${n.title}” को ${TaskStatus.label(n.body)} किया", "Admin marked “${n.title}” as ${statusWord(n.body)}")
        else -> tr("टास्क “${n.title}” हटाया गया", "Task “${n.title}” was deleted")
    }
    val sub = listOfNotNull(
        n.body.takeIf { n.type == NotifType.NEW_TASK && it.isNotBlank() },
        Dates.dateTime(n.createdAt)
    ).joinToString(" · ")
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(bg), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = if (n.read) Sub else Ink, fontSize = 15.sp, fontWeight = if (n.read) FontWeight.Normal else FontWeight.SemiBold)
            Text(sub, color = Sub, fontSize = 12.sp)
        }
        if (!n.read) {
            Spacer(Modifier.width(8.dp))
            Box(Modifier.padding(top = 6.dp).size(9.dp).clip(CircleShape).background(Purple))
        }
    }
}

private fun statusWord(s: String) = when (s) {
    TaskStatus.DONE -> "Done"
    TaskStatus.WORKING -> "Working"
    else -> "Pending"
}
