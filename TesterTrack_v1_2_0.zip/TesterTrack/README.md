# Tester Track v1.2.0

Admin + tester app in the Samuh Khata style (purple header, "नमस्ते, Name", white summary card).

- Package: `com.rajeev.testertrack` (name "Tester Track" can be changed later in `res/values/strings.xml`)
- Kotlin + Jetpack Compose, Firebase Auth (Google sign-in) + Firestore, minSdk 26, targetSdk 35

## Features
**Admin (you)**
- Home: team name, नमस्ते + your photo, chips (एडमिन, N टेस्टर)
- Card "आज टीम का काम" with total hours + tiles: पूरे / चालू / बाकी टास्क
- Testers list: duty on/off, today hours, time in your apps, active tasks
- Tester detail: today's hours, task tiles, per-app usage today, 7-day history
- ☰ menu: add/remove testers (by Gmail), tracked apps, new task, all tasks
- Tap any task to change status or delete

**Tester**
- Same header ("टेस्टर", "ड्यूटी पर / बंद")
- Card "आज का काम" + पूरे / चालू / बाकी tiles
- Duty start/stop button (ongoing notification while on duty)
- My tasks with "शुरू करें" / "पूरा करें"
- Sees their own app usage too (transparency)

**Both**: ☰ opens a full Menu page; profile photo + name in ⚙️ Settings; **English / हिंदी** switch only in Settings (English by default, saved per phone); sign out; delete account.

**Tester mobile number**: required once right after joining, editable in Settings. Admin sees it on the tester's page with a **Call** button, and a 📞 button in the home Tester list (opens the dialer).

**Waiting testers**: Gmails the admin added that haven't signed in show on the home screen as "Not signed in yet"; the header chip (e.g. "1 tester · 1 waiting") opens the Testers page.

**Home design (v1.0.6)**: admin and tester homes have a purple background; the header and white work card stay fixed while the list scrolls under a rounded, card-shaped edge; short tile labels (Done / Working / Pending); long names shrink to fit; no floating New task button (New task is in ☰ Menu); Sign out only in Settings.

**App link on tasks**: New task has an optional App link (Play closed-testing or Google Drive APK link); testers get an Open link button. Free — nothing is stored in Firebase Storage.

**Tester notifications**: bell with unread count next to the duty chip, Notifications page (Mark all read). Created when the admin adds a task, changes its status, or deletes it. Phone notifications appear instantly while the app is open and via a background check about every 15 minutes when closed (no paid Firebase plan needed).

**All tasks page (v1.0.7)**: the four filters (All / Done / Working / Pending) share the width so all fit; each task shows its status beside the title, with the date on its own line; divider lines only between tasks.

**New task, several testers (v1.0.8)**: pick testers one by one or tap “All testers”; each picked tester gets their own copy of the task and their own notification; Add stays off until there is a title and at least one tester.

**Three-layer home (v1.0.9)**, admin and tester: fixed purple background; a full-height scrolling layer of cards; a floating top layer (profile pic, menu, settings, chips, bell and the work card) that stays in place while the cards scroll behind it, with a soft purple strip behind the greeting while scrolled.

**Clear buttons (v1.1.0)**: one button style everywhere. Main actions are solid purple (Start duty green, End duty / Delete solid red), second actions are white with a purple border, risky ones white with a red border. A button that is off turns grey, with a small grey line under it saying what to do to turn it on. Tester chips in New task are white boxes with a border and turn solid purple with ✓ when picked; text boxes have a darker outline on white. Covers New task, Testers, Tracked apps, tasks, All tasks, Settings, Duty, Usage access banner, Notifications (Mark all read), mobile number page and sign-in/setup pages.

**App watch (v1.2.0)** — for the admin's **tracked apps** only (☰ → Tracked apps); no other app is looked at or uploaded:
- **Install / uninstall alerts**: instant (a few seconds). Like Family Shield, a small background service on the tester's phone listens for install/remove, and a "Watching for tester alerts" service on the admin's phone shows the alert the moment it arrives. Uninstall message includes how long it lasted, e.g. “My App (day 9 · opened 7 days)”.
- **Daily open count**: Day 1 = the real install day; the tester page shows “Day N”, “opened X of N days”, and a row of dots for the last 14 days (green = opened that day) plus “Opened today”. Counting stops when the app is uninstalled and the record stays as “Uninstalled · lasted N days”. Re-installing starts again at Day 1. Needs the tester's **Usage access** (existing banner); the admin sees a warning if it is off. Android keeps about a week of history, so counts are filled in right after install and catch up if the phone was off.
- **Missed-day reminder**: from 9 am you get one notification per tester, e.g. “Aman didn't open an app yesterday — My App (day 6 · missed 2 days in a row)”, with a **Call** button on the notification. Skips the install day itself, sends once per app per day, and needs the tester's Usage access. On first setup it starts from the next day, so you aren't flooded.
- **Tester home**: the Duty card and "On duty" chip are replaced by **Testing days (1–14)** — one row of numbered circles per tracked app: green = opened that day, red = day passed without opening, outlined = today (open it to turn green), grey = not reached. The header chip shows "Day N".
- Runs on and off duty while the tester is signed in (notification: “On duty” or “Your admin's chosen apps … are being checked”). Services restart after reboot; a 15-min background job is the fallback.
- Apps the admin adds later are not announced as "new" if already installed; apps removed from the list stop being watched.
- Testers must accept the updated notice once. **Update `firestore.rules`** (new `installed` collection; testers may create app-install notices for the admin only).
- If battery saver kills the service, set Tester Track to "Unrestricted" battery on that phone.

**Icon**: AppForge logo (launcher icon, login page, header fallback) + white silhouette notification icon.

**Linking**: admin creates the group with its name (editable in Settings) and adds testers by Gmail. The tester signs in with that Gmail and joins directly, then sees a one-time "what is tracked" consent screen. A Gmail that isn't added gets a "Recheck" / "Create team (admin)" screen, so a tester can't become admin by accident.

**App usage**: counted only for the package names you add in "ट्रैक होने वाले ऐप्स", only while duty is on, uploaded every ~15 min and on duty stop. Tester must allow "Usage access" once (app shows a banner).

## Firebase setup (one time)
1. Firebase Console → new project **Tester Track**.
2. Add Android app, package `com.rajeev.testertrack`, add the **same SHA-1** as your other apps.
3. Authentication → Sign-in method → enable **Google**.
4. Firestore Database → Create (production mode) → Rules → paste `firestore.rules` from this zip → Publish.
5. Download `google-services.json` → put it in the **`app/`** folder of this project.
6. Zip and push to your build repo as usual.

Without `google-services.json` the app still builds, but sign-in shows a "file missing" message.

## Play Store notes
- Play Console: declare Foreground service "special use" (reason is in the manifest). Declare in Data safety: name, email, photo, app activity (app usage of selected apps), whether chosen apps are installed and the days they were opened (on and off duty), collected for app functionality, deletable in-app.
- Privacy policy should say: whether the admin's chosen apps are installed and on which days they were opened (days only) is checked, on and off duty, and shown to the admin; no location, no messages/calls/photos; usage counted only for the admin's apps during duty, with the tester's consent.
