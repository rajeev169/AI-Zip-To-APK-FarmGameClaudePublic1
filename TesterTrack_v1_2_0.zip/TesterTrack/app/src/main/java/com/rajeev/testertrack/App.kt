package com.rajeev.testertrack

import android.app.Application
import android.content.Context
import com.rajeev.testertrack.tracking.DutyNotice
import java.io.File

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
        com.rajeev.testertrack.data.Lang.load(this)
        try { DutyNotice.createChannel(this); com.rajeev.testertrack.tracking.TaskAlerts.createChannel(this) } catch (_: Exception) {}
    }
}

/** Saves the last crash so the app can show it on the next launch (easy to copy & send). */
object CrashLog {
    private fun file(c: Context) = File(c.filesDir, "last_crash.txt")

    fun install(c: Context) {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { file(c).writeText(android.util.Log.getStackTraceString(e).take(6000)) } catch (_: Exception) {}
            prev?.uncaughtException(t, e)
        }
    }

    fun read(c: Context): String? = file(c).takeIf { it.exists() }?.readText()?.takeIf { it.isNotBlank() }
    fun clear(c: Context) { file(c).delete() }
}
