package com.rajeev.testertrack

import com.rajeev.testertrack.data.tr
import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import com.google.firebase.FirebaseApp
import com.rajeev.testertrack.ui.screens.CrashScreen
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import com.rajeev.testertrack.data.AuthState
import com.rajeev.testertrack.data.GoogleAuth
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.tracking.DutyNotice
import com.rajeev.testertrack.tracking.DutyPrefs
import com.rajeev.testertrack.tracking.Duty
import com.rajeev.testertrack.ui.AppRoot
import com.rajeev.testertrack.ui.screens.ConsentScreen
import com.rajeev.testertrack.ui.screens.ErrorScreen
import com.rajeev.testertrack.ui.screens.LoadingScreen
import com.rajeev.testertrack.ui.screens.NotLinkedScreen
import com.rajeev.testertrack.ui.screens.SignInScreen
import com.rajeev.testertrack.ui.theme.TesterTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var state by mutableStateOf<AuthState>(AuthState.Loading)

    /** Set when the app was opened by tapping a task notification. */
    private var openNotifications by mutableStateOf(false)

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        if (intent.getStringExtra("open") == "notifications") openNotifications = true
    }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun refresh() {
        if (FirebaseApp.getApps(this).isEmpty()) {
            state = AuthState.Error(
                tr("Firebase सेट नहीं है (google-services.json नहीं मिली)।\n\n", "Firebase is not set up (google-services.json not found).\n\n") +
                    tr("Firebase प्रोजेक्ट से google-services.json डाउनलोड करके project के app/ फ़ोल्डर में डालें, फिर APK दोबारा बनाएं।", "Download google-services.json from your Firebase project, put it in the project's app/ folder, then build the APK again.")
            )
            return
        }
        state = AuthState.Loading
        lifecycleScope.launch {
            state = try { Repo.resolve() } catch (e: Exception) { AuthState.Error(e.message ?: tr("कुछ गड़बड़ हुई", "Something went wrong")) }
        }
    }

    fun signOut() {
        if (FirebaseApp.getApps(this).isEmpty()) { refresh(); return }
        lifecycleScope.launch {
            val ctx = this@MainActivity
            if (DutyPrefs.sessionId(ctx).isNotBlank()) {
                // End duty first so hours are not left running
                val s = state
                if (s is AuthState.Ready) {
                    try { Duty.stop(ctx, s.user, DutyPrefs.sessionId(ctx)) } catch (_: Exception) {}
                }
            }
            DutyPrefs.clear(ctx)
            com.rajeev.testertrack.tracking.TaskAlerts.clear(ctx)
            com.rajeev.testertrack.tracking.InstallWatch.clear(ctx)
            com.rajeev.testertrack.tracking.DutyService.stop(ctx)
            com.rajeev.testertrack.tracking.AdminAlertService.stop(ctx)
            DutyNotice.hide(ctx)
            Duty.cancelWorker(ctx)
            GoogleAuth.signOut(ctx)
            state = AuthState.SignedOut
        }
    }

    fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openNotifications = intent?.getStringExtra("open") == "notifications"
        // white status-bar icons over the purple header
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        refresh()
        setContent {
            TesterTheme {
                val scope = rememberCoroutineScope()
                var crash by remember { mutableStateOf(CrashLog.read(this@MainActivity)) }
                val c = crash
                if (c != null) {
                    CrashScreen(c) { CrashLog.clear(this@MainActivity); crash = null }
                    return@TesterTheme
                }
                when (val s = state) {
                    AuthState.Loading -> LoadingScreen()
                    AuthState.SignedOut -> SignInScreen(onSignIn = { setError ->
                        scope.launch {
                            val err = GoogleAuth.signIn(this@MainActivity)
                            if (err == null) refresh() else setError(err)
                        }
                    })
                    is AuthState.NotLinked -> NotLinkedScreen(
                        email = s.email,
                        googleName = s.name,
                        onRecheck = { refresh() },
                        onCreateTeam = { team, name, done ->
                            scope.launch {
                                try { Repo.createTeam(team, name); refresh() } catch (e: Exception) { done(e.message) }
                            }
                        },
                        onSignOut = { signOut() },
                    )
                    is AuthState.NeedsConsent -> ConsentScreen(
                        onAccept = {
                            scope.launch {
                                try { Repo.giveConsent(s.user.uid) } catch (_: Exception) {}
                                askNotificationPermission()
                                refresh()
                            }
                        },
                        onSignOut = { signOut() },
                    )
                    is AuthState.Ready -> AppRoot(
                        initialUser = s.user,
                        onSignOut = { signOut() },
                        onRemoved = { refresh() },
                        askNotificationPermission = { askNotificationPermission() },
                        openNotifications = openNotifications,
                    )
                    is AuthState.Error -> ErrorScreen(s.message, onRetry = { refresh() }, onSignOut = { signOut() })
                }
            }
        }
    }
}
