package com.rajeev.testertrack.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

sealed class AuthState {
    data object Loading : AuthState()
    data object SignedOut : AuthState()
    /** Signed in, but this Gmail is not added to any team yet */
    data class NotLinked(val email: String, val name: String) : AuthState()
    /** Tester joined a team but has not accepted the tracking notice yet */
    data class NeedsConsent(val user: UserProfile) : AuthState()
    data class Ready(val user: UserProfile) : AuthState()
    data class Error(val message: String) : AuthState()
}

object Repo {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    private fun users() = db.collection("users")
    private fun invites() = db.collection("invites")
    fun team(teamId: String) = db.collection("teams").document(teamId)
    private fun members(teamId: String) = team(teamId).collection("members")
    private fun tasks(teamId: String) = team(teamId).collection("tasks")
    private fun sessions(teamId: String) = team(teamId).collection("sessions")
    private fun usage(teamId: String) = team(teamId).collection("usage")
    private fun notifs(teamId: String) = team(teamId).collection("notifs")
    private fun installed(teamId: String) = team(teamId).collection("installed")

    private fun myEmail() = (auth.currentUser?.email ?: "").trim().lowercase()

    // ---------------- sign-in resolution ----------------

    /** Decides where a signed-in user goes: team setup, consent, or home. */
    suspend fun resolve(): AuthState {
        val fu = auth.currentUser ?: return AuthState.SignedOut
        val email = myEmail()
        val googleName = fu.displayName ?: email.substringBefore("@")
        return try {
            val uDoc = users().document(fu.uid).get().await()
            if (uDoc.exists()) {
                val u = uDoc.toUser()
                if (u.teamId.isNotBlank()) {
                    if (u.role == Role.ADMIN) {
                        val exists = try { team(u.teamId).get().await().exists() } catch (e: Exception) { false }
                        if (exists) return AuthState.Ready(u)
                    } else {
                        val m = members(u.teamId).document(u.uid).get().await()
                        if (m.exists()) {
                            return if (u.consentAt > 0 && u.consentV >= CONSENT_VERSION) AuthState.Ready(u) else AuthState.NeedsConsent(u)
                        }
                    }
                    // Removed from team, or team deleted -> unlink
                    users().document(fu.uid).update(mapOf("teamId" to "", "role" to "")).await()
                }
            }
            // Auto-link: has the admin added this Gmail?
            val inv = invites().document(email).get().await()
            if (inv.exists()) {
                val teamId = inv.getString("teamId") ?: ""
                if (teamId.isNotBlank()) {
                    joinTeam(teamId, googleName, uDoc)
                    val u = users().document(fu.uid).get().await().toUser()
                    return if (u.consentAt > 0 && u.consentV >= CONSENT_VERSION) AuthState.Ready(u) else AuthState.NeedsConsent(u)
                }
            }
            AuthState.NotLinked(email, googleName)
        } catch (e: Exception) {
            AuthState.Error(e.message ?: tr("कुछ गड़बड़ हुई", "Something went wrong"))
        }
    }

    private suspend fun joinTeam(teamId: String, googleName: String, existing: DocumentSnapshot) {
        val fu = auth.currentUser ?: return
        val name = existing.getString("name")?.takeIf { it.isNotBlank() } ?: googleName
        val photo = existing.getString("photo") ?: ""
        val phone = existing.getString("phone") ?: ""
        val now = System.currentTimeMillis()
        members(teamId).document(fu.uid).set(
            mapOf(
                "name" to name,
                "email" to myEmail(),
                "photo" to photo,
                "phone" to phone,
                "onDuty" to false,
                "dutyStart" to 0L,
                "sessionId" to "",
                "joinedAt" to now,
                "lastSeen" to now,
            )
        ).await()
        users().document(fu.uid).set(
            mapOf(
                "name" to name,
                "email" to myEmail(),
                "photo" to photo,
                "role" to Role.MEMBER,
                "teamId" to teamId,
                "consentAt" to 0L,
            ),
            SetOptions.merge()
        ).await()
    }

    suspend fun createTeam(teamName: String, myName: String) {
        val fu = auth.currentUser ?: return
        val ref = db.collection("teams").document()
        val photo = users().document(fu.uid).get().await().getString("photo") ?: ""
        ref.set(
            mapOf(
                "name" to teamName.trim(),
                "adminUid" to fu.uid,
                "adminName" to myName.trim(),
                "adminPhoto" to photo,
                "apps" to emptyList<Map<String, String>>(),
                "createdAt" to System.currentTimeMillis(),
            )
        ).await()
        users().document(fu.uid).set(
            mapOf(
                "name" to myName.trim(),
                "email" to myEmail(),
                "photo" to photo,
                "role" to Role.ADMIN,
                "teamId" to ref.id,
                "consentAt" to System.currentTimeMillis(),
                "consentV" to CONSENT_VERSION,
            ),
            SetOptions.merge()
        ).await()
    }

    suspend fun giveConsent(uid: String) {
        users().document(uid).update(mapOf("consentAt" to System.currentTimeMillis(), "consentV" to CONSENT_VERSION)).await()
    }

    // ---------------- profile ----------------

    suspend fun updateProfile(user: UserProfile, name: String, photo: String, phone: String = user.phone) {
        val data = mutableMapOf<String, Any>("name" to name.trim(), "photo" to photo)
        if (user.role != Role.ADMIN) data["phone"] = Phone.clean(phone)
        users().document(user.uid).set(data, SetOptions.merge()).await()
        if (user.teamId.isBlank()) return
        if (user.role == Role.ADMIN) {
            team(user.teamId).update(mapOf("adminName" to name.trim(), "adminPhoto" to photo)).await()
        } else {
            members(user.teamId).document(user.uid).update(data).await()
        }
    }

    /** Tester's mobile number, saved to profile and to the group so the admin can call. */
    suspend fun savePhone(user: UserProfile, phone: String) {
        val p = Phone.clean(phone)
        users().document(user.uid).set(mapOf("phone" to p), SetOptions.merge()).await()
        if (user.teamId.isNotBlank() && user.role != Role.ADMIN) {
            members(user.teamId).document(user.uid).update("phone", p).await()
        }
    }

    suspend fun updateTeamName(teamId: String, name: String) {
        team(teamId).update("name", name.trim()).await()
    }

    // ---------------- testers (admin) ----------------

    suspend fun addInvite(teamId: String, teamName: String, email: String, name: String) {
        val fu = auth.currentUser ?: return
        invites().document(email.trim().lowercase()).set(
            mapOf(
                "teamId" to teamId,
                "teamName" to teamName,
                "adminUid" to fu.uid,
                "name" to name.trim(),
                "addedAt" to System.currentTimeMillis(),
            )
        ).await()
    }

    suspend fun removeTester(teamId: String, email: String, uid: String?) {
        invites().document(email.trim().lowercase()).delete().await()
        if (uid != null) {
            try { installed(teamId).document(uid).delete().await() } catch (_: Exception) {}
            members(teamId).document(uid).delete().await()
        }
    }

    // ---------------- tracked apps (admin) ----------------

    suspend fun addApp(teamId: String, name: String, pkg: String) {
        team(teamId).update("apps", FieldValue.arrayUnion(mapOf("name" to name.trim(), "pkg" to pkg.trim())))
            .await()
    }

    suspend fun removeApp(teamId: String, app: TrackedApp) {
        team(teamId).update("apps", FieldValue.arrayRemove(mapOf("name" to app.name, "pkg" to app.pkg))).await()
    }

    // ---------------- tasks ----------------

    suspend fun addTask(teamId: String, title: String, appName: String, note: String, link: String, assignee: Member) {
        tasks(teamId).add(
            mapOf(
                "title" to title.trim(),
                "appName" to appName.trim(),
                "note" to note.trim(),
                "link" to normalizeLink(link),
                "assigneeUid" to assignee.uid,
                "assigneeName" to assignee.name,
                "status" to TaskStatus.PENDING,
                "createdAt" to System.currentTimeMillis(),
                "startedAt" to 0L,
                "doneAt" to 0L,
            )
        ).await()
        notify(teamId, assignee.uid, NotifType.NEW_TASK, title.trim(), appName.trim())
    }

    /** Admin changed a tester's task: status update + notification to that tester. */
    suspend fun adminSetTaskStatus(teamId: String, task: WorkTask, status: String) {
        setTaskStatus(teamId, task.id, status)
        if (task.assigneeUid.isNotBlank()) {
            notify(teamId, task.assigneeUid, NotifType.STATUS, task.title, status)
        }
    }

    /** Admin deleted a tester's task: delete + notification to that tester. */
    suspend fun adminDeleteTask(teamId: String, task: WorkTask) {
        deleteTask(teamId, task.id)
        if (task.assigneeUid.isNotBlank()) {
            notify(teamId, task.assigneeUid, NotifType.DELETED, task.title, "")
        }
    }

    // ---------------- notifications (to testers) ----------------

    private suspend fun notify(teamId: String, toUid: String, type: String, title: String, body: String) {
        try {
            notifs(teamId).add(
                mapOf(
                    "toUid" to toUid,
                    "type" to type,
                    "title" to title,
                    "body" to body,
                    "createdAt" to System.currentTimeMillis(),
                    "read" to false,
                    "pushed" to false,
                )
            ).await()
        } catch (_: Exception) {
            // a missing notification must never block the task change itself
        }
    }

    fun notifsQuery(teamId: String, uid: String) = notifs(teamId).whereEqualTo("toUid", uid)

    fun notifsFlow(teamId: String, uid: String) =
        notifs(teamId).whereEqualTo("toUid", uid).listFlow { it.toNotif() }

    suspend fun markRead(teamId: String, id: String) {
        notifs(teamId).document(id).update("read", true).await()
    }

    suspend fun markAllRead(teamId: String, list: List<Notif>) {
        val unread = list.filter { !it.read }
        if (unread.isEmpty()) return
        val batch = db.batch()
        unread.forEach { batch.update(notifs(teamId).document(it.id), "read", true) }
        batch.commit().await()
    }

    /** Notifications not yet shown on the phone; marks them as shown. */
    suspend fun takeUnpushed(teamId: String, uid: String): List<Notif> {
        val list = notifs(teamId).whereEqualTo("toUid", uid).get().await().documents
            .map { it.toNotif() }.filter { !it.pushed }.sortedBy { it.createdAt }
        if (list.isEmpty()) return list
        val batch = db.batch()
        list.forEach { batch.update(notifs(teamId).document(it.id), "pushed", true) }
        batch.commit().await()
        return list
    }

    suspend fun setTaskStatus(teamId: String, taskId: String, status: String) {
        val now = System.currentTimeMillis()
        val data = mutableMapOf<String, Any>("status" to status)
        when (status) {
            TaskStatus.WORKING -> { data["startedAt"] = now; data["doneAt"] = 0L }
            TaskStatus.DONE -> data["doneAt"] = now
            TaskStatus.PENDING -> { data["startedAt"] = 0L; data["doneAt"] = 0L }
        }
        tasks(teamId).document(taskId).update(data).await()
    }

    suspend fun deleteTask(teamId: String, taskId: String) {
        tasks(teamId).document(taskId).delete().await()
    }

    // ---------------- installed apps (tester -> admin) ----------------

    /**
     * Writes the tester's launcher-app list. [baseline] = first check: replaces the whole list and marks every
     * app as "already there" (since = 0), so nothing is announced. Otherwise only the changes are merged in.
     */
    suspend fun writeInstalled(
        teamId: String, uid: String, now: Long, usageOk: Boolean,
        names: Map<String, String>, starts: Map<String, Long>,
        added: Set<String>, silent: Set<String>, removed: Set<String>, stale: Set<String>, baseline: Boolean,
    ) {
        val ref = installed(teamId).document(uid)
        if (baseline) {
            val all = names.map { (pkg, name) -> encodePkg(pkg) to mapOf("n" to name, "t" to 0L, "s" to (starts[pkg] ?: now), "w" to maxOf(starts[pkg] ?: now, now - 7L * 24 * 60 * 60 * 1000)) }.toMap()
            ref.set(mapOf("uid" to uid, "checkedAt" to now, "ua" to usageOk, "apps" to all)).await()
            return
        }
        val changes = HashMap<String, Any>()
        // newly installed: fresh record (a re-install starts again at Day 1)
        added.forEach { pkg ->
            changes[encodePkg(pkg)] = mapOf(
                "n" to (names[pkg] ?: pkg), "t" to now, "s" to (starts[pkg] ?: now), "w" to (starts[pkg] ?: now),
                "u" to FieldValue.delete(), "d" to FieldValue.delete(),
            )
        }
        // admin just started tracking an app that was already there: keep it quiet
        silent.forEach { pkg ->
            changes[encodePkg(pkg)] = mapOf(
                "n" to (names[pkg] ?: pkg), "t" to 0L, "s" to (starts[pkg] ?: now),
                "w" to maxOf(starts[pkg] ?: now, now - 7L * 24 * 60 * 60 * 1000), "u" to FieldValue.delete(),
            )
        }
        // uninstalled: keep the record (days so far) and mark when it ended
        removed.forEach { pkg -> changes[encodePkg(pkg)] = mapOf("u" to now) }
        // admin stopped tracking it: drop the record
        stale.forEach { pkg -> changes[encodePkg(pkg)] = FieldValue.delete() }
        ref.set(mapOf("uid" to uid, "checkedAt" to now, "ua" to usageOk, "apps" to changes), SetOptions.merge()).await()
    }

    /** Adds the days the tester opened each app (safe to repeat: days are added to a set). */
    suspend fun addOpenDays(teamId: String, uid: String, now: Long, usageOk: Boolean, days: Map<String, Set<String>>) {
        val changes = days.map { (pkg, d) -> encodePkg(pkg) to mapOf("d" to FieldValue.arrayUnion(*d.toTypedArray())) }.toMap()
        installed(teamId).document(uid)
            .set(mapOf("uid" to uid, "checkedAt" to now, "ua" to usageOk, "apps" to changes), SetOptions.merge()).await()
    }

    /** Only refreshes the "last checked" time (nothing changed on the phone). */
    suspend fun touchInstalled(teamId: String, uid: String, now: Long, usageOk: Boolean) {
        installed(teamId).document(uid)
            .set(mapOf("uid" to uid, "checkedAt" to now, "ua" to usageOk), SetOptions.merge()).await()
    }

    /** One notification to the admin listing the app names (max 6 shown, then "+N"). */
    suspend fun notifyAdminApps(teamId: String, fromUid: String, fromName: String, type: String, names: List<String>, phone: String = "") {
        if (names.isEmpty()) return
        val adminUid = team(teamId).get().await().getString("adminUid") ?: return
        val sorted = names.sortedBy { it.lowercase() }
        val shown = sorted.take(6).joinToString(", ") + if (sorted.size > 6) " +${sorted.size - 6}" else ""
        notifs(teamId).add(
            mapOf(
                "toUid" to adminUid,
                "fromUid" to fromUid,
                "phone" to phone,
                "type" to type,
                "title" to fromName,
                "body" to shown,
                "createdAt" to System.currentTimeMillis(),
                "read" to false,
                "pushed" to false,
            )
        ).await()
    }

    fun installedFlow(teamId: String, uid: String) =
        installed(teamId).document(uid).docFlow { it.toInstalled() }

    // ---------------- duty sessions ----------------

    /** Returns new session id */
    suspend fun startDuty(user: UserProfile): Pair<String, Long> {
        val now = System.currentTimeMillis()
        val ref = sessions(user.teamId).document()
        ref.set(
            mapOf(
                "uid" to user.uid,
                "name" to user.name,
                "start" to now,
                "end" to 0L,
                "date" to Dates.dayKey(now),
            )
        ).await()
        members(user.teamId).document(user.uid).update(
            mapOf("onDuty" to true, "dutyStart" to now, "sessionId" to ref.id, "lastSeen" to now)
        ).await()
        return ref.id to now
    }

    suspend fun stopDuty(teamId: String, uid: String, sessionId: String) {
        val now = System.currentTimeMillis()
        if (sessionId.isNotBlank()) {
            sessions(teamId).document(sessionId).update("end", now).await()
        }
        members(teamId).document(uid).update(
            mapOf("onDuty" to false, "dutyStart" to 0L, "sessionId" to "", "lastSeen" to now)
        ).await()
    }

    /** Overwrites this session's numbers for the day (safe to call repeatedly). */
    suspend fun writeUsage(teamId: String, uid: String, date: String, sessionId: String, perPkg: Map<String, Long>) {
        val encoded = perPkg.mapKeys { encodePkg(it.key) }
        usage(teamId).document("${uid}_$date").set(
            mapOf(
                "uid" to uid,
                "date" to date,
                "sessions" to mapOf(sessionId to encoded),
                "updatedAt" to System.currentTimeMillis(),
            ),
            SetOptions.merge()
        ).await()
        members(teamId).document(uid).update("lastSeen", System.currentTimeMillis()).await()
    }

    // ---------------- account ----------------

    suspend fun deleteAccount(user: UserProfile) {
        val fu = auth.currentUser ?: return
        if (user.teamId.isNotBlank()) {
            if (user.role == Role.ADMIN) {
                val inv = invites().whereEqualTo("adminUid", fu.uid).get().await()
                inv.documents.forEach { it.reference.delete().await() }
                team(user.teamId).delete().await()
            } else {
                val s = sessions(user.teamId).whereEqualTo("uid", user.uid).get().await()
                s.documents.forEach { it.reference.delete().await() }
                val u = usage(user.teamId).whereEqualTo("uid", user.uid).get().await()
                u.documents.forEach { it.reference.delete().await() }
                try { installed(user.teamId).document(user.uid).delete().await() } catch (_: Exception) {}
                members(user.teamId).document(user.uid).delete().await()
            }
        }
        users().document(fu.uid).delete().await()
        fu.delete().await()
    }

    // ---------------- live streams ----------------

    fun userFlow(uid: String) = users().document(uid).docFlow { it.toUser() }
    fun teamFlow(teamId: String) = team(teamId).docFlow { it.toTeam() }
    fun memberFlow(teamId: String, uid: String) = members(teamId).document(uid).docFlow { it.toMember() }
    fun membersFlow(teamId: String) = members(teamId).listFlow { it.toMember() }
    fun invitesFlow(adminUid: String) = invites().whereEqualTo("adminUid", adminUid).listFlow { it.toInvite() }
    fun tasksFlow(teamId: String) = tasks(teamId).listFlow { it.toTask() }

    /** Sessions from [fromDate] (yyyy-MM-dd) onward, whole team. Filter by uid in UI. */
    fun sessionsFlow(teamId: String, fromDate: String) =
        sessions(teamId).whereGreaterThanOrEqualTo("date", fromDate).listFlow { it.toSession() }

    fun usageFlow(teamId: String, date: String) =
        usage(teamId).whereEqualTo("date", date).listFlow { it.toUsage() }

    /** Member-safe variants (rules let testers read only their own sessions/usage). */
    fun mySessionsFlow(teamId: String, uid: String) =
        sessions(teamId).whereEqualTo("uid", uid).listFlow { it.toSession() }

    fun myUsageFlow(teamId: String, uid: String, date: String) =
        usage(teamId).document("${uid}_$date").docFlow { it.toUsage() }
}

private fun <T> DocumentReference.docFlow(map: (DocumentSnapshot) -> T): Flow<T?> = callbackFlow {
    val reg = addSnapshotListener { s, e ->
        if (e != null) { trySend(null); return@addSnapshotListener }
        trySend(if (s != null && s.exists()) map(s) else null)
    }
    awaitClose { reg.remove() }
}

private fun <T> Query.listFlow(map: (DocumentSnapshot) -> T): Flow<List<T>> = callbackFlow {
    val reg = addSnapshotListener { s, e ->
        if (e != null) { trySend(emptyList()); return@addSnapshotListener }
        trySend(s?.documents?.map(map) ?: emptyList())
    }
    awaitClose { reg.remove() }
}
