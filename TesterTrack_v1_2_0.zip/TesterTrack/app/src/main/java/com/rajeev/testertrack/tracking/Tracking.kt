package com.rajeev.testertrack.tracking

import com.rajeev.testertrack.data.tr
import android.Manifest
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.rajeev.testertrack.MainActivity
import com.rajeev.testertrack.R
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.UserProfile
import com.rajeev.testertrack.data.Notif
import com.rajeev.testertrack.data.NotifType
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.TimeUnit

/** Small local store so the background worker knows the running duty session. */
object DutyPrefs {
    private const val FILE = "duty"
    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun save(c: Context, teamId: String, uid: String, sessionId: String, start: Long) {
        p(c).edit().putString("teamId", teamId).putString("uid", uid)
            .putString("sessionId", sessionId).putLong("start", start).apply()
    }

    fun clear(c: Context) {
        p(c).edit().remove("teamId").remove("uid").remove("sessionId").remove("start").apply()
    }

    fun sessionId(c: Context) = p(c).getString("sessionId", "") ?: ""
    fun teamId(c: Context) = p(c).getString("teamId", "") ?: ""
    fun uid(c: Context) = p(c).getString("uid", "") ?: ""
    fun start(c: Context) = p(c).getLong("start", 0L)

    fun setPackages(c: Context, pkgs: Set<String>) {
        p(c).edit().putStringSet("pkgs", pkgs).apply()
    }

    fun packages(c: Context): Set<String> = p(c).getStringSet("pkgs", emptySet()) ?: emptySet()
}

object UsageAccess {
    // Raw event codes (ACTIVITY_RESUMED=1, ACTIVITY_PAUSED=2, ACTIVITY_STOPPED=23) so this works on Android 8+
    private const val EV_RESUMED = 1
    private const val EV_PAUSED = 2
    private const val EV_STOPPED = 23

    fun granted(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openSettings(c: Context) {
        val i = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.startActivity(i) } catch (_: Exception) {
            c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /**
     * Foreground time (ms) per package between [from] and [to], counted ONLY for [pkgs]
     * (the admin's own apps). Nothing else on the phone is read or uploaded.
     */
    fun measure(c: Context, from: Long, to: Long, pkgs: Set<String>): Map<String, Long> {
        if (pkgs.isEmpty() || !granted(c) || to <= from) return emptyMap()
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(from, to)
        val openSince = HashMap<String, Long>()
        val total = HashMap<String, Long>()
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            if (pkg !in pkgs) continue
            when (e.eventType) {
                EV_RESUMED -> openSince[pkg] = e.timeStamp
                EV_PAUSED, EV_STOPPED -> {
                    val s = openSince.remove(pkg)
                    if (s != null) total[pkg] = (total[pkg] ?: 0L) + (e.timeStamp - s).coerceAtLeast(0)
                }
            }
        }
        // still open at the end of the window
        openSince.forEach { (pkg, s) -> total[pkg] = (total[pkg] ?: 0L) + (to - s).coerceAtLeast(0) }
        return total.filterValues { it > 0 }
    }
}

object DutyNotice {
    const val CHANNEL = "duty"
    private const val ID = 7001

    fun createChannel(c: Context) {
        val ch = NotificationChannel(CHANNEL, tr("ड्यूटी स्थिति", "Duty status"), NotificationManager.IMPORTANCE_LOW).apply {
            description = tr("ड्यूटी चालू होने पर दिखता है", "Shown while duty is on")
        }
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    const val NOTIF_ID = 7001

    fun build(c: Context, start: Long): android.app.Notification {
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val onDuty = start > 0L
        return NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(
                if (onDuty) tr("ड्यूटी चालू है · ${Dates.time(start)} से", "On duty · since ${Dates.time(start)}")
                else "Tester Track"
            )
            .setContentText(
                if (onDuty) tr("काम का समय, चुने गए ऐप्स का उपयोग, इंस्टॉल और रोज़ खोलना देखा जा रहा है", "Work time, selected app usage, installs and daily opens are being checked")
                else tr("एडमिन के चुने ऐप्स का इंस्टॉल और रोज़ खोलना देखा जा रहा है", "Your admin's chosen apps (install and daily opens) are being checked")
            )
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }

    fun show(c: Context, start: Long) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        try { NotificationManagerCompat.from(c).notify(ID, build(c, start)) } catch (_: SecurityException) {}
    }

    fun hide(c: Context) = NotificationManagerCompat.from(c).cancel(ID)
}

/** Every ~15 minutes while on duty: upload usage of the admin's apps for this session. */
class UsageWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        val sessionId = DutyPrefs.sessionId(c)
        if (sessionId.isBlank()) { Duty.cancelWorker(c); return Result.success() }
        return try {
            Duty.syncUsage(c)
            DutyNotice.show(c, DutyPrefs.start(c))
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object Duty {
    private const val WORK = "usage_sync"

    fun scheduleWorker(c: Context) {
        val req = PeriodicWorkRequestBuilder<UsageWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun cancelWorker(c: Context) = WorkManager.getInstance(c).cancelUniqueWork(WORK)

    suspend fun syncUsage(c: Context) {
        val sessionId = DutyPrefs.sessionId(c)
        val teamId = DutyPrefs.teamId(c)
        val uid = DutyPrefs.uid(c)
        val start = DutyPrefs.start(c)
        if (sessionId.isBlank() || teamId.isBlank() || uid.isBlank()) return
        val now = System.currentTimeMillis()
        val usage = UsageAccess.measure(c, start, now, DutyPrefs.packages(c))
        Repo.writeUsage(teamId, uid, Dates.dayKey(start), sessionId, usage)
    }

    suspend fun start(c: Context, user: UserProfile) {
        val (sid, start) = Repo.startDuty(user)
        DutyPrefs.save(c, user.teamId, user.uid, sid, start)
        DutyNotice.show(c, start)
        scheduleWorker(c)
        DutyService.start(c)
    }

    suspend fun stop(c: Context, user: UserProfile, sessionIdFromServer: String) {
        val sid = DutyPrefs.sessionId(c).ifBlank { sessionIdFromServer }
        try { if (DutyPrefs.sessionId(c).isNotBlank()) syncUsage(c) } catch (_: Exception) {}
        Repo.stopDuty(user.teamId, user.uid, sid)
        DutyPrefs.clear(c)
        cancelWorker(c)
        DutyService.start(c)   // keeps running off duty; refreshes its notification to the idle text
    }

    /** Make local state match the server (e.g. after reinstall or a second phone). */
    fun restoreIfNeeded(c: Context, user: UserProfile, serverSessionId: String, serverStart: Long, onDuty: Boolean) {
        if (onDuty && serverSessionId.isNotBlank() && DutyPrefs.sessionId(c) != serverSessionId) {
            DutyPrefs.save(c, user.teamId, user.uid, serverSessionId, serverStart)
            DutyNotice.show(c, serverStart)
            scheduleWorker(c)
            DutyService.start(c)
        } else if (!onDuty && DutyPrefs.sessionId(c).isNotBlank()) {
            DutyPrefs.clear(c)
            cancelWorker(c)
            DutyService.start(c)
        }
    }
}

/**
 * For the admin's TRACKED apps only (☰ → Tracked apps), on the tester's phone:
 *  - tells the admin when one is installed or uninstalled,
 *  - counts the days the tester opened it: Day 1 = install day, until it is uninstalled.
 * Days only (never what was done inside the app). Runs while the tester is signed in, on or off duty.
 * Instant via [DutyService]; also by a 15-minute background job and whenever the app opens.
 */
object InstallWatch {
    private val lock = Mutex()
    private const val TOUCH_EVERY_MS = 10 * 60_000L
    private const val DAY_MS = 24L * 60 * 60 * 1000
    private const val WORK = "install_watch"
    private const val MISSED_ALERT_HOUR = 9      // tell the admin about yesterday's missed open from 9 am
    private fun p(c: Context) = c.getSharedPreferences("installwatch", Context.MODE_PRIVATE)

    private data class Known(val name: String, val start: Long)

    fun setTarget(c: Context, teamId: String, uid: String, name: String, phone: String = "") {
        val changed = p(c).getString("uid", "") != uid || p(c).getString("teamId", "") != teamId
        val e = p(c).edit()
        if (changed) e.clear()   // new person on this phone -> fresh baseline
        e.putString("teamId", teamId).putString("uid", uid).putString("name", name).putString("phone", phone).apply()
    }

    fun active(c: Context) = !p(c).getString("uid", "").isNullOrBlank()

    fun clear(c: Context) {
        p(c).edit().clear().apply()
        WorkManager.getInstance(c).cancelUniqueWork(WORK)
    }

    /** Fallback every ~15 min in case the service was stopped by the phone. */
    fun schedule(c: Context) {
        val req = PeriodicWorkRequestBuilder<WatchWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    @Suppress("DEPRECATION")
    private fun firstInstall(pm: android.content.pm.PackageManager, pkg: String): Long =
        try { pm.getPackageInfo(pkg, 0).firstInstallTime } catch (_: Exception) { System.currentTimeMillis() }

    /** Only the admin's tracked packages that are installed (and have a launcher icon). */
    private fun trackedInstalled(c: Context, tracked: Set<String>): Map<String, Known> {
        if (tracked.isEmpty()) return emptyMap()
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first in tracked }
            .associate { (pkg, label) -> pkg to Known(label, firstInstall(pm, pkg)) }
    }

    // stored as "pkg<TAB>name<TAB>start" so the name and Day-1 time are still known after the app is removed
    private fun readKnown(c: Context): Map<String, Known>? =
        p(c).getStringSet("known", null)?.associate { e ->
            val parts = e.split('\t')
            parts[0] to Known(parts.getOrNull(1) ?: parts[0], parts.getOrNull(2)?.toLongOrNull() ?: 0L)
        }

    private fun save(c: Context, apps: Map<String, Known>, tracked: Set<String>, now: Long) {
        p(c).edit()
            .putStringSet("known", apps.map { (k, v) -> "$k\t${v.name}\t${v.start}" }.toSet())
            .putStringSet("tracked", tracked)
            .putLong("touched", now)
            .apply()
    }

    private fun markMissedSeen(c: Context, pkgs: Set<String>) {
        val y = Dates.daysAgoKey(1)
        val e = p(c).edit()
        pkgs.forEach { e.putString("missed_$it", y) }
        e.apply()
    }

    private fun sentDays(c: Context, pkg: String): Set<String> = HashSet(p(c).getStringSet("sent_$pkg", emptySet()) ?: emptySet())

    /** Days each installed tracked app was opened since the last check (needs Usage access). */
    private fun collectOpens(c: Context, installedPkgs: Set<String>, starts: Map<String, Long>, now: Long): Map<String, Set<String>> {
        val last = p(c).getLong("opensFrom", 0L)
        val from = if (last > 0) maxOf(last - 60 * 60_000L, now - 8 * DAY_MS) else now - 7 * DAY_MS   // Android keeps ~a week
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = try { usm.queryEvents(from, now) } catch (_: Exception) { return emptyMap() }
        val found = HashMap<String, MutableSet<String>>()
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType != 1) continue                    // ACTIVITY_RESUMED = the app was opened / brought to front
            val pkg = e.packageName ?: continue
            if (pkg !in installedPkgs) continue
            if (e.timeStamp < (starts[pkg] ?: 0L)) continue   // before this install
            found.getOrPut(pkg) { HashSet() }.add(Dates.dayKey(e.timeStamp))
        }
        return found
    }

    /** Uploads newly seen open-days. Returns true if something was written. */
    private suspend fun pushOpens(c: Context, teamId: String, uid: String, now: Long, usageOk: Boolean, installed: Map<String, Known>): Boolean {
        if (!usageOk || installed.isEmpty()) return false
        val found = collectOpens(c, installed.keys, installed.mapValues { it.value.start }, now)
        val fresh = HashMap<String, Set<String>>()
        found.forEach { (pkg, days) -> val n = days - sentDays(c, pkg); if (n.isNotEmpty()) fresh[pkg] = n }
        if (fresh.isNotEmpty()) {
            Repo.addOpenDays(teamId, uid, now, usageOk, fresh)
            fresh.forEach { (pkg, n) -> p(c).edit().putStringSet("sent_$pkg", sentDays(c, pkg) + n).apply() }
        }
        p(c).edit().putLong("opensFrom", now).apply()
        return fresh.isNotEmpty()
    }

    /**
     * "Didn't open yesterday" reminder: from 9 am, one notification per tester listing each tracked app that was not
     * opened yesterday (with how many days in a row). Once per app per day. Skips the install day itself.
     */
    private suspend fun checkMissed(c: Context, teamId: String, uid: String, name: String, now: Long, usageOk: Boolean, current: Map<String, Known>) {
        if (!usageOk || current.isEmpty()) return
        if (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) < MISSED_ALERT_HOUR) return
        val yesterday = Dates.daysAgoKey(1)
        val lines = ArrayList<String>()
        val pkgs = ArrayList<String>()
        current.forEach { (pkg, k) ->
            if (p(c).getString("missed_$pkg", "") == yesterday) return@forEach      // already told today
            val installDay = Dates.dayKey(k.start)
            if (installDay >= yesterday) return@forEach                              // not a full day since install yet
            val opened = sentDays(c, pkg)
            if (yesterday in opened) return@forEach
            var streak = 0
            for (back in 1..14) {
                val key = Dates.daysAgoKey(back)
                if (key <= installDay || key in opened) break
                streak++
            }
            val how = if (streak >= 2) "missed $streak days in a row" else "not opened yesterday"
            lines += "${k.name} (day ${Dates.dayNumber(k.start, now)} · $how)"
            pkgs += pkg
        }
        if (lines.isEmpty()) return
        Repo.notifyAdminApps(teamId, uid, name, NotifType.APP_MISSED, lines, p(c).getString("phone", "") ?: "")
        val e = p(c).edit()
        pkgs.forEach { e.putString("missed_$it", yesterday) }
        e.apply()
    }

    suspend fun sync(c: Context) = lock.withLock {
        val teamId = p(c).getString("teamId", "") ?: ""
        val uid = p(c).getString("uid", "") ?: ""
        val name = (p(c).getString("name", "") ?: "").ifBlank { "Tester" }
        if (teamId.isBlank() || uid.isBlank()) return@withLock
        val tracked = DutyPrefs.packages(c)
        val now = System.currentTimeMillis()
        val usageOk = UsageAccess.granted(c)
        val current = trackedInstalled(c, tracked)
        val names = current.mapValues { it.value.name }
        val starts = current.mapValues { it.value.start }
        val known = readKnown(c)
        if (known == null) {                                     // first check: quiet baseline
            Repo.writeInstalled(teamId, uid, now, usageOk, names, starts, emptySet(), emptySet(), emptySet(), emptySet(), baseline = true)
            pushOpens(c, teamId, uid, now, usageOk, current)
            markMissedSeen(c, current.keys)   // first setup: start reminding from the next day
            save(c, current, tracked, now)
            return@withLock
        }
        val prevTracked = p(c).getStringSet("tracked", null) ?: tracked
        val newlyTracked = tracked - prevTracked                  // admin just added this app: don't announce it
        val knownTracked = known.filterKeys { it in tracked }
        val added = (current.keys - knownTracked.keys) - newlyTracked
        val silent = (current.keys - knownTracked.keys) intersect newlyTracked
        val removed = knownTracked.keys - current.keys
        val stale = known.keys - tracked                          // admin stopped tracking these
        val changed = added.isNotEmpty() || silent.isNotEmpty() || removed.isNotEmpty() || stale.isNotEmpty()
        if (changed) {
            // numbers for the uninstall message, taken before anything is reset
            val removedText = removed.map { pkg ->
                val k = knownTracked[pkg]
                val day = Dates.dayNumber(k?.start ?: 0L, now)
                "${k?.name ?: pkg} (day $day · opened ${sentDays(c, pkg).size})"
            }
            added.forEach { p(c).edit().remove("sent_$it").apply() }   // re-install starts counting again
            markMissedSeen(c, silent)
            Repo.writeInstalled(teamId, uid, now, usageOk, names, starts, added, silent, removed, stale, baseline = false)
            if (added.isNotEmpty()) Repo.notifyAdminApps(teamId, uid, name, NotifType.APP_ADDED, added.map { names[it] ?: it })
            if (removed.isNotEmpty()) Repo.notifyAdminApps(teamId, uid, name, NotifType.APP_REMOVED, removedText)
        }
        val wrote = pushOpens(c, teamId, uid, now, usageOk, current)
        checkMissed(c, teamId, uid, name, now, usageOk, current)
        if (!changed && !wrote && now - p(c).getLong("touched", 0L) > TOUCH_EVERY_MS) {
            Repo.touchInstalled(teamId, uid, now, usageOk)
        }
        save(c, current, tracked, if (changed || wrote || now - p(c).getLong("touched", 0L) > TOUCH_EVERY_MS) now else p(c).getLong("touched", now))
    }
}

class WatchWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        InstallWatch.sync(applicationContext)
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }
}

/** Phone notifications: testers get task changes; the admin also gets tester app-install alerts. */
object TaskAlerts {
    const val CHANNEL = "tasks"
    const val CHANNEL_APPS = "apps"
    private const val WORK = "notif_check"
    private fun p(c: Context) = c.getSharedPreferences("alerts", Context.MODE_PRIVATE)

    fun createChannel(c: Context) {
        val ch = NotificationChannel(CHANNEL, tr("टास्क सूचनाएं", "Task notifications"), NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = tr("एडमिन से नए या बदले हुए टास्क", "New or changed tasks from the admin")
        }
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(ch)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_APPS, tr("ऐप इंस्टॉल सूचनाएं", "App install alerts"), NotificationManager.IMPORTANCE_HIGH).apply {
                description = tr("टेस्टर के फ़ोन में ऐप जुड़ने या हटने पर", "When a tester installs or removes an app")
            }
        )
    }

    /** Remember who to check for, so the background check works when the app is closed. */
    fun setTarget(c: Context, teamId: String, uid: String) {
        p(c).edit().putString("teamId", teamId).putString("uid", uid).apply()
    }

    fun teamId(c: Context) = p(c).getString("teamId", "") ?: ""
    fun uid(c: Context) = p(c).getString("uid", "") ?: ""
    fun setAdminWatch(c: Context, on: Boolean) { p(c).edit().putBoolean("adminWatch", on).apply() }
    fun adminWatch(c: Context) = p(c).getBoolean("adminWatch", false)

    fun clear(c: Context) {
        p(c).edit().clear().apply()
        WorkManager.getInstance(c).cancelUniqueWork(WORK)
    }

    fun schedule(c: Context) {
        val req = PeriodicWorkRequestBuilder<NotifWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    /** Fetch notifications not yet shown and post them to the notification bar. */
    suspend fun check(c: Context) {
        val teamId = p(c).getString("teamId", "") ?: ""
        val uid = p(c).getString("uid", "") ?: ""
        if (teamId.isBlank() || uid.isBlank()) return
        Repo.takeUnpushed(teamId, uid).forEach { show(c, it) }
    }

    private fun show(c: Context, n: Notif) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val (title, text) = phoneText(n)
        val pi = PendingIntent.getActivity(
            c, 1, Intent(c, MainActivity::class.java).putExtra("open", "notifications")
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = NotificationCompat.Builder(c, if (NotifType.isApp(n.type)) CHANNEL_APPS else CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .apply {
                // one tap to call the tester and remind them
                if (n.type == NotifType.APP_MISSED && n.phone.length == 10) {
                    val dial = PendingIntent.getActivity(
                        c, n.id.hashCode(),
                        Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:+91${n.phone}")),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    addAction(0, tr("कॉल करें", "Call"), dial)
                }
            }
            .build()
        try { NotificationManagerCompat.from(c).notify(n.id.hashCode(), notif) } catch (_: SecurityException) {}
    }

    fun phoneText(n: Notif): Pair<String, String> = when (n.type) {
        NotifType.NEW_TASK -> tr("एडमिन से नया टास्क", "New task from admin") to n.title
        NotifType.STATUS -> tr("टास्क ${com.rajeev.testertrack.data.TaskStatus.label(n.body)} किया गया", "Task marked ${statusEn(n.body)}") to n.title
        NotifType.DELETED -> tr("टास्क हटाया गया", "Task deleted") to n.title
        NotifType.APP_ADDED -> tr("${n.title} ने नया ऐप इंस्टॉल किया", "${n.title} installed an app") to n.body
        NotifType.APP_REMOVED -> tr("${n.title} ने ऐप हटाया", "${n.title} removed an app") to n.body
        NotifType.APP_MISSED -> tr("${n.title} ने कल ऐप नहीं खोला", "${n.title} didn't open an app yesterday") to n.body
        else -> "Tester Track" to n.title
    }

    fun statusEn(s: String) = when (s) {
        com.rajeev.testertrack.data.TaskStatus.DONE -> "Done"
        com.rajeev.testertrack.data.TaskStatus.WORKING -> "Working"
        else -> "Pending"
    }
}

class NotifWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        TaskAlerts.check(applicationContext)
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }
}
