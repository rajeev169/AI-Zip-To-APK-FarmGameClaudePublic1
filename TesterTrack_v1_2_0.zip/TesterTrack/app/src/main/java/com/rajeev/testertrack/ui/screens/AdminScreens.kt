package com.rajeev.testertrack.ui.screens

import com.rajeev.testertrack.ui.components.fieldColors
import com.rajeev.testertrack.data.tr
import androidx.compose.foundation.clickable
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Invite
import com.rajeev.testertrack.data.InstalledSnapshot
import com.rajeev.testertrack.data.Phone
import com.rajeev.testertrack.data.Member
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.Session
import com.rajeev.testertrack.data.TaskStatus
import com.rajeev.testertrack.data.Team
import com.rajeev.testertrack.data.UsageDay
import com.rajeev.testertrack.data.UserProfile
import com.rajeev.testertrack.data.WorkTask
import com.rajeev.testertrack.ui.Runner
import com.rajeev.testertrack.ui.Screen
import com.rajeev.testertrack.ui.components.Avatar
import com.rajeev.testertrack.ui.components.Chip
import com.rajeev.testertrack.ui.components.EmptyNote
import com.rajeev.testertrack.ui.components.FixedHome
import com.rajeev.testertrack.ui.components.AppButton
import com.rajeev.testertrack.ui.components.BtnKind
import com.rajeev.testertrack.ui.components.ButtonHint
import com.rajeev.testertrack.ui.components.IconBox
import com.rajeev.testertrack.ui.components.SelectChip
import com.rajeev.testertrack.ui.components.InfoBanner
import com.rajeev.testertrack.ui.components.Pill
import com.rajeev.testertrack.ui.components.SectionCard
import com.rajeev.testertrack.ui.components.SubTopBar
import com.rajeev.testertrack.ui.components.SummaryCard
import com.rajeev.testertrack.ui.components.TileData
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.GreenSoft
import com.rajeev.testertrack.ui.theme.GreenLine
import com.rajeev.testertrack.ui.theme.RedLine
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.theme.Tile
import com.rajeev.testertrack.ui.todayMs
import com.rajeev.testertrack.ui.usageTotal

// ======================= ADMIN HOME =======================

@Composable
fun AdminHome(
    user: UserProfile,
    team: Team?,
    members: List<Member>,
    invites: List<Invite>,
    tasks: List<WorkTask>,
    sessions: List<Session>,
    usageToday: List<UsageDay>,
    now: Long,
    nav: (Screen) -> Unit,
    run: Runner,
    unread: Int = 0,
    onBell: () -> Unit = {},
) {
    val today = Dates.dayKey(now)
    val done = tasks.count { it.status == TaskStatus.DONE }
    val working = tasks.count { it.status == TaskStatus.WORKING }
    val pending = tasks.count { it.status == TaskStatus.PENDING }
    val waiting = waitingInvites(members, invites)

    FixedHome(
        teamName = team?.name ?: "",
        userName = user.name,
        photo = user.photo,
        chips = listOf(
            Chip(tr("एडमिन", "Admin"), true),
            Chip(testerCountText(members.size, waiting.size), false) { nav(Screen.Testers) },
        ),
        onMenu = { nav(Screen.Menu) },
        onAvatar = { nav(Screen.Settings) },
        onSettings = { nav(Screen.Settings) },
        cardTitle = tr("आज ग्रुप का काम", "Group work today"),
        cardValue = Dates.hoursLong(todayMs(sessions, null, today, now)),
        tiles = listOf(
            TileData(tr("पूरे", "Done"), "$done") { nav(Screen.Tasks(TaskStatus.DONE)) },
            TileData(tr("चालू", "Working"), "$working") { nav(Screen.Tasks(TaskStatus.WORKING)) },
            TileData(tr("बाकी", "Pending"), "$pending", Purple) { nav(Screen.Tasks(TaskStatus.PENDING)) },
        ),
        bell = { com.rajeev.testertrack.ui.components.BellButton(unread, onBell) },
    ) {

            if (members.isEmpty() && waiting.isEmpty()) {
                item {
                    InfoBanner(Icons.Filled.Person, tr("अभी कोई टेस्टर नहीं है। टेस्टर का Gmail जोड़ें — वह साइन इन करते ही अपने-आप जुड़ जाएगा।", "No testers yet. Add your tester's Gmail — they join automatically when they sign in.")) {
                        nav(Screen.Testers)
                    }
                }
            }
            if (team != null && team.apps.isEmpty()) {
                item {
                    InfoBanner(Icons.Filled.Info, tr("अपने ऐप्स जोड़ें, ताकि ड्यूटी के दौरान टेस्टर का उनमें बिताया समय गिना जा सके।", "Add your apps so the tester's time in them is counted during duty.")) {
                        nav(Screen.Apps)
                    }
                }
            }

            if (members.isNotEmpty() || waiting.isNotEmpty()) {
                item {
                    SectionCard(tr("टेस्टर", "Testers"), action = tr("जोड़ें", "Add"), onAction = { nav(Screen.Testers) }) {
                        members.sortedByDescending { it.onDuty }.forEachIndexed { i, m ->
                            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                            TesterRow(
                                m = m,
                                todayWork = todayMs(sessions, m.uid, today, now),
                                appTime = usageTotal(usageToday.firstOrNull { it.uid == m.uid }),
                                working = tasks.count { it.assigneeUid == m.uid && it.status == TaskStatus.WORKING },
                                pending = tasks.count { it.assigneeUid == m.uid && it.status == TaskStatus.PENDING },
                                onClick = { nav(Screen.TesterDetail(m.uid)) }
                            )
                        }
                        waiting.forEachIndexed { i, inv ->
                            if (i > 0 || members.isNotEmpty()) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                            WaitingRow(inv) { nav(Screen.Testers) }
                        }
                    }
                }
            }

            item {
                SectionCard(tr("हाल के टास्क", "Recent tasks"), action = tr("सभी देखें", "See all"), onAction = { nav(Screen.Tasks(null)) }) {
                    val recent = tasks.sortedByDescending { maxOf(it.createdAt, it.startedAt, it.doneAt) }.take(5)
                    if (recent.isEmpty()) EmptyNote(tr("कोई टास्क नहीं। ☰ मेनू → नया टास्क से जोड़ें।", "No tasks yet. Add one from ☰ Menu → New task."))
                    recent.forEachIndexed { i, t ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        TaskRow(t, isAdmin = true, teamId = user.teamId, run = run)
                    }
                }
            }
    }
}

/** Gmails the admin added that have not signed in yet. */
fun waitingInvites(members: List<Member>, invites: List<Invite>): List<Invite> {
    val joined = members.map { it.email.lowercase() }.toSet()
    return invites.filter { it.email !in joined }
}

/** Opens the phone dialer with the tester's number (no call permission needed). */
fun dialTester(ctx: android.content.Context, phone: String) {
    val i = android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:+91$phone"))
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

@Composable
private fun TesterRow(m: Member, todayWork: Long, appTime: Long, working: Int, pending: Int, onClick: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(start = 22.dp, end = 10.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(m.photo, m.name, 48.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.name, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.width(8.dp))
                if (m.onDuty) Pill(tr("ड्यूटी पर", "On duty"), Green, GreenSoft) else Pill(tr("ड्यूटी बंद", "Off duty"), Sub, Tile)
            }
            Text(
                tr("आज ${Dates.hoursShort(todayWork)} · ऐप्स में ${Dates.hoursShort(appTime)}", "Today ${Dates.hoursShort(todayWork)} · in apps ${Dates.hoursShort(appTime)}"),
                color = Sub, fontSize = 13.sp
            )
            Text(tr("$working चालू · $pending बाकी टास्क", "$working working · $pending pending tasks"), color = Sub, fontSize = 13.sp)
        }
        if (m.phone.isNotBlank()) {
            IconButton(onClick = { dialTester(ctx, m.phone) }) {
                Box(
                    Modifier.size(40.dp).clip(androidx.compose.foundation.shape.CircleShape).background(GreenSoft),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Phone, tr("कॉल करें", "Call"), tint = Green, modifier = Modifier.size(20.dp)) }
            }
        } else {
            Text("›", color = Sub, fontSize = 26.sp, modifier = Modifier.padding(end = 12.dp))
        }
    }
}

@Composable
private fun WaitingRow(inv: Invite, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar("", inv.name.ifBlank { inv.email }, 48.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                inv.name.ifBlank { inv.email.substringBefore("@") }, color = Sub, fontSize = 17.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(inv.email, color = Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Pill(tr("अभी साइन इन नहीं किया", "Not signed in yet"), Sub, Tile)
        }
        Text("›", color = Sub, fontSize = 26.sp)
    }
}

// ======================= ADD TASK =======================

@Composable
@OptIn(ExperimentalLayoutApi::class)
fun AddTaskDialog(
    team: Team?,
    members: List<Member>,
    onDismiss: () -> Unit,
    onAdd: (title: String, app: String, note: String, link: String, testers: List<Member>) -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var app by remember { mutableStateOf(team?.apps?.firstOrNull()?.name ?: "") }
    var note by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    // several testers can be picked; each gets their own copy of the task
    var picked by remember { mutableStateOf(setOf<String>()) }
    val allPicked = members.isNotEmpty() && picked.size == members.size

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("नया टास्क", "New task")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (members.isEmpty()) {
                    Text(tr("पहले ☰ → टेस्टर जोड़ें। टेस्टर के साइन इन करने के बाद ही टास्क दिया जा सकता है।", "First add a tester from ☰. You can assign tasks once the tester has signed in."), color = Red)
                    return@Column
                }
                OutlinedTextField(
                    title, { title = it }, label = { Text(tr("क्या करना है", "What to do")) },
                    placeholder = { Text(tr("जैसे: लॉगिन और फ़ोटो अपलोड जाँचें", "e.g. Check login and photo upload")) },
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                Spacer(Modifier.height(12.dp))
                Text(tr("ऐप", "App"), color = Sub, fontSize = 14.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (team?.apps?.map { it.name } ?: emptyList()).plus(tr("अन्य", "Other")).forEach { n ->
                        val key = if (n == tr("अन्य", "Other")) "" else n
                        SelectChip(n, app == key, { app = key }, showTick = false)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(tr("किसे देना है", "Assign to"), color = Sub, fontSize = 14.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SelectChip(
                        tr("सभी टेस्टर", "All testers"), allPicked,
                        { picked = if (allPicked) emptySet() else members.map { it.uid }.toSet() }
                    )
                    members.forEach { m ->
                        val on = m.uid in picked
                        SelectChip(m.name, on, { picked = if (on) picked - m.uid else picked + m.uid })
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    when (picked.size) {
                        0 -> tr("कम से कम एक टेस्टर चुनें", "Select at least one tester")
                        1 -> tr("1 टेस्टर चुना", "1 tester selected")
                        else -> tr("${picked.size} टेस्टर चुने", "${picked.size} testers selected")
                    },
                    color = Purple, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    link, { link = it.trim() }, label = { Text(tr("ऐप लिंक (वैकल्पिक)", "App link (optional)")) },
                    placeholder = { Text(tr("Play टेस्टिंग या Drive लिंक", "Play testing or Drive link")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                Text(
                    tr("Google Play closed-testing लिंक या Google Drive APK लिंक पेस्ट करें", "Paste a Google Play closed-testing link or a Google Drive APK link"),
                    color = Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    note, { note = it }, label = { Text(tr("नोट (वैकल्पिक)", "Note (optional)")) },
                    modifier = Modifier.fillMaxWidth(), minLines = 2, colors = fieldColors())
                Spacer(Modifier.height(4.dp))
                ButtonHint(
                    when {
                        title.isBlank() -> tr("जोड़ें चालू करने के लिए काम लिखें", "Type what to do to enable Add")
                        picked.isEmpty() -> tr("जोड़ें चालू करने के लिए कम से कम एक टेस्टर चुनें", "Pick at least one tester to enable Add")
                        else -> ""
                    }
                )
            }
        },
        confirmButton = {
            AppButton(
                tr("जोड़ें", "Add"),
                onClick = { onAdd(title, app, note, link, members.filter { it.uid in picked }) },
                enabled = title.isNotBlank() && picked.isNotEmpty(),
                small = true,
            )
        },
        dismissButton = { AppButton(tr("रद्द करें", "Cancel"), onDismiss, kind = BtnKind.Outline, small = true) }
    )
}

// ======================= TESTER DETAIL =======================

@Composable
fun TesterDetailScreen(
    member: Member,
    team: Team?,
    tasks: List<WorkTask>,
    sessions: List<Session>,
    usageToday: UsageDay?,
    installed: InstalledSnapshot?,
    now: Long,
    nav: (Screen) -> Unit,
    run: Runner,
    onBack: () -> Unit,
) {
    val today = Dates.dayKey(now)
    Column(Modifier.fillMaxSize()) {
        SubTopBar(member.name, onBack)
        LazyColumn(
            Modifier.navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(Modifier.height(14.dp))
                Row(Modifier.padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(member.photo, member.name, 56.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(member.email, color = Sub, fontSize = 14.sp)
                        Text(
                            if (member.onDuty) tr("ड्यूटी पर · ${Dates.time(member.dutyStart)} से", "On duty · since ${Dates.time(member.dutyStart)}")
                            else tr("ड्यूटी बंद", "Off duty") + if (member.lastSeen > 0) tr(" · आखिरी बार ${Dates.dateTime(member.lastSeen)}", " · last seen ${Dates.dateTime(member.lastSeen)}") else "",
                            color = if (member.onDuty) Green else Sub, fontWeight = FontWeight.SemiBold, fontSize = 15.sp
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                PhoneCallRow(member.phone)
                Spacer(Modifier.height(14.dp))
                SummaryCard(
                    tr("आज का काम", "Today's work"),
                    Dates.hoursLong(todayMs(sessions, member.uid, today, now)),
                    listOf(
                        TileData(tr("पूरे", "Done"), "${tasks.count { it.status == TaskStatus.DONE }}") { nav(Screen.Tasks(TaskStatus.DONE, member.uid)) },
                        TileData(tr("चालू", "Working"), "${tasks.count { it.status == TaskStatus.WORKING }}") { nav(Screen.Tasks(TaskStatus.WORKING, member.uid)) },
                        TileData(tr("बाकी", "Pending"), "${tasks.count { it.status == TaskStatus.PENDING }}", Purple) { nav(Screen.Tasks(TaskStatus.PENDING, member.uid)) },
                    )
                )
            }
            item {
                SectionCard(tr("आज ऐप उपयोग", "App usage today"), trailing = Dates.hoursShort(usageTotal(usageToday))) {
                    UsageList(
                        usageToday?.perApp() ?: emptyMap(), team?.apps ?: emptyList(),
                        if (team?.apps.isNullOrEmpty()) tr("☰ → ट्रैक होने वाले ऐप्स में अपने ऐप्स जोड़ें", "Add your apps in ☰ → Tracked apps")
                        else tr("आज ड्यूटी के दौरान आपके ऐप्स नहीं खोले गए (या टेस्टर ने उपयोग अनुमति नहीं दी)", "Your apps weren't opened during duty today (or the tester hasn't allowed usage access)")
                    )
                }
            }
            item { InstalledAppsCard(installed, team?.apps ?: emptyList(), now) }
            item {
                SectionCard(tr("इस हफ़्ते", "This week"), action = tr("पूरा इतिहास", "Full history"), onAction = { nav(Screen.History(member.uid, member.name)) }) {
                    Text(
                        tr("7 दिन में कुल ${Dates.hoursLong(sessions.sumOf { it.durationMs(now) })} · ${sessions.map { it.date }.distinct().size} दिन काम", "${Dates.hoursLong(sessions.sumOf { it.durationMs(now) })} in 7 days · worked ${sessions.map { it.date }.distinct().size} days"),
                        color = Ink, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 22.dp)
                    )
                }
            }
            item {
                SectionCard(tr("चल रहे टास्क", "Active tasks"), action = tr("सभी देखें", "See all"), onAction = { nav(Screen.Tasks(null, member.uid)) }) {
                    val active = tasks.filter { it.status != TaskStatus.DONE }.sortedByDescending { it.createdAt }
                    if (active.isEmpty()) EmptyNote(tr("कोई बाकी या चालू टास्क नहीं", "No pending or working tasks"))
                    active.forEachIndexed { i, t ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        TaskRow(t, isAdmin = true, teamId = team?.id ?: "", run = run, showAssignee = false)
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

/** The admin's tracked apps on this tester's phone: Day N since install, days opened, until uninstall. */
@Composable
private fun InstalledAppsCard(installed: InstalledSnapshot?, tracked: List<com.rajeev.testertrack.data.TrackedApp>, now: Long) {
    val weekAgo = now - 7L * 24 * 60 * 60 * 1000
    val have = installed?.apps.orEmpty().associateBy { it.pkg }
    SectionCard(
        tr("आपके ऐप्स इस फ़ोन में", "Your apps on this phone"),
        trailing = if (tracked.isNotEmpty()) "${tracked.count { (have[it.pkg]?.uninstalledAt ?: 1L) == 0L }}/${tracked.size}" else null
    ) {
        if (tracked.isEmpty()) {
            EmptyNote(tr("☰ → ट्रैक होने वाले ऐप्स में ऐप जोड़ें। इंस्टॉल, अनइंस्टॉल और रोज़ खोलने के दिन यहाँ दिखेंगे।", "Add apps in ☰ → Tracked apps. Install, uninstall and daily opens will show here."))
            return@SectionCard
        }
        Text(
            if (installed != null && installed.checkedAt > 0)
                tr("आखिरी जाँच ${Dates.dateTime(installed.checkedAt)}", "Last checked ${Dates.dateTime(installed.checkedAt)}")
            else tr("अभी जाँच नहीं हुई। टेस्टर के ऐप खोलते ही दिखेगा।", "Not checked yet. Shows once the tester opens Tester Track."),
            color = Sub, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 22.dp)
        )
        if (installed != null && !installed.usageOk) {
            Text(
                tr("टेस्टर ने Usage access नहीं दिया, इसलिए ऐप खोलने के दिन गिने नहीं जा सकते।", "Usage access is off on the tester's phone, so opened days can't be counted."),
                color = Red, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 2.dp)
            )
        }
        Spacer(Modifier.height(6.dp))
        tracked.forEachIndexed { i, app ->
            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
            val a = have[app.pkg]
            val gone = a != null && a.uninstalledAt > 0
            val dayNo = if (a == null) 0 else Dates.dayNumber(a.start, if (gone) a.uninstalledAt else now)
            val openedDays = a?.opened?.size ?: 0
            Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(app.name.ifBlank { app.pkg }, color = Ink, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            when {
                                a == null -> app.pkg
                                gone -> tr("हटाया: ${Dates.dateTime(a.uninstalledAt)} · $dayNo दिन चला, $openedDays दिन खोला", "Uninstalled ${Dates.dateTime(a.uninstalledAt)} · lasted $dayNo days, opened $openedDays")
                                else -> tr("इंस्टॉल: ${Dates.dateTime(a.start)} · $dayNo में से $openedDays दिन खोला", "Installed ${Dates.dateTime(a.start)} · opened $openedDays of $dayNo days")
                            },
                            color = Sub, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    when {
                        a == null -> Pill(tr("इंस्टॉल नहीं", "Not installed"), Sub, Tile)
                        gone -> Pill(tr("हटाया गया", "Uninstalled"), Red, Color(0xFFFDECEC))
                        else -> Pill(tr("दिन $dayNo", "Day $dayNo"), Green, GreenSoft)
                    }
                }
                if (a != null && !gone) {
                    // Day 1..14 from install: green = opened, red = missed, grey = not reached / unknown
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        for (st in com.rajeev.testertrack.data.testingDays(a, now)) {
                            Box(
                                Modifier.size(11.dp).clip(androidx.compose.foundation.shape.CircleShape).background(
                                    when (st) {
                                        com.rajeev.testertrack.data.DayState.OPENED -> Green
                                        com.rajeev.testertrack.data.DayState.MISSED -> Red
                                        else -> Line
                                    }
                                )
                            )
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (Dates.dayKey(now) in a.opened) tr("आज खोला ✓", "Opened today ✓") else tr("आज नहीं खोला", "Not opened today"),
                            color = if (Dates.dayKey(now) in a.opened) Green else Sub, fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PhoneCallRow(phone: String) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Row(
        Modifier.padding(horizontal = 14.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Color.White).padding(start = 18.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Phone, null, tint = if (phone.isBlank()) Sub else Green, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(
            if (phone.isBlank()) tr("नंबर नहीं जोड़ा", "No number added") else Phone.pretty(phone),
            color = if (phone.isBlank()) Sub else Ink, fontSize = 17.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        if (phone.isNotBlank()) {
            Button(
                onClick = { dialTester(ctx, phone) },
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Green),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Filled.Phone, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(tr("कॉल करें", "Call"))
            }
        }
    }
}

// ======================= TESTERS (add / remove) =======================

@Composable
fun TestersScreen(team: Team?, members: List<Member>, invites: List<Invite>, run: Runner, onBack: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var removeTarget by remember { mutableStateOf<Pair<String, String?>?>(null) } // email, uid
    val joinedEmails = members.map { it.email.lowercase() }.toSet()
    val waiting = invites.filter { it.email !in joinedEmails }
    val validEmail = email.trim().contains("@") && email.trim().contains(".")

    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("टेस्टर", "Testers"), onBack)
        LazyColumn(Modifier.navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Spacer(Modifier.height(14.dp))
                SectionCard(tr("नया टेस्टर जोड़ें", "Add a new tester")) {
                    Column(Modifier.padding(horizontal = 22.dp)) {
                        OutlinedTextField(
                            email, { email = it }, label = { Text(tr("टेस्टर का Gmail", "Tester's Gmail")) }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            name, { name = it }, label = { Text(tr("नाम (वैकल्पिक)", "Name (optional)")) }, singleLine = true,
                            modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                        Spacer(Modifier.height(12.dp))
                        AppButton(
                            tr("जोड़ें", "Add"),
                            onClick = {
                                val e = email; val n = name
                                email = ""; name = ""
                                run(tr("जोड़ दिया — अब टेस्टर इसी Gmail से साइन इन करे", "Added — now the tester signs in with this Gmail")) {
                                    Repo.addInvite(team!!.id, team.name, e, n)
                                }
                            },
                            enabled = team != null && validEmail,
                            modifier = Modifier.fillMaxWidth()
                        )
                        ButtonHint(if (validEmail) "" else tr("जोड़ें चालू करने के लिए Gmail लिखें", "Type a Gmail to enable Add"))
                        Spacer(Modifier.height(6.dp))
                        Text(
                            tr("टेस्टर ऐप इंस्टॉल करके इसी Gmail से साइन इन करेगा तो अपने-आप आपके ग्रुप से जुड़ जाएगा।", "When the tester installs the app and signs in with this Gmail, they join your group automatically."),
                            color = Sub, fontSize = 13.sp
                        )
                    }
                }
            }
            item {
                SectionCard(tr("जुड़े हुए टेस्टर", "Joined testers"), trailing = "${members.size}") {
                    if (members.isEmpty()) EmptyNote(tr("अभी कोई नहीं", "None yet"))
                    members.forEachIndexed { i, m ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        Row(Modifier.padding(start = 22.dp, end = 10.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(m.photo, m.name, 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(m.name, color = Ink, fontSize = 16.sp)
                                Text(m.email, color = Sub, fontSize = 13.sp)
                            }
                            if (m.phone.isNotBlank()) {
                                IconBox(Icons.Filled.Phone, tr("कॉल करें", "Call"), Green, GreenLine, GreenSoft) { dialTester(ctx, m.phone) }
                                Spacer(Modifier.width(8.dp))
                            }
                            IconBox(Icons.Filled.Delete, tr("हटाएं", "Remove"), Red, RedLine) { removeTarget = m.email to m.uid }
                        }
                    }
                }
            }
            if (waiting.isNotEmpty()) {
                item {
                    SectionCard(tr("साइन इन का इंतज़ार", "Waiting for sign-in")) {
                        waiting.forEach { inv ->
                            Row(Modifier.padding(start = 22.dp, end = 10.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    if (inv.name.isNotBlank()) Text(inv.name, color = Ink, fontSize = 16.sp)
                                    Text(inv.email, color = Sub, fontSize = 13.sp)
                                }
                                IconBox(Icons.Filled.Delete, tr("हटाएं", "Remove"), Red, RedLine) { removeTarget = inv.email to null }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    removeTarget?.let { (e, uid) ->
        AlertDialog(
            onDismissRequest = { removeTarget = null },
            title = { Text(tr("टेस्टर हटाएं?", "Remove tester?")) },
            text = { Text(tr("$e ग्रुप से हट जाएगा। उसका पुराना काम का इतिहास बना रहेगा।", "$e will be removed from the group. Their past work history stays.")) },
            confirmButton = {
                AppButton(tr("हटाएं", "Remove"), onClick = {
                    removeTarget = null
                    run(tr("हटा दिया", "Removed")) { Repo.removeTester(team?.id ?: "", e, uid) }
                }, kind = BtnKind.RedFill, small = true)
            },
            dismissButton = { AppButton(tr("रहने दें", "Keep"), { removeTarget = null }, kind = BtnKind.Outline, small = true) }
        )
    }
}

// ======================= TRACKED APPS =======================

@Composable
fun AppsScreen(team: Team?, run: Runner, onBack: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var pkg by remember { mutableStateOf("") }
    val validPkg = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$").matches(pkg.trim())

    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("ट्रैक होने वाले ऐप्स", "Tracked apps"), onBack)
        LazyColumn(Modifier.navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Spacer(Modifier.height(14.dp))
                InfoBanner(
                    Icons.Filled.Info,
                    tr("टेस्टर के फ़ोन पर सिर्फ़ इन्हीं ऐप्स का समय गिना जाता है, और सिर्फ़ ड्यूटी चालू रहने पर।", "Only these apps are counted on the tester's phone, and only while duty is on.")
                )
            }
            item {
                SectionCard(tr("ऐप जोड़ें", "Add app")) {
                    Column(Modifier.padding(horizontal = 22.dp)) {
                        OutlinedTextField(
                            name, { name = it }, label = { Text(tr("ऐप का नाम", "App name")) },
                            placeholder = { Text(tr("जैसे Samuh Khata", "e.g. Samuh Khata")) }, singleLine = true,
                            modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            pkg, { pkg = it.trim() }, label = { Text(tr("पैकेज नाम", "Package name")) },
                            placeholder = { Text("com.rajeev.samuhkhata") }, singleLine = true,
                            isError = pkg.isNotBlank() && !validPkg,
                            modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                        Text(
                            tr("पैकेज नाम Play Console में या ऐप के Play Store लिंक में id= के बाद मिलता है।", "Find the package name in Play Console, or after id= in the app's Play Store link."),
                            color = Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        val canAdd = team != null && validPkg && team.apps.none { it.pkg == pkg.trim() }
                        AppButton(
                            tr("जोड़ें", "Add"),
                            onClick = {
                                val n = name; val p = pkg
                                name = ""; pkg = ""
                                run(tr("ऐप जोड़ा", "App added")) { Repo.addApp(team!!.id, n.ifBlank { p }, p) }
                            },
                            enabled = canAdd,
                            modifier = Modifier.fillMaxWidth()
                        )
                        ButtonHint(if (canAdd) "" else tr("जोड़ें चालू करने के लिए पैकेज नाम लिखें", "Type a package name to enable Add"))
                    }
                }
            }
            item {
                SectionCard(tr("आपके ऐप्स", "Your apps"), trailing = "${team?.apps?.size ?: 0}") {
                    val apps = team?.apps ?: emptyList()
                    if (apps.isEmpty()) EmptyNote(tr("अभी कोई ऐप नहीं जोड़ा", "No apps added yet"))
                    apps.forEachIndexed { i, a ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        Row(Modifier.padding(start = 22.dp, end = 10.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar("", a.name, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(a.name, color = Ink, fontSize = 16.sp)
                                Text(a.pkg, color = Sub, fontSize = 13.sp)
                            }
                            IconBox(Icons.Filled.Delete, tr("हटाएं", "Remove"), Red, RedLine) {
                                run(tr("ऐप हटाया", "App removed")) { Repo.removeApp(team!!.id, a) }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
