package com.rajeev.testertrack.ui.screens

import com.rajeev.testertrack.ui.components.BtnKind
import com.rajeev.testertrack.ui.components.AppButton
import com.rajeev.testertrack.data.tr
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import com.rajeev.testertrack.ui.components.Pill
import com.rajeev.testertrack.ui.theme.GreenSoft
import com.rajeev.testertrack.ui.theme.Tile
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.DayState
import com.rajeev.testertrack.data.InstalledSnapshot
import com.rajeev.testertrack.data.TrackedApp
import com.rajeev.testertrack.data.testingDays
import com.rajeev.testertrack.data.Member
import com.rajeev.testertrack.data.Session
import com.rajeev.testertrack.data.TaskStatus
import com.rajeev.testertrack.data.Team
import com.rajeev.testertrack.data.UsageDay
import com.rajeev.testertrack.data.UserProfile
import com.rajeev.testertrack.data.WorkTask
import com.rajeev.testertrack.tracking.UsageAccess
import com.rajeev.testertrack.ui.Runner
import com.rajeev.testertrack.ui.Screen
import com.rajeev.testertrack.ui.components.Chip
import com.rajeev.testertrack.ui.components.EmptyNote
import com.rajeev.testertrack.ui.components.BellButton
import com.rajeev.testertrack.ui.components.FixedHome
import com.rajeev.testertrack.ui.components.InfoBanner
import com.rajeev.testertrack.ui.components.SectionCard
import com.rajeev.testertrack.ui.components.TileData
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.todayMs
import com.rajeev.testertrack.ui.usageTotal

@Composable
fun MemberHome(
    user: UserProfile,
    team: Team?,
    me: Member?,
    tasks: List<WorkTask>,
    sessions: List<Session>,
    usageToday: UsageDay?,
    now: Long,
    nav: (Screen) -> Unit,
    run: Runner,
    installed: InstalledSnapshot? = null,
    onDutyToggle: (Member) -> Unit = {},
    unread: Int,
    onBell: () -> Unit,
) {
    val ctx = LocalContext.current
    val today = Dates.dayKey(now)
    var usageOk by remember { mutableStateOf(UsageAccess.granted(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { usageOk = UsageAccess.granted(ctx) }

    val have = installed?.apps.orEmpty().associateBy { it.pkg }
    val dayChip = team?.apps.orEmpty().mapNotNull { have[it.pkg] }.firstOrNull { it.uninstalledAt == 0L }
        ?.let { Chip(tr("दिन ${Dates.dayNumber(it.start, now)}", "Day ${Dates.dayNumber(it.start, now)}"), false) }
    val done = tasks.count { it.status == TaskStatus.DONE }
    val working = tasks.count { it.status == TaskStatus.WORKING }
    val pending = tasks.count { it.status == TaskStatus.PENDING }

    FixedHome(
        teamName = team?.name ?: "",
        userName = user.name,
        photo = user.photo,
        chips = listOfNotNull(Chip(tr("टेस्टर", "Tester"), true), dayChip),
        onMenu = { nav(Screen.Menu) },
        onAvatar = { nav(Screen.Settings) },
        onSettings = { nav(Screen.Settings) },
        cardTitle = tr("आज का काम", "Today's work"),
        cardValue = Dates.hoursLong(todayMs(sessions, user.uid, today, now)),
        tiles = listOf(
            TileData(tr("पूरे", "Done"), "$done") { nav(Screen.Tasks(TaskStatus.DONE)) },
            TileData(tr("चालू", "Working"), "$working") { nav(Screen.Tasks(TaskStatus.WORKING)) },
            TileData(tr("बाकी", "Pending"), "$pending", Purple) { nav(Screen.Tasks(TaskStatus.PENDING)) },
        ),
        bell = { BellButton(unread, onBell) },
    ) {
        // 14-day testing tracker for the admin's apps
        item { TestingDaysCard(team?.apps ?: emptyList(), installed, now) }

        if (!usageOk && team?.apps?.isNotEmpty() == true) {
            item {
                InfoBanner(
                    Icons.Filled.Lock,
                    tr("ऐप खोलने के दिन गिनने के लिए “Usage access” में Tester Track को चालू करें। सिर्फ़ एडमिन के ऐप्स, सिर्फ़ खोलने का दिन।", "To count the days you open the admin's apps, turn on Tester Track in “Usage access”. Only the admin's apps, only the day you opened them."),
                    buttonText = tr("सेटिंग खोलें ›", "Open settings ›")
                ) { UsageAccess.openSettings(ctx) }
            }
        }

        item {
            SectionCard(tr("मेरे टास्क", "My tasks"), action = tr("सभी देखें", "See all"), onAction = { nav(Screen.Tasks(null)) }) {
                val active = tasks.filter { it.status != TaskStatus.DONE }
                    .sortedWith(compareBy<WorkTask> { if (it.status == TaskStatus.WORKING) 0 else 1 }.thenByDescending { it.createdAt })
                if (active.isEmpty()) EmptyNote(tr("अभी कोई टास्क नहीं — एडमिन के टास्क यहाँ दिखेंगे", "No tasks yet — the admin's tasks will show here"))
                active.forEachIndexed { i, t ->
                    if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                    TaskRow(t, isAdmin = false, teamId = user.teamId, run = run, showAssignee = false)
                }
            }
        }

        item {
            SectionCard(tr("आज ऐप उपयोग", "App usage today"), trailing = Dates.hoursShort(usageTotal(usageToday))) {
                UsageList(
                    usageToday?.perApp() ?: emptyMap(), team?.apps ?: emptyList(),
                    tr("ड्यूटी के दौरान एडमिन के ऐप्स में बिताया समय यहाँ दिखेगा (हर ~15 मिनट में अपडेट)", "Time in the admin's apps during duty shows here (updates every ~15 min)")
                )
            }
        }

        item {
            SectionCard(tr("इस हफ़्ते", "This week"), action = tr("इतिहास", "History"), onAction = { nav(Screen.History(user.uid, user.name)) }) {
                Text(
                    tr("7 दिन में कुल ${Dates.hoursLong(sessions.sumOf { it.durationMs(now) })}", "${Dates.hoursLong(sessions.sumOf { it.durationMs(now) })} in the last 7 days"),
                    color = Ink, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 22.dp)
                )
            }
        }
    }
}


private val Orange = Color(0xFFE65100)

/**
 * Day 1..14 for each app the admin chose: green circle = opened that day, red = that day passed without opening,
 * outlined = today (open it to turn it green), grey = not reached yet.
 */
@Composable
private fun TestingDaysCard(apps: List<TrackedApp>, installed: InstalledSnapshot?, now: Long) {
    SectionCard(tr("टेस्टिंग के दिन (1–14)", "Testing days (1–14)")) {
        if (apps.isEmpty()) {
            EmptyNote(tr("एडमिन ने अभी कोई ऐप नहीं चुना। चुनते ही यहाँ दिन दिखेंगे।", "Your admin hasn't chosen any app yet. Days will show here once they do."))
            return@SectionCard
        }
        val have = installed?.apps.orEmpty().associateBy { it.pkg }
        apps.forEachIndexed { i, app ->
            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp, vertical = 10.dp))
            val a = have[app.pkg]
            val gone = a != null && a.uninstalledAt > 0
            Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        app.name.ifBlank { app.pkg }, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    when {
                        a == null -> Pill(tr("इंस्टॉल नहीं", "Not installed"), Sub, Tile)
                        gone -> Pill(tr("हटाया गया", "Uninstalled"), Red, Color(0xFFFDECEC))
                        else -> Pill(tr("दिन ${Dates.dayNumber(a.start, now)}", "Day ${Dates.dayNumber(a.start, now)}"), Green, GreenSoft)
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (a == null) {
                    Text(
                        if (installed == null) tr("पहली जाँच का इंतज़ार…", "Waiting for the first check…")
                        else tr("ऐप इंस्टॉल करते ही दिन 1 शुरू होगा।", "Day 1 starts the day you install it."),
                        color = Sub, fontSize = 14.sp
                    )
                } else {
                    val states = testingDays(a, now)
                    states.chunked(7).forEachIndexed { row, chunk ->
                        if (row > 0) Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            chunk.forEachIndexed { j, st -> DayCircle(row * 7 + j + 1, st) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    val done = states.count { it == DayState.OPENED }
                    val dayNo = com.rajeev.testertrack.data.Dates.dayNumber(a.start, if (gone) a.uninstalledAt else now)
                    Text(
                        tr("$done दिन खोला · हरा = खोला, लाल = नहीं खोला", "Opened $done of ${minOf(dayNo, 14)} days · green = opened, red = missed"),
                        color = Sub, fontSize = 12.sp
                    )
                    if (!gone && states.getOrNull(minOf(dayNo, 14) - 1) == DayState.TODAY) {
                        Text(
                            tr("आज ${app.name.ifBlank { app.pkg }} खोलें — दिन हरा हो जाएगा।", "Open ${app.name.ifBlank { app.pkg }} today to turn this day green."),
                            color = Orange, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun DayCircle(n: Int, state: DayState) {
    val bg = when (state) {
        DayState.OPENED -> Green
        DayState.MISSED -> Red
        DayState.TODAY -> Color.White
        else -> Line
    }
    val fg = when (state) {
        DayState.OPENED, DayState.MISSED -> Color.White
        DayState.TODAY -> Purple
        else -> Sub
    }
    Box(
        Modifier.size(38.dp).clip(CircleShape).background(bg)
            .then(if (state == DayState.TODAY) Modifier.border(2.dp, Purple, CircleShape) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text("$n", color = fg, fontSize = 14.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}
