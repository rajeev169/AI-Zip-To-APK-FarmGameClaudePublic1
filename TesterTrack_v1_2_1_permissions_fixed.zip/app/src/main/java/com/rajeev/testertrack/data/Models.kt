package com.rajeev.testertrack.data

import com.google.firebase.firestore.DocumentSnapshot
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Role {
    const val ADMIN = "admin"
    const val MEMBER = "member"
}

object TaskStatus {
    const val PENDING = "pending"   // बाकी
    const val WORKING = "working"   // चालू
    const val DONE = "done"         // पूरे

    fun label(s: String) = when (s) {
        DONE -> tr("पूरा", "Done")
        WORKING -> tr("चालू", "Working")
        else -> tr("बाकी", "Pending")
    }
}

data class UserProfile(
    val uid: String,
    val name: String,
    val email: String,
    val photo: String,
    val role: String,
    val teamId: String,
    val consentAt: Long,
    val phone: String,
    val consentV: Int = 0,
)

/** Bump when the tester notice changes, so existing testers must agree again. */
const val CONSENT_VERSION = 5

data class TrackedApp(val name: String, val pkg: String)

data class Team(
    val id: String,
    val name: String,
    val adminUid: String,
    val adminName: String,
    val apps: List<TrackedApp>,
)

data class Member(
    val uid: String,
    val name: String,
    val email: String,
    val photo: String,
    val onDuty: Boolean,
    val dutyStart: Long,
    val sessionId: String,
    val lastSeen: Long,
    val phone: String,
    val deviceId: String = "",   // scrambled phone id: lets the admin see two Gmails on one phone
    val upi: String = "",        // where the tester wants to be paid
)

data class Invite(val email: String, val name: String, val teamId: String)

data class WorkTask(
    val id: String,
    val title: String,
    val appName: String,
    val note: String,
    val assigneeUid: String,
    val assigneeName: String,
    val status: String,
    val createdAt: Long,
    val startedAt: Long,
    val doneAt: Long,
    val link: String,
)

/** In-app notification for a tester (new task, status changed, task deleted). */
data class Notif(
    val id: String,
    val type: String,
    val title: String,
    val body: String,
    val createdAt: Long,
    val read: Boolean,
    val pushed: Boolean,
    val fromUid: String = "",
    val phone: String = "",
)

object NotifType {
    const val NEW_TASK = "new_task"
    const val STATUS = "status"
    const val DELETED = "deleted"
    const val APP_ADDED = "app_added"       // tester installed app(s) -> admin
    const val APP_REMOVED = "app_removed"   // tester removed app(s) -> admin
    const val APP_MISSED = "app_missed"     // tester did not open app(s) yesterday -> admin
    const val APP_READY = "app_ready"       // tester finished 14 days in a row -> admin (reward ready)
    const val REWARD = "reward"             // admin gave the 14-day reward -> tester
    const val WITHDRAW = "withdraw_request" // tester asked to withdraw the wallet -> admin
    const val PAID = "paid"                 // admin paid the withdrawal -> tester
    const val DECLINED = "declined"         // admin declined the withdrawal -> tester

    fun isApp(t: String) = t == APP_ADDED || t == APP_REMOVED || t == APP_MISSED || t == APP_READY || t == WITHDRAW
}

/**
 * One tracked app on the tester's phone.
 * [start] = real install time (Day 1), [uninstalledAt] = 0 while still installed,
 * [opened] = the days (yyyy-MM-dd) the tester opened it.
 */
data class InstalledApp(
    val pkg: String,
    val name: String,
    val since: Long,
    val start: Long = 0L,
    val uninstalledAt: Long = 0L,
    val opened: Set<String> = emptySet(),
    val watchFrom: Long = 0L,     // days before this can't be known (Android keeps ~a week of history)
    val minutes: Map<String, Long> = emptyMap(),   // yyyy-MM-dd -> minutes used that day
)

data class InstalledSnapshot(val apps: List<InstalledApp>, val checkedAt: Long, val usageOk: Boolean = true)

/** Adds https:// when someone pastes "drive.google.com/…" without it. */
fun normalizeLink(raw: String): String {
    val t = raw.trim()
    if (t.isBlank()) return ""
    return if (t.startsWith("http://", true) || t.startsWith("https://", true)) t else "https://$t"
}

data class Session(
    val id: String,
    val uid: String,
    val name: String,
    val start: Long,
    val end: Long,     // 0 while running
    val date: String,
) {
    fun durationMs(now: Long = System.currentTimeMillis()): Long =
        ((if (end > 0) end else now) - start).coerceAtLeast(0)
}

/** usage/{uid_date}: sessions -> (encoded pkg -> millis) */
data class UsageDay(
    val uid: String,
    val date: String,
    val sessions: Map<String, Map<String, Long>>,
) {
    /** pkg -> total millis for the day */
    fun perApp(): Map<String, Long> {
        val out = HashMap<String, Long>()
        sessions.values.forEach { m ->
            m.forEach { (k, v) -> val p = decodePkg(k); out[p] = (out[p] ?: 0L) + v }
        }
        return out
    }
}

fun encodePkg(p: String) = p.replace('.', ',')
fun decodePkg(p: String) = p.replace(',', '.')

// ---------- mapping ----------

fun DocumentSnapshot.toUser(): UserProfile = UserProfile(
    uid = id,
    name = getString("name") ?: "",
    email = getString("email") ?: "",
    photo = getString("photo") ?: "",
    role = getString("role") ?: "",
    teamId = getString("teamId") ?: "",
    consentAt = getLong("consentAt") ?: 0L,
    phone = getString("phone") ?: "",
    consentV = (getLong("consentV") ?: 0L).toInt(),
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toTeam(): Team {
    val raw = get("apps") as? List<Map<String, Any?>> ?: emptyList()
    return Team(
        id = id,
        name = getString("name") ?: "",
        adminUid = getString("adminUid") ?: "",
        adminName = getString("adminName") ?: "",
        apps = raw.map { TrackedApp(it["name"] as? String ?: "", it["pkg"] as? String ?: "") }
            .filter { it.pkg.isNotBlank() },
    )
}

fun DocumentSnapshot.toMember(): Member = Member(
    uid = id,
    name = getString("name") ?: "",
    email = getString("email") ?: "",
    photo = getString("photo") ?: "",
    onDuty = getBoolean("onDuty") ?: false,
    dutyStart = getLong("dutyStart") ?: 0L,
    sessionId = getString("sessionId") ?: "",
    lastSeen = getLong("lastSeen") ?: 0L,
    phone = getString("phone") ?: "",
    deviceId = getString("dev") ?: "",
    upi = getString("upi") ?: "",
)

fun DocumentSnapshot.toInvite(): Invite = Invite(
    email = id,
    name = getString("name") ?: "",
    teamId = getString("teamId") ?: "",
)

fun DocumentSnapshot.toTask(): WorkTask = WorkTask(
    id = id,
    title = getString("title") ?: "",
    appName = getString("appName") ?: "",
    note = getString("note") ?: "",
    assigneeUid = getString("assigneeUid") ?: "",
    assigneeName = getString("assigneeName") ?: "",
    status = getString("status") ?: TaskStatus.PENDING,
    createdAt = getLong("createdAt") ?: 0L,
    startedAt = getLong("startedAt") ?: 0L,
    doneAt = getLong("doneAt") ?: 0L,
    link = getString("link") ?: "",
)

fun DocumentSnapshot.toNotif(): Notif = Notif(
    id = id,
    type = getString("type") ?: "",
    title = getString("title") ?: "",
    body = getString("body") ?: "",
    createdAt = getLong("createdAt") ?: 0L,
    read = getBoolean("read") ?: false,
    pushed = getBoolean("pushed") ?: false,
    fromUid = getString("fromUid") ?: "",
    phone = getString("phone") ?: "",
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toInstalled(): InstalledSnapshot {
    val raw = get("apps") as? Map<String, Map<String, Any?>> ?: emptyMap()
    return InstalledSnapshot(
        apps = raw.map { (k, v) ->
            InstalledApp(
                pkg = decodePkg(k),
                name = v["n"] as? String ?: decodePkg(k),
                since = (v["t"] as? Number)?.toLong() ?: 0L,
                start = (v["s"] as? Number)?.toLong() ?: 0L,
                uninstalledAt = (v["u"] as? Number)?.toLong() ?: 0L,
                opened = (v["d"] as? List<*>)?.filterIsInstance<String>()?.toSet() ?: emptySet(),
                watchFrom = (v["w"] as? Number)?.toLong() ?: 0L,
                minutes = (v["m"] as? Map<*, *>)?.entries
                    ?.mapNotNull { (k, x) -> (k as? String)?.let { it to ((x as? Number)?.toLong() ?: 0L) } }
                    ?.toMap() ?: emptyMap(),
            )
        },
        checkedAt = getLong("checkedAt") ?: 0L,
        usageOk = getBoolean("ua") ?: true,
    )
}

fun DocumentSnapshot.toSession(): Session = Session(
    id = id,
    uid = getString("uid") ?: "",
    name = getString("name") ?: "",
    start = getLong("start") ?: 0L,
    end = getLong("end") ?: 0L,
    date = getString("date") ?: "",
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toUsage(): UsageDay {
    val raw = get("sessions") as? Map<String, Map<String, Any?>> ?: emptyMap()
    return UsageDay(
        uid = getString("uid") ?: "",
        date = getString("date") ?: "",
        sessions = raw.mapValues { (_, m) -> m.mapValues { (it.value as? Number)?.toLong() ?: 0L } },
    )
}

// ---------- date / time helpers ----------

object Dates {
    private fun fmt(p: String) = SimpleDateFormat(p, Locale.ENGLISH)

    fun dayKey(t: Long = System.currentTimeMillis()): String = fmt("yyyy-MM-dd").format(Date(t))

    /** Install day = Day 1. Calendar days, so 11 pm on day 1 and 1 am the next morning are Day 1 and Day 2. */
    fun dayNumber(from: Long, to: Long): Int {
        if (from <= 0L) return 1
        val zone = java.time.ZoneId.systemDefault()
        val a = java.time.Instant.ofEpochMilli(from).atZone(zone).toLocalDate()
        val b = java.time.Instant.ofEpochMilli(to).atZone(zone).toLocalDate()
        return (java.time.temporal.ChronoUnit.DAYS.between(a, b).toInt() + 1).coerceAtLeast(1)
    }

    fun daysAgoKey(n: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -n)
        return dayKey(c.timeInMillis)
    }

    fun time(t: Long): String = if (t <= 0) "" else fmt("h:mm a").format(Date(t))
    fun dateTime(t: Long): String = if (t <= 0) "" else fmt("d MMM, h:mm a").format(Date(t))

    fun dayLabel(key: String): String {
        if (key == dayKey()) return tr("आज", "Today")
        if (key == daysAgoKey(1)) return tr("कल", "Yesterday")
        return try {
            val d = fmt("yyyy-MM-dd").parse(key)
            if (d == null) key else fmt("EEE, d MMM").format(d)
        } catch (e: Exception) { key }
    }

    /** e.g. "5 घंटे 20 मिनट" */
    fun hoursLong(ms: Long): String {
        val totalMin = ms / 60000
        val h = totalMin / 60
        val m = totalMin % 60
        return when {
            h == 0L -> tr("$m मिनट", "$m min")
            m == 0L -> tr("$h घंटे", "$h hr")
            else -> tr("$h घंटे $m मिनट", "$h hr $m min")
        }
    }

    /** e.g. "5 घं 20 मि" */
    fun hoursShort(ms: Long): String {
        val totalMin = ms / 60000
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h == 0L) tr("$m मि", "$m m") else tr("$h घं $m मि", "$h h $m m")
    }
}

/** Indian mobile: keeps last 10 digits; valid if it starts with 6-9. */
object Phone {
    fun clean(raw: String): String {
        val d = raw.filter { it.isDigit() }
        return if (d.length > 10) d.takeLast(10) else d
    }
    fun valid(raw: String): Boolean = clean(raw).let { it.length == 10 && it[0] in '6'..'9' }
    fun pretty(p: String): String = if (p.length == 10) "+91 ${p.substring(0, 5)} ${p.substring(5)}" else p
}


/** How one day of the 14-day test looks. */
enum class DayState { OPENED, MISSED, TODAY, UNKNOWN, FUTURE }

/**
 * Day 1..[total] counted from the install day: green = opened, red = day passed without opening,
 * TODAY = today, not opened yet (can still be saved), UNKNOWN = before we could see, FUTURE = not reached / app removed.
 */
fun testingDays(app: InstalledApp, now: Long, total: Int = 14): List<DayState> {
    val zone = java.time.ZoneId.systemDefault()
    fun date(t: Long) = java.time.Instant.ofEpochMilli(t).atZone(zone).toLocalDate()
    fun key(d: java.time.LocalDate) = Dates.dayKey(d.atStartOfDay(zone).toInstant().toEpochMilli())
    val startDate = date(if (app.start > 0) app.start else now)
    val today = date(now)
    val endDate = if (app.uninstalledAt > 0) date(app.uninstalledAt) else null
    val watchDate = if (app.watchFrom > 0) date(app.watchFrom) else startDate
    return (0 until total).map { i ->
        val d = startDate.plusDays(i.toLong())
        when {
            key(d) in app.opened -> DayState.OPENED
            endDate != null && !d.isBefore(endDate) -> DayState.FUTURE
            d.isAfter(today) -> DayState.FUTURE
            d == today -> DayState.TODAY
            d.isBefore(watchDate) -> DayState.UNKNOWN
            else -> DayState.MISSED
        }
    }
}


// ---------------- wallet ----------------

const val STREAK_DAYS = 14
const val REWARD_RS = 14        // Rs 1 per day x 14 days, only if no day was missed

object TxKind {
    const val REWARD = "reward14"
    const val PAYOUT = "payout"
}

/** One line of a tester's wallet. Positive = money added, negative = paid out. Never edited or deleted. */
data class WalletTx(val id: String, val uid: String, val amount: Int, val kind: String, val label: String, val pkg: String, val at: Long)

fun DocumentSnapshot.toTx() = WalletTx(
    id = id,
    uid = getString("uid") ?: "",
    amount = (getLong("amount") ?: 0L).toInt(),
    kind = getString("kind") ?: "",
    label = getString("label") ?: "",
    pkg = getString("pkg") ?: "",
    at = getLong("at") ?: 0L,
)

data class UserInstalled(val uid: String, val snap: InstalledSnapshot)

fun DocumentSnapshot.toUserInstalled() = UserInstalled(id, toInstalled())

/** The yyyy-MM-dd of Day 1..[total] counted from the install day (same order as [testingDays]). */
fun testingDayKeys(app: InstalledApp, now: Long, total: Int = 14): List<String> {
    val zone = java.time.ZoneId.systemDefault()
    val startDate = java.time.Instant.ofEpochMilli(if (app.start > 0) app.start else now).atZone(zone).toLocalDate()
    return (0 until total).map { i ->
        Dates.dayKey(startDate.plusDays(i.toLong()).atStartOfDay(zone).toInstant().toEpochMilli())
    }
}

/** True when every one of days 1..14 (from the install day) was opened. */
fun streakComplete(app: InstalledApp, now: Long): Boolean =
    app.start > 0 && testingDays(app, now, STREAK_DAYS).all { it == DayState.OPENED }

/** Other testers (names) whose Gmail is signed in on the same phone as [m]. */
fun sharedPhoneWith(m: Member, members: List<Member>): List<String> =
    if (m.deviceId.isBlank()) emptyList()
    else members.filter { it.uid != m.uid && it.deviceId == m.deviceId }.map { it.name }

/**
 * A reward that is earned but not yet given. The id makes sure one install can only be paid once.
 * [sameDevice] = other testers on the same phone. [phonePaidTo] = name of someone on this phone who was already
 * paid for this app, in which case the admin can't pay again.
 */
data class RewardDue(
    val uid: String, val name: String, val pkg: String, val appName: String, val start: Long,
    val sameDevice: List<String> = emptyList(), val phonePaidTo: String? = null,
) {
    val id: String get() = "r14_${uid}_${encodePkg(pkg)}_$start"
}

fun rewardsDue(
    tracked: List<TrackedApp>, members: List<Member>, all: List<UserInstalled>, txs: List<WalletTx>, now: Long,
): List<RewardDue> {
    val paidIds = txs.map { it.id }.toSet()
    return all.flatMap { ui ->
        val m = members.find { it.uid == ui.uid } ?: return@flatMap emptyList<RewardDue>()
        val phoneMates = if (m.deviceId.isBlank()) emptyList() else members.filter { it.uid != m.uid && it.deviceId == m.deviceId }
        tracked.mapNotNull { t ->
            val a = ui.snap.apps.find { it.pkg == t.pkg } ?: return@mapNotNull null
            if (!streakComplete(a, now)) return@mapNotNull null
            val paidOnPhone = phoneMates.firstOrNull { pm ->
                txs.any { it.kind == TxKind.REWARD && it.pkg == t.pkg && it.uid == pm.uid }
            }?.name
            val due = RewardDue(ui.uid, m.name, t.pkg, t.name.ifBlank { t.pkg }, a.start, phoneMates.map { it.name }, paidOnPhone)
            if (due.id in paidIds) null else due
        }
    }
}


// ---------------- withdrawals ----------------

const val MIN_WITHDRAW_RS = 14

private val UPI_REGEX = Regex("^[a-zA-Z0-9._-]{2,256}@[a-zA-Z0-9]{2,64}$")
fun isValidUpi(s: String) = UPI_REGEX.matches(s.trim())

/** A tester's request to be paid their whole wallet. One at a time; the amount is always the real wallet balance. */
data class Withdrawal(val id: String, val uid: String, val name: String, val upi: String, val createdAt: Long)

fun DocumentSnapshot.toWithdrawal() = Withdrawal(
    id = id, uid = getString("uid") ?: "", name = getString("name") ?: "",
    upi = getString("upi") ?: "", createdAt = getLong("createdAt") ?: 0L,
)
