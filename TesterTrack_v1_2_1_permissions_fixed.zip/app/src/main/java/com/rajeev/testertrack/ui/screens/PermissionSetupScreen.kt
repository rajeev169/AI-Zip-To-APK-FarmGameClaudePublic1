package com.rajeev.testertrack.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.rajeev.testertrack.data.tr
import com.rajeev.testertrack.tracking.BatteryOptimization
import com.rajeev.testertrack.tracking.UsageAccess
import com.rajeev.testertrack.ui.theme.Bg
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Sub

/** One place for the tester to grant the permissions required before monitoring starts. */
@Composable
fun PermissionSetupScreen(onComplete: () -> Unit, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    var notificationRequested by remember { mutableStateOf(false) }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { refresh++ }

    fun notificationGranted(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            androidx.core.content.ContextCompat.checkSelfPermission(
                ctx, Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        refresh++
        if (UsageAccess.granted(ctx) && BatteryOptimization.unrestricted(ctx) && notificationGranted()) {
            onComplete()
        }
    }

    val usageOk = remember(refresh) { UsageAccess.granted(ctx) }
    val batteryOk = remember(refresh) { BatteryOptimization.unrestricted(ctx) }
    val notificationOk = remember(refresh) { notificationGranted() }
    val ready = usageOk && batteryOk && notificationOk

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            tr("Tester Track तैयार करें", "Set up Tester Track"),
            color = Ink,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            tr(
                "होम स्क्रीन पर जाने से पहले ये अनुमतियाँ चालू करें। इससे केवल एडमिन द्वारा चुने गए ऐप्स की टेस्टिंग ठीक से चल सकेगी।",
                "Turn on these permissions before entering the home screen. They keep testing reliable for only the apps selected by your admin."
            ),
            color = Sub,
            fontSize = 15.sp
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PermissionRow(
                    Icons.Filled.Info,
                    tr("Usage access", "Usage access"),
                    tr("एडमिन के चुने हुए ऐप्स के खुले दिन और समय गिनने के लिए।", "Counts the days and time for the apps selected by your admin."),
                    usageOk,
                    tr("सेटिंग खोलें", "Open settings")
                ) { UsageAccess.openSettings(ctx) }
                PermissionRow(
                    Icons.Filled.Build,
                    tr("Keep running", "Keep running"),
                    tr("Tester Track को बैकग्राउंड में चलाने के लिए Battery → Unrestricted।", "Allows Tester Track to keep monitoring in the background: Battery → Unrestricted."),
                    batteryOk,
                    tr("अनुमति दें", "Allow")
                ) { BatteryOptimization.request(ctx) }
                PermissionRow(
                    Icons.Filled.Notifications,
                    tr("Notifications", "Notifications"),
                    tr("टास्क, टेस्टिंग अलर्ट और भुगतान सूचनाएँ दिखाने के लिए।", "Shows task, testing, and payment alerts."),
                    notificationOk,
                    tr("अनुमति दें", "Allow")
                ) {
                    if (Build.VERSION.SDK_INT >= 33) {
                        notificationRequested = true
                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Lock, null, tint = Purple)
                Spacer(Modifier.weight(1f))
                Text(
                    tr("Foreground service permission is handled by Android while an active monitoring service runs.", "Foreground service permission is handled by Android while an active monitoring service runs."),
                    color = Sub,
                    fontSize = 13.sp,
                    modifier = Modifier.weight(8f)
                )
            }
        }

        Button(
            onClick = { if (ready) onComplete() },
            enabled = ready,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Purple,
                disabledContainerColor = Color(0xFFBDBDBD)
            )
        ) {
            Text(
                if (ready) tr("होम स्क्रीन खोलें", "Continue to home")
                else tr("ऊपर की सभी अनुमतियाँ चालू करें", "Turn on all permissions above")
            )
        }

        Button(
            onClick = onSignOut,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.textButtonColors(contentColor = Sub)
        ) { Text(tr("साइन आउट", "Sign out")) }
    }
}

@Composable
private fun PermissionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    granted: Boolean,
    actionText: String,
    onAction: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (granted) Green else Purple)
        Spacer(Modifier.padding(horizontal = 6.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold)
            Text(description, color = Sub, fontSize = 12.sp)
        }
        if (granted) {
            Icon(Icons.Filled.CheckCircle, "Granted", tint = Green)
        } else {
            Button(
                onClick = onAction,
                shape = RoundedCornerShape(10.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                modifier = Modifier.height(38.dp)
            ) { Text(actionText, fontSize = 12.sp) }
        }
    }
}
