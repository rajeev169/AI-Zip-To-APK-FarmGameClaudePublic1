package com.rajeev.testertrack.ui.screens

import com.rajeev.testertrack.ui.components.ButtonHint
import com.rajeev.testertrack.ui.components.BtnKind
import com.rajeev.testertrack.ui.components.AppButton
import com.rajeev.testertrack.ui.components.fieldColors
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.testertrack.data.Phone
import com.rajeev.testertrack.data.tr
import com.rajeev.testertrack.ui.components.SubTopBar
import com.rajeev.testertrack.ui.theme.Bg
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.theme.Tile

data class MenuItem(
    val icon: ImageVector,
    val title: String,
    val subtitle: String,
    val danger: Boolean = false,
    val onClick: () -> Unit,
)

/** ☰ opens this full page instead of a small dropdown. */
@Composable
fun MenuScreen(groups: List<List<MenuItem>>, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("मेनू", "Menu"), onBack)
        Column(
            Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(vertical = 14.dp)
        ) {
            groups.forEach { items ->
                Surface(
                    shape = RoundedCornerShape(28.dp), color = Color.White,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp).fillMaxWidth()
                ) {
                    Column(Modifier.padding(vertical = 6.dp)) {
                        items.forEachIndexed { i, m ->
                            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(start = 78.dp, end = 22.dp))
                            MenuRow(m)
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun MenuRow(m: MenuItem) {
    val fg = if (m.danger) Red else Purple
    Row(
        Modifier.fillMaxWidth().clickable { m.onClick() }.padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                .background(if (m.danger) Color(0xFFFDECEC) else Tile),
            contentAlignment = Alignment.Center
        ) { Icon(m.icon, null, tint = fg, modifier = Modifier.size(24.dp)) }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(m.title, color = if (m.danger) Red else Ink, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            if (m.subtitle.isNotBlank()) Text(m.subtitle, color = Sub, fontSize = 13.sp)
        }
        if (!m.danger) Text("›", color = Sub, fontSize = 26.sp)
    }
}

fun adminMenu(
    testers: Int, waiting: Int, apps: Int,
    onTesters: () -> Unit, onApps: () -> Unit, onNewTask: () -> Unit, onAllTasks: () -> Unit,
    onShare: () -> Unit = {},
): List<List<MenuItem>> = listOf(
    listOf(
        MenuItem(
            Icons.Filled.Person, tr("टेस्टर", "Testers"),
            testerCountText(testers, waiting), onClick = onTesters
        ),
        MenuItem(
            Icons.Filled.Build, tr("ट्रैक होने वाले ऐप्स", "Tracked apps"),
            tr("$apps ऐप्स · जिनका समय गिना जाता है", "$apps apps · whose time is counted"), onClick = onApps
        ),
    ),
    listOf(
        MenuItem(Icons.Filled.Add, tr("नया टास्क", "New task"), tr("टेस्टर को टास्क दें", "Give a task to a tester"), onClick = onNewTask),
        MenuItem(Icons.AutoMirrored.Filled.List, tr("सभी टास्क", "All tasks"), tr("पूरे, चालू और बाकी", "Done, working and pending"), onClick = onAllTasks),
    ),
    listOf(
        MenuItem(Icons.Filled.Share, tr("ऐप शेयर करें", "Share app"), tr("लिंक सेट करें और दूसरों को भेजें", "Set the link and send it to others"), onClick = onShare),
    ),
)

fun testerMenu(
    onTasks: () -> Unit, onHistory: () -> Unit, onUsage: () -> Unit,
    onShare: () -> Unit = {},
    onAddMember: (() -> Unit)? = null,   // only for a co-admin
): List<List<MenuItem>> = listOfNotNull(
    onAddMember?.let {
        listOf(
            MenuItem(Icons.Filled.Add, tr("सदस्य जोड़ें", "Add member"), tr("एडमिन की मंज़ूरी से नया सदस्य", "A new member, with the admin's approval"), onClick = it)
        )
    },
    listOf(
        MenuItem(Icons.AutoMirrored.Filled.List, tr("मेरे टास्क", "My tasks"), tr("पूरे, चालू और बाकी", "Done, working and pending"), onClick = onTasks),
        MenuItem(Icons.Filled.DateRange, tr("काम का इतिहास", "Work history"), tr("पिछले 7 दिन के घंटे", "Hours for the last 7 days"), onClick = onHistory),
        MenuItem(Icons.Filled.Lock, tr("ऐप उपयोग अनुमति", "Usage access permission"), tr("ऐप्स का समय गिनने के लिए", "Needed to count app time"), onClick = onUsage),
    ),
    listOf(
        MenuItem(Icons.Filled.Share, tr("ऐप शेयर करें", "Share app"), tr("दूसरों को ऐप का लिंक भेजें", "Send the app link to others"), onClick = onShare),
    ),
)

/** "1 tester", "2 testers · 1 waiting" */
fun testerCountText(joined: Int, waiting: Int): String {
    val base = tr("$joined टेस्टर", if (joined == 1) "1 tester" else "$joined testers")
    return if (waiting > 0) base + tr(" · $waiting इंतज़ार में", " · $waiting waiting") else base
}

/** Required once for testers: mobile number so the admin can call. */
@Composable
fun PhoneScreen(name: String, onSave: (phone: String, done: (String?) -> Unit) -> Unit, onSignOut: () -> Unit) {
    var phone by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val ok = Phone.valid(phone)
    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(22.dp)
    ) {
        Spacer(Modifier.height(30.dp))
        Box(
            Modifier.size(72.dp).clip(RoundedCornerShape(22.dp)).background(Tile),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Filled.Phone, null, tint = Purple, modifier = Modifier.size(36.dp)) }
        Spacer(Modifier.height(18.dp))
        Text(tr("आपका मोबाइल नंबर", "Your mobile number"), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(6.dp))
        Text(
            tr("$name, ज़रूरत पड़ने पर एडमिन आपको इसी नंबर पर कॉल करेंगे।", "$name, your admin will call you on this number when needed."),
            color = Sub, fontSize = 15.sp, lineHeight = 22.sp
        )
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            phone, { v -> phone = v.filter { it.isDigit() || it == '+' || it == ' ' }.take(16); error = null },
            label = { Text(tr("मोबाइल नंबर", "Mobile number")) },
            prefix = { Text("+91 ") }, placeholder = { Text("98765 43210") }, singleLine = true,
            isError = phone.isNotBlank() && !ok,
            supportingText = {
                if (phone.isNotBlank() && !ok) Text(tr("10 अंकों का सही नंबर डालें", "Enter a valid 10-digit number"))
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth(), colors = fieldColors())
        error?.let { Text(it, color = Red, modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.height(16.dp))
        AppButton(
            if (busy) tr("सेव हो रहा है…", "Saving…") else tr("सेव करें और आगे बढ़ें", "Save and continue"),
            { busy = true; onSave(phone) { e -> busy = false; error = e } },
            modifier = Modifier.fillMaxWidth(), enabled = ok && !busy
        )
        ButtonHint(if (!ok && !busy) tr("सेव के लिए 10 अंकों का नंबर डालें", "Enter a 10-digit number to enable Save") else "")
        Spacer(Modifier.height(10.dp))
        AppButton(tr("साइन आउट", "Sign out"), onSignOut, modifier = Modifier.fillMaxWidth(), kind = BtnKind.Outline)
    }
}
