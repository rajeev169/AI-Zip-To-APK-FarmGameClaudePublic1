# Tester Track v1.3.2

Admin + tester app in the Samuh Khata style (purple header, "नमस्ते, Name", white summary card).

- Package: `com.rajeev.testertrack` (name "Tester Track" can be changed later in `res/values/strings.xml`)
- Kotlin + Jetpack Compose, Firebase Auth (Google sign-in) + Firestore, minSdk 26, targetSdk 35

## v1.3.2 — fully automatic tracking (no duty, no task buttons)
**Publish the new `firestore.rules`** (Firebase Console > Firestore > Rules) before installing this version. Testers accept the updated notice once (consent v6).

- **On/off duty removed completely.** No duty button, pills, hours or duty notifications. The tester's phone watches the admin's tracked apps all the time in the background (notification: "Your admin's chosen apps are being checked"). Old duty data is cleaned up on update.
- **Every open is recorded**: start time, end time and minutes, for the tracked apps only. The phone looks every 5 seconds (screen on only) and uploads within seconds of opening/closing; the 5-minute check and the 15-minute job catch up if the phone stopped the service. Admin sees a timeline on the tester's page ("Pulse Music · 11:42 – 11:54 am · 12 min"), "Opened N times", and a 7-day history (☰/tester page → 7 days). Kept 14 days.
- **Admin home**: card shows the group's minutes in your apps today; each tester shows "Active" (open now / in the last 30 min) or "Last opened 3:10 pm", minutes today and Day N.
- **Alerts to the admin (name, date, time)**: tester clicked a task's link · installed an app · installed and opened it and started working · first open of each app each day ("opened today · 11:42 am (Day 6)") · uninstalled (with time) · 🎉 Congratulations, completed (all 14 days green) · failed the 14 days (missed N days).
- **Tasks move by themselves** — the tester's Start and Mark done buttons are gone. New task has a **Tracked app** choice ("Other" = no tracking). Pending → shows "Link opened" when the tester taps Open link → **Working** when the app is installed and opened after the task was given → **Done** when all 14 days are green, or **Failed** when a day was missed. The admin can still tap a task to change it (Pending / Working / Done / Failed) or delete it; a task you mark **Done by hand** also shows the "Rewards ready ₹14" card (you still confirm Give).
- **14-day check**: the task runs the full 14 days. After Day 14: all green → congratulations to you + reward card; any day missed → alert to you and a "Sorry Vikash, you failed to get rewards for Pulse Music" notice to the tester. Days before tracking could see (first days after updating) don't count as missed.
- **Uninstall / reinstall**: you get the uninstall alert at once. Reinstalled **the same day** → the 14 days carry on unchanged. Reinstalled **a later day** → starts again from Day 1. Uninstalled and never reinstalled → Failed after Day 14 (alert + Sorry notice).
- **Tester reminders on the lock screen** (during the 14 days): **4:30 pm** "You haven't opened Pulse Music today" (only if not opened yet) and **9 am** "You missed Pulse Music yesterday (Day 6)". Tapping opens the tracked app. Also saved in Notifications.
- **Security**: an invite can only be changed by the admin who made it (another team can't take over your tester's invite); the tester's phone id can't be changed once saved.
- **Setup screen** no longer jumps to home right after the last permission, so testers also see the Auto-start step (if everything was already allowed earlier, it still opens home directly).
- **Play Console**: Foreground service "special use" text updated in the manifest. Data safety: App activity (which of the admin's apps were opened, when and for how long), app installs of selected apps, Device or other IDs.

## v1.3.1
- Redesigned the permission setup screen: purple header with a progress bar, one card per step (Needed / Allowed), optional Auto-start card, fixed Continue bar.

## What is new in v1.3.0
- **Co-admins**: admin opens a tester's page and taps *Make co-admin* (any number of co-admins). A co-admin stays a normal tester and gets one extra menu item, **Add member**: Gmail + name, sent to the admin as a request. Each co-admin can send **5 requests per day** (enforced in `firestore.rules`; the day changes at 5:30 am India time). The admin sees **Member requests** on the home screen with Approve / Decline and gets a notification; approving creates the normal invite, so the person becomes a tester when they sign in with that Gmail. Removing a co-admin does not cancel their pending requests.
- **Share app** (☰, everyone): the admin saves one download link (Play testing link, Play Store link or a Drive link); everyone can share or copy it with a ready message. Having the link does not add anyone.
- **Keep running**: background services are restarted by the 15-minute jobs, after a swipe from recents, after reboot and after an app update. Setup screen now also offers the phone maker's *Auto-start* page (Xiaomi, Oppo/Realme, Vivo, Huawei, Asus). The admin sees a warning on a tester's page when their phone has not reported for 45+ minutes. A manual *Force stop* cannot be overcome by any app.
- Fixes: notification permission can no longer dead-end the setup screen; withdrawal payout and closing the request are now one atomic step.

**Publish the new `firestore.rules`** (Firebase Console > Firestore > Rules) before using co-admins; without it requests are refused.

## Features
**Admin (you)**
- Home: team name, नमस्ते + your photo, chips (एडमिन, N टेस्टर)
- Card "group time in your apps today" + tiles: पूरे / चालू / बाकी टास्क
- Testers list: Active / last opened, minutes in your apps today, Day N, active tasks
- Tester detail: minutes today, task tiles, per-app usage and every open today, 7-day history
- ☰ menu: add/remove testers (by Gmail), tracked apps, new task, all tasks
- Tap any task to change status or delete

**Tester**
- Same header ("टेस्टर", "ड्यूटी पर / बंद")
- Card "today in the apps" + पूरे / चालू / बाकी tiles
- My tasks (status moves by itself; no buttons)
- Sees their own app usage too (transparency)

**Both**: ☰ opens a full Menu page; profile photo + name in ⚙️ Settings; **English / हिंदी** switch only in Settings (English by default, saved per phone); sign out; delete account.

**Tester mobile number**: required once right after joining, editable in Settings. Admin sees it on the tester's page with a **Call** button, and a 📞 button in the home Tester list (opens the dialer).

**Waiting testers**: Gmails the admin added that haven't signed in show on the home screen as "Not signed in yet"; the header chip (e.g. "1 tester · 1 waiting") opens the Testers page.

**Home design (v1.0.6)**: admin and tester homes have a purple background; the header and white work card stay fixed while the list scrolls under a rounded, card-shaped edge; short tile labels (Done / Working / Pending); long names shrink to fit; no floating New task button (New task is in ☰ Menu); Sign out only in Settings.

**App link on tasks**: New task has an optional App link (Play closed-testing or Google Drive APK link); testers get an Open link button. Free — nothing is stored in Firebase Storage.

**Tester notifications**: bell with unread count in the header, Notifications page (Mark all read). Created when the admin adds a task, changes its status, or deletes it. Phone notifications appear instantly while the app is open and via a background check about every 15 minutes when closed (no paid Firebase plan needed).

**All tasks page (v1.0.7)**: the four filters (All / Done / Working / Pending) share the width so all fit; each task shows its status beside the title, with the date on its own line; divider lines only between tasks.

**New task, several testers (v1.0.8)**: pick testers one by one or tap “All testers”; each picked tester gets their own copy of the task and their own notification; Add stays off until there is a title and at least one tester.

**Three-layer home (v1.0.9)**, admin and tester: fixed purple background; a full-height scrolling layer of cards; a floating top layer (profile pic, menu, settings, chips, bell and the work card) that stays in place while the cards scroll behind it, with a soft purple strip behind the greeting while scrolled.

**Clear buttons (v1.1.0)**: one button style everywhere. Main actions are solid purple (Start duty green, End duty / Delete solid red), second actions are white with a purple border, risky ones white with a red border. A button that is off turns grey, with a small grey line under it saying what to do to turn it on. Tester chips in New task are white boxes with a border and turn solid purple with ✓ when picked; text boxes have a darker outline on white. Covers New task, Testers, Tracked apps, tasks, All tasks, Settings, Duty, Usage access banner, Notifications (Mark all read), mobile number page and sign-in/setup pages.

**App watch (v1.2.0)** — for the admin's **tracked apps** only (☰ → Tracked apps); no other app is looked at or uploaded:
- **Install / uninstall alerts**: instant (a few seconds). Like Family Shield, a small background service on the tester's phone listens for install/remove, and a "Watching for tester alerts" service on the admin's phone shows the alert the moment it arrives. Uninstall message includes how long it lasted, e.g. “My App (day 9 · opened 7 days)”.
- **Daily open count**: Day 1 = the real install day; the tester page shows “Day N”, “opened X of N days”, and a row of dots for the last 14 days (green = opened that day) plus “Opened today”. Counting stops when the app is uninstalled and the record stays as “Uninstalled · lasted N days”. Re-installing starts again at Day 1. Needs the tester's **Usage access** (existing banner); the admin sees a warning if it is off. Android keeps about a week of history, so counts are filled in right after install and catch up if the phone was off.
- **Missed-day reminder**: from 9 am you get one notification per tester, e.g. “Aman didn't open an app yesterday — My App (day 6 · missed 2 days in a row)”, with a **Call** button on the notification. Skips the install day itself, sends once per app per day, and needs the tester's Usage access. On first setup it starts from the next day, so you aren't flooded.
- **Tester home**: the Duty card and "On duty" chip are replaced by **Testing days (1–14)** — one row of numbered circles per tracked app: green = opened that day, red = day passed without opening, outlined = today (open it to turn green), grey = not reached. The header chip shows "Day N".
- Runs on and off duty while the tester is signed in (notification: “On duty” or “Your admin's chosen apps … are being checked”). Services restart after reboot; a 15-min background job is the fallback.
- Apps the admin adds later are not announced as "new" if already installed; apps removed from the list stop being watched.
- Testers must accept the updated notice once. **Update `firestore.rules`** (new `installed` collection; testers may create app-install notices for the admin only).
- If battery saver kills the service, set Tester Track to "Unrestricted" battery on that phone.

**Tester permission setup (v1.2.1)** — after a tester saves their phone number, Tester Track shows one setup screen before the tester home:
- Usage access opens Android's Usage Access settings.
- Keep running requests Android's battery-optimization exemption and verifies the result as **Unrestricted**.
- Notifications requests Android 13+ notification permission.
- The tester cannot continue to the home until all applicable items are granted. Foreground service access is controlled by Android when the monitoring service runs; it has no separate runtime permission screen.
- Android still requires the tester to approve special settings. Tester Track never silently changes system permissions.

**Loud alerts + wallet (v1.2.0)**
- Every notification (tasks, rewards, install/uninstall/missed-day alerts) pops up with a long vibration, and the app itself plays a loud sound at **alarm volume** (alarm volume is raised to ~80% for 4 s, then restored). Many phones (Realme/Oppo/Xiaomi/Vivo) mute an app's own channel sound, which is why the sound is played by the app. It does not play when the phone is on silent/vibrate or Do Not Disturb is on. **Settings → Alert sound → Test alert sound** checks it.
- The tester home has a **₹ wallet chip** next to the bell showing the balance.
- **Wallet**: ₹14 per tester per tracked app, only when all 14 days (Day 1–14 from install) are green with no missed day. When that happens the admin gets an alert and a **Rewards ready** card on the home screen with the tester's name and a **Give ₹14** button (with a confirm). The money is added only when the admin taps it; the tester gets a notification and sees it in **Wallet** on their home screen.
- The ledger is append-only (nobody can edit or delete lines), each install can be paid once, and only the admin can add lines. The tester's page (admin view) shows the wallet and a **Mark paid** button to record a payout after you send the money yourself.
- **Update `firestore.rules`** (new `wallet_tx` collection, new `app_ready` type).

**One phone, one reward (v1.2.0)**: each tester account saves a scrambled phone id (SHA-256 of Android's per-phone id, shortened) on its member record. If two Gmails are signed in on the same phone, the admin sees a ⚠ "Same phone as …" warning on the tester page and on the **Rewards ready** card, the confirm dialog repeats it, and once one account on that phone has been paid for an app, the Give button for the others is disabled. Limits: a second real phone, a factory reset, or a "Dual apps / clone app / second space" profile (separate Android user) looks like a different phone. Play Data safety: declare "Device or other IDs". Testers must accept the updated notice once (consent v4).

**Copies of the app are blocked (v1.2.0)**: if Tester Track is opened inside Dual apps / App clone / Second space / a work profile / Secure Folder (different Android user) or inside a cloner app such as Parallel Space, it shows a block screen and does not sign in, track or send anything. Android doesn't let an app stop another copy from being *installed* (or even see it from another user space), so the copy refuses to *run*. The block screen shows the technical reason, so a false alarm can be diagnosed. Admin phones are checked the same way: use the original app.

**Withdraw to UPI (v1.2.0)**: on the tester's **Wallet** screen the tester saves a UPI ID (checked for a valid format, kept on their member record) and taps **Request withdrawal of ₹X**. One request at a time; they can cancel it. The admin gets a notification and a **Withdrawal requests** card on the home screen with the tester's name, the real wallet balance (taken from the ledger, not from the request) and the UPI ID, plus **Copy UPI**, **Pay in UPI app** (opens GPay/PhonePe/Paytm with the payee and amount filled in), **Mark ₹X paid** and **Decline**. The app never moves money: the admin pays in a UPI app, then taps Mark paid, which records a payout line (wallet goes to ₹0), closes the request and notifies the tester. Minimum withdrawal ₹14. **Update `firestore.rules`** (new `withdrawals` collection, new `withdraw_request` notice type).

**Time-in-app graph (v1.2.0)**: for each tracked app the tester's phone measures the minutes it was in the foreground each day (today, plus the last 7 days once) and saves them with the app's record. Tester home and the admin's tester page show a bar chart for Day 1–14 (from the install day) with the minutes on each bar, the total and the daily average. Only the admin's tracked apps are measured; times are in minutes, never what happens inside the app. Needs Usage access; works on and off duty. Android keeps about a week of history, so days before tracking started can't be filled in. Consent is now v5 (testers accept once more). Play Data safety: App activity (time in selected apps).

**Icon**: AppForge logo (launcher icon, login page, header fallback) + white silhouette notification icon.

**Linking**: admin creates the group with its name (editable in Settings) and adds testers by Gmail. The tester signs in with that Gmail and joins directly, then sees a one-time "what is tracked" consent screen. A Gmail that isn't added gets a "Recheck" / "Create team (admin)" screen, so a tester can't become admin by accident.

**App usage** (v1.3.2): only for the package names you add in Tracked apps — each open (time and length) and minutes per day, all the time in the background. Tester must allow "Usage access" once (setup screen).

## Firebase setup (one time)
1. Firebase Console → new project **Tester Track**.
2. Add Android app, package `com.rajeev.testertrack`, add the **same SHA-1** as your other apps.
3. Authentication → Sign-in method → enable **Google**.
4. Firestore Database → Create (production mode) → Rules → paste `firestore.rules` from this zip → Publish.
5. Download `google-services.json` → put it in the **`app/`** folder of this project.
6. Zip and push to your build repo as usual.

Without `google-services.json` the app still builds, but sign-in shows a "file missing" message.

## Play Store notes
- Play Console: declare Foreground service "special use" (reason is in the manifest). Declare in Data safety: name, email, photo, app activity (app usage of selected apps), whether chosen apps are installed and the days they were opened (on and off duty), collected for app functionality, deletable in-app.
- Privacy policy should say (v1.3.2): for the admin's chosen apps only — whether they are installed, each time they are opened (time and duration) and minutes per day — is recorded in the background and shown to the admin, with the tester's consent; no location, no messages/calls/photos, nothing about other apps or what is done inside the apps.
