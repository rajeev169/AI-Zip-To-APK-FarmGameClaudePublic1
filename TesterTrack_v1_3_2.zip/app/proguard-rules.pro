# Minify is off; rules kept for future use.
-keep class com.google.firebase.** { *; }
