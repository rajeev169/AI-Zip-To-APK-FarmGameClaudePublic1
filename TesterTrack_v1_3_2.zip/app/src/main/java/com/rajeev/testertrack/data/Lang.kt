package com.rajeev.testertrack.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** App language: "en" (default) or "hi". Each phone keeps its own choice. */
object Lang {
    var code by mutableStateOf("en")
        private set

    private fun prefs(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(c: Context) {
        code = prefs(c).getString("lang", "en") ?: "en"
    }

    fun set(c: Context, newCode: String) {
        code = newCode
        prefs(c).edit().putString("lang", newCode).apply()
    }

    val isEnglish: Boolean get() = code == "en"
}

/** Pick the Hindi or English text for the current language. */
fun tr(hi: String, en: String): String = if (Lang.isEnglish) en else hi
