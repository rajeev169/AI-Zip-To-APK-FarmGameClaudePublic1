package com.rajeev.testertrack.tracking

import android.content.Context

/**
 * Detects a COPY of the app: "Dual apps" / "App clone" / "Second space" / work profile / Secure Folder (these run as a
 * different Android user) and app-cloner apps like Parallel Space (these run inside another app's data folder).
 * Android never lets an app stop another copy from being installed, or even see it from another user space,
 * so the copy itself refuses to run. That is where the cheating (a second account on the same phone) would happen.
 */
object CloneGuard {
    /** null = this is the normal, original app. Otherwise a short technical reason, shown on the block screen. */
    fun check(c: Context): String? {
        // Android user id = uid / 100000. The phone's owner space is always 0; clones/work profiles/Secure Folder are not.
        val userId = android.os.Process.myUid() / 100000
        if (userId != 0) return "user space $userId"

        // Cloner apps run us inside their own folder, e.g. /data/user/0/<cloner package>/.../<our package>/
        val pkg = c.packageName
        val path = try { c.filesDir.absolutePath } catch (_: Exception) { return null }
        val normal = path.startsWith("/data/user/0/$pkg/") || path.startsWith("/data/data/$pkg/")
        if (!normal) return "data folder $path"
        return null
    }
}
