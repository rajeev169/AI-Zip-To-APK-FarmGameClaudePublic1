package com.rajeev.testertrack.tracking

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * Brings the background services back if the phone stopped them. No app can survive a manual "Force stop",
 * but this covers a swipe from recents, the system killing the app for memory, a reboot and an app update.
 * Starting a foreground service from the background is allowed because the tester gives the "Unrestricted battery" setting.
 */
object KeepAlive {
    private const val RESTART_WORK = "keepalive_restart"

    /** Starts whichever service this phone needs (tester: WatchService, admin: AdminAlertService). Safe to call often. */
    fun ensure(c: Context) {
        try { if (InstallWatch.active(c)) WatchService.start(c) } catch (_: Exception) {}
        try { if (TaskAlerts.adminWatch(c)) AdminAlertService.start(c) } catch (_: Exception) {}
    }

    /** Called when the tester swipes the app away: a moment later, check that the services are still running. */
    fun restartSoon(c: Context) {
        try {
            val req = OneTimeWorkRequestBuilder<WatchWorker>().setInitialDelay(5, TimeUnit.SECONDS).build()
            WorkManager.getInstance(c).enqueueUniqueWork(RESTART_WORK, ExistingWorkPolicy.REPLACE, req)
        } catch (_: Exception) {}
    }
}

/** Opens the phone maker's own "Auto-start / Background activity" page when it exists, otherwise this app's info page. */
object OemSettings {
    private val pages = listOf(
        "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",          // Xiaomi, Redmi, Poco
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",     // Oppo, Realme (older)
        "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",     // Vivo
        "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",                      // iQOO
        "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity", // Huawei, Honor
        "com.asus.mobilemanager" to "com.asus.mobilemanager.powersaver.PowerSaverSettings",                 // Asus
    )

    fun openAutoStart(c: Context) {
        for ((pkg, cls) in pages) {
            try {
                c.startActivity(Intent().setComponent(ComponentName(pkg, cls)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {
                // this maker's page is not on this phone; try the next one
            }
        }
        try {
            c.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            try { c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }

    fun openNotificationSettings(c: Context) {
        try {
            c.startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            openAutoStart(c)
        }
    }
}
