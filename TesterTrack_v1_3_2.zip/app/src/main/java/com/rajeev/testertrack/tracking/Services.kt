package com.rajeev.testertrack.tracking

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.ListenerRegistration
import com.rajeev.testertrack.MainActivity
import com.rajeev.testertrack.R
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.tr
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Live Firestore listener: shows a phone notification the moment a new one is written for this person. */
object NotifListener {
    fun start(c: Context, scope: CoroutineScope): ListenerRegistration? {
        val teamId = TaskAlerts.teamId(c)
        val uid = TaskAlerts.uid(c)
        if (teamId.isBlank() || uid.isBlank()) return null
        return Repo.notifsQuery(teamId, uid).addSnapshotListener { snap, _ ->
            if (snap != null && snap.documents.any { it.getBoolean("pushed") != true }) {
                scope.launch { try { TaskAlerts.check(c) } catch (_: Exception) {} }
            }
        }
    }
}

private fun Service.goForeground(id: Int, n: Notification) {
    try {
        if (Build.VERSION.SDK_INT >= 34) startForeground(id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(id, n)
    } catch (_: Exception) {}
}

/**
 * Runs on the tester's phone all the time while signed in (no duty button any more).
 * Listens for app install / remove, and every few seconds (screen on only) looks whether a tracked app was opened or
 * closed, so the admin is told within seconds and every open is recorded with its time.
 */
class WatchService : Service() {
    companion object {
        fun start(c: Context) {
            try { ContextCompat.startForegroundService(c, Intent(c, WatchService::class.java)) } catch (_: Exception) {}
        }
        fun stop(c: Context) { c.stopService(Intent(c, WatchService::class.java)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var receiver: BroadcastReceiver? = null
    private var reg: ListenerRegistration? = null
    private var looping = false
    private var syncJob: kotlinx.coroutines.Job? = null

    /** Runs a full check shortly (several triggers close together become one check). */
    private fun syncSoon(waitMs: Long) {
        if (syncJob?.isActive == true) return
        syncJob = scope.launch {
            delay(waitMs)
            try { InstallWatch.sync(this@WatchService) } catch (_: Exception) {}
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        WatchNotice.createChannel(this)
        goForeground(WatchNotice.NOTIF_ID, WatchNotice.build(this))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!InstallWatch.active(this)) { stopSelf(); return START_NOT_STICKY }
        goForeground(WatchNotice.NOTIF_ID, WatchNotice.build(this))
        if (receiver == null) {
            val r = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    // the app may not be launchable the very instant it is added; short wait, then check
                    scope.launch { delay(2_000); try { InstallWatch.sync(this@WatchService) } catch (_: Exception) {} }
                }
            }
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addDataScheme("package")
            }
            ContextCompat.registerReceiver(this, r, f, ContextCompat.RECEIVER_EXPORTED)
            receiver = r
        }
        if (reg == null) reg = NotifListener.start(this, scope)   // task notices arrive instantly too
        if (!looping) {
            looping = true
            scope.launch {
                while (isActive) {
                    try { InstallWatch.sync(this@WatchService) } catch (_: Exception) {}
                    delay(5 * 60_000L)    // regular check (uploads minutes, reminders, results)
                }
            }
            // every 5 seconds while the screen is on: was a tracked app just opened or closed?
            scope.launch {
                val power = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                while (isActive) {
                    delay(5_000L)
                    if (!power.isInteractive) continue
                    when (try { OpenWatch.tick(this@WatchService) } catch (_: Exception) { 0 }) {
                        1 -> syncSoon(1_500L)    // opened: alert the admin within seconds
                        2 -> syncSoon(4_000L)    // closed: save how long it was open
                    }
                }
            }
        }
        return START_STICKY
    }

    /** The tester swiped Tester Track away from recents: some phones stop the service too, so check again shortly. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        KeepAlive.restartSoon(applicationContext)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        try { receiver?.let { unregisterReceiver(it) } } catch (_: Exception) {}
        reg?.remove()
        scope.cancel()
        super.onDestroy()
    }
}

/** Runs on the admin's phone so tester app-install alerts (and anything else) arrive instantly. */
class AdminAlertService : Service() {
    companion object {
        private const val CH = "watch"
        private const val ID = 7002
        fun start(c: Context) {
            try { ContextCompat.startForegroundService(c, Intent(c, AdminAlertService::class.java)) } catch (_: Exception) {}
        }
        fun stop(c: Context) { c.stopService(Intent(c, AdminAlertService::class.java)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var reg: ListenerRegistration? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CH, tr("अलर्ट निगरानी", "Alert watching"), NotificationManager.IMPORTANCE_MIN).apply { setShowBadge(false) }
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Tester Track")
            .setContentText(tr("टेस्टर के अलर्ट देखे जा रहे हैं", "Watching for tester alerts"))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
        goForeground(ID, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!TaskAlerts.adminWatch(this)) { stopSelf(); return START_NOT_STICKY }
        if (reg == null) reg = NotifListener.start(this, scope)
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        KeepAlive.restartSoon(applicationContext)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        reg?.remove()
        scope.cancel()
        super.onDestroy()
    }
}

/** Restarts the services after the phone restarts or the app updates. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        KeepAlive.ensure(context)
    }
}


/**
 * Plays the alert sound itself at ALARM volume, because many phones (Realme, Oppo, Xiaomi, Vivo...) silence or ignore the
 * sound of an app's notification channel. Skipped when the phone is on silent/vibrate or Do Not Disturb is on, so it never
 * wakes someone who muted their phone. The alarm volume is raised to ~80% for 4 seconds and then put back.
 */
object AlertSound {
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private var ringtone: android.media.Ringtone? = null
    private var savedVolume: Int? = null
    private var am: android.media.AudioManager? = null
    private val stop = Runnable { stopNow() }

    fun play(c: Context) {
        val app = c.applicationContext
        main.post {
            try {
                val audio = app.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                val nm = app.getSystemService(NotificationManager::class.java)
                if (audio.ringerMode != android.media.AudioManager.RINGER_MODE_NORMAL) return@post
                if (nm.currentInterruptionFilter > android.app.NotificationManager.INTERRUPTION_FILTER_ALL) return@post
                am = audio
                val max = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM)
                val target = (max * 0.8).toInt().coerceAtLeast(1)
                val now = audio.getStreamVolume(android.media.AudioManager.STREAM_ALARM)
                if (savedVolume == null && now < target) {
                    savedVolume = now
                    audio.setStreamVolume(android.media.AudioManager.STREAM_ALARM, target, 0)
                }
                if (ringtone?.isPlaying != true) {
                    val attrs = android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                    val r = android.media.RingtoneManager.getRingtone(
                        app, android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
                    )
                    r.audioAttributes = attrs
                    r.play()
                    ringtone = r
                }
                main.removeCallbacks(stop)
                main.postDelayed(stop, 4_000)
            } catch (_: Exception) {}
        }
    }

    private fun stopNow() {
        try { ringtone?.stop() } catch (_: Exception) {}
        ringtone = null
        val v = savedVolume
        if (v != null) {
            try { am?.setStreamVolume(android.media.AudioManager.STREAM_ALARM, v, 0) } catch (_: Exception) {}
            savedVolume = null
        }
    }
}
