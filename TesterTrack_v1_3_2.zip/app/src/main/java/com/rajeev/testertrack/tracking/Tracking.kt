package com.rajeev.testertrack.tracking

import com.rajeev.testertrack.data.tr
import android.Manifest
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.rajeev.testertrack.MainActivity
import com.rajeev.testertrack.R
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.OpenSession
import com.rajeev.testertrack.data.TaskStatus
import com.rajeev.testertrack.data.encodeSessions
import com.rajeev.testertrack.data.trackedPkg
import com.rajeev.testertrack.data.Notif
import com.rajeev.testertrack.data.NotifType
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.TimeUnit

/** The admin's tracked apps, saved on this phone so the background checks know what to watch. */
object TrackPrefs {
    private const val FILE = "duty"   // same file as earlier versions, so the saved list carries over
    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun setApps(c: Context, apps: List<com.rajeev.testertrack.data.TrackedApp>) {
        p(c).edit()
            .putStringSet("pkgs", apps.map { it.pkg }.toSet())
            .putStringSet("names", apps.map { "${it.pkg}\t${it.name}" }.toSet())
            .apply()
    }

    fun packages(c: Context): Set<String> = p(c).getStringSet("pkgs", emptySet()) ?: emptySet()

    fun apps(c: Context): List<com.rajeev.testertrack.data.TrackedApp> {
        val names = (p(c).getStringSet("names", emptySet()) ?: emptySet()).associate { e ->
            val parts = e.split('\t'); parts[0] to (parts.getOrNull(1) ?: "")
        }
        return packages(c).map { com.rajeev.testertrack.data.TrackedApp(names[it] ?: "", it) }
    }

    /** Old duty data from v1.3.1 and earlier. */
    fun clearOldDuty(c: Context) {
        p(c).edit().remove("teamId").remove("uid").remove("sessionId").remove("start").apply()
        try { WorkManager.getInstance(c).cancelUniqueWork("usage_sync") } catch (_: Exception) {}
    }
}

object UsageAccess {
    // Raw event codes (ACTIVITY_RESUMED=1, ACTIVITY_PAUSED=2, ACTIVITY_STOPPED=23) so this works on Android 8+
    private const val EV_RESUMED = 1
    private const val EV_PAUSED = 2
    private const val EV_STOPPED = 23

    fun granted(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openSettings(c: Context) {
        val i = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.startActivity(i) } catch (_: Exception) {
            c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /**
     * Foreground time (ms) per package between [from] and [to], counted ONLY for [pkgs]
     * (the admin's own apps). Nothing else on the phone is read or uploaded.
     */
    fun measure(c: Context, from: Long, to: Long, pkgs: Set<String>): Map<String, Long> {
        if (pkgs.isEmpty() || !granted(c) || to <= from) return emptyMap()
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(from, to)
        val openSince = HashMap<String, Long>()
        val total = HashMap<String, Long>()
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            if (pkg !in pkgs) continue
            when (e.eventType) {
                EV_RESUMED -> openSince[pkg] = e.timeStamp
                EV_PAUSED, EV_STOPPED -> {
                    val s = openSince.remove(pkg)
                    if (s != null) total[pkg] = (total[pkg] ?: 0L) + (e.timeStamp - s).coerceAtLeast(0)
                }
            }
        }
        // still open at the end of the window
        openSince.forEach { (pkg, s) -> total[pkg] = (total[pkg] ?: 0L) + (to - s).coerceAtLeast(0) }
        return total.filterValues { it > 0 }
    }

    /**
     * Every time one of [pkgs] was on screen between [from] and [to]: start and end. Switching screens inside the app
     * (a gap of up to 15 s) counts as the same visit. If [stillOpen] and the app is on screen at [to], end = 0.
     */
    fun sessions(c: Context, from: Long, to: Long, pkgs: Set<String>, stillOpen: Boolean): Map<String, List<OpenSession>> {
        if (pkgs.isEmpty() || !granted(c) || to <= from) return emptyMap()
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(from, to)
        val openSince = HashMap<String, Long>()
        val seen = HashSet<String>()
        val raw = HashMap<String, MutableList<OpenSession>>()
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            if (pkg !in pkgs) continue
            when (e.eventType) {
                EV_RESUMED -> { if (pkg !in openSince) openSince[pkg] = e.timeStamp; seen += pkg }
                EV_PAUSED, EV_STOPPED -> {
                    val s = openSince.remove(pkg) ?: if (pkg !in seen) from else null   // opened before [from] (e.g. before midnight)
                    seen += pkg
                    if (s != null && e.timeStamp > s) raw.getOrPut(pkg) { ArrayList() } += OpenSession(s, e.timeStamp)
                }
            }
        }
        openSince.forEach { (pkg, s) -> raw.getOrPut(pkg) { ArrayList() } += OpenSession(s, if (stillOpen) 0L else to) }
        return raw.mapValues { (_, list) ->
            val merged = ArrayList<OpenSession>()
            for (x in list.sortedBy { it.start }) {
                val last = merged.lastOrNull()
                if (last != null && last.end > 0 && x.start - last.end <= 15_000L) {
                    merged[merged.lastIndex] = OpenSession(last.start, if (x.end == 0L) 0L else maxOf(last.end, x.end))
                } else merged += x
            }
            merged.filter { it.end == 0L || it.end - it.start >= 1_000L }
        }.filterValues { it.isNotEmpty() }
    }
}

/**
 * Looks every few seconds (only while the screen is on) whether a tracked app just came to the screen or left it.
 * Returns 1 = opened, 2 = closed, 0 = nothing. The real work (alerts, upload) is done by [InstallWatch.sync].
 */
object OpenWatch {
    private var lastTs = 0L
    private var from = 0L

    fun tick(c: Context): Int {
        val pkgs = TrackPrefs.packages(c)
        if (pkgs.isEmpty() || !UsageAccess.granted(c)) return 0
        val now = System.currentTimeMillis()
        val start = if (from == 0L) now - 10_000L else from - 3_000L
        from = now
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = try { usm.queryEvents(start, now) } catch (_: Exception) { return 0 }
        var result = 0
        var maxTs = lastTs
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.timeStamp <= lastTs) continue
            val pkg = e.packageName ?: continue
            if (pkg !in pkgs) continue
            when (e.eventType) {
                1 -> result = 1
                2, 23 -> if (result == 0) result = 2
                else -> continue
            }
            if (e.timeStamp > maxTs) maxTs = e.timeStamp
        }
        lastTs = maxTs
        return result
    }
}

/** Android's user-approved Doze exemption used for reliable background test monitoring. */
object BatteryOptimization {
    fun unrestricted(c: Context): Boolean {
        val pm = c.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        return pm.isIgnoringBatteryOptimizations(c.packageName)
    }

    fun request(c: Context) {
        val request = Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            android.net.Uri.parse("package:${c.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            c.startActivity(request)
        } catch (_: Exception) {
            // Some OEMs do not expose the direct prompt; show the system list instead.
            try {
                c.startActivity(
                    Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
                c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}

/** The always-on notification on the tester's phone while Tester Track watches the admin's apps. */
object WatchNotice {
    const val CHANNEL = "duty"   // same id as earlier versions
    const val NOTIF_ID = 7001

    fun createChannel(c: Context) {
        val ch = NotificationChannel(CHANNEL, tr("ऐप निगरानी", "App watching"), NotificationManager.IMPORTANCE_LOW).apply {
            description = tr("Tester Track एडमिन के चुने ऐप्स देख रहा है", "Shown while Tester Track checks your admin's chosen apps")
        }
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    fun build(c: Context): android.app.Notification {
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Tester Track")
            .setContentText(tr("आपके एडमिन के चुने ऐप्स देखे जा रहे हैं", "Your admin's chosen apps are being checked"))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }

    fun hide(c: Context) = NotificationManagerCompat.from(c).cancel(NOTIF_ID)
}

/**
 * For the admin's TRACKED apps only (☰ → Tracked apps), on the tester's phone, all in the background:
 *  - tells the admin when one is installed, opened for the first time ("started working"), opened each day, or uninstalled,
 *  - records every open (start, end) and the minutes per day,
 *  - counts the 14 testing days (Day 1 = install day; a re-install on the same day carries on, a later day starts again),
 *  - after Day 14: congratulations (all green) or "failed" (a day was missed), to the admin and the tester,
 *  - reminds the tester at 4:30 pm and tells them next morning about a missed day,
 *  - moves the tester's tasks: Working when the app is installed and opened, Done / Failed after the 14 days.
 * Never what is done inside an app, and nothing about other apps.
 */
object InstallWatch {
    private val lock = Mutex()
    private const val TOUCH_EVERY_MS = 10 * 60_000L
    private const val DAY_MS = 24L * 60 * 60 * 1000
    private const val WORK = "install_watch"
    private const val MISSED_ALERT_HOUR = 9      // yesterday's missed open: admin + tester, from 9 am
    private const val REMIND_MINUTE = 16 * 60 + 30   // 4:30 pm reminder to the tester
    private fun p(c: Context) = c.getSharedPreferences("installwatch", Context.MODE_PRIVATE)

    private data class Known(val name: String, val start: Long)
    /** An app that was uninstalled: its 14 days still get their result after Day 14 unless it is re-installed. */
    private data class Gone(val pkg: String, val name: String, val start: Long, val at: Long)

    fun setTarget(c: Context, teamId: String, uid: String, name: String, phone: String = "") {
        val changed = p(c).getString("uid", "") != uid || p(c).getString("teamId", "") != teamId
        val e = p(c).edit()
        if (changed) e.clear()   // new person on this phone -> fresh baseline
        e.putString("teamId", teamId).putString("uid", uid).putString("name", name).putString("phone", phone).apply()
    }

    fun active(c: Context) = !p(c).getString("uid", "").isNullOrBlank()

    fun clear(c: Context) {
        p(c).edit().clear().apply()
        WorkManager.getInstance(c).cancelUniqueWork(WORK)
    }

    /** Fallback every ~15 min in case the service was stopped by the phone. */
    fun schedule(c: Context) {
        val req = PeriodicWorkRequestBuilder<WatchWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    @Suppress("DEPRECATION")
    private fun firstInstall(pm: android.content.pm.PackageManager, pkg: String): Long =
        try { pm.getPackageInfo(pkg, 0).firstInstallTime } catch (_: Exception) { System.currentTimeMillis() }

    /** Day 1 of this install: the install time, or the old Day 1 when it was re-installed on the day it was removed. */
    private fun startFor(c: Context, pkg: String, installedAt: Long): Long {
        val v = p(c).getString("cont_$pkg", null) ?: return installedAt
        val parts = v.split('|')
        return if (parts.getOrNull(0)?.toLongOrNull() == installedAt) parts.getOrNull(1)?.toLongOrNull() ?: installedAt else installedAt
    }

    /** Only the admin's tracked packages that are installed (and have a launcher icon). */
    private fun trackedInstalled(c: Context, tracked: Set<String>): Map<String, Known> {
        if (tracked.isEmpty()) return emptyMap()
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first in tracked }
            .associate { (pkg, label) -> pkg to Known(label, startFor(c, pkg, firstInstall(pm, pkg))) }
    }

    // stored as "pkg<TAB>name<TAB>start" so the name and Day-1 time are still known after the app is removed
    private fun readKnown(c: Context): Map<String, Known>? =
        p(c).getStringSet("known", null)?.associate { e ->
            val parts = e.split('\t')
            parts[0] to Known(parts.getOrNull(1) ?: parts[0], parts.getOrNull(2)?.toLongOrNull() ?: 0L)
        }

    private fun save(c: Context, apps: Map<String, Known>, tracked: Set<String>, now: Long) {
        p(c).edit()
            .putStringSet("known", apps.map { (k, v) -> "$k\t${v.name}\t${v.start}" }.toSet())
            .putStringSet("tracked", tracked)
            .putLong("touched", now)
            .apply()
    }

    private fun readGone(c: Context): List<Gone> =
        (p(c).getStringSet("gone", emptySet()) ?: emptySet()).mapNotNull { e ->
            val x = e.split('\t')
            if (x.size < 4) null else Gone(x[0], x[1], x[2].toLongOrNull() ?: 0L, x[3].toLongOrNull() ?: 0L)
        }

    private fun writeGone(c: Context, list: List<Gone>) {
        p(c).edit().putStringSet("gone", list.map { "${it.pkg}\t${it.name}\t${it.start}\t${it.at}" }.toSet()).apply()
    }

    private fun markMissedSeen(c: Context, pkgs: Set<String>) {
        val y = Dates.daysAgoKey(1)
        val e = p(c).edit()
        pkgs.forEach { e.putString("missed_$it", y); e.putString("selfMissed_$it", y) }
        e.apply()
    }

    private fun sentDays(c: Context, pkg: String): Set<String> = HashSet(p(c).getStringSet("sent_$pkg", emptySet()) ?: emptySet())

    /** Days before this could not be seen (Android keeps about a week of history). */
    private fun watchFrom(c: Context, pkg: String, start: Long): Long = p(c).getLong("wf_${pkg}_$start", start)

    private fun setWatchFrom(c: Context, pkg: String, start: Long, value: Long) {
        if (!p(c).contains("wf_${pkg}_$start")) p(c).edit().putLong("wf_${pkg}_$start", value).apply()
    }

    /** This install's 14 days as the phone sees them. Days after an uninstall count as not opened. */
    private fun cycle(c: Context, pkg: String, name: String, start: Long) =
        com.rajeev.testertrack.data.InstalledApp(pkg, name, 0L, start, 0L, sentDays(c, pkg), watchFrom(c, pkg, start))

    /** Days each installed tracked app was opened since the last check (needs Usage access). */
    private fun collectOpens(c: Context, installedPkgs: Set<String>, starts: Map<String, Long>, now: Long): Map<String, Set<String>> {
        val last = p(c).getLong("opensFrom", 0L)
        val from = if (last > 0) maxOf(last - 60 * 60_000L, now - 8 * DAY_MS) else now - 7 * DAY_MS   // Android keeps ~a week
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = try { usm.queryEvents(from, now) } catch (_: Exception) { return emptyMap() }
        val found = HashMap<String, MutableSet<String>>()
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType != 1) continue                    // ACTIVITY_RESUMED = the app was opened / brought to front
            val pkg = e.packageName ?: continue
            if (pkg !in installedPkgs) continue
            if (e.timeStamp < (starts[pkg] ?: 0L)) continue   // before this install
            found.getOrPut(pkg) { HashSet() }.add(Dates.dayKey(e.timeStamp))
        }
        return found
    }

    /** Uploads newly seen open-days. Returns true if something was written. */
    private suspend fun pushOpens(c: Context, teamId: String, uid: String, now: Long, usageOk: Boolean, installed: Map<String, Known>): Boolean {
        if (!usageOk || installed.isEmpty()) return false
        val found = collectOpens(c, installed.keys, installed.mapValues { it.value.start }, now)
        val fresh = HashMap<String, Set<String>>()
        found.forEach { (pkg, days) -> val n = days - sentDays(c, pkg); if (n.isNotEmpty()) fresh[pkg] = n }
        if (fresh.isNotEmpty()) {
            Repo.addOpenDays(teamId, uid, now, usageOk, fresh)
            fresh.forEach { (pkg, n) -> p(c).edit().putStringSet("sent_$pkg", sentDays(c, pkg) + n).apply() }
        }
        p(c).edit().putLong("opensFrom", now).apply()
        return fresh.isNotEmpty()
    }

    private fun dayStart(now: Long, back: Int): Long {
        val cal = java.util.Calendar.getInstance()
        cal.timeInMillis = now
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
        cal.add(java.util.Calendar.DAY_OF_YEAR, -back)
        return cal.timeInMillis
    }

    /**
     * Minutes in each tracked app per day (today, plus the last 7 days once). Only the admin's tracked apps are measured;
     * only changed numbers are uploaded. Past days are measured once because they can't change any more.
     */
    private suspend fun pushMinutes(c: Context, teamId: String, uid: String, now: Long, usageOk: Boolean, installed: Map<String, Known>): Boolean {
        if (!usageOk || installed.isEmpty()) return false
        val pkgs = installed.keys
        val changes = HashMap<String, MutableMap<String, Long>>()
        val toSave = HashMap<String, Long>()
        val doneDays = ArrayList<String>()
        for (back in 0..7) {
            val from = dayStart(now, back)
            val day = Dates.dayKey(from)
            if (back > 0 && p(c).getBoolean("mdone_$day", false)) continue
            val to = minOf(dayStart(now, back - 1), now)
            val per = try { UsageAccess.measure(c, from, to, pkgs) } catch (_: Exception) { continue }
            for (pkg in pkgs) {
                val min = (per[pkg] ?: 0L) / 60_000L
                val key = "m_${pkg}_$day"
                val last = p(c).getLong(key, -1L)
                if (min != last && !(min == 0L && last < 0L)) {
                    changes.getOrPut(pkg) { HashMap() }[day] = min
                    toSave[key] = min
                }
            }
            if (back > 0) doneDays += day
        }
        if (changes.isNotEmpty()) Repo.addMinutes(teamId, uid, now, usageOk, changes)
        val e = p(c).edit()
        toSave.forEach { (k, v) -> e.putLong(k, v) }
        doneDays.forEach { e.putBoolean("mdone_$it", true) }
        e.apply()
        return changes.isNotEmpty()
    }

    /**
     * Every open of each tracked app (today and yesterday), uploaded when it changed. Returns today's opens per app.
     * Days older than 14 days are removed from the record once a day, so it stays small.
     */
    private suspend fun pushSessions(c: Context, teamId: String, uid: String, now: Long, usageOk: Boolean, installed: Map<String, Known>): Pair<Boolean, Map<String, List<OpenSession>>> {
        if (!usageOk || installed.isEmpty()) return false to emptyMap()
        val changes = HashMap<String, MutableMap<String, List<String>?>>()
        val sigs = HashMap<String, String>()
        val today = HashMap<String, List<OpenSession>>()
        for (back in 0..1) {
            val from = dayStart(now, back)
            val to = minOf(dayStart(now, back - 1), now)
            val day = Dates.dayKey(from)
            val per = try { UsageAccess.sessions(c, from, to, installed.keys, stillOpen = back == 0) } catch (_: Exception) { continue }
            for ((pkg, k) in installed) {
                val list = per[pkg].orEmpty().filter { it.start >= k.start || it.end == 0L || it.end >= k.start }
                if (back == 0) today[pkg] = list
                val enc = encodeSessions(list.takeLast(60))
                val key = "o_${pkg}_$day"
                val sig = enc.joinToString(",")
                val last = p(c).getString(key, null)
                if (last != sig && !(enc.isEmpty() && last == null)) {
                    changes.getOrPut(pkg) { HashMap() }[day] = enc
                    sigs[key] = sig
                }
            }
        }
        val todayKey = Dates.dayKey(now)
        val prune = p(c).getString("oprune", "") != todayKey
        if (prune) {
            for (pkg in installed.keys) for (back in 15..21) changes.getOrPut(pkg) { HashMap() }[Dates.dayKey(dayStart(now, back))] = null
        }
        if (changes.isNotEmpty()) {
            Repo.addSessions(teamId, uid, now, usageOk, changes)
            val e = p(c).edit()
            sigs.forEach { (k, v) -> e.putString(k, v) }
            if (prune) e.putString("oprune", todayKey)
            e.apply()
        }
        return changes.isNotEmpty() to today
    }

    /**
     * First open of each app each day -> one alert to the admin with the time. The very first open after an install is
     * "installed and opened, started working" instead.
     */
    private suspend fun checkOpenAlerts(c: Context, teamId: String, uid: String, name: String, phone: String, now: Long,
                                        current: Map<String, Known>, todayOpens: Map<String, List<OpenSession>>) {
        val today = Dates.dayKey(now)
        for ((pkg, k) in current) {
            val first = todayOpens[pkg].orEmpty().minByOrNull { it.start } ?: continue
            if (p(c).getString("openAlert_$pkg", "") == today) continue
            val startedKey = "started_${pkg}_${k.start}"
            if (!p(c).getBoolean(startedKey, false)) {
                Repo.notifyAdmin(teamId, uid, name, NotifType.APP_STARTED, "${k.name} · ${Dates.dateTime(first.start)}", phone, pkg)
                p(c).edit().putBoolean(startedKey, true).putLong("startedAt_${pkg}_${k.start}", first.start).apply()
            } else {
                val day = Dates.dayNumber(k.start, now)
                Repo.notifyAdmin(teamId, uid, name, NotifType.APP_OPENED,
                    "${k.name} · ${Dates.time(first.start)} (${tr("दिन", "Day")} $day)", phone, pkg)
            }
            p(c).edit().putString("openAlert_$pkg", today).apply()
        }
    }

    /**
     * "Didn't open yesterday" reminder to the admin: from 9 am, one notification per tester listing each tracked app that was
     * not opened yesterday (with how many days in a row). Once per app per day. Skips the install day itself.
     */
    private suspend fun checkMissed(c: Context, teamId: String, uid: String, name: String, now: Long, usageOk: Boolean, current: Map<String, Known>) {
        if (!usageOk || current.isEmpty()) return
        if (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) < MISSED_ALERT_HOUR) return
        val yesterday = Dates.daysAgoKey(1)
        val lines = ArrayList<String>()
        val pkgs = ArrayList<String>()
        current.forEach { (pkg, k) ->
            if (p(c).getString("missed_$pkg", "") == yesterday) return@forEach      // already told today
            val installDay = Dates.dayKey(k.start)
            if (installDay >= yesterday) return@forEach                              // not a full day since install yet
            val opened = sentDays(c, pkg)
            if (yesterday in opened) return@forEach
            var streak = 0
            for (back in 1..14) {
                val key = Dates.daysAgoKey(back)
                if (key <= installDay || key in opened) break
                streak++
            }
            val how = if (streak >= 2) "missed $streak days in a row" else "not opened yesterday"
            lines += "${k.name} (day ${Dates.dayNumber(k.start, now)} · $how)"
            pkgs += pkg
        }
        if (lines.isEmpty()) return
        Repo.notifyAdminApps(teamId, uid, name, NotifType.APP_MISSED, lines, p(c).getString("phone", "") ?: "")
        val e = p(c).edit()
        pkgs.forEach { e.putString("missed_$it", yesterday) }
        e.apply()
    }

    /**
     * Notices for the tester on their own phone (lock screen + Notifications), only during the 14 testing days:
     * 4:30 pm "you haven't opened it today", and from 9 am "you missed it yesterday".
     */
    private suspend fun checkTesterReminders(c: Context, teamId: String, uid: String, now: Long, usageOk: Boolean,
                                             current: Map<String, Known>, todayOpens: Map<String, List<OpenSession>>) {
        if (!usageOk || current.isEmpty()) return
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = now }
        val minuteOfDay = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        val today = Dates.dayKey(now)
        val yesterday = Dates.daysAgoKey(1)
        for ((pkg, k) in current) {
            val dayNo = Dates.dayNumber(k.start, now)
            // 4:30 pm reminder (Day 1..14)
            if (dayNo in 1..14 && minuteOfDay >= REMIND_MINUTE && p(c).getString("remind_$pkg", "") != today &&
                today !in sentDays(c, pkg) && todayOpens[pkg].isNullOrEmpty()
            ) {
                Repo.notifySelf(teamId, uid, NotifType.SELF_REMIND, k.name, "$dayNo", pkg)
                p(c).edit().putString("remind_$pkg", today).apply()
            }
            // yesterday missed (yesterday was Day 2..14; the install day itself is skipped)
            val yNo = dayNo - 1
            if (yNo in 2..14 && cal.get(java.util.Calendar.HOUR_OF_DAY) >= MISSED_ALERT_HOUR &&
                p(c).getString("selfMissed_$pkg", "") != yesterday && yesterday !in sentDays(c, pkg) &&
                Dates.dayKey(watchFrom(c, pkg, k.start)) <= yesterday
            ) {
                Repo.notifySelf(teamId, uid, NotifType.SELF_MISSED, k.name, "$yNo", pkg)
                p(c).edit().putString("selfMissed_$pkg", yesterday).apply()
            }
        }
    }

    /** All 14 days green: congratulations to the admin (once), and the reward card shows on the admin's home. */
    private suspend fun checkReady(c: Context, teamId: String, uid: String, name: String, phone: String, now: Long, current: Map<String, Known>) {
        current.forEach { (pkg, k) ->
            if (k.start <= 0) return@forEach
            val mark = "ready_${pkg}_${k.start}"
            if (p(c).getBoolean(mark, false) || p(c).getBoolean("eval_${pkg}_${k.start}", false)) return@forEach
            if (com.rajeev.testertrack.data.streakComplete(cycle(c, pkg, k.name, k.start), now)) {
                Repo.notifyAdmin(teamId, uid, name, NotifType.APP_READY, "${k.name} · ${Dates.dateTime(now)}", phone, pkg)
                p(c).edit().putBoolean(mark, true).putBoolean("eval_${pkg}_${k.start}", true)
                    .putLong("readyAt_${pkg}_${k.start}", now).apply()
            }
        }
    }

    /**
     * After Day 14 (also for an app that was uninstalled and never re-installed): if any day was missed, the admin gets
     * an alert and the tester a "Sorry, no reward" notice. Days that couldn't be seen (before tracking began) don't count.
     */
    private suspend fun checkFailed(c: Context, teamId: String, uid: String, name: String, phone: String, now: Long,
                                    usageOk: Boolean, current: Map<String, Known>) {
        if (!usageOk) return     // can't judge without Usage access; checked again once it is on
        val cycles = current.map { (pkg, k) -> Gone(pkg, k.name, k.start, 0L) } +
            readGone(c).filter { g -> current[g.pkg]?.start != g.start }
        for (cy in cycles) {
            if (cy.start <= 0) continue
            val evalKey = "eval_${cy.pkg}_${cy.start}"
            if (p(c).getBoolean(evalKey, false)) continue
            if (Dates.dayNumber(cy.start, now) <= 14) continue
            val app = cycle(c, cy.pkg, cy.name, cy.start)
            if (com.rajeev.testertrack.data.streakFailed(app, now)) {
                val missed = com.rajeev.testertrack.data.testingDays(app, now).count { it == com.rajeev.testertrack.data.DayState.MISSED }
                Repo.notifyAdmin(teamId, uid, name, NotifType.APP_FAILED,
                    "${cy.name} · ${tr("$missed दिन छूटे", "missed $missed days")}", phone, cy.pkg)
                Repo.notifySelf(teamId, uid, NotifType.SELF_FAILED, cy.name, name.substringBefore(' '), cy.pkg)
                p(c).edit().putLong("failAt_${cy.pkg}_${cy.start}", now).apply()
            }
            p(c).edit().putBoolean(evalKey, true).apply()
        }
        // forget uninstalled apps whose result is out and that are older than a month
        val keep = readGone(c).filter { !(p(c).getBoolean("eval_${it.pkg}_${it.start}", false) && now - it.at > 30 * DAY_MS) }
        writeGone(c, keep)
    }

    /**
     * Moves this tester's tasks on its own (no buttons): Pending -> Working when the task's app is opened after the task
     * was given, Working -> Done when the 14 days are all green, -> Failed when a day was missed.
     */
    private suspend fun updateTasks(c: Context, teamId: String, uid: String, now: Long, force: Boolean,
                                    current: Map<String, Known>, todayOpens: Map<String, List<OpenSession>>) {
        if (!force && now - p(c).getLong("tasksChecked", 0L) < 5 * 60_000L) return
        p(c).edit().putLong("tasksChecked", now).apply()
        val apps = TrackPrefs.apps(c)
        val tasks = try { Repo.myTasksOnce(teamId, uid) } catch (_: Exception) { return }
        val gone = readGone(c)
        for (t in tasks) {
            if (t.status == TaskStatus.DONE || t.status == TaskStatus.FAILED) continue
            val pkg = t.trackedPkg(apps)
            if (pkg.isBlank()) continue
            val k = current[pkg]
            // the 14-day cycle that counts for this task: the installed one, or an uninstalled one with a result
            val starts = listOfNotNull(k?.start) + gone.filter { it.pkg == pkg }.map { it.start }
            val readyAt = starts.maxOfOrNull { p(c).getLong("readyAt_${pkg}_$it", 0L) } ?: 0L
            val failAt = starts.maxOfOrNull { p(c).getLong("failAt_${pkg}_$it", 0L) } ?: 0L
            when {
                readyAt > 0 && readyAt >= t.createdAt -> Repo.setTaskStatus(teamId, t.id, TaskStatus.DONE, at = readyAt)
                failAt > 0 && failAt >= t.createdAt -> Repo.setTaskStatus(teamId, t.id, TaskStatus.FAILED, at = failAt)
                t.status == TaskStatus.PENDING && k != null -> {
                    val openedAt = todayOpens[pkg].orEmpty().map { it.start }.filter { it >= t.createdAt }.minOrNull()
                        ?: sentDays(c, pkg).filter { it > Dates.dayKey(t.createdAt) }.minOrNull()?.let { now }
                    if (openedAt != null) Repo.setTaskStatus(teamId, t.id, TaskStatus.WORKING, at = openedAt)
                }
            }
        }
    }

    /** SHA-256 of Android's per-phone id, shortened. Same phone = same value for every Gmail on it. */
    fun deviceHash(c: Context): String {
        val id = android.provider.Settings.Secure.getString(c.contentResolver, android.provider.Settings.Secure.ANDROID_ID) ?: return ""
        val d = java.security.MessageDigest.getInstance("SHA-256").digest("tt:$id".toByteArray())
        return d.take(12).joinToString("") { "%02x".format(it) }
    }

    /** Clears what this phone remembers about an earlier install of [pkg] (a fresh install starts at Day 1). */
    private fun forgetInstall(c: Context, pkg: String) {
        val e = p(c).edit()
        p(c).all.keys.filter { it.startsWith("m_${pkg}_") || it.startsWith("o_${pkg}_") }.forEach { e.remove(it) }
        e.remove("sent_$pkg").remove("cont_$pkg").remove("openAlert_$pkg")
        e.apply()
    }

    suspend fun sync(c: Context) = lock.withLock {
        val teamId = p(c).getString("teamId", "") ?: ""
        val uid = p(c).getString("uid", "") ?: ""
        val name = (p(c).getString("name", "") ?: "").ifBlank { "Tester" }
        val phone = p(c).getString("phone", "") ?: ""
        if (teamId.isBlank() || uid.isBlank()) return@withLock
        // tell the admin which phone this account is on (so one phone can't earn the reward twice)
        val dev = deviceHash(c)
        if (dev.isNotBlank() && p(c).getString("dev_sent", "") != dev) {
            try {
                Repo.setDevice(teamId, uid, dev)
                p(c).edit().putString("dev_sent", dev).apply()
            } catch (_: Exception) {}
        }
        val tracked = TrackPrefs.packages(c)
        val now = System.currentTimeMillis()
        val today = Dates.dayKey(now)
        val usageOk = UsageAccess.granted(c)
        var current = trackedInstalled(c, tracked)
        val known = readKnown(c)
        if (known == null) {                                     // first check: quiet baseline
            val names = current.mapValues { it.value.name }
            val starts = current.mapValues { it.value.start }
            Repo.writeInstalled(teamId, uid, now, usageOk, names, starts, emptySet(), emptySet(), emptySet(), emptySet(), baseline = true)
            current.forEach { (pkg, k) ->
                setWatchFrom(c, pkg, k.start, maxOf(k.start, now - 7 * DAY_MS))
                p(c).edit().putBoolean("started_${pkg}_${k.start}", true).putString("openAlert_$pkg", today).apply()
            }
            pushOpens(c, teamId, uid, now, usageOk, current)
            try { pushMinutes(c, teamId, uid, now, usageOk, current) } catch (_: Exception) {}
            try { pushSessions(c, teamId, uid, now, usageOk, current) } catch (_: Exception) {}
            markMissedSeen(c, current.keys)   // first setup: start reminding from the next day
            p(c).edit().putBoolean("init132", true).apply()
            save(c, current, tracked, now)
            return@withLock
        }
        if (!p(c).getBoolean("init132", false)) {
            // first check after updating from v1.3.1: no flood of alerts for what already happened
            val e = p(c).edit()
            current.forEach { (pkg, k) ->
                if (!p(c).contains("wf_${pkg}_${k.start}")) e.putLong("wf_${pkg}_${k.start}", maxOf(k.start, now - 7 * DAY_MS))
                if (sentDays(c, pkg).isNotEmpty()) e.putBoolean("started_${pkg}_${k.start}", true)
                if (today in sentDays(c, pkg)) e.putString("openAlert_$pkg", today)
                if (Dates.dayNumber(k.start, now) > 14) e.putBoolean("eval_${pkg}_${k.start}", true)
                if (p(c).getBoolean("ready_${pkg}_${k.start}", false)) e.putBoolean("eval_${pkg}_${k.start}", true)
            }
            e.putBoolean("init132", true).apply()
        }
        val prevTracked = p(c).getStringSet("tracked", null) ?: tracked
        val newlyTracked = tracked - prevTracked                  // admin just added this app: don't announce it
        val knownTracked = known.filterKeys { it in tracked }
        val added = (current.keys - knownTracked.keys) - newlyTracked
        val silent = (current.keys - knownTracked.keys) intersect newlyTracked
        val removed = knownTracked.keys - current.keys
        val stale = known.keys - tracked                          // admin stopped tracking these
        val changed = added.isNotEmpty() || silent.isNotEmpty() || removed.isNotEmpty() || stale.isNotEmpty()
        var force = false
        if (changed) {
            force = true
            var gone = readGone(c)
            // re-installed: same day as the uninstall -> the 14 days carry on; a later day -> start again at Day 1
            val continued = HashMap<String, Long>()
            for (pkg in added) {
                val g = gone.filter { it.pkg == pkg }.maxByOrNull { it.at }
                val installedAt = current[pkg]?.start ?: now
                if (g != null && g.at > 0 && Dates.dayKey(g.at) == today && g.start > 0) {
                    continued[pkg] = g.start
                    p(c).edit().putString("cont_$pkg", "$installedAt|${g.start}").apply()
                } else {
                    forgetInstall(c, pkg)
                    setWatchFrom(c, pkg, installedAt, installedAt)
                }
            }
            if (continued.isNotEmpty()) current = trackedInstalled(c, tracked)   // picks up the old Day 1
            gone = gone.filter { it.pkg !in added }   // re-installed: the earlier install's days are replaced (carried on or restarted)
            // numbers for the uninstall message, taken before anything is reset
            val removedText = removed.map { pkg ->
                val k = knownTracked[pkg]
                val day = Dates.dayNumber(k?.start ?: 0L, now)
                "${k?.name ?: pkg} · ${Dates.time(now)} (day $day · opened ${sentDays(c, pkg).size})"
            }
            gone = gone + removed.mapNotNull { pkg -> knownTracked[pkg]?.let { Gone(pkg, it.name, it.start, now) } }
            writeGone(c, gone)
            silent.forEach { pkg ->
                current[pkg]?.let { k ->
                    setWatchFrom(c, pkg, k.start, maxOf(k.start, now - 7 * DAY_MS))
                    p(c).edit().putBoolean("started_${pkg}_${k.start}", true).apply()
                }
            }
            markMissedSeen(c, silent)
            val names = current.mapValues { it.value.name }
            val starts = current.mapValues { it.value.start }
            Repo.writeInstalled(teamId, uid, now, usageOk, names, starts, added, silent, removed, stale, baseline = false, continued = continued)
            if (added.isNotEmpty()) Repo.notifyAdminApps(teamId, uid, name, NotifType.APP_ADDED, added.map { names[it] ?: it }, phone)
            if (removed.isNotEmpty()) Repo.notifyAdminApps(teamId, uid, name, NotifType.APP_REMOVED, removedText, phone)
        }
        val wroteOpens = pushOpens(c, teamId, uid, now, usageOk, current)
        val wroteMins = try { pushMinutes(c, teamId, uid, now, usageOk, current) } catch (_: Exception) { false }
        val (wroteSessions, todayOpens) = try { pushSessions(c, teamId, uid, now, usageOk, current) } catch (_: Exception) { false to emptyMap<String, List<OpenSession>>() }
        val wrote = wroteOpens || wroteMins || wroteSessions
        try { checkOpenAlerts(c, teamId, uid, name, phone, now, current, todayOpens) } catch (_: Exception) {}
        checkMissed(c, teamId, uid, name, now, usageOk, current)
        try { checkTesterReminders(c, teamId, uid, now, usageOk, current, todayOpens) } catch (_: Exception) {}
        val readyBefore = p(c).all.keys.count { it.startsWith("readyAt_") || it.startsWith("failAt_") }
        try { checkReady(c, teamId, uid, name, phone, now, current) } catch (_: Exception) {}
        try { checkFailed(c, teamId, uid, name, phone, now, usageOk, current) } catch (_: Exception) {}
        if (p(c).all.keys.count { it.startsWith("readyAt_") || it.startsWith("failAt_") } != readyBefore) force = true
        if (todayOpens.values.any { it.isNotEmpty() } && p(c).getString("taskOpenDay", "") != today) {
            force = true; p(c).edit().putString("taskOpenDay", today).apply()
        }
        try { updateTasks(c, teamId, uid, now, force, current, todayOpens) } catch (_: Exception) {}
        if (!changed && !wrote && now - p(c).getLong("touched", 0L) > TOUCH_EVERY_MS) {
            Repo.touchInstalled(teamId, uid, now, usageOk)
        }
        save(c, current, tracked, if (changed || wrote || now - p(c).getLong("touched", 0L) > TOUCH_EVERY_MS) now else p(c).getLong("touched", now))
    }
}

class WatchWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        KeepAlive.ensure(applicationContext)      // bring the always-on service back if the phone stopped it
        InstallWatch.sync(applicationContext)
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }
}

/** Phone notifications: testers get task changes; the admin also gets tester app-install alerts. */
object TaskAlerts {
    const val CHANNEL = "alerts_v3"   // new id: Android never lets an old channel change its sound
    private const val WORK = "notif_check"
    private fun p(c: Context) = c.getSharedPreferences("alerts", Context.MODE_PRIVATE)

    fun createChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        // channels from earlier versions
        listOf("tasks", "apps", "alerts_loud").forEach { nm.deleteNotificationChannel(it) }
        // The channel pops up and vibrates; the sound itself is played by AlertSound (see Services.kt), which is
        // louder and works on phones that mute channel sounds.
        val ch = NotificationChannel(CHANNEL, tr("ज़रूरी सूचनाएं", "Important alerts"), NotificationManager.IMPORTANCE_HIGH).apply {
            description = tr("नया टास्क, इनाम, ऐप इंस्टॉल/अनइंस्टॉल और रिमाइंडर", "New tasks, rewards, app installs/uninstalls and reminders")
            setSound(null, null)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 500)
            enableLights(true)
        }
        nm.createNotificationChannel(ch)
    }

    /** True if the notification could be shown. Used by the "Test alert sound" button in Settings. */
    fun testAlert(c: Context): Boolean {
        if (!NotificationManagerCompat.from(c).areNotificationsEnabled()) return false
        show(c, Notif(
            id = "test_" + System.currentTimeMillis(), type = NotifType.NEW_TASK,
            title = tr("टेस्ट सूचना", "Test alert"), body = tr("अगर आपको आवाज़ आई, तो सब ठीक है।", "If you heard a sound, alerts are working."),
            createdAt = System.currentTimeMillis(), read = true, pushed = true,
        ))
        return true
    }

    /** Remember who to check for, so the background check works when the app is closed. */
    fun setTarget(c: Context, teamId: String, uid: String) {
        p(c).edit().putString("teamId", teamId).putString("uid", uid).apply()
    }

    fun teamId(c: Context) = p(c).getString("teamId", "") ?: ""
    fun uid(c: Context) = p(c).getString("uid", "") ?: ""
    fun setAdminWatch(c: Context, on: Boolean) { p(c).edit().putBoolean("adminWatch", on).apply() }
    fun adminWatch(c: Context) = p(c).getBoolean("adminWatch", false)

    fun clear(c: Context) {
        p(c).edit().clear().apply()
        WorkManager.getInstance(c).cancelUniqueWork(WORK)
    }

    fun schedule(c: Context) {
        val req = PeriodicWorkRequestBuilder<NotifWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    /** Fetch notifications not yet shown and post them to the notification bar. */
    suspend fun check(c: Context) {
        val teamId = p(c).getString("teamId", "") ?: ""
        val uid = p(c).getString("uid", "") ?: ""
        if (teamId.isBlank() || uid.isBlank()) return
        Repo.takeUnpushed(teamId, uid).forEach { show(c, it) }
    }

    private fun show(c: Context, n: Notif) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val (title, text) = phoneText(n)
        // a reminder to open the tracked app opens that app directly; everything else opens Notifications
        val launch = if (n.type == NotifType.SELF_REMIND || n.type == NotifType.SELF_MISSED) {
            try { c.packageManager.getLaunchIntentForPackage(n.pkg) } catch (_: Exception) { null }
        } else null
        val pi = if (launch != null) PendingIntent.getActivity(
            c, n.id.hashCode(), launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        ) else PendingIntent.getActivity(
            c, 1, Intent(c, MainActivity::class.java).putExtra("open", "notifications")
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)   // full text on the lock screen, like other apps
            .setContentIntent(pi)
            .apply {
                // one tap to call the tester and remind them
                if (n.type == NotifType.APP_MISSED && n.phone.length == 10) {
                    val dial = PendingIntent.getActivity(
                        c, n.id.hashCode(),
                        Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:+91${n.phone}")),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    addAction(0, tr("कॉल करें", "Call"), dial)
                }
            }
            .build()
        try {
            NotificationManagerCompat.from(c).notify(n.id.hashCode(), notif)
            AlertSound.play(c)
        } catch (_: SecurityException) {}
    }

    fun phoneText(n: Notif): Pair<String, String> = when (n.type) {
        NotifType.NEW_TASK -> tr("एडमिन से नया टास्क", "New task from admin") to n.title
        NotifType.STATUS -> tr("टास्क ${com.rajeev.testertrack.data.TaskStatus.label(n.body)} किया गया", "Task marked ${statusEn(n.body)}") to n.title
        NotifType.DELETED -> tr("टास्क हटाया गया", "Task deleted") to n.title
        NotifType.APP_ADDED -> tr("${n.title} ने नया ऐप इंस्टॉल किया", "${n.title} installed an app") to n.body
        NotifType.APP_REMOVED -> tr("${n.title} ने ऐप अनइंस्टॉल किया", "${n.title} uninstalled an app") to n.body
        NotifType.APP_MISSED -> tr("${n.title} ने कल ऐप नहीं खोला", "${n.title} didn't open an app yesterday") to n.body
        NotifType.APP_READY -> tr("🎉 बधाई हो! ${n.title} ने 14 दिन पूरे किए", "🎉 Congratulations! ${n.title} has completed") to n.body
        NotifType.APP_FAILED -> tr("${n.title} 14 दिन पूरे नहीं कर पाए", "${n.title} failed the 14 days") to n.body
        NotifType.LINK_OPENED -> tr("${n.title} ने लिंक खोला", "${n.title} has clicked the link") to n.body
        NotifType.APP_STARTED -> tr("${n.title} ने ऐप इंस्टॉल करके खोला और काम शुरू किया", "${n.title} has installed and opened the app and started working") to n.body
        NotifType.APP_OPENED -> tr("${n.title} ने आज ऐप खोला", "${n.title} opened an app today") to n.body
        NotifType.SELF_REMIND -> tr("आज ${n.title} नहीं खोला", "You haven't opened ${n.title} today") to
            tr("आधी रात से पहले खोलें, ताकि दिन ${n.body} हरा रहे।", "Open it before midnight to keep Day ${n.body} green.")
        NotifType.SELF_MISSED -> tr("कल ${n.title} नहीं खोला (दिन ${n.body})", "You missed ${n.title} yesterday (Day ${n.body})") to
            tr("₹14 इनाम के लिए इसे हर दिन खोलें।", "Open it every day to get your ₹14 reward.")
        NotifType.SELF_FAILED -> tr("माफ़ करें ${n.body}, ${n.title} का इनाम नहीं मिला", "Sorry ${n.body}, you failed to get rewards for ${n.title}") to
            tr("14 दिनों में एक या ज़्यादा दिन ऐप नहीं खोला गया।", "The app wasn't opened on one or more of the 14 days.")
        NotifType.REWARD -> tr("₹${n.body} आपके वॉलेट में जुड़े", "₹${n.body} added to your wallet") to n.title
        NotifType.WITHDRAW -> tr("${n.title} ने निकासी माँगी", "${n.title} requested a withdrawal") to n.body
        NotifType.PAID -> tr("₹${n.body} आपके UPI में भेजे गए", "₹${n.body} sent to your UPI") to n.title
        NotifType.DECLINED -> tr("निकासी अनुरोध अस्वीकार हुआ", "Withdrawal request declined") to tr("एडमिन से संपर्क करें", "Please contact the admin")
        NotifType.MEMBER_REQUEST -> tr("${n.title} ने सदस्य जोड़ने को कहा", "${n.title} asked to add a member") to n.body
        NotifType.MEMBER_APPROVED -> tr("सदस्य मंज़ूर हुआ", "Member approved") to "${n.title} · ${n.body}"
        NotifType.MEMBER_DECLINED -> tr("सदस्य का अनुरोध अस्वीकार हुआ", "Member request declined") to "${n.title} · ${n.body}"
        else -> "Tester Track" to n.title
    }

    fun statusEn(s: String) = when (s) {
        com.rajeev.testertrack.data.TaskStatus.DONE -> "Done"
        com.rajeev.testertrack.data.TaskStatus.FAILED -> "Failed"
        com.rajeev.testertrack.data.TaskStatus.WORKING -> "Working"
        else -> "Pending"
    }
}

class NotifWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        KeepAlive.ensure(applicationContext)
        TaskAlerts.check(applicationContext)
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }
}
