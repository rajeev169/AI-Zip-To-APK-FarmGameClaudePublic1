package com.rajeev.testertrack.ui

import com.rajeev.testertrack.data.tr
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.REWARD_RS
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.rewardsDue
import com.rajeev.testertrack.data.sharedPhoneWith
import com.rajeev.testertrack.data.Role
import com.rajeev.testertrack.data.UserProfile
import com.rajeev.testertrack.tracking.TrackPrefs
import com.rajeev.testertrack.tracking.TaskAlerts
import com.rajeev.testertrack.tracking.InstallWatch
import com.rajeev.testertrack.ui.screens.PermissionSetupScreen
import com.rajeev.testertrack.ui.components.firstName
import com.rajeev.testertrack.ui.screens.AddMemberScreen
import com.rajeev.testertrack.ui.screens.AddTaskDialog
import com.rajeev.testertrack.ui.screens.ShareAppScreen
import com.rajeev.testertrack.ui.screens.AdminHome
import com.rajeev.testertrack.ui.screens.MenuScreen
import com.rajeev.testertrack.ui.screens.NotificationsScreen
import com.rajeev.testertrack.ui.screens.PhoneScreen
import com.rajeev.testertrack.ui.screens.adminMenu
import com.rajeev.testertrack.ui.screens.testerMenu
import com.rajeev.testertrack.ui.screens.waitingInvites
import com.rajeev.testertrack.ui.screens.AppsScreen
import com.rajeev.testertrack.ui.screens.HistoryScreen
import com.rajeev.testertrack.ui.screens.MemberHome
import com.rajeev.testertrack.ui.screens.SettingsScreen
import com.rajeev.testertrack.ui.screens.TasksScreen
import com.rajeev.testertrack.ui.screens.TesterDetailScreen
import com.rajeev.testertrack.ui.screens.TestersScreen
import com.rajeev.testertrack.ui.screens.WalletScreen
import com.rajeev.testertrack.ui.theme.Bg
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed class Screen {
    data object Home : Screen()
    data object Menu : Screen()
    data class Tasks(val filter: String?, val uid: String? = null) : Screen()
    data class TesterDetail(val uid: String) : Screen()
    data object Testers : Screen()
    data object Apps : Screen()
    data object Settings : Screen()
    data object Notifications : Screen()
    data object Wallet : Screen()
    data object ShareApp : Screen()
    data object AddMember : Screen()    // co-admin only
    data class History(val uid: String, val name: String) : Screen()
}

/** Runs a Firestore action, shows a toast on success/failure. */
typealias Runner = (successMsg: String?, block: suspend () -> Unit) -> Unit

@Composable
fun AppRoot(
    initialUser: UserProfile,
    onSignOut: () -> Unit,
    onRemoved: () -> Unit,
    askNotificationPermission: () -> Unit,
    openNotifications: Boolean = false,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val teamId = initialUser.teamId
    val isAdmin = initialUser.role == Role.ADMIN
    var permissionSetupComplete by remember(initialUser.uid) { mutableStateOf(false) }

    val userLive by remember { Repo.userFlow(initialUser.uid) }.collectAsState(initialUser)
    val user = userLive ?: initialUser
    val team by remember { Repo.teamFlow(teamId) }.collectAsState(null)
    val tasks by remember { Repo.tasksFlow(teamId) }.collectAsState(emptyList())

    // ticking clock so "today", Day N and "active" stay current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); now = System.currentTimeMillis() } }
    val today = Dates.dayKey(now)

    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    val nav: (Screen) -> Unit = { stack.add(it) }
    val back: () -> Unit = { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    BackHandler(enabled = stack.size > 1) { back() }

    val run: Runner = { msg, block ->
        scope.launch {
            try {
                block()
                if (msg != null) Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, e.message ?: tr("नहीं हो पाया", "Could not complete"), Toast.LENGTH_LONG).show()
            }
        }
    }

    // Team deleted -> back to start
    var teamSeen by remember { mutableStateOf(false) }
    LaunchedEffect(team) {
        if (team != null) teamSeen = true else if (teamSeen) onRemoved()
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        if (!isAdmin && user.phone.isNotBlank() && !permissionSetupComplete) {
            PermissionSetupScreen(
                onComplete = { permissionSetupComplete = true },
                onSignOut = onSignOut,
            )
        } else if (isAdmin) {
            val members by remember { Repo.membersFlow(teamId) }.collectAsState(emptyList())
            val invites by remember { Repo.invitesFlow(initialUser.uid) }.collectAsState(emptyList())

            var addTask by remember { mutableStateOf(false) }
            val waiting = waitingInvites(members, invites)

            // Admin notifications: testers installing / removing apps
            val adminNotifs by remember { Repo.notifsFlow(teamId, initialUser.uid) }.collectAsState(emptyList())
            val allInstalled by remember { Repo.installedAllFlow(teamId) }.collectAsState(emptyList())
            val allTx by remember { Repo.walletAllFlow(teamId) }.collectAsState(emptyList())
            val allWithdrawals by remember { Repo.withdrawalsFlow(teamId) }.collectAsState(emptyList())
            val rewardsReady = rewardsDue(team?.apps ?: emptyList(), members, allInstalled, allTx, now, tasks)
            val allRequests by remember { Repo.memberRequestsFlow(teamId) }.collectAsState(emptyList())
            val pendingRequests = allRequests.filter { it.status == com.rajeev.testertrack.data.ReqStatus.PENDING }.sortedBy { it.createdAt }
            LaunchedEffect(Unit) {
                TaskAlerts.setTarget(ctx, teamId, initialUser.uid)
                TaskAlerts.schedule(ctx)
                askNotificationPermission()
                TaskAlerts.setAdminWatch(ctx, true)
                com.rajeev.testertrack.tracking.AdminAlertService.start(ctx)   // instant tester alerts
            }
            LaunchedEffect(adminNotifs.count { !it.pushed }) {
                if (adminNotifs.any { !it.pushed }) try { TaskAlerts.check(ctx) } catch (_: Exception) {}
            }
            LaunchedEffect(openNotifications) {
                if (openNotifications && stack.last() != Screen.Notifications) nav(Screen.Notifications)
            }

            when (val s = stack.last()) {
                Screen.Home -> AdminHome(
                    user, team, members, invites, tasks, allInstalled, now, nav, run,
                    unread = adminNotifs.count { !it.read },
                    onBell = { nav(Screen.Notifications) },
                    rewards = rewardsReady,
                    withdrawals = allWithdrawals,
                    balances = allTx.groupBy { it.uid }.mapValues { e -> e.value.sumOf { it.amount } },
                    onPaid = { w, amt ->
                        run(tr("भुगतान रिकॉर्ड हुआ", "Payout recorded")) { Repo.completeWithdraw(teamId, initialUser.uid, w, amt) }
                    },
                    onDecline = { w ->
                        run(tr("अनुरोध अस्वीकार किया", "Request declined")) { Repo.declineWithdraw(teamId, w) }
                    },
                    onGive = { d ->
                        run(tr("₹$REWARD_RS ${d.name} के वॉलेट में जुड़े", "₹$REWARD_RS added to ${d.name}'s wallet")) {
                            Repo.giveReward(d, teamId, initialUser.uid)
                        }
                    },
                    memberRequests = pendingRequests,
                    joinedEmails = members.map { it.email.trim().lowercase() }.toSet(),
                    onApproveRequest = { r ->
                        run(tr("मंज़ूर — अब वह इसी Gmail से साइन इन करे", "Approved — they can now sign in with this Gmail")) {
                            Repo.approveMemberRequest(teamId, team?.name ?: "", initialUser.uid, r)
                        }
                    },
                    onDeclineRequest = { r ->
                        run(tr("अनुरोध बंद किया", "Request closed")) { Repo.declineMemberRequest(teamId, r) }
                    },
                )
                Screen.Menu -> MenuScreen(
                    adminMenu(
                        testers = members.size, waiting = waiting.size, apps = team?.apps?.size ?: 0,
                        onTesters = { back(); nav(Screen.Testers) },
                        onApps = { back(); nav(Screen.Apps) },
                        onNewTask = { back(); addTask = true },
                        onAllTasks = { back(); nav(Screen.Tasks(null)) },
                        onShare = { back(); nav(Screen.ShareApp) },
                    ),
                    onBack = back
                )
                is Screen.Tasks -> TasksScreen(
                    isAdmin = true, teamId = teamId,
                    tasks = if (s.uid != null) tasks.filter { it.assigneeUid == s.uid } else tasks,
                    title = s.uid?.let { id -> members.find { it.uid == id }?.name?.let { tr("$it के टास्क", "$it's tasks") } } ?: tr("सभी टास्क", "All tasks"),
                    initialFilter = s.filter, run = run, onBack = back
                )
                is Screen.TesterDetail -> {
                    val m = members.find { it.uid == s.uid }
                    val installed by remember(s.uid) { Repo.installedFlow(teamId, s.uid) }.collectAsState(null)
                    if (m == null) LaunchedEffect(Unit) { back() } else TesterDetailScreen(
                        member = m, team = team, installed = installed,
                        tasks = tasks.filter { it.assigneeUid == m.uid },
                        now = now, nav = nav, run = run, onBack = back,
                        sharedWith = sharedPhoneWith(m, members),
                        txs = allTx.filter { it.uid == m.uid },
                        onMarkPaid = { amt ->
                            run(tr("भुगतान रिकॉर्ड हुआ", "Payout recorded")) { Repo.markPaid(teamId, initialUser.uid, m.uid, amt) }
                        },
                        isCoAdmin = team?.coAdmins?.contains(m.uid) == true,
                        onToggleCoAdmin = {
                            val on = team?.coAdmins?.contains(m.uid) != true
                            run(if (on) tr("${m.name} को-एडमिन बने", "${m.name} is now a co-admin") else tr("को-एडमिन हटाया", "Co-admin removed")) {
                                Repo.setCoAdmin(teamId, m.uid, on)
                            }
                        },
                    )
                }
                Screen.Testers -> TestersScreen(team, members, invites, run, onBack = back)
                Screen.Apps -> AppsScreen(team, run, onBack = back)
                Screen.Settings -> SettingsScreen(user, team, run, onSignOut, onDeleted = onRemoved, onBack = back)
                is Screen.History -> {
                    val inst by remember(s.uid) { Repo.installedFlow(teamId, s.uid) }.collectAsState(null)
                    HistoryScreen(s.name, inst, team?.apps ?: emptyList(), now, onBack = back)
                }
                Screen.Notifications -> NotificationsScreen(
                    teamId = teamId, list = adminNotifs, run = run,
                    onOpenTasks = { back(); nav(Screen.Tasks(null)) },
                    onBack = back,
                    isAdmin = true,
                    onOpenTester = { uid -> back(); if (uid.isNotBlank()) nav(Screen.TesterDetail(uid)) },
                )
                Screen.ShareApp -> ShareAppScreen(team, isAdmin = true, run = run, onBack = back)
                Screen.Wallet, Screen.AddMember -> LaunchedEffect(Unit) { back() }
            }

            if (addTask) {
                AddTaskDialog(team, members, onDismiss = { addTask = false }) { title, app, pkg, note, link, testers ->
                    addTask = false
                    val n = testers.size
                    run(
                        if (n == 1) tr("1 टेस्टर के लिए टास्क जोड़ा", "Task added for 1 tester")
                        else tr("$n टेस्टर के लिए टास्क जोड़ा", "Task added for $n testers")
                    ) {
                        // one copy per tester, each with its own notification
                        testers.forEach { m -> Repo.addTask(teamId, title, app, pkg, note, link, m) }
                    }
                }
            }
        } else if (user.phone.isBlank()) {
            // Mobile number is required once for testers
            PhoneScreen(
                name = firstName(user.name),
                onSave = { phone, done ->
                    scope.launch {
                        try { Repo.savePhone(user, phone) } catch (e: Exception) { done(e.message ?: "Error") }
                    }
                },
                onSignOut = onSignOut,
            )
        } else {
            val me by remember { Repo.memberFlow(teamId, initialUser.uid) }.collectAsState(null)

            // Removed by admin -> back to start
            var meSeen by remember { mutableStateOf(false) }
            LaunchedEffect(me) {
                val m = me
                if (m != null) {
                    meSeen = true
                } else if (meSeen) {
                    com.rajeev.testertrack.tracking.WatchService.stop(ctx)
                    InstallWatch.clear(ctx)
                    onRemoved()
                }
            }
            // The phone only ever looks at the admin's chosen apps
            LaunchedEffect(team?.apps) {
                team?.let { t -> TrackPrefs.setApps(ctx, t.apps) }
            }

            val myTasks = tasks.filter { it.assigneeUid == initialUser.uid }
            val notifs by remember { Repo.notifsFlow(teamId, initialUser.uid) }.collectAsState(emptyList())
            val isCoAdmin = team?.coAdmins?.contains(initialUser.uid) == true
            val myRequests by remember(isCoAdmin) {
                if (isCoAdmin) Repo.myMemberRequestsFlow(teamId, initialUser.uid)
                else kotlinx.coroutines.flow.flowOf(emptyList<com.rajeev.testertrack.data.MemberRequest>())
            }.collectAsState(emptyList())

            // Phone notifications: remember who to check for, run the ~15 min background check,
            // and show any new ones right away while the app is open.
            LaunchedEffect(Unit) {
                TaskAlerts.setTarget(ctx, teamId, initialUser.uid)
                TaskAlerts.schedule(ctx)
                askNotificationPermission()
            }
            LaunchedEffect(notifs.count { !it.pushed }) {
                if (notifs.any { !it.pushed }) try { TaskAlerts.check(ctx) } catch (_: Exception) {}
            }
            LaunchedEffect(openNotifications) {
                if (openNotifications && stack.last() != Screen.Notifications) nav(Screen.Notifications)
            }

            val installedMine by remember { Repo.installedFlow(teamId, initialUser.uid) }.collectAsState(null)
            val myTx by remember { Repo.walletMineFlow(teamId, initialUser.uid) }.collectAsState(emptyList())
            val myWithdrawal by remember { Repo.myWithdrawalFlow(teamId, initialUser.uid) }.collectAsState(emptyList())
            // Tester tapped Open link on a task: the admin is told once, with the time
            val onLinkOpened: (com.rajeev.testertrack.data.WorkTask) -> Unit = { t ->
                if (t.linkAt == 0L) run(null) { Repo.taskLinkOpened(teamId, t, user.name, user.phone) }
            }

            // App watch (install, opens with time, uninstall of the admin's tracked apps only), always in the background.
            // The instant part runs in WatchService; these keep it running and check once when the app opens or the list changes.
            LaunchedEffect(user.name, user.phone) { InstallWatch.setTarget(ctx, teamId, initialUser.uid, user.name, user.phone) }
            LaunchedEffect(Unit) {
                com.rajeev.testertrack.tracking.WatchService.start(ctx)
                InstallWatch.schedule(ctx)
            }
            LaunchedEffect(team?.apps) {
                if (team != null) try { InstallWatch.sync(ctx) } catch (_: Exception) {}
            }

            when (val s = stack.last()) {
                Screen.Home -> MemberHome(
                    user = user, team = team, tasks = myTasks,
                    now = now, nav = nav, run = run,
                    installed = installedMine,
                    walletBalance = myTx.sumOf { it.amount },
                    onLinkOpened = onLinkOpened,
                    unread = notifs.count { !it.read },
                    onBell = { nav(Screen.Notifications) },
                )
                Screen.Notifications -> NotificationsScreen(
                    teamId = teamId, list = notifs, run = run,
                    onOpenTasks = { back(); nav(Screen.Tasks(null)) },
                    onBack = back,
                    onOpenWallet = { back(); nav(Screen.Wallet) },
                    onOpenAddMember = { back(); if (isCoAdmin) nav(Screen.AddMember) },
                )
                Screen.Wallet -> WalletScreen(
                    txs = myTx,
                    upi = me?.upi ?: "",
                    pending = myWithdrawal.isNotEmpty(),
                    onSaveUpi = { v -> run(tr("UPI ID सेव हुई", "UPI ID saved")) { Repo.saveUpi(teamId, initialUser.uid, v) } },
                    onRequest = {
                        run(tr("अनुरोध भेजा गया", "Request sent")) {
                            Repo.requestWithdraw(teamId, initialUser.uid, user.name, me?.upi ?: "", myTx.sumOf { it.amount }, user.phone)
                        }
                    },
                    onCancel = { run(tr("अनुरोध रद्द हुआ", "Request cancelled")) { Repo.cancelWithdraw(teamId, initialUser.uid) } },
                    onBack = back,
                )
                Screen.Menu -> MenuScreen(
                    testerMenu(
                        onTasks = { back(); nav(Screen.Tasks(null)) },
                        onHistory = { back(); nav(Screen.History(user.uid, user.name)) },
                        onUsage = { com.rajeev.testertrack.tracking.UsageAccess.openSettings(ctx) },
                        onShare = { back(); nav(Screen.ShareApp) },
                        onAddMember = if (isCoAdmin) ({ back(); nav(Screen.AddMember) }) else null,
                    ),
                    onBack = back
                )
                is Screen.Tasks -> TasksScreen(
                    isAdmin = false, teamId = teamId, tasks = myTasks, title = tr("मेरे टास्क", "My tasks"),
                    initialFilter = s.filter, run = run, onBack = back, onLinkOpened = onLinkOpened
                )
                Screen.Settings -> SettingsScreen(user, team, run, onSignOut, onDeleted = onRemoved, onBack = back)
                is Screen.History -> HistoryScreen(s.name, installedMine, team?.apps ?: emptyList(), now, onBack = back)
                Screen.ShareApp -> ShareAppScreen(team, isAdmin = false, run = run, onBack = back)
                Screen.AddMember -> {
                    val t = team
                    if (isCoAdmin && t != null) AddMemberScreen(t, user, myRequests, run, onBack = back)
                    else LaunchedEffect(Unit) { back() }     // no longer a co-admin
                }
                else -> LaunchedEffect(Unit) { back() }
            }
        }
    }
}

