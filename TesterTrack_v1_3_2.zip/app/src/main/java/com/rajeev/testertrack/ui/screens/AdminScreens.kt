package com.rajeev.testertrack.ui.screens

import com.rajeev.testertrack.ui.components.fieldColors
import com.rajeev.testertrack.data.tr
import androidx.compose.foundation.clickable
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Invite
import com.rajeev.testertrack.data.InstalledSnapshot
import com.rajeev.testertrack.data.Phone
import com.rajeev.testertrack.data.Member
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.TaskStatus
import com.rajeev.testertrack.data.Team
import com.rajeev.testertrack.data.UserProfile
import com.rajeev.testertrack.data.WorkTask
import com.rajeev.testertrack.ui.Runner
import com.rajeev.testertrack.ui.Screen
import com.rajeev.testertrack.ui.components.Avatar
import com.rajeev.testertrack.ui.components.Chip
import com.rajeev.testertrack.ui.components.EmptyNote
import com.rajeev.testertrack.ui.components.FixedHome
import com.rajeev.testertrack.ui.components.AppButton
import com.rajeev.testertrack.ui.components.BtnKind
import com.rajeev.testertrack.ui.components.ButtonHint
import com.rajeev.testertrack.ui.components.IconBox
import com.rajeev.testertrack.ui.components.SelectChip
import com.rajeev.testertrack.ui.components.InfoBanner
import com.rajeev.testertrack.ui.components.Pill
import com.rajeev.testertrack.ui.components.SectionCard
import com.rajeev.testertrack.ui.components.SubTopBar
import com.rajeev.testertrack.ui.components.SummaryCard
import com.rajeev.testertrack.ui.components.TileData
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.GreenSoft
import com.rajeev.testertrack.ui.theme.GreenLine
import com.rajeev.testertrack.ui.theme.RedLine
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.theme.Tile
import com.rajeev.testertrack.data.minutesOn
import com.rajeev.testertrack.data.lastOpen
import com.rajeev.testertrack.data.activeNow

// ======================= ADMIN HOME =======================

@Composable
fun AdminHome(
    user: UserProfile,
    team: Team?,
    members: List<Member>,
    invites: List<Invite>,
    tasks: List<WorkTask>,
    installed: List<com.rajeev.testertrack.data.UserInstalled>,
    now: Long,
    nav: (Screen) -> Unit,
    run: Runner,
    unread: Int = 0,
    onBell: () -> Unit = {},
    rewards: List<com.rajeev.testertrack.data.RewardDue> = emptyList(),
    onGive: (com.rajeev.testertrack.data.RewardDue) -> Unit = {},
    withdrawals: List<com.rajeev.testertrack.data.Withdrawal> = emptyList(),
    balances: Map<String, Int> = emptyMap(),
    onPaid: (com.rajeev.testertrack.data.Withdrawal, Int) -> Unit = { _, _ -> },
    onDecline: (com.rajeev.testertrack.data.Withdrawal) -> Unit = {},
    memberRequests: List<com.rajeev.testertrack.data.MemberRequest> = emptyList(),
    joinedEmails: Set<String> = emptySet(),
    onApproveRequest: (com.rajeev.testertrack.data.MemberRequest) -> Unit = {},
    onDeclineRequest: (com.rajeev.testertrack.data.MemberRequest) -> Unit = {},
) {
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var payConfirm by remember { mutableStateOf<com.rajeev.testertrack.data.Withdrawal?>(null) }
    var confirm by remember { mutableStateOf<com.rajeev.testertrack.data.RewardDue?>(null) }
    val today = Dates.dayKey(now)
    val done = tasks.count { it.status == TaskStatus.DONE }
    val working = tasks.count { it.status == TaskStatus.WORKING }
    val pending = tasks.count { it.status == TaskStatus.PENDING }
    val waiting = waitingInvites(members, invites)
    val apps = team?.apps.orEmpty()
    val snapOf: (String) -> com.rajeev.testertrack.data.InstalledSnapshot? = { uid -> installed.find { it.uid == uid }?.snap }
    val teamMinutes = members.sumOf { m -> snapOf(m.uid)?.minutesOn(today, apps) ?: 0L }

    FixedHome(
        teamName = team?.name ?: "",
        userName = user.name,
        photo = user.photo,
        chips = listOf(
            Chip(tr("एडमिन", "Admin"), true),
            Chip(testerCountText(members.size, waiting.size), false) { nav(Screen.Testers) },
        ),
        onMenu = { nav(Screen.Menu) },
        onAvatar = { nav(Screen.Settings) },
        onSettings = { nav(Screen.Settings) },
        cardTitle = tr("आज आपके ऐप्स में ग्रुप का समय", "Group time in your apps today"),
        cardValue = Dates.hoursLong(teamMinutes * 60_000L),
        tiles = listOf(
            TileData(tr("पूरे", "Done"), "$done") { nav(Screen.Tasks(TaskStatus.DONE)) },
            TileData(tr("चालू", "Working"), "$working") { nav(Screen.Tasks(TaskStatus.WORKING)) },
            TileData(tr("बाकी", "Pending"), "$pending", Purple) { nav(Screen.Tasks(TaskStatus.PENDING)) },
        ),
        bell = { com.rajeev.testertrack.ui.components.BellButton(unread, onBell) },
    ) {

            if (members.isEmpty() && waiting.isEmpty()) {
                item {
                    InfoBanner(Icons.Filled.Person, tr("अभी कोई टेस्टर नहीं है। टेस्टर का Gmail जोड़ें — वह साइन इन करते ही अपने-आप जुड़ जाएगा।", "No testers yet. Add your tester's Gmail — they join automatically when they sign in.")) {
                        nav(Screen.Testers)
                    }
                }
            }
            if (team != null && team.apps.isEmpty()) {
                item {
                    InfoBanner(Icons.Filled.Info, tr("अपने ऐप्स जोड़ें, ताकि टेस्टर का उन्हें खोलना और उनमें बिताया समय अपने-आप गिना जाए।", "Add your apps so the tester's opens and time in them are tracked automatically.")) {
                        nav(Screen.Apps)
                    }
                }
            }

            if (memberRequests.isNotEmpty()) {
                item { MemberRequestsCard(memberRequests, joinedEmails, onApproveRequest, onDeclineRequest) }
            }

            if (withdrawals.isNotEmpty()) {
                item {
                    SectionCard(tr("निकासी अनुरोध", "Withdrawal requests"), trailing = "${withdrawals.size}") {
                        withdrawals.forEachIndexed { i, w ->
                            val bal = balances[w.uid] ?: 0
                            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                            Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp)) {
                                Text(w.name, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                Text("₹$bal · ${w.upi}", color = Sub, fontSize = 13.sp)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AppButton(
                                        tr("UPI कॉपी", "Copy UPI"),
                                        {
                                            clip.setText(androidx.compose.ui.text.AnnotatedString(w.upi))
                                            android.widget.Toast.makeText(ctx, tr("UPI ID कॉपी हुई", "UPI ID copied"), android.widget.Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.weight(1f), kind = BtnKind.Outline, small = true
                                    )
                                    AppButton(
                                        tr("UPI ऐप में भुगतान", "Pay in UPI app"),
                                        {
                                            try {
                                                val uri = android.net.Uri.parse(
                                                    "upi://pay?pa=${android.net.Uri.encode(w.upi)}&pn=${android.net.Uri.encode(w.name)}&am=$bal.00&cu=INR&tn=${android.net.Uri.encode("Tester Track reward")}"
                                                )
                                                ctx.startActivity(
                                                    android.content.Intent.createChooser(android.content.Intent(android.content.Intent.ACTION_VIEW, uri), tr("भुगतान ऐप चुनें", "Pay with"))
                                                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                                )
                                            } catch (_: Exception) {
                                                android.widget.Toast.makeText(ctx, tr("कोई UPI ऐप नहीं मिला। UPI ID कॉपी करके खुद भेजें।", "No UPI app found. Copy the UPI ID and pay manually."), android.widget.Toast.LENGTH_LONG).show()
                                            }
                                        },
                                        modifier = Modifier.weight(1f), kind = BtnKind.Outline, small = true, enabled = bal > 0
                                    )
                                }
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AppButton(
                                        tr("भुगतान हो गया ₹$bal", "Mark ₹$bal paid"), { payConfirm = w },
                                        modifier = Modifier.weight(1f), small = true, enabled = bal > 0
                                    )
                                    AppButton(tr("अस्वीकार", "Decline"), { onDecline(w) }, modifier = Modifier.weight(1f), kind = BtnKind.Outline, small = true)
                                }
                            }
                        }
                    }
                }
            }

            if (rewards.isNotEmpty()) {
                item {
                    SectionCard(tr("इनाम तैयार", "Rewards ready"), trailing = "${rewards.size}") {
                        rewards.forEachIndexed { i, r ->
                            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(r.name, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        if (r.manual) tr("${r.appName} · आपने हाथ से पूरा किया", "${r.appName} · you marked it Done")
                                        else tr("${r.appName} · लगातार 14 दिन", "${r.appName} · 14 days in a row"),
                                        color = Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                    if (r.phonePaidTo != null) {
                                        Text(
                                            tr("इसी फ़ोन पर ${r.phonePaidTo} को इस ऐप का इनाम पहले दिया जा चुका है", "Same phone as ${r.phonePaidTo}, who was already paid for this app"),
                                            color = Red, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                                        )
                                    } else if (r.sameDevice.isNotEmpty()) {
                                        Text(
                                            tr("⚠ इसी फ़ोन पर: ${r.sameDevice.joinToString(", ")}", "⚠ Same phone as: ${r.sameDevice.joinToString(", ")}"),
                                            color = Color(0xFFE65100), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                                Spacer(Modifier.width(8.dp))
                                AppButton(
                                    tr("₹${com.rajeev.testertrack.data.REWARD_RS} दें", "Give ₹${com.rajeev.testertrack.data.REWARD_RS}"),
                                    { confirm = r }, small = true, enabled = r.phonePaidTo == null
                                )
                            }
                        }
                    }
                }
            }

            if (members.isNotEmpty() || waiting.isNotEmpty()) {
                item {
                    SectionCard(tr("टेस्टर", "Testers"), action = tr("जोड़ें", "Add"), onAction = { nav(Screen.Testers) }) {
                        members.sortedByDescending { m -> snapOf(m.uid)?.lastOpen(apps)?.start ?: 0L }.forEachIndexed { i, m ->
                            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                            TesterRow(
                                m = m,
                                snap = snapOf(m.uid), apps = apps, now = now,
                                working = tasks.count { it.assigneeUid == m.uid && it.status == TaskStatus.WORKING },
                                pending = tasks.count { it.assigneeUid == m.uid && it.status == TaskStatus.PENDING },
                                onClick = { nav(Screen.TesterDetail(m.uid)) }
                            )
                        }
                        waiting.forEachIndexed { i, inv ->
                            if (i > 0 || members.isNotEmpty()) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                            WaitingRow(inv) { nav(Screen.Testers) }
                        }
                    }
                }
            }

            item {
                SectionCard(tr("हाल के टास्क", "Recent tasks"), action = tr("सभी देखें", "See all"), onAction = { nav(Screen.Tasks(null)) }) {
                    val recent = tasks.sortedByDescending { maxOf(it.createdAt, it.startedAt, it.doneAt) }.take(5)
                    if (recent.isEmpty()) EmptyNote(tr("कोई टास्क नहीं। ☰ मेनू → नया टास्क से जोड़ें।", "No tasks yet. Add one from ☰ Menu → New task."))
                    recent.forEachIndexed { i, t ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        TaskRow(t, isAdmin = true, teamId = user.teamId, run = run)
                    }
                }
            }
    }

    payConfirm?.let { w ->
        val bal = balances[w.uid] ?: 0
        AlertDialog(
            onDismissRequest = { payConfirm = null },
            title = { Text(tr("₹$bal भुगतान हो गया?", "Paid ₹$bal?")) },
            text = {
                Text(tr(
                    "${w.name} की UPI ID ${w.upi} पर पैसे पहले भेजें, फिर यहाँ दबाएं। उनका वॉलेट ₹0 हो जाएगा।",
                    "Send ₹$bal to ${w.name}'s UPI ID (${w.upi}) first, then confirm here. Their wallet goes to ₹0."
                ))
            },
            confirmButton = { TextButton(onClick = { onPaid(w, bal); payConfirm = null }) { Text(tr("हाँ, भेज दिया", "Yes, paid")) } },
            dismissButton = { TextButton(onClick = { payConfirm = null }) { Text(tr("रद्द करें", "Cancel")) } },
        )
    }

    confirm?.let { r ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(tr("₹${com.rajeev.testertrack.data.REWARD_RS} वॉलेट में जोड़ें?", "Add ₹${com.rajeev.testertrack.data.REWARD_RS} to wallet?")) },
            text = {
                Text(
                    (if (r.manual) tr(
                        "आपने ${r.name} का ${r.appName} टास्क हाथ से पूरा किया (सभी 14 दिन हरे नहीं थे)। एक बार जुड़ने के बाद वापस नहीं होगा।",
                        "You marked ${r.name}'s ${r.appName} task Done by hand (not all 14 days were green). This can't be undone once added."
                    ) else tr(
                        "${r.name} ने ${r.appName} लगातार 14 दिन खोला, एक भी दिन नहीं छूटा। एक बार जुड़ने के बाद वापस नहीं होगा।",
                        "${r.name} opened ${r.appName} 14 days in a row with no missed day. This can't be undone once added."
                    )) + if (r.sameDevice.isNotEmpty()) tr(
                        "\n\nध्यान दें: यह फ़ोन ${r.sameDevice.joinToString(", ")} के साथ साझा है। सिर्फ़ एक को इनाम दें।",
                        "\n\nNote: this phone is shared with ${r.sameDevice.joinToString(", ")}. Pay only one of them."
                    ) else ""
                )
            },
            confirmButton = { TextButton(onClick = { onGive(r); confirm = null }) { Text(tr("जोड़ें", "Add")) } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text(tr("रद्द करें", "Cancel")) } },
        )
    }
}

/** Gmails the admin added that have not signed in yet. */
fun waitingInvites(members: List<Member>, invites: List<Invite>): List<Invite> {
    val joined = members.map { it.email.lowercase() }.toSet()
    return invites.filter { it.email !in joined }
}

/** "Active" (a tracked app is open now or was in the last 30 min), else when one was last opened. */
@Composable
fun ActivityPill(snap: com.rajeev.testertrack.data.InstalledSnapshot?, apps: List<com.rajeev.testertrack.data.TrackedApp>, now: Long) {
    val last = snap?.lastOpen(apps)
    when {
        snap != null && snap.activeNow(apps, now) -> Pill(tr("सक्रिय", "Active"), Green, GreenSoft)
        last == null -> Pill(tr("अभी नहीं खोला", "Not opened yet"), Sub, Tile)
        Dates.dayKey(last.start) == Dates.dayKey(now) -> Pill(tr("आखिरी बार ${Dates.time(last.start)}", "Last opened ${Dates.time(last.start)}"), Sub, Tile)
        else -> Pill(tr("आखिरी बार ${Dates.dateTime(last.start)}", "Last opened ${Dates.dateTime(last.start)}"), Sub, Tile)
    }
}

/** Opens the phone dialer with the tester's number (no call permission needed). */
fun dialTester(ctx: android.content.Context, phone: String) {
    val i = android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:+91$phone"))
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

@Composable
private fun TesterRow(
    m: Member, snap: com.rajeev.testertrack.data.InstalledSnapshot?, apps: List<com.rajeev.testertrack.data.TrackedApp>, now: Long,
    working: Int, pending: Int, onClick: () -> Unit,
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(start = 22.dp, end = 10.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(m.photo, m.name, 48.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.name, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.width(8.dp))
                ActivityPill(snap, apps, now)
            }
            val mins = snap?.minutesOn(Dates.dayKey(now), apps) ?: 0L
            val day = snap?.apps.orEmpty().filter { a -> apps.any { it.pkg == a.pkg } && a.uninstalledAt == 0L }
                .minByOrNull { it.start }?.let { Dates.dayNumber(it.start, now) }
            Text(
                tr("आज आपके ऐप्स में ${mins} मिनट", "Today $mins min in your apps") + (day?.let { tr(" · दिन $it", " · Day $it") } ?: ""),
                color = Sub, fontSize = 13.sp
            )
            Text(tr("$working चालू · $pending बाकी टास्क", "$working working · $pending pending tasks"), color = Sub, fontSize = 13.sp)
        }
        if (m.phone.isNotBlank()) {
            IconButton(onClick = { dialTester(ctx, m.phone) }) {
                Box(
                    Modifier.size(40.dp).clip(androidx.compose.foundation.shape.CircleShape).background(GreenSoft),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Phone, tr("कॉल करें", "Call"), tint = Green, modifier = Modifier.size(20.dp)) }
            }
        } else {
            Text("›", color = Sub, fontSize = 26.sp, modifier = Modifier.padding(end = 12.dp))
        }
    }
}

@Composable
private fun WaitingRow(inv: Invite, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar("", inv.name.ifBlank { inv.email }, 48.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                inv.name.ifBlank { inv.email.substringBefore("@") }, color = Sub, fontSize = 17.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(inv.email, color = Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Pill(tr("अभी साइन इन नहीं किया", "Not signed in yet"), Sub, Tile)
        }
        Text("›", color = Sub, fontSize = 26.sp)
    }
}

// ======================= ADD TASK =======================

@Composable
@OptIn(ExperimentalLayoutApi::class)
fun AddTaskDialog(
    team: Team?,
    members: List<Member>,
    onDismiss: () -> Unit,
    onAdd: (title: String, app: String, pkg: String, note: String, link: String, testers: List<Member>) -> Unit,
) {
    var title by remember { mutableStateOf("") }
    // the tracked app this task is about: its installs and opens move the task by itself ("" = Other, no tracking)
    var appPkg by remember { mutableStateOf(team?.apps?.firstOrNull()?.pkg ?: "") }
    var note by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    // several testers can be picked; each gets their own copy of the task
    var picked by remember { mutableStateOf(setOf<String>()) }
    val allPicked = members.isNotEmpty() && picked.size == members.size

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("नया टास्क", "New task")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (members.isEmpty()) {
                    Text(tr("पहले ☰ → टेस्टर जोड़ें। टेस्टर के साइन इन करने के बाद ही टास्क दिया जा सकता है।", "First add a tester from ☰. You can assign tasks once the tester has signed in."), color = Red)
                    return@Column
                }
                OutlinedTextField(
                    title, { title = it }, label = { Text(tr("क्या करना है", "What to do")) },
                    placeholder = { Text(tr("जैसे: लॉगिन और फ़ोटो अपलोड जाँचें", "e.g. Check login and photo upload")) },
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                Spacer(Modifier.height(12.dp))
                Text(tr("ट्रैक होने वाला ऐप", "Tracked app"), color = Sub, fontSize = 14.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    team?.apps.orEmpty().forEach { a ->
                        SelectChip(a.name.ifBlank { a.pkg }, appPkg == a.pkg, { appPkg = a.pkg }, showTick = false)
                    }
                    SelectChip(tr("अन्य", "Other"), appPkg == "", { appPkg = "" }, showTick = false)
                }
                Text(
                    if (appPkg.isBlank()) tr("“अन्य” टास्क अपने-आप नहीं बदलता — आप स्थिति खुद बदलें।", "An “Other” task doesn't move by itself — change its status yourself.")
                    else tr("इंस्टॉल करके खोलते ही चालू, 14 दिन बाद अपने-आप पूरा या फ़ेल।", "Working once installed and opened; Done or Failed by itself after 14 days."),
                    color = Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text(tr("किसे देना है", "Assign to"), color = Sub, fontSize = 14.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SelectChip(
                        tr("सभी टेस्टर", "All testers"), allPicked,
                        { picked = if (allPicked) emptySet() else members.map { it.uid }.toSet() }
                    )
                    members.forEach { m ->
                        val on = m.uid in picked
                        SelectChip(m.name, on, { picked = if (on) picked - m.uid else picked + m.uid })
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    when (picked.size) {
                        0 -> tr("कम से कम एक टेस्टर चुनें", "Select at least one tester")
                        1 -> tr("1 टेस्टर चुना", "1 tester selected")
                        else -> tr("${picked.size} टेस्टर चुने", "${picked.size} testers selected")
                    },
                    color = Purple, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    link, { link = it.trim() }, label = { Text(tr("ऐप लिंक (वैकल्पिक)", "App link (optional)")) },
                    placeholder = { Text(tr("Play टेस्टिंग या Drive लिंक", "Play testing or Drive link")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                Text(
                    tr("Google Play closed-testing लिंक या Google Drive APK लिंक पेस्ट करें", "Paste a Google Play closed-testing link or a Google Drive APK link"),
                    color = Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    note, { note = it }, label = { Text(tr("नोट (वैकल्पिक)", "Note (optional)")) },
                    modifier = Modifier.fillMaxWidth(), minLines = 2, colors = fieldColors())
                Spacer(Modifier.height(4.dp))
                ButtonHint(
                    when {
                        title.isBlank() -> tr("जोड़ें चालू करने के लिए काम लिखें", "Type what to do to enable Add")
                        picked.isEmpty() -> tr("जोड़ें चालू करने के लिए कम से कम एक टेस्टर चुनें", "Pick at least one tester to enable Add")
                        else -> ""
                    }
                )
            }
        },
        confirmButton = {
            AppButton(
                tr("जोड़ें", "Add"),
                onClick = {
                    val appName = team?.apps?.find { it.pkg == appPkg }?.let { it.name.ifBlank { it.pkg } } ?: ""
                    onAdd(title, appName, appPkg, note, link, members.filter { it.uid in picked })
                },
                enabled = title.isNotBlank() && picked.isNotEmpty(),
                small = true,
            )
        },
        dismissButton = { AppButton(tr("रद्द करें", "Cancel"), onDismiss, kind = BtnKind.Outline, small = true) }
    )
}

// ======================= TESTER DETAIL =======================

@Composable
fun TesterDetailScreen(
    member: Member,
    team: Team?,
    tasks: List<WorkTask>,
    installed: InstalledSnapshot?,
    now: Long,
    nav: (Screen) -> Unit,
    run: Runner,
    onBack: () -> Unit,
    txs: List<com.rajeev.testertrack.data.WalletTx> = emptyList(),
    onMarkPaid: (Int) -> Unit = {},
    sharedWith: List<String> = emptyList(),
    isCoAdmin: Boolean = false,
    onToggleCoAdmin: () -> Unit = {},
) {
    val today = Dates.dayKey(now)
    val apps = team?.apps.orEmpty()
    // The tester's phone reports in at least every ~15 minutes; silence for 45+ minutes means the phone is off or the app was stopped.
    val silent = installed != null && installed.checkedAt > 0 && now - installed.checkedAt > 45 * 60_000L
    Column(Modifier.fillMaxSize()) {
        SubTopBar(member.name, onBack)
        LazyColumn(
            Modifier.navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(Modifier.height(14.dp))
                Row(Modifier.padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(member.photo, member.name, 56.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(member.email, color = Sub, fontSize = 14.sp)
                        Spacer(Modifier.height(4.dp))
                        ActivityPill(installed, apps, now)
                    }
                }
                Spacer(Modifier.height(12.dp))
                PhoneCallRow(member.phone)
                Spacer(Modifier.height(14.dp))
                SummaryCard(
                    tr("आज आपके ऐप्स में", "Today in your apps"),
                    Dates.hoursLong((installed?.minutesOn(today, apps) ?: 0L) * 60_000L),
                    listOf(
                        TileData(tr("पूरे", "Done"), "${tasks.count { it.status == TaskStatus.DONE }}") { nav(Screen.Tasks(TaskStatus.DONE, member.uid)) },
                        TileData(tr("चालू", "Working"), "${tasks.count { it.status == TaskStatus.WORKING }}") { nav(Screen.Tasks(TaskStatus.WORKING, member.uid)) },
                        TileData(tr("बाकी", "Pending"), "${tasks.count { it.status == TaskStatus.PENDING }}", Purple) { nav(Screen.Tasks(TaskStatus.PENDING, member.uid)) },
                    )
                )
            }
            item {
                SectionCard(
                    tr("आज ऐप उपयोग", "App usage today"),
                    action = tr("7 दिन", "7 days"), onAction = { nav(Screen.History(member.uid, member.name)) }
                ) {
                    UsageList(
                        todayPerApp(installed, apps, today), apps,
                        if (apps.isEmpty()) tr("☰ → ट्रैक होने वाले ऐप्स में अपने ऐप्स जोड़ें", "Add your apps in ☰ → Tracked apps")
                        else tr("आज आपके ऐप्स नहीं खोले गए (या टेस्टर ने Usage access नहीं दिया)", "Your apps weren't opened today (or the tester hasn't allowed Usage access)")
                    )
                    OpensTimeline(installed, apps, today, now)
                }
            }
            if (sharedWith.isNotEmpty()) {
                item {
                    Text(
                        tr("⚠ इस टेस्टर का Gmail इसी फ़ोन पर ${sharedWith.joinToString(", ")} के साथ है। एक फ़ोन से इनाम एक बार ही दें।",
                            "⚠ This tester's Gmail is on the same phone as ${sharedWith.joinToString(", ")}. Pay the reward once per phone."),
                        color = Color(0xFFE65100), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(14.dp)).background(Color(0xFFFFF3E0)).padding(14.dp)
                    )
                }
            }
            if (silent) {
                item {
                    Text(
                        tr("⚠ Tester Track इस फ़ोन पर शायद नहीं चल रहा (फ़ोन बंद है या ऐप रोका गया)। आखिरी जाँच ${Dates.dateTime(installed?.checkedAt ?: 0L)}।",
                            "⚠ Tester Track may not be running on this phone (phone off, or the app was stopped). Last check ${Dates.dateTime(installed?.checkedAt ?: 0L)}."),
                        color = Color(0xFFE65100), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(14.dp)).background(Color(0xFFFFF3E0)).padding(14.dp)
                    )
                }
            }
            item { CoAdminCard(isCoAdmin, member.name, onToggleCoAdmin) }
            item { InstalledAppsCard(installed, team?.apps ?: emptyList(), now) }
            item { WalletCard(txs, onMarkPaid) }
            item {
                SectionCard(tr("चल रहे टास्क", "Active tasks"), action = tr("सभी देखें", "See all"), onAction = { nav(Screen.Tasks(null, member.uid)) }) {
                    val active = tasks.filter { it.status == TaskStatus.PENDING || it.status == TaskStatus.WORKING }.sortedByDescending { it.createdAt }
                    if (active.isEmpty()) EmptyNote(tr("कोई बाकी या चालू टास्क नहीं", "No pending or working tasks"))
                    active.forEachIndexed { i, t ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        TaskRow(t, isAdmin = true, teamId = team?.id ?: "", run = run, showAssignee = false)
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

/** This tester's wallet as the admin sees it: balance, recent lines, and a button to record a payout. */
@Composable
private fun WalletCard(txs: List<com.rajeev.testertrack.data.WalletTx>, onMarkPaid: (Int) -> Unit) {
    val balance = txs.sumOf { it.amount }
    var confirm by remember { mutableStateOf(false) }
    SectionCard(tr("वॉलेट", "Wallet"), trailing = "₹$balance") {
        if (txs.isEmpty()) {
            EmptyNote(tr("अभी कोई लेन-देन नहीं। लगातार 14 दिन पूरे होने पर होम स्क्रीन पर “दें” बटन आएगा।", "No entries yet. A “Give” button appears on your home screen when this tester finishes 14 days in a row."))
        }
        txs.sortedByDescending { it.at }.take(5).forEachIndexed { i, t ->
            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (t.kind == com.rajeev.testertrack.data.TxKind.PAYOUT) tr("भुगतान किया", "Paid out") else t.label,
                        color = Ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(Dates.dateTime(t.at), color = Sub, fontSize = 11.sp)
                }
                Text(
                    if (t.amount >= 0) "+₹${t.amount}" else "−₹${-t.amount}",
                    color = if (t.amount >= 0) Green else Red, fontWeight = FontWeight.Bold, fontSize = 15.sp
                )
            }
        }
        if (balance > 0) {
            Spacer(Modifier.height(8.dp))
            AppButton(
                tr("₹$balance भुगतान किया (रिकॉर्ड करें)", "Mark ₹$balance as paid"),
                { confirm = true },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp), kind = BtnKind.Outline, small = true
            )
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(tr("₹$balance भुगतान हो गया?", "Paid ₹$balance?")) },
            text = { Text(tr("पहले UPI आदि से टेस्टर को पैसे भेजें, फिर यहाँ रिकॉर्ड करें। वॉलेट ₹0 हो जाएगा।", "Send the money to the tester first (UPI etc.), then record it here. The wallet goes to ₹0.")) },
            confirmButton = { TextButton(onClick = { onMarkPaid(balance); confirm = false }) { Text(tr("हाँ, हो गया", "Yes, paid")) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(tr("रद्द करें", "Cancel")) } },
        )
    }
}

/** The admin's tracked apps on this tester's phone: Day N since install, days opened, until uninstall. */
@Composable
private fun InstalledAppsCard(installed: InstalledSnapshot?, tracked: List<com.rajeev.testertrack.data.TrackedApp>, now: Long) {
    val weekAgo = now - 7L * 24 * 60 * 60 * 1000
    val have = installed?.apps.orEmpty().associateBy { it.pkg }
    SectionCard(
        tr("आपके ऐप्स इस फ़ोन में", "Your apps on this phone"),
        trailing = if (tracked.isNotEmpty()) "${tracked.count { (have[it.pkg]?.uninstalledAt ?: 1L) == 0L }}/${tracked.size}" else null
    ) {
        if (tracked.isEmpty()) {
            EmptyNote(tr("☰ → ट्रैक होने वाले ऐप्स में ऐप जोड़ें। इंस्टॉल, अनइंस्टॉल और रोज़ खोलने के दिन यहाँ दिखेंगे।", "Add apps in ☰ → Tracked apps. Install, uninstall and daily opens will show here."))
            return@SectionCard
        }
        Text(
            if (installed != null && installed.checkedAt > 0)
                tr("आखिरी जाँच ${Dates.dateTime(installed.checkedAt)}", "Last checked ${Dates.dateTime(installed.checkedAt)}")
            else tr("अभी जाँच नहीं हुई। टेस्टर के ऐप खोलते ही दिखेगा।", "Not checked yet. Shows once the tester opens Tester Track."),
            color = Sub, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 22.dp)
        )
        if (installed != null && !installed.usageOk) {
            Text(
                tr("टेस्टर ने Usage access नहीं दिया, इसलिए ऐप खोलने के दिन गिने नहीं जा सकते।", "Usage access is off on the tester's phone, so opened days can't be counted."),
                color = Red, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 2.dp)
            )
        }
        Spacer(Modifier.height(6.dp))
        tracked.forEachIndexed { i, app ->
            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
            val a = have[app.pkg]
            val gone = a != null && a.uninstalledAt > 0
            val dayNo = if (a == null) 0 else Dates.dayNumber(a.start, if (gone) a.uninstalledAt else now)
            val openedDays = a?.opened?.size ?: 0
            Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(app.name.ifBlank { app.pkg }, color = Ink, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            when {
                                a == null -> app.pkg
                                gone -> tr("हटाया: ${Dates.dateTime(a.uninstalledAt)} · $dayNo दिन चला, $openedDays दिन खोला", "Uninstalled ${Dates.dateTime(a.uninstalledAt)} · lasted $dayNo days, opened $openedDays")
                                else -> tr("इंस्टॉल: ${Dates.dateTime(a.start)} · $dayNo में से $openedDays दिन खोला", "Installed ${Dates.dateTime(a.start)} · opened $openedDays of $dayNo days")
                            },
                            color = Sub, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    when {
                        a == null -> Pill(tr("इंस्टॉल नहीं", "Not installed"), Sub, Tile)
                        gone -> Pill(tr("हटाया गया", "Uninstalled"), Red, Color(0xFFFDECEC))
                        else -> Pill(tr("दिन $dayNo", "Day $dayNo"), Green, GreenSoft)
                    }
                }
                if (a != null && !gone) {
                    // Day 1..14 from install: green = opened, red = missed, grey = not reached / unknown
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        for (st in com.rajeev.testertrack.data.testingDays(a, now)) {
                            Box(
                                Modifier.size(11.dp).clip(androidx.compose.foundation.shape.CircleShape).background(
                                    when (st) {
                                        com.rajeev.testertrack.data.DayState.OPENED -> Green
                                        com.rajeev.testertrack.data.DayState.MISSED -> Red
                                        else -> Line
                                    }
                                )
                            )
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (Dates.dayKey(now) in a.opened) tr("आज खोला ✓", "Opened today ✓") else tr("आज नहीं खोला", "Not opened today"),
                            color = if (Dates.dayKey(now) in a.opened) Green else Sub, fontSize = 11.sp
                        )
                    }
                }
                if (a != null) {
                    Spacer(Modifier.height(10.dp))
                    com.rajeev.testertrack.ui.components.AppTimeChart(a, now)
                }
            }
        }
    }
}

@Composable
private fun PhoneCallRow(phone: String) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Row(
        Modifier.padding(horizontal = 14.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Color.White).padding(start = 18.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Phone, null, tint = if (phone.isBlank()) Sub else Green, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(
            if (phone.isBlank()) tr("नंबर नहीं जोड़ा", "No number added") else Phone.pretty(phone),
            color = if (phone.isBlank()) Sub else Ink, fontSize = 17.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        if (phone.isNotBlank()) {
            Button(
                onClick = { dialTester(ctx, phone) },
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Green),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Filled.Phone, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(tr("कॉल करें", "Call"))
            }
        }
    }
}

// ======================= TESTERS (add / remove) =======================

@Composable
fun TestersScreen(team: Team?, members: List<Member>, invites: List<Invite>, run: Runner, onBack: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var removeTarget by remember { mutableStateOf<Pair<String, String?>?>(null) } // email, uid
    val joinedEmails = members.map { it.email.lowercase() }.toSet()
    val waiting = invites.filter { it.email !in joinedEmails }
    val validEmail = email.trim().contains("@") && email.trim().contains(".")

    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("टेस्टर", "Testers"), onBack)
        LazyColumn(Modifier.navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Spacer(Modifier.height(14.dp))
                SectionCard(tr("नया टेस्टर जोड़ें", "Add a new tester")) {
                    Column(Modifier.padding(horizontal = 22.dp)) {
                        OutlinedTextField(
                            email, { email = it }, label = { Text(tr("टेस्टर का Gmail", "Tester's Gmail")) }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            name, { name = it }, label = { Text(tr("नाम (वैकल्पिक)", "Name (optional)")) }, singleLine = true,
                            modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                        Spacer(Modifier.height(12.dp))
                        AppButton(
                            tr("जोड़ें", "Add"),
                            onClick = {
                                val e = email; val n = name
                                email = ""; name = ""
                                run(tr("जोड़ दिया — अब टेस्टर इसी Gmail से साइन इन करे", "Added — now the tester signs in with this Gmail")) {
                                    Repo.addInvite(team!!.id, team.name, e, n)
                                }
                            },
                            enabled = team != null && validEmail,
                            modifier = Modifier.fillMaxWidth()
                        )
                        ButtonHint(if (validEmail) "" else tr("जोड़ें चालू करने के लिए Gmail लिखें", "Type a Gmail to enable Add"))
                        Spacer(Modifier.height(6.dp))
                        Text(
                            tr("टेस्टर ऐप इंस्टॉल करके इसी Gmail से साइन इन करेगा तो अपने-आप आपके ग्रुप से जुड़ जाएगा।", "When the tester installs the app and signs in with this Gmail, they join your group automatically."),
                            color = Sub, fontSize = 13.sp
                        )
                    }
                }
            }
            item {
                SectionCard(tr("जुड़े हुए टेस्टर", "Joined testers"), trailing = "${members.size}") {
                    if (members.isEmpty()) EmptyNote(tr("अभी कोई नहीं", "None yet"))
                    members.forEachIndexed { i, m ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        Row(Modifier.padding(start = 22.dp, end = 10.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(m.photo, m.name, 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    m.name + if (team?.coAdmins?.contains(m.uid) == true) " · " + tr("को-एडमिन", "Co-admin") else "",
                                    color = Ink, fontSize = 16.sp
                                )
                                Text(m.email, color = Sub, fontSize = 13.sp)
                            }
                            if (m.phone.isNotBlank()) {
                                IconBox(Icons.Filled.Phone, tr("कॉल करें", "Call"), Green, GreenLine, GreenSoft) { dialTester(ctx, m.phone) }
                                Spacer(Modifier.width(8.dp))
                            }
                            IconBox(Icons.Filled.Delete, tr("हटाएं", "Remove"), Red, RedLine) { removeTarget = m.email to m.uid }
                        }
                    }
                }
            }
            if (waiting.isNotEmpty()) {
                item {
                    SectionCard(tr("साइन इन का इंतज़ार", "Waiting for sign-in")) {
                        waiting.forEach { inv ->
                            Row(Modifier.padding(start = 22.dp, end = 10.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    if (inv.name.isNotBlank()) Text(inv.name, color = Ink, fontSize = 16.sp)
                                    Text(inv.email, color = Sub, fontSize = 13.sp)
                                }
                                IconBox(Icons.Filled.Delete, tr("हटाएं", "Remove"), Red, RedLine) { removeTarget = inv.email to null }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    removeTarget?.let { (e, uid) ->
        AlertDialog(
            onDismissRequest = { removeTarget = null },
            title = { Text(tr("टेस्टर हटाएं?", "Remove tester?")) },
            text = { Text(tr("$e ग्रुप से हट जाएगा। उसका पुराना काम का इतिहास बना रहेगा।", "$e will be removed from the group. Their past work history stays.")) },
            confirmButton = {
                AppButton(tr("हटाएं", "Remove"), onClick = {
                    removeTarget = null
                    run(tr("हटा दिया", "Removed")) { Repo.removeTester(team?.id ?: "", e, uid) }
                }, kind = BtnKind.RedFill, small = true)
            },
            dismissButton = { AppButton(tr("रहने दें", "Keep"), { removeTarget = null }, kind = BtnKind.Outline, small = true) }
        )
    }
}

// ======================= TRACKED APPS =======================

@Composable
fun AppsScreen(team: Team?, run: Runner, onBack: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var pkg by remember { mutableStateOf("") }
    val validPkg = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$").matches(pkg.trim())

    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("ट्रैक होने वाले ऐप्स", "Tracked apps"), onBack)
        LazyColumn(Modifier.navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Spacer(Modifier.height(14.dp))
                InfoBanner(
                    Icons.Filled.Info,
                    tr("टेस्टर के फ़ोन पर सिर्फ़ इन्हीं ऐप्स को देखा जाता है: इंस्टॉल, हर बार खोलना और कितनी देर — अपने-आप, बैकग्राउंड में।", "Only these apps are watched on the tester's phone: installs, each open and for how long — automatically, in the background.")
                )
            }
            item {
                SectionCard(tr("ऐप जोड़ें", "Add app")) {
                    Column(Modifier.padding(horizontal = 22.dp)) {
                        OutlinedTextField(
                            name, { name = it }, label = { Text(tr("ऐप का नाम", "App name")) },
                            placeholder = { Text(tr("जैसे Samuh Khata", "e.g. Samuh Khata")) }, singleLine = true,
                            modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            pkg, { pkg = it.trim() }, label = { Text(tr("पैकेज नाम", "Package name")) },
                            placeholder = { Text("com.rajeev.samuhkhata") }, singleLine = true,
                            isError = pkg.isNotBlank() && !validPkg,
                            modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                        Text(
                            tr("पैकेज नाम Play Console में या ऐप के Play Store लिंक में id= के बाद मिलता है।", "Find the package name in Play Console, or after id= in the app's Play Store link."),
                            color = Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        val canAdd = team != null && validPkg && team.apps.none { it.pkg == pkg.trim() }
                        AppButton(
                            tr("जोड़ें", "Add"),
                            onClick = {
                                val n = name; val p = pkg
                                name = ""; pkg = ""
                                run(tr("ऐप जोड़ा", "App added")) { Repo.addApp(team!!.id, n.ifBlank { p }, p) }
                            },
                            enabled = canAdd,
                            modifier = Modifier.fillMaxWidth()
                        )
                        ButtonHint(if (canAdd) "" else tr("जोड़ें चालू करने के लिए पैकेज नाम लिखें", "Type a package name to enable Add"))
                    }
                }
            }
            item {
                SectionCard(tr("आपके ऐप्स", "Your apps"), trailing = "${team?.apps?.size ?: 0}") {
                    val apps = team?.apps ?: emptyList()
                    if (apps.isEmpty()) EmptyNote(tr("अभी कोई ऐप नहीं जोड़ा", "No apps added yet"))
                    apps.forEachIndexed { i, a ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        Row(Modifier.padding(start = 22.dp, end = 10.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar("", a.name, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(a.name, color = Ink, fontSize = 16.sp)
                                Text(a.pkg, color = Sub, fontSize = 13.sp)
                            }
                            IconBox(Icons.Filled.Delete, tr("हटाएं", "Remove"), Red, RedLine) {
                                run(tr("ऐप हटाया", "App removed")) { Repo.removeApp(team!!.id, a) }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
