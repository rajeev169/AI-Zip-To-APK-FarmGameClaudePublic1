package com.rajeev.testertrack.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.MAX_REQUESTS_PER_DAY
import com.rajeev.testertrack.data.MemberRequest
import com.rajeev.testertrack.data.ReqSlots
import com.rajeev.testertrack.data.ReqStatus
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.Team
import com.rajeev.testertrack.data.UserProfile
import com.rajeev.testertrack.data.isValidEmail
import com.rajeev.testertrack.data.tr
import com.rajeev.testertrack.ui.Runner
import com.rajeev.testertrack.ui.components.AppButton
import com.rajeev.testertrack.ui.components.BtnKind
import com.rajeev.testertrack.ui.components.ButtonHint
import com.rajeev.testertrack.ui.components.EmptyNote
import com.rajeev.testertrack.ui.components.SectionCard
import com.rajeev.testertrack.ui.components.SubTopBar
import com.rajeev.testertrack.ui.components.fieldColors
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub

private val Orange = Color(0xFFE65100)

/** Co-admin only: ☰ → Add member. Sends a request; the admin approves it. */
@Composable
fun AddMemberScreen(team: Team, user: UserProfile, myRequests: List<MemberRequest>, run: Runner, onBack: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    val used = ReqSlots.usedToday(user.uid, myRequests)
    val left = MAX_REQUESTS_PER_DAY - used
    val okEmail = isValidEmail(email)
    val okName = name.trim().length >= 2
    val ready = okEmail && okName && left > 0

    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("सदस्य जोड़ें", "Add member"), onBack)
        LazyColumn(Modifier.navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Spacer(Modifier.height(14.dp))
                SectionCard(tr("नया सदस्य", "New member"), trailing = tr("आज $used/$MAX_REQUESTS_PER_DAY", "Today $used/$MAX_REQUESTS_PER_DAY")) {
                    Column(Modifier.padding(horizontal = 22.dp)) {
                        OutlinedTextField(
                            email, { email = it }, label = { Text(tr("सदस्य का Gmail", "Member's Gmail")) }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            name, { name = it }, label = { Text(tr("नाम", "Name")) }, singleLine = true,
                            modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                        )
                        Spacer(Modifier.height(12.dp))
                        AppButton(
                            tr("जोड़ें", "Add"),
                            onClick = {
                                val e = email; val n = name
                                email = ""; name = ""
                                run(tr("अनुरोध एडमिन को भेज दिया गया", "Request sent to the admin")) {
                                    Repo.submitMemberRequest(team.id, team.adminUid, user, myRequests, e, n)
                                }
                            },
                            enabled = ready,
                            modifier = Modifier.fillMaxWidth()
                        )
                        ButtonHint(
                            when {
                                left <= 0 -> tr("आज के 5 अनुरोध पूरे हो गए। कल फिर कोशिश करें।", "Today's 5 requests are used. Try again tomorrow.")
                                !okEmail -> tr("जोड़ें चालू करने के लिए सही Gmail लिखें", "Type a valid Gmail to enable Add")
                                !okName -> tr("जोड़ें चालू करने के लिए नाम लिखें", "Type a name to enable Add")
                                else -> ""
                            }
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            tr(
                                "एडमिन के मंज़ूर करने पर ही सदस्य जुड़ेगा। फिर वह इसी Gmail से साइन इन करे तो अपने-आप टेस्टर बन जाएगा। गिनती हर दिन भारतीय समय सुबह 5:30 पर नई होती है।",
                                "The member is added only after the admin approves. Then, signing in with this Gmail makes them a tester automatically. The daily count resets at 5:30 am India time."
                            ),
                            color = Sub, fontSize = 13.sp
                        )
                    }
                }
            }
            item {
                val list = myRequests.sortedByDescending { it.createdAt }.take(30)
                SectionCard(tr("आपके अनुरोध", "Your requests"), trailing = "${myRequests.size}") {
                    if (list.isEmpty()) EmptyNote(tr("अभी कोई अनुरोध नहीं", "No requests yet"))
                    list.forEachIndexed { i, r ->
                        if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 8.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(r.name.ifBlank { r.email }, color = Ink, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    r.email + if (r.createdAt > 0) " · " + Dates.dateTime(r.createdAt) else "",
                                    color = Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                            val (label, color) = when (r.status) {
                                ReqStatus.APPROVED -> tr("मंज़ूर", "Approved") to Green
                                ReqStatus.DECLINED -> tr("अस्वीकार", "Declined") to Red
                                else -> tr("इंतज़ार", "Waiting") to Sub
                            }
                            Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

/** Admin home: co-admins' requests waiting for approval. */
@Composable
fun MemberRequestsCard(
    requests: List<MemberRequest>,
    joinedEmails: Set<String>,
    onApprove: (MemberRequest) -> Unit,
    onDecline: (MemberRequest) -> Unit,
) {
    SectionCard(tr("सदस्य अनुरोध", "Member requests"), trailing = "${requests.size}") {
        requests.forEachIndexed { i, r ->
            val already = r.email.trim().lowercase() in joinedEmails
            if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 22.dp))
            Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp)) {
                Text(r.name.ifBlank { r.email }, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(r.email, color = Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    tr("${r.byName} ने जोड़ने को कहा", "Added by ${r.byName}") + if (r.createdAt > 0) " · " + Dates.dateTime(r.createdAt) else "",
                    color = Sub, fontSize = 12.sp
                )
                if (already) {
                    Text(
                        tr("यह Gmail पहले से ग्रुप में है", "This Gmail is already in the group"),
                        color = Orange, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppButton(tr("मंज़ूर करें", "Approve"), { onApprove(r) }, modifier = Modifier.weight(1f), small = true, enabled = !already)
                    AppButton(
                        if (already) tr("बंद करें", "Close") else tr("अस्वीकार", "Decline"),
                        { onDecline(r) }, modifier = Modifier.weight(1f), kind = BtnKind.Outline, small = true
                    )
                }
            }
        }
    }
}

/** Admin tester page: make this member a co-admin, or take it back. */
@Composable
fun CoAdminCard(isCoAdmin: Boolean, name: String, onToggle: () -> Unit) {
    SectionCard(tr("को-एडमिन", "Co-admin"), trailing = if (isCoAdmin) tr("हाँ", "Yes") else null) {
        Column(Modifier.padding(horizontal = 22.dp)) {
            Text(
                if (isCoAdmin) tr("$name अभी को-एडमिन है। वह मेनू से सदस्य जोड़ने का अनुरोध भेज सकता है; मंज़ूरी आप देते हैं।", "$name is a co-admin now. They can send add-member requests from the menu; you approve them.")
                else tr("को-एडमिन बनाने पर $name के मेनू में “सदस्य जोड़ें” दिखेगा। बाकी सब कुछ टेस्टर जैसा ही रहेगा।", "Making $name a co-admin adds “Add member” to their menu. Everything else stays the same as a tester."),
                color = Sub, fontSize = 13.sp
            )
            Spacer(Modifier.height(10.dp))
            AppButton(
                if (isCoAdmin) tr("को-एडमिन हटाएं", "Remove co-admin") else tr("को-एडमिन बनाएं", "Make co-admin"),
                onToggle, modifier = Modifier.fillMaxWidth(), kind = if (isCoAdmin) BtnKind.Danger else BtnKind.Primary, small = true
            )
            Spacer(Modifier.height(4.dp))
        }
    }
}

/** ☰ → Share app, for everyone. The admin also sets the link here. */
@Composable
fun ShareAppScreen(team: Team?, isAdmin: Boolean, run: Runner, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val saved = team?.appLink.orEmpty()
    var link by remember(saved) { mutableStateOf(saved) }
    val hasLink = saved.isNotBlank()
    val teamName = team?.name.orEmpty()

    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("ऐप शेयर करें", "Share app"), onBack)
        LazyColumn(Modifier.navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (isAdmin) {
                item {
                    Spacer(Modifier.height(14.dp))
                    SectionCard(tr("ऐप डाउनलोड लिंक", "App download link")) {
                        Column(Modifier.padding(horizontal = 22.dp)) {
                            OutlinedTextField(
                                link, { link = it }, label = { Text(tr("लिंक यहाँ चिपकाएँ", "Paste the link here")) }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                                modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                            )
                            Spacer(Modifier.height(10.dp))
                            val changed = link.trim() != saved
                            AppButton(
                                tr("लिंक सेव करें", "Save link"),
                                onClick = {
                                    val v = link
                                    run(tr("लिंक सेव हुआ", "Link saved")) { Repo.setAppLink(team!!.id, v) }
                                },
                                enabled = team != null && changed, modifier = Modifier.fillMaxWidth()
                            )
                            ButtonHint(if (changed) "" else tr("लिंक बदलने पर सेव चालू होगा", "Save turns on when you change the link"))
                            Spacer(Modifier.height(6.dp))
                            Text(
                                tr(
                                    "Play Store टेस्टिंग लिंक, Play Store लिंक या APK का Drive लिंक — कोई भी चलेगा। सब लोग इसी लिंक से शेयर करेंगे।",
                                    "A Play testing link, a Play Store link or a Drive link to the APK all work. Everyone shares this same link."
                                ),
                                color = Sub, fontSize = 13.sp
                            )
                        }
                    }
                }
            }
            item {
                if (!isAdmin) Spacer(Modifier.height(14.dp))
                SectionCard(tr("दोस्तों को भेजें", "Send to others")) {
                    Column(Modifier.padding(horizontal = 22.dp)) {
                        if (hasLink) {
                            Text(saved, color = Ink, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(10.dp))
                        }
                        AppButton(
                            tr("शेयर करें", "Share"),
                            onClick = {
                                val msg = tr(
                                    "${teamName.ifBlank { "हमारे ग्रुप" }} में जुड़ें — Tester Track ऐप: $saved\n\nइंस्टॉल करके अपना Gmail एडमिन को भेजें, ताकि वे आपको जोड़ सकें।",
                                    "Join ${teamName.ifBlank { "our group" }} on Tester Track: $saved\n\nInstall it, then send your Gmail to the admin so they can add you."
                                )
                                try {
                                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg)
                                    ctx.startActivity(Intent.createChooser(send, tr("शेयर करें", "Share via")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                } catch (_: Exception) {
                                    Toast.makeText(ctx, tr("शेयर नहीं हो पाया", "Could not open share"), Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = hasLink, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        AppButton(
                            tr("लिंक कॉपी करें", "Copy link"),
                            onClick = {
                                clip.setText(AnnotatedString(saved))
                                Toast.makeText(ctx, tr("लिंक कॉपी हुआ", "Link copied"), Toast.LENGTH_SHORT).show()
                            },
                            enabled = hasLink, kind = BtnKind.Outline, modifier = Modifier.fillMaxWidth()
                        )
                        ButtonHint(
                            when {
                                hasLink -> ""
                                isAdmin -> tr("ऊपर लिंक डालकर सेव करें", "Paste the link above and save it first")
                                else -> tr("एडमिन ने अभी लिंक नहीं डाला है", "Admin has not added the link yet")
                            }
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            tr(
                                "लिंक मिलने से कोई जुड़ता नहीं। जुड़ने के लिए एडमिन (या को-एडमिन के अनुरोध पर एडमिन) को उसका Gmail जोड़ना होगा।",
                                "Having the link does not add anyone. The admin (or a co-admin's request, approved by the admin) must add their Gmail to join."
                            ),
                            color = Sub, fontSize = 13.sp
                        )
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
