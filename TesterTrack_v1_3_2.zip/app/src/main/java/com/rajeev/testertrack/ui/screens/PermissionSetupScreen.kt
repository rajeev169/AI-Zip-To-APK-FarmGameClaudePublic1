package com.rajeev.testertrack.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.rajeev.testertrack.data.tr
import com.rajeev.testertrack.tracking.BatteryOptimization
import com.rajeev.testertrack.tracking.OemSettings
import com.rajeev.testertrack.tracking.UsageAccess
import com.rajeev.testertrack.ui.components.AppButton
import com.rajeev.testertrack.ui.components.BtnKind
import com.rajeev.testertrack.ui.components.ButtonHint
import com.rajeev.testertrack.ui.components.Pill
import com.rajeev.testertrack.ui.theme.Amber
import com.rajeev.testertrack.ui.theme.AmberSoft
import com.rajeev.testertrack.ui.theme.Bg
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.GreenSoft
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.PurpleDeep
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.theme.Tile

/** One place for the tester to grant the permissions required before monitoring starts. */
@Composable
fun PermissionSetupScreen(onComplete: () -> Unit, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    // When the notification prompt is refused twice, Android stops showing it and returns at once. Then we open the
    // app's notification settings instead, so the tester is never stuck on this screen.
    val askedAt = remember { longArrayOf(0L) }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        refresh++
        if (!granted && System.currentTimeMillis() - askedAt[0] < 700L) OemSettings.openNotificationSettings(ctx)
    }

    fun notificationGranted(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            androidx.core.content.ContextCompat.checkSelfPermission(
                ctx, Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

    // Already set up earlier (e.g. opening the app again): go straight to the home screen.
    // Right after granting the last step we stay here, so the optional Auto-start card is still seen.
    val readyAtStart = remember { UsageAccess.granted(ctx) && BatteryOptimization.unrestricted(ctx) && notificationGranted() }
    androidx.compose.runtime.LaunchedEffect(Unit) { if (readyAtStart) onComplete() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh++ }

    val usageOk = remember(refresh) { UsageAccess.granted(ctx) }
    val batteryOk = remember(refresh) { BatteryOptimization.unrestricted(ctx) }
    val notificationOk = remember(refresh) { notificationGranted() }
    val ready = usageOk && batteryOk && notificationOk
    val done = listOf(usageOk, batteryOk, notificationOk).count { it }
    val progress by animateFloatAsState(done / 3f, label = "setupProgress")

    Column(Modifier.fillMaxSize().background(Bg)) {

        // ---- purple header with progress ----
        Column(
            Modifier
                .fillMaxWidth()
                .background(Purple, RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                .statusBarsPadding()
                .padding(start = 24.dp, end = 24.dp, top = 22.dp, bottom = 24.dp)
        ) {
            Text(
                tr("Tester Track तैयार करें", "Set up Tester Track"),
                color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                tr(
                    "तीन छोटे स्टेप। इसके बाद ही होम स्क्रीन खुलेगी, और सिर्फ़ एडमिन के चुने ऐप्स देखे जाएँगे।",
                    "Three quick steps, then you're in. Only the apps your admin selected are watched."
                ),
                color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp
            )
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(50)).background(PurpleDeep)
                ) {
                    Box(
                        Modifier.fillMaxWidth(progress).height(10.dp).clip(RoundedCornerShape(50))
                            .background(if (ready) Color(0xFF7BD88F) else Color.White)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    tr("$done / 3 तैयार", "$done of 3 ready"),
                    color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                )
            }
        }

        // ---- the steps ----
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            StepCard(
                icon = Icons.Filled.DateRange,
                step = 1,
                title = tr("Usage access", "Usage access"),
                text = tr(
                    "एडमिन के चुने ऐप्स के खुले दिन और समय गिनने के लिए। सूची में Tester Track चुनकर चालू करें।",
                    "Counts the days and time for the apps your admin selected. Find Tester Track in the list and switch it on."
                ),
                granted = usageOk,
                actionText = tr("सेटिंग खोलें", "Open settings"),
            ) { UsageAccess.openSettings(ctx) }

            StepCard(
                icon = Icons.Filled.Refresh,
                step = 2,
                title = tr("Keep running", "Keep running"),
                text = tr(
                    "Tester Track को बैकग्राउंड में चलते रहने दें। Battery → Unrestricted चुनें।",
                    "Lets Tester Track keep watching in the background. Choose Battery → Unrestricted."
                ),
                granted = batteryOk,
                actionText = tr("अनुमति दें", "Allow"),
            ) { BatteryOptimization.request(ctx) }

            StepCard(
                icon = Icons.Filled.Notifications,
                step = 3,
                title = tr("Notifications", "Notifications"),
                text = tr(
                    "टास्क, टेस्टिंग और भुगतान के अलर्ट दिखाने के लिए।",
                    "Shows your task, testing and payment alerts."
                ),
                granted = notificationOk,
                actionText = tr("अनुमति दें", "Allow"),
            ) {
                if (Build.VERSION.SDK_INT >= 33) {
                    askedAt[0] = System.currentTimeMillis()
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    OemSettings.openNotificationSettings(ctx)
                }
            }

            StepCard(
                icon = Icons.Filled.PlayArrow,
                step = 0,
                title = tr("Auto-start चालू करें", "Turn on Auto-start"),
                text = tr(
                    "Realme, Oppo, Vivo और Xiaomi फ़ोन ऐप्स को बैकग्राउंड में बंद कर देते हैं। यहाँ Tester Track के लिए Auto-start चालू करें, ताकि अलर्ट न रुकें।",
                    "Realme, Oppo, Vivo and Xiaomi phones close apps in the background. Turn on Auto-start for Tester Track so your alerts don't stop."
                ),
                granted = false,
                optional = true,
                actionText = tr("सेटिंग खोलें", "Open settings"),
            ) { OemSettings.openAutoStart(ctx) }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(Icons.Filled.Lock, null, tint = Sub, modifier = Modifier.size(16.dp).padding(top = 2.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    tr(
                        "निगरानी के दौरान Android एक स्थायी सूचना दिखाता है। यह सामान्य है और ऐप को चालू रखती है।",
                        "While Tester Track is watching, Android shows a permanent notification. That's normal, and it keeps the app running."
                    ),
                    color = Sub, fontSize = 12.sp
                )
            }
        }

        // ---- continue ----
        Column(
            Modifier
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AppButton(
                if (ready) tr("होम स्क्रीन खोलें", "Continue to home") else tr("आगे बढ़ें", "Continue"),
                onClick = { if (ready) onComplete() },
                enabled = ready,
                modifier = Modifier.fillMaxWidth()
            )
            ButtonHint(if (ready) "" else tr("आगे बढ़ने के लिए ऊपर के 3 स्टेप पूरे करें", "Finish the 3 steps above to continue"))
            TextButton(onClick = onSignOut) {
                Text(tr("साइन आउट", "Sign out"), color = Sub, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun StepCard(
    icon: ImageVector,
    step: Int,                       // 1..3, or 0 for the optional card
    title: String,
    text: String,
    granted: Boolean,
    actionText: String,
    optional: Boolean = false,
    onAction: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = Color.White,
        shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(if (granted) GreenSoft else Tile),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (granted) Icons.Filled.Check else icon, null,
                        tint = if (granted) Green else Purple, modifier = Modifier.size(26.dp)
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    if (step > 0) Text(tr("स्टेप $step", "Step $step"), color = Sub, fontSize = 12.sp)
                    Text(title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                }
                when {
                    granted -> Pill(tr("चालू", "Allowed"), Green, GreenSoft)
                    optional -> Pill(tr("वैकल्पिक", "Optional"), Purple, Tile)
                    else -> Pill(tr("ज़रूरी", "Needed"), Amber, AmberSoft)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(text, color = Sub, fontSize = 14.sp)
            if (!granted) {
                Spacer(Modifier.height(14.dp))
                AppButton(
                    actionText, onAction,
                    modifier = Modifier.fillMaxWidth(),
                    kind = if (optional) BtnKind.Outline else BtnKind.Primary
                )
            }
        }
    }
}
