package com.rajeev.testertrack.ui.screens

import com.rajeev.testertrack.ui.components.BtnKind
import com.rajeev.testertrack.ui.components.AppButton
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.testertrack.data.Dates
import com.rajeev.testertrack.data.Notif
import com.rajeev.testertrack.data.NotifType
import com.rajeev.testertrack.data.Repo
import com.rajeev.testertrack.data.TaskStatus
import com.rajeev.testertrack.data.tr
import com.rajeev.testertrack.ui.Runner
import com.rajeev.testertrack.ui.components.EmptyNote
import com.rajeev.testertrack.ui.components.SubTopBar
import com.rajeev.testertrack.ui.theme.Green
import com.rajeev.testertrack.ui.theme.GreenSoft
import com.rajeev.testertrack.ui.theme.Ink
import com.rajeev.testertrack.ui.theme.Line
import com.rajeev.testertrack.ui.theme.Purple
import com.rajeev.testertrack.ui.theme.Red
import com.rajeev.testertrack.ui.theme.Sub
import com.rajeev.testertrack.ui.theme.Tile

/** Tester's list of notifications; opens from the bell on the home screen. */
@Composable
fun NotificationsScreen(
    teamId: String, list: List<Notif>, run: Runner, onOpenTasks: () -> Unit, onBack: () -> Unit,
    isAdmin: Boolean = false, onOpenTester: (String) -> Unit = {}, onOpenWallet: () -> Unit = {},
    onOpenAddMember: () -> Unit = {},
    onOpenUsefulLinks: () -> Unit = {},
) {
    val sorted = list.sortedByDescending { it.createdAt }
    Column(Modifier.fillMaxSize()) {
        SubTopBar(tr("सूचनाएं", "Notifications"), onBack)
        val unreadCount = sorted.count { !it.read }
        if (unreadCount > 0) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(tr("$unreadCount नई", "$unreadCount unread"), color = Sub, fontSize = 14.sp, modifier = Modifier.weight(1f))
                AppButton(tr("सब पढ़ा हुआ", "Mark all read"), { run(null) { Repo.markAllRead(teamId, sorted) } },
                    kind = BtnKind.Outline, small = true)
            }
        }
        if (sorted.isEmpty()) {
            Spacer(Modifier.size(16.dp))
            EmptyNote(
                if (isAdmin) tr("अभी कोई सूचना नहीं। टेस्टर कोई ऐप इंस्टॉल या हटाएगा तो यहाँ दिखेगा।", "No notifications yet. When a tester installs or removes an app, it will show here.")
                else tr("अभी कोई सूचना नहीं। नए टास्क और टेस्टिंग के रिमाइंडर यहाँ दिखेंगे।", "No notifications yet. New tasks and testing reminders will show here.")
            )
            return@Column
        }
        Surface(
            shape = RoundedCornerShape(24.dp), color = Color.White,
            modifier = Modifier.padding(14.dp).fillMaxWidth()
        ) {
            LazyColumn(Modifier.navigationBarsPadding()) {
                itemsIndexed(sorted, key = { _, n -> n.id }) { i, n ->
                    if (i > 0) HorizontalDivider(color = Line, modifier = Modifier.padding(horizontal = 16.dp))
                    NotifRow(n) {
                        if (!n.read) run(null) { Repo.markRead(teamId, n.id) }
                        if (n.type == NotifType.REWARD || n.type == NotifType.PAID || n.type == NotifType.DECLINED) onOpenWallet()
                        else if (n.type == NotifType.USEFUL_LINK) onOpenUsefulLinks()
                        else if (NotifType.isSelf(n.type)) onBack()                                            // testing days are on the home screen
                        else if (n.type == NotifType.APP_READY || n.type == NotifType.WITHDRAW) onBack()     // the Give button is on the admin home
                        else if (n.type == NotifType.MEMBER_REQUEST) onBack()                                  // Approve / Decline is on the admin home
                        else if (n.type == NotifType.MEMBER_APPROVED || n.type == NotifType.MEMBER_DECLINED) onOpenAddMember()
                        else if (NotifType.isApp(n.type)) onOpenTester(n.fromUid)
                        else if (n.type != NotifType.DELETED) onOpenTasks()
                    }
                }
            }
        }
    }
}

@Composable
private fun NotifRow(n: Notif, onClick: () -> Unit) {
    val (icon, bg, fg) = when (n.type) {
        NotifType.NEW_TASK -> Triple(Icons.AutoMirrored.Filled.List, Tile, Purple)
        NotifType.STATUS -> Triple(Icons.Filled.CheckCircle, GreenSoft, Green)
        NotifType.APP_ADDED -> Triple(Icons.Filled.AddCircle, Tile, Purple)
        NotifType.APP_REMOVED -> Triple(Icons.Filled.Delete, Color(0xFFFDECEC), Red)
        NotifType.APP_MISSED, NotifType.SELF_MISSED, NotifType.SELF_REMIND -> Triple(Icons.Filled.Warning, Color(0xFFFFF3E0), Color(0xFFE65100))
        NotifType.APP_FAILED, NotifType.SELF_FAILED -> Triple(Icons.Filled.Warning, Color(0xFFFDECEC), Red)
        NotifType.LINK_OPENED, NotifType.APP_OPENED -> Triple(Icons.Filled.CheckCircle, Tile, Purple)
        NotifType.APP_STARTED -> Triple(Icons.Filled.CheckCircle, GreenSoft, Green)
        NotifType.USEFUL_LINK -> Triple(Icons.Filled.Star, Tile, Purple)
        NotifType.APP_READY, NotifType.REWARD, NotifType.PAID, NotifType.WITHDRAW -> Triple(Icons.Filled.Star, GreenSoft, Green)
        NotifType.DECLINED, NotifType.MEMBER_DECLINED -> Triple(Icons.Filled.Warning, Color(0xFFFFF3E0), Color(0xFFE65100))
        NotifType.MEMBER_REQUEST, NotifType.MEMBER_APPROVED -> Triple(Icons.Filled.Person, Tile, Purple)
        else -> Triple(Icons.Filled.Delete, Color(0xFFFDECEC), Red)
    }
    val title = when (n.type) {
        NotifType.NEW_TASK -> tr("नया टास्क: ${n.title}", "New task: ${n.title}")
        NotifType.STATUS -> tr("एडमिन ने “${n.title}” को ${TaskStatus.label(n.body)} किया", "Admin marked “${n.title}” as ${statusWord(n.body)}")
        NotifType.APP_ADDED -> tr("${n.title} ने ऐप इंस्टॉल किया", "${n.title} installed an app")
        NotifType.APP_REMOVED -> tr("${n.title} ने ऐप अनइंस्टॉल किया", "${n.title} uninstalled an app")
        NotifType.LINK_OPENED -> tr("${n.title} ने लिंक खोला", "${n.title} has clicked the link")
        NotifType.USEFUL_LINK -> if (n.body == "changed") tr("उपयोगी लिंक बदला: ${n.title}", "Useful link changed: ${n.title}")
            else tr("नया उपयोगी लिंक: ${n.title}", "New useful link: ${n.title}")
        NotifType.APP_STARTED -> tr("${n.title} ने ऐप इंस्टॉल करके खोला और काम शुरू किया", "${n.title} has installed and opened the app and started working")
        NotifType.APP_OPENED -> tr("${n.title} ने आज ऐप खोला", "${n.title} opened an app today")
        NotifType.APP_FAILED -> tr("${n.title} 14 दिन पूरे नहीं कर पाए", "${n.title} failed the 14 days")
        NotifType.SELF_REMIND -> tr("आज ${n.title} नहीं खोला — आधी रात से पहले खोलें (दिन ${n.body})", "You haven't opened ${n.title} today — open it before midnight (Day ${n.body})")
        NotifType.SELF_MISSED -> tr("कल ${n.title} नहीं खोला (दिन ${n.body})", "You missed ${n.title} yesterday (Day ${n.body})")
        NotifType.SELF_FAILED -> tr("माफ़ करें ${n.body}, ${n.title} का इनाम नहीं मिला", "Sorry ${n.body}, you failed to get rewards for ${n.title}")
        NotifType.APP_MISSED -> tr("${n.title} ने कल ऐप नहीं खोला", "${n.title} didn't open an app yesterday")
        NotifType.APP_READY -> tr("🎉 बधाई हो! ${n.title} ने 14 दिन पूरे किए", "🎉 Congratulations! ${n.title} has completed")
        NotifType.REWARD -> tr("₹${n.body} आपके वॉलेट में जुड़े", "₹${n.body} added to your wallet")
        NotifType.WITHDRAW -> tr("${n.title} ने निकासी माँगी", "${n.title} requested a withdrawal")
        NotifType.PAID -> tr("₹${n.body} आपके UPI में भेजे गए", "₹${n.body} sent to your UPI")
        NotifType.DECLINED -> tr("निकासी अनुरोध अस्वीकार हुआ", "Withdrawal request declined")
        NotifType.MEMBER_REQUEST -> tr("${n.title} ने सदस्य जोड़ने को कहा", "${n.title} asked to add a member")
        NotifType.MEMBER_APPROVED -> tr("${n.title} का अनुरोध मंज़ूर हुआ", "${n.title} was approved")
        NotifType.MEMBER_DECLINED -> tr("${n.title} का अनुरोध अस्वीकार हुआ", "${n.title} was declined")
        else -> tr("टास्क “${n.title}” हटाया गया", "Task “${n.title}” was deleted")
    }
    val sub = listOfNotNull(
        (if (n.type == NotifType.REWARD) n.title else n.body).takeIf { (n.type == NotifType.NEW_TASK || NotifType.isApp(n.type) || n.type == NotifType.REWARD || n.type == NotifType.MEMBER_REQUEST || n.type == NotifType.MEMBER_APPROVED || n.type == NotifType.MEMBER_DECLINED) && it.isNotBlank() },
        Dates.dateTime(n.createdAt)
    ).joinToString(" · ")
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(bg), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = if (n.read) Sub else Ink, fontSize = 15.sp, fontWeight = if (n.read) FontWeight.Normal else FontWeight.SemiBold)
            Text(sub, color = Sub, fontSize = 12.sp)
        }
        if (!n.read) {
            Spacer(Modifier.width(8.dp))
            Box(Modifier.padding(top = 6.dp).size(9.dp).clip(CircleShape).background(Purple))
        }
    }
}

private fun statusWord(s: String) = when (s) {
    TaskStatus.DONE -> "Done"
    TaskStatus.FAILED -> "Failed"
    TaskStatus.WORKING -> "Working"
    else -> "Pending"
}
