BUILD (Android Studio, free)
1. Install Android Studio (Koala or newer). File > Open > select this folder (NiftyLevels). Let Gradle sync finish.
2. Plug in your phone (enable Developer options + USB debugging) and press Run. Or Build > Build APK(s) and install the APK.
3. On first launch allow notifications. Tap Refresh to fill 16 Jul to today.
The app then updates itself about 4:45 PM IST on weekdays and sends a notification.
Change NEAR (50 points) in Levels.kt.
