NIFTY LEVELS (educational tool)

BUILD: open this folder in Android Studio, let Gradle sync, press Run (or Build > Build APK).
Or upload to your ZIP-to-APK workflow. Needs Android 10 or newer.

TABS
Sheet  - your Excel grid, today's row pinned, Open in Excel / Export
Today  - levels, open, level-based indication, CPR read, log your trade
Chart  - candles with next-session levels
Stats  - backtest of your rule + win rates from your logged trades
More   - settings (theme, rule distance, alerts, PIN) and your trades list

SYMBOLS: top-left menu switches Nifty 50 / Bank Nifty / Sensex or any Yahoo code (e.g. RELIANCE.NS).
WIDGET: long-press home screen > Widgets > Nifty Levels.
TESTS: ./gradlew testDebugUnitTest
Edit the rule distance in More > Rule distance (default 50 points).
