package com.niftylevels

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class BtRow(val date: String, val side: String, val strike: Double, val close: Double, val win: Boolean)

data class Backtest(val rows: List<BtRow>) {
    val n get() = rows.size
    val wins get() = rows.count { it.win }
    fun pct(side: String? = null): Double {
        val r = if (side == null) rows else rows.filter { it.side == side }
        return if (r.isEmpty()) 0.0 else 100.0 * r.count { it.win } / r.size
    }
    fun count(side: String) = rows.count { it.side == side }
}

/**
 * Replays your rule on past days: green open near R1 -> Call (strike at R1), red open near S1 -> Put (strike at S2).
 * A Call "wins" if the day closes above the strike, a Put if it closes below it (same as your Yes/No).
 */
fun backtest(candles: List<Candle>, near: Double): Backtest {
    val out = mutableListOf<BtRow>()
    for (i in 1 until candles.size) {
        val prev = candles[i - 1]; val cur = candles[i]
        val op = cur.open ?: continue
        val lv = levels(prev.high, prev.low, prev.close)
        val gap = op - prev.close
        val step = stepFor(prev.close)
        if (gap > 0 && abs(op - lv.r1) <= near) {
            val k = floorTo(lv.r1, step); out.add(BtRow(cur.date, "Call", k, cur.close, cur.close > k))
        } else if (gap < 0 && abs(op - lv.s1) <= near) {
            val k = floorTo(lv.s2, step); out.add(BtRow(cur.date, "Put", k, cur.close, cur.close < k))
        }
    }
    return Backtest(out)
}

data class Stat(val label: String, val n: Int, val wins: Int) {
    val pct get() = if (n == 0) 0.0 else 100.0 * wins / n
}

/** Win rates from YOUR logged trades: by side, by level, and by green/red open. */
fun noteStats(candles: List<Candle>, notes: Map<String, Note>): List<Stat> {
    val idx = candles.withIndex().associate { it.value.date to it.index }
    val map = linkedMapOf<String, IntArray>()
    fun add(k: String, w: Boolean) { val a = map.getOrPut(k) { IntArray(2) }; a[0]++; if (w) a[1]++ }
    for ((date, n) in notes) {
        val r = n.result.lowercase()
        if (r != "yes" && r != "no") continue
        val w = r == "yes"
        if (n.side.isNotEmpty()) add(n.side, w)
        if (n.level.isNotEmpty()) add("Level ${n.level}", w)
        val i = idx[date]
        if (i != null && i > 0) {
            val op = candles[i].open
            if (op != null) add(if (op > candles[i - 1].close) "Green open" else "Red open", w)
        }
    }
    return map.map { Stat(it.key, it.value[0], it.value[1]) }.sortedBy { it.label }
}

data class CprInfo(val width: Double, val pctOfPrice: Double, val kind: String, val trend: String, val openPos: String)

/** CPR width, its trend versus the previous CPR, and where today's open sits. */
fun cprInfo(candles: List<Candle>, open: Double?): CprInfo? {
    if (candles.size < 3) return null
    fun band(c: Candle): Pair<Double, Double> {
        val l = levels(c.high, c.low, c.close); return min(l.tc, l.bc) to max(l.tc, l.bc)
    }
    val last = candles.last()
    val (bot, top) = band(last)
    val width = top - bot
    val hist = candles.dropLast(1).takeLast(20).map { val b = band(it); b.second - b.first }
    val avg = hist.average()
    val ratio = if (avg > 0) width / avg else 1.0
    val kind = when {
        ratio < 0.7 -> "Narrow CPR: trending or breakout day more likely"
        ratio > 1.3 -> "Wide CPR: range-bound day more likely"
        else -> "Normal CPR width"
    }
    val (pBot, pTop) = band(candles[candles.size - 2])
    val trend = when {
        bot > pTop -> "Higher-value CPR (bullish bias)"
        top < pBot -> "Lower-value CPR (bearish bias)"
        else -> "Overlapping CPR (sideways bias)"
    }
    val pos = when {
        open == null -> ""
        open > top -> "Open is above CPR"
        open < bot -> "Open is below CPR"
        else -> "Open is inside CPR"
    }
    return CprInfo(width, 100.0 * width / last.close, kind, trend, pos)
}
