package com.niftylevels

import android.app.Application
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import kotlin.concurrent.thread

/** Holds all app state so screens stay simple and survive rotation. */
class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application = app
    val settings = Settings(app)
    private val main = Handler(Looper.getMainLooper())

    var candles by mutableStateOf<List<Candle>>(emptyList())
    var notes by mutableStateOf<Map<String, Note>>(emptyMap())
    var status by mutableStateOf("")
    var loading by mutableStateOf(false)
    var symbol by mutableStateOf(NIFTY)
    var symbols by mutableStateOf<List<Sym>>(PRESETS)
    var openText by mutableStateOf("")
    var theme by mutableStateOf(0)
    var near by mutableStateOf(50.0)
    var alertPts by mutableStateOf(10.0)
    var alertsOn by mutableStateOf(false)
    var morningOn by mutableStateOf(false)
    var pinSet by mutableStateOf(false)
    var disclaimerOk by mutableStateOf(true)

    init { reload(); if (candles.isEmpty()) refresh() }

    val symbolName: String get() = settings.nameOf(symbol)
    fun session(): String = nextTradingDay(candles.last().date)

    fun reload() {
        symbol = settings.symbol
        symbols = settings.allSymbols()
        theme = settings.theme; near = settings.near; alertPts = settings.alertPts
        alertsOn = settings.alertsOn; morningOn = settings.morningOn
        pinSet = settings.hasPin(); disclaimerOk = settings.disclaimerOk
        candles = Repo.loadCandles(ctx)
        notes = Repo.loadNotes(ctx)
        openText = if (candles.isEmpty()) "" else Repo.loadOpen(ctx, session())?.toString() ?: ""
    }

    fun refresh() {
        loading = true; status = "Updating…"
        thread {
            val msg = try { "Added ${Repo.refresh(ctx)} day(s)" } catch (e: Exception) { "Update failed (check internet / symbol)" }
            try { ExcelExport.writeFile(ctx) } catch (e: Exception) { }
            try { LevelsWidget.refresh(ctx) } catch (e: Exception) { }
            main.post { reload(); status = msg; loading = false }
        }
    }

    fun switchSymbol(code: String) {
        settings.symbol = code
        reload()
        if (candles.isEmpty()) refresh() else status = ""
    }

    fun addSymbol(code: String) {
        settings.addCustom(code)
        switchSymbol(code.trim().uppercase())
    }

    fun onOpenChange(s: String) {
        openText = s
        if (candles.isNotEmpty()) Repo.saveOpen(ctx, session(), s.toDoubleOrNull())
    }

    fun saveNote(n: Note) {
        val m = notes + (session() to n)
        notes = m; Repo.saveNotes(ctx, m)
        try { ExcelExport.writeFile(ctx) } catch (e: Exception) { }
        status = "Saved to sheet"
    }

    fun updateTheme(v: Int) { settings.theme = v; theme = v }
    fun updateNear(v: Double) { settings.near = v; near = v }
    fun updateAlertPts(v: Double) { settings.alertPts = v; alertPts = v }
    fun setAlerts(v: Boolean) { settings.alertsOn = v; alertsOn = v }
    fun setMorning(v: Boolean) { settings.morningOn = v; morningOn = v }
    fun setPin(p: String?) { settings.setPin(p); pinSet = p != null }
    fun acceptDisclaimer() { settings.disclaimerOk = true; disclaimerOk = true }
}
