package com.niftylevels

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.min

/** Candlestick chart of the last 40 days with the next session's levels drawn on it. */
@Composable
fun ChartScreen(vm: AppViewModel) {
    val data = vm.candles.takeLast(40)
    val last = vm.candles.last()
    val lv = levels(last.high, last.low, last.close)
    val up = cUp(); val dn = cDown(); val ac = cAccent(); val muted = cMuted()
    val lines = listOf(
        Triple("R2", lv.r2, dn), Triple("R1", lv.r1, dn), Triple("TC", lv.tc, ac), Triple("Pivot", lv.p, ac),
        Triple("BC", lv.bc, ac), Triple("S1", lv.s1, up), Triple("S2", lv.s2, up)
    )
    val lo0 = data.minOf { it.low }
    val hi0 = data.maxOf { it.high }
    val pad = (hi0 - lo0) * 0.12
    val lo = lo0 - pad
    val hi = hi0 + pad
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Last ${data.size} days · levels for ${nextTradingDay(last.date)}", color = muted, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Canvas(Modifier.fillMaxWidth().weight(1f)) {
            val w = size.width
            val h = size.height
            val rightPad = 64.dp.toPx()
            val plotW = w - rightPad
            val step = plotW / data.size
            fun y(v: Double): Float = (((hi - v) / (hi - lo)) * h).toFloat()
            // level lines first (behind candles)
            for ((name, v, col) in lines) {
                if (v < lo || v > hi) continue
                drawLine(col, Offset(0f, y(v)), Offset(plotW, y(v)), strokeWidth = 1.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
                val paint = Paint().apply { color = col.toArgb(); textSize = 11.sp.toPx(); isAntiAlias = true }
                drawContext.canvas.nativeCanvas.drawText("$name ${v.toInt()}", plotW + 6f, y(v) + 4f, paint)
            }
            for ((i, c) in data.withIndex()) {
                val x = step * i + step / 2f
                val o = c.open ?: c.close
                val col = if (c.close >= o) up else dn
                drawLine(col, Offset(x, y(c.high)), Offset(x, y(c.low)), strokeWidth = 2f)
                val top = y(max(o, c.close))
                val bottom = y(min(o, c.close))
                drawRect(col, Offset(x - step * 0.3f, top), Size(step * 0.6f, max(bottom - top, 2f)))
            }
        }
        Text("Green candle: close above open. Dashed lines: next-session levels.", color = muted, fontSize = 11.sp)
    }
}
