package com.niftylevels

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Builds an .xlsx with the same layout, colours and formulas as your original sheet.
 * assets/template.xlsx = your workbook (styles, headers); sheet_head/tail = rows 1-3 and the sheet footer.
 */
object ExcelExport {
    // Style ids copied from your sheet (see styles.xml)
    private val BLANK = listOf(
        "A" to 53, "B" to 53, "C" to 54, "D" to 54, "E" to 54, "F" to 55, "G" to 25, "H" to 20,
        "I" to 56, "J" to 56, "K" to 57, "L" to 3, "M" to 52, "N" to 20, "O" to 20, "P" to 20,
        "Q" to 9, "R" to 58, "S" to 58, "T" to 58, "U" to 39, "V" to 9, "W" to 9, "X" to 9
    )

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun serial(d: String) = LocalDate.parse(d).toEpochDay() + 25569
    private fun dayName(d: String) = LocalDate.parse(d).dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)

    private fun StringBuilder.num(ref: String, s: Int, v: Number) { append("<c r=\"$ref\" s=\"$s\"><v>$v</v></c>") }
    private fun StringBuilder.str(ref: String, s: Int, v: String) { append("<c r=\"$ref\" s=\"$s\" t=\"inlineStr\"><is><t>${esc(v)}</t></is></c>") }
    private fun StringBuilder.fml(ref: String, s: Int, f: String, v: Double) { append("<c r=\"$ref\" s=\"$s\"><f>${esc(f)}</f><v>$v</v></c>") }
    private fun StringBuilder.blank(ref: String, s: Int) { append("<c r=\"$ref\" s=\"$s\"/>") }

    fun build(ctx: Context, rows: List<SheetRow>): ByteArray {
        val sb = StringBuilder(ctx.assets.open("sheet_head.xml").bufferedReader().readText())
        for ((i, w) in rows.withIndex()) {
            val r = 4 + i
            val op = w.op
            sb.append("<row r=\"$r\">")
            sb.num("A$r", 22, serial(w.prevDate)); sb.str("B$r", 5, dayName(w.prevDate))
            sb.num("C$r", 23, w.h); sb.num("D$r", 23, w.l); sb.num("E$r", 23, w.c)
            sb.fml("F$r", 24, "(C$r+D$r)/2", w.bc)
            sb.fml("G$r", 25, "(C$r+D$r+E$r)/3", w.p)
            sb.fml("H$r", 26, "(G$r-F$r)+G$r", w.tc)
            sb.num("I$r", 27, serial(w.curDate)); sb.str("J$r", 27, dayName(w.curDate))
            if (op != null) sb.num("K$r", 31, op) else sb.blank("K$r", 31)
            if (w.diff != null) sb.fml("L$r", 34, "K$r-M${r - 1}", w.diff) else sb.blank("L$r", 34)
            if (w.cl != null) sb.num("M$r", 32, w.cl) else sb.blank("M$r", 32)
            sb.fml("N$r", 26, "C$r+2*(G$r-D$r)", w.r3)
            sb.fml("O$r", 26, "G$r+(C$r-D$r)", w.r2)
            sb.fml("P$r", 26, "(2*G$r)-D$r", w.r1)
            // Today's open: green when above yesterday's close, red when below (same as your sheet)
            if (op != null) sb.fml("Q$r", if (op > w.c) 26 else 33, "K$r", op) else sb.blank("Q$r", 26)
            sb.fml("R$r", 29, "(2*G$r)-C$r", w.s1)
            sb.fml("S$r", 29, "G$r-(C$r-D$r)", w.s2)
            sb.fml("T$r", 29, "D$r-2*(C$r-G$r)", w.s3)
            sb.blank("U$r", 21)
            val n = w.note
            if (n != null && (n.side.isNotEmpty() || n.level.isNotEmpty() || n.strike.isNotEmpty())) {
                val sv = n.strike.toDoubleOrNull()
                if (sv != null) sb.num("V$r", 9, sv) else sb.blank("V$r", 9)
                val label = if (n.side.isNotEmpty()) n.side + (if (n.level.isNotEmpty()) "(${n.level})" else "") else n.level
                if (label.isNotEmpty()) sb.str("W$r", 9, label) else sb.blank("W$r", 9)
                if (n.result.isNotEmpty()) sb.str("X$r", 9, n.result) else sb.blank("X$r", 9)
            } else { sb.blank("V$r", 9); sb.blank("W$r", 9); sb.blank("X$r", 9) }
            sb.append("</row>")
        }
        for (r in (4 + rows.size)..1004) {
            sb.append("<row r=\"$r\">")
            for ((col, s) in BLANK) sb.blank("$col$r", s)
            sb.append("</row>")
        }
        sb.append(ctx.assets.open("sheet_tail.xml").bufferedReader().readText())

        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { zo ->
            ZipInputStream(ctx.assets.open("template.xlsx")).use { zi ->
                var e = zi.nextEntry
                while (e != null) {
                    zo.putNextEntry(ZipEntry(e.name)); zo.write(zi.readBytes()); zo.closeEntry()
                    e = zi.nextEntry
                }
            }
            zo.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
            zo.write(sb.toString().toByteArray(Charsets.UTF_8)); zo.closeEntry()
        }
        return bos.toByteArray()
    }

    /** Rebuilds the app's own Nifty_Levels.xlsx from the latest data and notes. Called after every update or save. */
    fun writeFile(ctx: Context): File {
        val candles = Repo.loadCandles(ctx)
        val session = nextTradingDay(candles.last().date)
        val rows = buildRows(candles, Repo.loadNotes(ctx), Repo.loadOpen(ctx, session))
        val f = File(ctx.filesDir, "Nifty_Levels.xlsx")
        f.writeBytes(build(ctx, rows))
        return f
    }
}
