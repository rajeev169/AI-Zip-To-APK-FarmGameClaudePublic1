package com.niftylevels

import java.time.DayOfWeek
import java.time.LocalDate
import kotlin.math.floor

/** How close (in points) the open must be to R1 / S1 to count as "close to". Edit as you like. */
const val NEAR = 50.0

data class Candle(val date: String, val open: Double?, val high: Double, val low: Double, val close: Double)

data class Note(val side: String = "", val level: String = "", val strike: String = "", val result: String = "", val open: String = "")

/** Same formulas as your Excel sheet. */
data class Levels(
    val r3: Double, val r2: Double, val r1: Double,
    val tc: Double, val p: Double, val bc: Double,
    val s1: Double, val s2: Double, val s3: Double
) {
    fun asList() = listOf(
        "R3" to r3, "R2" to r2, "R1" to r1, "TC" to tc, "Pivot" to p, "BC" to bc,
        "S1" to s1, "S2" to s2, "S3" to s3
    )
}

fun levels(h: Double, l: Double, c: Double): Levels {
    val p = (h + l + c) / 3
    val bc = (h + l) / 2
    return Levels(
        r3 = h + 2 * (p - l), r2 = p + (h - l), r1 = 2 * p - l,
        tc = 2 * p - bc, p = p, bc = bc,
        s1 = 2 * p - h, s2 = p - (h - l), s3 = l - 2 * (h - p)
    )
}

fun nextTradingDay(date: String): String {
    var d = LocalDate.parse(date).plusDays(1)
    while (d.dayOfWeek == DayOfWeek.SATURDAY || d.dayOfWeek == DayOfWeek.SUNDAY) d = d.plusDays(1)
    return d.toString()
}

fun floor50(x: Double) = floor(x / 50) * 50

/** Typical option strike gap for a given price level (Nifty 50, Bank Nifty 100, stocks smaller). */
fun stepFor(price: Double): Double = when {
    price >= 30000 -> 100.0
    price >= 10000 -> 50.0
    price >= 2000 -> 20.0
    price >= 500 -> 10.0
    else -> 5.0
}

fun floorTo(x: Double, step: Double) = floor(x / step) * step

data class Suggestion(val text: String, val kind: String) // kind: CALL, PUT, NONE

/** Your rule: green open near R1 -> Call; red open near S1 -> Put (strike at S2). */
fun suggest(open: Double, last: Candle, near: Double = NEAR): Suggestion {
    val l = levels(last.high, last.low, last.close)
    val gap = open - last.close
    val step = stepFor(last.close)
    return when {
        gap > 0 && Math.abs(open - l.r1) <= near ->
            Suggestion("CALL idea: green open (+%.2f) near R1 %.2f. Strike about %.0f".format(gap, l.r1, floorTo(l.r1, step)), "CALL")
        gap < 0 && Math.abs(open - l.s1) <= near ->
            Suggestion("PUT idea: red open (%.2f) near S1 %.2f. Strike S2 about %.0f".format(gap, l.s1, floorTo(l.s2, step)), "PUT")
        else -> Suggestion(
            "NO TRADE: %s open (%.2f), not within %.0f pts of %s".format(
                if (gap > 0) "green" else "red", gap, near, if (gap > 0) "R1" else "S1"), "NONE")
    }
}
