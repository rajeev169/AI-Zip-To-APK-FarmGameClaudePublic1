package com.niftylevels

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Home-screen widget: today's R1, Pivot and S1. */
class LevelsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { appWidgetManager.updateAppWidget(it, build(context)) }
    }

    companion object {
        fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_levels)
            try {
                val c = Repo.loadCandles(ctx)
                if (c.isNotEmpty()) {
                    val last = c.last()
                    val l = levels(last.high, last.low, last.close)
                    rv.setTextViewText(R.id.w_title, "${Settings(ctx).nameOf(Repo.symbol(ctx))} · ${nextTradingDay(last.date)}")
                    rv.setTextViewText(R.id.w_r1, "R1  %,.2f".format(l.r1))
                    rv.setTextViewText(R.id.w_p, "Pivot  %,.2f".format(l.p))
                    rv.setTextViewText(R.id.w_s1, "S1  %,.2f".format(l.s1))
                }
            } catch (e: Exception) { }
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            rv.setOnClickPendingIntent(R.id.w_root, pi)
            return rv
        }

        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, LevelsWidget::class.java))
            ids.forEach { mgr.updateAppWidget(it, build(ctx)) }
        }
    }
}
