package com.niftylevels

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlin.concurrent.thread

private val Bg = Color(0xFF0F1419)
private val Card = Color(0xFF18202A)
private val Up = Color(0xFF3DDC97)
private val Down = Color(0xFFFF6B6B)
private val Accent = Color(0xFF6EA8FE)
private val Muted = Color(0xFF8A97A6)
private const val XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        UpdateWorker.schedule(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) {
                Surface(color = Bg, modifier = Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) =
    Column(
        Modifier.fillMaxWidth().background(Card, androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).padding(14.dp),
        content = content
    )

fun colorFor(name: String) = when {
    name.startsWith("R") -> Down
    name.startsWith("S") -> Up
    else -> Accent
}

/** Opens the app's own Nifty_Levels.xlsx in Excel / Sheets. */
fun openInExcel(ctx: Context): String {
    return try {
        val f = ExcelExport.writeFile(ctx)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, XLSX)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Open Excel file"))
        ""
    } catch (e: ActivityNotFoundException) {
        "Install Excel or Google Sheets to open the file"
    } catch (e: Exception) {
        "Could not open: ${e.message}"
    }
}

/** Saves a dated copy into Downloads and opens the share sheet. */
fun exportToDownloads(ctx: Context): String {
    return try {
        val bytes = ExcelExport.writeFile(ctx).readBytes()
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "Nifty_Levels_${java.time.LocalDate.now()}.xlsx")
            put(MediaStore.Downloads.MIME_TYPE, XLSX)
        }
        val uri: Uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        ctx.contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = XLSX
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Share Excel"))
        "Saved in Downloads"
    } catch (e: Exception) {
        "Export failed: ${e.message}"
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var candles by remember { mutableStateOf(Repo.loadCandles(ctx)) }
    var notes by remember { mutableStateOf(Repo.loadNotes(ctx)) }
    var status by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }

    val last = candles.last()
    val session = nextTradingDay(last.date)
    var openText by remember(session) { mutableStateOf(Repo.loadOpen(ctx, session)?.toString() ?: "") }
    val open = openText.toDoubleOrNull()
    val rows = remember(candles, notes, open) { buildRows(candles, notes, open) }

    fun refresh() {
        status = "Updating…"
        thread {
            val msg = try { "Added ${Repo.refresh(ctx)} day(s)" } catch (e: Exception) { "Update failed (check internet)" }
            try { ExcelExport.writeFile(ctx) } catch (e: Exception) { }
            val fresh = Repo.loadCandles(ctx)
            android.os.Handler(ctx.mainLooper).post { candles = fresh; status = msg }
        }
    }

    Scaffold(
        containerColor = Bg,
        modifier = Modifier.statusBarsPadding(),
        bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf("Sheet" to "▦", "Today" to "◎", "Notes" to "✎").forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(icon, fontSize = 18.sp) }, label = { Text(label) })
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Nifty Levels", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("Last data ${last.date} · $status", color = Muted, fontSize = 11.sp, maxLines = 1)
                        }
                        Button({ status = openInExcel(ctx) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Open in Excel", fontSize = 12.sp) }
                        Spacer(Modifier.width(6.dp))
                        FilledTonalButton({ status = exportToDownloads(ctx) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Export", fontSize = 12.sp) }
                    }
                    SheetGrid(rows, Modifier.weight(1f))
                }
                1 -> TodayTab(
                    last = last, session = session, openText = openText,
                    onOpen = { openText = it; Repo.saveOpen(ctx, session, it.toDoubleOrNull()) },
                    note = notes[session], status = status,
                    onRefresh = { refresh() },
                    onSave = { n ->
                        notes = notes + (session to n); Repo.saveNotes(ctx, notes)
                        try { ExcelExport.writeFile(ctx) } catch (e: Exception) { }
                        status = "Saved to sheet"
                    }
                )
                else -> NotesTab(notes)
            }
        }
    }
}

@Composable
fun TodayTab(
    last: Candle, session: String, openText: String, onOpen: (String) -> Unit,
    note: Note?, status: String, onRefresh: () -> Unit, onSave: (Note) -> Unit
) {
    val lv = levels(last.high, last.low, last.close)
    val open = openText.toDoubleOrNull()
    val sug = open?.let { suggest(it, last) }
    var side by remember(session) { mutableStateOf(note?.side ?: "") }
    var level by remember(session) { mutableStateOf(note?.level ?: "") }
    var strike by remember(session) { mutableStateOf(note?.strike ?: "") }
    var result by remember(session) { mutableStateOf(note?.result ?: "") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Today · $session", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Panel {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Levels (from ${last.date} close)", color = Muted, fontSize = 14.sp)
                TextButton(onRefresh) { Text("Refresh") }
            }
            if (status.isNotEmpty()) Text(status, color = Muted, fontSize = 12.sp)
            lv.asList().forEach { (k, v) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(k, color = colorFor(k)); Text(n2(v), fontWeight = FontWeight.Bold)
                }
            }
        }
        Panel {
            Text("Today's open", color = Muted, fontSize = 14.sp)
            OutlinedTextField(openText, onOpen, Modifier.fillMaxWidth(), placeholder = { Text("e.g. 24142.10") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            Spacer(Modifier.height(8.dp))
            Text(sug?.text ?: "Enter the open to get a suggestion (a guide only, you decide)",
                color = when (sug?.kind) { "CALL" -> Up; "PUT" -> Down; else -> Muted })
        }
        Panel {
            Text("My trade", color = Muted, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Call", "Put").forEach { s -> FilterChip(side == s, { side = if (side == s) "" else s }, { Text(s) }) }
                Spacer(Modifier.width(8.dp))
                listOf("Yes", "No").forEach { r -> FilterChip(result == r, { result = if (result == r) "" else r }, { Text(r) }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(level, { level = it }, Modifier.weight(1f), label = { Text("Level (R1, S2…)") }, singleLine = true)
                OutlinedTextField(strike, { strike = it }, Modifier.weight(1f), label = { Text("Strike") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Spacer(Modifier.height(8.dp))
            Button({ onSave(Note(side, level, strike, result)) }) { Text("Save to sheet") }
        }
    }
}

@Composable
fun NotesTab(notes: Map<String, Note>) {
    val list = notes.entries.filter { it.value.side.isNotEmpty() || it.value.level.isNotEmpty() || it.value.strike.isNotEmpty() }
        .sortedByDescending { it.key }
    val yes = list.count { it.value.result.equals("Yes", true) }
    val no = list.count { it.value.result.equals("No", true) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("My trades", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Yes: $yes   No: $no   Total: ${list.size}", color = Muted, fontSize = 13.sp)
        }
        items(list) { e ->
            val n = e.value
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(e.key, fontWeight = FontWeight.Bold)
                    Text(n.result, color = if (n.result.equals("Yes", true)) Up else if (n.result.equals("No", true)) Down else Muted)
                }
                Text("${n.side} ${if (n.level.isNotEmpty()) "(${n.level})" else ""} strike ${n.strike}".trim(), color = Muted, fontSize = 13.sp)
            }
        }
    }
}
