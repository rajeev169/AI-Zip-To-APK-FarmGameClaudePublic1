package com.niftylevels

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.provider.MediaStore
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.concurrent.thread

private val Bg = Color(0xFF0F1419)
private val Card = Color(0xFF18202A)
private val Up = Color(0xFF3DDC97)
private val Down = Color(0xFFFF6B6B)
private val Accent = Color(0xFF6EA8FE)
private val Muted = Color(0xFF8A97A6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        UpdateWorker.schedule(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) {
                Surface(color = Bg, modifier = Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun Box2(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().background(Card, androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).padding(14.dp), content = content)

fun colorFor(name: String) = when {
    name.startsWith("R") -> Down
    name.startsWith("S") -> Up
    else -> Accent
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var candles by remember { mutableStateOf(Repo.loadCandles(ctx)) }
    var notes by remember { mutableStateOf(Repo.loadNotes(ctx)) }
    var openText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf<String?>(null) }

    val last = candles.last()
    val lv = levels(last.high, last.low, last.close)
    val session = nextTradingDay(last.date)
    val open = openText.toDoubleOrNull()
    val sug = open?.let { suggest(it, last) }

    var side by remember(session) { mutableStateOf(notes[session]?.side ?: "") }
    var level by remember(session) { mutableStateOf(notes[session]?.level ?: "") }
    var strike by remember(session) { mutableStateOf(notes[session]?.strike ?: "") }
    var result by remember(session) { mutableStateOf(notes[session]?.result ?: "") }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Nifty 50 Daily Levels", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Last data: ${last.date} · ${candles.size} days  $status", color = Muted, fontSize = 13.sp)
        }
        item {
            Box2 {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Levels for $session", color = Muted, fontSize = 14.sp)
                    TextButton(onClick = {
                        status = "updating…"
                        thread {
                            val msg = try { "added ${Repo.refresh(ctx)} day(s)" } catch (e: Exception) { "update failed" }
                            val fresh = Repo.loadCandles(ctx)
                            android.os.Handler(ctx.mainLooper).post { candles = fresh; status = msg }
                        }
                    }) { Text("Refresh") }
                }
                lv.asList().forEach { (k, v) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(k, color = colorFor(k)); Text("%,.2f".format(v), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Box2 {
                Text("Today's open", color = Muted, fontSize = 14.sp)
                OutlinedTextField(openText, { openText = it }, Modifier.fillMaxWidth(),
                    placeholder = { Text("e.g. 24142.10") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Spacer(Modifier.height(8.dp))
                Text(sug?.text ?: "Enter the open to get a suggestion (a guide only, you decide)",
                    color = when (sug?.kind) { "CALL" -> Up; "PUT" -> Down; else -> Muted })
            }
        }
        item {
            Box2 {
                Text("My trade note for $session", color = Muted, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Call", "Put").forEach { s -> FilterChip(side == s, { side = if (side == s) "" else s }, { Text(s) }) }
                    Spacer(Modifier.width(8.dp))
                    listOf("Yes", "No").forEach { r -> FilterChip(result == r, { result = if (result == r) "" else r }, { Text(r) }) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(level, { level = it }, Modifier.weight(1f), label = { Text("Level (R1, S2…)") }, singleLine = true)
                    OutlinedTextField(strike, { strike = it }, Modifier.weight(1f), label = { Text("Strike") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                Button({
                    notes = notes + (session to Note(side, level, strike, result)); Repo.saveNotes(ctx, notes); status = "saved"
                }) { Text("Save") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("History (tap a day)", color = Muted, fontSize = 14.sp)
                Button({
                    try {
                        val bytes = ExcelExport.build(ctx, candles, notes, open)
                        val cv = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, "Nifty_Levels_${java.time.LocalDate.now()}.xlsx")
                            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                        }
                        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
                        ctx.contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                        status = "Excel saved in Downloads"
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Open or share Excel"))
                    } catch (e: Exception) { status = "Export failed: ${e.message}" }
                }) { Text("Export Excel") }
            }
        }
        items(candles.reversed()) { c ->
            val n = notes[nextTradingDay(c.date)]
            Box2 {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == c.date) null else c.date },
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(c.date); Text("C %,.2f".format(c.close), color = Muted, fontSize = 13.sp)
                    Text(if (n != null && (n.side.isNotEmpty() || n.level.isNotEmpty()))
                        "${n.side} ${n.level} ${n.strike} ${n.result}".trim() else "",
                        color = if (n?.result == "Yes") Up else if (n?.result == "No") Down else Muted, fontSize = 13.sp)
                }
                if (expanded == c.date) {
                    val l = levels(c.high, c.low, c.close)
                    Spacer(Modifier.height(6.dp))
                    Text("High %,.2f / Low %,.2f (applies to ${nextTradingDay(c.date)})".format(c.high, c.low), color = Muted, fontSize = 12.sp)
                    l.asList().forEach { (k, v) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(k, color = colorFor(k), fontSize = 13.sp); Text("%,.2f".format(v), fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
