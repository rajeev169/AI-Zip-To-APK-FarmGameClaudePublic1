package com.niftylevels

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Scheduler.scheduleAll(this)
        LockState.locked = vm.settings.hasPin()
        setContent { AppRoot(vm) }
    }

    override fun onStop() {
        super.onStop()
        if (vm.settings.hasPin()) LockState.locked = true
    }
}

@Composable
fun AppRoot(vm: AppViewModel) {
    val dark = when (vm.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val scheme = if (dark)
        darkColorScheme(primary = Color(0xFF6EA8FE), background = Color(0xFF0F1419), surface = Color(0xFF18202A), onSurfaceVariant = Color(0xFF8A97A6))
    else
        lightColorScheme(primary = Color(0xFF1A5FD0), background = Color(0xFFF4F6F9), surface = Color(0xFFFFFFFF), onSurfaceVariant = Color(0xFF5B6773))
    CompositionLocalProvider(LocalDark provides dark) {
        MaterialTheme(colorScheme = scheme) {
            Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
                if (LockState.locked && vm.pinSet) PinLock(vm) else App(vm)
                if (!vm.disclaimerOk) {
                    AlertDialog(
                        onDismissRequest = { },
                        title = { Text("Educational tool") },
                        text = { Text("This app shows pivot / CPR levels and past statistics for learning. It is not investment advice or a recommendation to buy or sell. Trading in options involves a high risk of loss. Data comes from a free source and may be delayed or wrong.") },
                        confirmButton = { TextButton({ vm.acceptDisclaimer() }) { Text("I understand") } }
                    )
                }
            }
        }
    }
}

@Composable
fun PinLock(vm: AppViewModel) {
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Nifty Levels", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            pin, { if (it.length <= 6 && it.all { ch -> ch.isDigit() }) { pin = it; err = false } },
            label = { Text("Enter PIN") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
        )
        if (err) Text("Wrong PIN", color = cDown())
        Spacer(Modifier.height(12.dp))
        Button({ if (vm.settings.checkPin(pin)) { LockState.locked = false } else { err = true }; pin = "" }) { Text("Unlock") }
    }
}

@Composable
fun SymbolBar(vm: AppViewModel) {
    var menu by remember { mutableStateOf(false) }
    var add by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box {
            TextButton({ menu = true }) { Text("${vm.symbolName} ▾", fontWeight = FontWeight.Bold) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                vm.symbols.forEach { s ->
                    DropdownMenuItem(text = { Text(s.name) }, onClick = { menu = false; vm.switchSymbol(s.code) })
                }
                DropdownMenuItem(text = { Text("+ Add symbol…") }, onClick = { menu = false; add = true })
            }
        }
        Spacer(Modifier.weight(1f))
        if (vm.loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
        Spacer(Modifier.width(8.dp))
        Text(vm.status, color = cMuted(), fontSize = 11.sp, maxLines = 1)
    }
    if (add) {
        AlertDialog(
            onDismissRequest = { add = false },
            title = { Text("Add symbol") },
            text = {
                Column {
                    Text("Yahoo Finance code, for example RELIANCE.NS, TCS.NS or ^NSEBANK", fontSize = 12.sp, color = cMuted())
                    OutlinedTextField(code, { code = it }, singleLine = true)
                }
            },
            confirmButton = { TextButton({ if (code.isNotBlank()) vm.addSymbol(code); add = false; code = "" }) { Text("Add") } },
            dismissButton = { TextButton({ add = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun EmptyState(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        if (vm.loading) {
            CircularProgressIndicator()
            Spacer(Modifier.height(12.dp))
            Text("Downloading ${vm.symbolName} data…", color = cMuted())
        } else {
            Text("No data for ${vm.symbolName}", fontWeight = FontWeight.Bold)
            Text(vm.status, color = cMuted(), fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Button({ vm.refresh() }) { Text("Try again") }
        }
    }
}

@Composable
fun App(vm: AppViewModel) {
    var tab by remember { mutableStateOf(0) }
    val items = listOf("Sheet" to "▦", "Today" to "◎", "Chart" to "◢", "Stats" to "%", "More" to "☰")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        modifier = Modifier.statusBarsPadding(),
        bottomBar = {
            NavigationBar(containerColor = cCard()) {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(icon, fontSize = 18.sp) }, label = { Text(label, fontSize = 11.sp) })
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            SymbolBar(vm)
            if (vm.candles.isEmpty() && tab != 4) EmptyState(vm)
            else when (tab) {
                0 -> SheetScreen(vm)
                1 -> TodayScreen(vm)
                2 -> ChartScreen(vm)
                3 -> StatsScreen(vm)
                else -> MoreScreen(vm)
            }
        }
    }
}
