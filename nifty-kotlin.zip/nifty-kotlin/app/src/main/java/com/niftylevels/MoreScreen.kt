package com.niftylevels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MoreScreen(vm: AppViewModel) {
    val list = vm.notes.entries
        .filter { it.value.side.isNotEmpty() || it.value.level.isNotEmpty() || it.value.strike.isNotEmpty() }
        .sortedByDescending { it.key }
    val yes = list.count { it.value.result.equals("Yes", true) }
    val no = list.count { it.value.result.equals("No", true) }
    var newPin by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item {
            Panel {
                Text("Appearance", color = cMuted(), fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("System", "Light", "Dark").forEachIndexed { i, t ->
                        FilterChip(vm.theme == i, { vm.setTheme(i) }, { Text(t) })
                    }
                }
            }
        }
        item {
            Panel {
                Text("Rule distance", color = cMuted(), fontSize = 14.sp)
                Text("How close (points) the open must be to R1 or S1 to count as \"near\".", fontSize = 12.sp, color = cMuted())
                var t by remember { mutableStateOf(vm.near.toInt().toString()) }
                OutlinedTextField(t, { t = it; it.toDoubleOrNull()?.let { v -> if (v > 0) vm.setNear(v) } }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("Points") })
            }
        }
        item {
            Panel {
                Text("Alerts", color = cMuted(), fontSize = 14.sp)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Price alerts")
                        Text("While the market is open, notify when price touches R2, R1, Pivot, S1 or S2", fontSize = 11.sp, color = cMuted())
                    }
                    Switch(vm.alertsOn, { vm.setAlerts(it) })
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Morning plan (9:00 AM)")
                        Text("Today's R1, Pivot, S1 and CPR read", fontSize = 11.sp, color = cMuted())
                    }
                    Switch(vm.morningOn, { vm.setMorning(it) })
                }
                var t by remember { mutableStateOf(vm.alertPts.toInt().toString()) }
                OutlinedTextField(t, { t = it; it.toDoubleOrNull()?.let { v -> if (v > 0) vm.setAlertPts(v) } }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("Alert distance (points)") },
                    modifier = Modifier.padding(top = 8.dp))
                Text("Android checks about every 15 minutes and may delay alerts to save battery. Data is delayed.", fontSize = 11.sp, color = cMuted())
            }
        }
        item {
            Panel {
                Text("PIN lock", color = cMuted(), fontSize = 14.sp)
                if (vm.pinSet) {
                    Text("PIN is on. The app locks when you leave it.")
                    TextButton({ vm.setPin(null); LockState.locked = false }) { Text("Remove PIN") }
                } else {
                    OutlinedTextField(newPin, { if (it.length <= 6 && it.all { c -> c.isDigit() }) newPin = it }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), label = { Text("New PIN (4 to 6 digits)") })
                    Button({ if (newPin.length >= 4) { vm.setPin(newPin); newPin = "" } }, Modifier.padding(top = 8.dp)) { Text("Set PIN") }
                }
            }
        }
        item {
            Panel {
                Text("About", color = cMuted(), fontSize = 14.sp)
                Text("Educational tool. Not investment advice. Data from Yahoo Finance (free, unofficial) and may be delayed or inaccurate.", fontSize = 12.sp)
                Text("Add the \"Nifty Levels\" widget from your home screen's widget list.", fontSize = 12.sp, color = cMuted())
            }
        }
        item {
            Text("My trades", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Yes: $yes   No: $no   Total: ${list.size}", color = cMuted(), fontSize = 13.sp)
        }
        items(list) { e ->
            val n = e.value
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(e.key, fontWeight = FontWeight.Bold)
                    Text(n.result, color = if (n.result.equals("Yes", true)) cUp() else if (n.result.equals("No", true)) cDown() else cMuted())
                }
                Text("${n.side} ${if (n.level.isNotEmpty()) "(${n.level})" else ""} strike ${n.strike}".trim(), color = cMuted(), fontSize = 13.sp)
            }
        }
    }
}
