package com.niftylevels

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime

/** Storage and data download. Everything works on the symbol currently chosen in Settings. */
object Repo {
    private val IST = ZoneId.of("Asia/Kolkata")

    fun symbol(ctx: Context): String = Settings(ctx).symbol
    fun key(sym: String): String = sym.replace(Regex("[^A-Za-z0-9]"), "_")

    private fun candleFile(ctx: Context, sym: String): File =
        File(ctx.filesDir, if (sym == NIFTY) "history.json" else "hist_${key(sym)}.json")

    // ---- candles ----
    fun loadCandles(ctx: Context): List<Candle> {
        val sym = symbol(ctx)
        val f = candleFile(ctx, sym)
        val text = when {
            f.exists() -> f.readText()
            sym == NIFTY -> ctx.assets.open("history.json").bufferedReader().readText()
            else -> return emptyList()
        }
        val arr = JSONArray(text)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Candle(o.getString("date"), if (o.has("open")) o.getDouble("open") else null,
                o.getDouble("high"), o.getDouble("low"), o.getDouble("close"))
        }.sortedBy { it.date }
    }

    private fun saveCandles(ctx: Context, sym: String, list: List<Candle>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("date", it.date); it.open?.let { o -> put("open", o) }
                put("high", it.high); put("low", it.low); put("close", it.close)
            })
        }
        candleFile(ctx, sym).writeText(arr.toString())
    }

    private fun download(url: String): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        conn.connectTimeout = 20000; conn.readTimeout = 20000
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        return JSONObject(body).getJSONObject("chart").getJSONArray("result").getJSONObject(0)
    }

    /** Downloads recent candles, merges new days in, returns how many days were added. Call off the main thread. */
    fun refresh(ctx: Context): Int {
        val sym = symbol(ctx)
        val res = download("https://query1.finance.yahoo.com/v8/finance/chart/${URLEncoder.encode(sym, "UTF-8")}?range=2y&interval=1d")
        val off = res.getJSONObject("meta").optLong("gmtoffset", 19800L)
        val ts = res.getJSONArray("timestamp")
        val q = res.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
        val o = q.getJSONArray("open"); val h = q.getJSONArray("high")
        val l = q.getJSONArray("low"); val c = q.getJSONArray("close")

        val now = ZonedDateTime.now(IST)
        val map = loadCandles(ctx).associateBy { it.date }.toMutableMap()
        var added = 0
        for (i in 0 until ts.length()) {
            if (h.isNull(i) || l.isNull(i) || c.isNull(i)) continue
            val date = Instant.ofEpochSecond(ts.getLong(i) + off).atZone(ZoneOffset.UTC).toLocalDate().toString()
            // don't store today's candle until the market has closed
            if (date == now.toLocalDate().toString() && now.toLocalTime().isBefore(LocalTime.of(15, 45))) continue
            if (date !in map) added++
            map[date] = Candle(date, if (o.isNull(i)) null else o.getDouble(i), h.getDouble(i), l.getDouble(i), c.getDouble(i))
        }
        if (map.isEmpty()) throw IllegalStateException("No data for $sym")
        saveCandles(ctx, sym, map.values.sortedBy { it.date })
        return added
    }

    /** Latest traded price (for alerts). Call off the main thread. */
    fun livePrice(ctx: Context): Double {
        val sym = symbol(ctx)
        val res = download("https://query1.finance.yahoo.com/v8/finance/chart/${URLEncoder.encode(sym, "UTF-8")}?range=1d&interval=1m")
        return res.getJSONObject("meta").getDouble("regularMarketPrice")
    }

    // ---- your own Call/Put notes (kept on the phone, one set per symbol) ----
    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(if (symbol(ctx) == NIFTY) "notes" else "notes_${key(symbol(ctx))}", Context.MODE_PRIVATE)

    fun loadNotes(ctx: Context): Map<String, Note> {
        val s = prefs(ctx).getString("json", null)
        if (s == null) {
            if (symbol(ctx) != NIFTY) return emptyMap()
            val seed = mapOf( // first run: your 4 entries from the sheet
                "2026-04-16" to Note("Call", "R2", "24350", "No"),
                "2026-04-17" to Note("Call", "R1", "24300", "Yes"),
                "2026-05-08" to Note("Put", "S2", "24150", ""),
                "2026-07-10" to Note("", "R2", "24200", "")
            )
            saveNotes(ctx, seed); return seed
        }
        val o = JSONObject(s)
        return o.keys().asSequence().associateWith {
            val n = o.getJSONObject(it)
            Note(n.optString("side"), n.optString("level"), n.optString("strike"), n.optString("result"))
        }
    }

    fun saveNotes(ctx: Context, notes: Map<String, Note>) {
        val o = JSONObject()
        notes.forEach { (k, n) ->
            o.put(k, JSONObject().put("side", n.side).put("level", n.level).put("strike", n.strike).put("result", n.result))
        }
        prefs(ctx).edit().putString("json", o.toString()).apply()
    }

    // ---- today's open, remembered per symbol and session date ----
    fun loadOpen(ctx: Context, date: String): Double? =
        ctx.getSharedPreferences("opens", Context.MODE_PRIVATE).getString("${key(symbol(ctx))}|$date", null)?.toDoubleOrNull()

    fun saveOpen(ctx: Context, date: String, v: Double?) {
        val e = ctx.getSharedPreferences("opens", Context.MODE_PRIVATE).edit()
        val k = "${key(symbol(ctx))}|$date"
        if (v == null) e.remove(k) else e.putString(k, v.toString())
        e.apply()
    }
}
