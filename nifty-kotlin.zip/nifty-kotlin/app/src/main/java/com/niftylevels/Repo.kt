package com.niftylevels

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime

object Repo {
    private const val URL_NIFTY = "https://query1.finance.yahoo.com/v8/finance/chart/%5ENSEI?range=1y&interval=1d"
    private val IST = ZoneId.of("Asia/Kolkata")

    // ---- candles ----
    fun loadCandles(ctx: Context): List<Candle> {
        val f = File(ctx.filesDir, "history.json")
        val text = if (f.exists()) f.readText() else ctx.assets.open("history.json").bufferedReader().readText()
        val arr = JSONArray(text)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Candle(o.getString("date"), if (o.has("open")) o.getDouble("open") else null,
                o.getDouble("high"), o.getDouble("low"), o.getDouble("close"))
        }.sortedBy { it.date }
    }

    private fun saveCandles(ctx: Context, list: List<Candle>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("date", it.date); it.open?.let { o -> put("open", o) }
                put("high", it.high); put("low", it.low); put("close", it.close)
            })
        }
        File(ctx.filesDir, "history.json").writeText(arr.toString())
    }

    /** Downloads recent candles, merges new days in, returns how many days were added. Call off the main thread. */
    fun refresh(ctx: Context): Int {
        val conn = URL(URL_NIFTY).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        conn.connectTimeout = 20000; conn.readTimeout = 20000
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        val res = JSONObject(body).getJSONObject("chart").getJSONArray("result").getJSONObject(0)
        val off = res.getJSONObject("meta").optLong("gmtoffset", 19800L)
        val ts = res.getJSONArray("timestamp")
        val q = res.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
        val o = q.getJSONArray("open"); val h = q.getJSONArray("high")
        val l = q.getJSONArray("low"); val c = q.getJSONArray("close")

        val now = ZonedDateTime.now(IST)
        val map = loadCandles(ctx).associateBy { it.date }.toMutableMap()
        var added = 0
        for (i in 0 until ts.length()) {
            if (h.isNull(i) || l.isNull(i) || c.isNull(i)) continue
            val date = Instant.ofEpochSecond(ts.getLong(i) + off).atZone(ZoneOffset.UTC).toLocalDate().toString()
            // don't store today's candle until the market has closed
            if (date == now.toLocalDate().toString() && now.toLocalTime().isBefore(LocalTime.of(15, 45))) continue
            if (date !in map) added++
            map[date] = Candle(date, if (o.isNull(i)) null else o.getDouble(i), h.getDouble(i), l.getDouble(i), c.getDouble(i))
        }
        saveCandles(ctx, map.values.sortedBy { it.date })
        return added
    }

    // ---- your own Call/Put notes (kept on the phone) ----
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("notes", Context.MODE_PRIVATE)

    fun loadNotes(ctx: Context): Map<String, Note> {
        val s = prefs(ctx).getString("json", null)
        if (s == null) { // first run: your 4 entries from the sheet
            val seed = mapOf(
                "2026-04-16" to Note("Call", "R2", "24350", "No"),
                "2026-04-17" to Note("Call", "R1", "24300", "Yes"),
                "2026-05-08" to Note("Put", "S2", "24150", ""),
                "2026-07-10" to Note("", "R2", "24200", "")
            )
            saveNotes(ctx, seed); return seed
        }
        val o = JSONObject(s)
        return o.keys().asSequence().associateWith {
            val n = o.getJSONObject(it)
            Note(n.optString("side"), n.optString("level"), n.optString("strike"), n.optString("result"))
        }
    }

    fun saveNotes(ctx: Context, notes: Map<String, Note>) {
        val o = JSONObject()
        notes.forEach { (k, n) ->
            o.put(k, JSONObject().put("side", n.side).put("level", n.level).put("strike", n.strike).put("result", n.result))
        }
        prefs(ctx).edit().putString("json", o.toString()).apply()
    }
}
