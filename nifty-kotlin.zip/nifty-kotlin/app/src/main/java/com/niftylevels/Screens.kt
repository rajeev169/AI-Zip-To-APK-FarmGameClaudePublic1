package com.niftylevels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ColumnScope.SheetScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val open = vm.openText.toDoubleOrNull()
    val rows = remember(vm.candles, vm.notes, open) { buildRows(vm.candles, vm.notes, open) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Last data ${vm.candles.last().date}", color = cMuted(), fontSize = 11.sp, modifier = Modifier.weight(1f))
        Button({ vm.status = openInExcel(ctx) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Open in Excel", fontSize = 12.sp) }
        Spacer(Modifier.width(6.dp))
        FilledTonalButton({ vm.status = exportToDownloads(ctx) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Export", fontSize = 12.sp) }
    }
    SheetGrid(rows, Modifier.weight(1f))
}

@Composable
fun TodayScreen(vm: AppViewModel) {
    val last = vm.candles.last()
    val session = vm.session()
    val lv = levels(last.high, last.low, last.close)
    val open = vm.openText.toDoubleOrNull()
    val sug = open?.let { suggest(it, last, vm.near) }
    val cpr = remember(vm.candles, open) { cprInfo(vm.candles, open) }
    val note = vm.notes[session]
    var side by remember(session, vm.symbol) { mutableStateOf(note?.side ?: "") }
    var level by remember(session, vm.symbol) { mutableStateOf(note?.level ?: "") }
    var strike by remember(session, vm.symbol) { mutableStateOf(note?.strike ?: "") }
    var result by remember(session, vm.symbol) { mutableStateOf(note?.result ?: "") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Today · $session", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Panel {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Levels (from ${last.date} close)", color = cMuted(), fontSize = 14.sp)
                TextButton({ vm.refresh() }) { Text("Refresh") }
            }
            lv.asList().forEach { (k, v) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(k, color = levelColor(k)); Text(n2(v), fontWeight = FontWeight.Bold)
                }
            }
        }
        Panel {
            Text("Today's open", color = cMuted(), fontSize = 14.sp)
            OutlinedTextField(vm.openText, { vm.onOpenChange(it) }, Modifier.fillMaxWidth(), placeholder = { Text("e.g. 24142.10") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            Spacer(Modifier.height(8.dp))
            Text(sug?.text ?: "Enter the open to get a level-based indication (a guide only, you decide)",
                color = when (sug?.kind) { "CALL" -> cUp(); "PUT" -> cDown(); else -> cMuted() })
        }
        if (cpr != null) {
            Panel {
                Text("CPR read", color = cMuted(), fontSize = 14.sp)
                Text("Width %.2f (%.2f%% of price)".format(cpr.width, cpr.pctOfPrice))
                Text(cpr.kind)
                Text(cpr.trend)
                if (cpr.openPos.isNotEmpty()) Text(cpr.openPos, fontWeight = FontWeight.Bold)
            }
        }
        Panel {
            Text("My trade", color = cMuted(), fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Call", "Put").forEach { s -> FilterChip(side == s, { side = if (side == s) "" else s }, { Text(s) }) }
                Spacer(Modifier.width(8.dp))
                listOf("Yes", "No").forEach { r -> FilterChip(result == r, { result = if (result == r) "" else r }, { Text(r) }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(level, { level = it }, Modifier.weight(1f), label = { Text("Level (R1, S2…)") }, singleLine = true)
                OutlinedTextField(strike, { strike = it }, Modifier.weight(1f), label = { Text("Strike") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Spacer(Modifier.height(8.dp))
            Button({ vm.saveNote(Note(side, level, strike, result)) }) { Text("Save to sheet") }
        }
    }
}
