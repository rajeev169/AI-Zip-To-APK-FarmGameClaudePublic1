package com.niftylevels

import android.content.Context
import java.security.MessageDigest

data class Sym(val code: String, val name: String)

const val NIFTY = "^NSEI"
val PRESETS = listOf(Sym(NIFTY, "Nifty 50"), Sym("^NSEBANK", "Bank Nifty"), Sym("^BSESN", "Sensex"))

/** App preferences (theme, thresholds, alerts, PIN, chosen symbol). */
class Settings(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var near: Double
        get() = p.getFloat("near", 50f).toDouble()
        set(v) { p.edit().putFloat("near", v.toFloat()).apply() }
    var alertPts: Double
        get() = p.getFloat("alertPts", 10f).toDouble()
        set(v) { p.edit().putFloat("alertPts", v.toFloat()).apply() }
    var theme: Int // 0 system, 1 light, 2 dark
        get() = p.getInt("theme", 0)
        set(v) { p.edit().putInt("theme", v).apply() }
    var alertsOn: Boolean
        get() = p.getBoolean("alertsOn", false)
        set(v) { p.edit().putBoolean("alertsOn", v).apply() }
    var morningOn: Boolean
        get() = p.getBoolean("morningOn", false)
        set(v) { p.edit().putBoolean("morningOn", v).apply() }
    var disclaimerOk: Boolean
        get() = p.getBoolean("disclaimerOk", false)
        set(v) { p.edit().putBoolean("disclaimerOk", v).apply() }
    var symbol: String
        get() = p.getString("symbol", NIFTY) ?: NIFTY
        set(v) { p.edit().putString("symbol", v).apply() }

    fun customSymbols(): List<String> =
        (p.getString("custom", "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }

    fun addCustom(code: String) {
        val c = code.trim().uppercase()
        if (c.isEmpty() || PRESETS.any { it.code == c } || c in customSymbols()) return
        p.edit().putString("custom", (customSymbols() + c).joinToString(",")).apply()
    }

    fun allSymbols(): List<Sym> = PRESETS + customSymbols().map { Sym(it, it) }
    fun nameOf(code: String): String = allSymbols().firstOrNull { it.code == code }?.name ?: code

    fun hasPin(): Boolean = p.contains("pin")
    fun setPin(pin: String?) {
        if (pin == null) p.edit().remove("pin").apply() else p.edit().putString("pin", hash(pin)).apply()
    }
    fun checkPin(pin: String): Boolean = hash(pin) == p.getString("pin", "")

    companion object {
        fun hash(s: String): String =
            MessageDigest.getInstance("SHA-256").digest(("nifty:$s").toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
