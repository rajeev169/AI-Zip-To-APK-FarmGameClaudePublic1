package com.niftylevels

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

// Colours copied from your Excel
private val Yellow = Color(0xFFFFFF00)
private val Green = Color(0xFF00FF00)
private val Red = Color(0xFFE06666)
private val Cyan = Color(0xFF00FFFF)
private val LGreen = Color(0xFF93C47D)
private val Blue = Color(0xFF9FC5E8)
private val LYellow = Color(0xFFFFE599)
private val Gold = Color(0xFFFFD966)
private val Peach = Color(0xFFF9CB9C)
private val Pink = Color(0xFFEA9999)
private val Periwinkle = Color(0xFFA4C2F4)
private val White = Color.White

private val DATE_FMT = DateTimeFormatter.ofPattern("dMMMyy", Locale.ENGLISH)
private fun fd(s: String) = LocalDate.parse(s).format(DATE_FMT)
private fun dn(s: String) = LocalDate.parse(s).dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)
fun n2(v: Double): String = String.format(Locale.US, "%,.2f", v)

private class Col(val title: String, val w: Dp, val head: Color, val bg: (SheetRow) -> Color, val text: (SheetRow) -> String)
private class Group(val label: String, val from: Int, val to: Int, val color: Color)

private val DATE_W = 84.dp
private val ROW_H = 32.dp

private val cols: List<Col> = listOf(
    Col("Day", 52.dp, Yellow, { Yellow }, { dn(it.prevDate) }),
    Col("High", 92.dp, Green, { Green }, { n2(it.h) }),
    Col("Low", 92.dp, Green, { Green }, { n2(it.l) }),
    Col("Close", 92.dp, Green, { Green }, { n2(it.c) }),
    Col("BC", 92.dp, Red, { Red }, { n2(it.bc) }),
    Col("Pivot", 92.dp, Cyan, { Cyan }, { n2(it.p) }),
    Col("TC", 92.dp, LGreen, { LGreen }, { n2(it.tc) }),
    Col("Cur.Date", 84.dp, Blue, { Blue }, { fd(it.curDate) }),
    Col("Day", 52.dp, Blue, { Blue }, { dn(it.curDate) }),
    Col("Open", 92.dp, LYellow, { LYellow }, { it.op?.let(::n2) ?: "" }),
    Col("Open-PrevC", 92.dp, Gold, { Gold }, { it.diff?.let(::n2) ?: "" }),
    Col("Close", 92.dp, Peach, { Peach }, { it.cl?.let(::n2) ?: "" }),
    Col("R3", 92.dp, LGreen, { LGreen }, { n2(it.r3) }),
    Col("R2", 92.dp, LGreen, { LGreen }, { n2(it.r2) }),
    Col("R1", 92.dp, LGreen, { LGreen }, { n2(it.r1) }),
    // Today's open: green if above yesterday's close, red if below (your sheet's colouring)
    Col("TodayOpen", 92.dp, Red, { r -> if (r.op != null && r.op > r.c) LGreen else if (r.op != null) Red else LGreen }, { it.op?.let(::n2) ?: "" }),
    Col("S1", 92.dp, Pink, { Pink }, { n2(it.s1) }),
    Col("S2", 92.dp, Pink, { Pink }, { n2(it.s2) }),
    Col("S3", 92.dp, Pink, { Pink }, { n2(it.s3) }),
    Col("Strike", 80.dp, Periwinkle, { White }, { it.note?.strike ?: "" }),
    Col("Call/Put", 92.dp, Periwinkle, { White }, { r -> r.note?.let { n -> if (n.side.isNotEmpty()) n.side + (if (n.level.isNotEmpty()) "(${n.level})" else "") else n.level } ?: "" }),
    Col("Result", 72.dp, Periwinkle, { White }, { it.note?.result ?: "" })
)

private val groups = listOf(
    Group("Previous day Data", 0, 3, Yellow),
    Group("Data used for trading", 4, 6, Yellow),
    Group("Current day", 7, 8, Yellow),
    Group("Current day Data", 9, 11, LYellow),
    Group("Call side prediction", 12, 14, LGreen),
    Group("Today", 15, 15, Cyan),
    Group("Put side prediction", 16, 18, Pink),
    Group("Prediction", 19, 21, Periwinkle)
)

@Composable
private fun Cell(text: String, w: Dp, bg: Color, bold: Boolean = false, center: Boolean = false) {
    Box(
        Modifier.width(w).height(ROW_H).background(bg).border(0.5.dp, Color(0xFF555555)),
        contentAlignment = if (center) Alignment.Center else Alignment.CenterEnd
    ) {
        Text(
            text, color = Color.Black, fontSize = 12.sp, maxLines = 1,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 6.dp)
        )
    }
}

private val Orange = Color(0xFFFF7A00)

/** Your Excel sheet inside the app. The Date column stays fixed; everything else scrolls sideways together.
 *  Today's row is pinned under the header so it is always visible. */
@Composable
fun SheetGrid(rows: List<SheetRow>, modifier: Modifier = Modifier) {
    val hs = rememberScrollState()
    val ls = rememberLazyListState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(rows.size) { if (rows.isNotEmpty()) ls.scrollToItem(rows.lastIndex) }
    val todayHidden by remember(rows.size) {
        derivedStateOf { rows.isNotEmpty() && ls.layoutInfo.visibleItemsInfo.none { it.index == rows.lastIndex } }
    }
    Box(modifier.background(White)) {
        Column(Modifier.fillMaxSize()) {
            // group header row
            Row {
                Cell("Previous day", DATE_W, Yellow, bold = true, center = true)
                Row(Modifier.weight(1f).horizontalScroll(hs)) {
                    groups.forEach { g ->
                        val w = cols.subList(g.from, g.to + 1).fold(0.dp) { acc, c -> acc + c.w }
                        Cell(g.label, w, g.color, bold = true, center = true)
                    }
                }
            }
            // column header row
            Row {
                Cell("Date", DATE_W, Yellow, bold = true, center = true)
                Row(Modifier.weight(1f).horizontalScroll(hs)) {
                    cols.forEach { c -> Cell(c.title, c.w, c.head, bold = true, center = true) }
                }
            }
            // pinned TODAY row (always visible)
            if (rows.isNotEmpty()) {
                val t = rows.last()
                Box(Modifier.fillMaxWidth().background(Orange).padding(horizontal = 8.dp, vertical = 2.dp)) {
                    Text("▼ TODAY · session ${fd(t.curDate)} · uses ${fd(t.prevDate)} data", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                }
                Row {
                    Cell(fd(t.prevDate), DATE_W, Yellow, bold = true)
                    Row(Modifier.weight(1f).horizontalScroll(hs)) {
                        cols.forEach { c -> Cell(c.text(t), c.w, c.bg(t), bold = true) }
                    }
                }
                Box(Modifier.fillMaxWidth().height(3.dp).background(Orange))
            }
            LazyColumn(Modifier.fillMaxSize(), state = ls) {
                items(rows) { r ->
                    Row {
                        Cell(fd(r.prevDate), DATE_W, Yellow)
                        Row(Modifier.weight(1f).horizontalScroll(hs)) {
                            cols.forEach { c -> Cell(c.text(r), c.w, c.bg(r)) }
                        }
                    }
                }
            }
        }
        if (todayHidden) {
            Button(
                onClick = { scope.launch { ls.animateScrollToItem(rows.lastIndex) } },
                colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.White),
                modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp)
            ) { Text("↓ Jump to today", fontWeight = FontWeight.ExtraBold) }
        }
    }
}
