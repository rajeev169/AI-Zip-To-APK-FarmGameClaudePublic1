package com.niftylevels

/** One row of your sheet: previous-day data on the left, current-day data on the right. */
data class SheetRow(
    val prevDate: String, val h: Double, val l: Double, val c: Double,
    val bc: Double, val p: Double, val tc: Double,
    val curDate: String, val op: Double?, val diff: Double?, val cl: Double?,
    val r3: Double, val r2: Double, val r1: Double,
    val s1: Double, val s2: Double, val s3: Double,
    val note: Note?
)

/** Same formulas as your Excel. Row i uses candle i as "previous day" and candle i+1 as "current day". */
fun buildRows(candles: List<Candle>, notes: Map<String, Note>, todayOpen: Double?): List<SheetRow> =
    candles.mapIndexed { i, p ->
        val cur = candles.getOrNull(i + 1)
        val cd = cur?.date ?: nextTradingDay(p.date)
        val lv = levels(p.high, p.low, p.close)
        val op: Double? = if (cur != null) cur.open else todayOpen
        SheetRow(
            p.date, p.high, p.low, p.close, lv.bc, lv.p, lv.tc,
            cd, op, if (op != null && i > 0) op - p.close else null, cur?.close,
            lv.r3, lv.r2, lv.r1, lv.s1, lv.s2, lv.s3, notes[cd]
        )
    }
