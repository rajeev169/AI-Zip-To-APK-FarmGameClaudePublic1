package com.niftylevels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun StatsScreen(vm: AppViewModel) {
    val bt = remember(vm.candles, vm.near) { backtest(vm.candles, vm.near) }
    val sens = remember(vm.candles) { listOf(20.0, 30.0, 50.0, 70.0, 100.0).map { it to backtest(vm.candles, it) } }
    val ns = remember(vm.candles, vm.notes) { noteStats(vm.candles, vm.notes) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Stats", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Panel {
            Text("Backtest of your rule", color = cMuted(), fontSize = 14.sp)
            Text("Green open near R1 gives a Call (strike at R1), red open near S1 gives a Put (strike at S2). A Call wins if the day closes above the strike, a Put if it closes below.", fontSize = 12.sp, color = cMuted())
            Spacer(Modifier.height(8.dp))
            Text("Near = ${vm.near.toInt()} pts · ${vm.candles.size} days of data", fontSize = 12.sp, color = cMuted())
            if (bt.n == 0) Text("No matching days yet.") else {
                Text("%d signals · %d wins · %.0f%% win rate".format(bt.n, bt.wins, bt.pct()), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Call: %d signals, %.0f%% win".format(bt.count("Call"), bt.pct("Call")))
                Text("Put: %d signals, %.0f%% win".format(bt.count("Put"), bt.pct("Put")))
            }
        }
        Panel {
            Text("How the \"near\" distance changes the result", color = cMuted(), fontSize = 14.sp)
            sens.forEach { (d, r) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${d.toInt()} pts")
                    Text(if (r.n == 0) "no signals" else "%d signals · %.0f%% win".format(r.n, r.pct()))
                }
            }
        }
        Panel {
            Text("Your logged trades", color = cMuted(), fontSize = 14.sp)
            if (ns.isEmpty()) Text("Log trades with a Yes/No result on the Today tab to see win rates here.", fontSize = 13.sp)
            ns.forEach { s ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.label)
                    Text("%d/%d · %.0f%%".format(s.wins, s.n, s.pct), fontWeight = FontWeight.Bold)
                }
            }
        }
        Text("Past results do not predict future results. Small samples can mislead. For learning only, not investment advice.", color = cMuted(), fontSize = 11.sp)
    }
}
