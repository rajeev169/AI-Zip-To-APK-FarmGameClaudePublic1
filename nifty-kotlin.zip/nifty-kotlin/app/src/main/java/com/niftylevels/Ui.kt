package com.niftylevels

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider

const val XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

val LocalDark = staticCompositionLocalOf { true }

/** True while the PIN lock screen should be shown. */
object LockState { var locked by mutableStateOf(false) }

@Composable fun cUp(): Color = if (LocalDark.current) Color(0xFF3DDC97) else Color(0xFF0E9F66)
@Composable fun cDown(): Color = if (LocalDark.current) Color(0xFFFF6B6B) else Color(0xFFD93A3A)
@Composable fun cAccent(): Color = MaterialTheme.colorScheme.primary
@Composable fun cMuted(): Color = MaterialTheme.colorScheme.onSurfaceVariant
@Composable fun cCard(): Color = MaterialTheme.colorScheme.surface

@Composable
fun levelColor(name: String): Color = when {
    name.startsWith("R") -> cDown()
    name.startsWith("S") -> cUp()
    else -> cAccent()
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) =
    Column(
        Modifier.fillMaxWidth().background(cCard(), RoundedCornerShape(12.dp)).padding(14.dp),
        content = content
    )

/** Opens the app's own xlsx in Excel / Sheets. Returns an error message or "". */
fun openInExcel(ctx: Context): String {
    return try {
        val f = ExcelExport.writeFile(ctx)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, XLSX)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Open Excel file"))
        ""
    } catch (e: ActivityNotFoundException) {
        "Install Excel or Google Sheets to open the file"
    } catch (e: Exception) {
        "Could not open: ${e.message}"
    }
}

/** Saves a dated copy into Downloads and opens the share sheet. */
fun exportToDownloads(ctx: Context): String {
    return try {
        val bytes = ExcelExport.writeFile(ctx).readBytes()
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "${Repo.key(Repo.symbol(ctx))}_Levels_${java.time.LocalDate.now()}.xlsx")
            put(MediaStore.Downloads.MIME_TYPE, XLSX)
        }
        val uri: Uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        ctx.contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = XLSX
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Share Excel"))
        "Saved in Downloads"
    } catch (e: Exception) {
        "Export failed: ${e.message}"
    }
}
