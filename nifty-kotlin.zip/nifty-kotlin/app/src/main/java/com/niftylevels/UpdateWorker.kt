package com.niftylevels

import android.content.Context
import androidx.work.*
import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

private val IST: ZoneId = ZoneId.of("Asia/Kolkata")

/** Runs once a day after market close, fetches the new day and notifies you. */
class UpdateWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            val added = Repo.refresh(ctx)
            if (added > 0) {
                try { ExcelExport.writeFile(ctx) } catch (e: Exception) { }
                try { LevelsWidget.refresh(ctx) } catch (e: Exception) { }
                val last = Repo.loadCandles(ctx).last()
                val l = levels(last.high, last.low, last.close)
                Notifier.show(ctx, 1, "${Settings(ctx).nameOf(Repo.symbol(ctx))} levels ready for ${nextTradingDay(last.date)}",
                    "R1 %.0f  Pivot %.0f  S1 %.0f".format(l.r1, l.p, l.s1))
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

/** While the market is open, checks the live price and alerts when it touches R2, R1, Pivot, S1 or S2. */
class AlertWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val s = Settings(ctx)
        if (!s.alertsOn) return Result.success()
        val now = ZonedDateTime.now(IST)
        if (now.dayOfWeek == DayOfWeek.SATURDAY || now.dayOfWeek == DayOfWeek.SUNDAY) return Result.success()
        if (now.toLocalTime().isBefore(LocalTime.of(9, 15)) || now.toLocalTime().isAfter(LocalTime.of(15, 30))) return Result.success()
        return try {
            val candles = Repo.loadCandles(ctx)
            if (candles.isEmpty()) return Result.success()
            val last = candles.last()
            val lv = levels(last.high, last.low, last.close)
            val price = Repo.livePrice(ctx)
            val sp = ctx.getSharedPreferences("alerts", Context.MODE_PRIVATE)
            val today = now.toLocalDate().toString()
            val sent = (sp.getStringSet("sent", emptySet()) ?: emptySet()).filter { it.startsWith(today) }.toMutableSet()
            val sym = Repo.symbol(ctx)
            val targets = listOf("R2" to lv.r2, "R1" to lv.r1, "Pivot" to lv.p, "S1" to lv.s1, "S2" to lv.s2)
            for ((name, v) in targets) {
                val k = "$today|$sym|$name"
                if (Math.abs(price - v) <= s.alertPts && k !in sent) {
                    Notifier.show(ctx, 100 + name.hashCode() % 50, "${s.nameOf(sym)} at $name",
                        "Price %.2f is within %.0f pts of %s %.2f".format(price, s.alertPts, name, v))
                    sent.add(k)
                }
            }
            sp.edit().putStringSet("sent", sent).apply()
            Result.success()
        } catch (e: Exception) {
            Result.success()
        }
    }
}

/** Around 9:00 AM IST on weekdays: today's levels and CPR read. */
class MorningWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val s = Settings(ctx)
        if (!s.morningOn) return Result.success()
        val now = ZonedDateTime.now(IST)
        if (now.dayOfWeek == DayOfWeek.SATURDAY || now.dayOfWeek == DayOfWeek.SUNDAY) return Result.success()
        val candles = Repo.loadCandles(ctx)
        if (candles.isEmpty()) return Result.success()
        val last = candles.last()
        val lv = levels(last.high, last.low, last.close)
        val cpr = cprInfo(candles, null)
        Notifier.show(ctx, 2, "${s.nameOf(Repo.symbol(ctx))} plan for today",
            "R1 %.0f  Pivot %.0f  S1 %.0f\n%s".format(lv.r1, lv.p, lv.s1, cpr?.kind ?: ""))
        return Result.success()
    }
}

object Scheduler {
    private fun delayTo(hour: Int, minute: Int): Long {
        val now = ZonedDateTime.now(IST)
        var next = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return Duration.between(now, next).toMinutes()
    }

    /** Safe to call on every app start; existing schedules are kept. */
    fun scheduleAll(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        wm.enqueueUniquePeriodicWork("daily", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<UpdateWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(delayTo(16, 45), TimeUnit.MINUTES).setConstraints(net).build())
        wm.enqueueUniquePeriodicWork("morning", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<MorningWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(delayTo(9, 0), TimeUnit.MINUTES).build())
        wm.enqueueUniquePeriodicWork("alerts", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<AlertWorker>(15, TimeUnit.MINUTES).setConstraints(net).build())
    }
}
