package com.niftylevels

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.work.*
import java.time.DayOfWeek
import java.time.Duration
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

/** Runs once a day after market close, fetches the new day and notifies you. */
class UpdateWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            val added = Repo.refresh(ctx)
            if (added > 0) { try { ExcelExport.writeFile(ctx) } catch (e: Exception) { }; notifyNew() }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun notifyNew() {
        val last = Repo.loadCandles(ctx).last()
        val l = levels(last.high, last.low, last.close)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("levels", "Daily levels", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, "levels")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Nifty levels ready for ${nextTradingDay(last.date)}")
            .setContentText("R1 %.0f  Pivot %.0f  S1 %.0f".format(l.r1, l.p, l.s1))
            .setContentIntent(pi).setAutoCancel(true).build()
        nm.notify(1, n)
    }

    companion object {
        /** Schedules a daily run at ~4:45 PM IST. Safe to call on every app start. */
        fun schedule(ctx: Context) {
            val ist = ZoneId.of("Asia/Kolkata")
            val now = ZonedDateTime.now(ist)
            var next = now.withHour(16).withMinute(45).withSecond(0).withNano(0)
            if (!next.isAfter(now)) next = next.plusDays(1)
            while (next.dayOfWeek == DayOfWeek.SATURDAY || next.dayOfWeek == DayOfWeek.SUNDAY) next = next.plusDays(1)
            val delay = Duration.between(now, next).toMinutes()
            val req = PeriodicWorkRequestBuilder<UpdateWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(delay, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("daily", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
