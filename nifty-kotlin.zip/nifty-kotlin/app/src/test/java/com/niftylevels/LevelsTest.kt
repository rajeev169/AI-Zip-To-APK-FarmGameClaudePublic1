package com.niftylevels

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LevelsTest {
    @Test
    fun levelsMatchYourSheetRow4() {
        // 30 Mar 2026 row of your Excel: High 22714.1, Low 22283.85, Close 22331.4
        val l = levels(22714.1, 22283.85, 22331.4)
        assertEquals(22443.11667, l.p, 0.001)
        assertEquals(22498.975, l.bc, 0.001)
        assertEquals(22387.25833, l.tc, 0.001)
        assertEquals(23032.63333, l.r3, 0.001)
        assertEquals(22873.36667, l.r2, 0.001)
        assertEquals(22602.38333, l.r1, 0.001)
        assertEquals(22172.13333, l.s1, 0.001)
        assertEquals(22012.86667, l.s2, 0.001)
        assertEquals(21741.88333, l.s3, 0.001)
    }

    @Test
    fun nextTradingDaySkipsWeekend() {
        assertEquals("2026-11-02", nextTradingDay("2026-10-30")) // Friday -> Monday
        assertEquals("2026-10-30", nextTradingDay("2026-10-29")) // Thursday -> Friday
    }

    private val last = Candle("2026-07-15", null, 24220.35, 24010.55, 24078.5)

    @Test
    fun greenOpenNearR1GivesCall() {
        assertEquals("CALL", suggest(24200.0, last, 50.0).kind)
    }

    @Test
    fun redOpenNearS1GivesPut() {
        assertEquals("PUT", suggest(23990.0, last, 50.0).kind)
    }

    @Test
    fun farFromLevelsGivesNoTrade() {
        assertEquals("NONE", suggest(24100.0, last, 20.0).kind)
    }

    @Test
    fun backtestCountsWinsAndLosses() {
        // Previous day: High 110, Low 90, Close 100 -> Pivot 100, R1 110
        val prev = Candle("d1", null, 110.0, 90.0, 100.0)
        val win = backtest(listOf(prev, Candle("d2", 108.0, 125.0, 105.0, 120.0)), 50.0)
        assertEquals(1, win.n); assertTrue(win.rows[0].win)
        val loss = backtest(listOf(prev, Candle("d2", 108.0, 125.0, 105.0, 109.0)), 50.0)
        assertEquals(1, loss.n); assertTrue(!loss.rows[0].win)
    }

    @Test
    fun noteStatsGroupsByOpenColour() {
        val candles = listOf(Candle("d1", null, 110.0, 90.0, 100.0), Candle("d2", 108.0, 125.0, 105.0, 120.0))
        val s = noteStats(candles, mapOf("d2" to Note("Call", "R1", "110", "Yes")))
        assertTrue(s.any { it.label == "Green open" && it.wins == 1 })
        assertTrue(s.any { it.label == "Call" && it.n == 1 })
    }
}
