# Pulse Music 2.1

Material 3 Expressive music player for Android (Kotlin, Jetpack Compose, Media3).

## What's new in 2.1

- "Share to Pulse": share a call recording from Google's Phone app (Recents → recorded call →
  Share → Pulse) and Pulse saves a copy into `Recordings/Call` so it appears under Calls.
- Clearer empty Recordings screen: says when the other filter has recordings, and explains
  how to bring recordings from Google's Phone app.

## What's new in 2.0

- Background playback with Media3 (ExoPlayer + MediaSessionService): notification, lock-screen,
  headset/Bluetooth buttons and Android Auto controls.
- Pauses for phone calls and other apps (audio focus) and when headphones are unplugged.
- "Open with Pulse" plays the audio file you opened.
- Settings are saved (DataStore). Light theme is the default; Dark and "Follow phone" are in Settings.
- Real shuffle (no repeats until every song has played), crossfade (fade out / fade in), gapless playback.
- Recordings section in Library: call recordings and voice notes from shared storage, grouped by day.
- Short-audio filter now applies only to songs; recordings are always listed.
- Recently played / Most played use real play history.
- Material 3 Expressive look: wavy seek bar, shape-morphing play button, floating mini player,
  bigger rounded controls, predictive back support.
- Removed: generated demo tracks, unused Firebase / Gemini / Retrofit / OkHttp / Moshi code.

## Build

```
./gradlew assembleDebug          # debug APK -> app/build/outputs/apk/debug/
./gradlew bundleRelease          # release AAB (needs a keystore, see below)
```

Release signing is used only when a keystore exists. Set these environment variables
(for example as CI secrets): `KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Without them the release build is produced unsigned so your pipeline can sign it.

Requirements: JDK 17+ and Android SDK platform 36.1 (compileSdk 36.1, minSdk 24, targetSdk 36).

## Notes

- Call recordings appear only if your phone's dialer saves them to shared storage
  (e.g. `Recordings/Call`, `MIUI/sound_recorder/call_rec`). Some dialers keep recordings in
  private storage that no other app can read.
- The visualizer on the Now Playing screen is decorative; it is not driven by the audio signal.
