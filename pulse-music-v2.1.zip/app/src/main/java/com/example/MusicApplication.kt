package com.example

import android.app.Application
import com.example.audio.AudioPlayerManager
import com.example.data.SettingsStore
import com.example.data.local.MusicDatabase
import com.example.data.repository.MusicRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class MusicApplication : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database by lazy { MusicDatabase.getDatabase(this, applicationScope) }
    val repository by lazy { MusicRepository(this, database.musicDao()) }
    val settingsStore by lazy { SettingsStore(this) }
    val playerManager by lazy { AudioPlayerManager(this) }
}
