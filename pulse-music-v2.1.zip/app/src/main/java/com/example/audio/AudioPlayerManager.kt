package com.example.audio

import android.content.ComponentName
import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.CountDownTimer
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.model.LyricsLine
import com.example.model.PlaybackState
import com.example.model.RepeatMode
import com.example.model.Song
import com.example.playback.PlaybackService
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.sin
import kotlin.random.Random

/**
 * Owns the single ExoPlayer used by the whole app.
 *
 * The same player instance is wrapped in a MediaSession by [PlaybackService], which gives
 * background playback, the media notification, lock-screen and headset/Bluetooth controls.
 * Audio focus (pausing for calls and other apps) and "becoming noisy" (pausing when
 * headphones are unplugged) are handled by ExoPlayer itself.
 */
@OptIn(UnstableApi::class)
class AudioPlayerManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    val player: ExoPlayer = ExoPlayer.Builder(context)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .setUsage(C.USAGE_MEDIA)
                .build(),
            /* handleAudioFocus = */ true
        )
        .setHandleAudioBecomingNoisy(true)
        .setWakeMode(C.WAKE_MODE_LOCAL)
        .build()

    private var controllerFuture: ListenableFuture<MediaController>? = null

    // Audio Effects
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null

    // State flows
    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _playbackState = MutableStateFlow(PlaybackState.IDLE)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.ALL)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    /** Queue in playlist order (the order songs were added), like the player's timeline. */
    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    val queue: StateFlow<List<Song>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(-1)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    // Decorative visualizer bands (24 bands). Not driven by the audio signal.
    private val _visualizerBands = MutableStateFlow(List(24) { 0.1f })
    val visualizerBands: StateFlow<List<Float>> = _visualizerBands.asStateFlow()

    // Sleep Timer
    private val _sleepTimerRemainingMs = MutableStateFlow(0L)
    val sleepTimerRemainingMs: StateFlow<Long> = _sleepTimerRemainingMs.asStateFlow()
    private var sleepCountDown: CountDownTimer? = null
    private var sleepFadeActive = false

    // Equalizer State
    private val _eqEnabled = MutableStateFlow(true)
    val eqEnabled: StateFlow<Boolean> = _eqEnabled.asStateFlow()

    private val _eqBands = MutableStateFlow(listOf(0, 0, 0, 0, 0)) // 5 bands (-10 to +10)
    val eqBands: StateFlow<List<Int>> = _eqBands.asStateFlow()

    private val _bassBoostLevel = MutableStateFlow(0) // 0 to 100
    val bassBoostLevel: StateFlow<Int> = _bassBoostLevel.asStateFlow()

    private val _virtualizerLevel = MutableStateFlow(0) // 0 to 100
    val virtualizerLevel: StateFlow<Int> = _virtualizerLevel.asStateFlow()

    // Lyrics
    private val _parsedLyrics = MutableStateFlow<List<LyricsLine>>(emptyList())
    val parsedLyrics: StateFlow<List<LyricsLine>> = _parsedLyrics.asStateFlow()

    private val _currentLyricIndex = MutableStateFlow(-1)
    val currentLyricIndex: StateFlow<Int> = _currentLyricIndex.asStateFlow()

    // Crossfade (fade out the end of a song, fade in the next one)
    private var crossfadeEnabled = false
    private var crossfadeMs = 3000L
    private var fadeInJob: Job? = null

    private var progressJob: Job? = null
    private var visualizerJob: Job? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = syncPlaybackState()

        override fun onPlaybackStateChanged(playbackState: Int) {
            syncPlaybackState()
            if (playbackState == Player.STATE_READY) {
                _duration.value = player.duration.coerceAtLeast(0L)
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            syncCurrentItem()
            if (crossfadeEnabled && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                startFadeIn()
            } else if (!sleepFadeActive) {
                player.volume = 1f
            }
        }

        override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
            syncCurrentItem()
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _isShuffle.value = shuffleModeEnabled
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _repeatMode.value = when (repeatMode) {
                Player.REPEAT_MODE_ONE -> RepeatMode.ONE
                Player.REPEAT_MODE_ALL -> RepeatMode.ALL
                else -> RepeatMode.OFF
            }
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            initAudioEffects(audioSessionId)
        }

        override fun onPlayerError(error: PlaybackException) {
            Log.e("AudioPlayerManager", "Playback error", error)
            _playbackState.value = PlaybackState.PAUSED
            // Skip a broken file instead of getting stuck on it.
            if (player.hasNextMediaItem()) {
                player.seekToNextMediaItem()
                player.prepare()
                player.play()
            }
        }
    }

    init {
        player.addListener(listener)
        player.repeatMode = Player.REPEAT_MODE_ALL
        // ExoPlayer already has an audio session; attach the equalizer to it now.
        initAudioEffects(player.audioSessionId)
        startProgressTracking()
        startVisualizerLoop()
    }

    /** Binds to [PlaybackService] so it can run in the foreground with the media notification. */
    private fun ensureServiceConnected() {
        if (controllerFuture != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(context, token).buildAsync()
    }

    private fun Song.toMediaItem(): MediaItem {
        val uri = when {
            uri.startsWith("content://") || uri.startsWith("file://") -> Uri.parse(uri)
            else -> Uri.fromFile(java.io.File(uri))
        }
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .apply { albumArtUri?.let { setArtworkUri(Uri.parse(it)) } }
            .setIsPlayable(true)
            .setIsBrowsable(false)
            .build()
        return MediaItem.Builder()
            .setMediaId(id)
            .setUri(uri)
            .setMediaMetadata(metadata)
            .build()
    }

    private fun syncPlaybackState() {
        _playbackState.value = when {
            player.isPlaying -> PlaybackState.PLAYING
            player.playbackState == Player.STATE_BUFFERING && player.playWhenReady -> PlaybackState.BUFFERING
            player.playbackState == Player.STATE_IDLE && player.mediaItemCount == 0 -> PlaybackState.IDLE
            else -> PlaybackState.PAUSED
        }
    }

    private fun syncCurrentItem() {
        val index = player.currentMediaItemIndex
        val q = _queue.value
        if (player.mediaItemCount == 0 || index !in q.indices) {
            _currentIndex.value = -1
            if (player.mediaItemCount == 0) _currentSong.value = null
            return
        }
        _currentIndex.value = index
        val song = q[index]
        if (_currentSong.value?.id != song.id) {
            _currentSong.value = song
            _currentPosition.value = 0L
            _duration.value = song.durationMs
            parseLyrics(song.lyrics)
        }
    }

    fun setQueue(songs: List<Song>, startIndex: Int = 0, startPlaying: Boolean = true) {
        if (songs.isEmpty()) return
        val validIndex = startIndex.coerceIn(0, songs.size - 1)
        _queue.value = songs
        player.setMediaItems(songs.map { it.toMediaItem() }, validIndex, 0L)
        player.prepare()
        syncCurrentItem()
        if (startPlaying) {
            ensureServiceConnected()
            player.volume = 1f
            player.play()
        }
    }

    fun playSong(song: Song) {
        val index = _queue.value.indexOfFirst { it.id == song.id }
        if (index >= 0) {
            playQueueItem(index)
        } else {
            setQueue(listOf(song), 0, true)
        }
    }

    fun togglePlayPause() {
        if (player.mediaItemCount == 0) return
        if (player.isPlaying) {
            player.pause()
        } else {
            ensureServiceConnected()
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(player.currentMediaItemIndex, 0L)
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            if (!sleepFadeActive) player.volume = 1f
            player.play()
        }
    }

    fun pause() = player.pause()

    fun resume() {
        if (player.mediaItemCount == 0) return
        ensureServiceConnected()
        player.play()
    }

    fun seekTo(positionMs: Long) {
        player.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    fun playNext() {
        if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem()
            player.volume = 1f
        }
    }

    fun playPrevious() {
        // Restarts the song if more than ~3 s have played, otherwise goes to the previous one.
        player.seekToPrevious()
        player.volume = 1f
    }

    fun toggleRepeatMode() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    /** Real shuffle: every song plays once in a random order before any repeats. */
    fun toggleShuffle() {
        player.shuffleModeEnabled = !player.shuffleModeEnabled
    }

    fun setShuffle(enabled: Boolean) {
        player.shuffleModeEnabled = enabled
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        player.setPlaybackSpeed(speed)
    }

    fun setCrossfade(enabled: Boolean, seconds: Int) {
        crossfadeEnabled = enabled
        crossfadeMs = seconds.coerceIn(1, 12) * 1000L
        if (!enabled && !sleepFadeActive) player.volume = 1f
    }

    private fun startFadeIn() {
        fadeInJob?.cancel()
        fadeInJob = scope.launch {
            val steps = 20
            for (i in 1..steps) {
                if (!sleepFadeActive) player.volume = i / steps.toFloat()
                delay(crossfadeMs / steps)
            }
        }
    }

    // Equalizer & FX
    private fun initAudioEffects(audioSessionId: Int) {
        if (audioSessionId == C.AUDIO_SESSION_ID_UNSET) return
        try {
            releaseAudioEffects()
            equalizer = Equalizer(0, audioSessionId).apply { enabled = _eqEnabled.value }
            bassBoost = BassBoost(0, audioSessionId).apply {
                enabled = _eqEnabled.value
                if (strengthSupported) setStrength((_bassBoostLevel.value * 10).toShort())
            }
            virtualizer = Virtualizer(0, audioSessionId).apply {
                enabled = _eqEnabled.value
                if (strengthSupported) setStrength((_virtualizerLevel.value * 10).toShort())
            }
            applyEqualizerBands(_eqBands.value)
        } catch (e: Exception) {
            Log.w("AudioPlayerManager", "Audio effects not available on this device", e)
        }
    }

    fun setEqualizerBand(bandIndex: Int, level: Int) {
        val current = _eqBands.value.toMutableList()
        if (bandIndex in current.indices) {
            current[bandIndex] = level
            _eqBands.value = current
            applyEqualizerBands(current)
        }
    }

    fun setEqualizerPreset(levels: List<Int>, bass: Int, virt: Int) {
        _eqBands.value = levels
        applyEqualizerBands(levels)
        setBassBoost(bass)
        setVirtualizer(virt)
    }

    private fun applyEqualizerBands(bands: List<Int>) {
        equalizer?.let { eq ->
            try {
                val numBands = eq.numberOfBands.toInt()
                val minBand = eq.bandLevelRange[0]
                val maxBand = eq.bandLevelRange[1]
                for (i in 0 until minOf(numBands, bands.size)) {
                    val normalized = (bands[i] / 10f) * (maxBand - minBand) / 2f
                    eq.setBandLevel(i.toShort(), normalized.toInt().toShort())
                }
            } catch (e: Exception) {
                Log.w("AudioPlayerManager", "Could not apply equalizer", e)
            }
        }
    }

    fun setBassBoost(level: Int) {
        _bassBoostLevel.value = level.coerceIn(0, 100)
        try {
            bassBoost?.setStrength((_bassBoostLevel.value * 10).toShort())
        } catch (e: Exception) {
            Log.w("AudioPlayerManager", "Could not set bass boost", e)
        }
    }

    fun setVirtualizer(level: Int) {
        _virtualizerLevel.value = level.coerceIn(0, 100)
        try {
            virtualizer?.setStrength((_virtualizerLevel.value * 10).toShort())
        } catch (e: Exception) {
            Log.w("AudioPlayerManager", "Could not set virtualizer", e)
        }
    }

    fun toggleEqualizer(enabled: Boolean) {
        _eqEnabled.value = enabled
        try {
            equalizer?.enabled = enabled
            bassBoost?.enabled = enabled
            virtualizer?.enabled = enabled
        } catch (e: Exception) {
            Log.w("AudioPlayerManager", "Could not toggle effects", e)
        }
    }

    // Sleep Timer
    fun startSleepTimer(minutes: Int) {
        cancelSleepTimer()
        val totalMs = minutes * 60 * 1000L
        _sleepTimerRemainingMs.value = totalMs

        sleepCountDown = object : CountDownTimer(totalMs, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                _sleepTimerRemainingMs.value = millisUntilFinished
                // Fade out volume in the last 15 seconds
                if (millisUntilFinished < 15000L) {
                    sleepFadeActive = true
                    player.volume = (millisUntilFinished / 15000f).coerceIn(0f, 1f)
                }
            }

            override fun onFinish() {
                _sleepTimerRemainingMs.value = 0L
                player.pause()
                sleepFadeActive = false
                player.volume = 1f
            }
        }.start()
    }

    fun cancelSleepTimer() {
        sleepCountDown?.cancel()
        sleepCountDown = null
        _sleepTimerRemainingMs.value = 0L
        if (sleepFadeActive) {
            sleepFadeActive = false
            player.volume = 1f
        }
    }

    // Lyrics Parsing
    private fun parseLyrics(rawLyrics: String?) {
        if (rawLyrics.isNullOrBlank()) {
            _parsedLyrics.value = emptyList()
            _currentLyricIndex.value = -1
            return
        }

        val lines = mutableListOf<LyricsLine>()
        val regex = Regex("\\[(\\d{2}):(\\d{2})(?:\\.(\\d{2,3}))?\\](.*)")

        rawLyrics.lines().forEach { line ->
            val match = regex.find(line.trim())
            if (match != null) {
                val min = match.groupValues[1].toLongOrNull() ?: 0L
                val sec = match.groupValues[2].toLongOrNull() ?: 0L
                val msStr = match.groupValues.getOrNull(3) ?: "0"
                val ms = if (msStr.length == 2) (msStr.toLongOrNull() ?: 0L) * 10 else (msStr.toLongOrNull() ?: 0L)
                val totalMs = (min * 60 * 1000) + (sec * 1000) + ms
                val text = match.groupValues.getOrElse(4) { "" }.trim()
                if (text.isNotEmpty()) lines.add(LyricsLine(totalMs, text))
            } else if (line.isNotBlank()) {
                lines.add(LyricsLine(lines.size * 3500L, line.trim()))
            }
        }
        _parsedLyrics.value = lines.sortedBy { it.timeMs }
    }

    private fun updateCurrentLyricIndex(currentMs: Long) {
        val lyrics = _parsedLyrics.value
        if (lyrics.isEmpty()) {
            _currentLyricIndex.value = -1
            return
        }
        var foundIndex = -1
        for (i in lyrics.indices) {
            if (currentMs >= lyrics[i].timeMs) foundIndex = i else break
        }
        _currentLyricIndex.value = foundIndex
    }

    // Loops
    private fun startProgressTracking() {
        progressJob = scope.launch {
            while (isActive) {
                if (player.mediaItemCount > 0) {
                    val pos = player.currentPosition.coerceAtLeast(0L)
                    _currentPosition.value = pos
                    val dur = player.duration
                    if (dur > 0) _duration.value = dur
                    updateCurrentLyricIndex(pos)

                    // Crossfade: fade out the last seconds of a song before the next one starts.
                    if (crossfadeEnabled && player.isPlaying && !sleepFadeActive &&
                        player.repeatMode != Player.REPEAT_MODE_ONE && player.hasNextMediaItem() && dur > crossfadeMs * 2
                    ) {
                        val remaining = dur - pos
                        if (remaining in 0..crossfadeMs) {
                            fadeInJob?.cancel()
                            player.volume = (remaining / crossfadeMs.toFloat()).coerceIn(0.05f, 1f)
                        }
                    }
                }
                delay(200)
            }
        }
    }

    private fun startVisualizerLoop() {
        visualizerJob = scope.launch {
            var phase = 0f
            while (isActive) {
                if (_playbackState.value == PlaybackState.PLAYING) {
                    phase += 0.25f
                    _visualizerBands.value = List(24) { i ->
                        val bassMultiplier = if (i < 6) 1.2f + (_bassBoostLevel.value / 100f) * 0.8f else 1.0f
                        val wave = (sin(phase + i * 0.45f) + 1f) / 2f
                        val randomJitter = Random.nextFloat() * 0.25f
                        ((0.2f + 0.6f * wave + randomJitter) * bassMultiplier).coerceIn(0.08f, 1.0f)
                    }
                } else {
                    _visualizerBands.value = List(24) { 0.08f }
                }
                delay(60)
            }
        }
    }

    // Queue management
    fun playQueueItem(index: Int) {
        if (index in 0 until player.mediaItemCount) {
            ensureServiceConnected()
            player.seekTo(index, 0L)
            player.volume = 1f
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.play()
        }
    }

    fun addToQueue(song: Song) {
        if (player.mediaItemCount == 0) {
            setQueue(listOf(song), 0, false)
            return
        }
        player.addMediaItem(song.toMediaItem())
        _queue.value = _queue.value + song
    }

    fun playNextInQueue(song: Song) {
        if (player.mediaItemCount == 0) {
            setQueue(listOf(song), 0, false)
            return
        }
        val insertAt = (player.currentMediaItemIndex + 1).coerceAtMost(player.mediaItemCount)
        player.addMediaItem(insertAt, song.toMediaItem())
        _queue.value = _queue.value.toMutableList().apply { add(insertAt, song) }
        syncCurrentItem()
    }

    fun removeQueueItem(index: Int) {
        if (index in 0 until player.mediaItemCount) {
            _queue.value = _queue.value.toMutableList().apply { removeAt(index) }
            player.removeMediaItem(index)
            syncCurrentItem()
        }
    }

    fun moveQueueItem(from: Int, to: Int) {
        val count = player.mediaItemCount
        if (from in 0 until count && to in 0 until count) {
            _queue.value = _queue.value.toMutableList().apply { add(to, removeAt(from)) }
            player.moveMediaItem(from, to)
            syncCurrentItem()
        }
    }

    fun clearQueue() {
        player.stop()
        player.clearMediaItems()
        _queue.value = emptyList()
        _currentIndex.value = -1
        _currentSong.value = null
        syncPlaybackState()
    }

    private fun releaseAudioEffects() {
        try {
            equalizer?.release()
            bassBoost?.release()
            virtualizer?.release()
        } catch (e: Exception) {
            Log.w("AudioPlayerManager", "Could not release effects", e)
        }
        equalizer = null
        bassBoost = null
        virtualizer = null
    }

    fun release() {
        progressJob?.cancel()
        visualizerJob?.cancel()
        cancelSleepTimer()
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        releaseAudioEffects()
        player.removeListener(listener)
        player.release()
        scope.cancel()
    }
}
