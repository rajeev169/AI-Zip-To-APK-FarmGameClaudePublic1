package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppSettings
import com.example.model.AppTheme
import com.example.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

/** Saves app settings on the device so they survive restarts. */
class SettingsStore(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val CROSSFADE = booleanPreferencesKey("crossfade")
        val CROSSFADE_SEC = intPreferencesKey("crossfade_sec")
        val FILTER_SHORT = booleanPreferencesKey("filter_short_audio")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { p ->
        val defaults = AppSettings()
        AppSettings(
            theme = p[Keys.THEME]?.let { name -> AppTheme.entries.firstOrNull { it.name == name } } ?: defaults.theme,
            themeMode = p[Keys.THEME_MODE]?.let { name -> ThemeMode.entries.firstOrNull { it.name == name } } ?: defaults.themeMode,
            isCrossfadeEnabled = p[Keys.CROSSFADE] ?: defaults.isCrossfadeEnabled,
            crossfadeDurationSec = p[Keys.CROSSFADE_SEC] ?: defaults.crossfadeDurationSec,
            isFilterShortAudio = p[Keys.FILTER_SHORT] ?: defaults.isFilterShortAudio
        )
    }

    suspend fun setTheme(theme: AppTheme) = context.settingsDataStore.edit { it[Keys.THEME] = theme.name }
    suspend fun setThemeMode(mode: ThemeMode) = context.settingsDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    suspend fun setCrossfade(enabled: Boolean) = context.settingsDataStore.edit { it[Keys.CROSSFADE] = enabled }
    suspend fun setCrossfadeSeconds(sec: Int) = context.settingsDataStore.edit { it[Keys.CROSSFADE_SEC] = sec }
    suspend fun setFilterShortAudio(enabled: Boolean) = context.settingsDataStore.edit { it[Keys.FILTER_SHORT] = enabled }
}
