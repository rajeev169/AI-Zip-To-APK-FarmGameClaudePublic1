package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.MusicDao
import com.example.data.local.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        PlaylistEntity::class,
        PlaylistSongEntity::class,
        FavoriteSongEntity::class,
        PlayHistoryEntity::class,
        EqualizerPresetEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MusicDatabase : RoomDatabase() {
    abstract fun musicDao(): MusicDao

    companion object {
        @Volatile
        private var INSTANCE: MusicDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): MusicDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MusicDatabase::class.java,
                    "pulse_music_database"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(private val scope: CoroutineScope) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.musicDao())
                    }
                }
            }
        }

        private suspend fun populateInitialData(dao: MusicDao) {
            // Default Playlists
            val chillId = dao.insertPlaylist(
                PlaylistEntity(
                    name = "Chill Vibes",
                    description = "Relaxing tracks for unwind and focus",
                    iconName = "spa",
                    colorHex = "#26A69A"
                )
            )
            val workoutId = dao.insertPlaylist(
                PlaylistEntity(
                    name = "Workout Energy",
                    description = "High energy beats for training and cardio",
                    iconName = "fitness",
                    colorHex = "#FF7043"
                )
            )
            val focusId = dao.insertPlaylist(
                PlaylistEntity(
                    name = "Deep Focus",
                    description = "Atmospheric synthwave and ambient waves",
                    iconName = "brain",
                    colorHex = "#AB47BC"
                )
            )

            // Associate demo tracks
            dao.addSongToPlaylist(PlaylistSongEntity(chillId, "demo_lofi", orderIndex = 0))
            dao.addSongToPlaylist(PlaylistSongEntity(chillId, "demo_acoustic", orderIndex = 1))
            dao.addSongToPlaylist(PlaylistSongEntity(workoutId, "demo_synthwave", orderIndex = 0))
            dao.addSongToPlaylist(PlaylistSongEntity(focusId, "demo_cosmic", orderIndex = 0))
            dao.addSongToPlaylist(PlaylistSongEntity(focusId, "demo_lofi", orderIndex = 1))

            // Default Equalizer Presets
            val presets = listOf(
                EqualizerPresetEntity(name = "Flat", bandLevels = "0,0,0,0,0", bassBoost = 0, virtualizer = 0),
                EqualizerPresetEntity(name = "Bass Boost", bandLevels = "7,5,0,0,2", bassBoost = 80, virtualizer = 20),
                EqualizerPresetEntity(name = "Rock", bandLevels = "4,2,-1,3,5", bassBoost = 40, virtualizer = 30),
                EqualizerPresetEntity(name = "Electronic", bandLevels = "5,3,0,2,4", bassBoost = 60, virtualizer = 50),
                EqualizerPresetEntity(name = "Pop", bandLevels = "-1,2,4,3,-1", bassBoost = 25, virtualizer = 20),
                EqualizerPresetEntity(name = "Jazz", bandLevels = "3,1,0,2,3", bassBoost = 20, virtualizer = 40),
                EqualizerPresetEntity(name = "Vocal Boost", bandLevels = "-2,-1,5,4,1", bassBoost = 10, virtualizer = 15),
                EqualizerPresetEntity(name = "Acoustic", bandLevels = "3,2,1,3,4", bassBoost = 20, virtualizer = 30)
            )
            presets.forEach { dao.insertPreset(it) }
        }
    }
}
