package com.example.data.repository

import android.content.ContentUris
import android.content.ContentValues
import android.media.MediaScannerConnection
import android.os.Environment
import android.webkit.MimeTypeMap
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.MediaStore
import com.example.data.local.dao.MusicDao
import com.example.data.local.entity.*
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.withContext
import java.io.File

class MusicRepository(
    private val context: Context,
    private val musicDao: MusicDao
) {

    private val _deviceSongs = MutableStateFlow<List<Song>>(emptyList())
    val deviceSongs: StateFlow<List<Song>> = _deviceSongs.asStateFlow()

    val allPlaylists: Flow<List<PlaylistEntity>> = musicDao.getAllPlaylists()
    val allFavoriteIds: Flow<List<String>> = musicDao.getAllFavorites()
    val allPresets: Flow<List<EqualizerPresetEntity>> = musicDao.getAllPresets()

    private val _recordings = MutableStateFlow<List<Song>>(emptyList())
    /** Call recordings and voice notes, newest first. */
    val recordings: StateFlow<List<Song>> = _recordings.asStateFlow()

    /**
     * Scans the phone's shared storage. Music goes to [deviceSongs]; call recordings and
     * voice notes go to [recordings]. Recordings that a dialer keeps in its own private
     * storage cannot be read by any other app.
     */
    suspend fun scanDeviceMusic(): List<Song> = withContext(Dispatchers.IO) {
        val songList = mutableListOf<Song>()
        val recordingList = mutableListOf<Song>()

        try {
            val projection = mutableListOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.TRACK,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATE_ADDED,
                MediaStore.Audio.Media.IS_MUSIC,
                MediaStore.Audio.Media.DISPLAY_NAME
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                projection.add(MediaStore.Audio.Media.IS_RECORDING)
            }

            // Everything except ringtones, alarms and notification sounds.
            val selection = "${MediaStore.Audio.Media.IS_ALARM} = 0 AND " +
                "${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND " +
                "${MediaStore.Audio.Media.IS_RINGTONE} = 0"

            val cursor = context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection.toTypedArray(),
                selection,
                null,
                "${MediaStore.Audio.Media.TITLE} ASC"
            )

            cursor?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val trackCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateAddedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val isMusicCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_MUSIC)
                val displayNameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val isRecordingCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    c.getColumnIndex(MediaStore.Audio.Media.IS_RECORDING)
                } else -1

                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val path = c.getString(dataCol) ?: ""
                    val displayName = c.getString(displayNameCol) ?: ""
                    val duration = c.getLong(durationCol)
                    val isMusic = c.getInt(isMusicCol) != 0
                    val flaggedRecording = isRecordingCol >= 0 && c.getInt(isRecordingCol) != 0

                    val kind = classify(path, displayName, isMusic, flaggedRecording)
                    if (kind == AudioKind.OTHER) continue
                    if (kind == AudioKind.MUSIC && duration < 5000) continue

                    val rawTitle = c.getString(titleCol)?.takeIf { it.isNotBlank() } ?: displayName.substringBeforeLast('.')
                    val artist = c.getString(artistCol) ?: "Unknown Artist"
                    val album = c.getString(albumCol) ?: "Unknown Album"
                    val albumId = c.getLong(albumIdCol)
                    val dateAddedSec = c.getLong(dateAddedCol)

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id
                    ).toString()
                    val folder = try {
                        File(path).parentFile?.name ?: "Music"
                    } catch (e: Exception) {
                        "Music"
                    }

                    if (kind == AudioKind.MUSIC) {
                        songList.add(
                            Song(
                                id = "device_$id",
                                title = rawTitle,
                                artist = if (artist == "<unknown>") "Unknown Artist" else artist,
                                album = if (album == "<unknown>") "Unknown Album" else album,
                                durationMs = duration,
                                uri = contentUri,
                                albumArtUri = "content://media/external/audio/albumart/$albumId",
                                trackNumber = c.getInt(trackCol),
                                sizeBytes = c.getLong(sizeCol),
                                dateAdded = dateAddedSec * 1000L,
                                folder = folder
                            )
                        )
                    } else {
                        val isCall = kind == AudioKind.CALL_RECORDING
                        recordingList.add(
                            Song(
                                id = "device_$id",
                                title = cleanRecordingName(rawTitle),
                                artist = if (isCall) "Call recording" else "Voice note",
                                album = if (isCall) "Call recordings" else "Voice notes",
                                durationMs = duration,
                                uri = contentUri,
                                albumArtUri = null,
                                sizeBytes = c.getLong(sizeCol),
                                dateAdded = dateAddedSec * 1000L,
                                folder = folder,
                                isRecording = true,
                                isCallRecording = isCall
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        _deviceSongs.value = songList
        _recordings.value = recordingList.sortedByDescending { it.dateAdded }
        songList
    }

    /** Builds a playable song for a file opened from another app. */
    suspend fun songFromUri(uri: Uri): Song = withContext(Dispatchers.IO) {
        var name: String? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val fileName = name ?: uri.lastPathSegment ?: "Audio file"
        var title = fileName.substringBeforeLast('.', fileName)
        var artist = "Unknown Artist"
        var duration = 0L
        try {
            MediaMetadataRetriever().apply {
                setDataSource(context, uri)
                extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }?.let { title = it }
                extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.takeIf { it.isNotBlank() }?.let { artist = it }
                duration = extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        Song(
            id = "external_${uri.hashCode()}",
            title = title,
            artist = artist,
            album = "Opened file",
            durationMs = duration,
            uri = uri.toString(),
            folder = "Opened files"
        )
    }

    /**
     * Saves a recording shared to Pulse (for example from Google's Phone app, which keeps call
     * recordings private) into a shared "call recordings" folder so it appears under Calls.
     * Returns the number of files saved.
     */
    suspend fun saveSharedCallRecordings(uris: List<Uri>): Int = withContext(Dispatchers.IO) {
        var saved = 0
        for (uri in uris) {
            try {
                if (saveOneSharedRecording(uri)) saved++
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        saved
    }

    private fun saveOneSharedRecording(source: Uri): Boolean {
        val resolver = context.contentResolver
        var name: String? = null
        resolver.query(source, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0)
        }
        val mime = resolver.getType(source) ?: "audio/mp4"
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "m4a"
        val fileName = (name ?: "Call recording ${System.currentTimeMillis()}")
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .let { if (it.contains('.')) it else "$it.$ext" }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                "${Environment.DIRECTORY_RECORDINGS}/Call/"
            } else {
                "${Environment.DIRECTORY_MUSIC}/Call recordings/"
            }
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Audio.Media.MIME_TYPE, mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, relativePath)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val target = resolver.insert(collection, values) ?: return false
            try {
                resolver.openInputStream(source).use { input ->
                    resolver.openOutputStream(target).use { output ->
                        if (input == null || output == null) throw java.io.IOException("Cannot open stream")
                        input.copyTo(output)
                    }
                }
                values.clear()
                values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                resolver.update(target, values, null, null)
                return true
            } catch (e: Exception) {
                resolver.delete(target, null, null)
                throw e
            }
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "Call recordings")
            if (!dir.exists() && !dir.mkdirs()) return false
            var outFile = File(dir, fileName)
            var n = 1
            while (outFile.exists()) {
                outFile = File(dir, fileName.substringBeforeLast('.') + " ($n)." + fileName.substringAfterLast('.'))
                n++
            }
            resolver.openInputStream(source).use { input ->
                if (input == null) return false
                outFile.outputStream().use { input.copyTo(it) }
            }
            // Make the new file visible to MediaStore, then wait briefly for indexing.
            val latch = java.util.concurrent.CountDownLatch(1)
            MediaScannerConnection.scanFile(context, arrayOf(outFile.absolutePath), arrayOf(mime)) { _, _ -> latch.countDown() }
            latch.await(5, java.util.concurrent.TimeUnit.SECONDS)
            return true
        }
    }

    private enum class AudioKind { MUSIC, CALL_RECORDING, VOICE_NOTE, OTHER }

    private fun classify(path: String, displayName: String, isMusic: Boolean, flaggedRecording: Boolean): AudioKind {
        val p = path.lowercase()
        val name = displayName.lowercase()
        val callHints = listOf(
            "/call", "callrecord", "call_rec", "call rec", "callrec", "/phonerecord",
            "sound_recorder/call", "/recordings/call", "call recordings"
        )
        val recorderHints = listOf(
            "/recordings/", "/recording/", "sound_recorder", "soundrecorder", "voice recorder",
            "voicerecorder", "/recorder/", "voice notes", "voice_notes"
        )
        val isCall = callHints.any { p.contains(it) } || name.startsWith("call_") || name.startsWith("call recording")
        val isRecorder = flaggedRecording || recorderHints.any { p.contains(it) }
        return when {
            isCall && (isRecorder || !isMusic) -> AudioKind.CALL_RECORDING
            isCall && p.contains("record") -> AudioKind.CALL_RECORDING
            isRecorder -> AudioKind.VOICE_NOTE
            isMusic -> AudioKind.MUSIC
            else -> AudioKind.OTHER
        }
    }

    /** "Call recording Amit Kumar_20261101_161200" -> "Amit Kumar". */
    private fun cleanRecordingName(raw: String): String {
        var t = raw.substringBeforeLast('.', raw)
        t = t.replace(Regex("(?i)^(call[ _-]?recording|call[ _-]?rec|recording|record)[ _-]*"), "")
        t = t.replace(Regex("(?i)^(call )?(with|from|to) "), "")
        t = t.replace(Regex("[ _-]*\\(?\\d{6,8}[ _-]?\\d{4,6}\\)?$"), "")
        t = t.replace(Regex("[ _-]*\\d{4}-\\d{2}-\\d{2}[ _-]\\d{2}-\\d{2}(-\\d{2})?$"), "")
        t = t.replace('_', ' ').trim()
        return t.ifBlank { raw }
    }

    // Playlists Operations
    suspend fun createPlaylist(name: String, description: String = "", iconName: String = "playlist", colorHex: String = "#7C4DFF"): Long {
        return musicDao.insertPlaylist(
            PlaylistEntity(
                name = name,
                description = description,
                iconName = iconName,
                colorHex = colorHex
            )
        )
    }

    suspend fun deletePlaylist(playlistId: Long) {
        musicDao.deletePlaylist(playlistId)
        musicDao.deletePlaylistSongs(playlistId)
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: String) {
        musicDao.addSongToPlaylist(PlaylistSongEntity(playlistId = playlistId, songId = songId))
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: String) {
        musicDao.removeSongFromPlaylist(playlistId, songId)
    }

    fun getSongsForPlaylist(playlistId: Long): Flow<List<Song>> {
        return combine(musicDao.getSongIdsForPlaylist(playlistId), _deviceSongs, _recordings) { ids, songs, recs ->
            val byId = (songs + recs).associateBy { it.id }
            ids.mapNotNull { byId[it] }
        }
    }

    // Favorites Operations
    suspend fun toggleFavorite(songId: String, isFav: Boolean) {
        if (isFav) {
            musicDao.addFavorite(FavoriteSongEntity(songId = songId))
        } else {
            musicDao.removeFavorite(songId)
        }
    }

    // Play History
    suspend fun recordPlay(songId: String) {
        musicDao.recordPlayHistory(PlayHistoryEntity(songId = songId))
    }

    fun getRecentSongs(limit: Int = 30): Flow<List<Song>> {
        return combine(musicDao.getRecentSongIds(limit), _deviceSongs) { ids, songs ->
            val byId = songs.associateBy { it.id }
            ids.distinct().mapNotNull { byId[it] }
        }
    }

    fun getMostPlayedSongs(limit: Int = 30): Flow<List<Song>> {
        return combine(musicDao.getMostPlayedSongIds(limit), _deviceSongs) { ids, songs ->
            val byId = songs.associateBy { it.id }
            ids.mapNotNull { byId[it] }
        }
    }

    // Equalizer Presets
    suspend fun saveEqualizerPreset(name: String, bandLevels: List<Int>, bass: Int, virt: Int): Long {
        return musicDao.insertPreset(
            EqualizerPresetEntity(
                name = name,
                bandLevels = bandLevels.joinToString(","),
                bassBoost = bass,
                virtualizer = virt,
                isCustom = true
            )
        )
    }

    suspend fun deletePreset(preset: EqualizerPresetEntity) {
        musicDao.deletePreset(preset)
    }
}
