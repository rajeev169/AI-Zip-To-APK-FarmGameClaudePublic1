package com.example.model

data class AppSettings(
    val theme: AppTheme = AppTheme.DEEP_PURPLE,
    val themeMode: ThemeMode = ThemeMode.LIGHT,
    val isCrossfadeEnabled: Boolean = false,
    val crossfadeDurationSec: Int = 3,
    val isFilterShortAudio: Boolean = true
)

enum class ThemeMode(val displayName: String) {
    LIGHT("Light"),
    DARK("Dark"),
    SYSTEM("Follow phone")
}
