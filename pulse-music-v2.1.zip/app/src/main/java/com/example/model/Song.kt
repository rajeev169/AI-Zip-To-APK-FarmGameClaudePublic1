package com.example.model

data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: String,
    val albumArtUri: String? = null,
    val albumArtResId: Int? = null,
    val genre: String = "Various",
    val trackNumber: Int = 1,
    val sizeBytes: Long = 0L,
    val dateAdded: Long = System.currentTimeMillis(),
    val folder: String = "Music",
    val lyrics: String? = null,
    val isFavorite: Boolean = false,
    val isBuiltIn: Boolean = false,
    /** Call recording or voice note (not music). */
    val isRecording: Boolean = false,
    val isCallRecording: Boolean = false
)

data class LyricsLine(
    val timeMs: Long,
    val text: String
)

data class Album(
    val id: String,
    val title: String,
    val artist: String,
    val songCount: Int,
    val albumArtUri: String? = null,
    val albumArtResId: Int? = null,
    val year: Int = 2026
)

data class Artist(
    val id: String,
    val name: String,
    val songCount: Int,
    val albumCount: Int
)

data class Folder(
    val path: String,
    val name: String,
    val songCount: Int
)

enum class RepeatMode {
    OFF, ALL, ONE
}

enum class PlaybackState {
    IDLE, BUFFERING, PLAYING, PAUSED, STOPPED
}

enum class SortOption(val displayName: String) {
    TITLE_ASC("Title (A-Z)"),
    TITLE_DESC("Title (Z-A)"),
    ARTIST_ASC("Artist (A-Z)"),
    DATE_ADDED_DESC("Recently Added"),
    DURATION_DESC("Longest First")
}

enum class AppTheme(val displayName: String) {
    DYNAMIC("Dynamic Material You"),
    DEEP_PURPLE("Neon Purple"),
    MIDNIGHT_AMOLED("Midnight AMOLED"),
    SUNSET_AMBER("Sunset Amber"),
    CYBER_EMERALD("Cyber Emerald"),
    OCEAN_BLUE("Electric Ocean")
}
