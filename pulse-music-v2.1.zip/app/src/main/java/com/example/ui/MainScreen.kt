package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.local.entity.PlaylistEntity
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.viewmodel.MusicViewModel

enum class MainNavigationTab(
    val title: String,
    val icon: ImageVector
) {
    LIBRARY("Library", Icons.Default.LibraryMusic),
    PLAYLISTS("Playlists", Icons.Default.QueueMusic),
    FAVORITES("Favorites", Icons.Default.Favorite),
    EQUALIZER("Equalizer", Icons.Default.GraphicEq)
}

enum class LibrarySection(val title: String) {
    SONGS("Songs"),
    ALBUMS("Albums"),
    ARTISTS("Artists"),
    FOLDERS("Folders"),
    RECORDINGS("Recordings")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MusicViewModel) {
    val context = LocalContext.current

    // Request permissions on Android 13+ (READ_MEDIA_AUDIO) or older (READ_EXTERNAL_STORAGE)
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.scanMusic()
        }
    }

    LaunchedEffect(Unit) {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(permission)
        }
    }

    // State Collection
    val songs: List<Song> by viewModel.allSongs.collectAsState()
    val currentSong: Song? by viewModel.currentSong.collectAsState()
    val playbackState: PlaybackState by viewModel.playbackState.collectAsState()
    val currentPositionMs: Long by viewModel.currentPosition.collectAsState()
    val durationMs: Long by viewModel.duration.collectAsState()
    val repeatMode: RepeatMode by viewModel.repeatMode.collectAsState()
    val isShuffle: Boolean by viewModel.isShuffle.collectAsState()
    val playbackSpeed: Float by viewModel.playbackSpeed.collectAsState()
    val queue: List<Song> by viewModel.queue.collectAsState()
    val currentIndex: Int by viewModel.currentIndex.collectAsState()
    val playlists: List<PlaylistEntity> by viewModel.allPlaylists.collectAsState()
    val albums: List<Album> by viewModel.albums.collectAsState()
    val artists: List<Artist> by viewModel.artists.collectAsState()
    val folders: List<Folder> by viewModel.folders.collectAsState()
    val sortOption: SortOption by viewModel.sortOption.collectAsState()
    val searchQuery: String by viewModel.searchQuery.collectAsState()
    val eqEnabled: Boolean by viewModel.eqEnabled.collectAsState()
    val eqBands: List<Int> by viewModel.eqBands.collectAsState()
    val bassBoostLevel: Int by viewModel.bassBoostLevel.collectAsState()
    val virtualizerLevel: Int by viewModel.virtualizerLevel.collectAsState()
    val eqPresets by viewModel.allPresets.collectAsState()
    val visualizerBands: List<Float> by viewModel.visualizerBands.collectAsState()
    val parsedLyrics: List<LyricsLine> by viewModel.parsedLyrics.collectAsState()
    val currentLyricIndex: Int by viewModel.currentLyricIndex.collectAsState()
    val sleepTimerRemainingMs: Long by viewModel.sleepTimerRemainingMs.collectAsState()
    val appSettings: AppSettings by viewModel.appSettings.collectAsState()
    val recordings: List<Song> by viewModel.recordings.collectAsState()
    val recentlyPlayed: List<Song> by viewModel.recentlyPlayed.collectAsState()
    val mostPlayed: List<Song> by viewModel.mostPlayed.collectAsState()
    val sharedImportResult: Int? by viewModel.sharedImportResult.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Navigation and Dialog States
    var selectedTab by rememberSaveable { mutableStateOf(MainNavigationTab.LIBRARY) }
    var librarySection by rememberSaveable { mutableStateOf(LibrarySection.SONGS) }
    var isSettingsOpen by rememberSaveable { mutableStateOf(false) }
    var isSearchActive by remember { mutableStateOf(false) }
    var isNowPlayingExpanded by remember { mutableStateOf(false) }
    var isQueueOpen by remember { mutableStateOf(false) }
    var isDriveModeOpen by remember { mutableStateOf(false) }
    var isEqDialogOpen by remember { mutableStateOf(false) }
    var isSleepTimerOpen by remember { mutableStateOf(false) }
    var isCreatePlaylistOpen by remember { mutableStateOf(false) }
    var songForAddToPlaylist by remember { mutableStateOf<Song?>(null) }
    var songForDetails by remember { mutableStateOf<Song?>(null) }

    // Screen specific sub-selections
    var selectedPlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }
    var selectedAlbum by remember { mutableStateOf<Album?>(null) }
    var selectedArtist by remember { mutableStateOf<Artist?>(null) }
    var selectedFolder by remember { mutableStateOf<Folder?>(null) }

    // After "Share to Pulse": open Library > Recordings and confirm.
    LaunchedEffect(sharedImportResult) {
        val saved = sharedImportResult ?: return@LaunchedEffect
        viewModel.consumeSharedImportResult()
        if (saved > 0) {
            isSettingsOpen = false
            isSearchActive = false
            isNowPlayingExpanded = false
            selectedTab = MainNavigationTab.LIBRARY
            librarySection = LibrarySection.RECORDINGS
        }
        snackbarHostState.showSnackbar(
            when {
                saved == 1 -> "Saved to Calls"
                saved > 1 -> "$saved recordings saved to Calls"
                else -> "Couldn't save the recording"
            }
        )
    }

    // System back / predictive back closes the innermost open thing first.
    BackHandler(enabled = !isNowPlayingExpanded && !isDriveModeOpen &&
        (isSettingsOpen || isSearchActive || selectedPlaylist != null || selectedAlbum != null ||
            selectedArtist != null || selectedFolder != null)) {
        when {
            isSettingsOpen -> isSettingsOpen = false
            isSearchActive -> {
                isSearchActive = false
                viewModel.onSearchQueryChanged("")
            }
            selectedPlaylist != null -> selectedPlaylist = null
            selectedAlbum != null -> selectedAlbum = null
            selectedArtist != null -> selectedArtist = null
            selectedFolder != null -> selectedFolder = null
        }
    }
    BackHandler(enabled = isDriveModeOpen) { isDriveModeOpen = false }

    // Derive Smart Playlists
    val favoriteSongs = remember(songs) { songs.filter { it.isFavorite } }
    val playlistSongsFlow = remember(selectedPlaylist) {
        if (selectedPlaylist == null) kotlinx.coroutines.flow.flowOf(emptyList())
        else viewModel.getSongsForPlaylist(selectedPlaylist!!.id)
    }
    val playlistSongs by playlistSongsFlow.collectAsState(initial = emptyList())

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (!isNowPlayingExpanded && !isDriveModeOpen) {
                TopAppBar(
                    navigationIcon = {
                        if (isSettingsOpen || isSearchActive) {
                            IconButton(onClick = {
                                if (isSettingsOpen) isSettingsOpen = false
                                else {
                                    isSearchActive = false
                                    viewModel.onSearchQueryChanged("")
                                }
                            }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                        }
                    },
                    title = {
                        val isHome = !isSettingsOpen && !isSearchActive && selectedTab == MainNavigationTab.LIBRARY
                        Text(
                            text = when {
                                isSettingsOpen -> "Settings"
                                isSearchActive -> "Search"
                                isHome -> "Pulse"
                                else -> selectedTab.title
                            },
                            style = if (isHome) {
                                MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp)
                            } else {
                                MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                            },
                            color = if (isHome) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    },
                    actions = {
                        if (!isSearchActive && !isSettingsOpen) {
                            FilledTonalIconButton(
                                onClick = { isSearchActive = true },
                                shape = CircleShape,
                                modifier = Modifier.testTag("open_search_btn")
                            ) {
                                Icon(Icons.Default.Search, contentDescription = "Search")
                            }
                            FilledTonalIconButton(
                                onClick = { isSettingsOpen = true },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .padding(end = 8.dp)
                                    .testTag("open_settings_btn")
                            ) {
                                Icon(Icons.Default.Settings, contentDescription = "Settings")
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        },
        bottomBar = {
            if (!isNowPlayingExpanded && !isDriveModeOpen) {
                Column {
                    // Mini Player above bottom bar
                    if (currentSong != null) {
                        MiniPlayer(
                            song = currentSong,
                            playbackState = playbackState,
                            currentPositionMs = currentPositionMs,
                            durationMs = durationMs,
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onPlayNext = { viewModel.playNext() },
                            onExpandNowPlaying = { isNowPlayingExpanded = true },
                            onToggleFavorite = { currentSong?.let { viewModel.toggleFavorite(it) } }
                        )
                    }

                    // Navigation bar
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer
                    ) {
                        MainNavigationTab.entries.forEach { tab ->
                            NavigationBarItem(
                                selected = selectedTab == tab && !isSearchActive && !isSettingsOpen,
                                onClick = {
                                    isSearchActive = false
                                    isSettingsOpen = false
                                    selectedTab = tab
                                    selectedPlaylist = null
                                    selectedAlbum = null
                                    selectedArtist = null
                                    selectedFolder = null
                                },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title
                                    )
                                },
                                label = {
                                    Text(
                                        tab.title,
                                        fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Content Area
            if (isSettingsOpen) {
                    SettingsScreen(
                        settings = appSettings,
                        songCount = songs.size,
                        onUpdateTheme = { viewModel.setTheme(it) },
                        onSetThemeMode = { viewModel.setThemeMode(it) },
                        onToggleCrossfade = { viewModel.toggleCrossfade(it) },
                        onSetCrossfadeDuration = { viewModel.setCrossfadeDuration(it) },
                        onToggleFilterShortAudio = { viewModel.toggleFilterShortAudio(it) },
                        onRescanLibrary = { viewModel.scanMusic() }
                    )
            } else if (isSearchActive) {
                SearchScreen(
                    searchQuery = searchQuery,
                    searchResults = emptyList(),
                    allSongs = songs,
                    currentSong = currentSong,
                    playbackState = playbackState,
                    onQueryChange = { viewModel.onSearchQueryChanged(it) },
                    onSongClick = { viewModel.playSong(it) },
                    onToggleFavorite = { viewModel.toggleFavorite(it) },
                    onPlayNext = { viewModel.playNextInQueue(it) },
                    onAddToQueue = { viewModel.addToQueue(it) },
                    onAddToPlaylist = { songForAddToPlaylist = it },
                    onShowDetails = { songForDetails = it }
                )
            } else {
                when (selectedTab) {
                    MainNavigationTab.LIBRARY -> Column(modifier = Modifier.fillMaxSize()) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 4.dp)
                        ) {
                            items(LibrarySection.entries.toList()) { section ->
                                val selected = librarySection == section
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        librarySection = section
                                        selectedAlbum = null
                                        selectedArtist = null
                                        selectedFolder = null
                                    },
                                    label = {
                                        Text(
                                            if (section == LibrarySection.RECORDINGS && recordings.isNotEmpty()) "${section.title} · ${recordings.size}" else section.title,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    },
                                    shape = if (selected) RoundedCornerShape(20.dp) else RoundedCornerShape(12.dp),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                    ),
                                    modifier = Modifier
                                        .height(40.dp)
                                        .testTag("library_chip_${section.name.lowercase()}")
                                )
                            }
                        }
                        Box(modifier = Modifier.weight(1f)) {
                            when (librarySection) {
                                LibrarySection.SONGS -> {
                                    TracksScreen(
                                        songs = songs,
                                        currentSong = currentSong,
                                        playbackState = playbackState,
                                        sortOption = sortOption,
                                        onSortOptionSelected = { viewModel.setSortOption(it) },
                                        onSongClick = { viewModel.playSong(it) },
                                        onPlayAll = { shuffle -> viewModel.playAll(songs, shuffle) },
                                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                                        onPlayNext = { viewModel.playNextInQueue(it) },
                                        onAddToQueue = { viewModel.addToQueue(it) },
                                        onAddToPlaylist = { songForAddToPlaylist = it },
                                        onShowDetails = { songForDetails = it },
                                        onRescan = { viewModel.scanMusic() }
                                    )
                                }
                                LibrarySection.ALBUMS -> {
                                    AlbumsScreen(
                                        albums = albums,
                                        selectedAlbum = selectedAlbum,
                                        allSongs = songs,
                                        currentSong = currentSong,
                                        playbackState = playbackState,
                                        onSelectAlbum = { selectedAlbum = it },
                                        onSongClick = { viewModel.playSong(it) },
                                        onPlayAll = { list, shuffle -> viewModel.playAll(list, shuffle) },
                                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                                        onPlayNext = { viewModel.playNextInQueue(it) },
                                        onAddToQueue = { viewModel.addToQueue(it) },
                                        onAddToPlaylist = { songForAddToPlaylist = it },
                                        onShowDetails = { songForDetails = it }
                                    )
                                }
                                LibrarySection.ARTISTS -> {
                                    ArtistsScreen(
                                        artists = artists,
                                        selectedArtist = selectedArtist,
                                        allSongs = songs,
                                        currentSong = currentSong,
                                        playbackState = playbackState,
                                        onSelectArtist = { selectedArtist = it },
                                        onSongClick = { viewModel.playSong(it) },
                                        onPlayAll = { list, shuffle -> viewModel.playAll(list, shuffle) },
                                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                                        onPlayNext = { viewModel.playNextInQueue(it) },
                                        onAddToQueue = { viewModel.addToQueue(it) },
                                        onAddToPlaylist = { songForAddToPlaylist = it },
                                        onShowDetails = { songForDetails = it }
                                    )
                                }
                                LibrarySection.FOLDERS -> {
                                    FoldersScreen(
                                        folders = folders,
                                        selectedFolder = selectedFolder,
                                        allSongs = songs,
                                        currentSong = currentSong,
                                        playbackState = playbackState,
                                        onSelectFolder = { selectedFolder = it },
                                        onSongClick = { viewModel.playSong(it) },
                                        onPlayAll = { list, shuffle -> viewModel.playAll(list, shuffle) },
                                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                                        onPlayNext = { viewModel.playNextInQueue(it) },
                                        onAddToQueue = { viewModel.addToQueue(it) },
                                        onAddToPlaylist = { songForAddToPlaylist = it },
                                        onShowDetails = { songForDetails = it }
                                    )
                                }
                                LibrarySection.RECORDINGS -> {
                                    RecordingsScreen(
                                        recordings = recordings,
                                        currentSong = currentSong,
                                        playbackState = playbackState,
                                        onPlay = { viewModel.playRecording(it) },
                                        onShowDetails = { songForDetails = it },
                                        onRescan = { viewModel.scanMusic() }
                                    )
                                }
                            }
                        }
                    }
                    MainNavigationTab.PLAYLISTS -> {
                        PlaylistsScreen(
                            playlists = playlists,
                            favoriteSongs = favoriteSongs,
                            recentSongs = recentlyPlayed,
                            mostPlayedSongs = mostPlayed,
                            selectedPlaylist = selectedPlaylist,
                            playlistSongs = playlistSongs,
                            currentSong = currentSong,
                            playbackState = playbackState,
                            onSelectPlaylist = { selectedPlaylist = it },
                            onCreatePlaylistClick = { isCreatePlaylistOpen = true },
                            onDeletePlaylist = { viewModel.deletePlaylist(it) },
                            onSongClick = { viewModel.playSong(it) },
                            onPlayAll = { list, shuffle -> viewModel.playAll(list, shuffle) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onPlayNext = { viewModel.playNextInQueue(it) },
                            onAddToQueue = { viewModel.addToQueue(it) },
                            onAddToPlaylist = { songForAddToPlaylist = it },
                            onShowDetails = { songForDetails = it },
                            onRemoveFromPlaylist = { playlistId, songId ->
                                viewModel.removeSongFromPlaylist(playlistId, songId)
                            }
                        )
                    }
                    MainNavigationTab.FAVORITES -> {
                        FavoritesScreen(
                            favorites = favoriteSongs,
                            currentSong = currentSong,
                            playbackState = playbackState,
                            onSongClick = { viewModel.playSongFromList(favoriteSongs, it) },
                            onPlayAll = { list, shuffle -> viewModel.playAll(list, shuffle) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onPlayNext = { viewModel.playNextInQueue(it) },
                            onAddToQueue = { viewModel.addToQueue(it) },
                            onAddToPlaylist = { songForAddToPlaylist = it },
                            onShowDetails = { songForDetails = it }
                        )
                    }
                    MainNavigationTab.EQUALIZER -> {
                        EqualizerScreen(
                            eqEnabled = eqEnabled,
                            eqBands = eqBands,
                            bassBoostLevel = bassBoostLevel,
                            virtualizerLevel = virtualizerLevel,
                            presets = eqPresets,
                            onToggleEq = { viewModel.toggleEqualizer(it) },
                            onBandChange = { band, level -> viewModel.setEqualizerBand(band, level) },
                            onBassBoostChange = { viewModel.setBassBoost(it) },
                            onVirtualizerChange = { viewModel.setVirtualizer(it) },
                            onApplyPreset = { viewModel.applyPreset(it) },
                            onSaveCustomPreset = { viewModel.saveCustomPreset(it) },
                            onDeletePreset = { viewModel.deletePreset(it) }
                        )
                    }
                }
            }

            // Animated Now Playing Full Screen Overlay
            AnimatedVisibility(
                visible = isNowPlayingExpanded,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                NowPlayingSheet(
                    song = currentSong,
                    playbackState = playbackState,
                    currentPositionMs = currentPositionMs,
                    durationMs = durationMs,
                    repeatMode = repeatMode,
                    isShuffle = isShuffle,
                    playbackSpeed = playbackSpeed,
                    visualizerBands = visualizerBands,
                    parsedLyrics = parsedLyrics,
                    currentLyricIndex = currentLyricIndex,
                    sleepTimerRemainingMs = sleepTimerRemainingMs,
                    onCollapse = { isNowPlayingExpanded = false },
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onSeekTo = { viewModel.seekTo(it) },
                    onPlayNext = { viewModel.playNext() },
                    onPlayPrevious = { viewModel.playPrevious() },
                    onToggleRepeat = { viewModel.toggleRepeatMode() },
                    onToggleShuffle = { viewModel.toggleShuffle() },
                    onSetSpeed = { viewModel.setPlaybackSpeed(it) },
                    onToggleFavorite = { currentSong?.let { viewModel.toggleFavorite(it) } },
                    onOpenQueue = { isQueueOpen = true },
                    onOpenEqualizer = { isEqDialogOpen = true },
                    onOpenSleepTimer = { isSleepTimerOpen = true },
                    onOpenDriveMode = { isDriveModeOpen = true },
                    onOpenSongDetails = { currentSong?.let { songForDetails = it } }
                )
            }

            // Animated Drive Mode Full Screen Overlay
            AnimatedVisibility(
                visible = isDriveModeOpen,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                DriveModeScreen(
                    song = currentSong,
                    playbackState = playbackState,
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onPlayNext = { viewModel.playNext() },
                    onPlayPrevious = { viewModel.playPrevious() },
                    onToggleFavorite = { currentSong?.let { viewModel.toggleFavorite(it) } },
                    onExitDriveMode = { isDriveModeOpen = false }
                )
            }
        }
    }

    // Modal Bottom Sheet: Queue
    if (isQueueOpen) {
        QueueSheet(
            queue = queue,
            currentIndex = currentIndex,
            onDismiss = { isQueueOpen = false },
            onSelectTrack = { index ->
                viewModel.playQueueItem(index)
            },
            onRemoveItem = { index ->
                viewModel.removeFromQueue(index)
            },
            onClearQueue = {
                viewModel.clearQueue()
            },
            onSaveAsPlaylist = {
                isQueueOpen = false
                isCreatePlaylistOpen = true
            }
        )
    }

    // Equalizer Dialog (can be opened from NowPlayingSheet)
    if (isEqDialogOpen) {
        EqualizerDialog(
            eqEnabled = eqEnabled,
            eqBands = eqBands,
            bassBoostLevel = bassBoostLevel,
            virtualizerLevel = virtualizerLevel,
            presets = eqPresets,
            onToggleEq = { viewModel.toggleEqualizer(it) },
            onBandChange = { band, level -> viewModel.setEqualizerBand(band, level) },
            onBassBoostChange = { viewModel.setBassBoost(it) },
            onVirtualizerChange = { viewModel.setVirtualizer(it) },
            onApplyPreset = { viewModel.applyPreset(it) },
            onSaveCustomPreset = { viewModel.saveCustomPreset(it) },
            onDeletePreset = { viewModel.deletePreset(it) },
            onDismiss = { isEqDialogOpen = false }
        )
    }

    // Sleep Timer Dialog
    if (isSleepTimerOpen) {
        SleepTimerDialog(
            remainingMs = sleepTimerRemainingMs,
            onStartTimer = { minutes -> viewModel.startSleepTimer(minutes) },
            onCancelTimer = { viewModel.cancelSleepTimer() },
            onDismiss = { isSleepTimerOpen = false }
        )
    }

    // Create Playlist Dialog
    if (isCreatePlaylistOpen) {
        CreatePlaylistDialog(
            onDismiss = { isCreatePlaylistOpen = false },
            onCreatePlaylist = { name, desc, icon, colorHex ->
                viewModel.createPlaylist(name, desc, icon, colorHex)
            }
        )
    }

    // Add To Playlist Dialog
    if (songForAddToPlaylist != null) {
        AddToPlaylistDialog(
            song = songForAddToPlaylist,
            playlists = playlists,
            onSelectPlaylist = { playlist ->
                songForAddToPlaylist?.let { song ->
                    viewModel.addSongToPlaylist(playlist.id, song.id)
                }
                songForAddToPlaylist = null
            },
            onCreateNewPlaylist = {
                songForAddToPlaylist = null
                isCreatePlaylistOpen = true
            },
            onDismiss = { songForAddToPlaylist = null }
        )
    }

    // Song Details Dialog
    if (songForDetails != null) {
        SongDetailsDialog(
            song = songForDetails,
            onDismiss = { songForDetails = null }
        )
    }
}
