package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.Song
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun SongDetailsDialog(
    song: Song?,
    onDismiss: () -> Unit
) {
    if (song == null) return

    val locale = LocalConfiguration.current.locales[0]
    val fileSizeMb = String.format(locale, "%.2f MB", song.sizeBytes.toFloat() / (1024 * 1024))
    val dateStr = if (song.dateAdded > 0) {
        SimpleDateFormat("MMM dd, yyyy", locale).format(Date(song.dateAdded))
    } else {
        "Unknown"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = "Track Information",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DetailRow(label = "Title", value = song.title)
                DetailRow(label = "Artist", value = song.artist)
                DetailRow(label = "Album", value = song.album)
                DetailRow(label = "Genre", value = song.genre)
                DetailRow(label = "Duration", value = formatDuration(song.durationMs))
                DetailRow(label = "File Size", value = fileSizeMb)
                DetailRow(label = "Folder", value = song.folder)
                DetailRow(label = "Date Added", value = dateStr)
                DetailRow(label = "Audio Type", value = if (song.isCallRecording) "Call recording" else if (song.isRecording) "Voice note" else "Music file")
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done")
            }
        },
        shape = RoundedCornerShape(28.dp)
    )
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
