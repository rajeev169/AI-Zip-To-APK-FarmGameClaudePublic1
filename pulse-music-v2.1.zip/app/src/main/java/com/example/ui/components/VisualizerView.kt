package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun BarVisualizerView(
    bands: List<Float>,
    modifier: Modifier = Modifier,
    height: Dp = 60.dp,
    barColor: Color = MaterialTheme.colorScheme.primary,
    accentColor: Color = MaterialTheme.colorScheme.secondary
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val count = bands.size.coerceAtLeast(1)
        val totalWidth = size.width
        val barSpacing = 4.dp.toPx()
        val barWidth = ((totalWidth - (barSpacing * (count - 1))) / count).coerceAtLeast(2f)

        val gradient = Brush.verticalGradient(
            colors = listOf(accentColor, barColor),
            startY = 0f,
            endY = size.height
        )

        for (i in bands.indices) {
            val level = bands[i].coerceIn(0.05f, 1f)
            val barHeight = (size.height * level).coerceAtLeast(4f)
            val left = i * (barWidth + barSpacing)
            val top = (size.height - barHeight) / 2f

            drawRoundRect(
                brush = gradient,
                topLeft = Offset(left, top),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )
        }
    }
}

@Composable
fun MiniWaveVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = MaterialTheme.colorScheme.primary
) {
    val infiniteTransition = rememberInfiniteTransition(label = "MiniWaveTransition")
    val phase1 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "phase1"
    )
    val phase2 by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(550, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "phase2"
    )
    val phase3 by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(350, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "phase3"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val barW = w / 5f
        val gap = w / 10f

        val heights = if (isPlaying) {
            listOf(phase1, phase3, phase2)
        } else {
            listOf(0.2f, 0.2f, 0.2f)
        }

        for (i in heights.indices) {
            val currentH = h * heights[i]
            val left = i * (barW + gap)
            val top = h - currentH
            drawRoundRect(
                color = barColor,
                topLeft = Offset(left, top),
                size = Size(barW, currentH),
                cornerRadius = CornerRadius(2.dp.toPx())
            )
        }
    }
}
