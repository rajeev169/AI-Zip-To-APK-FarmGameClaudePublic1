package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.PlaybackState
import com.example.model.Song
import com.example.ui.components.formatDuration
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private enum class RecordingFilter(val label: String) { ALL("All"), CALLS("Calls"), VOICE("Voice notes") }

/** Call recordings and voice notes found on the phone, grouped by day. */
@Composable
fun RecordingsScreen(
    recordings: List<Song>,
    currentSong: Song?,
    playbackState: PlaybackState,
    onPlay: (Song) -> Unit,
    onShowDetails: (Song) -> Unit,
    onRescan: () -> Unit
) {
    var filter by rememberSaveable { mutableStateOf(RecordingFilter.ALL) }
    val calls = remember(recordings) { recordings.count { it.isCallRecording } }
    val voice = recordings.size - calls

    val visible = remember(recordings, filter) {
        when (filter) {
            RecordingFilter.ALL -> recordings
            RecordingFilter.CALLS -> recordings.filter { it.isCallRecording }
            RecordingFilter.VOICE -> recordings.filter { !it.isCallRecording }
        }
    }
    val locale = LocalConfiguration.current.locales[0]
    val grouped = remember(visible, locale) { visible.groupBy { dayLabel(it.dateAdded, locale) } }

    Column(modifier = Modifier.fillMaxSize().testTag("recordings_screen")) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            items(RecordingFilter.entries.toList()) { f ->
                val count = when (f) {
                    RecordingFilter.ALL -> recordings.size
                    RecordingFilter.CALLS -> calls
                    RecordingFilter.VOICE -> voice
                }
                FilterChip(
                    selected = filter == f,
                    onClick = { filter = f },
                    label = { Text("${f.label} · $count") },
                    leadingIcon = if (filter == f) {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    } else null,
                    shape = if (filter == f) RoundedCornerShape(20.dp) else RoundedCornerShape(12.dp)
                )
            }
        }

        if (visible.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(40.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))
                val (heading, otherHint) = when {
                    recordings.isEmpty() -> "No recordings found" to null
                    filter == RecordingFilter.CALLS -> "No call recordings yet" to
                        "$voice voice ${if (voice == 1) "note" else "notes"} found. Tap All or Voice notes to see them."
                    else -> "No voice notes yet" to
                        "$calls call ${if (calls == 1) "recording" else "recordings"} found. Tap All or Calls to see them."
                }
                Text(
                    heading,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
                if (otherHint != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        otherHint,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
                if (filter != RecordingFilter.VOICE) {
                    Spacer(Modifier.height(16.dp))
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "Using Google's Phone app?",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "It keeps call recordings private, so no other app can read them. To add one here: open Phone → Recents → tap the recorded call → Share → Pulse.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                FilledTonalButton(onClick = onRescan) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Scan again")
                }
            }
            return@Column
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 24.dp)
        ) {
            grouped.forEach { (label, items) ->
                item(key = "header_$label") {
                    Text(
                        text = label.uppercase(locale),
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 8.dp, top = 14.dp, bottom = 6.dp)
                    )
                }
                items(items, key = { it.id }) { rec ->
                    RecordingRow(
                        recording = rec,
                        isCurrent = currentSong?.id == rec.id,
                        isPlaying = currentSong?.id == rec.id && playbackState == PlaybackState.PLAYING,
                        onPlay = { onPlay(rec) },
                        onShowDetails = { onShowDetails(rec) }
                    )
                }
            }
        }
    }
}

@Composable
private fun RecordingRow(
    recording: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    onPlay: () -> Unit,
    onShowDetails: () -> Unit
) {
    val avatarColors = listOf(
        MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer,
        MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer,
        MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
    )
    val (avatarBg, avatarFg) = avatarColors[(recording.title.hashCode() and 0x7fffffff) % avatarColors.size]

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(if (isCurrent) MaterialTheme.colorScheme.surfaceContainerHigh else Color.Transparent)
            .clickable(onClick = onPlay)
            .padding(8.dp)
            .testTag("recording_${recording.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(48.dp).clip(CircleShape).background(avatarBg),
            contentAlignment = Alignment.Center
        ) {
            val initials = initialsOf(recording.title)
            if (initials != null) {
                Text(initials, color = avatarFg, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
            } else {
                Icon(
                    if (recording.isCallRecording) Icons.Default.Call else Icons.Default.Mic,
                    contentDescription = null,
                    tint = avatarFg
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                recording.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (recording.isCallRecording) Icons.Default.Call else Icons.Default.Mic,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    "${if (recording.isCallRecording) "Call" else "Voice note"} · ${timeLabel(recording.dateAdded, LocalConfiguration.current.locales[0])}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
        Text(
            formatDuration(recording.durationMs),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.width(4.dp))
        IconButton(onClick = onShowDetails) {
            Icon(Icons.Default.Info, contentDescription = "Recording details", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        FilledTonalIconButton(
            onClick = onPlay,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.size(44.dp)
        ) {
            Icon(
                if (isPlaying) Icons.Default.GraphicEq else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Playing" else "Play recording"
            )
        }
    }
}

private fun initialsOf(name: String): String? {
    val words = name.split(' ', '_', '-').filter { it.isNotBlank() && it.first().isLetter() }
    if (words.isEmpty()) return null
    return words.take(2).joinToString("") { it.first().uppercase() }
}

private fun dayLabel(timeMs: Long, locale: Locale): String {
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = timeMs }
    val sameYear = now.get(Calendar.YEAR) == then.get(Calendar.YEAR)
    val dayDiff = now.get(Calendar.DAY_OF_YEAR) - then.get(Calendar.DAY_OF_YEAR)
    return when {
        sameYear && dayDiff == 0 -> "Today"
        sameYear && dayDiff == 1 -> "Yesterday"
        sameYear -> SimpleDateFormat("EEE, d MMM", locale).format(Date(timeMs))
        else -> SimpleDateFormat("d MMM yyyy", locale).format(Date(timeMs))
    }
}

private fun timeLabel(timeMs: Long, locale: Locale): String =
    SimpleDateFormat("h:mm a", locale).format(Date(timeMs))
