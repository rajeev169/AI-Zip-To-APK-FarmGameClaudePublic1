package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.PlaybackState
import com.example.model.Song
import com.example.model.SortOption
import com.example.ui.components.SongItemRow
import com.example.ui.components.AlbumArtImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TracksScreen(
    songs: List<Song>,
    currentSong: Song?,
    playbackState: PlaybackState,
    sortOption: SortOption,
    onSortOptionSelected: (SortOption) -> Unit,
    onSongClick: (Song) -> Unit,
    onPlayAll: (Boolean) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onShowDetails: (Song) -> Unit,
    onRescan: () -> Unit
) {
    var sortMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("tracks_screen")
    ) {
        // Expressive action row: big Shuffle pill, Play square, sort menu
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { onPlayAll(true) },
                enabled = songs.isNotEmpty(),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("shuffle_all_btn")
            ) {
                Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text("Shuffle all", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }

            FilledTonalIconButton(
                onClick = { onPlayAll(false) },
                enabled = songs.isNotEmpty(),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .size(width = 64.dp, height = 56.dp)
                    .testTag("play_all_btn")
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Play all", modifier = Modifier.size(26.dp))
            }

            Box {
                FilledTonalIconButton(
                    onClick = { sortMenuExpanded = true },
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .size(width = 56.dp, height = 56.dp)
                        .testTag("sort_menu_btn")
                ) {
                    Icon(Icons.Default.Sort, contentDescription = "Sort songs")
                }

                DropdownMenu(
                    expanded = sortMenuExpanded,
                    onDismissRequest = { sortMenuExpanded = false }
                ) {
                    SortOption.entries.forEach { option ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = option.displayName,
                                    fontWeight = if (sortOption == option) FontWeight.Bold else FontWeight.Normal,
                                    color = if (sortOption == option) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            },
                            onClick = {
                                onSortOptionSelected(option)
                                sortMenuExpanded = false
                            }
                        )
                    }
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text("Rescan library") },
                        leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null) },
                        onClick = {
                            sortMenuExpanded = false
                            onRescan()
                        }
                    )
                }
            }
        }

        if (songs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.MusicOff,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No songs found",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onRescan,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Scan Again")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                val recent = songs.sortedByDescending { it.dateAdded }.take(10)
                if (songs.size >= 6) {
                    item(key = "recent_header") {
                        Text(
                            "Recently added",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                        )
                    }
                    item(key = "recent_row") {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            itemsIndexed(recent, key = { _, it -> "recent_" + it.id }) { index, song ->
                                Column(
                                    modifier = Modifier
                                        .width(112.dp)
                                        .clip(RoundedCornerShape(20.dp))
                                        .clickable { onSongClick(song) }
                                ) {
                                    AlbumArtImage(
                                        song = song,
                                        modifier = Modifier.size(112.dp),
                                        shape = if (index % 3 == 1) {
                                            RoundedCornerShape(topStart = 56.dp, topEnd = 56.dp, bottomStart = 28.dp, bottomEnd = 28.dp)
                                        } else {
                                            RoundedCornerShape(28.dp)
                                        }
                                    )
                                    Text(
                                        song.title,
                                        style = MaterialTheme.typography.labelLarge,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(top = 6.dp)
                                    )
                                    Text(
                                        song.artist,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
                item(key = "all_header") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp, bottom = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text("All songs", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text(
                            "${songs.size} songs · ${sortOption.displayName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                items(songs, key = { it.id }) { song ->
                    val isCurrent = currentSong?.id == song.id
                    val isPlaying = isCurrent && playbackState == PlaybackState.PLAYING

                    SongItemRow(
                        song = song,
                        isPlaying = isPlaying,
                        isCurrent = isCurrent,
                        onClick = { onSongClick(song) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onPlayNext = { onPlayNext(song) },
                        onAddToQueue = { onAddToQueue(song) },
                        onAddToPlaylist = { onAddToPlaylist(song) },
                        onShowDetails = { onShowDetails(song) }
                    )
                }
            }
        }
    }
}
