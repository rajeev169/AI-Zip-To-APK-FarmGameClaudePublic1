package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.model.AppTheme

private val GeometricBalanceLightColorScheme = lightColorScheme(
    primary = GeoPrimaryLight,
    onPrimary = GeoOnPrimaryLight,
    primaryContainer = GeoPrimaryContainerLight,
    onPrimaryContainer = GeoOnPrimaryContainerLight,
    secondary = GeoSecondaryLight,
    onSecondary = GeoOnSecondaryLight,
    secondaryContainer = GeoSecondaryContainerLight,
    onSecondaryContainer = GeoOnSecondaryContainerLight,
    tertiary = GeoTertiaryLight,
    onTertiary = GeoOnTertiaryLight,
    tertiaryContainer = GeoTertiaryContainerLight,
    onTertiaryContainer = GeoOnTertiaryContainerLight,
    background = GeoBackgroundLight,
    onBackground = GeoOnBackgroundLight,
    surface = GeoSurfaceLight,
    onSurface = GeoOnSurfaceLight,
    surfaceVariant = GeoSurfaceVariantLight,
    onSurfaceVariant = GeoOnSurfaceVariantLight,
    outline = GeoOutlineLight,
    outlineVariant = GeoOutlineVariantLight
)

private val GeometricBalanceDarkColorScheme = darkColorScheme(
    primary = GeoPrimaryDark,
    onPrimary = GeoOnPrimaryDark,
    primaryContainer = GeoPrimaryContainerDark,
    onPrimaryContainer = GeoOnPrimaryContainerDark,
    secondary = GeoSecondaryDark,
    onSecondary = GeoOnSecondaryDark,
    secondaryContainer = GeoSecondaryContainerDark,
    onSecondaryContainer = GeoOnSecondaryContainerDark,
    tertiary = GeoTertiaryDark,
    onTertiary = GeoOnTertiaryDark,
    tertiaryContainer = GeoTertiaryContainerDark,
    onTertiaryContainer = GeoOnTertiaryContainerDark,
    background = GeoBackgroundDark,
    onBackground = GeoOnBackgroundDark,
    surface = GeoSurfaceDark,
    onSurface = GeoOnSurfaceDark,
    surfaceVariant = GeoSurfaceVariantDark,
    onSurfaceVariant = GeoOnSurfaceVariantDark,
    outline = GeoOutlineDark,
    outlineVariant = GeoOutlineVariantDark
)

private val MidnightAmoledColorScheme = darkColorScheme(
    primary = GeoPrimaryDark,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF2B1D4F),
    onPrimaryContainer = Color(0xFFEADDFF),
    secondary = GeoSecondaryDark,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF332D41),
    onSecondaryContainer = Color(0xFFE8DEF8),
    tertiary = GeoTertiaryDark,
    background = AmoledBackground,
    onBackground = Color.White,
    surface = AmoledSurface,
    onSurface = Color.White,
    surfaceVariant = AmoledSurfaceVariant,
    onSurfaceVariant = Color(0xFFCAC4D0),
    outline = Color(0xFF49454F)
)

private fun ColorScheme.withAccent(
    primary: Color,
    onPrimary: Color,
    primaryContainer: Color,
    onPrimaryContainer: Color
) = copy(
    primary = primary,
    onPrimary = onPrimary,
    primaryContainer = primaryContainer,
    onPrimaryContainer = onPrimaryContainer,
    surfaceTint = primary
)

private fun accentScheme(theme: AppTheme, dark: Boolean): ColorScheme {
    val base = if (dark) GeometricBalanceDarkColorScheme else GeometricBalanceLightColorScheme
    return when (theme) {
        AppTheme.SUNSET_AMBER -> if (dark) base.withAccent(Color(0xFFFFB870), Color(0xFF4A2800), Color(0xFF693C00), Color(0xFFFFDCBE))
            else base.withAccent(Color(0xFF8B5000), Color.White, Color(0xFFFFDCBE), Color(0xFF2C1600))
        AppTheme.CYBER_EMERALD -> if (dark) base.withAccent(Color(0xFF6CDBAC), Color(0xFF003826), Color(0xFF005138), Color(0xFF89F8C7))
            else base.withAccent(Color(0xFF006C4C), Color.White, Color(0xFF89F8C7), Color(0xFF002114))
        AppTheme.OCEAN_BLUE -> if (dark) base.withAccent(Color(0xFF9ECAFF), Color(0xFF003258), Color(0xFF00497D), Color(0xFFD1E4FF))
            else base.withAccent(Color(0xFF0061A4), Color.White, Color(0xFFD1E4FF), Color(0xFF001D36))
        else -> base
    }
}

/** Material 3 Expressive shape scale: generous, friendly corners. */
val ExpressiveShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun MyApplicationTheme(
    appTheme: AppTheme = AppTheme.DEEP_PURPLE,
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when (appTheme) {
        AppTheme.DYNAMIC -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            } else {
                if (darkTheme) GeometricBalanceDarkColorScheme else GeometricBalanceLightColorScheme
            }
        }
        AppTheme.MIDNIGHT_AMOLED -> MidnightAmoledColorScheme
        else -> accentScheme(appTheme, darkTheme)
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = ExpressiveShapes,
        content = content
    )
}
