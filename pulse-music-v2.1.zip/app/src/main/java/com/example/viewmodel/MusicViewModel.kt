package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.MusicApplication
import com.example.audio.AudioPlayerManager
import com.example.data.local.entity.EqualizerPresetEntity
import com.example.data.local.entity.PlaylistEntity
import com.example.data.repository.MusicRepository
import com.example.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as MusicApplication
    private val repository: MusicRepository = app.repository
    val playerManager: AudioPlayerManager = app.playerManager

    // Search & Filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _sortOption = MutableStateFlow(SortOption.TITLE_ASC)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    // Settings (saved on the device)
    private val settingsStore = app.settingsStore
    val appSettings: StateFlow<AppSettings> = settingsStore.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    /** Call recordings and voice notes, newest first. */
    val recordings: StateFlow<List<Song>> = combine(
        repository.recordings,
        repository.allFavoriteIds
    ) { recs, favoriteIds ->
        recs.map { it.copy(isFavorite = favoriteIds.contains(it.id)) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Playback state forwarded from PlayerManager
    val currentSong: StateFlow<Song?> = playerManager.currentSong
    val playbackState: StateFlow<PlaybackState> = playerManager.playbackState
    val currentPosition: StateFlow<Long> = playerManager.currentPosition
    val duration: StateFlow<Long> = playerManager.duration
    val repeatMode: StateFlow<RepeatMode> = playerManager.repeatMode
    val isShuffle: StateFlow<Boolean> = playerManager.isShuffle
    val playbackSpeed: StateFlow<Float> = playerManager.playbackSpeed
    val queue: StateFlow<List<Song>> = playerManager.queue
    val currentIndex: StateFlow<Int> = playerManager.currentIndex
    val visualizerBands: StateFlow<List<Float>> = playerManager.visualizerBands
    val sleepTimerRemainingMs: StateFlow<Long> = playerManager.sleepTimerRemainingMs
    val eqEnabled: StateFlow<Boolean> = playerManager.eqEnabled
    val eqBands: StateFlow<List<Int>> = playerManager.eqBands
    val bassBoostLevel: StateFlow<Int> = playerManager.bassBoostLevel
    val virtualizerLevel: StateFlow<Int> = playerManager.virtualizerLevel
    val parsedLyrics: StateFlow<List<LyricsLine>> = playerManager.parsedLyrics
    val currentLyricIndex: StateFlow<Int> = playerManager.currentLyricIndex

    // Database flows
    val allPlaylists: StateFlow<List<PlaylistEntity>> = repository.allPlaylists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allPresets: StateFlow<List<EqualizerPresetEntity>> = repository.allPresets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Real play history for the smart playlists
    val recentlyPlayed: StateFlow<List<Song>> = repository.getRecentSongs(20)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val mostPlayed: StateFlow<List<Song>> = repository.getMostPlayedSongs(20)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Combined song list with favorite mapping and sorting
    val allSongs: StateFlow<List<Song>> = combine(
        repository.deviceSongs,
        repository.allFavoriteIds,
        _sortOption,
        _searchQuery,
        appSettings
    ) { rawSongs, favoriteIds, sort, query, settings ->
        val filteredByDuration = if (settings.isFilterShortAudio) {
            rawSongs.filter { it.durationMs >= 30_000 }
        } else {
            rawSongs
        }

        val mapped = filteredByDuration.map { song ->
            song.copy(isFavorite = favoriteIds.contains(song.id))
        }

        val filtered = if (query.isBlank()) {
            mapped
        } else {
            val q = query.trim().lowercase()
            mapped.filter {
                it.title.lowercase().contains(q) ||
                it.artist.lowercase().contains(q) ||
                it.album.lowercase().contains(q) ||
                it.genre.lowercase().contains(q)
            }
        }

        when (sort) {
            SortOption.TITLE_ASC -> filtered.sortedBy { it.title.lowercase() }
            SortOption.TITLE_DESC -> filtered.sortedByDescending { it.title.lowercase() }
            SortOption.ARTIST_ASC -> filtered.sortedBy { it.artist.lowercase() }
            SortOption.DATE_ADDED_DESC -> filtered.sortedByDescending { it.dateAdded }
            SortOption.DURATION_DESC -> filtered.sortedByDescending { it.durationMs }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Derived Albums
    val albums: StateFlow<List<Album>> = allSongs.map { songs ->
        songs.groupBy { it.album }
            .map { (albumTitle, songList) ->
                val first = songList.first()
                Album(
                    id = albumTitle,
                    title = albumTitle,
                    artist = first.artist,
                    songCount = songList.size,
                    albumArtUri = first.albumArtUri
                )
            }.sortedBy { it.title.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Derived Artists
    val artists: StateFlow<List<Artist>> = allSongs.map { songs ->
        songs.groupBy { it.artist }
            .map { (artistName, songList) ->
                val albumCount = songList.map { it.album }.distinct().size
                Artist(
                    id = artistName,
                    name = artistName,
                    songCount = songList.size,
                    albumCount = albumCount
                )
            }.sortedBy { it.name.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Derived Folders
    val folders: StateFlow<List<Folder>> = allSongs.map { songs ->
        songs.groupBy { it.folder }
            .map { (folderName, songList) ->
                Folder(
                    path = folderName,
                    name = folderName,
                    songCount = songList.size
                )
            }.sortedBy { it.name.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        scanMusic()
        // Keep the player's crossfade in sync with the saved setting.
        viewModelScope.launch {
            appSettings.collect { playerManager.setCrossfade(it.isCrossfadeEnabled, it.crossfadeDurationSec) }
        }
    }

    fun scanMusic() {
        viewModelScope.launch {
            val scanned = repository.scanDeviceMusic()
            if (playerManager.currentSong.value == null && scanned.isNotEmpty()) {
                playerManager.setQueue(scanned, startIndex = 0, startPlaying = false)
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun setSortOption(option: SortOption) {
        _sortOption.value = option
    }

    // Playback Controls
    fun playSong(song: Song) {
        val currentList = allSongs.value
        val index = currentList.indexOfFirst { it.id == song.id }
        if (index >= 0) {
            playerManager.setQueue(currentList, startIndex = index, startPlaying = true)
        } else {
            playerManager.setQueue(listOf(song), startIndex = 0, startPlaying = true)
        }
        viewModelScope.launch {
            repository.recordPlay(song.id)
        }
    }

    fun playSongFromList(songs: List<Song>, song: Song) {
        val index = songs.indexOfFirst { it.id == song.id }
        if (index >= 0) {
            playerManager.setQueue(songs, startIndex = index, startPlaying = true)
            viewModelScope.launch {
                repository.recordPlay(song.id)
            }
        }
    }

    fun playAll(songs: List<Song>, shuffle: Boolean = false) {
        if (songs.isNotEmpty()) {
            playerManager.setShuffle(shuffle)
            val start = if (shuffle) songs.indices.random() else 0
            playerManager.setQueue(songs, startIndex = start, startPlaying = true)
        }
    }

    /** Plays a recording, with the other recordings of the same list queued after it. */
    fun playRecording(recording: Song) {
        playSongFromList(recordings.value, recording)
    }

    /** Result of the last "Share to Pulse": number of recordings saved, or null when nothing pending. */
    private val _sharedImportResult = MutableStateFlow<Int?>(null)
    val sharedImportResult: StateFlow<Int?> = _sharedImportResult.asStateFlow()

    /** Saves recordings shared to Pulse into the call recordings folder, then rescans. */
    fun importSharedRecordings(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val saved = repository.saveSharedCallRecordings(uris)
            repository.scanDeviceMusic()
            _sharedImportResult.value = saved
        }
    }

    fun consumeSharedImportResult() {
        _sharedImportResult.value = null
    }

    /** Plays an audio file opened from another app ("Open with Pulse"). */
    fun playExternalUri(uri: Uri) {
        viewModelScope.launch {
            val song = repository.songFromUri(uri)
            playerManager.setShuffle(false)
            playerManager.setQueue(listOf(song), startIndex = 0, startPlaying = true)
        }
    }

    fun togglePlayPause() {
        playerManager.togglePlayPause()
    }

    fun seekTo(positionMs: Long) {
        playerManager.seekTo(positionMs)
    }

    fun playNext() {
        playerManager.playNext()
    }

    fun playPrevious() {
        playerManager.playPrevious()
    }

    fun toggleRepeatMode() {
        playerManager.toggleRepeatMode()
    }

    fun toggleShuffle() {
        playerManager.toggleShuffle()
    }

    fun setPlaybackSpeed(speed: Float) {
        playerManager.setPlaybackSpeed(speed)
    }

    // Queue Management
    fun playQueueItem(index: Int) {
        playerManager.playQueueItem(index)
    }

    fun addToQueue(song: Song) {
        playerManager.addToQueue(song)
    }

    fun playNextInQueue(song: Song) {
        playerManager.playNextInQueue(song)
    }

    fun removeFromQueue(index: Int) {
        playerManager.removeQueueItem(index)
    }

    fun clearQueue() {
        playerManager.clearQueue()
    }

    // Favorites & Playlists
    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            repository.toggleFavorite(song.id, !song.isFavorite)
        }
    }

    fun createPlaylist(name: String, description: String = "", iconName: String = "playlist", colorHex: String = "#6750A4") {
        viewModelScope.launch {
            repository.createPlaylist(name, description, iconName, colorHex)
        }
    }

    fun deletePlaylist(playlist: PlaylistEntity) {
        viewModelScope.launch {
            repository.deletePlaylist(playlist.id)
        }
    }

    fun addSongToPlaylist(playlistId: Long, songId: String) {
        viewModelScope.launch {
            repository.addSongToPlaylist(playlistId, songId)
        }
    }

    fun removeSongFromPlaylist(playlistId: Long, songId: String) {
        viewModelScope.launch {
            repository.removeSongFromPlaylist(playlistId, songId)
        }
    }

    fun getSongsForPlaylist(playlistId: Long): Flow<List<Song>> {
        return repository.getSongsForPlaylist(playlistId)
    }

    // Equalizer & Sound FX
    fun setEqualizerBand(bandIndex: Int, level: Int) {
        playerManager.setEqualizerBand(bandIndex, level)
    }

    fun applyPreset(preset: EqualizerPresetEntity) {
        val bands = preset.bandLevels.split(",").mapNotNull { it.trim().toIntOrNull() }
        if (bands.size == 5) {
            playerManager.setEqualizerPreset(bands, preset.bassBoost, preset.virtualizer)
        }
    }

    fun saveCustomPreset(name: String) {
        viewModelScope.launch {
            repository.saveEqualizerPreset(
                name = name,
                bandLevels = playerManager.eqBands.value,
                bass = playerManager.bassBoostLevel.value,
                virt = playerManager.virtualizerLevel.value
            )
        }
    }

    fun deletePreset(preset: EqualizerPresetEntity) {
        viewModelScope.launch {
            repository.deletePreset(preset)
        }
    }

    fun setBassBoost(level: Int) {
        playerManager.setBassBoost(level)
    }

    fun setVirtualizer(level: Int) {
        playerManager.setVirtualizer(level)
    }

    fun toggleEqualizer(enabled: Boolean) {
        playerManager.toggleEqualizer(enabled)
    }

    // Sleep Timer
    fun startSleepTimer(minutes: Int) {
        playerManager.startSleepTimer(minutes)
    }

    fun cancelSleepTimer() {
        playerManager.cancelSleepTimer()
    }

    // Settings Updates (saved with DataStore)
    fun setTheme(theme: AppTheme) {
        viewModelScope.launch { settingsStore.setTheme(theme) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settingsStore.setThemeMode(mode) }
    }

    fun toggleCrossfade(enabled: Boolean) {
        viewModelScope.launch { settingsStore.setCrossfade(enabled) }
    }

    fun setCrossfadeDuration(sec: Int) {
        viewModelScope.launch { settingsStore.setCrossfadeSeconds(sec) }
    }

    fun toggleFilterShortAudio(enabled: Boolean) {
        viewModelScope.launch { settingsStore.setFilterShortAudio(enabled) }
    }
}
